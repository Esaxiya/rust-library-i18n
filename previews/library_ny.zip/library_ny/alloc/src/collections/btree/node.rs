// Uku ndikuyesa kukhazikitsa kutsatira zomwe zanenedwa
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Popeza Rust ilibe mitundu yodalira komanso kubwereranso kwa ma polymorphic, timachita mosatekeseka kwambiri.
//

// Cholinga chachikulu cha gawoli ndikupewa zovuta pakuwona mtengo ngati chidebe chabwinobwino (ngati chododometsa) ndikupewa kuthana ndi obalalika a B-Tree.
//
// Mwakutero, gawo ili silisamala ngati zolembedwazo zidasankhidwa, ndi mfundo ziti zomwe zingakwaniritse, kapena ngakhale zomwe underfull amatanthauza.Komabe, timadalira ochepa omwe sangasinthe:
//
// - Mitengo iyenera kukhala ndi yunifolomu depth/height.Izi zikutanthauza kuti njira iliyonse mpaka tsamba kuchokera pa mfundo yapatsidwa imakhala yofanana ndendende.
// - Node ya kutalika `n` ili ndi mafungulo a `n`, mfundo za `n`, ndi m'mbali za `n + 1`.
//   Izi zikutanthauza kuti ngakhale mfundo yopanda kanthu ili ndi edge imodzi.
//   Patsamba lamasamba, "having an edge" imangotanthauza kuti titha kuzindikira malo, popeza m'mbali mwa masamba mulibe kanthu ndipo sitifunikira choyimira chilichonse.
// Pakatikati, edge zonse zimafotokoza malo ndipo zimakhala ndi cholozera ku mfundo ya mwana.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Zomwe zikuyimira masamba am'magawo komanso gawo la mawonekedwe amkati.
struct LeafNode<K, V> {
    /// Tikufuna kukhala ovomerezeka mu `K` ndi `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Mndandanda wa node iyi mu gulu la `edges` yamagulu.
    /// `*node.parent.edges[node.parent_idx]` iyenera kukhala yofanana ndi `node`.
    /// Izi zimangotsimikizika kuti ziyambitsidwe `parent` ikakhala yopanda tanthauzo.
    parent_idx: MaybeUninit<u16>,

    /// Chiwerengero cha mafungulo ndikuyamikira mfundo izi.
    len: u16,

    /// Zolemba zosunga zomwe zidafotokozeredwa.
    /// Zinthu zoyamba za `len` zokha zokha ndizomwe zimayambitsidwa komanso ndizovomerezeka.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Imayambitsa `LeafNode` yatsopano m'malo mwake.
    unsafe fn init(this: *mut Self) {
        // Monga mfundo yodziwika bwino, timasiya minda tisanakhazikitsidwe ngati ingatheke, chifukwa izi zikuyenera kukhala zofulumira pang'ono komanso zosavuta kutsatira ku Valgrind.
        //
        unsafe {
            // parent_idx, makiyi, ndi ma vals onse mwina ndiUnUnit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Pangani bokosi latsopano la `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Zomwe zikuyimira magawo amkati.Monga momwe ziliri ndi `LeafNode`s, izi ziyenera kubisika kuseri kwa`BoxedNode`s kuti tipewe kutaya makiyi ndi malingaliro omwe sanatchulidwepo.
/// Cholozera chilichonse ku `InternalNode` chitha kuponyedwa kwa cholozera ku gawo loyambira la `LeafNode` la node, kulola kuti code ichitepo kanthu pamasamba ndi mkati mwake osafunikira kuti alembetse.
///
/// Izi zimatheka chifukwa chogwiritsa ntchito `repr(C)`.
///
#[repr(C)]
// gdb_providers.py imagwiritsa ntchito dzina lamtunduwu pofufuza.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Zolemba kwa ana amfundo iyi.
    /// `len + 1` mwa izi zimawerengedwa kuti ndizoyambika komanso ndizovomerezeka, kupatula kuti pafupi kumapeto, mtengo umagwiridwa kudzera mu mtundu wa `Dying`, zina mwazolembera izi zikulendewera.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Pangani bokosi latsopano la `InternalNode`.
    ///
    /// # Safety
    /// Zosintha zamkati zamkati ndikuti zimakhala ndi yoyambira imodzi yoyambira komanso yovomerezeka edge.
    /// Ntchitoyi siyikhazikitsa edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Tiyenera kungoyambitsa zidziwitsozo;m'mbali ndi MwinaUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Cholozera chosamalidwa, chosasunthika ku mfundo.Ichi ndi cholozera cha `LeafNode<K, V>` kapena cholozera cha `InternalNode<K, V>`.
///
/// Komabe, `BoxedNode` ilibe chidziwitso kuti ndi mitundu iti yamtundu womwe ilimo, ndipo, mwina chifukwa chosowa chidziwitso ichi, si mtundu wina ndipo alibe wowononga.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Mzu wa mtengo womwe uli nawo.
///
/// Dziwani kuti izi zilibe wowononga, ndipo ziyenera kutsukidwa pamanja.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Imabwezeretsa mtengo watsopano womwe umakhala nawo, wokhala ndi mizu yake yomwe ilibe kanthu.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` sayenera kukhala zero.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Zonse zimabwereka muzu womwe uli nawo.
    /// Mosiyana ndi `reborrow_mut`, izi ndi zotetezeka chifukwa phindu lobweza silingagwiritsidwe ntchito kuwononga muzu, ndipo sipangakhale zonena za mtengowo.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Pang'ono pang'ono imabwereka mzu womwe uli nawo.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Kusintha kosasinthika kukalozera komwe kumaloleza kuwoloka ndikupereka njira zowononga osati china chilichonse.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Ikuwonjezera njira yatsopano yamkati yokhala ndi edge imodzi yomwe ikuloza kuzolozera wam'mbuyomu, ipange mfundo yatsopanoyo, ndikubweza.
    /// Izi zimawonjezera kutalika ndi 1 ndipo ndizosiyana ndi `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, kupatula kuti tayiwala kuti tili mkati tsopano:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Imachotsa mfundo zamkati zamkati, pogwiritsa ntchito mwana wawo woyamba monga mizu yatsopano.
    /// Monga zimangotchulidwira kuti mizu yokhala ndi mwana m'modzi yekha, palibe kuyeretsa komwe kumachitika pamakiyi, mfundo ndi ana ena onse.
    ///
    /// Izi zimachepetsa kutalika ndi 1 ndipo ndizosiyana ndi `push_internal_level`.
    ///
    /// Imafunikira kufikira kokha ku chinthu cha `Root` koma osati kuzu lazu;
    /// sizingasokoneze ma handle ena kapena kutanthauzira kuzu wazu.
    ///
    /// Panics ngati mulibe mkati mwake, mwachitsanzo, ngati mizu yake ndi tsamba.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // CHITETEZO: tinanena kuti tili mkati.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // CHITETEZO: tinabwereka `self` kokha ndipo mtundu wake wobwereka ndiwokha.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // CHITETEZO: edge yoyamba imayambitsidwa nthawi zonse.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` nthawi zonse imakhala yofanana mu `K` ndi `V`, ngakhale `BorrowType` ili `Mut`.
// Izi ndizolakwika, koma sizingabweretse chitetezo chilichonse chifukwa chogwiritsa ntchito `NodeRef` chifukwa timakhala opanda `K` ndi `V`.
//
// Komabe, mtundu uliwonse wa anthu ukakulunga `NodeRef`, onetsetsani kuti uli ndi kusiyanasiyana kolondola.
//
/// Kutchulidwa kwa mfundo.
///
/// Mtundu uwu uli ndi magawo angapo omwe amawongolera momwe amachitira:
/// - `BorrowType`: Mtundu wachabechabe womwe umalongosola mtundu wa ngongole ndikunyamula moyo wonse.
///    - Ngati iyi ndi `Immut<'a>`, `NodeRef` imachita pafupifupi ngati `&'a Node`.
///    - Izi zikakhala `ValMut<'a>`, `NodeRef` imachita pafupifupi ngati `&'a Node` pokhudzana ndi mafungulo ndi kapangidwe ka mitengo, komanso imaperekanso maumboni ambiri osinthika pamitengo yonse pamtengo.
///    - Ngati iyi ndi `Mut<'a>`, `NodeRef` imachita pafupifupi ngati `&'a mut Node`, ngakhale njira zolowetsera zimaloleza cholozera chosinthika kuti chikhale pamodzi.
///    - Ngati iyi ndi `Owned`, `NodeRef` imachita pafupifupi ngati `Box<Node>`, koma ilibe wowononga, ndipo iyenera kutsukidwa pamanja.
///    - Izi zikakhala `Dying`, `NodeRef` imagwirabe ntchito ngati `Box<Node>`, koma ili ndi njira zowonongera mtengo pang'ono pang'ono, ndipo njira wamba, ngakhale sizinatchulidwe kuti ndizosavomerezeka kuyimba, zitha kuyitanitsa UB ngati itayikidwa molakwika.
///
///   Popeza `NodeRef` iliyonse imalola kudutsa pamtengo, `BorrowType` imagwira ntchito pamtengo wonsewo, osati pamfundo yokha.
/// - `K` ndi `V`: Izi ndi mitundu ya mafungulo ndi mfundo zomwe zimasungidwa munfundo.
/// - `Type`: Izi zitha kukhala `Leaf`, `Internal`, kapena `LeafOrInternal`.
/// Pamene iyi ndi `Leaf`, `NodeRef` imaloza pamfundo, pomwe iyi ndi `Internal` pomwe `NodeRef` imaloza node yamkati, ndipo ikakhala `LeafOrInternal` `NodeRef` ikhoza kuloza mtundu uliwonse wa mfundo.
///   `Type` amatchedwa `NodeType` akagwiritsidwa ntchito kunja kwa `NodeRef`.
///
/// Onse awiri `BorrowType` ndi `NodeType` amaletsa njira zomwe timagwiritsa ntchito, kugwiritsa ntchito chitetezo chamtundu wa static.Pali zoperewera momwe tingagwiritsire ntchito zoletsedwazi:
/// - Pazoyimira zamtundu uliwonse, titha kungotanthauzira njira mwina mwanjira ina kapena yamtundu wina.
/// Mwachitsanzo, sitingafotokozere njira ngati `into_kv` mozama kwa onse `BorrowType`, kapena kamodzi pamitundu yonse yomwe imakhala ndi moyo wonse, chifukwa tikufuna kuti ibweretse zolemba za `&'a`.
///   Chifukwa chake, timangotanthauzira za mtundu wopanda mphamvu `Immut<'a>`.
/// - Sitingakakamizidwe kuchokera ku `Mut<'a>` mpaka `Immut<'a>`.
///   Chifukwa chake, tiyenera kutchula `reborrow` momveka bwino `NodeRef` kuti tithe kufikira njira ngati `into_kv`.
///
/// Njira zonse pa `NodeRef` zomwe zimabweretsanso zina, mwina:
/// - Tengani `self` pamtengo, ndikubwezeretsani nthawi yamoyo yonyamula `BorrowType`.
///   Nthawi zina, kugwiritsa ntchito njira yotere, tifunika kuyimbira `reborrow_mut`.
/// - Tengani `self` pofotokoza, ndipo (implicitly) mubwezeretse moyo wonse wa zolembedwazo, m'malo mwa nthawi yanthawi yonse yomwe `BorrowType` idatenga.
/// Mwanjira imeneyi, wobwereketsa amatitsimikizira kuti `NodeRef` imakhalabe yobwereka malinga ngati kagwiritsidwe ntchito kamagwiritsidwanso ntchito.
///   Njira zothandizira kulowetsa kukhotetsa lamuloli pobweza pointer yaiwisi, kutanthauza, popanda nthawi iliyonse.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Chiwerengero cha mulingo womwe masamba ake ndi mulingo wamasamba ndizosiyana, mawonekedwe osasintha omwe sangathe kufotokozedweratu ndi `Type`, ndikuti nodeyo siyimasunga.
    /// Tiyenera kungosunga kutalika kwa mizu, ndikupeza kutalika kwina kulikonse.
    /// Iyenera kukhala zero ngati `Type` ndi `Leaf` komanso osakhala zero ngati `Type` ndi `Internal`.
    ///
    ///
    height: usize,
    /// Cholozera tsamba kapena mfundo zamkati.
    /// Tanthauzo la `InternalNode` limatsimikizira kuti cholozera ndi chovomerezeka m'njira iliyonse.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Chotsani cholozera cha node chomwe chinali chodzaza ndi `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Ikuwonetsa tsatanetsatane wa mfundo zamkati.
    ///
    /// Imabwezera ptr yaiwisi kuti ipewe kusokoneza zina zomwe zafotokozedwera.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // CHITETEZO: mtundu wamtundu wa static ndi `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Imabwereketsa mwayi wopeza zokhazokha zamkati.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Imapeza kutalika kwa mfundo.Iyi ndiye nambala yamakiyi kapena zikhulupiriro.
    /// Chiwerengero cha m'mphepete ndi `len() + 1`.
    /// Dziwani kuti, ngakhale kukhala otetezeka, kuyitanitsa ntchitoyi kumatha kuyambitsa zovuta zomwe zingasinthidwe zomwe malamulo osatetezeka apanga.
    ///
    pub fn len(&self) -> usize {
        // Mwakhama, timangopeza gawo la `len` apa.
        // Ngati BorrowType ndi marker::ValMut, pakhoza kukhala mafotokozedwe osinthika osunthika pazikhalidwe zomwe sitiyenera kuzichita.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Kubwezeretsa kuchuluka kwa milingo yomwe mfundo ndi masamba ndizosiyana.
    /// Kutalika kwa zero kumatanthauza kuti mfundoyo ndi tsamba lokha.
    /// Ngati mukujambula mitengo yokhala ndi mizu pamwamba, chiwerengerocho chimati kukwera kwake kwa nodeyo.
    /// Ngati mungayerekezere mitengo yomwe ili ndi masamba pamwamba, chiwerengerocho chimati kutalika kwake kumakwera pamwamba pamfundoyo.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Kwa kanthawi amatulutsa china, chosasinthika cha mfundo yomweyo.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Amawululira tsamba lililonse patsamba lililonse kapena mkati mwake.
    ///
    /// Imabwezera ptr yaiwisi kuti ipewe kusokoneza zina zomwe zafotokozedwera.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Node iyenera kukhala yoyenera pamtundu wina wa LeafNode.
        // Izi sizikutanthauza mtundu wa NodeRef chifukwa sitikudziwa ngati iyenera kukhala yapadera kapena yogawana.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Amapeza kholo la mfundo zomwe zilipo pano.
    /// Kubwezeretsa `Ok(handle)` ngati mfundo yomwe ilipo ilidi ndi kholo, pomwe `handle` imaloza ku edge ya kholo yomwe imaloza ku mfundo yomwe ilipo.
    ///
    /// Kubwezeretsa `Err(self)` ngati mfundo yapano ilibe kholo, ndikubwezeretsanso `NodeRef` yoyambayo.
    ///
    /// Dzinali limatengera mitengo yazithunzi yomwe ili ndi mizu yake pamwamba.
    ///
    /// `edge.descend().ascend().unwrap()` ndipo `node.ascend().unwrap().descend()` sayenera, onse kuchita bwino, osachita chilichonse.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Tiyenera kugwiritsa ntchito zolozera zosaphika ku mfundo chifukwa, ngati BorrowType ndi marker::ValMut, pakhoza kukhala kutanthauzira kosinthika kwa mfundo zomwe sitiyenera kuzisokoneza.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Dziwani kuti `self` iyenera kukhala yopanda malire.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Dziwani kuti `self` iyenera kukhala yopanda malire.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Amawululira tsamba lililonse la tsamba lililonse kapena mfundo zamkati mumtengo wosasunthika.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // CHITETEZO: sipangakhale zolemba zomwe zingasinthike pamtengo womwe udabwereka ngati `Immut`.
        unsafe { &*ptr }
    }

    /// Imabwereka mawonekedwe mu mafungulo omwe asungidwa munsinga.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Zofanana ndi `ascend`, zimafotokoza za mfundo zamakolo za node, komanso zimasinthitsa mfundo zomwe zikuchitika pakadali pano.
    /// Izi ndizosatetezeka chifukwa mfundo zomwe zilipo pano zitha kupezeka ngakhale zitasunthidwa.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Zosavomerezeka zimatsimikizira kwa wopangirayo kuti chidziwitsochi ndi `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Chosavomerezeka chimatsimikizira kwa wopangirayo chidziwitso kuti node iyi ndi `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Kwa kanthawi amatulutsa chinthu china, chosinthika pamfundo yomweyo.Chenjerani, chifukwa njirayi ndi yowopsa, kawiri konse chifukwa mwina singawoneke ngati yowopsa nthawi yomweyo.
    ///
    /// Chifukwa ma pointer osinthika amatha kuyendayenda kulikonse kuzungulira mtengowo, cholozera chobwezeretsacho chitha kugwiritsidwa ntchito kupangira pointer yoyambirira, yopanda malire, kapena yosavomerezeka pansi pamalamulo obwereketsa.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) lingalirani kuwonjezeranso mtundu wina ku `NodeRef` womwe umaletsa kugwiritsa ntchito njira zoyendera pama pointers obwerekedwa, kupewa izi.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Imabwereka mwayi wopezeka tsamba la tsamba lililonse kapena mfundo zamkati.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // CHITETEZO: timakhala ndi mwayi wopeza mfundo zonsezo.
        unsafe { &mut *ptr }
    }

    /// Amapereka mwayi wopezeka patsamba la tsamba lililonse kapena mfundo zamkati.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // CHITETEZO: timakhala ndi mwayi wopeza mfundo zonsezo.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Imabwereketsa kufikira kokha pamalo ena osungira.
    ///
    /// # Safety
    /// `index` ili m'malire a 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // CHITETEZO: woyimbayo sangathe kuyitananso njira zina payekha
        // mpaka pomwe chidutswa chofunikira chidagwetsedwe, popeza tili ndi mwayi wapadera wokhala ndi nthawi yobwereka.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Imabwereketsa kufikira kokha kapena chidutswa cha malo osungira mtengo.
    ///
    /// # Safety
    /// `index` ili m'malire a 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // CHITETEZO: woyimbayo sangathe kuyitananso njira zina payekha
        // mpaka phindu la chidutswa ligwetsedwe, popeza tili ndi mwayi wapadera wokhala ndi nthawi yobwereka.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Imabwereketsa kufikira kokha kapena chidutswa cha malo osungira mfundo za edge.
    ///
    /// # Safety
    /// `index` ili m'malire a 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // CHITETEZO: woyimbayo sangathe kuyitananso njira zina payekha
        // mpaka pomwe chidutswa cha edge chidagwetsedwa, popeza tili ndi mwayi wapadera wokhala ndi nthawi yobwereka.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Node ili ndi zinthu zoposa `idx` zoyambira.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Timangopanga kutchula chinthu chimodzi chomwe tili nacho chidwi, kuti tipewe kudzipangitsa kuti tizingokhalira kutchulapo zinthu zina, makamaka, zomwe zimabwereranso kwa omwe adayimbira kale.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Tiyenera kukakamiza kulozera pazosalemba chifukwa cha Rust kutulutsa #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Imabwereka kufikira kokha kutalika kwa mfundoyo.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Ikani ulalo wa nodeyo kwa kholo lake edge, popanda kulepheretsa zina zomwe zalembedwazi.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Iyeretsani ulalo wa muzu ndi kholo lake edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Ikuwonjezera awiri amtengo wapatali kumapeto kwa mfundo.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Chilichonse chomwe chabwezedwa ndi `range` ndichizindikiro chovomerezeka cha edge cha node.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Ikuwonjezera awiri amtengo wapatali, ndi edge kuti mupite kumanja kwa awiriwo, kumapeto kwa mfundo.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Imafufuza ngati mfundo ndi `Internal` node kapena `Leaf` node.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Kutchulidwa kwamitundu iwiri yamtengo wapatali kapena edge mkati mwa node.
/// Gawo la `Node` liyenera kukhala `NodeRef`, pomwe `Type` itha kukhala `KV` (kutanthauza chogwirizira pamiyeso yamtengo wapatali) kapena `Edge` (kutanthauza chogwirira pa edge).
///
/// Dziwani kuti ngakhale ma `Leaf` node amatha kukhala ndi ma `Edge`.
/// M'malo moyimira cholozera ku mfundo ya mwana, izi zikuyimira malo omwe zolozera za ana zimatha kupita pakati pa magulu ofunikira.
/// Mwachitsanzo, pamfundo yokhala ndi kutalika 2, pamakhala malo atatu otheka a edge, m'modzi kumanzere kwa mfundoyo, wina pakati pa awiriawiriwo, ndi wina kumanja kwa mfundoyo.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Sitikusowa kuchuluka kwathunthu kwa `#[derive(Clone)]`, popeza nthawi yokhayo `Node` idzakhala `Clone`able ndi nthawi yosasinthika motero `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Imatengera mfundo yomwe ili ndi edge kapena ma key-value pair awa akuwonetsera.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Akufotokozera udindo wa chogwirira ichi mu mfundo za.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Pangani chogwirira chatsopano pamiyeso yamtengo wapatali mu `node`.
    /// Zosatetezeka chifukwa woyimbayo ayenera kuwonetsetsa kuti `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Kungakhale kukhazikitsa pagulu kwa PartialEq, koma kumangogwiritsidwa ntchito pagawoli.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Amatenga kachakudya kena kosasinthika kwakanthawi.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Sitingagwiritse ntchito Handle::new_kv kapena Handle::new_edge chifukwa sitidziwa mtundu wathu
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Chosavomerezeka chimatsimikizira kwa wopangirayo chidziwitso chazomwe chimafotokoza kuti chogwirizira ndi `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Amatenga kachakudya kena kosintha komweko kwakanthawi.
    /// Chenjerani, chifukwa njirayi ndi yowopsa, kawiri konse chifukwa mwina singawoneke ngati yowopsa nthawi yomweyo.
    ///
    ///
    /// Kuti mumve zambiri, onani `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Sitingagwiritse ntchito Handle::new_kv kapena Handle::new_edge chifukwa sitidziwa mtundu wathu
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Pangani chogwirira chatsopano ku edge mu `node`.
    /// Zosatetezeka chifukwa woyimbayo ayenera kuwonetsetsa kuti `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Popeza cholozera cha edge pomwe tikufuna kuyika mu mfundo yodzaza ndi mphamvu, imalemba cholozera chanzeru cha KV cha malo ogawanika komanso malo oyikapo.
///
/// Cholinga cha kugawanika ndikofunikira ndi kufunikira kwake kuti kukhale munjira ya kholo;
/// mafungulo, malingaliro ndi m'mphepete kumanzere kwa malo ogawanika amakhala mwana wamanzere;
/// makiyi, malingaliro ndi m'mbali mwa kumanja kwa malo ogawanika amakhala mwana woyenera.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Kutulutsa kwa Rust #74834 kumayesa kufotokoza malamulowa.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Imaika awiri amtengo wapatali pakati pamitundu iwiri yamtengo kumanja ndi kumanzere kwa edge iyi.
    /// Njirayi imaganiza kuti pali malo okwanira kuti banja latsopanolo likwane.
    ///
    /// Cholozera chobwezeretsedwacho chimaloza pamtengo womwe walowetsedwa.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Imaika awiri amtengo wapatali pakati pamitundu iwiri yamtengo kumanja ndi kumanzere kwa edge iyi.
    /// Njirayi imagawanitsa mfundo ngati palibe malo okwanira.
    ///
    /// Cholozera chobwezeretsedwacho chimaloza pamtengo womwe walowetsedwa.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Imakonza cholozera cha makolo ndi cholozera mu mfundo ya mwana yomwe edge imalumikizana nayo.
    /// Izi ndizothandiza pomwe dongosolo lam'mbali lasinthidwa,
    fn correct_parent_link(self) {
        // Pangani chojambula chambuyo popanda kulepheretsa zina zomwe zalembedwazi.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Ikani ma para-key atsopano ndi edge zomwe zipita kumanja kwa awiriwa pakati pa edge ndi ma value-key awiri kumanja kwa edge.
    /// Njirayi imaganiza kuti pali malo okwanira kuti banja latsopanolo likwane.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Ikani ma para-key atsopano ndi edge zomwe zipita kumanja kwa awiriwa pakati pa edge ndi ma value-key awiri kumanja kwa edge.
    /// Njirayi imagawanitsa mfundo ngati palibe malo okwanira.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Imaika awiri amtengo wapatali pakati pamitundu iwiri yamtengo kumanja ndi kumanzere kwa edge iyi.
    /// Njirayi imagawanitsa mfundo ngati mulibe malo okwanira, ndikuyesera kuyika gawo logawikirananso panjira ya makolo mobwerezabwereza, mpaka muzu ufike.
    ///
    ///
    /// Ngati zotsatira zobwezeredwa ndi `Fit`, mfundo yake yogwirizira ikhoza kukhala mfundo ya edge kapena kholo.
    /// Ngati zotsatira zobwezeredwa ndi `Split`, gawo la `left` lidzakhala njira yazu.
    /// Cholozera chobwezeretsedwacho chimaloza pamtengo womwe walowetsedwa.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Amapeza mfundo yomwe yatchulidwa ndi edge.
    ///
    /// Dzinali limatengera mitengo yazithunzi yomwe ili ndi mizu yake pamwamba.
    ///
    /// `edge.descend().ascend().unwrap()` ndipo `node.ascend().unwrap().descend()` sayenera, onse kuchita bwino, osachita chilichonse.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Tiyenera kugwiritsa ntchito zolozera zosaphika ku mfundo chifukwa, ngati BorrowType ndi marker::ValMut, pakhoza kukhala kutanthauzira kosinthika kwa mfundo zomwe sitiyenera kuzisokoneza.
        // Palibe chodandaula chofika pamtunda chifukwa kutalika kwake kumakopedwa.
        // Chenjerani kuti, pomwe pointer ya node ikachotsedwa, titha kulowa m'mbali mwake ndi tsamba (Rust kutulutsa #73987) ndikuwononga kutchulidwako kwina kulikonse kapena mkati mwa gulu, pangakhale paliponse.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Sitingatchule njira zopatulira ndi phindu, chifukwa kuyitana wachiwiri kumapangitsa kuti zolembedwazo zibwezeretsedwe koyamba.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Sinthanitsani kiyi ndi mtengo womwe chogwirizira cha KV chimatchulira.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Imathandizira kukhazikitsa kwa `split` kwa `NodeType` inayake, posamalira masamba.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Gawani mfundo yoyambira m'magawo atatu:
    ///
    /// - Chombocho chimadulidwa kuti chimangokhala ndimipangiri yamtengo wapatali kumanzere kwa chogwirira ichi.
    /// - Chinsinsi ndi mtengo womwe walongosoledwa ndi chogwirira ichi watengedwa.
    /// - Zida zonse zamtengo wapatali kumanja kwa chogwirira ichi zimayikidwa mu mfundo zomwe zapatsidwa kumene.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Imachotsa mitengo yamtengo wapatali yomwe ikulozeredwa ndi chogwirira ichi ndikuibweza, limodzi ndi edge yomwe mtengo wamtengo wapatali udagwera.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Gawani mfundo yoyambira m'magawo atatu:
    ///
    /// - Nodeyo idadulidwa kuti izikhala ndi m'mbali komanso ma mtengo ofunikira kumanzere kwa chogwirira ichi.
    /// - Chinsinsi ndi mtengo womwe walongosoledwa ndi chogwirira ichi watengedwa.
    /// - Zozungulira zonse ndi maphatidwe amtengo wapatali kumanja kwa chogwirira ichi amayikidwa mu mfundo zomwe zapatsidwa kumene.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Imayimira gawo loyesa ndikuchita ntchito yolinganiza mozungulira ma mtengo amkati amkati.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Amasankha malingaliro osakanikirana okhudzana ndi mfundozo ngati mwana, motero pakati pa KV nthawi yomweyo kumanzere kapena kumanja mu mfundo ya kholo.
    /// Imabwezeretsa `Err` ngati palibe kholo.
    /// Panics ngati kholo mulibe.
    ///
    /// Amakonda mbali yakumanzere, kuti ikhale yoyenera ngati mfundo zomwe zapatsidwa sizikwaniritsidwa, kutanthauza apa kuti zili ndi zinthu zochepa kuposa m'bale wake wamanzere komanso m'bale wake wamanja, ngati alipo.
    /// Zikatero, kuphatikiza ndi m'bale wakumanzere kumathamanga, chifukwa timangofunika kusuntha zinthu za N, m'malo mozisunthira kumanja ndikusuntha kuposa zinthu za N kutsogolo.
    /// Kuba kwa m'bale wakumanzere kumathandizanso mwachangu, popeza timangofunika kusunthira zinthu za N kupita kumanja, m'malo mosunthira zinthu za m'bale kumanzere.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Kubwezera ngati kuphatikizika kuli kotheka, mwachitsanzo, ngati pali malo okwanira kuti agwirizane ndi KV yapakati ndi zigawo zonse zoyandikana za ana.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Amagwirizana ndikupangitsa kutseka kusankha komwe angabwerere.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // CHITETEZO: kutalika kwa mfundo zomwe zikuphatikizidwa ndikumodzi kwakumtunda
                // ya mfundo iyi ya edge, motero pamwamba pa zero, kotero ili mkati.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Imaphatikiza mfundo zamtengo wapatali za kholo ndi zigawo ziwiri zoyandikana za ana kumanzere amwana ndikubwezeretsa mfundo ya kholo yomwe yasokonekera.
    ///
    ///
    /// Panics pokhapokha titakhala `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Imaphatikiza ma mtengo ofunikira amtengo wamakolo ndi onse oyandikana ndi ana kumalo amanzere amwana ndikubwezeretsa nodeyo.
    ///
    ///
    /// Panics pokhapokha titakhala `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Kuphatikiza mapatani amtengo wamakolo ndi zonse zoyandikana za mwana m'ndondomeko yamwana wamanzere ndikubweza chogwirizira cha edge mgulu la mwana komwe mwana womutsata edge adathera,
    ///
    ///
    /// Panics pokhapokha titakhala `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Imachotsa mitengo yamtengo wapatali kuchokera kwa mwana wamanzere ndikuyiyika pakusungitsa kwa kholo lamtengo wapatali, kwinaku ikukankhira awiri amtengo wamtengo wapatali wa kholo mu mwana woyenera.
    ///
    /// Kubwezeretsa chogwirira ku edge mwa mwana wamanja wolingana ndi komwe edge yoyambirira yomwe idatchulidwa ndi `track_right_edge_idx` idathera.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Imachotsa mitengo yamtengo wapatali kuchokera kwa mwana woyenera ndikuyiyika pakusungitsa kwamtengo wapatali kwa kholo, kwinaku ikukankhira awiri amtengo wamtengo wapatali kwa mwana wamanzere.
    ///
    /// Kubwezeretsa chogwirira ku edge mu mwana wamanzere wotchulidwa ndi `track_left_edge_idx`, yemwe sanasunthe.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Izi zimakhala ngati `steal_left` koma zimaba zinthu zingapo nthawi imodzi.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Onetsetsani kuti takuba bwino.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Sungani zambiri zamasamba.
            {
                // Pangani malo obedwa mwa mwana woyenera.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Sungani zinthu kuchokera kumwana wamanzere kupita kumanja.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Sungani awiri omwe abedwa kumanzere kwa kholo.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Sunthani mitengo yamtengo wapatali ya kholo kumwana woyenera.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Pangani malo okhala m'mbali.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Kuba m'mbali.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Chojambula chosakanikirana cha `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Onetsetsani kuti takuba bwino.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Sungani zambiri zamasamba.
            {
                // Sungani awiri omwe abedwa kumanja kwa kholo.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Sunthani mitengo yamtengo wapatali ya kholo kumwana wamanzere.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Sungani zinthu kuchokera kumwana wamanja kumanzere.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Lembani mpata pomwe zinthu zabedwa kale.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Kuba m'mbali.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Lembani mpata pomwe m'mbali mwake munkabedwa kale.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Imachotsa chidziwitso chilichonse chotsimikiza kuti node iyi ndi `Leaf` node.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Imachotsa chidziwitso chilichonse chotsimikiza kuti node iyi ndi `Internal` node.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Imafufuza ngati mfundo yayikulu ndi `Internal` node kapena `Leaf` node.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Sungani chokwanira pambuyo pa `self` kuchokera pa mfundo imodzi kupita ku ina.`right` iyenera kukhala yopanda kanthu.
    /// edge yoyamba ya `right` sinasinthe.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Zotsatira zakuyikapo, pomwe mfundo ikufunika kukulira kuposa momwe ingathere.
pub struct SplitResult<'a, K, V, NodeType> {
    // Zosintha pamtengo womwe ulipo wokhala ndi zinthu ndi m'mbali mwake zomwe zili kumanzere kwa `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Chinsinsi china ndi mtengo zidagawika, kuti ziyikidwe kwina.
    pub kv: (K, V),
    // Yokhala nayo, yopanda cholumikizira, mfundo yatsopano yokhala ndi zinthu ndi m'mbali mwake zomwe zili kumanja kwa `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Kaya mafotokozedwe amtundu wamtundu wobwereketsawa amalola kudutsa njira zina mumtengowo.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal siyofunikira, zimachitika pogwiritsa ntchito zotsatira za `borrow_mut`.
        // Mwa kulepheretsa kuwoloka, ndikungopanga zolemba zatsopano za mizu, tikudziwa kuti mtundu uliwonse wa `Owned` umakhala pamutu wazu.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Kuyika mtengo mu chidutswa cha zinthu zoyambitsidwa ndikutsatira chinthu chimodzi chosasinthidwa.
///
/// # Safety
/// Kagawo kali ndi zinthu zoposa `idx`.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Imachotsa ndikubwezeretsa mtengo pachidutswa cha zinthu zonse zoyambitsidwa, ndikusiya chinthu chimodzi chosatsata kale.
///
///
/// # Safety
/// Kagawo kali ndi zinthu zoposa `idx`.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Imasinthira zinthu pagawo la `distance` kumanzere.
///
/// # Safety
/// Kagawo kali ndi zinthu zosachepera `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Imasinthira zinthu pagawo la `distance` kumanja.
///
/// # Safety
/// Kagawo kali ndi zinthu zosachepera `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Imasuntha miyezo yonse kuchokera pagawo lazinthu zoyambira kupita pagawo lazinthu zomwe sizinayambike, ndikusiya `src` ngati yonse yopanda tanthauzo.
///
/// Imagwira ngati `dst.copy_from_slice(src)` koma sikutanthauza `T` kukhala `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;