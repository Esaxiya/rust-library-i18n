//! Mzere woyambirira wokhazikitsidwa ndi mulu wamabinawo.
//!
//! Kuyika ndi kutulutsa chinthu chachikulu kwambiri kumakhala ndi zovuta za *O*(log(*n*)).
//! Kuyang'ana chinthu chachikulu kwambiri ndi *O*(1).Kusintha vector kukhala mulu wamabinawo kumatha kuchitidwa m'malo, ndipo kumakhala kovuta kwa *O*(*n*).
//! Mulu wamabinawo utha kusinthidwa kukhala vector m'malo mwake, kuwalola kugwiritsidwa ntchito ngati *O*(*n*\*log(* n*)) m'malo amalo.
//!
//! # Examples
//!
//! Ichi ndi chitsanzo chokulirapo chomwe chimagwiritsa ntchito [Dijkstra's algorithm][dijkstra] kuthetsa [shortest path problem][sssp] pa [directed graph][dir_graph].
//!
//! Ikuwonetsa momwe mungagwiritsire ntchito [`BinaryHeap`] ndimitundu yazikhalidwe.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Mzere woyambirira umadalira `Ord`.
//! // Tsatirani kwathunthu trait kotero kuti mzere umakhala mulu m'malo mwa mulu waukulu.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Zindikirani kuti ife timasanja kuyitanitsa pamitengo.
//!         // Ngati tayi tifananitsa malo, sitepe iyi ndiyofunikira kuti kukhazikitsa kwa `PartialEq` ndi `Ord` kusasinthe.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` iyeneranso kukhazikitsidwa.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Node iliyonse imayimiriridwa ngati `usize`, kuti ikwaniritse mwachidule.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Njira yachidule kwambiri ya Dijkstra.
//!
//! // Yambirani pa `start` ndikugwiritsa ntchito `dist` kutsata mtunda wafupipafupi wa mfundo iliyonse.Kukhazikitsa kumeneku sikothandiza kukumbukira chifukwa kumatha kusiya magawo obwereza pamzera.
//! //
//! // Imagwiritsanso ntchito `usize::MAX` ngati mtengo wa sentinel, kukhazikitsa kosavuta.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=mtunda wafupipafupi kwambiri kuchokera ku `start` mpaka `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Tili pa `start`, ndi mtengo wiro
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Onaninso malire ndi mitengo yotsika mtengo woyamba (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Kapenanso tikadapitiliza kupeza njira zazifupi kwambiri
//!         if position == goal { return Some(cost); }
//!
//!         // Zofunika monga momwe tingakhalire tapeza kale njira yabwinoko
//!         if cost > dist[position] { continue; }
//!
//!         // Pa mfundo iliyonse yomwe titha kufikira, onani ngati tingapeze njira ndi mtengo wotsika womwe udutsapo
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Ngati ndi choncho, onjezerani kumalire ndikupitiliza
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Kupumula, tsopano tapeza njira yabwinoko
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Cholinga sichingatheke
//!     None
//! }
//!
//! fn main() {
//!     // Iyi ndiye graph yomwe tiziwongolera.
//!     // Manambala amtunduwu amafanana ndi mayiko osiyanasiyana, ndipo zolemera za edge zikuyimira mtengo wosunthira kuchoka pamfundo imodzi kupita pa ina.
//!     //
//!     // Onani kuti m'mbali mwake ndi njira imodzi.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          ndime 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Chithunzicho chikuyimiridwa ngati mndandanda wazotsatira pomwe index iliyonse, yolingana ndi mtengo wamtengo wapatali, ili ndi mndandanda wazonse zotuluka.
//!     // Osankhidwa kuti achite bwino.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Mfundo 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Njira 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Njira 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Mfundo 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Mfundo 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Mzere woyambirira wokhazikitsidwa ndi mulu wamabinawo.
///
/// Uwu ukhala mulu waukulu.
///
/// Ndi kulakwitsa kwa chinthu kuti chinthu chisinthidwe mwanjira yoti kuyitanitsa chinthucho kukhudzana ndi chinthu china chilichonse, malinga ndi `Ord` trait, chimasintha pomwe chili pamulu.
///
/// Izi zimatheka pokhapokha `Cell`, `RefCell`, dziko lonse, I/O, kapena nambala yosatetezeka.
/// Makhalidwe omwe amabwera chifukwa chakulakwitsa koteroko sanatchulidwe, koma sangapangitse kukhala osadziwika.
/// Izi zitha kuphatikizira panics, zotsatira zolakwika, kuchotsa, kutaya kukumbukira, komanso kusachotsa.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Kutengera mtundu kumatithandiza kuti tisayine siginecha yodziwika bwino (yomwe ingakhale `BinaryHeap<i32>` muchitsanzo ichi).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Titha kugwiritsira ntchito poyang'ana chinthu chotsatira pamuluwo.
/// // Poterepa, mulibe zinthu mmenemo kotero kuti sitimapeza Palibe.
/// assert_eq!(heap.peek(), None);
///
/// // Tiyeni tiwonjezere zambiri ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Tsopano peek akuwonetsa chinthu chofunikira kwambiri pamuluwo.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Titha kuwona kutalika kwa mulu.
/// assert_eq!(heap.len(), 3);
///
/// // Titha kuyerekeza pazinthu zomwe zili muluwo, ngakhale zimabwezedwa mwanjira iliyonse.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Ngati m'malo mwake tizijambula izi, abwereranso mwadongosolo.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Titha kuchotsa mulu wazinthu zotsala.
/// heap.clear();
///
/// // Muluwo uyenera kukhala wopanda munthu.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Mwina `std::cmp::Reverse` kapena kukhazikitsa `Ord` kungagwiritsidwe ntchito kupanga `BinaryHeap` kukhala mulu-umodzi.
/// Izi zimapangitsa `heap.pop()` kubwezera mtengo wocheperako m'malo mwake waukulu kwambiri.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Manga zinthu mu `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Ngati tizijambula izi tsopano, ziyenera kubwereranso mwatsatanetsatane.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Nthawi yovuta
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Mtengo wa `push` ndi mtengo woyembekezeka;zolembazo zimapereka kusanthula mwatsatanetsatane.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Kapangidwe kokulunga kosinthika kosinthika kwa chinthu chachikulu pa `BinaryHeap`.
///
///
/// `struct` iyi imapangidwa ndi njira ya [`peek_mut`] pa [`BinaryHeap`].
/// Onani zolemba zake kuti mumve zambiri.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // CHITETEZO: PeekMut imangokhazikitsidwa pam milu yopanda kanthu.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SAFE: PeekMut imangokhazikitsidwa pam milu yopanda kanthu
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SAFE: PeekMut imangokhazikitsidwa pam milu yopanda kanthu
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Imachotsa mtengo wojambulidwa pamulu ndikuubweza.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Amapanga `BinaryHeap<T>` yopanda kanthu.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Imapanga `BinaryHeap` yopanda kanthu ngati mulu waukulu.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Zimapanga `BinaryHeap` yopanda kanthu ndi mphamvu inayake.
    /// Izi zimakonzekeretsa kukumbukira kokwanira kwa zinthu `capacity`, kotero kuti `BinaryHeap` sayenera kukhazikitsidwanso mpaka itakhala ndi mfundo zocheperako.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Imabwezeretsa kutanthauzira kosinthika kwa chinthu chachikulu pamulu wowerengera, kapena `None` ngati chilibe kanthu.
    ///
    /// Note: Ngati mtengo wa `PeekMut` watulutsidwa, muluwo ukhoza kukhala wosagwirizana.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Nthawi yovuta
    ///
    /// Ngati chinthucho chasinthidwa ndiye kuti nthawi yovuta kwambiri ndi *O*(log(*n*)), apo ayi ndi *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Imachotsa chinthu chachikulu kwambiri pamulu wa binary ndikuibweza, kapena `None` ngati ilibe kanthu.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Nthawi yovuta
    ///
    /// Mtengo wotsika kwambiri wa `pop` pamulu wokhala ndi zinthu za *n* ndi *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // CHITETEZO: !self.is_empty() amatanthauza kuti self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Amakankhira chinthu pamulu wamaguluwo.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Nthawi yovuta
    ///
    /// Mtengo woyembekezeredwa wa `push`, wowerengeka pakapangidwe kalikonse kamene zinthu zikukankhidwa, komanso kuchuluka kwa ma pushes, ndi *O*(1).
    ///
    /// Ili ndiye mtengo wofunikira kwambiri mukamakankhira zinthu zomwe sizili kale munthawi iliyonse.
    ///
    /// Kupanikizika kwakanthawi kumatsika ngati zinthu zimakankhidwa mokwera kwambiri.
    /// Zikakhala zoyipa kwambiri, zinthu zimakankhidwira kukwera mosanjikiza ndipo mtengo wotsika mtengo pakukankha ndi *O*(log(*n*)) motsutsana ndi mulu wokhala ndi zinthu za *n*.
    ///
    /// Mtengo woyipitsitsa woyimbira *single* ku `push` ndi *O*(*n*).Nkhani yoyipa kwambiri imachitika mphamvu ikatha ndikufunika kukula.
    /// Mtengo wakubwezeretsanso wachotsedwa mumanambala am'mbuyomu.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // CHITETEZO: Popeza tidakankhira chinthu chatsopano zikutanthauza kuti
        //  zakale_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Idya `BinaryHeap` ndikubwezera vector mu dongosolo la (ascending).
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // CHITETEZO: `end` imachokera ku `self.len() - 1` kupita ku 1 (onsewa akuphatikizidwa),
            //  Chifukwa chake nthawi zonse imakhala index yoyenera kupeza.
            //  Ndizotheka kupeza index 0 (ie `ptr`), chifukwa
            //  1 <=end <self.len(), kutanthauza kuti self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // CHITETEZO: `end` imachokera ku `self.len() - 1` kupita ku 1 (onse kuphatikiza) kotero:
            //  0 <1 <=end <= self.len(), 1 <self.len() Zomwe zikutanthauza kuti 0 <end and end <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Kukhazikitsa kwa sift_up ndi sift_down kumagwiritsa ntchito midadada yosatetezedwa kuti mutulutse chinthu mu vector (kusiya dzenje), sinthani enawo ndikusunthira chinthu chotsitsidwacho ku vector pamalo omaliza a dzenje.
    //
    // Mtundu wa `Hole` umagwiritsidwa ntchito kuyimira izi, ndipo onetsetsani kuti dzenje ladzazidwa kumapeto kwa kukula kwake, ngakhale pa panic.
    // Kugwiritsa ntchito bowo kumachepetsa zomwe zimachitika nthawi zonse poyerekeza ndi kugwiritsa ntchito swaps, zomwe zimaphatikizapo kuyenda kawiri konse.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Woyimbirayo akuyenera kutsimikizira kuti `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Chotsani mtengo ku `pos` ndikupanga una.
        // CHITETEZO: Woyimbirayo akutsimikizira kuti pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // CHITETEZO: hole.pos()> kuyamba>=0, kutanthauza kuti hole.pos()> 0
            //  ndipo hole.pos(), 1 sichitha kusefukira.
            //  Izi zimatsimikizira kholo <hole.pos() kotero ndi index yolondola komanso!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // CHITETEZO: Momwemonso pamwambapa
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Tengani chinthu ku `pos` ndikusunthani pamuluwo, pomwe ana ake ndi okulirapo.
    ///
    ///
    /// # Safety
    ///
    /// Woyimbirayo akuyenera kutsimikizira kuti `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // CHITETEZO: Woyimbirayo akutsimikizira kuti pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Zosasintha za loop: mwana==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // yerekezerani ndi wamkulu wa ana awiri CHITETEZO: child <end, 1 <self.len() and child + 1 <end <= self.len(), ndiye ma index oyenera.
            //
            //  mwana==2 *hole.pos() + 1!= hole.pos() ndi mwana + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 kapena 2* hole.pos() + 2 ikhoza kusefukira ngati T ndi ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // ngati takonzeka kale, imani.
            // CHITETEZO: mwana tsopano ndi mwana wakale kapena mwana wakale + 1
            //  Tatsimikizira kale kuti onse ndi <self.len() ndi!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // CHITETEZO: monga pamwambapa.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // CHITETEZO: &&dera lalifupi, zomwe zikutanthauza kuti mu
        //  chikhalidwe chachiwiri ndizowona kale kuti mwana==mathero, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // CHITETEZO: mwana watsimikiziridwa kale kuti ndi index woyenera ndipo
            //  mwana==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Woyimbirayo akuyenera kutsimikizira kuti `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // CHITETEZO: pos <len ndiyotsimikizika ndi woyimbayo ndipo
        //  mwachidziwikire len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Tengani chinthu ku `pos` ndikuchichotsa pamuluwo, kenako nkusani mpaka pamalo ake.
    ///
    ///
    /// Note: Izi ndizothamanga pomwe chinthucho chimadziwika kuti ndi chachikulu/chikuyenera kukhala pafupi ndi pansi.
    ///
    /// # Safety
    ///
    /// Woyimbirayo akuyenera kutsimikizira kuti `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // CHITETEZO: Woyimbirayo akutsimikizira kuti pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Zosasintha za loop: mwana==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // CHITETEZO: mwana <kumapeto, 1 <self.len() ndi
            //  child + 1 <end <= self.len(), chifukwa chake ndizovomerezeka.
            //  mwana==2 *hole.pos() + 1!= hole.pos() ndi mwana + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 kapena 2* hole.pos() + 2 ikhoza kusefukira ngati T ndi ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // CHITETEZO: Momwemonso pamwambapa
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // CHITETEZO: kumapeto kwa mwana=1, 1 <self.len(), chifukwa chake ndi index yolondola
            //  ndi mwana==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // CHITETEZO: pos ndi malo mdzenje ndipo anali atatsimikiziridwa kale
        //  kukhala index yolondola.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // CHITETEZO: n imayamba kuchokera ku self.len()/2 ndikupita ku 0.
            //  Mlandu wokha when! (N <self.len()) is if self.len() ==0, koma ikulamulidwa ndi kutambasula kwake.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Imasuntha zinthu zonse za `other` kupita ku `self`, ndikusiya `other` yopanda kanthu.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` imatenga zochitika za O(len1 + len2) komanso kuyerekezera pafupifupi 2 *(len1 + len2) poyipa kwambiri pomwe `extend` imagwira ntchito za O(len2* log(len1)) ndipo pafupifupi 1 *len2* log_2(len1) poyerekeza kwambiri, poganiza kuti len1>= len2.
        // Pamulu waukulu, mfundo ya crossover siyitsatiranso izi ndipo idatsimikizika mwamphamvu.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Imabwezeretsa iterator yomwe imabwezeretsa zinthu mulu.
    /// Zinthu zobwezedwa zimachotsedwa pamulu woyambirira.
    /// Zinthu zotsalazo zizichotsedwa pakadutsa mulu.
    ///
    /// Note:
    /// * `.drain_sorted()` is *O*(*n*\*log(* n*)); pang'onopang'ono kuposa `.drain()`.
    ///   Muyenera kugwiritsa ntchito yomalizayi nthawi zambiri.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // amachotsa zinthu zonse motsatira mulu
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Imasunga zinthu zokhazokha zotchulidwa ndi wotsogolera.
    ///
    /// Mwanjira ina, chotsani zonse `e` kotero kuti `f(&e)` ibweretse `false`.
    /// Zinthu zimayendera mosasankhidwa (komanso osadziwika).
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // sungani manambala okha
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Imabwezeretsa iterator yoyendera zikhalidwe zonse mu vector, mosasunthika.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Sindikizani 1, 2, 3, 4 mwatsatanetsatane
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Imabwezeretsa iterator yomwe imabwezeretsa zinthu mulu.
    /// Njirayi imagwiritsa ntchito mulu woyambirira.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Imabwezeretsa chinthu chachikulu kwambiri pamulu wowerengera, kapena `None` ngati chilibe kanthu.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Nthawi yovuta
    ///
    /// Mtengo ndi *O*(1) pakavuta kwambiri.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Imabwezeretsa kuchuluka kwa zinthu zomwe mulu wamabinawo ukhoza kugwira osasunthiranso kwina.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Imasunga mphamvu yocheperako yazinthu zina `additional` zoti ziyikidwe mu `BinaryHeap` yomwe yapatsidwa.
    /// Sichichita chilichonse ngati kuthekera kuli kokwanira kale.
    ///
    /// Dziwani kuti woperekayo atha kupatsa malo osonkhanitsa malo ochulukirapo kuposa momwe amafunsira.
    /// Chifukwa chake mphamvu sizingadaliridwe kukhala zochepa kwenikweni.
    /// Sankhani [`reserve`] ngati future akuyembekezeredwa.
    ///
    /// # Panics
    ///
    /// Panics ngati mphamvu yatsopano ikusefukira `usize`.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Kusunga kuthekera kwa zinthu zosachepera `additional` kuti ziyikidwe mu `BinaryHeap`.
    /// Zosonkhanitsazo zitha kusunga malo ambiri kuti zisawonongeke pafupipafupi.
    ///
    /// # Panics
    ///
    /// Panics ngati mphamvu yatsopano ikusefukira `usize`.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Amataya zowonjezera zowonjezera momwe angathere.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Kutaya mphamvu ndi kumunsi.
    ///
    /// Mphamvuyo idzakhalabe yocheperako ngati kutalika kwake ndi mtengo womwe waperekedwa.
    ///
    ///
    /// Ngati mphamvu zomwe zilipo pakadali pano ndizochepera malire, ndiye kuti palibe-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Idya `BinaryHeap` ndikubwezeretsanso vector mosasinthasintha.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Tidzasindikiza mwanjira ina
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Kubwezeretsa kutalika kwa mulu wa binary.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Macheke ngati mulu wa binary ulibe kanthu.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Itsuka mulu wa binary, ndikubwezeretsanso chojambulira pazinthu zomwe zachotsedwa.
    ///
    /// Zinthu zimachotsedwa mosasinthasintha.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Akutsitsa zinthu zonse kuchokera pamulu wamabinawo.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Dzenje limaimira bowo pagawo mwachitsanzo, cholozera chopanda phindu (chifukwa chidachotsedwa kapena kubwerezedwa).
///
/// Pogwetsa, `Hole` ibwezeretsanso chidutswacho podzaza bwaloli ndi mtengo womwe udachotsedwa koyamba.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Pangani `Hole` yatsopano pa index `pos`.
    ///
    /// Zosatetezeka chifukwa positi iyenera kukhala pagawo lazidziwitso.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SAFE: pos iyenera kukhala mkati kagawo
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Kubwezeretsa kutanthauzira kwa chinthucho kuchotsedwa.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Kubwezeretsa kutanthauzira kwa chinthucho ku `index`.
    ///
    /// Zosatetezeka chifukwa index iyenera kukhala pagawo lazosankha osati kufanana ndi pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Sungani dzenje kumalo atsopano
    ///
    /// Zosatetezeka chifukwa index iyenera kukhala pagawo lazosankha osati kufanana ndi pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // dzazani dzenje kachiwiri
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Cholemba pazinthu za `BinaryHeap`.
///
/// `struct` iyi idapangidwa ndi [`BinaryHeap::iter()`].
/// Onani zolemba zake kuti mumve zambiri.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Chotsani mokomera `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Iterator yokhala ndi zinthu za `BinaryHeap`.
///
/// `struct` iyi idapangidwa ndi [`BinaryHeap::into_iter()`] (yoperekedwa ndi `IntoIterator` trait).
/// Onani zolemba zake kuti mumve zambiri.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Chojambulira chotsitsa pazinthu za `BinaryHeap`.
///
/// `struct` iyi idapangidwa ndi [`BinaryHeap::drain()`].
/// Onani zolemba zake kuti mumve zambiri.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Chojambulira chotsitsa pazinthu za `BinaryHeap`.
///
/// `struct` iyi idapangidwa ndi [`BinaryHeap::drain_sorted()`].
/// Onani zolemba zake kuti mumve zambiri.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Imachotsa mulu wa mulu.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Imatembenuza `Vec<T>` kukhala `BinaryHeap<T>`.
    ///
    /// Kutembenuka kumeneku kumachitika m'malo, ndipo kumakhala ndi *O*(*n*) nthawi zovuta.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Imatembenuza `BinaryHeap<T>` kukhala `Vec<T>`.
    ///
    /// Kutembenuka kumeneku sikusowa kuyendetsa kapena kugawa deta, ndipo kumakhala ndi zovuta nthawi yayitali.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Imapanga cholembera chowononga, ndiye kuti, chomwe chimachotsa phindu lililonse pamulu wamakanema motsatira dongosolo.
    /// Mulu wamabinawo sungagwiritsidwe ntchito mutayimba izi.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Sindikizani 1, 2, 3, 4 mwatsatanetsatane
    /// for x in heap.into_iter() {
    ///     // x ili ndi mtundu i32, osati &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}