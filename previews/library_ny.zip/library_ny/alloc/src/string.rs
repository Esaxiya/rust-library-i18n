//! Chingwe chojambulira cha UTF-8, chotheka kukula.
//!
//! Gawoli lili ndi mtundu wa [`String`], [`ToString`] trait yosinthira zingwe, ndi mitundu ingapo yolakwika yomwe ingabwere chifukwa chogwira ntchito ndi [`String`] s.
//!
//!
//! # Examples
//!
//! Pali njira zingapo zopangira [`String`] yatsopano kuchokera pachingwe chenicheni:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Mutha kupanga [`String`] yatsopano kuchokera pomwe mulipo pokambirana ndi
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Ngati muli ndi vector ya UTF-8 byte yovomerezeka, mutha kupanga [`String`].Inunso mutha kusintha.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Tikudziwa kuti mabayilowa ndi ovomerezeka, chifukwa chake tigwiritsa ntchito `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Chingwe chojambulira cha UTF-8, chotheka kukula.
///
/// Mtundu wa `String` ndiye mtundu wofala kwambiri wazingwe womwe umakhala ndi umwini pazomwe zili pachingwecho.Ili ndi ubale wapamtima ndi mnzake wobwereka, [`str`] wakale.
///
/// # Examples
///
/// Mutha kupanga `String` kuchokera ku [a literal string][`str`] ndi [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Mutha kuyika [`char`] ku `String` ndi njira ya [`push`], ndikuyikapo [`&str`] ndi njira ya [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Ngati muli ndi vector ya UTF-8 byte, mutha kupanga `String` kuchokera pamenepo ndi njira ya [`from_utf8`]:
///
/// ```
/// // ma byte ena, mu vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Tikudziwa kuti mabayilowa ndi ovomerezeka, chifukwa chake tigwiritsa ntchito `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// Zingwe nthawi zonse zimakhala zogwirizana ndi UTF-8.Izi zili ndi tanthauzo zochepa, choyamba ndikuti ngati mukufuna chingwe chosakhala cha UTF-8, ganizirani za [`OsString`].Ndizofanana, koma popanda choletsa UTF-8.Lingaliro lachiwiri ndikuti simungathe kulembera `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Kukhazikitsa index cholinga chake ndi kugwira ntchito nthawi zonse, koma kukopera kwa UTF-8 sikukutilola kuchita izi.Kuphatikiza apo, sizikudziwika kuti ndi chiani chomwe cholozera chiziyenera kubwerera: byte, codepoint, kapena grapheme cluster.
/// Njira za [`bytes`] ndi [`chars`] zimabwezeretsa oyeserera pamawiri oyamba, motsatana.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `Mzere umagwiritsa ntchito [` Deref`]`<Target=str>`, ndikuti mulandire njira zonse za (` `str`].Kuphatikiza apo, izi zikutanthauza kuti mutha kupititsa `String` kuntchito yomwe imatenga [`&str`] pogwiritsa ntchito ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Izi zipanga [`&str`] kuchokera ku `String` ndikudutsamo. Kutembenuka kumeneku ndikotsika mtengo kwambiri, chifukwa chake, magwiridwe antchito angavomereze [`&str`] ngati zifukwa pokhapokha atafunikira `String` pazifukwa zina.
///
/// Nthawi zina Rust ilibe chidziwitso chokwanira kuti isinthe, yotchedwa [`Deref`] kukakamiza.Pachitsanzo chotsatira chingwe cha [`&'a str`][`&str`] chimagwiritsa ntchito trait `TraitExample`, ndipo ntchito `example_func` imatenga chilichonse chomwe chingagwiritse ntchito trait.
/// Poterepa Rust angafunike kutembenuza kawiri konse, komwe Rust ilibe njira yochitira.
/// Pachifukwachi, chitsanzo chotsatira sichingapangidwe.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Pali njira ziwiri zomwe zingagwire ntchito m'malo mwake.Choyamba chikanakhala kusintha mzere `example_func(&example_string);` kukhala `example_func(example_string.as_str());`, pogwiritsa ntchito njira [`as_str()`] kuti muchotse chidutswa chachingwe chomwe chinali ndi chingwecho.
/// Njira yachiwiri imasinthira `example_func(&example_string);` kukhala `example_func(&*example_string);`.
/// Poterepa tikulemba `String` kukhala [`str`][`&str`], kenako tikunena za [`str`][`&str`] kubwerera ku [`&str`].
/// Njira yachiwiri ndiyopendekera kwambiri, komabe onsewa amayesetsa kuti asinthe kutembenuka m'malo modalira kutembenuka kwathunthu.
///
/// # Representation
///
/// `String` ili ndi zinthu zitatu: cholozera ku ma byte, kutalika, ndi mphamvu.Cholozera chimaloza chosungira mkati `String` chomwe chimagwiritsa ntchito posungira.Kutalika ndi chiwerengero cha mabayiti omwe amasungidwa mu buffer, ndipo kuchuluka kwake ndikokulira kwa buffer m'ma byte.
///
/// Mwakutero, kutalika kumakhala kocheperako kapena kofanana ndi kuchuluka kwake.
///
/// Chotetezera ichi chimasungidwa pamulu nthawi zonse.
///
/// Mutha kuyang'ana izi ndi njira za [`as_ptr`], [`len`], ndi [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Sinthani izi pamene vec_into_raw_parts ikhazikika.
/// // Pewani kutaya zokhazokha za String
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // nkhani ili ndi ma byte khumi ndi asanu ndi anayi
/// assert_eq!(19, len);
///
/// // Titha kumanganso chingwe kuchokera ptr, len, ndi mphamvu.
/// // Izi zonse ndizosatetezeka chifukwa tili ndi udindo wowonetsetsa kuti zinthuzo ndizovomerezeka:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Ngati `String` ili ndi mphamvu zokwanira, kuwonjezera zinthu pamenepo sikudzagaŵanso.Mwachitsanzo, taganizirani pulogalamuyi:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Izi zidzatulutsa izi:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Poyamba, sitimakumbukira zomwe tidapatsidwa, koma momwe timalumikiza chingwecho, chimakulitsa mphamvu zake moyenera.Ngati m'malo mwake timagwiritsa ntchito njira ya [`with_capacity`] kuti tipeze mphamvu yoyenera poyamba:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Timakhala ndi zotulutsa zosiyana:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Apa, palibe chifukwa chogawa zokumbukira zambiri mkati mwake.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Cholakwika chotheka mukamasintha `String` kuchokera pa UTF-8 byte vector.
///
/// Mtundu uwu ndi mtundu wolakwika wa njira ya [`from_utf8`] pa [`String`].
/// Zapangidwa m'njira yoti tipewe kusamutsidwa mosamalitsa: njira ya [`into_bytes`] iperekanso byte vector yomwe idagwiritsidwa ntchito poyesa kutembenuka.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Mtundu wa [`Utf8Error`] woperekedwa ndi [`std::str`] umaimira cholakwika chomwe chingachitike posintha kagawo ka [`u8`] kukhala [`&str`].
/// Mwanjira imeneyi, ndi yofanana ndi `FromUtf8Error`, ndipo mutha kuyipeza kuchokera ku `FromUtf8Error` kudzera mu njira ya [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// // ma bafa ena osavomerezeka, mu vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Phindu lomwe lingakhalepo mukamasintha `String` kuchokera pagawo la UTF-16 byte.
///
/// Mtundu uwu ndi mtundu wolakwika wa njira ya [`from_utf16`] pa [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Kagwiritsidwe:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Pangani `String` yatsopano yopanda kanthu.
    ///
    /// Popeza `String` ilibe kanthu, izi sizigawa gawo lililonse loyambira.Ngakhale izi zikutanthauza kuti ntchito yoyambayi ndiyotsika mtengo kwambiri, itha kubweretsa kugawidwa kwakukulu pambuyo pake mukawonjezera deta.
    ///
    /// Ngati muli ndi chidziwitso cha kuchuluka kwa zomwe `String` idzagwira, ganizirani njira ya [`with_capacity`] yoletsa kugawa mobwerezabwereza.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Pangani `String` yopanda kanthu yatsopano.
    ///
    /// Zingwe zili ndi chosungira mkati kuti zisunge deta yawo.
    /// Kutalika kwake ndikutalika kwa buffer, ndipo kumatha kufunsidwa ndi njira ya [`capacity`].
    /// Njirayi imapanga `String` yopanda kanthu, koma yokhala ndi choyambitsa choyambirira chomwe chimatha kugwira ma `capacity` byte.
    /// Izi ndizothandiza mukakhala kuti mukugwiritsira ntchito gulu la deta ku `String`, ndikuchepetsa kuchuluka kwa magawo omwe akuyenera kuchita.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Ngati mphamvu yapatsidwa ndi `0`, palibe kugawa komwe kudzachitike, ndipo njirayi ndi yofanana ndi njira ya [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Chingwecho chilibe chars, ngakhale chili ndi kuthekera kowonjezera
    /// assert_eq!(s.len(), 0);
    ///
    /// // Izi zonse zimachitika popanda kusinthanso malo ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... koma izi zitha kupangitsa kuti chingwe chiwoneke
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): ndi cfg(test) njira yodziwika ya `[T]::to_vec`, yomwe imafunikira pakutanthauzira njirayi, sikupezeka.
    // Popeza sitikufuna njirayi poyesa kuyesa, ndingoyipaka NB kuwona slice::hack module mu slice.rs kuti mumve zambiri
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Imatembenuza vector ya mabayiti kukhala `String`.
    ///
    /// Chingwe ([`String`]) chimapangidwa ndi mabayiti ([`u8`]), ndipo vector ya mabayiti ([`Vec<u8>`]) amapangidwa ndi ma byte, kotero ntchitoyi imasintha pakati pa awiriwo.
    /// Osati magawo onse amtundu ndi othandiza `String`s, komabe: `String` imafuna kuti ikhale yovomerezeka UTF-8.
    /// `from_utf8()` macheke kuonetsetsa kuti mabayiti ndi ovomerezeka UTF-8, kenako amatembenuka.
    ///
    /// Ngati mukutsimikiza kuti kagawo kakang'ono ndi kovomerezeka UTF-8, ndipo simukufuna kuti mukhale ndi chitsimikizo chotsimikizika, pali mtundu wina wosatetezeka wa ntchitoyi, [`from_utf8_unchecked`], yomwe ili ndi machitidwe omwewo koma idumpha cheke.
    ///
    ///
    /// Njirayi idzasamalira kuti isatengere vector, kuti zitheke.
    ///
    /// Ngati mukufuna [`&str`] m'malo mwa `String`, ganizirani [`str::from_utf8`].
    ///
    /// Chosiyana ndi njirayi ndi [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Kubwezeretsa [`Err`] ngati kagawo sikali UTF-8 ndikufotokozera chifukwa chake mabayiti omwe aperekedwa si UTF-8.vector yomwe mwasamukira ikuphatikizidwanso.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// // ma byte ena, mu vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Tikudziwa kuti mabayilowa ndi ovomerezeka, chifukwa chake tigwiritsa ntchito `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Mabayiti olakwika:
    ///
    /// ```
    /// // ma bafa ena osavomerezeka, mu vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Onani zolemba za [`FromUtf8Error`] kuti mumve zambiri pazomwe mungachite ndi vuto ili.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Imatembenuza chidutswa cha mabatani kukhala chingwe, kuphatikiza zilembo zosayenera.
    ///
    /// Zingwe ndizopangidwa ndi ma byte ([`u8`]), ndipo kagawo ka mabayiti ([`&[u8]`][byteslice]) amapangidwa ndi ma byte, kotero ntchitoyi imasintha pakati pa awiriwo.Osati magawo onse amtundu ndi zingwe zomveka, komabe: zingwe zimayenera kukhala zenizeni UTF-8.
    /// Pakusintha uku, `from_utf8_lossy()` idzasinthira njira iliyonse yolakwika ya UTF-8 ndi [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], yomwe ikuwoneka ngati iyi:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Ngati mukutsimikiza kuti kagawo kakang'ono ndi kovomerezeka UTF-8, ndipo simukufuna kuti muthe kusintha, pali mtundu wina wosatetezeka wa ntchitoyi, [`from_utf8_unchecked`], womwe umakhala ndi machitidwe omwewo koma umadumpha macheke.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Ntchitoyi ibwezeretsa [`Cow<'a, str>`].Ngati chidutswa chathu sichiri cholondola UTF-8, ndiye kuti tifunika kuyikapo zilembo zosinthira, zomwe zingasinthe kukula kwa chingwecho, chifukwa chake, zimafunikira `String`.
    /// Koma ngati ndi UTF-8 yovomerezeka kale, sitikusowa gawo latsopano.
    /// Mtundu wobwererawu umatilola kuthana ndi milandu yonseyi.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// // ma byte ena, mu vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Mabayiti olakwika:
    ///
    /// ```
    /// // mabayiti osavomerezeka
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Sanjani UTF-16-encoded vector `v` kukhala `String`, ndikubwezera [`Err`] ngati `v` ili ndi chidziwitso chilichonse chosayenera.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Izi sizinachitike kudzera collect: : <Result<_, _>> () pazifukwa zogwirira ntchito.
        // FIXME: Ntchitoyi imatha kuphweka pamene #48994 yatsekedwa.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Sankhani kagawo kakang'ono kotsekedwa ka UTF-16-`v` mu `String`, ndikusintha deta yolakwika ndi [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Mosiyana ndi [`from_utf8_lossy`] yomwe imabwezeretsa [`Cow<'a, str>`], `from_utf16_lossy` imabwezeretsa `String` popeza kutembenuka kwa UTF-16 kukhala UTF-8 kumafuna kugawana kukumbukira.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Imasokoneza `String` m'zigawo zake zosaphika.
    ///
    /// Kubwezeretsa pointer yaiwisi kuzomwe zimayambira, kutalika kwa chingwe (m'mabayeti), ndi kuchuluka kwa zomwe zalembedwa (m'mabayeti).
    /// Izi ndi zifukwa zofananira chimodzimodzi monga zotsutsana ndi [`from_raw_parts`].
    ///
    /// Pambuyo poyitanitsa ntchitoyi, woyimbayo ndi amene amachititsa kuti kukumbukira kumayendetsedwa kale ndi `String`.
    /// Njira yokhayo yochitira izi ndikutembenuza cholembera, kutalika, ndi mphamvu kubwerera ku `String` ndi ntchito ya [`from_raw_parts`], kulola wowonongekayo kuti ayeretse.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Kupanga `String` yatsopano kuchokera kutalika, mphamvu, ndi pointer.
    ///
    /// # Safety
    ///
    /// Izi ndizosatetezeka kwambiri, chifukwa cha kuchuluka kwa osasintha omwe sanayang'anidwe:
    ///
    /// * Kukumbukira ku `buf` kuyenera kuti kudapatsidwa kale ndi omwe amagawa laibulale yofananira, ndikugwirizana kofanana ndendende 1.
    /// * `length` iyenera kukhala yochepera kapena yofanana ndi `capacity`.
    /// * `capacity` iyenera kukhala mtengo wolondola.
    /// * Ma `length` byte oyamba ku `buf` akuyenera kukhala ovomerezeka UTF-8.
    ///
    /// Kuphwanya izi kumatha kubweretsa mavuto monga kuwononga zomwe zili mkati mwa woperekayo.
    ///
    /// Umwini wa `buf` umasamutsidwa bwino kupita ku `String` yomwe imatha kusamutsa, kusinthanso kapena kusintha zomwe zili m'makumbukiro omwe cholozera cholozera chikuchita mwakufuna kwawo.
    /// Onetsetsani kuti palibenso china chomwe chimagwiritsa ntchito cholozera pambuyo poyitanitsa ntchitoyi.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Sinthani izi pamene vec_into_raw_parts ikhazikika.
    ///     // Pewani kutaya zokhazokha za String
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Imatembenuza vector ya mabayiti kukhala `String` osayang'ana ngati chingwecho chili ndi UTF-8 yoyenera.
    ///
    /// Onani mtundu wotetezeka, [`from_utf8`], kuti mumve zambiri.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Ntchitoyi ndi yosatetezeka chifukwa sikuwunika ngati mabayiti omwe adadutsamo ndi UTF-8.
    /// Ngati choletsedwachi chikuphwanyidwa, chitha kubweretsa kukumbukira kusatetezedwa ndi ogwiritsa ntchito a future a `String`, monga momwe laibulale yonseyo imaganiza kuti `String`s ndizovomerezeka UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// // ma byte ena, mu vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Imatembenuza `String` kukhala Byte vector.
    ///
    /// Izi zimawononga `String`, chifukwa chake sitiyenera kutengera zomwe zikupezeka.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Imachotsa kagawo kakang'ono kokhala ndi `String` yonse.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Imatembenuza `String` kukhala chingwe chosinthika.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Amagwiritsa ntchito chingwe chopatsidwa kumapeto kwa `String`.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Kubwezeretsa mphamvu ya `String`, m'ma byte.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Iwonetsetsa kuti mphamvu ya `String 'iyi ndi ma `additional` byte okulirapo kuposa kutalika kwake.
    ///
    /// Kuchulukako kumatha kuchulukitsidwa kuposa ma `additional` byte ngati angafune, popewa kusamutsidwa pafupipafupi.
    ///
    ///
    /// Ngati simukufuna izi "at least", onani njira ya [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics ngati mphamvu yatsopano ikusefukira [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Izi sizingakulitse mphamvu:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s tsopano ili ndi kutalika kwa 2 ndikutha kwa 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Popeza tili ndi mphamvu zowonjezera 8, kuzitcha izi ...
    /// s.reserve(8);
    ///
    /// // ... sichikula kwenikweni.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Onetsetsani kuti mphamvu ya `String 'iyi ndi ma `additional` byte okulirapo kuposa kutalika kwake.
    ///
    /// Ganizirani kugwiritsa ntchito njira ya [`reserve`] pokhapokha mutadziwa bwino kuposa wopatsa.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics ngati mphamvu yatsopano ikusefukira `usize`.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Izi sizingakulitse mphamvu:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s tsopano ili ndi kutalika kwa 2 ndikutha kwa 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Popeza tili ndi mphamvu zowonjezera 8, kuzitcha izi ...
    /// s.reserve_exact(8);
    ///
    /// // ... sichikula kwenikweni.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Imayesetsa kusunga mphamvu zosachepera `additional` zowonjezera kuti ziyikidwe mu `String` yomwe yapatsidwa.
    /// Zosonkhanitsazo zitha kusunga malo ambiri kuti zisawonongeke pafupipafupi.
    /// Pambuyo poyimba `reserve`, kuthekera kumakhala kwakukulu kuposa kapena kofanana ndi `self.len() + additional`.
    /// Sichichita chilichonse ngati kuthekera ndikwanira kale.
    ///
    /// # Errors
    ///
    /// Ngati mphamvu ikusefukira, kapena woperekayo akuti walephera, ndiye kuti cholakwika chimabwezedwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Sungitsani kukumbukira, kutuluka ngati sitingathe
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Tsopano tikudziwa kuti izi sizingatheke OOM pakati pa ntchito yathu yovuta
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Imayesetsa kusunga mphamvu zochepa pazinthu zina `additional` kuti ziyikidwe mu `String` yomwe yapatsidwa.
    ///
    /// Pambuyo poyimba `reserve_exact`, kuthekera kumakhala kwakukulu kuposa kapena kofanana ndi `self.len() + additional`.
    /// Sichichita chilichonse ngati kuthekera kuli kokwanira kale.
    ///
    /// Dziwani kuti woperekayo atha kupatsa malo osonkhanitsa malo ochulukirapo kuposa momwe amafunsira.
    /// Chifukwa chake, kuthekera sikungadaliridwe kukhala kocheperako kwenikweni.
    /// Sankhani `reserve` ngati future akuyembekezeredwa.
    ///
    /// # Errors
    ///
    /// Ngati mphamvu ikusefukira, kapena woperekayo akuti walephera, ndiye kuti cholakwika chimabwezedwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Sungitsani kukumbukira, kutuluka ngati sitingathe
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Tsopano tikudziwa kuti izi sizingatheke OOM pakati pa ntchito yathu yovuta
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Imachepetsa mphamvu ya `String` iyi kuti igwirizane ndi kutalika kwake.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Imachepetsa mphamvu ya `String` iyi ndikumangirira kotsika.
    ///
    /// Mphamvuyo idzakhalabe yocheperako ngati kutalika kwake ndi mtengo womwe waperekedwa.
    ///
    ///
    /// Ngati mphamvu zomwe zilipo pakadali pano ndizochepera malire, ndiye kuti palibe-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Amagwiritsa ntchito [`char`] yomwe yapatsidwa kumapeto kwa `String` iyi.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Kubwezeretsa chidutswa chazomwe zili mu `` String ''.
    ///
    /// Chosiyana ndi njirayi ndi [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Imafupikitsa `String` iyi kutalika kwake.
    ///
    /// Ngati `new_len` ndi yayikulu kuposa kutalika kwa chingwe, izi sizikhala ndi zotsatirapo.
    ///
    ///
    /// Dziwani kuti njirayi ilibe mphamvu pazogawika za chingwecho
    ///
    /// # Panics
    ///
    /// Panics ngati `new_len` sigona pamalire a [`char`].
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Imachotsa mawonekedwe omaliza pazosungira chingwe ndikuibweza.
    ///
    /// Imabwezeretsa [`None`] ngati `String` iyi ilibe kanthu.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Imachotsa [`char`] kuchokera ku `String` iyi pamalo pobwerera ndikubweza.
    ///
    /// Uku ndi ntchito ya *O*(*n*), chifukwa imafunika kukopera chilichonse chomwe chili mu buffer.
    ///
    /// # Panics
    ///
    /// Panics ngati `idx` ndi yayikulu kuposa kapena yofanana ndi kutalika kwa `String`, kapena ngati sikugona pamalire a [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Chotsani machesi onse a `pat` mu `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Zofanana zidzawoneka ndikuchotsedwa mozungulira, chifukwa chake momwe zochitika zimaphatikizira, ndi koyamba kokhako kamene kadzachotsedwe:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // CHITETEZO: kuyamba ndi kutha kudzakhala pamalire a utf8 by
        // Zofufuza za Searcher
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Imasunga zilembo zokha zotchulidwa ndi wotsogolera.
    ///
    /// Mwanjira ina, chotsani zilembo zonse `c` kotero kuti `f(c)` ibweretse `false`.
    /// Njirayi imagwira ntchito, kuyendera munthu aliyense chimodzimodzi kamodzi koyambirira, ndikusunga dongosolo la omwe adasungidwa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Dongosolo lenileni lingakhale lothandiza kutsatira zakunja, monga index.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Idx yoloza ku char yotsatira
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Ikani chilembo mu `String` iyi pamalo oyimilira.
    ///
    /// Uku ndi ntchito ya *O*(*n*) chifukwa imafunikira kukopera chilichonse chomwe chili mu buffer.
    ///
    /// # Panics
    ///
    /// Panics ngati `idx` ndi yayikulu kuposa kutalika kwa `String`, kapena ngati sikugona pamalire a [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Kuyika chingwe mu chingwe ichi mu `String` pamalo oyimilira.
    ///
    /// Uku ndi ntchito ya *O*(*n*) chifukwa imafunikira kukopera chilichonse chomwe chili mu buffer.
    ///
    /// # Panics
    ///
    /// Panics ngati `idx` ndi yayikulu kuposa kutalika kwa `String`, kapena ngati sikugona pamalire a [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Imabwezeretsa kutanthauzira kosinthika pazomwe zili mu `String` iyi.
    ///
    /// # Safety
    ///
    /// Ntchitoyi ndi yosatetezeka chifukwa sikuwunika ngati mabayiti omwe adadutsamo ndi UTF-8.
    /// Ngati choletsedwachi chikuphwanyidwa, chitha kubweretsa kukumbukira kusatetezedwa ndi ogwiritsa ntchito a future a `String`, monga momwe laibulale yonseyo imaganiza kuti `String`s ndizovomerezeka UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Imabwezera kutalika kwa `String` iyi, ndi ma byte, osati [`char`] s kapena graphemes.
    /// Mwanjira ina, sizingakhale zomwe munthu amawona kutalika kwa chingwecho.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Imabwezeretsa `true` ngati `String` iyi ili ndi kutalika kwa zero, ndipo `false` mwanjira ina.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Gawani chingwechi muwiri pa index ya byte yomwe yapatsidwa.
    ///
    /// Kubwezeretsa `String` yomwe yangoperekedwa kumene.
    /// `self` ili ndi ma byte `[0, at)`, ndipo `String` yobwezeretsedwayo ili ndi ma byte `[at, len)`.
    /// `at` iyenera kukhala pamalire a UTF-8 code point.
    ///
    /// Dziwani kuti kuchuluka kwa `self` sikusintha.
    ///
    /// # Panics
    ///
    /// Panics ngati `at` sichili pamalire a `UTF-8`, kapena ngati ili kupitirira gawo lomaliza la chingwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Imachotsa `String` iyi, ndikuchotsa zonse zomwe zili mkatimo.
    ///
    /// Ngakhale izi zikutanthauza kuti `String` idzakhala ndi kutalika kwa zero, sikumakhudza kukula kwake.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Pangani chojambulira chotulutsa chomwe chimachotsa mtundu wa `String` ndikupereka `chars` yochotsedwa.
    ///
    ///
    /// Note: Mtundu wazinthu umachotsedwa ngakhale iterator sichiwonongedwa mpaka kumapeto.
    ///
    /// # Panics
    ///
    /// Panics ngati poyambira kapena pomaliza sakugona pamalire a [`char`], kapena ngati alibe malire.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Chotsani mndandanda mpaka β kuchokera pa chingwe
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Mtundu wathunthu umachotsa chingwe
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Chitetezo chokumbukira
        //
        // Mtundu wa Zingwe za Drain ulibe zoteteza kukumbukira kukumbukira za vector.
        // Zambiri ndizongotengera.
        // Chifukwa kuchotsa kwamtunduwu kumachitika mu Drop, ngati Drain iterator yatulutsidwa, kuchotsa sikudzachitika.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Tulutsani ngongole ziwiri nthawi imodzi.
        // Chingwe cha &mut sichingapezeke mpaka itatha, ku Drop.
        let self_ptr = self as *mut _;
        // CHITETEZO: `slice::range` ndi `is_char_boundary` amachita malire oyenera.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Imachotsa mtundu womwe wafotokozedwayo, ndikuisintha ndi chingwe chomwe chapatsidwa.
    /// Chingwe chopatsidwa sichiyenera kukhala chofanana kutalika kwake.
    ///
    /// # Panics
    ///
    /// Panics ngati poyambira kapena pomaliza sakugona pamalire a [`char`], kapena ngati alibe malire.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Sinthani malirewo mpaka β kuchokera pachingwe
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Chitetezo chokumbukira
        //
        // M'malo_range ilibe zoteteza kukumbukira kukumbukira kwa vector Splice.
        // ya mtundu wa vector.Zambiri ndizongotengera.

        // Chenjezo: Kuyika zosinthazi sikungakhale koyenera (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // Chenjezo: Kuyika zosinthazi sikungakhale koyenera (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Kugwiritsa ntchito `range` kachiwiri sikungakhale koyenera (#81138) Timalingalira kuti malire omwe alembedwa ndi `range` amakhalabe ofanana, koma kukhazikitsa mdani kumatha kusintha pakati pama foni
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Imatembenuza `String` iyi kukhala [`Box`]`<`(`str`] `>`.
    ///
    /// Izi zitha kusiya kuchuluka kulikonse.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Imabwezeretsa kagawo ka [`u8`] s bytes omwe adayesedwa kuti asinthe kukhala `String`.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// // ma bafa ena osavomerezeka, mu vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Imabwezeretsa mabayiti omwe amayesedwa kuti asinthe kukhala `String`.
    ///
    /// Njirayi idapangidwa mosamala kuti isagawidwe.
    /// Idzathetsa cholakwikacho, kusunthira mabayiti, kotero kuti mtundu wa mabayiti safunika kupangidwa.
    ///
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// // ma bafa ena osavomerezeka, mu vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Tengani `Utf8Error` kuti mumve zambiri zakutembenuka kulephera.
    ///
    /// Mtundu wa [`Utf8Error`] woperekedwa ndi [`std::str`] umaimira cholakwika chomwe chingachitike posintha kagawo ka [`u8`] kukhala [`&str`].
    /// Mwanjira imeneyi, ndi analog ya `FromUtf8Error`.
    /// Onani zolemba zake kuti mumve zambiri pakugwiritsa ntchito.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// // ma bafa ena osavomerezeka, mu vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // chimbale choyamba ndi chosagwira pano
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Chifukwa tikulimbana ndi `String`s, titha kupewa gawo limodzi mwakutenga chingwe choyamba kuchokera ku iterator ndikuikapo zingwe zonse zotsatirazi.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Chifukwa tikulimbana ndi ma CoW, titha (potentially) kupewa gawo limodzi mwakutenga chinthu choyamba ndikuchiyikapo zinthu zonse zotsatira.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Kukhazikitsa kosavuta komwe nthumwi zimayitanitsa `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Amapanga `String` yopanda kanthu.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Imagwiritsa ntchito `+` poyendetsa zingwe ziwiri.
///
/// Izi zimawononga `String` kumanzere ndikugwiritsanso ntchito buffer yake (kukulitsa ngati kuli kofunikira).
/// Izi zachitika kuti mupewe kugawa `String` yatsopano ndikukopera zonse zomwe zikuchitika pazochitika zilizonse, zomwe zingapangitse nthawi ya *O*(*n*^ 2) popanga chingwe cha *n*-byte mobwerezabwereza.
///
///
/// Chingwe chakumanja chimangobwereka;zomwe zilipo zimakopedwa mu `String` yomwe yabwerera.
///
/// # Examples
///
/// Kuthetsa ma `String` awiri kumatenga yoyamba ndi mtengo ndikubwereka yachiwiri:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` yasunthidwa ndipo silingagwiritsidwenso ntchito pano.
/// ```
///
/// Ngati mukufuna kupitiliza kugwiritsa ntchito `String` yoyamba, mutha kuyiyika ndikulumikiza choyerekeza m'malo mwake:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` ikugwirabe ntchito pano.
/// ```
///
/// Kuphatikiza magawo a `&str` kumatha kutheka ndikusintha koyamba kukhala `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Ikugwiritsa ntchito `+=` kugwiritsa ntchito `String`.
///
/// Izi zili ndi machitidwe ofanana ndi njira ya [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Mtundu wina wa [`Infallible`].
///
/// Zoterezi zimakhalapo chifukwa chakumbuyo kwakumbuyo, ndipo kumapeto kwake kumatha kutsitsidwa.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// trait yosinthira mtengo kukhala `String`.
///
/// trait iyi imangoyendetsedwa pamtundu uliwonse yomwe imagwiritsa ntchito [`Display`] trait.
/// Mwakutero, `ToString` sayenera kuchitidwa mwachindunji:
/// [`Display`] ziyenera kukhazikitsidwa m'malo mwake, ndipo mumalandira kukhazikitsidwa kwa `ToString` kwaulere.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Imatembenuza mtengo wopatsidwa kukhala `String`.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Pakukhazikitsa, njira ya `to_string` panics ngati kukhazikitsa `Display` kubweza cholakwika.
/// Izi zikuwonetsa kukhazikitsa kolakwika kwa `Display` popeza `fmt::Write for String` sikubwezeretsanso vuto lokha.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Chitsogozo chofala ndikuti musagwirizane ndi ntchito za generic.
    // Komabe, kuchotsa `#[inline]` kuchokera munjira iyi kumapangitsa kusinthanso kosafunikira.
    // Onani <https://github.com/rust-lang/rust/pull/74852>, kuyesa komaliza kuyesa kuchotsa.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Imatembenuza `&mut str` kukhala `String`.
    ///
    /// Zotsatira zake zimaperekedwa pamulu.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: test imakoka mu libstd, zomwe zimayambitsa zolakwika apa
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Imatembenuza kagawo kakang'ono ka `str` kukhala `String`.
    /// Ndizodabwitsa kuti kagawo ka `str` kali nako.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Imatembenuza `String` yoperekedwa kukhala chidutswa cha `str` chomwe chili chake.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Imatembenuza chidutswa chachingwe kukhala chosintha chobwerekedwa.
    /// Palibe kugawa mulu komwe kumachitika, ndipo chingwecho sichimakopedwa.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Imatembenuza chingwe kuti chikhale chosinthika.
    /// Palibe kugawa mulu komwe kumachitika, ndipo chingwecho sichimakopedwa.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Imatembenuza cholozera cha String kukhala chosintha chobwerekedwa.
    /// Palibe kugawa mulu komwe kumachitika, ndipo chingwecho sichimakopedwa.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Imatembenuza `String` yoperekedwa kukhala vector `Vec` yomwe imakhala ndi malingaliro amtundu wa `u8`.
    ///
    /// # Examples
    ///
    /// Kagwiritsidwe:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Iterator yotulutsa ya `String`.
///
/// Izi zimapangidwa ndi njira ya [`drain`] pa [`String`].
/// Onani zolemba zake kuti mumve zambiri.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Idzagwiritsidwa ntchito ngati&'a mut String in the destructor
    string: *mut String,
    /// Yambani gawo kuti muchotse
    start: usize,
    /// Kutha kwa gawo kuti muchotse
    end: usize,
    /// Mtunda wotsala kuti uchotse
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Gwiritsani ntchito Vec::drain.
            // "Reaffirm" malire amafufuza kuti zode ya panic isayikidwenso.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Imabwezeretsa chingwe chotsalira (sub) cha iterator iyi ngati chidutswa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: onetsani AsRef kuyika pansipa mukakhazikika.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Kusavomerezeka mukakhazikitsa `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// kuyika <'a> AsRef<str>za Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> ya Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}