#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Zomwe zili mu kukumbukira kwatsopano sizinayambike.
    Uninitialized,
    /// Kukumbukira kwatsopano kumatsimikizika kuti kutsekedwa.
    Zeroed,
}

/// Ntchito yocheperako yogawira ena moyenera, kugawa malo ena, komanso kuthana ndi kukumbukira pamulu popanda kuda nkhawa ndi milandu yonse yomwe ikukhudzidwa.
///
/// Mtundu uwu ndiwothandiza kwambiri popanga zomwe mumapanga monga Vec ndi VecDeque.
/// Makamaka:
///
/// * Imapanga `Unique::dangling()` pamitundu yayikulu kwambiri.
/// * Imapanga `Unique::dangling()` pamagawo osachepera zero.
/// * Amapewa kumasula `Unique::dangling()`.
/// * Amagwira kusefukira konse kwama computation (amawalimbikitsa kupita ku "capacity overflow" panics).
/// * Alonda motsutsana ndi machitidwe a 32-bit omwe amapatula ma isize::MAX byte.
/// * Alonda motsutsana kusefukira kutalika kwanu.
/// * Kuyimbira `handle_alloc_error` pazogawana zolakwika.
/// * Ili ndi `ptr::Unique` motero imapatsa wogwiritsa ntchito maubwino ena onse.
/// * Gwiritsani ntchito zowonjezera zomwe zabwezedwa kuchokera kwa wogawira kuti mugwiritse ntchito zomwe zilipo zazikulu kwambiri.
///
/// Mtunduwu samayang'ananso kukumbukira komwe ungakwanitse.Mukayisiya *imasunga chikumbukiro chake, koma* siyiyesa kusiya zomwe zili mkatimo.
/// Zili kwa wogwiritsa ntchito `RawVec` kusamalira zinthu zenizeni *zosungidwa* mkati mwa `RawVec`.
///
/// Dziwani kuti kuchuluka kwa mitundu yayikulu kwambiri ya zero nthawi zonse kumakhala kopanda malire, chifukwa chake `capacity()` imabweza `usize::MAX` nthawi zonse.
/// Izi zikutanthauza kuti muyenera kukhala osamala mukamazungulira mtundu uwu ndi `Box<[T]>`, popeza `capacity()` siyipereka kutalika.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Izi zilipo chifukwa `#[unstable]` `const fn`s sayenera kutsatira `min_const_fn` motero sangatchulidwe mu`min_const_fn`s mwina.
    ///
    /// Ngati mungasinthe `RawVec<T>::new` kapena kudalira, chonde samalani kuti musayambitse chilichonse chomwe chingaphwanye `min_const_fn`.
    ///
    /// NOTE: Titha kupewa kubera izi ndikuwona kutsatira kwa `#[rustc_force_min_const_fn]` yomwe imafunikira kutsatira `min_const_fn` koma siyilola kuyitcha mu `stable(...) const fn`/nambala yogwiritsa ntchito osalola `foo` pomwe `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ilipo.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Amapanga `RawVec` yayikulu kwambiri (pamulu wa makina) osagawa.
    /// Ngati `T` ili ndi kukula kwabwino, ndiye kuti izi zimapanga `RawVec` yokhala ndi `0`.
    /// Ngati `T` ndi yayikulu-zero, ndiye kuti imapanga `RawVec` yokhala ndi mphamvu `usize::MAX`.
    /// Zothandiza pakukhazikitsa kagawidwe kochedwa.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Amapanga `RawVec` (pamulu wa dongosololi) ndi kuthekera kokwanira ndi kulumikizana kwa `[T; capacity]`.
    /// Izi ndizofanana ndi kuyitanitsa `RawVec::new` pomwe `capacity` ndi `0` kapena `T` ndiyazikuluziro.
    /// Dziwani kuti ngati `T` ndi wofanana ndi zero izi zikutanthauza kuti simungapeze `RawVec` ndi mphamvu yofunsidwa.
    ///
    /// # Panics
    ///
    /// Panics ngati mphamvu yofunsidwa iposa ma `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Kuchotsa pa OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Monga `with_capacity`, koma zimatsimikizira kuti buffer idasinthidwa.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Imapangidwanso `RawVec` kuchokera pa cholembera ndi mphamvu.
    ///
    /// # Safety
    ///
    /// `ptr` iyenera kuperekedwa (pamulu wa muluwo), komanso ndi `capacity` yopatsidwa.
    /// `capacity` siyingadutse `isize::MAX` yamitundu yayikulu.(zokhazokha pamakina a 32-bit).
    /// ZST vectors itha kukhala ndi mphamvu mpaka `usize::MAX`.
    /// Ngati `ptr` ndi `capacity` zichokera ku `RawVec`, ndiye kuti izi ndizotsimikizika.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Tiny Vecs ndi osayankhula.Pitani ku:
    // - 8 ngati kukula kwake kuli 1, chifukwa aliyense amene amagawa muluwo atha kufunsa zopempha zosachepera 8 byte mpaka ma 8 byte.
    //
    // - 4 ngati zinthu zili zazing'ono (<=1 KiB).
    // - 1 mwina, kuti mupewe kuwononga malo ambiri ma Vec achidule kwambiri.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Monga `new`, koma munasankhidwa posankha ogawa omwe abweza `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` amatanthauza "unallocated".Mitundu yayitali-zero imanyalanyazidwa.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Monga `with_capacity`, koma munasankhidwa posankha ogawa omwe abweza `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Monga `with_capacity_zeroed`, koma munasankhidwa posankha ogawa omwe abweza `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Imatembenuza `Box<[T]>` kukhala `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Imatembenuza gawo lonse kukhala `Box<[MaybeUninit<T>]>` ndi `len`.
    ///
    /// Dziwani kuti izi zikonzanso molondola zosintha zilizonse za `cap` zomwe mwina zidachitidwa.(Onani mafotokozedwe amtunduwu kuti mumve zambiri.)
    ///
    /// # Safety
    ///
    /// * `len` iyenera kukhala yoposa kapena yofanana ndi omwe amafunsidwa posachedwa, ndipo
    /// * `len` iyenera kukhala yochepera kapena yofanana ndi `self.capacity()`.
    ///
    /// Tawonani, kuti kuchuluka kopemphedwa ndi `self.capacity()` zitha kukhala zosiyana, popeza wopatsa akhoza kupitilira ndikubwezera chikumbukiro chachikulu kuposa momwe amafunsira.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sanity-fufuzani theka la chitetezo (sitingathe kuwunika theka linalo).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Timapewa `unwrap_or_else` apa chifukwa imachepetsa kuchuluka kwa LLVM IR komwe kumapangidwa.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Imapangitsanso `RawVec` kuchokera pa pointer, mphamvu, ndi yogawa.
    ///
    /// # Safety
    ///
    /// `ptr` iyenera kugawidwa (kudzera pa omwe adapatsidwa `alloc`), komanso ndi `capacity` yopatsidwa.
    /// `capacity` siyingadutse `isize::MAX` yamitundu yayikulu.
    /// (zokhazokha pamakina a 32-bit).
    /// ZST vectors itha kukhala ndi mphamvu mpaka `usize::MAX`.
    /// Ngati `ptr` ndi `capacity` zimachokera ku `RawVec` yopangidwa kudzera pa `alloc`, ndiye kuti izi ndizotsimikizika.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Ikupeza pointer yaiwisi koyambirira kwa kagawidwe.
    /// Dziwani kuti iyi ndi `Unique::dangling()` ngati `capacity == 0` kapena `T` ndi yaying'ono.
    /// M'mbuyomu, muyenera kukhala osamala.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Amapeza kuthekera kogawikaku.
    ///
    /// Izi zidzakhala `usize::MAX` nthawi zonse ngati `T` ili wofanana.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Imabwezeretsa zomwe zagawidwa kwa omwe akugawa omwe amathandizira `RawVec` iyi.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Tili ndi chunk yokumbukira yomwe tapatsidwa, kotero titha kupyola macheke othamanga kuti tipeze dongosolo lathu.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Onetsetsani kuti buffer ili ndi malo okwanira osungira zinthu `len + additional`.
    /// Ngati ilibe mphamvu yokwanira, ingakonzenso malo okwanira kuphatikiza malo ocheperako kuti muchepetse *O*(1) machitidwe.
    ///
    /// Idzachepetsa khalidweli ngati lingadzipangitse kukhala panic.
    ///
    /// Ngati `len` idutsa `self.capacity()`, izi zitha kulephera kugawa malo omwe afunsidwa.
    /// Izi sizowopsa kwenikweni, koma nambala yosatetezeka *inu* yolemba yomwe imadalira machitidwe a ntchitoyi itha kusweka.
    ///
    /// Izi ndizofunikira kukhazikitsa ntchito yolimbikitsana ngati `extend`.
    ///
    /// # Panics
    ///
    /// Panics ngati mphamvu yatsopano iposa ma `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Kuchotsa pa OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // kusungitsa kukadachotsa pamimba kapena kuchita mantha ngati lensi ikadutsa `isize::MAX` kotero izi ndi zotheka kuti zisayang'anitsidwe pano.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Zomwezo ndi `reserve`, koma zimabwerera pazolakwika m'malo mochita mantha kapena kuchotsa mimba.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Onetsetsani kuti buffer ili ndi malo okwanira osungira zinthu `len + additional`.
    /// Ngati sizikutero, zisinthitsa kuchuluka kwakumbukiro koyenera.
    /// Nthawi zambiri izi zizikhala ndendende kuchuluka kwa kukumbukira koyenera, koma kwenikweni wopatsa amakhala ndi ufulu wobwezera zochuluka kuposa momwe tidafunira.
    ///
    ///
    /// Ngati `len` idutsa `self.capacity()`, izi zitha kulephera kugawa malo omwe afunsidwa.
    /// Izi sizowopsa kwenikweni, koma nambala yosatetezeka *inu* yolemba yomwe imadalira machitidwe a ntchitoyi itha kusweka.
    ///
    /// # Panics
    ///
    /// Panics ngati mphamvu yatsopano iposa ma `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Kuchotsa pa OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Zomwezo ndi `reserve_exact`, koma zimabwerera pazolakwika m'malo mochita mantha kapena kuchotsa mimba.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Imachepetsa kagawidweko mpaka kuchuluka komwe kunafotokozedwako.
    /// Ngati ndalama zomwe zapatsidwa ndi 0, zimasunthiratu.
    ///
    /// # Panics
    ///
    /// Panics ngati ndalamazo ndi zazikulu * kuposa momwe ziliri pakali pano.
    ///
    /// # Aborts
    ///
    /// Kuchotsa pa OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Kubwezera ngati buffer iyenera kukula kuti ikwaniritse zowonjezera zowonjezera.
    /// Amagwiritsidwa ntchito kwambiri kupangira mayendedwe osungidwa osakwanira `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Njirayi imalimbikitsidwa nthawi zambiri.Chifukwa chake tikufuna kuti ikhale yaying'ono momwe zingathere, kuti tithandizire kuphatikiza nthawi.
    // Koma tikufunanso zambiri zomwe zili mkatimo kuti zikhale zowerengera momwe zingathere, kuti code yomwe idapangidwa iziyenda mwachangu.
    // Chifukwa chake, njirayi idalembedwa mosamala kotero kuti nambala yonse yomwe imadalira `T` ili mkati mwake, pomwe nambala yayikulu yomwe siyidalira `T` momwe ingathere ikugwira ntchito zomwe sizachilendo pa `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Izi zimatsimikiziridwa ndi mayitanidwe.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Popeza timabweza mphamvu ya `usize::MAX` pomwe `elem_size` ili
            // 0, kufika apa kumatanthauza kuti `RawVec` ndi yodzaza.
            return Err(CapacityOverflow);
        }

        // Palibe chomwe tingachite pama cheke awa, zachisoni.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Izi zimatsimikizira kukula kwakukulu.
        // Kubwereza kumatha kusefukira chifukwa `cap <= isize::MAX` ndi mtundu wa `cap` ndi `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` non-generic over `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Zovuta za njirayi ndizofanana ndi za `grow_amortized`, koma njirayi nthawi zambiri imakhazikika nthawi zambiri kotero siyofunika kwenikweni.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Popeza timabweza mphamvu ya `usize::MAX` pomwe kukula kwake kuli
            // 0, kufika apa kumatanthauza kuti `RawVec` ndi yodzaza.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` non-generic over `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Ntchitoyi ili kunja kwa `RawVec` kuti ichepetse nthawi zophatikizika.Onani ndemanga pamwambapa `RawVec::grow_amortized` kuti mumve zambiri.
// (`A` parameter siyofunika, chifukwa kuchuluka kwamitundu yosiyanasiyana ya `A` yomwe ikuwonetsedwa ndikuchita ndi kocheperako poyerekeza ndi mitundu ya `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Fufuzani zolakwika apa kuti muchepetse kukula kwa `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Wogawana amafufuza kufanana komwe kulipo
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Kumasula kukumbukira kwa `RawVec`*popanda* kuyesera kusiya zomwe zili mkatimo.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Ntchito yapakati yosungitsa zolakwika.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Tiyenera kutsimikizira izi:
// * Sitimagawana konse zinthu zakutchire za `> isize::MAX`.
// * Sitikusefukira `usize::MAX` ndipo timagawana zochepa kwambiri.
//
// Pa 64-bit tifunika kungofufuza ngati kusefukira popeza kuyesa kugawa ma `> isize::MAX` byte kulephera.
// Pa 32-bit ndi 16-bit tifunika kuwonjezera zowonjezera pa izi ngati tikuthamanga papulatifomu yomwe ingagwiritse ntchito 4GB yonse m'malo ogwiritsa ntchito, mwachitsanzo, PAE kapena x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Ntchito imodzi yapakati yomwe imafotokoza kuchuluka kwa anthu kusefukira.
// Izi ziwonetsetsa kuti mtundu wama code wokhudzana ndi panics ndiwochepa ngati pali malo amodzi omwe panics osati gulu lonse.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}