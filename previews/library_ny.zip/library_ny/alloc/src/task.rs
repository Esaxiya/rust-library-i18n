#![stable(feature = "wake_trait", since = "1.51.0")]
//! Mitundu ndi Traits yogwira ntchito ndi zozizwitsa.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Kukhazikitsa ntchito yakudzutsa wakwaniritsa.
///
/// trait iyi itha kugwiritsidwa ntchito kupanga [`Waker`].
/// Wowonetsetsa akhoza kutanthauzira kukhazikitsidwa kwa trait, ndikuigwiritsa ntchito popanga Waker kuti ipite kuntchito zomwe zimaperekedwa kwa wakwanayo.
///
/// trait iyi ndi njira yoteteza kukumbukira komanso ergonomic popanga [`RawWaker`].
/// Ikuthandizira kapangidwe ka wamba wamba komwe deta yomwe imagwiritsa ntchito kudzutsa ntchito imasungidwa mu [`Arc`].
/// Ma executor ena (makamaka omwe ali ndi makina ophatikizidwa) sangathe kugwiritsa ntchito API iyi, ndichifukwa chake [`RawWaker`] imakhalapo ngati njira ina m'malo mwa machitidwewa.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Ntchito yoyambira `block_on` yomwe imatenga future ndikuyiyendetsa kuti ikwane pa ulusi wapano.
///
/// **Note:** Chitsanzo ichi chimagulitsa zolondola kuti chikhale chosavuta.
/// Pofuna kupewa zolepheretsa, kukhazikitsa magwiridwe antchito kuyeneranso kuyitanitsa mafoni apakatikati a `thread::unpark` komanso mapempho omwe ali ndi zisa.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Wodzuka yemwe amadzutsa ulusi wapano akaitanidwa.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Kuthamangitsani future kuti mumalize pa ulusi wapano.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Ikani future kuti athe kuyimba.
///     let mut fut = Box::pin(fut);
///
///     // Pangani nkhani yatsopano kuti iperekedwe ku future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Kuthamangitsani future mpaka kumaliza.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Dzutsani ntchitoyi.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Dzutsani ntchitoyi osadya chilichonse.
    ///
    /// Woweruza akamagwiritsa ntchito njira yotsika mtengo yodzuka popanda kugwiritsa ntchito waker, iyenera kupitilira njirayi.
    /// Pokhapokha, imagwirizira [`Arc`] ndikuyitanitsa [`wake`] pachonyamulira.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // CHITETEZO: Izi ndizabwino chifukwa raw_waker amamanga bwino
        // RawWaker waku Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Ntchito yachinsinsi yopanga RawWaker imagwiritsidwa ntchito, osati
// kulowetsa izi mu `From<Arc<W>> for RawWaker` impl, kuonetsetsa kuti chitetezo cha `From<Arc<W>> for Waker` sichidalira trait yolondola, m'malo mwake ma impls onse amatcha ntchitoyi molunjika komanso momveka bwino.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Lonjezerani kuchuluka kwa arc kuti mupangidwe.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Dzuka ndi mtengo, kusuntha Arc mu Wake::wake ntchito
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Dzukani mwa kutanthauzira, kukulunga waker mu ManuallyDrop kuti mupewe kugwa
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Pewani kuwerengera kwa Arc kutsika
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}