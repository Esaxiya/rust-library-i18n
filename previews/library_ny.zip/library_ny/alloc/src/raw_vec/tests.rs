use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Kulemba mayeso oyanjana pakati pa omwe amapereka chipani chachitatu ndi `RawVec` ndizovuta pang'ono chifukwa `RawVec` API siziwonetsa njira zoperekera zolakwika, chifukwa chake sitingayang'ane zomwe zimachitika ogawana atatopa (kupatula kudziwa panic).
    //
    //
    // M'malo mwake, izi zimangowunika kuti njira za `RawVec` zimadutsa mu Allocator API ikasungira.
    //
    //
    //
    //
    //

    // Wopatsa osayankhula omwe amadya mafuta okwanira asanayese kugawa ayamba kulephera.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (imayambitsa malo, ndikugwiritsa ntchito mafuta 50 + 150=200 mayunitsi)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Choyamba, `reserve` imagawa ngati `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 imadutsa kawiri pa 7, chifukwa chake `reserve` iyenera kugwira ntchito ngati `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 ndi ochepera theka la 12, chifukwa chake `reserve` iyenera kukula mopitilira muyeso.
        // Panthawi yolemba mayesowa kukula ndi 2, ndiye kuti mphamvu zatsopano ndi 24, komabe, kukula kwa 1.5 kulinso koyenera.
        //
        // Chifukwa chake `>= 18` imatsimikizira.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}