use core::ffi::c_void;
use core::fmt;

/// Imayang'ana malo omwe alipo tsopano, ndikudutsa mafelemu onse kuti atseke kuti apeze kuchuluka kwa zosewerera.
///
/// Ntchitoyi ndi ntchito yolumikizira laibulale iyi powerengera kuchuluka kwa pulogalamuyi.Kutseka komwe kwapatsidwa `cb` kumakhala ndi zochitika za `Frame` zomwe zimayimira zidziwitso za chimango choyimbira.
/// Kutsekedwa kumapereka mafelemu otsogola (omwe amatchedwa ntchito poyamba).
///
/// Mtengo wobwerera wotsekedwa ndi chisonyezo chobwerera kumbuyo kuyenera kupitilirabe.Phindu lobwezera la `false` limathetsa kubwerera kumbuyo ndikubwerera nthawi yomweyo.
///
/// `Frame` ikangopezeka mudzafuna kuyimbira `backtrace::resolve` kuti mutembenuzire `ip` (cholozera cholozera) kapena adilesi yazizindikiro kukhala `Symbol` kudzera momwe dzina ndi/kapena filename/nambala nambala ingaphunzire.
///
///
/// Dziwani kuti ili ndi gawo lotsika kwambiri ndipo ngati mungafune, mwachitsanzo, kujambula kumbuyo kuti mukayang'anitsidwe pambuyo pake, ndiye kuti mtundu wa `Backtrace` ungakhale woyenera kwambiri.
///
/// # Zofunikira
///
/// Ntchitoyi imafuna kuti mbali ya `std` ya `backtrace` crate ikhale yolumikizidwa, ndipo mawonekedwe a `std` amathandizidwa mwachisawawa.
///
/// # Panics
///
/// Ntchitoyi imayesetsa kuti isakhale panic, koma ngati `cb` idapereka panics ndiye kuti nsanja zina zimakakamiza panic kuti ichotse ntchitoyi.
/// Mapulatifomu ena amagwiritsa ntchito laibulale ya C yomwe mkati mwake imagwiritsa ntchito zovuta zomwe sizingadutsike, chifukwa chake mantha kuchokera ku `cb` atha kuyambitsa njira yochotsera.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // pitilizani kumbuyo
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Zofanana ndi `trace`, ndizotetezeka kokha chifukwa sizolumikizidwa.
///
/// Ntchitoyi ilibe mawonekedwe olumikizirana koma imapezeka ngati gawo la `std` la crate silinapangidwe.
/// Onani ntchito ya `trace` kuti mumve zambiri ndi zitsanzo.
///
/// # Panics
///
/// Onani zambiri pa `trace` pazodzitchinjiriza pa `cb` kuchita mantha.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait yoyimira chimango chimodzi chakumbuyo, idapereka ntchito ya `trace` ya crate iyi.
///
/// Kutsekedwa kwa ntchito yotsatirako kudzakhala ndi mafelemu, ndipo chimango chimatumizidwa ngati kukhazikitsa sikumadziwika nthawi zonse mpaka nthawi yothamanga.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Ikubwezeretsani cholozera chamakono cha chimango ichi.
    ///
    /// Ili ndiye lamulo lotsatira loti muchite mu chimango, koma sizinthu zonse zomwe zimalemba izi molondola 100% (koma nthawi zambiri zimayandikira).
    ///
    ///
    /// Tikulimbikitsidwa kupititsa mtengowu ku `backtrace::resolve` kuti usanduke dzina lodziwika.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Ikubwezeretsanso cholozera chamtunduwu.
    ///
    /// Pomwe backend singabwezeretse cholembera cha chimango ichi, cholembera chopanda pake chimabwezedwa.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Imabwezeretsa adilesi yoyambira ya chimango cha ntchitoyi.
    ///
    /// Izi ziyesa kubwezera cholembera chophunzitsira chomwe chabwezedwa ndi `ip` koyambirira kwa ntchitoyi, ndikubwezeretsanso mtengo wake.
    ///
    /// Nthawi zina, kubwerera kumbuyo kungangobweza `ip` kuchokera pantchitoyi.
    ///
    /// Mtengo wobwezedwa nthawi zina ungagwiritsidwe ntchito ngati `backtrace::resolve` yalephera pa `ip` yoperekedwa pamwambapa.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Akufotokozera adiresi m'munsi mwa gawo limene chimango chimakhala.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Izi zikuyenera kubwera poyamba, kuwonetsetsa kuti Miri akutenga malo oyamba kuposa omwe amakhala nawo
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // amagwiritsidwa ntchito pofanizira dbghelp
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}