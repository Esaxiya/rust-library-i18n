//! Gawo lothandizira kuthana ndi ma dbghelp bindings pa Windows
//!
//! Zobwerera kumbuyo pa Windows (makamaka za MSVC) zimayendetsedwa kwambiri kudzera mu `dbghelp.dll` ndi ntchito zosiyanasiyana zomwe ilipo.
//! Ntchitoyi pakadali pano imasungidwa *mwamphamvu* m'malo molumikizana ndi `dbghelp.dll`.
//! Izi zikuchitidwa ndi laibulale yanthawi zonse (ndipo mukuganiza kuti zikufunika pamenepo), koma ndicholinga chothandizira kuchepetsa kudalira kwa laibulale popeza kumbuyo kwake kumakhala kosavuta.
//!
//! Izi zikunenedwa, `dbghelp.dll` pafupifupi nthawi zonse imasenza bwino pa Windows.
//!
//! Dziwani ngakhale kuti popeza tikutsitsa chithandizo chonsechi mwamphamvu sitingagwiritse ntchito tanthauzo la `winapi`, koma tifunika kutanthauzira mitundu ya pointer ya ntchito tokha ndikuigwiritsa ntchito.
//! Sitikufuna kwenikweni kukhala ochita bizinesi yopanga winapi, chifukwa chake tili ndi gawo la Cargo `verify-winapi` lomwe limanena kuti zomangiriza zonse zikufanana ndi za winapi ndipo izi zimathandizidwa pa CI.
//!
//! Pomaliza, muwona apa kuti dll ya `dbghelp.dll` siyimasulidwa, ndipo pano ndicholinga.
//! Lingaliro ndiloti titha kuzisunga padziko lonse lapansi ndikuzigwiritsa ntchito pakati pa mafoni ku API, kupewa loads/unloads yotsika mtengo.
//! Ngati ili ndi vuto kwa ma detector otayikira kapena zina zotere titha kuwoloka mlatho titafika kumeneko.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Gwiritsani ntchito mozungulira `SymGetOptions` ndi `SymSetOptions` osapezeka mu winapi palokha.
// Kupanda kutero izi zimangogwiritsidwa ntchito tikayang'ana mitundu iwiri motsutsana ndi winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Sinafotokozedwe mu winapi panobe
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Izi zimatanthauzidwa mu winapi, koma sizolondola (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Sinafotokozedwe mu winapi panobe
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Macro awa amagwiritsidwa ntchito kutanthauzira kapangidwe ka `Dbghelp` kamene mkati mwake muli zolemba zonse zomwe tingatenge.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// DLL yodzaza ya `dbghelp.dll`
            dll: HMODULE,

            // Cholozera chilichonse cha ntchito iliyonse yomwe tingagwiritse ntchito
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Poyamba sitinatengere DLL
            dll: 0 as *mut _,
            // Initiall ntchito zonse zakonzedwa kuti zonena kuti ziyenera kusungidwa mwamphamvu.
            //
            $($name: 0,)*
        };

        // Mtundu woyenera wa mtundu uliwonse wa ntchito.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Kuyesera kutsegula `dbghelp.dll`.
            /// Kubwezeretsa kupambana ngati kungagwire ntchito kapena vuto ngati `LoadLibraryW` yalephera.
            ///
            /// Panics ngati laibulale yadzaza kale.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Ntchito ya njira iliyonse yomwe tikufuna kugwiritsa ntchito.
            // Ikayitanidwa itha kuwerenga cholembera cholozera kapena kuyiyika ndikubweza mtengo wolemetsedwa.
            // Katundu amatsimikiziridwa kuti achita bwino.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Proxy yosavuta kugwiritsa ntchito maloko oyeretsera kuti muwonetse ntchito za dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Yambitsani zonse zothandizira zofunika kupeza ma `dbghelp` API kuchokera ku crate.
///
///
/// Dziwani kuti ntchitoyi ndi **yotetezeka**, mkati mwake imakhala ndi kulumikizana kwake.
/// Onaninso kuti ndikwabwino kuyitanitsa ntchitoyi kangapo mobwerezabwereza.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Choyamba chomwe tiyenera kuchita ndikusinthanitsa ntchitoyi.Izi zitha kutchedwa nthawi imodzi kuchokera ku ulusi wina kapena kubwereranso mkati mwa ulusi umodzi.
        // Dziwani kuti ndizovuta kuposa izi chifukwa zomwe tikugwiritsa ntchito pano, `dbghelp`, * iyeneranso kulumikizidwa ndi onse omwe akuyimba foni ku `dbghelp` panthawiyi.
        //
        // Nthawi zambiri pamakhala mafoni ochuluka kwambiri ku `dbghelp` munjira yomweyo ndipo titha kuganiza kuti ndife okhawo omwe tikulipeza.
        // Komabe, pali wina wogwiritsa ntchito wamkulu yemwe timayenera kuda nkhawa kuti ndi ziti zomwe sizodabwitsa, koma mulaibulale yanthawi zonse.
        // Laibulale yokhazikika ya Rust imadalira pa crate iyi yothandizira kumbuyo, ndipo crate iyi imapezekanso pa crates.io.
        // Izi zikutanthauza kuti ngati laibulale yovomerezeka imasindikiza chobwerera cha panic itha kuthamanga ndi crate iyi yochokera ku crates.io, ndikupangitsa kusokonekera.
        //
        // Pofuna kuthana ndi vutoli, timagwiritsa ntchito chinyengo cha Windows apa (pambuyo pake, lamulo loletsa Windows kulunzanitsa).
        // Timapanga *gawo-lamderalo* lotchedwa mutex kuti titeteze kuyitanaku.
        // Cholinga apa ndikuti laibulale yovomerezeka ndi crate sichiyenera kugawana ma Rust-level API kuti agwirizane pano koma atha kugwira ntchito kuseri kuti awonetsetse kuti akugwirizana.
        //
        // Mwanjira imeneyi pamene ntchitoyi imayitanidwa kudzera mu laibulale yanthawi zonse kapena kudzera pa crates.io titha kukhala otsimikiza kuti chimx chomwecho chikupezeka.
        //
        // Chifukwa chake zonse ndikuti chinthu choyamba chomwe timachita apa ndikupanga `HANDLE` yomwe imatchedwa mutex pa Windows.
        // Timagwirizanitsa pang'ono ndi ulusi wina wogawira ntchitoyi makamaka ndikuonetsetsa kuti chogwirira chimodzi chokha chimapangidwa malinga ndi ntchitoyi.
        // Dziwani kuti chogwirira sichimatsekedwa chikasungidwa padziko lonse lapansi.
        //
        // Tikatha kupita pachokhacho timangopeza, ndipo chogwirizira chathu cha `Init` chomwe timapereka chidzakhala ndi udindo wosiya nthawi ina.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Chabwino, phew!Tsopano popeza tonsefe talumikizidwa bwino, tiyeni tiyambe kukonza chilichonse.
        // Choyamba tifunika kuwonetsetsa kuti `dbghelp.dll` imadzazidwiratu.
        // Timachita izi mwamphamvu kuti tipewe kudalira kokhazikika.
        // Izi zakhala zikuchitidwa kale kuti zizigwira ntchito yolumikizana modabwitsa ndipo cholinga chake ndikupangitsa kuti ma binaries atengeke kwambiri popeza izi ndizongogwiritsa ntchito potengera vuto.
        //
        //
        // Tikangotsegula `dbghelp.dll` tifunika kuyitanitsa zoyambitsa zake, ndipo ndizomwe zili pansipa.
        // Timangochita izi kamodzi, komabe, tili ndi boolean yapadziko lonse lapansi yomwe ikuwonetsa ngati tamaliza kapena ayi.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Onetsetsani kuti mbendera ya `SYMOPT_DEFERRED_LOADS` yakhazikitsidwa, chifukwa malinga ndi zolemba za MSVC za izi: "This is the fastest, most efficient way to use the symbol handler.", ndiye tiyeni tichite zimenezo!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Kwenikweni yambitsani zizindikiro ndi MSVC.Dziwani kuti izi zitha kulephera, koma timanyalanyaza.
        // Palibe tani yamaluso am'mbuyomu, koma LLVM mkati ikuwoneka ngati ikunyalanyaza phindu lobwezera pano ndipo imodzi mwalaibulale ya sanitizer ku LLVM imalemba chenjezo lowopsa ngati izi zilephera koma amazinyalanyaza pamapeto pake.
        //
        //
        // Mlandu umodzi womwe zimabwera kwambiri ku Rust ndikuti laibulale yofananira ndi crate iyi pa crates.io onse akufuna kupikisana ndi `SymInitializeW`.
        // Laibulale yovomerezeka yomwe kale idkafuna kuyambitsa ndikuyeretsa nthawi zambiri, koma popeza ikugwiritsa ntchito crate zikutanthauza kuti wina ayamba kuyambitsa ndipo winayo ndi amene ayambe kuyambitsa.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}