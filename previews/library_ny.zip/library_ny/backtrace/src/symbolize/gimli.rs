//! Chithandizo chophiphiritsira pogwiritsa ntchito `gimli` crate pa crates.io
//!
//! Uku ndiko kukhazikitsa kosasintha kwa Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'moyo wosasunthika ndi bodza lobera chifukwa chosowa chithandizo chodzipangira.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Sinthani kukhala 'nthawi yayitali chifukwa zizindikirazo zimangobwereka `map` ndi `stash` ndipo tikuzisunga pansipa.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Pojambula makanema achilengedwe pa Windows, onani zokambirana pa rust-lang/rust#71060 pazinthu zosiyanasiyana apa.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Malaibulale a MinGW pakadali pano sagwirizana ndi ASLR (rust-lang/rust#16514), koma ma DLL atha kusamutsidwa mozungulira m'malo adilesi.
            // Zikuwoneka kuti maadiresi omwe akupezeka pazotulutsa zonse ali ngati laibulale iyi idasungidwa ku "image base", yomwe ndi gawo m'mutu wake wa mafayilo a COFF.
            // Popeza izi ndi zomwe debuginfo ikuwoneka kuti ikulemba timayala tebulo lazizindikiro ndikusunga ma adilesi ngati kuti laibulale idadzazidwa ku "image base".
            //
            // Laibulale mwina silingadzaze pa "image base", komabe.
            // (mwina china chake chitha kunyamulidwa pamenepo?) Apa ndipomwe gawo la `bias` limayamba, ndipo tikufunika kudziwa phindu la `bias` apa.Tsoka ilo ngakhale sizikudziwika momwe mungapezere izi kuchokera modula yodzaza.
            // Zomwe tili nazo, komabe, ndi adilesi yathunthu ya (`modBaseAddr`).
            //
            // Monga kutulutsa pang'ono pakadali pano timasintha fayiloyo, werengani zambiri pamutu wa fayiloyo, kenako nkutaya mmap.Izi ndizowononga chifukwa mwina tidzatsegulanso mmap pambuyo pake, koma izi zikuyenera kugwira ntchito mokwanira pakadali pano.
            //
            // Tikakhala ndi `image_base` (malo omwe mukufuna katundu) ndi `base_addr` (malo enieni katundu) titha kudzaza `bias` (kusiyana pakati pa zenizeni ndi zomwe mukufuna) kenako adilesi yomwe yanenedwa pagawo lililonse ndi `image_base` popeza ndi zomwe fayilo imanena.
            //
            //
            // Pakadali pano zikuwoneka kuti mosiyana ndi ELF/MachO titha kuchita ndi gawo limodzi pa laibulale, pogwiritsa ntchito `modBaseSize` kukula kwake konse.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS imagwiritsa ntchito mafayilo amtundu wa Mach-O ndipo imagwiritsa ntchito ma API apadera a DYLD kuti ikweze mndandanda wamalaibulale omwe ali mgululi.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Tengani dzina la laibulale iyi lomwe likugwirizana ndi njira yomwe mungayikenso.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Tengani mutu wa chithunzi wa laibulale iyi ndikupatsirani `object` kuti muwerenge malamulo onse kuti titha kudziwa magawo onse omwe akukhudzidwa pano.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Sinthani magawo ndi kulembetsa madera omwe amadziwika kuti ndimagulu omwe timapeza.
            // Kuphatikiza apo lembani magawo amalemba pamagwiritsidwe kuti muwongolere pambuyo pake, onani ndemanga pansipa.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Dziwani "slide" ya laibulale iyi yomwe imatha kukhala kukondera komwe timagwiritsa ntchito kuti tidziwe komwe zinthu zokumbukira zimasungidwa.
            // Izi ndizowerengera modabwitsa ngakhale ndipo ndizotsatira zoyesera zinthu zochepa kuthengo ndikuwona zomwe zimamatira.
            //
            // Lingaliro ndilakuti `bias` kuphatikiza gawo la `stated_virtual_memory_address` lidzakhala komwe kuli adilesi yomwe gawolo likukhalamo.
            // China chomwe timadalira ndichakuti adilesi yeniyeni yopanda `bias` ndiye cholozera choti muyang'ane patebulo lazizindikiro ndi debuginfo.
            //
            // Zikuwoneka kuti, m'malaibulale osungidwa ndi makina kuwerengetsa uku sikulondola.Kwa otsogolera achibadwidwe, komabe, zikuwoneka ngati zolondola.
            // Kukweza malingaliro ena kuchokera ku gwero la LLDB ili ndi cholembera chapadera cha gawo loyamba la `__TEXT` lojambulidwa kuchokera pa fayilo offset 0 ndi kukula kwa nonzero.
            // Pazifukwa zilizonse izi zikakhala zikuwoneka kuti zikutanthawuza kuti tebulo lophiphiritsa limangofanana ndi vmaddr slide yapa library.
            // Ngati *palibe* ndiye kuti gome lazizindikiro likugwirizana ndi vmaddr slide kuphatikiza adilesi yomwe yanenedwa.
            //
            // Pofuna kuthana ndi vutoli ngati * sitipeza gawo pazolembapo zero timakulitsa kukondera ndi adilesi yoyambayo ndikuchepetsa ma adilesi onse ndi ndalamazo.
            //
            // Mwanjira imeneyi tebulo lazizindikiro nthawi zonse limawonekera poyerekeza ndi kuchuluka kwa kukondera kwa laibulale.
            // Izi zikuwoneka kuti zili ndi zotsatira zabwino zofananira kudzera pagome lazizindikiro.
            //
            // Moona mtima sindikutsimikiza ngati izi ndi zolondola kapena ngati pali china chake chomwe chikuyenera kuwonetsa momwe mungachitire izi.
            // Pakadali pano ngakhale izi zikuwoneka ngati zikugwira ntchito bwino (?) ndipo nthawi zonse timayenera kusintha izi pakapita nthawi ngati kuli kofunikira.
            //
            // Kuti mumve zambiri onani #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Unix ina (mwachitsanzo
        // Linux) nsanja zimagwiritsa ntchito ELF ngati fayilo yamafayilo ndipo imagwiritsa ntchito API yotchedwa `dl_iterate_phdr` kuti inyamule malaibulale akomweko.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` ziyenera kukhala zolozera zomveka.
        // `vec` iyenera kukhala cholozera chovomerezeka ku `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 sichikuthandizira mwanjira inayake chidziwitso chazakutsutsana, koma makinawo adzaika zambiri panjira `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // China chilichonse chiyenera kugwiritsa ntchito ELF, koma sichidziwa momwe mungayikitsire malaibulale achilengedwe.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Malaibulale onse odziwika omwe adagawana omwe adasungidwa.
    libraries: Vec<Library>,

    /// Mapu osungira kumene timasunga zidziwitso zazing'ono.
    ///
    /// Mndandandawu uli ndi mphamvu yokhazikika pa nthawi yonse ya moyo wake yomwe sichulukirapo.
    /// Chigawo cha `usize` cha gulu lililonse ndi cholozera ku `libraries` pamwambapa pomwe `usize::max_value()` ikuyimira zomwe zingachitike.
    ///
    /// `Mapping` imafanana ndi chidziwitso chachidule.
    ///
    /// Dziwani kuti ichi ndi cache ya LRU ndipo tidzakhala tikusuntha zinthu mozungulira pano pamene tikuyimira ma adilesi.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Zigawo za laibulaleyi zimasungidwa ndikukumbukira, komanso komwe zimasungidwa.
    segments: Vec<LibrarySegment>,
    /// "bias" ya laibulaleyi, makamaka pomwe imasungidwa kukumbukira.
    /// Mtengo uwu umawonjezeredwa ku adilesi iliyonse yomwe ili ndi gawo kuti ipeze adilesi yakumbukiro yomwe gawolo lidayikidwa.
    /// Kuphatikiza apo kusankhaku kumachotsedwa pamadiresi enieni amakumbukidwe kuti alowe mu debuginfo ndi tebulo lazizindikiro.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Adilesi yomwe yanenedwa pagawoli mu fayilo yazinthu.
    /// Apa sindiwo pomwe gawolo ladzaza, koma adilesi iyi kuphatikiza laibulale ya `bias` ndi komwe mungapeze.
    ///
    stated_virtual_memory_address: usize,
    /// Kukula kwa gawo ths kukumbukira.
    len: usize,
}

// osatetezeka chifukwa izi zimafunikira kuti zifanane ndi kunja
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // osatetezeka chifukwa izi zimafunikira kuti zifanane ndi kunja
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Chosungira chaching'ono kwambiri, chosavuta kwambiri cha LRU chazomwe mungachite polemba mapu.
        //
        // Mulingo woyenera kugunda uyenera kukhala wokwera kwambiri, popeza okwanira samadutsa pakati pamalaibulale ambiri omwe adagawidwa.
        //
        // Mapangidwe a `addr2line::Context` ndiokwera mtengo kwambiri kuti apange.
        // Mtengo wake ukuyembekezeka kuchepetsedwa ndi mafunso otsatira a `locate`, omwe amalimbikitsa zomangamanga pomanga `addr2line: : Context`s kuti mupeze ma speedups abwino.
        //
        // Tikadapanda kusungira izi, kuchotsera chithandizochi sikukadachitika, ndipo zoyimira kumbuyo zikadakhala ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Choyamba, yesani ngati `lib` iyi ili ndi gawo lililonse lomwe lili ndi `addr` (yothandizira kusamutsidwa).Ngati cheke ichi chikadutsa titha kupitiliza pansipa ndikumasulira adilesiyo.
                //
                // Dziwani kuti tikugwiritsa ntchito `wrapping_add` pano kuti tipewe macheke omwe akusefukira.Zakhala zikuwoneka kuthengo kuti kuwerengetsa kwa SVMA + kumasefukira.
                // Zikuwoneka ngati zosamvetseka zomwe zingachitike koma palibe zochuluka zomwe tingachite za izi kupatula kuti tingonyalanyaza zigawozo chifukwa mwina zikulozera mlengalenga.
                //
                // Izi zidayamba mu rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Tsopano popeza tikudziwa kuti `lib` ili ndi `addr`, titha kulimbana ndi tsankho kuti tipeze adilesi yakumbuyo ya virutal.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Zosintha: zikakwaniritsidwa izi popanda kubwerera msanga
        // kuchokera cholakwika, cholowa cha njirayi chili pa index 0.

        if let Some(idx) = idx {
            // Mapu atakhala kale posungira, sungani kutsogolo.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Ngati mapu palibe posungira, pangani mapu atsopano, ayikeni kutsogolo kwa cache, ndikuchotsa cholowa chakale kwambiri ngati kuli kofunikira.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // osatayitsa moyo wa `'static`, onetsetsani kuti awonongedwa tokha
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Onjezani nthawi ya `sym` mpaka `'static` popeza mwatsoka timafunikira pano, koma zikuyenera kutchulidwa ngati chofotokozera kotero kuti sizingafanane ndi chimango chilichonse.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Pomaliza, pezani mapu osungidwa kapena pangani mapu atsopano a fayilo iyi, ndikuwunika zambiri za DWARF kuti mupeze file/line/name ya adilesi iyi.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Tidatha kupeza zambiri za chimango cha chizindikirochi, ndipo chimango cha `addr2line 'mkati chili ndi tsatanetsatane waukatswiri.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Sitinapeze chidziwitso chokhudzidwa, koma tidachipeza pagome lazoyimira la elf omwe angathe kuchitidwa.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}