use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Sanjani adilesi ku chizindikiro, ndikudutsa chizindikirocho potseka.
///
/// Ntchitoyi idzawona ma adilesi omwe apatsidwa m'malo monga tebulo lazizindikiro, tebulo lamphamvu, kapena chidziwitso cha DWARF (malinga ndi kuyambitsa kwake) kuti mupeze zizindikilo zomwe mungapereke.
///
///
/// Kutseka sikungatchulidwe ngati chisankho sichingachitike, ndipo chitha kutchulidwanso kangapo ngati zingachitike.
///
/// Zizindikiro zomwe zimaperekedwa zimayimira kuphedwa kwa `addr`, ndikubweza ma file/line awiriawiri pa adilesiyi (ngati alipo).
///
/// Dziwani kuti ngati muli ndi `Frame` ndiye kuti tikulimbikitsidwa kuti mugwiritse ntchito `resolve_frame` m'malo mwa iyi.
///
/// # Zofunikira
///
/// Ntchitoyi imafuna kuti mbali ya `std` ya `backtrace` crate ikhale yolumikizidwa, ndipo mawonekedwe a `std` amathandizidwa mwachisawawa.
///
/// # Panics
///
/// Ntchitoyi imayesetsa kuti isakhale panic, koma ngati `cb` idapereka panics ndiye kuti nsanja zina zimakakamiza panic kuti ichotse ntchitoyi.
/// Mapulatifomu ena amagwiritsa ntchito laibulale ya C yomwe mkati mwake imagwiritsa ntchito zovuta zomwe sizingadutsike, chifukwa chake mantha kuchokera ku `cb` atha kuyambitsa njira yochotsera.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // yang'anani pa chimango chapamwamba
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Konzani chimango chojambulidwa kale kukhala chizindikiritso, ndikudutsa chizindikirocho potseka.
///
/// Functin imagwira ntchito yofanana ndi `resolve` kupatula kuti imatenga `Frame` ngati mkangano m'malo mwa adilesi.
/// Izi zitha kuloleza kukhazikitsidwa kwina kwa nsanja kuti zizipereka chidziwitso chazizindikiro kapena zidziwitso za mafelemu okhala pakati.
///
/// Ndibwino kuti mugwiritse ntchito izi ngati mungathe.
///
/// # Zofunikira
///
/// Ntchitoyi imafuna kuti mbali ya `std` ya `backtrace` crate ikhale yolumikizidwa, ndipo mawonekedwe a `std` amathandizidwa mwachisawawa.
///
/// # Panics
///
/// Ntchitoyi imayesetsa kuti isakhale panic, koma ngati `cb` idapereka panics ndiye kuti nsanja zina zimakakamiza panic kuti ichotse ntchitoyi.
/// Mapulatifomu ena amagwiritsa ntchito laibulale ya C yomwe mkati mwake imagwiritsa ntchito zovuta zomwe sizingadutsike, chifukwa chake mantha kuchokera ku `cb` atha kuyambitsa njira yochotsera.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // yang'anani pa chimango chapamwamba
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Makhalidwe a IP kuchokera pamafelemu amtunduwu amakhala (always?) malangizo *pambuyo* pakuyimbira komwe kumafunikira.
// Kuzindikiritsa izi kumapangitsa kuti nambala ya filename/line ikhale imodzi patsogolo ndipo mwina ikhale yopanda kanthu ngati ili kumapeto kwa ntchitoyi.
//
// Izi zikuwoneka kuti nthawi zonse zimakhala choncho pamapulatifomu onse, chifukwa chake nthawi zonse timachotsa imodzi kuchokera ku ip yothetsera vutoli kuti ithetsere kulangizidwa kwam'mbuyomu m'malo mwakuphunzitsidwako.
//
//
// Mwabwino sitingachite izi.
// Mwachidziwikire tingafune oitanitsa ma `resolve` APIs pano kuti apange -1 pamanja ndikuwerengera kuti akufuna chidziwitso cha komwe angapeze malangizo am'mbuyomu, osati apano.
// Mwinanso titha kuwululira pa `Frame` ngati tiliadi adilesi yotsatira kapena yapano.
//
// Pakadali pano ngakhale ili vuto lokongola kotero kuti mkati mwathu nthawi zonse timachotsa chimodzi.
// Ogula akuyenera kupitiliza kugwira ntchito ndikupeza zotsatira zabwino, chifukwa chake tiyenera kukhala okwanira.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Zofanana ndi `resolve`, ndizotetezeka kokha chifukwa sizolumikizidwa.
///
/// Ntchitoyi ilibe mawonekedwe olumikizirana koma imapezeka ngati gawo la `std` la crate silinapangidwe.
/// Onani ntchito ya `resolve` kuti mumve zambiri ndi zitsanzo.
///
/// # Panics
///
/// Onani zambiri pa `resolve` pazodzitchinjiriza pa `cb` kuchita mantha.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Zofanana ndi `resolve_frame`, ndizotetezeka kokha chifukwa sizolumikizidwa.
///
/// Ntchitoyi ilibe mawonekedwe olumikizirana koma imapezeka ngati gawo la `std` la crate silinapangidwe.
/// Onani ntchito ya `resolve_frame` kuti mumve zambiri ndi zitsanzo.
///
/// # Panics
///
/// Onani zambiri pa `resolve_frame` pazodzitchinjiriza pa `cb` kuchita mantha.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait yoyimira kusanja kwa chizindikiro mu fayilo.
///
/// trait iyi imaperekedwa ngati chinthu cha trait potseka kutsegulidwa kwa ntchito ya `backtrace::resolve`, ndipo imatumizidwa pafupifupi monga sizikudziwika kuti kukhazikitsidwa kwake kuli kumbuyo kwake.
///
///
/// Chizindikiro chimatha kupereka chidziwitso pamagwiritsidwe ntchito, mwachitsanzo dzina, dzina la fayilo, nambala ya mzere, adilesi yeniyeni, ndi zina zambiri.
/// Sizinthu zonse zomwe zimapezeka nthawi zonse ngati chizindikiro, komabe, njira zonse zimabwezeretsa `Option`.
///
///
pub struct Symbol {
    // TODO: zomangika pamoyo uno zimayenera kupitilizidwa mpaka `Symbol`,
    // koma uku ndikusintha kwakanthawi.
    // Pakadali pano izi ndizotetezeka popeza `Symbol` imangoperekedwapo mwa kutchulidwa ndipo siyingapangidwe.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Akufotokozera dzina la ntchitoyi.
    ///
    /// Kapangidwe kobwezeretsedwako kangagwiritsidwe ntchito kufunsa zinthu zosiyanasiyana za dzina lophiphiritsa:
    ///
    ///
    /// * Kukhazikitsa kwa `Display` kudzasindikiza chizindikiro chodulidwa.
    /// * Mtengo wa `str` wosaphika wa chizindikirocho ungapezeke (ngati ndiwothandiza utf-8).
    /// * Ma byte akuda a dzina lachizindikiro amatha kupezeka.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Ikubwezeretsa adilesi yoyambira ntchitoyi.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Akufotokozera yaiwisi filename to monga kagawo.
    /// Izi ndizothandiza makamaka m'malo a `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Ikubwezeretsanso nambala yamakalata komwe chizindikirochi chikuchitikira pano.
    ///
    /// Ndi ma gimli okha omwe pano amapereka phindu pano komanso pamenepo pokhapokha `filename` ikabweza `Some`, chifukwa chake pamakhala mapanga ofanana.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Ikubwezeretsani nambala ya mzere komwe chizindikirochi chikuchitikira pano.
    ///
    /// Mtengo wobwezerawu nthawi zambiri umakhala `Some` ngati `filename` imabweza `Some`, ndipo chifukwa chake imakhala ndi mapanga ofanana.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Imabwezeretsa dzina la fayilo pomwe ntchitoyi idatanthauzidwa.
    ///
    /// Izi zimapezeka pokhapokha libbacktrace kapena gimli ikugwiritsidwa ntchito (mwachitsanzo
    /// unix nsanja zina) ndipo binary ikalembedwa ndi debuginfo.
    /// Ngati zonsezi sizikwaniritsidwa ndiye kuti izi zibwerera ku `None`.
    ///
    /// # Zofunikira
    ///
    /// Ntchitoyi imafuna kuti mbali ya `std` ya `backtrace` crate ikhale yolumikizidwa, ndipo mawonekedwe a `std` amathandizidwa mwachisawawa.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Mwina chizindikiritso cha C++ , ngati kufotokozera chizindikirocho ngati Rust kwalephera.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Onetsetsani kuti musunge zero-size, kuti mawonekedwe a `cpp_demangle` asakhale ndi mtengo akalemala.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Chozunguliza mozungulira dzina lachizindikiro kuti apatse olowa nawo ma ergonomic ku dzina lomwe lachotsedwa, mabayipi osaphika, chingwe chosaphika, ndi zina zambiri.
///
// Lolani nambala yakufa pomwe mawonekedwe a `cpp_demangle` satha.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Pangani dzina latsopano lachizindikiro kuchokera kuzinyalala zoyambira.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Imabwezeretsa dzina loyimira la (mangled) ngati `str` ngati chizindikirocho ndi chovomerezeka utf-8.
    ///
    /// Gwiritsani ntchito kukhazikitsa kwa `Display` ngati mukufuna mtundu womwe udasinthidwa.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Imabwezeretsa dzina loyimira monga mndandanda wa mabayiti
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Izi zitha kusindikizidwa ngati chizindikirocho sichiri chovomerezeka, choncho gwirani zolakwika apa mwabwino osazifalitsa panja.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Yesetsani kubwezera chikumbutso chosungidwa chomwe chimagwiritsa ntchito kufanizira ma adilesi.
///
/// Njirayi iyesera kutulutsa zida zilizonse zapadziko lonse lapansi zomwe sizinalembedwe padziko lonse lapansi kapena mu ulusi womwe umayimira zambiri za DWARF kapena zina.
///
///
/// # Caveats
///
/// Ngakhale kuti ntchitoyi imapezeka nthawi zonse sichichita chilichonse pakukwaniritsa zambiri.
/// Malaibulale monga dbghelp kapena libbacktrace sapereka malo ogwiritsira ntchito boma ndikuwongolera zomwe azikumbukira.
/// Pakadali pano gawo la `gimli-symbolize` la crate ndilo gawo lokhalo pomwe ntchitoyi ingakhudze chilichonse.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}