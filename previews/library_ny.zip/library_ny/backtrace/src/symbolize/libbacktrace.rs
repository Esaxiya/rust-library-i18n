//! Njira yophiphiritsira pogwiritsa ntchito nambala yolemba DWARF mu libbacktrace.
//!
//! Laibulale ya libbacktrace C, yomwe imagawidwa ndi gcc, imathandizira sikuti imangopanga kumbuyo (komwe sitigwiritsa ntchito) komanso kufanizira zakumbuyo ndikusamalira zazambiri zazamawu pazinthu monga mafelemu okhazikika ndi chiyani.
//!
//!
//! Izi ndizovuta chifukwa cha zovuta zingapo pano, koma lingaliro lofunikira ndi:
//!
//! * Choyamba timatcha `backtrace_syminfo`.Izi zimalandira chidziwitso cha chizindikiro kuchokera patebulo lamphamvu ngati tingathe.
//! * Kenako timatcha `backtrace_pcinfo`.Izi ziwonetsa matebulo a debuginfo ngati alipo ndikutilola kuti tidziwe zambiri za mafelemu okhala pakati, mayina amawu, manambala amizere, ndi zina zambiri.
//!
//! Pali zachinyengo zambiri pobweretsa matebulo ang'onoang'ono mu libbacktrace, koma ndikukhulupirira kuti siwo malekezero adziko lapansi ndipo ndizomveka bwino mukawerenga pansipa.
//!
//! Awa ndi njira yophiphiritsira yopanga ma nsanja omwe si a MSVC komanso omwe si a OSX.Mu libstd ngakhale iyi ndiye njira yosasinthika ya OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Ngati kuli kotheka sankhani dzina la `function` lomwe limachokera ku debuginfo ndipo limatha kukhala lolondola pamafelemu olowera mwachitsanzo.
                // Ngati izi sizikupezeka ngakhale mutabwerera ku dzina la tebulo lazizindikiro lotchulidwa mu `symname`.
                //
                // Dziwani kuti nthawi zina `function` imatha kumverera ngati yolondola pang'ono, mwachitsanzo kukhala m'ndandanda wa `try<i32,closure>` m'malo mwa `std::panicking::try::do_call`.
                //
                // Sizikudziwika bwinobwino chifukwa chake, koma kwathunthu dzina la `function` limawoneka lolondola kwambiri.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // musachite chilichonse pakadali pano
}

/// Mtundu wa pointer wa `data` udadutsa `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Kuyimbaku kumayitanidwanso kuchokera ku `backtrace_syminfo` tikayamba kuthana ndi mavuto timapitiliza kuyimbira `backtrace_pcinfo`.
    // Ntchito ya `backtrace_pcinfo` idzagwiritsa ntchito njira zowunikira ndikuyesa kuchita zinthu monga kupezanso zambiri za file/line komanso mafelemu okhazikika.
    // Zindikirani ngakhale kuti `backtrace_pcinfo` itha kulephera kapena kuchita zambiri ngati palibe chidziwitso chotsutsana, chifukwa ngati izi zichitika tikutsimikiza kuyimbanso ndi chizindikiro chimodzi kuchokera ku `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Mtundu wa pointer wa `data` udadutsa `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Libbacktrace API imathandizira kupanga boma, koma siligwirizana ndi kuwononga boma.
// Ineyo pandekha ndimaona kuti izi zikutanthauza kuti boma liyenera kulengedwa ndikukhala ndi moyo kosatha.
//
// Ndingakonde kulembetsa wothandizira at_exit() yemwe amayeretsa dziko lino, koma libbacktrace silingapereke njira yochitira izi.
//
// Ndizovuta izi, ntchitoyi ili ndi malo osungidwa omwe amawerengedwa koyamba izi zikufunsidwa.
//
// Kumbukirani kuti kubwerera kumbuyo zonse kumachitika motsatana (loko limodzi padziko lonse).
//
// Tawonani kusowa kwa kalumikizidwe apa chifukwa chofunikira kuti `resolve` imagwirizanitsidwa kunja.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Musagwiritse ntchito ulusi wamtundu wa libbacktrace popeza nthawi zonse timazitcha mwanjira yolumikizirana.
        //
        0,
        error_cb,
        ptr::null_mut(), // palibe deta yowonjezera
    );

    return STATE;

    // Dziwani kuti kuti libbacktrace igwire ntchito zonse amafunika kupeza chidziwitso cha DWARF chazomwe zingachitike.Zimachita izi kudzera munjira zingapo kuphatikiza, koma osangokhala:
    //
    // * /proc/self/exe papulatifomu yothandizidwa
    // * Dzinalo limadutsa momveka bwino popanga boma
    //
    // Laibulale ya libbacktrace ndi mtundu waukulu wa C code.Izi mwachilengedwe zimatanthauza kuti imakhala ndi zovuta zoteteza kukumbukira, makamaka mukamagwiritsa ntchito zolakwika za debuginfo.
    // Libstd adakumana ndi zambiri mwambiri izi.
    //
    // Ngati /proc/self/exe imagwiritsidwa ntchito ndiye kuti titha kunyalanyaza izi poganiza kuti libbacktrace ndi "mostly correct" ndipo mwina sichichita zinthu zachilendo ndi "attempted to be correct" zazidziwitso zosokoneza bongo.
    //
    //
    // Ngati tingodutsa dzina la fayilo, komabe, ndizotheka pamapulatifomu ena (monga ma BSD) pomwe wochita zoyipa amatha kupangitsa kuti fayilo yokhayokha iyikidwe pamalopo.
    // Izi zikutanthauza kuti ngati tiuza libbacktrace za dzina lafayilo litha kukhala kuti likugwiritsa ntchito fayilo yotsutsana, mwina yoyambitsa magawano.
    // Ngati sitiuza libbacktrace chilichonse ndiye kuti sichichita chilichonse papulatifomu zomwe sizigwirizana ndi /proc/self/exe!
    //
    // Popeza zonse zomwe timayesetsa molimbika kuti * tisadutse mu fayilo, koma tiyenera pamapulatifomu omwe sagwirizana ndi /proc/self/exe konse.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Dziwani kuti tikadagwiritsa ntchito `std::env::current_exe`, koma sitingafune `std` apa.
            //
            // Gwiritsani ntchito `_NSGetExecutablePath` kuti mukweze njira yomwe ingachitike pakadali pano (yomwe ngati ndi yaying'ono ingosiya).
            //
            //
            // Dziwani kuti tikukhulupirira kwambiri libbacktrace pano kuti tisafe pazoyipa, koma zimatero ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ili ndi njira yotsegulira mafayilo pomwe ikatsegulidwa silingathe kuchotsedwa.
            // Izi ndizomwe tikufuna pano chifukwa tikufuna kuwonetsetsa kuti owongolera athu sangasinthe kuchokera pansi pathu tikapereka ku libbacktrace, ndikuyembekeza kuti kuthana ndi chidziwitso cholozera mu libbacktrace (yomwe itha kusokonezedwa).
            //
            //
            // Popeza kuti timavina pang'ono pano kuti tipeze loko pazithunzi zathu:
            //
            // * Pezani chogwiritsira ntchito pakadali pano, tsegulani dzina lake.
            // * Tsegulani fayilo ku dzinalo ndi mbendera yoyenera.
            // * Tsegulaninso dzina la fayilo lamakono, onetsetsani kuti ndilofanana
            //
            // Ngati zonsezi zitipitilira, tatsegulira fayilo yathu ndipo tatsimikizika kuti sizisintha.FWIW gulu la izi lidalembedwa kuchokera ku libstd mbiriyakale, chifukwa chake uku ndikumasulira kwanga kwabwino kwa zomwe zimachitika.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Izi zimakhala mumakumbukidwe olimba kuti titha kuzibwezera ..
                static mut BUF: [i8; N] = [0; N];
                // ... ndipo izi zimakhala mulu chifukwa ndizosakhalitsa
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // dontho mwadala `handle` apa chifukwa kutseguka koteroko kuyenera kuteteza loko yathu pa dzina la fayilo.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Tikufuna kubwezera chidutswa chomwe chathetsedwa, kotero ngati chilichonse chidadzazidwa ndipo chikufanana ndi kutalika kwake ndiye kuti kulephera.
                //
                //
                // Kupanda kutero mukamabwerera bwino onetsetsani kuti nul byte ili nawo pagawo.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // Zolakwitsa zakumbuyo zakasesedwa pansi pa rug
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Itanani `backtrace_syminfo` API yomwe (kuchokera powerenga nambala) iyenera kuyitanitsa `syminfo_cb` ndendende kamodzi (kapena kulephera ndi cholakwika mwina).
    // Timagwira zambiri mkati mwa `syminfo_cb`.
    //
    // Dziwani kuti timachita izi popeza `syminfo` idzagwiritsa ntchito gome lazizindikiro, ndikupeza mayina azizindikiro ngakhale mutakhala kuti mulibe zolakwika mu binary.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}