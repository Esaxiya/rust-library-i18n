// amagwiritsidwa ntchito pa Linux pakadali pano, chifukwa chake lolani ma code akufa kwina
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Malo ogulitsira mabwalo osavuta a ma tayipa.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Kugawa gawo lotetezera kukula kwake ndikubwezeretsanso zomwe zingasinthidwe.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // CHITETEZO: iyi ndiyo ntchito yokhayo yomwe imatha kusintha
        // ponena za `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // CHITETEZO: sitimachotsa zinthu ku `self.buffers`, ndiye kuti tanena
        // ku chidziwitso mkati mwa chosungira chilichonse chimakhala ndi moyo ngati `self`.
        &mut buffers[i]
    }
}