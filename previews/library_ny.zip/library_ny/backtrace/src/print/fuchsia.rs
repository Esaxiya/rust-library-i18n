use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr imatenga foni yomwe ingalandire dl_phdr_info pointer ya DSO iliyonse yomwe yakhala ikugwirizanitsidwa ndi njirayi.
    // dl_iterate_phdr imatsimikiziranso kuti cholumikizira champhamvu chimatsekedwa kuyambira koyambirira mpaka kumapeto kwa kuyeserera.
    // Ngati kubwerera kumabwezeretsanso mtengo wosakhala wa zero kukweza kumathetsedwa koyambirira.
    // 'data' idzaperekedwa ngati mkangano wachitatu pakubwezeretsanso pafoni iliyonse.
    // 'size' amapereka kukula kwa dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Tiyenera kufotokozera ID yomanga ndi zina zofunika pamutu wamapulogalamu zomwe zikutanthauza kuti timafunikira zinthu kuchokera ku ELF spec.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Tsopano tiyenera kubwereza, pang'ono pang'ono, kapangidwe ka mtundu wa dl_phdr_info wogwiritsidwa ntchito ndi cholumikizira champhamvu cha fuchsia.
// Chromium ilinso ndi malire awa a ABI komanso crashpad.
// Mwachiwonekere tikufuna kusunthira milanduyi kuti igwiritse ntchito kusaka kwa elf koma tiyenera kupereka izi mu SDK ndipo sizinachitike.
//
// Chifukwa chake ife (ndipo) tikukakamira kugwiritsa ntchito njirayi yomwe imalumikizana ndi fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Tilibe njira yodziwira ngati e_phoff ndi e_phnum ndizovomerezeka.
    // libc iyenera kutsimikizira izi kwa ife komabe zili bwino kupanga kagawo apa.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr imayimira mutu wa pulogalamu ya EL-64-bit kumapeto kwa zomangamanga.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr ikuyimira mutu wovomerezeka wa ELF ndi zomwe zili mkatimo.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Tilibe njira yowunika ngati p_addr kapena p_memsz ndizovomerezeka.
    // Libc ya Fuchsia imalemba zolemba zawozo komabe chifukwa chokhala pano mitu iyi iyenera kukhala yolondola.
    //
    // NoteIter safuna kuti zomwe zikuyikidwazo zikhale zovomerezeka koma zimafuna kuti malire akhale ovomerezeka.
    // Tikukhulupirira kuti libc yawonetsetsa kuti ndi choncho kwa ife pano.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Mtundu wolemba wa ma ID.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr imayimira mutu wa ELF kumapeto kwa chandamale.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Chidziwitso chikuyimira mawu a ELF (mutu + wamkati).
// Dzinalo latsala ngati kagawo ka u8 chifukwa sikumachotsedwa nthawi zonse ndipo rust imapangitsa kuti zikhale zosavuta kuti muwone ngati mabayiti amafanana.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter imakulolani kuti muziyenda bwino pagulu lazolemba.
// Amathera pakangochitika vuto kapena sipadzakhalanso zolembedwa.
// Ngati mungayang'anire pazosavomerezeka zitha kugwira ntchito ngati kuti palibe zolemba zomwe zapezeka.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Ndi ntchito yosasinthika yomwe cholozera ndi kukula kwake zomwe zapatsidwa zimatanthawuza mabetti angapo omwe amatha kuwerengedwa.
    // Zomwe zili m'mabayizi zitha kukhala zilizonse koma mawonekedwewo ayenera kukhala ovomerezeka kuti izi zikhale zotetezeka.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to aligns 'x' to 'to'-byte alignment poganiza kuti 'to' ndi mphamvu ya 2.
// Izi zikutsatira ndondomeko yoyenera mu C/C ++ ELF yofotokozera kumene (x + to, 1)&-to imagwiritsidwa ntchito.
// Rust sikukulolani kuti mugwiritse ntchito magwiritsidwe ntchito kotero ndimagwiritsa ntchito
// 2's-complement kutembenuka kuti mubwererenso izi.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 imagwiritsa ntchito ma num byte kuchokera pagawo (ngati lilipo) ndikuwonetsetsa kuti chidutswa chomaliza chikugwirizana moyenera.
// Ngati nambala yamatayipi yomwe yapemphedwa ndi yayikulu kwambiri kapena kagawo sikangasinthidwe pambuyo pake chifukwa chosakwanira mabayiti omwe alipo, Palibe amene amabwezedwa ndipo chidutswacho sichinasinthidwe.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Ntchitoyi ilibe olowa m'malo omwe woyimbayo ayenera kutsatira kupatula kuti 'bytes' iyenera kugwirizanitsidwa ndi magwiridwe antchito (komanso pazolondola zina).
// Makhalidwe omwe amapezeka m'minda ya Elf_Nhdr atha kukhala opanda pake koma izi sizikutsimikizira izi.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Izi ndizotetezedwa malinga ngati pali malo okwanira ndipo tangotsimikizira kuti m'mawu ali pamwambawa izi siziyenera kukhala zosatetezeka.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Dziwani kuti sice_of: :<Elf_Nhdr>() nthawi zonse imayendetsedwa ndi 4-byte.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Onani ngati tafika kumapeto.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Timatumiza nhdr koma timaganizira mosamala zotsatira zake.
        // Sitikukhulupirira namesz kapena descsz ndipo sitipanga zisankho zopanda chitetezo kutengera mtundu.
        //
        // Chifukwa chake ngakhale titatulutsa zinyalala zathu tiyenera kukhalabe otetezeka.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Ikuwonetsa kuti gawo limakwaniritsidwa.
const PERM_X: u32 = 0b00000001;
/// Ikuwonetsa kuti gawo limalembedwa.
const PERM_W: u32 = 0b00000010;
/// Zimasonyeza kuti gawo ndi lowerengeka.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Imayimira gawo la ELF panthawi yothamanga.
struct Segment {
    /// Amapereka adilesi yanthawi yothana ndi zomwe zili mgululi.
    addr: usize,
    /// Amapereka kukula kwakumbukiridwe kazomwe zili mgululi.
    size: usize,
    /// Amapereka gawo la adilesiyi ndi fayilo ya ELF.
    mod_rel_addr: usize,
    /// Amapereka zilolezo zopezeka mu fayilo ya ELF.
    /// Zilolezo izi sizomwe zili zilolezo zomwe zimakhalapo nthawi yothamanga komabe.
    flags: Perm,
}

/// Lolani kuti pakhale gawo limodzi kuchokera ku DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Imayimira ELF DSO (Dynamic Shared Object).
/// Mtundu uwu umafotokoza zomwe zasungidwa mu DSO yeniyeni m'malo mongopanga zake zokha.
struct Dso<'a> {
    /// Wolumikizira wamphamvu nthawi zonse amatipatsa dzina, ngakhale dzinalo lilibe kanthu.
    /// Pankhani ya oyendetsa bwino dzinali likhala lopanda kanthu.
    /// Pankhani ya chinthu chogawana idzakhala soname (onani DT_SONAME).
    name: &'a str,
    /// Ku Fuchsia pafupifupi mabinaries onse ali ndi ma ID koma ichi sichofunikira kwenikweni.
    /// Palibe njira yofananitsira chidziwitso cha DSO ndi fayilo yeniyeni ya ELF pambuyo pake ngati palibe build_id kotero tikufuna kuti DSO iliyonse ikhale nayo pano.
    ///
    /// Ma DSO opanda build_id amanyalanyazidwa.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Imabweza iterator pazigawo mu DSO iyi.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Zolakwitsa izi zimakhazikitsa zovuta zomwe zimadza pofotokoza zambiri za DSO iliyonse.
///
enum Error {
    /// NameError zikutanthauza kuti vuto lidachitika posintha chingwe cha C kukhala chingwe cha rust.
    ///
    NameError(core::str::Utf8Error),
    /// Zomangamanga zimatanthauza kuti sitinapeze chiphaso.
    /// Izi mwina ndi chifukwa DSO idalibe ID yomanga kapena chifukwa gawo lomwe lili ndi ID yomanga silinachite bwino.
    ///
    BuildIDError,
}

/// Imayimbira 'dso' kapena 'error' pa DSO iliyonse yolumikizidwa ndi cholumikizira champhamvu.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter yomwe itha kukhala ndi imodzi mwa njira zodyera zotchedwa foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr imatsimikizira kuti info.name idzaloza malo ovomerezeka.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Ntchitoyi imasindikiza chizindikiro cha Fuchsia chazidziwitso zonse zomwe zili mu DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}