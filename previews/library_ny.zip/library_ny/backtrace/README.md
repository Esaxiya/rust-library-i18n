# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Laibulale yopezera zakumbuyo panthawi yothamanga ya Rust.
Laibulaleyi ikufuna kukulitsa kuthandizira kwa laibulale yanthawi zonse powapatsa mawonekedwe omwe angagwire nawo ntchito, koma imathandizanso posindikiza kumbuyo komwe kuli ngati libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Kuti mungotenga zakumbuyo ndikuchedwetsani kuthana nazo mpaka nthawi ina, mutha kugwiritsa ntchito mtundu wapamwamba wa `Backtrace`.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Ngati, komabe, mungafune mwayi wambiri wofufuzira, mutha kugwiritsa ntchito `trace` ndi `resolve` mwachindunji.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Sankhani cholozera ichi ku dzina lophiphiritsa
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // pitirizani kupita ku chimango chotsatira
    });
}
```

# License

Ntchitoyi ili ndi chilolezo pansi pa iliyonse ya

 * Chilolezo cha Apache, Version 2.0, ([LICENSE-APACHE](LICENSE-APACHE) kapena http://www.apache.org/licenses/LICENSE-2.0)
 * Chilolezo cha MIT ([LICENSE-MIT](LICENSE-MIT) kapena http://opensource.org/licenses/MIT)

momwe mungasankhire.

### Contribution

Pokhapokha mutanena mwanjira ina, zopereka zilizonse zomwe mungapereke mwadala kuti muphatikizidwe mmbuyo-rs ndi inu, monga momwe zilili mu layisensi ya Apache-2.0, zikhala ndi ziphaso ziwiri monga pamwambapa, popanda zina zowonjezera.







