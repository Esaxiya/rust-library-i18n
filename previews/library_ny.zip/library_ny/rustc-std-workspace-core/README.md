# `rustc-std-workspace-core` crate

crate iyi ndi yopanda kanthu komanso yopanda kanthu crate yomwe imangodalira `libcore` ndikubwezeretsanso zonse zomwe zili mkatimo.
crate ndiye crux yopatsa mphamvu laibulale yokhazikika kuti izidalira crates kuchokera ku crates.io

Crates pa crates.io kuti laibulale yovomerezeka imadalira zosowa zake zimadalira `rustc-std-workspace-core` crate kuchokera ku crates.io, yomwe ilibe kanthu.

Timagwiritsa ntchito `[patch]` kupitilira ku crate iyi.
Zotsatira zake, crates pa crates.io ajambulira kudalira edge mpaka `libcore`, mtundu womwe wafotokozedwera posungira izi.
Izi zikuyenera kuyika magawo onse odalira kuti Cargo imange crates bwino!

Dziwani kuti crates pa crates.io iyenera kudalira crate iyi yotchedwa `core` kuti chilichonse chizigwira bwino ntchito.Kuti achite zomwe angagwiritse ntchito:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Pogwiritsa ntchito kiyi ya `package` crate imasinthidwa kukhala `core`, kutanthauza kuti idzawoneka

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

Cargo ikapempha wopangirayo, kukhutiritsa malangizo a `extern crate core` omwe adayikidwa ndi wopangirayo.




