#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// Onani [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_READ: i32 = 0;

/// Onani [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_WRITE: i32 = 1;

/// Onani [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// Onani [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// Onani [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// Onani [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// Tengani mzere wosungira womwe uli ndi adilesi `p` pogwiritsa ntchito `rw` ndi `locality`.
///
/// `rw` iyenera kukhala imodzi mwa:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): prefetch ikukonzekera kuwerenga.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): prefetch ikukonzekera kulemba.
///
/// `locality` iyenera kukhala imodzi mwa:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): Kutsatsira kapena kusanachitike kwakanthawi, kwa deta yomwe imagwiritsidwa ntchito kamodzi kokha.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): Tengerani posungira msinkhu wachitatu.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): Tengani mu cache yachiwiri.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): Tengani mu cache yoyamba.
///
/// Malangizo amakumbukidwe am'mbuyomu ku chikumbukiro chomwe kukumbukira kukumbukira kuchokera ku adilesi yomwe yatchulidwa kumatha kuchitika pafupi ndi future.
/// Makina okumbukira amatha kuyankha mwa kuchitapo kanthu zomwe zikuyembekezeka kufulumizitsa mwayi wokumbukira zikadzachitika, monga kukhazikitsanso adilesi yomwe idatchulidwayo kosungira kamodzi kapena zingapo.
///
/// Chifukwa ma siginolo ndi malingaliro chabe, ndizovomerezeka kwa CPU inayake kuti itenge chilichonse kapena malangizo onse monga NOP.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // Timagwiritsa ntchito `llvm.prefetch` instrinsic ndi `cache type` =1 (data cache).
    // `rw` ndipo `strategy` zimakhazikitsidwa potengera magwiridwe antchito.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}