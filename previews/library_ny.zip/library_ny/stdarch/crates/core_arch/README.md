`core::arch` - Rust zamkati mwazomangamanga zomangamanga
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Gawo la `core::arch` limagwiritsa ntchito zida zodalira zomangamanga (mwachitsanzo SIMD).

# Usage 

`core::arch` ikupezeka ngati gawo la `libcore` ndipo imatumizidwanso ndi `libstd`.Sankhani kugwiritsa ntchito `core::arch` kapena `std::arch` kuposa kudzera pa crate.
Zinthu zosakhazikika nthawi zambiri zimapezeka mu Rust usiku uliwonse kudzera pa `feature(stdsimd)`.

Kugwiritsa ntchito `core::arch` kudzera pa crate kumafuna Rust usiku uliwonse, ndipo imatha (ndipo imachita) kuswa pafupipafupi.Milandu yokha yomwe muyenera kuganizira kugwiritsa ntchito crate ndi iyi:

* ngati mukufuna kudzipezanso `core::arch` nokha, mwachitsanzo, ndizowunikira zomwe zololedwa zomwe sizimathandizidwa ndi `libcore`/`libstd`.
Note: ngati mukufuna kuyikonzanso kuti ikhale yopanda malire, chonde sankhani `xargo` ndikulembanso `libcore`/`libstd` koyenera m'malo mogwiritsa ntchito crate.
  
* kugwiritsa ntchito zina zomwe mwina sizingakhalepo ngakhale kuseli kwa zinthu zosakhazikika za Rust.Timayesetsa kuchepetsa izi.
Ngati mukufuna kugwiritsa ntchito zina mwazinthuzi, chonde tsegulani nkhani kuti titha kuziwonetsa usiku uliwonse Rust ndipo mutha kuzigwiritsa ntchito kuchokera pamenepo.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` imagawidwa makamaka malinga ndi chilolezo cha MIT ndi Apache License (Version 2.0), ndi magawo omwe amakhala ndi ziphaso ngati za BSD.

Onani LICENSE-APACHE, ndi LICENSE-MIT kuti mumve zambiri.

# Contribution

Pokhapokha mutanena mwanjira ina, zopereka zilizonse zomwe mungapereke mwadala kuti muphatikizire `core_arch` ndi inu, monga momwe zilili mu layisensi ya Apache-2.0, zikhala ndi ziphaso ziwiri monga pamwambapa, popanda zina zowonjezera.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












