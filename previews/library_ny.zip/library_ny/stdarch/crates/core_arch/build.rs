use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Tinkakonda kunena matanthauzidwe athu a `#[assert_instr]` kuti ma simd intrinsics onse amapezeka kuti ayese codegen yawo, popeza ena ali ndi zipata kumbuyo kwa `-Ctarget-feature=+unimplemented-simd128` yowonjezera yomwe ilibe zofanana mu `#[target_feature]` pompano.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}