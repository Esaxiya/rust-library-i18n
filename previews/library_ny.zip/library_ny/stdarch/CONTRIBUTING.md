# Kupititsa ku stdarch

`stdarch` crate ndi wofunitsitsa kulandira zopereka!Choyamba mungafune kuyang'ana posungira ndikuwonetsetsa kuti mayesero akudutsani:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Komwe `<your-target-arch>` ndi chandamale katatu monga imagwiritsidwa ntchito ndi `rustup`, mwachitsanzo `x86_x64-unknown-linux-gnu` (popanda `nightly-` yapitayi kapena yofananira).
Komanso kumbukirani kuti chosungira ichi chimafuna njira ya usiku ya Rust!
Mayesero omwe ali pamwambapa amafunikira kuti rust usiku uliwonse ikhale yopanda dongosolo, kuti mugwiritse ntchito `rustup default nightly` (ndi `rustup default stable` kuti mubwererenso).

Ngati izi sizikugwira ntchito, [please let us know][new]!

Pambuyo pake mutha [find an issue][issues] kuti muthandizirepo, tasankha ochepa okhala ndi ma [`help wanted`][help] ndi [`impl-period`][impl] omwe atha kugwiritsa ntchito kwambiri thandizo. 
Mutha kukhala ndi chidwi kwambiri ndi [#40][vendor], ndikukhazikitsa zonse zogulitsa pa x86.Magaziniyi ili ndi zokuthandizani kudziwa komwe mungayambire!

Ngati muli ndi mafunso wamba muzimasuka ku [join us on gitter][gitter] ndikufunsani mozungulira!Khalani omasuka kuyika@BurntSushi kapena@alexcrichton ndi mafunso.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Momwe mungalembere zitsanzo za stdarch intrinsics

Pali zinthu zingapo zomwe ziyenera kuthandizidwa kuti zomwe zapatsidwa kuti zizigwira bwino ntchito ndipo chitsanzocho chiyenera kuyendetsedwa ndi `cargo test --doc` pokhapokha mbaliyo ikathandizidwa ndi CPU.

Zotsatira zake, `fn main` yosasinthika yomwe imapangidwa ndi `rustdoc` sigwira ntchito (nthawi zambiri).
Ganizirani kugwiritsa ntchito zotsatirazi ngati chitsogozo kuti muwonetsetse kuti zitsanzo zanu zikugwira ntchito monga mukuyembekezera.

```rust
/// # // Tiyenera cfg_target_feature kuti tiwonetsetse kuti chitsanzo ndi chokha
/// # // yoyendetsedwa ndi `cargo test --doc` pomwe CPU ikuthandizira mawonekedwe
/// # #![feature(cfg_target_feature)]
/// # // Tikufuna chizindikiro_chithunzi kuti zamkati zizigwira ntchito
/// # #![feature(target_feature)]
/// #
/// # // rustdoc mwachisawawa imagwiritsa ntchito `extern crate stdarch`, koma tikufuna
/// # // `#[macro_use]`
/// # # [macro_use] kunja crate wowonjezera;
/// #
/// # // Ntchito yeniyeni yeniyeni
/// # fn main() {
/// #     // Ingothamangitsani izi ngati `<target feature>` ikuthandizidwa
/// #     ngati cfg_feature_enabled! ("<target feature>"){
/// #         // Pangani ntchito ya `worker` yomwe ingoyendetsedwa pokhapokha ngati chandamale
/// #         // imathandizidwa ndikuwonetsetsa kuti `target_feature` imathandizidwa kwa wogwira ntchito
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         zosatetezeka fn worker() {
/// // Lembani chitsanzo chanu apa.Zina mwazinthu zofunikira zidzagwira ntchito apa!Pitani kuthengo!
///
/// #         }
///
/// #         zosatetezeka { worker(); }
/// #     }
/// # }
```

Ngati ena mwa malembedwe pamwambapa sakuwoneka bwino, gawo la [Documentation as tests] la [Rust Book] limafotokoza bwino malembedwe bwino a `rustdoc`.
Monga nthawi zonse, khalani omasuka ku [join us on gitter][gitter] ndipo mutifunse ngati mungapeze zovuta zilizonse, ndikukuthokozani chifukwa chothandiza kukonza zolemba za `stdarch`!

# Malangizo Oyeserera Osiyanasiyana

Kawirikawiri amalimbikitsidwa kuti mugwiritse ntchito `ci/run.sh` poyesa mayeso.
Komabe izi sizingagwire ntchito kwa inu, mwachitsanzo ngati muli pa Windows.

Zikatero mungathe kubwerera ku `cargo +nightly test` ndi `cargo +nightly test --release -p core_arch` kuti muyese kupanga kachidindo.
Dziwani kuti izi zimafuna kuti chida chamadzulo cha usiku chiyikidwe komanso kuti `rustc` idziwe za chandamale chanu katatu ndi CPU yake.
Makamaka muyenera kukhazikitsa kusintha kwa chilengedwe cha `TARGET` monga momwe mungapangire `ci/run.sh`.
Kuphatikiza apo muyenera kukhazikitsa `RUSTCFLAGS` (muyenera `C`) kuti muwonetse zofunikira, mwachitsanzo `RUSTCFLAGS="-C -target-features=+avx2"`.
Muthanso kukhazikitsa `-C -target-cpu=native` ngati muli "just" motsutsana ndi CPU yanu yapano.

Achenjezedwe kuti mukamagwiritsa ntchito malangizo enawa, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], mwachitsanzo
mayesero opangira malangizo atha kulephera chifukwa disassembler adawatchula mosiyana, mwachitsanzo
itha kupanga `vaesenc` m'malo mwa malangizo a `aesenc` ngakhale amachita chimodzimodzi.
Komanso malangizowa amayesa mayeso ochepa kuposa momwe amachitira, choncho musadabwe kuti mukadzapempha-pempho zolakwika zina zitha kupezeka pamayeso omwe sanatchulidwe pano.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






