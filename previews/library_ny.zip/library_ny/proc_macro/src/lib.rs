//! Laibulale yothandizira olemba ambiri pakufotokozera ma macro atsopano.
//!
//! Laibulale iyi, yoperekedwa ndi magawidwe wamba, imapereka mitundu yomwe imagwiritsidwa ntchito polumikizira matanthauzidwe ofanananso ndi machitidwe monga macro `#[proc_macro]`, zikuluzikulu za `#[proc_macro_attribute]` ndi zomwe zimapangidwa `#[proc_macro_derive]`.
//!
//!
//! Onani [the book] kuti mumve zambiri.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Ikuwona ngati proc_macro yapangidwa kuti izitha kupezeka ndi pulogalamu yomwe ikuchitika pano.
///
/// Proc_macro crate imangogwiritsidwa ntchito pakukhazikitsa ma macros amachitidwe.Ntchito zonse mu crate panic izi ngati zimapangidwa kuchokera kunja kwa njira yayikulu, monga kuchokera kumayendedwe omanga kapena mayesero oyeserera kapena bayinare wamba wa Rust.
///
/// Poganizira za malaibulale a Rust omwe adapangidwa kuti azithandizira milandu yayikulu komanso yosagwiritsa ntchito macro, `proc_macro::is_available()` imapereka njira yopanda mantha kuti muwone ngati zomangamanga zofunika kugwiritsa ntchito API ya proc_macro zilipo.
/// Kubwerera koona ngati kuyitanitsidwa kuchokera mkati mwa njira yayikulu, yabodza ngati kuyitanitsidwa kuchokera kuzinthu zina zilizonse.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Mtundu waukulu woperekedwa ndi crate, woyimira mtsinje wa tokens, kapena, makamaka, mndandanda wa mitengo ya token.
/// Mtunduwo umalowetsa m'malo olumikizirana mitengo ya token ndipo, motsatana, amatola mitengo yambiri ya token mumtsinje umodzi.
///
///
/// Izi ndizowonjezera ndi kutulutsa kwa matanthauzo a `#[proc_macro]`, `#[proc_macro_attribute]` ndi `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Vuto lobwezera kuchokera ku `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Imabwezeretsa `TokenStream` yopanda mitengo ya token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Macheke ngati `TokenStream` iyi ilibe kanthu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Kuyesera kuthyola chingwe kukhala tokens ndikuwonetsa tokens mu mtsinje wa token.
/// Itha kulephera pazifukwa zingapo, mwachitsanzo, ngati chingwecho chili ndi osasintha osasintha kapena zilembo zomwe sizipezeka mchilankhulocho.
///
/// tokens zonse mumtsinje wodutsika zimatenga ma `Span::call_site()`.
///
/// NOTE: Zolakwitsa zina zitha kuyambitsa panics m'malo mobwezera `LexError`.Tili ndi ufulu wosintha zolakwikazo kukhala `LexError`s pambuyo pake.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, mlatho umangopereka `to_string`, tsatirani `fmt::Display` kutengera pamenepo (chosiyana ndi ubale wamba pakati pa awiriwa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Imasindikiza mtsinje wa token ngati chingwe chomwe chimayenera kusandulika mosataya kubwerera mumtsinje womwewo wa token (modulo spans), kupatula mwina `TokenTree: : Group`s yokhala ndi oyendetsa `Delimiter::None` ndi manambala oyipa.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Zosindikiza token mu mawonekedwe osavuta kukonza.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Pangani mtsinje wa token wokhala ndi mtengo umodzi wa token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Amasonkhanitsa mitengo ingapo ya token mumtsinje umodzi.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Ntchito ya "flattening" pamitsinje ya token, imasonkhanitsa mitengo ya token kuchokera mumitsinje ingapo ya token kupita mumtsinje umodzi.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Gwiritsani ntchito kukhazikitsa bwino if/when kotheka.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Zambiri zakukhazikitsa pagulu la mtundu wa `TokenStream`, monga ma iterator.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Wolemba pa `TokenStream 'a` TokenTree`s.
    /// Kuchulukitsa kwake ndi "shallow", mwachitsanzo, iterator siyimabwereranso m'magulu ochepa, ndipo imabwezeretsa magulu onse ngati mitengo ya token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` imavomereza tokens mosasinthasintha ndipo imakulitsa kukhala `TokenStream` yofotokozera zolowedwazo.
/// Mwachitsanzo, `quote!(a + b)` ipanga chiwonetsero, kuti, poyesedwa, apange `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Unquoting yachitika ndi `$`, ndipo imagwira ntchito potenga dzina limodzi lotsatira ngati nthawi yosagwidwa.
/// Kuti mutchule `$` yokha, gwiritsani ntchito `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Dera lokhala ndi magwero, komanso zambiri zowonjezera.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Kupanga `Diagnostic` yatsopano ndi `message` yopatsidwa pa span `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Utali womwe umatha pamasamba ofotokozera zazikulu.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Kutalika kwa kupembedzera kwamachitidwe amakono amakono.
    /// Zizindikiritso zopangidwa ndi nthawi imeneyi zidzathetsedwa ngati kuti zinalembedwa molunjika pamalo oitanira anthu ambiri (malo oyimbirako malo) ndi ma code ena omwe adzafotokozeredwe adzawatchulanso.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Kutalika komwe kumayimira ukhondo wa `macro_rules`, ndipo nthawi zina kumasintha pamasamba ofotokozera zazikulu (zosintha zam'deralo, zolemba, `$crate`) ndipo nthawi zina kumalo ochezera ambiri (china chilichonse).
    ///
    /// Malo otalikirako amachotsedwa pamalo ochezera.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Fayilo yoyambirira yomwe izi zimalozera.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` ya tokens pakukula kwakumbuyo komwe `self` idapangidwa, ngati kulipo.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Kutalika kwa kachidindo koyambira komwe `self` idapangidwira kuchokera.
    /// Ngati `Span` iyi sinapangidwe kuchokera pazowonjezera zina zazikulu ndiye kuti phindu lobwezera ndilofanana ndi `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Ikupeza line/column yoyambira mu fayilo yoyambira nthawi imeneyi.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Imapeza mathero a line/column mu fayilo yoyambira nthawi imeneyi.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Kupanga chikhato chatsopano chophatikiza `self` ndi `other`.
    ///
    /// Kubwezeretsa `None` ngati `self` ndi `other` akuchokera pamafayilo osiyanasiyana.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Zimapanga gawo latsopano lokhala ndi line/column yofanana ndi `self` koma izi zimatsimikiza zizindikilo ngati kuti zinali ku `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Imapanga gawo latsopano lokhala ndi mawonekedwe ofanana ndi `self` koma ndi chidziwitso cha line/column cha `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Kuyerekeza ndikutambasula kuti muwone ngati ali ofanana.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Kubwezeretsa mawu omwe adachokera kuseri kwa chikhato.
    /// Izi zimasunga nambala yoyambira, kuphatikiza mipata ndi ndemanga.
    /// Zimangobweretsanso zotsatira ngati chikhathochi chikugwirizana ndi nambala yeniyeni yeniyeni.
    ///
    /// Note: Zotsatira zowoneka bwino zazikulu zimangodalira tokens osati pazolemba izi.
    ///
    /// Zotsatira za ntchitoyi ndizoyesetsa kwambiri kugwiritsidwa ntchito pongofufuza.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Sindikizani chikwangwani mu mawonekedwe osavuta kukonza.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Gulu lazolumikiza mzere loyimira kuyamba kapena kutha kwa `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Mzere wa 1-index mu fayilo yoyambira pomwe span imayamba kapena kutha (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Mzere wa 0-indexed (mu zilembo za UTF-8) mu fayilo yoyambira pomwe span imayamba kapena kutha (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Fayilo yoyambira ya `Span` yopatsidwa.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Ikupeza njira yopita kufayiloyi.
    ///
    /// ### Note
    /// Ngati kachidindo kakang'ono kogwirizana ndi `SourceFile` kameneka kanapangidwa ndi macro akunja, macro awa, iyi siyingakhale njira yeniyeni pamafayilo.
    /// Gwiritsani ntchito [`is_real`] kuti muwone.
    ///
    /// Komanso dziwani kuti ngakhale `is_real` ibweza `true`, ngati `--remap-path-prefix` idadutsa pamzere wolamula, njira yomwe yaperekedwayo mwina siyingakhale yolondola.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Imabwezeretsa `true` ngati fayilo iyi ndi gwero lenileni, ndipo silinapangidwe ndikukula kwakunja kwakunja.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Uku ndikubera mpaka magawo a intercrate akhazikitsidwa ndipo titha kukhala ndi mafayilo enieni opangira ma macro akunja.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// token imodzi kapena mndandanda wazinthu za token (mwachitsanzo, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Mtsinje wa token wozunguliridwa ndi oyimilira m'mabokosi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Dzina.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Chizindikiro chimodzi ('+ `, `,`, `$`, etc.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Khalidwe lenileni (`'a'`), chingwe (`"hello"`), nambala (`2.3`), ndi zina zambiri.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Imabwezeretsa nthawi yayitali yamtengo uwu, yoperekera njira ya `span` ya token kapena mtsinje woperewera.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Imapanga chikwangwani cha *token* iyi yokha.
    ///
    /// Dziwani kuti ngati token iyi ndi `Group` ndiye kuti njirayi singasinthe nthawi yayitali ya tokens, izi zitha kungopereka njira ya `set_span` yamitundu iliyonse.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Sindikizani mtengo wa token m'njira yosavuta kukonza.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Iliyonse mwazimenezi ili ndi dzina mu mtundu wamtundu womwe watulutsidwa, chifukwa chake musadandaule ndi zina zowonjezera
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, mlatho umangopereka `to_string`, tsatirani `fmt::Display` kutengera pamenepo (chosiyana ndi ubale wamba pakati pa awiriwa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Sindikizani mtengo wa token ngati chingwe chomwe chimayenera kusandulika mosataya kubwerera mumtengo womwewo wa token (modulo spans), kupatula `TokenTree: : Group`s yokhala ndi oyambitsa `Delimiter::None` ndi manambala oyipa.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Mtsinje wa token woyerekeza.
///
/// `Group` mkati ili ndi `TokenStream` yomwe yazunguliridwa ndi `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Imafotokozera momwe mndandanda wa mitengo ya token umayendetsedwa.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Chojambula chotsimikizika, chomwe mwina, chitha kuwonekera mozungulira tokens kuchokera ku "macro variable" `$var`.
    /// Ndikofunikira kusunga zoyika patsogolo zaopanga ngati `$var * 3` pomwe `$var` ndi `1 + 2`.
    /// Otsutsa kwathunthu sangakhale ndi moyo paulendo wa token kudzera pachingwe.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Pangani `Group` yatsopano ndi delimiter yopatsidwa ndi token.
    ///
    /// Wopanga uyu akhazikitsa nthawi yayitali pagululi mpaka `Span::call_site()`.
    /// Kusintha chikhatho mutha kugwiritsa ntchito njira ya `set_span` pansipa.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Kubwezeretsa malire a `Group` iyi
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Imabwezeretsa `TokenStream` ya tokens yomwe idayikidwa mu `Group` iyi.
    ///
    /// Dziwani kuti mtsinje wobwezeretsanso wa token sukuphatikiza magawo omwe abwezeretsedwera pamwambapa.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Imabwezeretsa nthawi yayitali yoyendetsa tsambali la token, kutambasula `Group` yonse.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Imabwezeretsa chikwangwani choloza kumalire otsegulira gululi.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Imabwezeretsa chikwangwani cholozera kumapeto kwa gulu lino.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Imasanja chikhatho cha opitilira "Gulu" ili, koma osati tokens yake yamkati.
    ///
    /// Njirayi **siyikhala** yoyala kutalika kwa tokens zonse zomwe zili m'gululi, koma zimangokhazikitsa gawo la tokens pamlingo wa `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, mlatho umangopereka `to_string`, tsatirani `fmt::Display` kutengera pamenepo (chosiyana ndi ubale wamba pakati pa awiriwa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Sindikizani gululo ngati chingwe chomwe chiyenera kukhala chosasinthika kubwerera m'gulu lomwelo (modulo spans), kupatula mwina `TokenTree: : Group`s yokhala ndi `Delimiter::None` delimiters.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` ndi chizindikiro chimodzi chopumira monga `+`, `-` kapena `#`.
///
/// Ogwiritsa ntchito ma X-UM `+=` amaimiridwa ngati magawo awiri a `Punct` okhala ndi mitundu yosiyanasiyana ya `Spacing` yobwezeredwa.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Kaya `Punct` imatsatiridwa nthawi yomweyo ndi `Punct` ina kapena kutsatiridwa ndi token ina kapena whitespace.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// Mwachitsanzo, `+` ndi `Alone` mu `+ =`, `+ident` kapena `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// Mwachitsanzo, `+` ndi `Joint` mu `+=` kapena `'#`.
    /// Kuphatikiza apo, mawu amodzi `'` atha kujowina ndi zizindikiritso kuti apange nthawi yamoyo `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Kupanga `Punct` yatsopano kuchokera pamtundu womwe wapatsidwa ndikutalikirana.
    /// Mtsutso wa `ch` uyenera kukhala chilembedwe choyenera chololedwa ndi chilankhulo, apo ayi ntchitoyo izikhala panic.
    ///
    /// `Punct` yobwezeretsedwayo izikhala ndi nthawi ya `Span::call_site()` yomwe ingakonzedwenso ndi njira ya `set_span` pansipa.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Zimabwezeretsa mtengo wamakalata ngati `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Kubwezeretsa mpata wa zilembozi, kuwonetsa ngati ikutsatiridwa nthawi yomweyo ndi `Punct` ina mumtsinje wa token, kuti athe kuphatikizidwa kukhala wothandizira anthu angapo (`Joint`), kapena ikutsatiridwa ndi token kapena whitespace (`Alone`) kotero woyendetsa ali ndi inatha.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Imabwezeretsa chikhatho cha chilembochi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konzani chikhato cha chilembo ichi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, mlatho umangopereka `to_string`, tsatirani `fmt::Display` kutengera pamenepo (chosiyana ndi ubale wamba pakati pa awiriwa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Imasindikiza kalembedwe kake ngati chingwe chomwe chiyenera kukhala chosasinthika ndikuchokeranso chimodzimodzi.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Chizindikiro (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Amapanga `Ident` yatsopano ndi `string` yopatsidwa komanso `span`.
    /// Mtsutso wa `string` uyenera kukhala chizindikiritso chololedwa ndi chilankhulo (kuphatikiza mawu osakira, mwachitsanzo `self` kapena `fn`).Kupanda kutero, ntchitoyi idzakhala panic.
    ///
    /// Dziwani kuti `span`, yomwe ili ku rustc, imasintha zidziwitso zaukhondo za chizindikiritso ichi.
    ///
    /// Pakadali pano `Span::call_site()` imalowa muukhondo wa "call-site" kutanthauza kuti zizindikiritso zopangidwa ndi nthawi imeneyi zidzathetsedwa ngati kuti zidalembedwa molunjika komwe kuli mayitanidwe akulu, ndipo ma code ena omwe adzalembedwere pa macro adzatha kunena nawonso.
    ///
    ///
    /// Kutalika kwakanthawi ngati `Span::def_site()` kudzalola kulowa muukhondo wa "definition-site" kutanthauza kuti zizindikiritso zopangidwa ndi nthawi imeneyi zidzathetsedwa pomwe matanthauzidwe akulu ndi ma code ena omwe adzalembedwe pa macro sangathe kuwatumizira.
    ///
    /// Chifukwa chakufunika kwaukhondo komwe wopanga uyu, mosiyana ndi ma tokens, amafuna kuti `Span` ifotokozedwe pomanga.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Zomwezo ndi `Ident::new`, koma zimapanga dzina lachilendo (`r#ident`).
    /// Mtsutso wa `string` ukhale chizindikiritso chololedwa ndi chilankhulo (kuphatikiza mawu osakira, mwachitsanzo `fn`).
    /// Mawu osakira omwe amagwiritsidwa ntchito pamagawo oyenda (mwachitsanzo
    /// `self`, `super`) sizothandizidwa, ndipo zimayambitsa panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Imabwezeretsa kutalika kwa `Ident` iyi, kuphatikiza chingwe chonse chomwe chabwezedwa ndi [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Imakonza gawo la `Ident` iyi, mwina posintha ukhondo wake.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, mlatho umangopereka `to_string`, tsatirani `fmt::Display` kutengera pamenepo (chosiyana ndi ubale wamba pakati pa awiriwa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Sindikizani chizindikirocho ngati chingwe chomwe chiyenera kukhala chosasinthika kuti chibwererenso mu chizindikiritso chomwecho.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Chingwe chenicheni (`"hello"`), byte chingwe (`b"hello"`), chilembo (`'a'`), cholembedwera (`b'a'`), nambala yochulukirapo kapena yoyandama yopanda kapena yosakwanira (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Zolemba za Boolean monga `true` ndi `false` sizili pano, ndi ma `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Pangani chokwanira chokwanira chokwanira chokwanira ndi mtengo wofotokozedwayo.
        ///
        /// Ntchitoyi ipanga nambala yofanana ndi `1u32` pomwe mtengo wathunthu womwe watchulidwa ndiye gawo loyamba la token ndipo chophatikizacho chimakwaniritsidwa kumapeto.
        /// Zolemba zomwe zimapangidwa kuchokera ku manambala olakwika sizingakhalepo pamaulendo ozungulira kudzera pa `TokenStream` kapena zingwe ndipo zitha kusweka kukhala tokens (`-` ndi zenizeni zenizeni).
        ///
        ///
        /// Zolemba zomwe zimapangidwa kudzera mu njirayi zimakhala ndi nthawi ya `Span::call_site()` mwachisawawa, yomwe ingakonzedwe ndi njira ya `set_span` pansipa.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Pangani nambala yatsopano yosasinthidwa ndi mtengo wake.
        ///
        /// Ntchitoyi ipanga nambala yofanana ndi `1` pomwe mtengo wathunthu womwe watchulidwa ndiye gawo loyamba la token.
        /// Palibe chokwanira chomwe chatchulidwa pa token, kutanthauza kuti mapembedzero ngati `Literal::i8_unsuffixed(1)` ali ofanana ndi `Literal::u32_unsuffixed(1)`.
        /// Zolemba zomwe zimapangidwa kuchokera ku manambala olakwika sizingakhalepo pakati pa `TokenStream` kapena zingwe ndipo zitha kugawidwa mu tokens (`-` ndi zenizeni zenizeni).
        ///
        ///
        /// Zolemba zomwe zimapangidwa kudzera mu njirayi zimakhala ndi nthawi ya `Span::call_site()` mwachisawawa, yomwe ingakonzedwe ndi njira ya `set_span` pansipa.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Pangani chatsopano chenicheni chosasinthidwa.
    ///
    /// Wopanga uyu ndi wofanana ndi `Literal::i8_unsuffixed` pomwe mtengo wa float umatulutsidwa molunjika mu token koma palibe chokwanira chomwe chimagwiritsidwa ntchito, chifukwa chake atha kukhala `f64` pambuyo pake pakupanga.
    ///
    /// Zolemba zomwe zimapangidwa kuchokera ku manambala olakwika sizingakhalepo pakati pa `TokenStream` kapena zingwe ndipo zitha kugawidwa mu tokens (`-` ndi zenizeni zenizeni).
    ///
    /// # Panics
    ///
    /// Ntchitoyi imafuna kuti kuyandama kotchulidwako kukhale kotsirizira, mwachitsanzo ngati kuli kopanda malire kapena NaN ntchitoyi idzakhala panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Pangani cholembera chatsopano chokhazikika.
    ///
    /// Wopanga uyu apanga zenizeni monga `1.0f32` pomwe mtengo womwe watchulidwa ndi gawo lam'mbuyomu la token ndipo `f32` ndiye chokwanira cha token.
    /// token iyi nthawi zonse imadziwika kuti ndi `f32` pakupanga.
    /// Zolemba zomwe zimapangidwa kuchokera ku manambala olakwika sizingakhalepo pakati pa `TokenStream` kapena zingwe ndipo zitha kugawidwa mu tokens (`-` ndi zenizeni zenizeni).
    ///
    ///
    /// # Panics
    ///
    /// Ntchitoyi imafuna kuti kuyandama kotchulidwako kukhale kotsirizira, mwachitsanzo ngati kuli kopanda malire kapena NaN ntchitoyi idzakhala panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Pangani chatsopano chenicheni chosasinthidwa.
    ///
    /// Wopanga uyu ndi wofanana ndi `Literal::i8_unsuffixed` pomwe mtengo wa float umatulutsidwa molunjika mu token koma palibe chokwanira chomwe chimagwiritsidwa ntchito, chifukwa chake atha kukhala `f64` pambuyo pake pakupanga.
    ///
    /// Zolemba zomwe zimapangidwa kuchokera ku manambala olakwika sizingakhalepo pakati pa `TokenStream` kapena zingwe ndipo zitha kugawidwa mu tokens (`-` ndi zenizeni zenizeni).
    ///
    /// # Panics
    ///
    /// Ntchitoyi imafuna kuti kuyandama kotchulidwako kukhale kotsirizira, mwachitsanzo ngati kuli kopanda malire kapena NaN ntchitoyi idzakhala panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Pangani cholembera chatsopano chokhazikika.
    ///
    /// Wopanga uyu apanga zenizeni monga `1.0f64` pomwe mtengo womwe watchulidwa ndi gawo lam'mbuyomu la token ndipo `f64` ndiye chokwanira cha token.
    /// token iyi nthawi zonse imadziwika kuti ndi `f64` pakupanga.
    /// Zolemba zomwe zimapangidwa kuchokera ku manambala olakwika sizingakhalepo pakati pa `TokenStream` kapena zingwe ndipo zitha kugawidwa mu tokens (`-` ndi zenizeni zenizeni).
    ///
    ///
    /// # Panics
    ///
    /// Ntchitoyi imafuna kuti kuyandama kotchulidwako kukhale kotsirizira, mwachitsanzo ngati kuli kopanda malire kapena NaN ntchitoyi idzakhala panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Chingwe chenicheni.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Khalidwe lenileni.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Chingwe chachitsulo chenicheni.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Kubwezeretsa chikhatho chomwe chikuphatikiza zenizeni.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Imasanja chikhatho chogwirizana ndi izi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Imabwezeretsa `Span` yomwe ili gawo laling'ono la `self.span()` lokhala ndi mabatani oyambira osiyanasiyana mu `range`.
    /// Imabwezeretsa `None` ngati chochedwacho chikadali kunja kwa `self`.
    ///
    // FIXME(SergioBenitez): onetsetsani kuti mndandanda wamtunduwu ukuyamba ndikutha pamalire a UTF-8 a gwero.
    // Kupanda kutero, mwina panic imachitika kwina kulikonse pomwe zolembedwazo zisindikizidwa.
    // FIXME(SergioBenitez): palibe njira yoti wogwiritsa ntchito adziwe zomwe `self.span()` imapangira, chifukwa chake njirayi ikhoza kungotchedwa mwakhungu.
    // Mwachitsanzo, `to_string()` ya chikhalidwe 'c' imabweza "'\u{63}'";palibe njira yoti wogwiritsa ntchito adziwe ngati mawuwo anali 'c' kapena anali '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) china chofanana ndi `Option::cloned`, koma cha `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, mlatho umangopereka `to_string`, tsatirani `fmt::Display` kutengera pamenepo (chosiyana ndi ubale wamba pakati pa awiriwa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Sindikizani zenizeni monga chingwe chomwe chiyenera kukhala chosasinthika kuti chibwererenso chimodzimodzi (kupatula kuthekera kozungulira kwa malo oyandama).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Kutsata kutsata zosintha zachilengedwe.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Pezani zosintha zachilengedwe ndikuziwonjezera kuti mumange zambiri zodalira.
    /// Konzani makina opangira makinawo adziwa kuti zosinthazo zidapezeka panthawi yopanga, ndipo zitha kuyambiranso zomangazo phindu la zosinthazi zikasintha.
    ///
    /// Kupatula kudalira komwe kumatsata ntchitoyi kuyenera kukhala kofanana ndi `env::var` kuchokera ku laibulale yanthawi zonse, kupatula kuti mkanganowo uyenera kukhala UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}