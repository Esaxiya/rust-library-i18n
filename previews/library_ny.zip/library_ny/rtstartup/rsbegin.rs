// rsbegin.o ndipo rsend.o ndiomwe amatchedwa "compiler runtime startup objects".
// Amakhala ndi ma code omwe amafunikira kuti akhazikitse nthawi yoyeserera yopanga.
//
// Chithunzi chojambulidwa kapena dylib chikalumikizidwa, manambala onse ogwiritsa ntchito ndi malo owerengera amakhala "sandwiched" pakati pamafayilo awiriwa, chifukwa chake nambala kapena deta yochokera ku rsbegin.o imakhala yoyamba m'zigawo zonse za chithunzicho, pomwe nambala ndi ma data ochokera ku rsend.o amakhala omaliza.
// Izi zitha kugwiritsidwa ntchito kuyika zizindikilo koyambirira kapena kumapeto kwa gawo, komanso kuyika mutu uliwonse kapena zotsalira.
//
// Dziwani kuti gawo lenileni lolowera gawo limapezeka mu C poyambira nthawi yoyambira (yomwe nthawi zambiri imatchedwa `crtX.o`), yomwe imayitanitsa kuyimitsidwa koyambirira kwa zida zina zothamangira (zolembedwanso kudzera pagawo lina lazithunzi).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Zolemba kuyambika kwa chimango chakumapeto kwa gawo lazidziwitso
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Tsegulani malo osungira mabuku mkati.
    // Izi zimatanthauzidwa kuti `struct object` mu $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Sungani mawonekedwe a registration/deregistration.
    // Onani zolemba za libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // lembetsani zambiri pamasamba oyambira
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // lembetsani kutseka
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Kulembetsa kwanthawi zonse kwa MinGW-init/uninit
    pub mod mingw_init {
        // Zinthu zoyambira za MinGW (crt0.o/dllcrt0.o) zithandizira omanga padziko lonse lapansi mu zigawo za .ctors ndi .dtors poyambira ndikutuluka.
        // Pankhani ya DLLs, izi zimachitika DLL ikatsitsidwa ndikutsitsidwa.
        //
        // The linker amasanja magawo, omwe amatsimikizira kuti zovuta zathu zili kumapeto kwa mndandandandawo.
        // Popeza omanga amayendetsedwa mosinthana, izi zimawonetsetsa kuti zovuta zathu ndizoyambirira komanso zomaliza kuphedwa.
        //
        //

        #[link_section = ".ctors.65535"] // . madokotala. *: C kuyambitsa zovuta
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C kuchotsa kubwerera
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}