//! Kutsegula panics kwa Miri.
use alloc::boxed::Box;
use core::any::Any;

// Mtundu wa zolipira zomwe injini ya Miri imafalitsa kudzera pakusamasula kwa ife.
// Iyenera kukhala yayikulu kwambiri.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Ntchito yoperekedwa ndi Miri kuti ayambe kumasula.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Malipiro omwe timapereka ku `miri_start_panic` adzakhala chimodzimodzi mkangano womwe timapeza mu `cleanup` pansipa.
    // Chifukwa chake timangolemba kamodzi, kuti tipeze china chake cholozera.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Bwezeretsani zomwe zimayambitsa `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}