// rsbegin.o i rsend.o són els anomenats "compiler runtime startup objects".
// Contenen el codi necessari per inicialitzar correctament el temps d'execució del compilador.
//
// Quan hi ha una imatge executable o dylib enllaçada, tots els codis d'usuari i les biblioteques són "sandwiched" entre aquests dos fitxers objecte, de manera que el codi o les dades de rsbegin.o passen a ser els primers a les seccions respectives de la imatge, mentre que el codi i les dades de rsend.o es converteixen en els darrers.
// Aquest efecte es pot utilitzar per col・locar símbols al principi o al final d'una secció, així com per inserir capçaleres o peus de pàgina necessaris.
//
// Tingueu en compte que el punt d`entrada del mòdul real es troba a l`objecte d`inici del temps d`execució C (normalment anomenat `crtX.o`), que llavors invoca les devolucions de trucada d`inicialització d`altres components del temps d`execució (registrats a través d`una altra secció especial d`imatge).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Marca l'inici de la secció d'informació de desenrotllament del marc de la pila
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Espai per ratllar per a la comptabilitat interna del desenrotllador.
    // Això es defineix com `struct object` a $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Desenvolupeu les rutines d`informació registration/deregistration.
    // Consulteu els documents de libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // registreu informació de desenrotllament a l`inici del mòdul
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // cancel・lar el registre en apagar
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Registre de rutina específic de MinGW init/uninit
    pub mod mingw_init {
        // Els objectes d'inici de MinGW (crt0.o/dllcrt0.o) invocaran constructors globals a les seccions .ctors i .dtors en iniciar i sortir.
        // En el cas de les DLL, això es fa quan es carrega i descarrega la DLL.
        //
        // L'enllaçador ordenarà les seccions, cosa que garanteix que les nostres devolucions de trucades es localitzin al final de la llista.
        // Com que els constructors s`executen en ordre invers, això garanteix que les nostres devolucions de trucada siguin les primeres i les darreres que s`executen.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: devolucions de trucada d`inicialització C.
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: devolucions de trucada de terminació C.
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}