use backtrace::Backtrace;

// Aquesta prova només funciona en plataformes que tenen una funció `symbol_address` en funcionament per als fotogrames que informa de l'adreça inicial d'un símbol.
// Com a resultat, només està habilitat en algunes plataformes.
//
const ENABLED: bool = cfg!(all(
    // Windows no s'ha provat realment, i OSX no admet la cerca d'un marc adjunt, així que desactiveu-lo
    //
    target_os = "linux",
    // En trobar ARM, la funció de tancament és simplement retornar la pròpia ip.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}