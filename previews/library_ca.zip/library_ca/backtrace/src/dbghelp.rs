//! Un mòdul per ajudar a gestionar els enllaços dbghelp a Windows
//!
//! Les traces posteriors de Windows (almenys per a MSVC) s`alimenten en gran part mitjançant `dbghelp.dll` i les diverses funcions que conté.
//! Actualment, aquestes funcions es carreguen *dinàmicament* en lloc d'enllaçar-les a `dbghelp.dll` estàticament.
//! Això ho fa actualment la biblioteca estàndard (i en teoria és obligatori allà), però és un esforç per ajudar a reduir les dependències estàtiques de dll d'una biblioteca, ja que les traces posteriors solen ser força opcionals.
//!
//! Dit això, `dbghelp.dll` gairebé sempre es carrega amb èxit a Windows.
//!
//! Tingueu en compte, però, que com que estem carregant tot aquest suport de forma dinàmica, no podem utilitzar les definicions en brut de `winapi`, sinó que hem de definir nosaltres mateixos els tipus de punter de funció i utilitzar-lo.
//! Realment no volem dedicar-nos a la duplicació de winapi, de manera que tenim una funció Cargo `verify-winapi` que afirma que totes les vinculacions coincideixen amb les de winapi i aquesta funció està habilitada a CI.
//!
//! Finalment, observareu aquí que la dll per a `dbghelp.dll` mai es descarrega, i que actualment és intencionada.
//! El pensament és que podem emmagatzemar-lo en memòria cau a nivell mundial i utilitzar-lo entre trucades a l'API, evitant el costós loads/unloads.
//! Si això és un problema per als detectors de fuites o alguna cosa així, podem creuar el pont quan hi arribem.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Treballeu al voltant de `SymGetOptions` i `SymSetOptions` perquè no estiguin presents al propi winapi.
// En cas contrari, això només s`utilitza quan comprovem els tipus contra winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Encara no està definit a winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Això es defineix a winapi, però és incorrecte (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Encara no està definit a winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Aquesta macro s'utilitza per definir una estructura `Dbghelp` que conté internament tots els indicadors de funció que podríem carregar.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// La DLL carregada per a `dbghelp.dll`
            dll: HMODULE,

            // Podríem utilitzar cada punter de funció per a cada funció
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Inicialment no hem carregat la DLL
            dll: 0 as *mut _,
            // Inicialment, totes les funcions es posen a zero per dir que cal carregar-les dinàmicament.
            //
            $($name: 0,)*
        };

        // Tipus de comoditat per a cada tipus de funció.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Intents d'obrir `dbghelp.dll`.
            /// Retorna l'èxit si funciona o l'error si falla `LoadLibraryW`.
            ///
            /// Panics si la biblioteca ja està carregada.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Funció per a cada mètode que ens agradaria utilitzar.
            // Quan es crida, llegirà el punter de la funció de memòria cau o el carregarà i retornarà el valor carregat.
            // S'afirma que les càrregues tenen èxit.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Conveni intermediari per utilitzar els panys de neteja per fer referència a les funcions de dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Inicialitzeu tot el suport necessari per accedir a les funcions de l'API `dbghelp` des d'aquest crate.
///
///
/// Tingueu en compte que aquesta funció és **segura**, que internament té la seva pròpia sincronització.
/// Tingueu en compte també que és segur anomenar aquesta funció diverses vegades recursivament.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // El primer que hem de fer és sincronitzar aquesta funció.Això es pot anomenar simultàniament des d'altres fils o recursivament dins d'un fil.
        // Tingueu en compte que és més complicat que això, perquè el que fem servir aquí, `dbghelp`,*també*, ha de sincronitzar-se amb la resta de persones que truquen a `dbghelp` en aquest procés.
        //
        // Normalment no hi ha tantes trucades a `dbghelp` dins del mateix procés i probablement podem suposar amb seguretat que som els únics que hi accedim.
        // Tanmateix, hi ha un altre usuari principal que ens hem de preocupar, que és irònicament nosaltres, però a la biblioteca estàndard.
        // La biblioteca estàndard Rust depèn d'aquest crate per a suport de retrocés, i aquest crate també existeix a crates.io.
        // Això vol dir que si la biblioteca estàndard imprimeix un traçat posterior panic, pot aparèixer amb aquest crate procedent de crates.io, provocant defectes.
        //
        // Per ajudar a resoldre aquest problema de sincronització, fem servir un truc específic de Windows (al cap i a la fi, és una restricció específica de Windows sobre la sincronització).
        // Creem un *session-local* anomenat mutex per protegir aquesta trucada.
        // La intenció aquí és que la biblioteca estàndard i aquest crate no hagin de compartir API de nivell Rust per sincronitzar aquí, sinó que poden treballar darrere de les escenes per assegurar-se que se sincronitzen entre si.
        //
        // D'aquesta manera, quan es crida aquesta funció a través de la biblioteca estàndard o a través de crates.io, podem estar segurs que s'està adquirint el mateix mutex.
        //
        // Per tant, tot això vol dir que el primer que fem aquí és crear atomicament un `HANDLE` que és un mutex anomenat a Windows.
        // Sincronitzem una mica amb altres fils que comparteixen aquesta funció específicament i ens assegurem que només es creï un identificador per cada instància d'aquesta funció.
        // Tingueu en compte que el mànec no es tanca mai un cop emmagatzemat al global.
        //
        // Després d`haver realitzat el pany, simplement l`adquirim i el nostre mànec `Init` que repartirem serà el responsable de deixar-lo caure eventualment.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // D`acord, uf!Ara que estem sincronitzats de forma segura, comencem a processar-ho tot.
        // En primer lloc, hem d`assegurar-nos que `dbghelp.dll` es carrega realment en aquest procés.
        // Ho fem dinàmicament per evitar una dependència estàtica.
        // Històricament, això s`ha fet per solucionar problemes d`enllaços estranys i està pensat per fer que els binaris siguin una mica més portables, ja que en gran mesura només és una utilitat de depuració.
        //
        //
        // Un cop hem obert `dbghelp.dll`, hem de trucar a algunes funcions d'inicialització, i això es detalla més a continuació.
        // Però només ho fem una vegada, de manera que tenim un booleà global que indica si hem acabat o no.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Assegureu-vos que el senyalador `SYMOPT_DEFERRED_LOADS` estigui definit, ja que segons els propis documents de MSVC sobre això: "This is the fastest, most efficient way to use the symbol handler.", fem-ho.
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Inicialitzeu els símbols amb MSVC.Tingueu en compte que això pot fallar, però ho ignorem.
        // No hi ha una gran quantitat de tècniques anteriors per si mateixes, però LLVM sembla ignorar internament el valor de retorn aquí i una de les biblioteques de desinfectant de LLVM imprimeix un avís aterrador si falla, però bàsicament ho ignora a la llarga.
        //
        //
        // Un cas que surt molt per a Rust és que la biblioteca estàndard i aquest crate de crates.io volen competir per `SymInitializeW`.
        // Històricament, la biblioteca estàndard volia inicialitzar i després netejar la major part del temps, però ara que utilitza aquest crate significa que algú arribarà primer a la inicialització i l`altre recollirà aquesta inicialització.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}