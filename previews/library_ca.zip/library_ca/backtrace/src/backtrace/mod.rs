use core::ffi::c_void;
use core::fmt;

/// Inspecciona la pila de trucades actual, passant tots els fotogrames actius al tancament proporcionat per calcular una traça de pila.
///
/// Aquesta funció és el cavall de batalla d'aquesta biblioteca en el càlcul de les traces de pila d'un programa.El tancament donat `cb` es produeix instàncies d'un `Frame` que representen informació sobre aquest marc de trucades a la pila.
/// El tancament es tradueix en marcs de manera descendent (més recentment s`anomenen funcions primeres).
///
/// El valor retornat del tancament és una indicació de si s`hauria de continuar la traça posterior.Un valor de retorn de `false` finalitzarà la traça posterior i es retornarà immediatament.
///
/// Un cop adquirit un `Frame`, és probable que vulgueu trucar a `backtrace::resolve` per convertir l`adreça `ip` (indicador d`instruccions) o símbol a un `Symbol` a través del qual es pot aprendre el nom i/o el nom del fitxer/número de línia.
///
///
/// Tingueu en compte que es tracta d`una funció de nivell relativament baix i, si voleu, per exemple, capturar una traça posterior per inspeccionar-la posteriorment, el tipus `Backtrace` pot ser més adequat.
///
/// # Funcions necessàries
///
/// Aquesta funció requereix que la funció `std` del `backtrace` crate estigui habilitada i la funció `std` estigui habilitada per defecte.
///
/// # Panics
///
/// Aquesta funció s'esforça per no panic mai, però si el `cb` proporciona panics, algunes plataformes obligaran a panic doble a avortar el procés.
/// Algunes plataformes utilitzen una biblioteca C que utilitza internament devolucions de trucada que no es poden desenrotllar, de manera que el pànic des de `cb` pot provocar un avortament del procés.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // continuar la traça enrere
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Igual que `trace`, només no segur ja que no està sincronitzat.
///
/// Aquesta funció no té garantits de sincronització, però està disponible quan no es compila la característica `std` d'aquest crate.
/// Consulteu la funció `trace` per obtenir més documentació i exemples.
///
/// # Panics
///
/// Consulteu la informació sobre `trace` per obtenir advertències sobre el pànic de `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Un trait que representa un fotograma d'una traça posterior, va cedir a la funció `trace` d'aquest crate.
///
/// El tancament de la funció de rastreig obtindrà fotogrames, i el fotograma s`envia virtualment, ja que la implementació subjacent no sempre es coneix fins al temps d`execució.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Retorna el punter d'instrucció actual d'aquest marc.
    ///
    /// Normalment, aquesta és la següent instrucció a executar en el marc, però no totes les implementacions ho indiquen amb una precisió del 100% (però generalment és bastant propera).
    ///
    ///
    /// Es recomana passar aquest valor a `backtrace::resolve` per convertir-lo en un nom de símbol.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Retorna el punter de pila actual d'aquest marc.
    ///
    /// En el cas que un dorsal no pugui recuperar el punter de pila per a aquest marc, es retorna un punter nul.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Retorna l'adreça del símbol inicial del marc d'aquesta funció.
    ///
    /// Això intentarà rebobinar el punter d'instruccions retornat per `ip` a l'inici de la funció, retornant aquest valor.
    ///
    /// No obstant això, en alguns casos, els dorsals només retornaran `ip` des d'aquesta funció.
    ///
    /// El valor retornat de vegades es pot utilitzar si `backtrace::resolve` ha fallat a l `ip` indicat anteriorment.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Retorna l'adreça base del mòdul al qual pertany el marc.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Cal que això sigui primer, per garantir que Miri tingui prioritat sobre la plataforma d`amfitrió
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // només s'utilitza a dbghelp simbolitza
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}