// només s`utilitza a Linux ara mateix, així que permeteu el codi mort en qualsevol altre lloc
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Un simple assignador d`arena per als buffers de bytes.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Assigna una memòria intermèdia de la mida especificada i li retorna una referència mutable.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SEGURETAT: aquesta és l'única funció que construeix un mutable
        // referència a `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SEGURETAT: mai eliminem elements del `self.buffers`, per tant, és una referència
        // a les dades de qualsevol memòria intermèdia es mantindrà mentre ho faci `self`.
        &mut buffers[i]
    }
}