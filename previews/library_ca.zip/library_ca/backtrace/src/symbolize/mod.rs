use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Resol una adreça a un símbol, passant el símbol al tancament especificat.
///
/// Aquesta funció buscarà l'adreça indicada en àrees com la taula de símbols local, la taula de símbols dinàmica o la informació de depuració de DWARF (depenent de la implementació activada) per trobar símbols a produir.
///
///
/// El tancament no es pot trucar si no es pot dur a terme la resolució, i també es pot trucar més d'una vegada en el cas de funcions en línia.
///
/// Els símbols donats representen l'execució a la `addr` especificada, retornant parells file/line per a aquesta adreça (si està disponible).
///
/// Tingueu en compte que si teniu un `Frame`, es recomana utilitzar la funció `resolve_frame` en lloc d'aquesta.
///
/// # Funcions necessàries
///
/// Aquesta funció requereix que la funció `std` del `backtrace` crate estigui habilitada i la funció `std` estigui habilitada per defecte.
///
/// # Panics
///
/// Aquesta funció s'esforça per no panic mai, però si el `cb` proporciona panics, algunes plataformes obligaran a panic doble a avortar el procés.
/// Algunes plataformes utilitzen una biblioteca C que utilitza internament devolucions de trucada que no es poden desenrotllar, de manera que el pànic des de `cb` pot provocar un avortament del procés.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // només mireu el marc superior
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Resol un marc de captura prèviament a un símbol, passant el símbol al tancament especificat.
///
/// Aquesta funció realitza la mateixa funció que `resolve`, tret que pren un `Frame` com a argument en lloc d'una adreça.
/// Això pot permetre algunes implementacions de plataformes de retrocés per proporcionar informació de símbols més precisa o informació sobre marcs en línia, per exemple.
///
/// Es recomana utilitzar-ho si pot.
///
/// # Funcions necessàries
///
/// Aquesta funció requereix que la funció `std` del `backtrace` crate estigui habilitada i la funció `std` estigui habilitada per defecte.
///
/// # Panics
///
/// Aquesta funció s'esforça per no panic mai, però si el `cb` proporciona panics, algunes plataformes obligaran a panic doble a avortar el procés.
/// Algunes plataformes utilitzen una biblioteca C que utilitza internament devolucions de trucada que no es poden desenrotllar, de manera que el pànic des de `cb` pot provocar un avortament del procés.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // només mireu el marc superior
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Els valors IP dels marcs de pila solen ser (always?) la instrucció *després de* la trucada que és la traça de pila real.
// Simbolitzar això activat fa que el número filename/line estigui un per davant i potser al buit si és a prop del final de la funció.
//
// Sembla que això bàsicament sempre és el cas de totes les plataformes, de manera que sempre restem una de la IP resolta per resoldre-la a la instrucció de trucada anterior en lloc de tornar-la.
//
//
// L`ideal seria no fer-ho.
// Idealment, requeriríem a les persones que truquen a les API `resolve` aquí per fer manualment el -1 i tenir en compte que volen informació d`ubicació per a la instrucció *anterior*, no per a l`actual.
// L'ideal seria que també exposéssim a `Frame` si realment som l'adreça de la següent instrucció o l'actual.
//
// Ara com ara, però, és una preocupació força especialitzada, de manera que sempre restem internament una.
// Els consumidors haurien de continuar treballant i obtenir resultats força bons, de manera que hauríem de ser prou bons.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Igual que `resolve`, només no segur ja que no està sincronitzat.
///
/// Aquesta funció no té garantits de sincronització, però està disponible quan no es compila la característica `std` d'aquest crate.
/// Consulteu la funció `resolve` per obtenir més documentació i exemples.
///
/// # Panics
///
/// Consulteu la informació sobre `resolve` per obtenir advertències sobre el pànic de `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Igual que `resolve_frame`, només no segur ja que no està sincronitzat.
///
/// Aquesta funció no té garantits de sincronització, però està disponible quan no es compila la característica `std` d'aquest crate.
/// Consulteu la funció `resolve_frame` per obtenir més documentació i exemples.
///
/// # Panics
///
/// Consulteu la informació sobre `resolve_frame` per obtenir advertències sobre el pànic de `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Un trait que representa la resolució d'un símbol en un fitxer.
///
/// Aquest trait es cedeix com a objecte trait al tancament donat a la funció `backtrace::resolve` i pràcticament s`envia ja que es desconeix quina implementació hi ha darrere.
///
///
/// Un símbol pot proporcionar informació contextual sobre una funció, per exemple, el nom, el nom del fitxer, el número de línia, l'adreça precisa, etc.
/// Tanmateix, no tota la informació sempre està disponible en un símbol, de manera que tots els mètodes retornen un `Option`.
///
///
pub struct Symbol {
    // TODO: aquest límit de tota la vida ha de persistir-se fins a `Symbol`,
    // però actualment això és un canvi trencador.
    // De moment, això és segur, ja que `Symbol` només es reparteix per referència i no es pot clonar.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Retorna el nom d'aquesta funció.
    ///
    /// L'estructura retornada es pot utilitzar per consultar diverses propietats sobre el nom del símbol:
    ///
    ///
    /// * La implementació de `Display` imprimirà el símbol desemmarcat.
    /// * Es pot accedir al valor brut `str` del símbol (si és vàlid utf-8).
    /// * Es pot accedir als bytes en brut del nom del símbol.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Retorna l'adreça inicial d'aquesta funció.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Retorna el nom de fitxer en brut com una llesca.
    /// Això és útil sobretot per a entorns `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Retorna el número de columna on s`està executant aquest símbol.
    ///
    /// Actualment, només gimli proporciona un valor aquí i fins i tot només si `filename` retorna `Some` i, per tant, queda sotmès a advertències similars.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Retorna el número de línia on s'està executant aquest símbol.
    ///
    /// Aquest valor de retorn sol ser `Some` si `filename` retorna `Some` i, per tant, està subjecte a advertències similars.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Retorna el nom del fitxer on s'ha definit aquesta funció.
    ///
    /// Actualment només està disponible quan s`utilitza libbacktrace o gimli (per exemple
    /// unix altres plataformes) i quan es compila un binari amb debuginfo.
    /// Si no es compleix cap d'aquestes condicions, probablement tornarà `None`.
    ///
    /// # Funcions necessàries
    ///
    /// Aquesta funció requereix que la funció `std` del `backtrace` crate estigui habilitada i la funció `std` estigui habilitada per defecte.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Potser un símbol C++ analitzat, si fallava en analitzar el símbol manipulat com a Rust.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Assegureu-vos de mantenir aquesta mida zero, de manera que la funció `cpp_demangle` no tingui cap cost quan estigui desactivada.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Un embolcall al voltant d`un nom de símbol per proporcionar accessoris ergonòmics al nom desmembrat, als bytes bruts, a la cadena bruta, etc.
///
// Permet un codi mort quan la funció `cpp_demangle` no estigui habilitada.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Crea un nom de símbol nou a partir dels bytes subjacents en brut.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Retorna el nom del símbol (mangled) sense format com a `str` si el símbol és utf-8 vàlid.
    ///
    /// Utilitzeu la implementació `Display` si voleu la versió desemmarcada.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Retorna el nom del símbol en brut com a llista de bytes
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Això pot imprimir-se si el símbol desmarcat no és realment vàlid, així que gestioneu l'error aquí amb gràcia no propagant-lo cap a l'exterior.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Intenteu recuperar aquesta memòria emmagatzemada a la memòria cau que s`utilitzava per simbolitzar adreces.
///
/// Aquest mètode intentarà alliberar les estructures de dades globals que s'hagin emmagatzemat a la memòria cau de manera global o al fil que normalment representin informació analitzada de DWARF o similar.
///
///
/// # Caveats
///
/// Tot i que aquesta funció sempre està disponible, en realitat no fa res a la majoria d`implementacions.
/// Les biblioteques com dbghelp o libbacktrace no proporcionen facilitats per distribuir l'estat i gestionar la memòria assignada.
/// De moment, la funció `gimli-symbolize` d'aquest crate és l'única característica en què aquesta funció té algun efecte.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}