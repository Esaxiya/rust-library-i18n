//! Suport per a la simbolització mitjançant `gimli` crate a crates.io
//!
//! Aquesta és la implementació de simbolització per defecte per a Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'La vida estàtica és una mentida per piratejar sobre la manca de suport a les estructures autoreferencials.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Convertiu-lo en "vides estàtiques", ja que els símbols només haurien de demanar prestat `map` i `stash` i els conservem a continuació.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Per carregar biblioteques natives a Windows, consulteu algunes discussions sobre rust-lang/rust#71060 per a les diverses estratègies aquí.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Actualment, les biblioteques MinGW no admeten ASLR (rust-lang/rust#16514), però les DLL encara es poden reubicar a l'espai d'adreces.
            // Sembla que les adreces de la informació de depuració són com si aquesta biblioteca es carregés al seu "image base", que és un camp de les capçaleres del fitxer COFF.
            // Com que això és el que sembla afegir a debuginfo, analitzem la taula de símbols i emmagatzemem adreces com si la biblioteca es carregés també a "image base".
            //
            // Tanmateix, és possible que la biblioteca no es carregui a "image base".
            // (presumiblement es pot carregar alguna cosa més allà?) Aquí és on entra en joc el camp `bias`, i aquí hem d`esbrinar el valor de `bias`.Malauradament, però, no està clar com adquirir-ho d'un mòdul carregat.
            // El que sí, però, és l`adreça de càrrega real (`modBaseAddr`).
            //
            // Com a cop-out per ara, mapem el fitxer, llegim la informació de la capçalera del fitxer i després deixem el mapa.Això és malgastador perquè probablement tornarem a obrir el mmap més endavant, però ara hauria de funcionar prou bé.
            //
            // Un cop tenim el `image_base` (ubicació de càrrega desitjada) i el `base_addr` (ubicació de càrrega real) podem emplenar el `bias` (diferència entre el real i el desitjat) i, a continuació, l'adreça indicada de cada segment és la `image_base`, ja que això és el que diu el fitxer.
            //
            //
            // De moment sembla que, a diferència de ELF/MachO, podem conformar-nos amb un segment per biblioteca, fent servir `modBaseSize` com a mida completa.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS utilitza el format de fitxer Mach-O i utilitza API específiques de DYLD per carregar una llista de biblioteques natives que formen part de l`aplicació.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Obtingueu el nom d`aquesta biblioteca que correspon al camí d`on carregar-la també.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Carregueu la capçalera de la imatge d'aquesta biblioteca i delegueu-la a `object` per analitzar totes les ordres de càrrega i així esbrinar tots els segments implicats aquí.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Repeteix els segments i registra les regions conegudes per als segments que trobem.
            // A més, registreu informació sobre els segments de text per processar-la més tard, consulteu els comentaris a continuació.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Determineu el "slide" d`aquesta biblioteca que acaba sent el biaix que fem servir per esbrinar on es carreguen els objectes de la memòria.
            // Tot i això, és un càlcul una mica estrany i és el resultat d`intentar algunes coses en estat salvatge i veure què s`enganxa.
            //
            // La idea general és que el `bias` més el `stated_virtual_memory_address` d`un segment serà on resideix el segment a l`espai d`adreces real.
            // Però l`altra cosa en què confiem és que una adreça real menys el `bias` és l`índex que cal buscar a la taula de símbols i a la informació de depuració.
            //
            // No obstant això, resulta que per a les biblioteques carregades amb el sistema aquests càlculs són incorrectes.Tanmateix, per als executables natius sembla correcte.
            // Al treure una mica de lògica de la font de LLDB, té una carcassa especial per a la primera secció `__TEXT` carregada des del desplaçament 0 del fitxer amb una mida diferent de zero.
            // Per qualsevol motiu, quan això estigui present, sembla que significa que la taula de símbols és relativa només a la diapositiva vmaddr de la biblioteca.
            // Si és *no* present, la taula de símbols és relativa a la diapositiva vmaddr més l'adreça indicada del segment.
            //
            // Per solucionar aquesta situació si *no* trobem cap secció de text a zero de desplaçament del fitxer, augmentem el biaix per l'adreça indicada de les primeres seccions de text i disminuïm també totes les adreces indicades per aquesta quantitat.
            //
            // D'aquesta manera, la taula de símbols sempre apareix en relació amb la quantitat de parcialitat de la biblioteca.
            // Sembla que té els resultats adequats per simbolitzar mitjançant la taula de símbols.
            //
            // Sincerament, no estic del tot segur de si això és correcte o si hi ha alguna cosa més que indiqui com fer-ho.
            // De moment, tot i que sembla funcionar prou bé amb (?), sempre hauríem de ser capaços de modificar-ho amb el temps si cal.
            //
            // Per obtenir més informació, consulteu #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Altres Unix (per exemple,
        // Les plataformes Linux) utilitzen ELF com a format de fitxer objecte i normalment implementen una API anomenada `dl_iterate_phdr` per carregar biblioteques natives.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` hauria de ser un indicador vàlid.
        // `vec` hauria de ser un punter vàlid a un `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 no admet nativament la informació de depuració, però el sistema de compilació col・locarà la informació de depuració al camí `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Tota la resta hauria d`utilitzar ELF, però no sap com carregar les biblioteques natives.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Totes les biblioteques compartides conegudes que s'han carregat.
    libraries: Vec<Library>,

    /// Memòria cau de mapes on conservem informació nana analitzada.
    ///
    /// Aquesta llista té una capacitat fixa per a tota la durada que mai augmenta.
    /// L'element `usize` de cada parell és un índex a `libraries` anterior on `usize::max_value()` representa l'executable actual.
    ///
    /// El `Mapping` és informació nana corresponent analitzada.
    ///
    /// Tingueu en compte que bàsicament es tracta d`una memòria cau de LRU i anirem canviant les coses per aquí mentre simbolitzem les adreces.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Els segments d'aquesta biblioteca es carreguen a la memòria i on es carreguen.
    segments: Vec<LibrarySegment>,
    /// El "bias" d'aquesta biblioteca, normalment on es carrega a la memòria.
    /// Aquest valor s'afegeix a l'adreça indicada de cada segment per obtenir l'adreça de memòria virtual real en què es carrega el segment.
    /// A més, aquest biaix es resta de les adreces de memòria virtual real per indexar-les a debuginfo i a la taula de símbols.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// L'adreça indicada d'aquest segment al fitxer objecte.
    /// En realitat no és on es carrega el segment, sinó més aviat aquesta adreça més el `bias` de la biblioteca que la conté.
    ///
    stated_virtual_memory_address: usize,
    /// La mida del segment a la memòria.
    len: usize,
}

// no és segur perquè cal sincronitzar-lo externament
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // no és segur perquè cal sincronitzar-lo externament
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Una memòria cau LRU molt petita i molt senzilla per a assignacions d'informació de depuració.
        //
        // La taxa d`encert hauria de ser molt alta, ja que la pila típica no es creua entre moltes biblioteques compartides.
        //
        // Les estructures `addr2line::Context` són bastant costoses de crear.
        // S`espera que el seu cost s`amortitzi en consultes posteriors de `locate`, que aprofitin les estructures construïdes en construir `addr2line: : Context`s per obtenir bones acceleracions.
        //
        // Si no tinguéssim aquesta memòria cau, aquesta amortització mai no es produiria i les rastrejaments posteriors simbolitzants serien ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // En primer lloc, proveu si aquest `lib` té algun segment que contingui l `addr` (gestió de la reubicació).Si aquesta comprovació passa, podem continuar a continuació i traduir l'adreça.
                //
                // Tingueu en compte que aquí estem fent servir `wrapping_add` per evitar comprovacions de desbordament.S`ha vist en llibertat que el càlcul del biaix SVMA + desborda.
                // Sembla una mica estrany que passés, però no podem fer una gran quantitat de coses, a part de probablement ignorar aquests segments, ja que probablement apunten a l'espai.
                //
                // Això va aparèixer originalment a rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Ara que sabem que `lib` conté `addr`, podem compensar amb el biaix per trobar l'adreça de memòria virutal indicada.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariant: després que aquest condicional es completi sense tornar abans
        // a partir d'un error, l'entrada de memòria cau d'aquest camí es troba a l'índex 0.

        if let Some(idx) = idx {
            // Quan el mapatge ja sigui a la memòria cau, moveu-lo a la part frontal.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Quan el mapatge no estigui a la memòria cau, creeu-ne un de nou, inseriu-lo a la part frontal de la memòria cau i expulseu l'entrada de memòria cau més antiga si cal.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // no filtris la vida útil del `'static`, assegura't que estigui a l'abast de nosaltres mateixos
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Amplieu la vida útil de `sym` a `'static` ja que malauradament se`ns exigeix aquí, però sempre surt com a referència, de manera que no s`hauria de mantenir cap referència més enllà d`aquest marc.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Finalment, obteniu una assignació a la memòria cau o creeu una nova assignació per a aquest fitxer i avalueu la informació de DWARF per trobar el file/line/name per a aquesta adreça.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Hem pogut localitzar la informació del marc per a aquest símbol i el marc d`addr2line té internament tots els detalls descarnats.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// No s'ha pogut trobar la informació de depuració, però la hem trobat a la taula de símbols de l'executable de l'elf.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}