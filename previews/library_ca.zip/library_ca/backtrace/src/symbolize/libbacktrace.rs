//! Estratègia de simbolització mitjançant el codi d`anàlisi DWARF a libbacktrace.
//!
//! La biblioteca C de libbacktrace, que normalment es distribueix amb gcc, no només permet generar una traça posterior (que en realitat no fem servir), sinó que també simbolitza la traça posterior i maneja informació de depuració nana sobre coses com els marcs inclosos i el que no.
//!
//!
//! Això és relativament complicat a causa de moltes preocupacions aquí, però la idea bàsica és:
//!
//! * Primer anomenem `backtrace_syminfo`.Si obtenim informació sobre símbols de la taula de símbols dinàmics, si podem.
//! * A continuació, anomenem `backtrace_pcinfo`.Això analitzarà les taules de debuginfo si estan disponibles i ens permetrà recuperar informació sobre marcs en línia, noms de fitxers, números de línia, etc.
//!
//! Hi ha molts enganys per aconseguir que les taules nanes entren a libbacktrace, però espero que no sigui la fi del món i que sigui prou clar quan llegiu a continuació.
//!
//! Aquesta és l'estratègia de simbolització per defecte per a plataformes no MSVC i no OSX.A libstd, però, aquesta és l'estratègia predeterminada per a OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Si és possible, preferiu el nom `function` que prové de debuginfo i, per exemple, pot ser més precís per a marcs en línia.
                // Si no està present, torneu al nom de la taula de símbols especificat a `symname`.
                //
                // Tingueu en compte que, de vegades, `function` pot semblar una mica menys precís, per exemple, si apareix a la llista `try<i32,closure>` no és `std::panicking::try::do_call`.
                //
                // No està clar per què, però, en general, el nom `function` sembla més precís.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // no feu res per ara
}

/// Tipus de punter `data` passat a `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Una vegada que s`invoca aquesta devolució de trucada des de `backtrace_syminfo` quan comencem a resoldre, anem més enllà per trucar a `backtrace_pcinfo`.
    // La funció `backtrace_pcinfo` consultarà informació de depuració i intentarà fer coses com recuperar informació file/line, així com fotogrames inclinats.
    // Tingueu en compte que `backtrace_pcinfo` pot fallar o no fer molt si no hi ha informació de depuració, de manera que, si passa això, segur que trucarem a la devolució de trucada amb almenys un símbol del `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Tipus de punter `data` passat a `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// L'API libbacktrace admet la creació d'un estat, però no admet la destrucció d'un estat.
// Personalment, considero que això significa que s`ha de crear un estat i després viure per sempre.
//
// M'encantaria registrar un controlador at_exit() que neteja aquest estat, però libbacktrace no proporciona cap manera de fer-ho.
//
// Amb aquestes restriccions, aquesta funció té un estat de memòria cau estàtic que es calcula la primera vegada que se sol・licita.
//
// Recordeu que el rastreig posterior es produeix en sèrie (un bloqueig global).
//
// Tingueu en compte que la manca de sincronització aquí es deu al requisit que `resolve` estigui sincronitzat externament.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // No utilitzeu les funcions segures de fils de libbacktrace, ja que sempre ho anomenem de manera sincronitzada.
        //
        0,
        error_cb,
        ptr::null_mut(), // no hi ha dades addicionals
    );

    return STATE;

    // Tingueu en compte que perquè libbacktrace funcioni necessita trobar la informació de depuració DWARF per a l'executable actual.Normalment ho fa mitjançant diversos mecanismes que inclouen, entre d'altres:
    //
    // * /proc/self/exe en plataformes compatibles
    // * El nom del fitxer va passar explícitament en crear un estat
    //
    // La biblioteca libbacktrace és una gran quantitat de codi C.Això significa, naturalment, que té vulnerabilitats de seguretat de memòria, especialment quan es tracta de debuginfo mal format.
    // Històricament, Libstd s`ha trobat amb molts d`ells.
    //
    // Si s'utilitza /proc/self/exe, normalment podem ignorar-los, ja que suposem que libbacktrace és "mostly correct" i, en cas contrari, no fa coses estranyes amb la informació de depuració nana "attempted to be correct".
    //
    //
    // Tanmateix, si passem un nom de fitxer, és possible en algunes plataformes (com ara BSD) on un actor maliciós pot fer que es col・loqui un fitxer arbitrari en aquesta ubicació.
    // Això vol dir que si informem libbacktrace sobre un nom de fitxer, pot ser que estigui utilitzant un fitxer arbitrari, possiblement causant segfaults.
    // Si no expliquem res a libbacktrace, no farà res en plataformes que no admetin camins com /proc/self/exe.
    //
    // Tenint en compte tot el que intentem *no* passar en un nom de fitxer, però hem de fer-ho en plataformes que no admetin gens /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Tingueu en compte que, idealment, faríem servir `std::env::current_exe`, però no podem requerir `std` aquí.
            //
            // Utilitzeu `_NSGetExecutablePath` per carregar el camí executable actual en una àrea estàtica (que si és massa petita, només cal renunciar).
            //
            //
            // Tingueu en compte que aquí confiem seriosament en libbacktrace per no morir en executables corromputs, però segur que sí ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows té un mode d'obertura de fitxers on després de l'obrir no es pot esborrar.
            // En general, això és el que volem aquí, perquè volem assegurar-nos que el nostre executable no canviï de sota nostre després de lliurar-lo a libbacktrace, esperem que mitigui la capacitat de passar dades arbitràries a libbacktrace (que pot ser mal manipulat).
            //
            //
            // Tenint en compte que fem una mica de ball aquí per intentar aconseguir una mena de pany a la nostra pròpia imatge:
            //
            // * Obteniu un control del procés actual, carregueu el nom del fitxer.
            // * Obriu un fitxer a aquest nom de fitxer amb els indicadors adequats.
            // * Torneu a carregar el nom de fitxer del procés actual i assegureu-vos que sigui el mateix
            //
            // Si tot això passa, en teoria hem obert el fitxer del nostre procés i estem garantits que no canviarà.FWIW un munt d'això es copia històricament de libstd, de manera que aquesta és la meva millor interpretació del que estava passant.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Això viu a la memòria estàtica perquè puguem retornar-la ..
                static mut BUF: [i8; N] = [0; N];
                // ... i això viu a la pila ja que és temporal
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // fuga intencionadament `handle` aquí perquè tenir aquest obert hauria de preservar el nostre bloqueig en aquest nom de fitxer.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Volem retornar una llesca que finalitzi amb nul・litat, de manera que si tot s'ha omplert i és igual a la longitud total, equivaleu a fallada.
                //
                //
                // En cas contrari, quan torneu a l'èxit, assegureu-vos que el byte nul està inclòs a la part.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // actualment, els errors de traça posterior s`escombren sota la catifa
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Truqueu a l'API `backtrace_syminfo` que (a partir de la lectura del codi) hauria de trucar a `syminfo_cb` exactament una vegada (o fallar amb un error presumiblement).
    // Després en gestionem més dins del `syminfo_cb`.
    //
    // Tingueu en compte que ho fem ja que `syminfo` consultarà la taula de símbols, trobant noms de símbols encara que no hi hagi informació de depuració al binari.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}