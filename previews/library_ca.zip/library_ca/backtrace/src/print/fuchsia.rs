use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr pren una devolució de trucada que rebrà un punter dl_phdr_info per cada DSO que s`hagi enllaçat al procés.
    // dl_iterate_phdr també garanteix que l'enllaçador dinàmic estigui bloquejat de principi a fi de la iteració.
    // Si la devolució de trucada retorna un valor diferent de zero, la iteració finalitzarà abans.
    // 'data' es passarà com a tercer argument a la devolució de trucada de cada trucada.
    // 'size' dóna la mida del dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Hem d`analitzar l`identificador de compilació i algunes dades bàsiques de capçalera del programa, cosa que significa que també necessitem una mica de les especificacions d`ELF.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Ara hem de replicar, bit per bit, l`estructura del tipus dl_phdr_info que utilitza l`enllaç dinàmic actual de fucsia.
// Chromium també té aquest límit ABI i crashpad.
// Finalment, ens agradaria moure aquests casos per fer servir elf-search, però hauríem de proporcionar-ho a l'SDK i això encara no s'ha fet.
//
// Per tant, nosaltres (i ells) estem atrapats en haver d`utilitzar aquest mètode que incorre en un acoblament estret amb el libc fúcsia.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // No tenim cap manera de saber comprovar si e_phoff i e_phnum són vàlids.
    // libc ens ho hauria d'assegurar, de manera que és segur formar un segment aquí.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr representa una capçalera de programa ELF de 64 bits en la finalitat de l'arquitectura de destinació.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr representa una capçalera de programa ELF vàlida i el seu contingut.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // No tenim cap manera de comprovar si p_addr o p_memsz són vàlids.
    // El libc de Fuchsia analitza les notes primer, de manera que, en ser aquí, aquestes capçaleres han de ser vàlides.
    //
    // NoteIter no requereix que les dades subjacents siguin vàlides, però sí que els límits siguin vàlids.
    // Confiem que libc ens hagi assegurat que aquest és el nostre cas aquí.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// El tipus de nota per als identificadors de compilació.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr representa una capçalera de nota ELF en la finalitat de l'objectiu.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// La nota representa una nota ELF (capçalera + contingut).
// El nom es deixa com una porció u8 perquè no sempre és nul・la i rust facilita la comprovació de si els bytes coincideixen.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter us permet repetir de forma segura un segment de notes.
// Acaba tan aviat com es produeix un error o ja no hi ha notes.
// Si itereu sobre dades no vàlides, funcionarà com si no es trobessin notes.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // És una funció invariant que el punter i la mida donats denoten un rang vàlid de bytes que es poden llegir tots.
    // El contingut d'aquests bytes pot ser qualsevol, però l'interval ha de ser vàlid perquè sigui segur.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to alinea 'x' a l'alineació de "a" bytes suposant que 'to' és una potència de 2.
// Això segueix un patró estàndard en el codi d'anàlisi ELF C/C ++ on s'utilitza (x + to, 1) i -to.
// Rust no us permet negar la mida del vostre ús, així que faig servir
// Conversió de complement de 2 per recrear-ho.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 consumeix num bytes de la llesca (si n'hi ha) i, a més, garanteix que la llesca final estigui correctament alineada.
// Si el nombre de bytes sol・licitats és massa gran o no es pot reasignar el segment després perquè no hi ha prou bytes restants, no es retorna cap i no es modifica el segment.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Aquesta funció no té invariants reals que la persona que truca ha de mantenir, tret que potser 'bytes' s'hagi d'alinear per al rendiment (i en algunes arquitectures).
// Els valors dels camps Elf_Nhdr poden ser un disbarat, però aquesta funció no garanteix res.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Això és segur sempre que hi hagi prou espai i acabem de confirmar que a la declaració if anterior no hauria de ser insegur.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Tingueu en compte que sice_of: :<Elf_Nhdr>() sempre està alineat a 4 bytes.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Comproveu si hem arribat al final.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Transmutem un nhdr però considerem acuradament l'estructura resultant.
        // No confiem en els namesz o descsz i no prenem decisions insegures en funció del tipus.
        //
        // Per tant, fins i tot si traiem escombraries completes, hauríem d`estar segurs.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Indica que un segment és executable.
const PERM_X: u32 = 0b00000001;
/// Indica que un segment es pot escriure.
const PERM_W: u32 = 0b00000010;
/// Indica que es pot llegir un segment.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Representa un segment ELF en temps d'execució.
struct Segment {
    /// Proporciona l'adreça virtual d'execució dels continguts d'aquest segment.
    addr: usize,
    /// Dóna la mida de memòria del contingut d'aquest segment.
    size: usize,
    /// Proporciona l'adreça virtual del mòdul d'aquest segment amb el fitxer ELF.
    mod_rel_addr: usize,
    /// Ofereix els permisos que es troben al fitxer ELF.
    /// Aquests permisos no són necessàriament els permisos presents en temps d'execució.
    flags: Perm,
}

/// Permet fer una iteració per segments des d'un DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Representa un ELF DSO (Dynamic Shared Object).
/// Aquest tipus fa referència a les dades emmagatzemades al DSO real en lloc de fer la seva pròpia còpia.
struct Dso<'a> {
    /// L`enllaçador dinàmic sempre ens dóna un nom, fins i tot si el nom està buit.
    /// En el cas de l'executable principal, aquest nom estarà buit.
    /// En el cas d'un objecte compartit, serà el nom (vegeu DT_SONAME).
    name: &'a str,
    /// A Fuchsia, pràcticament tots els fitxers binaris tenen identificadors de compilació, però no és un requisit estricte.
    /// No hi ha manera de relacionar la informació DSO amb un fitxer ELF real després si no hi ha build_id, de manera que necessitem que cada DSO en tingui una aquí.
    ///
    /// Els DSO sense build_id s'ignoren.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Retorna un iterador per segments en aquest DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Aquests errors codifiquen els problemes que sorgeixen en analitzar informació sobre cada DSO.
///
enum Error {
    /// NameError significa que s'ha produït un error en convertir una cadena d'estil C en una cadena rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError significa que no hem trobat cap identificador de compilació.
    /// Això podria ser perquè el DSO no tenia cap identificador de compilació o perquè el segment que conté l'identificador de compilació estava mal format.
    ///
    BuildIDError,
}

/// Truca a 'dso' o 'error' per a cada DSO vinculat al procés per l'enllaçador dinàmic.
///
///
/// # Arguments
///
/// * `visitor` - Una DsoPrinter que tindrà un dels mètodes eats anomenats foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr assegura que info.name assenyalarà una ubicació vàlida.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Aquesta funció imprimeix el marcador del simbolitzador fúcsia per a tota la informació continguda en un DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}