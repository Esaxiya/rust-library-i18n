# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Una biblioteca per adquirir traces posteriors en temps d'execució per a Rust.
Aquesta biblioteca té com a objectiu millorar el suport de la biblioteca estàndard proporcionant una interfície programàtica amb la qual treballar, però també permet imprimir fàcilment la traça posterior actual, com el panics de libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Per capturar simplement una traça posterior i ajornar-la fins a un moment posterior, podeu utilitzar el tipus `Backtrace` de nivell superior.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

No obstant això, si voleu tenir més accés brut a la funcionalitat de rastreig real, podeu utilitzar les funcions `trace` i `resolve` directament.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Resoleu aquest punter d'instruccions amb un nom de símbol
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // continueu al següent fotograma
    });
}
```

# License

Aquest projecte està llicenciat amb qualsevol dels dos

 * Llicència Apache, versió 2.0, ([LICENSE-APACHE](LICENSE-APACHE) o http://www.apache.org/licenses/LICENSE-2.0)
 * Llicència MIT ([LICENSE-MIT](LICENSE-MIT) o http://opensource.org/licenses/MIT)

al vostre criteri.

### Contribution

Tret que expliqueu explícitament el contrari, qualsevol contribució que hàgiu enviat intencionadament per incloure-la a backtrace-rs, tal com es defineix a la llicència Apache-2.0, tindrà una llicència dual tal com es va indicar anteriorment, sense cap termini ni condició addicional.







