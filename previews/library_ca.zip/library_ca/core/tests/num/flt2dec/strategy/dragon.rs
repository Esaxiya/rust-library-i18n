use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri és massa lent
fn exact_sanity_test() {
    // Aquesta prova acaba executant-se el que només puc suposar que és un cas de la funció de biblioteca `exp2`, definit en qualsevol temps d'execució C que estem utilitzant.
    // Al VS 2013, aparentment, aquesta funció tenia un error, ja que aquesta prova falla quan s`enllaça, però amb VS 2015 l`error apareix solucionat, ja que la prova funciona bé.
    //
    // L'error sembla ser una diferència en el valor de retorn de `exp2(-1057)`, on a VS 2013 retorna un doble amb el patró de bits 0x2 i a VS 2015 retorna 0x20000.
    //
    //
    // De moment, només ignoreu aquesta prova completament a MSVC, ja que de totes maneres es prova en altres llocs i no estem súper interessats a provar la implementació de cada plataforma exp2.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}