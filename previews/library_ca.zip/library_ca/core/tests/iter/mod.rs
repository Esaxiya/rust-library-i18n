//! Note
//! ----
//! Probablement esteu veient aquest fitxer perquè afegiu una prova (o és possible que estigueu navegant, en aquest cas, hey allà!).
//!
//! El conjunt de proves iter es divideix en dos mòduls grans i alguns mòduls diversos més petits.Els dos grans mòduls són `adapters` i `traits`.
//!
//! `adapters` són per a mètodes a `Iterator` que adapten les dades a l'interior de l'iterador, ja sigui mitjançant l'emissió d'un altre iterador o la devolució d'un element de l'interior de l'iterador després d'executar un tancament de cada element.
//!
//!
//! `traits` són per a trait que estenen un `Iterator` (i el propi `Iterator` trait, que conté sobretot mètodes diversos).
//! En la seva major part, si una prova a `traits` utilitza un adaptador específic, s`hauria de moure al fitxer de prova d`aquest adaptador a `adapters`.
//!
//!
//!
//!
//!

mod adapters;
mod range;
mod sources;
mod traits;

use core::cell::Cell;
use core::convert::TryFrom;
use core::iter::*;

pub fn is_trusted_len<I: TrustedLen>(_: I) {}

#[test]
fn test_multi_iter() {
    let xs = [1, 2, 3, 4];
    let ys = [4, 3, 2, 1];
    assert!(xs.iter().eq(ys.iter().rev()));
    assert!(xs.iter().lt(xs.iter().skip(2)));
}

#[test]
fn test_counter_from_iter() {
    let it = (0..).step_by(5).take(10);
    let xs: Vec<isize> = FromIterator::from_iter(it);
    assert_eq!(xs, [0, 5, 10, 15, 20, 25, 30, 35, 40, 45]);
}

#[test]
fn test_functor_laws() {
    // identity:
    fn identity<T>(x: T) -> T {
        x
    }
    assert_eq!((0..10).map(identity).sum::<usize>(), (0..10).sum());

    // composition:
    fn f(x: usize) -> usize {
        x + 3
    }
    fn g(x: usize) -> usize {
        x * 2
    }
    fn h(x: usize) -> usize {
        g(f(x))
    }
    assert_eq!((0..10).map(f).map(g).sum::<usize>(), (0..10).map(h).sum());
}

#[test]
fn test_monad_laws_left_identity() {
    fn f(x: usize) -> impl Iterator<Item = usize> {
        (0..10).map(move |y| x * y)
    }
    assert_eq!(once(42).flat_map(f.clone()).sum::<usize>(), f(42).sum());
}

#[test]
fn test_monad_laws_right_identity() {
    assert_eq!((0..10).flat_map(|x| once(x)).sum::<usize>(), (0..10).sum());
}

#[test]
fn test_monad_laws_associativity() {
    fn f(x: usize) -> impl Iterator<Item = usize> {
        0..x
    }
    fn g(x: usize) -> impl Iterator<Item = usize> {
        (0..x).rev()
    }
    assert_eq!(
        (0..10).flat_map(f).flat_map(g).sum::<usize>(),
        (0..10).flat_map(|x| f(x).flat_map(g)).sum::<usize>()
    );
}

#[test]
pub fn extend_for_unit() {
    let mut x = 0;
    {
        let iter = (0..5).map(|_| {
            x += 1;
        });
        ().extend(iter);
    }
    assert_eq!(x, 5);
}