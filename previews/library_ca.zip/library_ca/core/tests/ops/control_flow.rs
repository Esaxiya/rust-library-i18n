use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Aquesta no és una superfície estable, però ajuda a mantenir `?` barat entre ells, fins i tot si LLVM no sempre pot aprofitar-la ara mateix.
    //
    // (Malauradament el resultat i l'opció són inconsistents, de manera que ControlFlow no pot coincidir amb tots dos).

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}