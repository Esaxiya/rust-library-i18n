//! Aquest mòdul implementa el `Any` trait, que permet escriure dinàmicament qualsevol tipus `'static` mitjançant la reflexió en temps d'execució.
//!
//! `Any` es pot utilitzar per obtenir un `TypeId` i té més funcions quan s`utilitza com a objecte trait.
//! Com a `&dyn Any` (un objecte trait manllevat), té els mètodes `is` i `downcast_ref` per comprovar si el valor contingut és d`un tipus determinat i obtenir una referència al valor intern com a tipus.
//! Com a `&mut dyn Any`, també hi ha el mètode `downcast_mut`, per obtenir una referència mutable al valor intern.
//! `Box<dyn Any>` afegeix el mètode `downcast`, que intenta convertir-lo en un `Box<T>`.
//! Consulteu la documentació [`Box`] per obtenir més informació.
//!
//! Tingueu en compte que `&dyn Any` es limita a provar si un valor és d`un tipus concret concret i no es pot utilitzar per provar si un tipus implementa un trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Punters intel・ligents i `dyn Any`
//!
//! Un comportament que cal tenir en compte quan s`utilitza `Any` com a objecte trait, especialment amb tipus com `Box<dyn Any>` o `Arc<dyn Any>`, és que simplement trucant `.type_id()` al valor es produirà el `TypeId` del *contenidor*, no l`objecte trait subjacent.
//!
//! Això es pot evitar convertint el punter intel・ligent en un `&dyn Any`, que retornarà el `TypeId` de l'objecte.
//! Per exemple:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // És més probable que vulgueu això:
//! let actual_id = (&*boxed).type_id();
//! // ... que això:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Penseu en una situació en què volem tancar la sessió un valor que es passa a una funció.
//! Sabem el valor en què estem treballant implementa la depuració, però no en sabem el tipus concret.Volem donar un tractament especial a certs tipus: en aquest cas imprimir la longitud dels valors de la cadena abans del seu valor.
//! No sabem el tipus concret del nostre valor en el moment de la compilació, de manera que hem d`utilitzar la reflexió en temps d`execució.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Funció de registre per a qualsevol tipus que implementi la depuració.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Proveu de convertir el nostre valor en un `String`.
//!     // Si té èxit, volem generar la longitud de la cadena i el seu valor.
//!     // Si no, és un tipus diferent: només cal imprimir-lo sense adorns.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Aquesta funció vol tancar la sessió del seu paràmetre abans de treballar-hi.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... fes una altra feina
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Qualsevol trait
///////////////////////////////////////////////////////////////////////////////

/// Un trait per emular la mecanografia dinàmica.
///
/// La majoria dels tipus implementen `Any`.Tanmateix, qualsevol tipus que contingui una referència no "estàtica" no ho fa.
/// Consulteu el [module-level documentation][mod] per obtenir més detalls.
///
/// [mod]: crate::any
// Aquest trait no és insegur, tot i que confiem en els detalls específics de la funció `type_id` de la seva única aplicació en codi no segur (per exemple, `downcast`).Normalment, això seria un problema, però com que l`única implementació de `Any` és una implementació general, cap altre codi pot implementar `Any`.
//
// Podríem fer plausiblement aquest trait insegur-no causaria trencaments, ja que controlem totes les implementacions-, però decidim no fer-ho, ja que no és realment necessari i pot confondre els usuaris sobre la distinció de traits insegur i mètodes insegurs `type_id` encara seria segur de trucar, però és probable que vulguem indicar-ho com a tal a la documentació).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Obté el `TypeId` de `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Mètodes d'extensió per a qualsevol objecte trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Assegureu-vos que el resultat d'unir un fil, per exemple, es pugui imprimir i, per tant, utilitzar-lo amb `unwrap`.
// Finalment, pot ser que ja no siguin necessaris si l'enviament funciona amb un alt nivell.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Retorna `true` si el tipus de caixa és el mateix que `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Obteniu `TypeId` del tipus amb què s`instancia aquesta funció.
        let t = TypeId::of::<T>();

        // Obteniu `TypeId` del tipus a l'objecte trait (`self`).
        let concrete = self.type_id();

        // Compareu els dos "TypeId" sobre igualtat.
        t == concrete
    }

    /// Retorna alguna referència al valor en caixa si és del tipus `T` o `None` si no ho és.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SEGURETAT: només hem comprovat si apuntem al tipus correcte i en què podem confiar
            // que comproveu la seguretat de la memòria perquè hem implementat Any per a tots els tipus;no poden existir altres implements, ja que entrarien en conflicte amb els nostres impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Retorna alguna referència mutable al valor en caixa si és del tipus `T` o `None` si no ho és.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SEGURETAT: només hem comprovat si apuntem al tipus correcte i en què podem confiar
            // que comproveu la seguretat de la memòria perquè hem implementat Any per a tots els tipus;no poden existir altres implements, ja que entrarien en conflicte amb els nostres impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Reenviament al mètode definit al tipus `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Reenviament al mètode definit al tipus `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Reenviament al mètode definit al tipus `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Reenviament al mètode definit al tipus `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Reenviament al mètode definit al tipus `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Reenviament al mètode definit al tipus `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID i els seus mètodes
///////////////////////////////////////////////////////////////////////////////

/// Un `TypeId` representa un identificador únic global per a un tipus.
///
/// Cada `TypeId` és un objecte opac que no permet inspeccionar el que hi ha dins, però sí que permet operacions bàsiques com la clonació, la comparació, la impressió i la visualització.
///
///
/// Actualment, un `TypeId` només està disponible per als tipus que s`atribueixen a `'static`, però aquesta limitació es pot eliminar a future.
///
/// Tot i que `TypeId` implementa `Hash`, `PartialOrd` i `Ord`, val la pena assenyalar que els hashs i l`ordenació variaran entre les versions de Rust.
/// Compte amb confiar en ells dins del vostre codi.
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Retorna el `TypeId` del tipus amb què s'ha instanciat aquesta funció genèrica.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Retorna el nom d'un tipus com a segment de cadena.
///
/// # Note
///
/// Està pensat per a ús diagnòstic.
/// No s'especifica el contingut i el format exactes de la cadena retornada, a part de ser una descripció del millor esforç.
/// Per exemple, entre les cadenes que podria retornar `type_name::<Option<String>>()` hi ha `"Option<String>"` i `"std::option::Option<std::string::String>"`.
///
///
/// La cadena retornada no s'ha de considerar un identificador únic d'un tipus, ja que diversos tipus poden assignar-se al mateix nom de tipus.
/// De la mateixa manera, no hi ha cap garantia que totes les parts d'un tipus apareixeran a la cadena retornada: per exemple, els especificadors de vida no estan inclosos actualment.
/// A més, la sortida pot variar entre les versions del compilador.
///
/// La implementació actual utilitza la mateixa infraestructura que el diagnòstic del compilador i el debuginfo, però això no està garantit.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Retorna el nom del tipus de valor apuntat com a segment de cadena.
/// És el mateix que `type_name::<T>()`, però es pot utilitzar quan el tipus de variable no està fàcilment disponible.
///
/// # Note
///
/// Està pensat per a ús diagnòstic.El contingut exacte i el format de la cadena no s`especifiquen, a part de ser una descripció del millor esforç del tipus.
/// Per exemple, `type_name_of_val::<Option<String>>(None)` pot retornar `"Option<String>"` o `"std::option::Option<std::string::String>"`, però no `"foobar"`.
///
/// A més, la sortida pot variar entre les versions del compilador.
///
/// Aquesta funció no resol els objectes trait, el que significa que `type_name_of_val(&7u32 as &dyn Debug)` pot retornar `"dyn Debug"`, però no `"u32"`.
///
/// El nom del tipus no s'ha de considerar un identificador únic d'un tipus;
/// diversos tipus poden compartir el mateix nom de tipus.
///
/// La implementació actual utilitza la mateixa infraestructura que el diagnòstic del compilador i el debuginfo, però això no està garantit.
///
/// # Examples
///
/// Imprimeix els tipus enters i flotants per defecte.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}