//! Conversions de personatges.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Converteix un `u32` en un `char`.
///
/// Tingueu en compte que tots els [`char`] són vàlids [`u32`] i es poden convertir en un amb
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Tanmateix, el contrari no és cert: no tots els [`u32`] vàlids són vàlids [`char`].
/// `from_u32()` retornarà `None` si l'entrada no és un valor vàlid per a un [`char`].
///
/// Per obtenir una versió no segura d'aquesta funció que ignora aquestes comprovacions, consulteu [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Retornant `None` quan l'entrada no és un [`char`] vàlid:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Converteix un `u32` en un `char`, ignorant la validesa.
///
/// Tingueu en compte que tots els [`char`] són vàlids [`u32`] i es poden convertir en un amb
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Tanmateix, el contrari no és cert: no tots els [`u32`] vàlids són vàlids [`char`].
/// `from_u32_unchecked()` ignorarà això i es llançarà a cegues a [`char`], creant possiblement un de no vàlid.
///
///
/// # Safety
///
/// Aquesta funció no és segura, ja que pot construir valors `char` no vàlids.
///
/// Per obtenir una versió segura d'aquesta funció, consulteu la funció [`from_u32`].
///
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // SEGURETAT: la persona que truca ha de garantir que `i` és un valor de caràcter vàlid.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Converteix un [`char`] en un [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Converteix un [`char`] en un [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // El caràcter es converteix al valor del punt de codi i, a continuació, s`estén a 64 bits.
        // Vegeu [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Converteix un [`char`] en un [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // El caràcter es converteix al valor del punt de codi i, a continuació, s`estén a 128 bits.
        // Vegeu [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Assigna un byte en 0x00 ..=0xFF a un `char` el punt de codi del qual té el mateix valor, en U + 0000 ..=U + 00FF.
///
/// Unicode està dissenyat de manera que això efectivament descodifica els bytes amb la codificació de caràcters que IANA anomena ISO-8859-1.
/// Aquesta codificació és compatible amb ASCII.
///
/// Tingueu en compte que això és diferent del ISO/IEC 8859-1 aka
/// ISO 8859-1 (amb un guionet menys), que deixa alguns valors de byte "blanks" que no estan assignats a cap caràcter.
/// ISO-8859-1 (el IANA) els assigna als codis de control C0 i C1.
///
/// Tingueu en compte que *també* és diferent del Windows-1252 també conegut com
/// pàgina de codis 1252, que és un superconjunt ISO/IEC 8859-1 que assigna alguns (no tots!) espais en blanc a la puntuació i diversos caràcters llatins.
///
/// Per confondre encara més les coses, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` i `windows-1252` són tots els àlies d`un superconjunt de Windows-1252 que omple els espais en blanc amb els codis de control C0 i C1 corresponents.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Converteix un [`u8`] en un [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Un error que es pot tornar en analitzar un caràcter.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // SEGURETAT: s'ha comprovat que és un valor unicode legal
            Ok(unsafe { transmute(i) })
        }
    }
}

/// El tipus d'error es torna quan falla la conversió de u32 a caràcters.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Converteix un dígit del radi donat en un `char`.
///
/// Un 'radix' aquí de vegades també s`anomena 'base'.
/// Un radi de dos indica un nombre binari, un radi de deu, decimal i un radi de setze, hexadecimal, per donar alguns valors comuns.
///
/// S'admeten radis arbitraris.
///
/// `from_digit()` retornarà `None` si l'entrada no és un dígit al radi donat.
///
/// # Panics
///
/// Panics si se li dóna un radi superior a 36.
///
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // El decimal 11 és un sol dígit a la base 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Retornant `None` quan l'entrada no és un dígit:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Passant una ràdio gran, provocant un panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}