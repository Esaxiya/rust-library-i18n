//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// El punt de codi més vàlid que pot tenir un `char`.
    ///
    /// Un `char` és un [Unicode Scalar Value], el que significa que és un [Code Point], però només els que es troben dins d`un interval determinat.
    /// `MAX` és el punt de codi vàlid més alt que és un [Unicode Scalar Value] vàlid.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () s'utilitza a Unicode per representar un error de descodificació.
    ///
    /// Pot ocórrer, per exemple, quan es donen bytes UTF-8 mal formats a [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// La versió de [Unicode](http://www.unicode.org/) en què es basen les parts Unicode dels mètodes `char` i `str`.
    ///
    /// Les noves versions d'Unicode es publiquen regularment i, posteriorment, s'actualitzen tots els mètodes de la biblioteca estàndard en funció d'Unicode.
    /// Per tant, el comportament d`alguns mètodes `char` i `str` i el valor d`aquesta constant canvia al llarg del temps.
    /// Això *no* es considera un canvi decisiu.
    ///
    /// L'esquema de numeració de versions s'explica a [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Crea un iterador sobre els punts de codi codificats UTF-16 a `iter`, retornant els substituts no aparellats com a `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Es pot obtenir un descodificador amb pèrdues substituint els resultats `Err` pel caràcter de reemplaçament:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Converteix un `u32` en un `char`.
    ///
    /// Tingueu en compte que tots els `char`s són vàlids [`u32`] i es poden convertir en un
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Tanmateix, el contrari no és cert: no tots els [`u32`] vàlids són`char`s vàlids.
    /// `from_u32()` retornarà `None` si l'entrada no és un valor vàlid per a un `char`.
    ///
    /// Per obtenir una versió no segura d'aquesta funció que ignora aquestes comprovacions, consulteu [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Retornant `None` quan l'entrada no és un `char` vàlid:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Converteix un `u32` en un `char`, ignorant la validesa.
    ///
    /// Tingueu en compte que tots els `char`s són vàlids [`u32`] i es poden convertir en un
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Tanmateix, el contrari no és cert: no tots els [`u32`] vàlids són`char`s vàlids.
    /// `from_u32_unchecked()` ignorarà això i es llançarà a cegues a `char`, creant possiblement un de no vàlid.
    ///
    ///
    /// # Safety
    ///
    /// Aquesta funció no és segura, ja que pot construir valors `char` no vàlids.
    ///
    /// Per obtenir una versió segura d'aquesta funció, consulteu la funció [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // SEGURETAT: el contractant de seguretat ha de ser confirmat per la persona que truca.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Converteix un dígit del radi donat en un `char`.
    ///
    /// Un 'radix' aquí de vegades també s`anomena 'base'.
    /// Un radi de dos indica un nombre binari, un radi de deu, decimal i un radi de setze, hexadecimal, per donar alguns valors comuns.
    ///
    /// S'admeten radis arbitraris.
    ///
    /// `from_digit()` retornarà `None` si l'entrada no és un dígit al radi donat.
    ///
    /// # Panics
    ///
    /// Panics si se li dóna un radi superior a 36.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // El decimal 11 és un sol dígit a la base 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Retornant `None` quan l'entrada no és un dígit:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Passant una ràdio gran, provocant un panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Comprova si un `char` és un dígit del radi donat.
    ///
    /// Un 'radix' aquí de vegades també s`anomena 'base'.
    /// Un radi de dos indica un nombre binari, un radi de deu, decimal i un radi de setze, hexadecimal, per donar alguns valors comuns.
    ///
    /// S'admeten radis arbitraris.
    ///
    /// En comparació amb [`is_numeric()`], aquesta funció només reconeix els caràcters `0-9`, `a-z` i `A-Z`.
    ///
    /// 'Digit' es defineix com a només els caràcters següents:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Per obtenir una comprensió més completa de 'digit', vegeu [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics si se li dóna un radi superior a 36.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Passant una ràdio gran, provocant un panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Converteix un `char` en un dígit del radi donat.
    ///
    /// Un 'radix' aquí de vegades també s`anomena 'base'.
    /// Un radi de dos indica un nombre binari, un radi de deu, decimal i un radi de setze, hexadecimal, per donar alguns valors comuns.
    ///
    /// S'admeten radis arbitraris.
    ///
    /// 'Digit' es defineix com a només els caràcters següents:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Retorna `None` si l `char` no fa referència a cap dígit del radi donat.
    ///
    /// # Panics
    ///
    /// Panics si se li dóna un radi superior a 36.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// En passar un dígit, es produeix un error:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Passant una ràdio gran, provocant un panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // el codi es divideix aquí per millorar la velocitat d'execució en casos en què l `radix` és constant i és inferior o igual a 10
        //
        let val = if likely(radix <= 10) {
            // Si no és un dígit, es crearà un nombre superior a radix.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Retorna un iterador que produeix la fugida hexadecimal Unicode d'un personatge com a `char`s.
    ///
    /// Això escaparà dels caràcters amb la sintaxi Rust de la forma `\u{NNNNNN}` on `NNNNNN` és una representació hexadecimal.
    ///
    ///
    /// # Examples
    ///
    /// Com a iterador:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilitzant `println!` directament:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Tots dos són equivalents a:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Utilitzant `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 garanteix que per a c==0 el codi calcula que s'hauria d'imprimir un dígit i (que és el mateix) evita el flux inferior (31, 32)
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // l`índex del dígit hexadecimal més significatiu
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Una versió ampliada de `escape_debug` que opcionalment permet escapar dels punts de codi Extended Grapheme.
    /// Això ens permet formatar millor els caràcters com les marques sense espaiat quan es troben al començament d'una cadena.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Retorna un iterador que proporciona el codi d'escapament literal d'un caràcter com a `char`s.
    ///
    /// Això escaparà dels caràcters similars a les implementacions `Debug` de `str` o `char`.
    ///
    ///
    /// # Examples
    ///
    /// Com a iterador:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilitzant `println!` directament:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Tots dos són equivalents a:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Utilitzant `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Retorna un iterador que proporciona el codi d'escapament literal d'un caràcter com a `char`s.
    ///
    /// El valor per defecte es tria amb un biaix cap a la producció de literals que siguin legals en diversos idiomes, inclosos els idiomes C++ 11 i similars de la família C.
    /// Les regles exactes són:
    ///
    /// * La pestanya s'escapa com a `\t`.
    /// * La devolució del carro s`escapa com a `\r`.
    /// * L'alimentació de línia s'escapa com a `\n`.
    /// * El pressupost únic s'escapa com a `\'`.
    /// * La doble cita s'escapa com a `\"`.
    /// * La barra invertida s'escapa com a `\\`.
    /// * No s'escapa cap caràcter de l'interior "ASCII imprimible" `0x20` .. `0x7e` inclòs.
    /// * La resta de caràcters tenen escapes hexadecimals Unicode;vegeu [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Com a iterador:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilitzant `println!` directament:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Tots dos són equivalents a:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Utilitzant `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Retorna el nombre de bytes que necessitaria aquest `char` si es codifica a UTF-8.
    ///
    /// Aquest nombre de bytes està sempre entre 1 i 4, inclosos.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// El tipus `&str` garanteix que el seu contingut és UTF-8 i, per tant, podem comparar la longitud que trigaria si cada punt de codi es representés com un `char` enfront del mateix `&str`:
    ///
    ///
    /// ```
    /// // com a caràcters
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // tots dos es poden representar com a tres bytes
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // com a &str, aquests dos estan codificats en UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // podem veure que triguen sis bytes en total ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... igual que el &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Retorna el nombre d'unitats de codi de 16 bits que necessitaria aquest `char` si es codifiquen en UTF-16.
    ///
    ///
    /// Consulteu la documentació de [`len_utf8()`] per obtenir més informació sobre aquest concepte.
    /// Aquesta funció és un mirall, però per a UTF-16 en lloc de UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Codifica aquest caràcter com a UTF-8 al buffer de bytes proporcionat i, a continuació, retorna la subdivisió del buffer que conté el caràcter codificat.
    ///
    ///
    /// # Panics
    ///
    /// Panics si el buffer no és prou gran.
    /// Un buffer de longitud quatre és prou gran per codificar qualsevol `char`.
    ///
    /// # Examples
    ///
    /// En tots dos exemples, 'ß' necessita dos bytes per codificar.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Un buffer massa petit:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // SEGURETAT: `char` no és un substitut, per tant, és vàlid UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Codifica aquest caràcter com a UTF-16 a la memòria intermèdia `u16` proporcionada i, a continuació, retorna la subdivisió de la memòria intermèdia que conté el caràcter codificat.
    ///
    ///
    /// # Panics
    ///
    /// Panics si el buffer no és prou gran.
    /// Una memòria intermèdia de longitud 2 és prou gran per codificar qualsevol `char`.
    ///
    /// # Examples
    ///
    /// En tots dos exemples, '𝕊' necessita dos `u16` per codificar.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Un buffer massa petit:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Retorna `true` si aquest `char` té la propietat `Alphabetic`.
    ///
    /// `Alphabetic` es descriu al capítol 4 (Propietats del caràcter) de l [Unicode Standard] i s'especifica a l [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // l'amor és moltes coses, però no és alfabètic
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Retorna `true` si aquest `char` té la propietat `Lowercase`.
    ///
    /// `Lowercase` es descriu al capítol 4 (Propietats del caràcter) de l [Unicode Standard] i s'especifica a l [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Els diversos scripts i puntuacions xineses no tenen majúscules i minúscules, i així:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Retorna `true` si aquest `char` té la propietat `Uppercase`.
    ///
    /// `Uppercase` es descriu al capítol 4 (Propietats del caràcter) de l [Unicode Standard] i s'especifica a l [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Els diversos scripts i puntuacions xineses no tenen majúscules i minúscules, i així:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Retorna `true` si aquest `char` té la propietat `White_Space`.
    ///
    /// `White_Space` s'especifica a l [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // un espai ininterromput
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Retorna `true` si aquest `char` compleix [`is_alphabetic()`] o [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Retorna `true` si aquest `char` té la categoria general per als codis de control.
    ///
    /// Els codis de control (punts de codi amb la categoria general de `Cc`) es descriuen al capítol 4 (Propietats del caràcter) del [Unicode Standard] i s`especifiquen al [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// // U + 009C, TERMINADOR DE CORDES
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Retorna `true` si aquest `char` té la propietat `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` es descriu a [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] i s'especifica a [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Retorna `true` si aquest `char` té una de les categories generals de números.
    ///
    /// Les categories generals de nombres (`Nd` per a dígits decimals, `Nl` per a caràcters numèrics semblants a lletres i `No` per a altres caràcters numèrics) s`especifiquen a [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Retorna un iterador que proporciona el mapatge en minúscula d'aquest `char` com a un o més
    /// `char`s.
    ///
    /// Si aquest `char` no té una assignació en minúscules, l'iterador produeix el mateix `char`.
    ///
    /// Si aquest `char` té una assignació minúscula un a un donada pel [Unicode Character Database][ucd] [`UnicodeData.txt`], l'iterador produeix aquest `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Si aquest `char` requereix consideracions especials (per exemple, múltiples `char`s) l'iterador produeix els`char` (s) donats per [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Aquesta operació realitza un mapatge incondicional sense adaptar-lo.És a dir, la conversió és independent del context i del llenguatge.
    ///
    /// Al [Unicode Standard], el capítol 4 (Propietats del caràcter) tracta l'assignació de casos en general i el capítol 3 (Conformance) tracta l'algorisme per defecte per a la conversió de casos.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Com a iterador:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilitzant `println!` directament:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Tots dos són equivalents a:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Utilitzant `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // De vegades, el resultat és més d`un personatge:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Els caràcters que no tenen majúscules ni minúscules es converteixen en ells mateixos.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Retorna un iterador que proporciona el mapatge en majúscules d'aquest `char` com a un o més
    /// `char`s.
    ///
    /// Si aquest `char` no té una assignació en majúscules, l'iterador produeix el mateix `char`.
    ///
    /// Si aquest `char` té una assignació en majúscules un a un donada per l [Unicode Character Database][ucd] [`UnicodeData.txt`], l'iterador produeix aquest `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Si aquest `char` requereix consideracions especials (per exemple, múltiples `char`s) l'iterador produeix els`char` (s) donats per [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Aquesta operació realitza un mapatge incondicional sense adaptar-lo.És a dir, la conversió és independent del context i del llenguatge.
    ///
    /// Al [Unicode Standard], el capítol 4 (Propietats del caràcter) tracta l'assignació de casos en general i el capítol 3 (Conformance) tracta l'algorisme per defecte per a la conversió de casos.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Com a iterador:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilitzant `println!` directament:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Tots dos són equivalents a:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Utilitzant `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // De vegades, el resultat és més d`un personatge:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Els caràcters que no tenen majúscules ni minúscules es converteixen en ells mateixos.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Nota sobre la configuració regional
    ///
    /// En turc, l'equivalent de 'i' en llatí té cinc formes en lloc de dues:
    ///
    /// * 'Dotless': I/ı, de vegades escrit ï
    /// * 'Dotted': İ/i
    ///
    /// Tingueu en compte que el 'i' amb punts minúsculs és el mateix que el llatí.Per tant:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// El valor de `upper_i` aquí es basa en l'idioma del text: si estem a `en-US`, hauria de ser `"I"`, però si estem a `tr_TR`, hauria de ser `"İ"`.
    /// `to_uppercase()` no ho té en compte, i per tant:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// es manté en diversos idiomes.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Comprova si el valor està dins de l'interval ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Fa una còpia del valor en l'equivalent en majúscules ASCII.
    ///
    /// Les lletres ASCII 'a' a 'z' s`assignen a 'A' a 'Z', però les lletres que no són ASCII no canvien.
    ///
    /// Per posar en majúscules el valor al seu lloc, utilitzeu [`make_ascii_uppercase()`].
    ///
    /// Per utilitzar majúscules caràcters ASCII a més de caràcters que no siguin ASCII, utilitzeu [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Fa una còpia del valor en l'equivalent en minúscules ASCII.
    ///
    /// Les lletres ASCII 'A' a 'Z' s`assignen a 'a' a 'z', però les lletres que no són ASCII no canvien.
    ///
    /// Per reduir el valor al seu lloc, utilitzeu [`make_ascii_lowercase()`].
    ///
    /// Per escriure en minúscules caràcters ASCII a més de caràcters no ASCII, utilitzeu [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Comprova que dos valors no coincideixin amb majúscules i minúscules ASCII.
    ///
    /// Equival a `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Converteix aquest tipus al seu equivalent en majúscules ASCII.
    ///
    /// Les lletres ASCII 'a' a 'z' s`assignen a 'A' a 'Z', però les lletres que no són ASCII no canvien.
    ///
    /// Per retornar un valor en majúscula nou sense modificar-ne l'existent, utilitzeu [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Converteix aquest tipus al seu equivalent en minúscules ASCII.
    ///
    /// Les lletres ASCII 'A' a 'Z' s`assignen a 'a' a 'z', però les lletres que no són ASCII no canvien.
    ///
    /// Per tornar un valor en minúscula nou sense modificar-ne l'existent, utilitzeu [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Comprova si el valor és un caràcter alfabètic ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' o
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Comprova si el valor és un caràcter en majúscula ASCII:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Comprova si el valor és un caràcter en minúscula ASCII:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Comprova si el valor és un caràcter alfanumèric ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' o
    /// - U + 0061 'a' ..=U + 007A 'z' o
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Comprova si el valor és un dígit decimal ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Comprova si el valor és un dígit hexadecimal ASCII:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9' o
    /// - U + 0041 'A' ..=U + 0046 'F' o
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Comprova si el valor és un caràcter de puntuació ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /` o
    /// - U + 003A ..=U + 0040 `: ; < = > ? @` o
    /// - U + 005B ..=U + 0060 "[\] ^ _` `` o
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Comprova si el valor és un caràcter gràfic ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Comprova si el valor és un caràcter d'espai en blanc ASCII:
    /// U + 0020 SPACE, U + 0009 TAULA HORITZONTAL, U + 000A LÍNIA D'ALIMENTACIÓ, U + 000C FORMAL D'ALIMENTACIÓ, O U + 000D TORNADA DE CARRET.
    ///
    /// Rust utilitza el [definition of ASCII whitespace][infra-aw] de WhatWG Infra Standard.Hi ha diverses definicions d`ús ampli.
    /// Per exemple, [the POSIX locale][pct] inclou U + 000B TAB VERTICAL així com tots els caràcters anteriors, però - des de la mateixa especificació- [la regla predeterminada per a "field splitting" a Bourne shell][bfs] considera *només* ESPAI, TAB HORITZONTAL i LINE FEED com a espai en blanc.
    ///
    ///
    /// Si esteu escrivint un programa que processarà un format de fitxer existent, comproveu quina és la definició d`aquest espai en blanc abans d`utilitzar aquesta funció.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Comprova si el valor és un caràcter de control ASCII:
    /// U + 0000 NUL ..=U + 001F SEPARADOR D'UNITATS o U + 007F SUPRIM.
    /// Tingueu en compte que la majoria de caràcters en blanc ASCII són caràcters de control, però SPACE no.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Codifica un valor u32 brut com a UTF-8 al buffer de bytes proporcionat i, a continuació, retorna la subclosa del buffer que conté el caràcter codificat.
///
///
/// A diferència de l `char::encode_utf8`, aquest mètode també gestiona els punts de codi del rang substitut.
/// (La creació d'un `char` en l'interval substitut és UB.) El resultat és vàlid [generalized UTF-8] però no vàlid UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics si el buffer no és prou gran.
/// Un buffer de longitud quatre és prou gran per codificar qualsevol `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Codifica un valor u32 brut com a UTF-16 al buffer `u16` proporcionat i, a continuació, retorna la subclosa del buffer que conté el caràcter codificat.
///
///
/// A diferència de l `char::encode_utf16`, aquest mètode també gestiona els punts de codi del rang substitut.
/// (Crear un `char` en el rang substitut és UB.)
///
/// # Panics
///
/// Panics si el buffer no és prou gran.
/// Una memòria intermèdia de longitud 2 és prou gran per codificar qualsevol `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SEGURETAT: cada braç comprova si hi ha prou bits per escriure-hi
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // El BMP cau
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Els avions complementaris es trenquen en substituts.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}