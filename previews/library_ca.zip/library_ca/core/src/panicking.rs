//! Suport de Panic per a libcore
//!
//! La biblioteca principal no pot definir el pànic, però sí *declara* el pànic.
//! Això vol dir que les funcions dins del libcore estan permeses a panic, però per ser útil, un crate amunt ha de definir el pànic perquè el libcore el pugui utilitzar.
//! La interfície actual per al pànic és:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Aquesta definició permet entrar en pànic amb qualsevol missatge general, però no permet fallar amb un valor `Box<Any>`.
//! (`PanicInfo` només conté un `&(dyn Any + Send)`, per al qual omplim un valor fictici a `PanicInfo: : internal_constructor`.) La raó d'això és que no es pot assignar libcore.
//!
//!
//! Aquest mòdul conté algunes altres funcions de pànic, però són només els elements de llenguatge necessaris per al compilador.Tots els panics es canalitzen mitjançant aquesta única funció.
//! El símbol real es declara mitjançant l'atribut `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// La implementació subjacent de la macro `panic!` de libcore quan no s'utilitza cap format.
#[cold]
// mai en línia, tret que panic_immediate_abort eviti el màxim inflació de codi als llocs de trucades
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // necessari per codegen per a panic en cas de desbordament i altres terminadors MIR `Assert`
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Utilitzeu Arguments::new_v1 en lloc de format_args! ("{}", Expr) per reduir potencialment la sobrecàrrega de la mida.
    // El format_args!La macro utilitza Display trait de str per escriure expr, que crida Formatter::pad, que ha de tenir cabuda la truncació de cadenes i el farciment (tot i que aquí no s'utilitza cap).
    //
    // L'ús de Arguments::new_v1 pot permetre al compilador ometre Formatter::pad del binari de sortida, estalviant fins a uns quants kilobytes.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // necessari per a panics avaluat constantment
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // necessari per codegen per a panic en accés OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// La implementació subjacent de la macro `panic!` de libcore quan s`utilitza el format.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // NOTA Aquesta funció mai no creua el límit FFI;es tracta d'una trucada Rust-to-Rust que es resol a la funció `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SEGURETAT: `panic_impl` es defineix en un codi Rust segur i, per tant, és segur trucar.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Funció interna per a macros `assert_eq!` i `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}