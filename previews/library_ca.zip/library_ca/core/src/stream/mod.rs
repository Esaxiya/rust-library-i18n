//! Iteració asíncrona composable.
//!
//! Si futures són valors asíncrons, els fluxos són iteradors asíncrons.
//! Si us heu trobat amb una col・lecció asíncrona d`alguna mena i necessiteu fer una operació amb els elements d`aquesta col・lecció, us trobareu ràpidament amb 'streams'.
//! Els fluxos s`utilitzen molt al codi idiomàtic asincrònic Rust, de manera que val la pena familiaritzar-se amb ells.
//!
//! Abans d`explicar-ne més, parlem de com s`estructura aquest mòdul:
//!
//! # Organization
//!
//! Aquest mòdul s`organitza en gran part per tipus:
//!
//! * [Traits] són la part principal: aquests traits defineixen quin tipus de corrents existeixen i què podeu fer amb ells.Els mètodes d`aquests traits val la pena dedicar-hi un temps d`estudi addicional.
//! * Les funcions proporcionen algunes maneres útils de crear fluxos bàsics.
//! * Les estructures solen ser els tipus de retorn dels diversos mètodes del traits d`aquest mòdul.Normalment voldreu veure el mètode que crea el `struct`, en lloc del `struct` en si.
//! Per obtenir més informació sobre per què, consulteu "[Implementing Stream](#implementation-stream)".
//!
//! [Traits]: #traits
//!
//! Això és!Anem a excavar a les rieres.
//!
//! # Stream
//!
//! El cor i l`ànima d`aquest mòdul és el [`Stream`] trait.El nucli de [`Stream`] té aquest aspecte:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! A diferència de `Iterator`, `Stream` fa una distinció entre el mètode [`poll_next`] que s'utilitza en implementar un `Stream` i un mètode (to-be-implemented) `next` que s'utilitza quan es consumeix un flux.
//!
//! Els consumidors de `Stream` només han de tenir en compte `next`, que quan es crida, retorna un future que produeix `Option<Stream::Item>`.
//!
//! El future retornat per `next` donarà `Some(Item)` sempre que hi hagi elements i, un cop s'hagin esgotat, donarà `None` per indicar que la iteració ha finalitzat.
//! Si esperem alguna cosa asíncrona per resoldre, el future esperarà fins que el flux estigui llest per tornar a cedir.
//!
//! Els fluxos individuals poden optar per reprendre la iteració i, per tant, trucar de nou a `next` pot provocar o no acabar `Some(Item)` en algun moment.
//!
//! La definició completa de [`Stream`] inclou també diversos mètodes, però són mètodes predeterminats, basats en [`poll_next`], de manera que els obteniu de forma gratuïta.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Implementació del flux
//!
//! Crear un flux propi implica dos passos: crear un `struct` per mantenir l'estat del flux i, després, implementar [`Stream`] per a aquest `struct`.
//!
//! Fem un flux anomenat `Counter` que compta de `1` a `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // En primer lloc, l`estructura:
//!
//! /// Un flux que compta d'un a cinc
//! struct Counter {
//!     count: usize,
//! }
//!
//! // volem que el nostre recompte comenci per un, així que afegim un mètode new() per ajudar-lo.
//! // Això no és estrictament necessari, però és convenient.
//! // Tingueu en compte que iniciem `count` a zero, veurem per què a la implementació `poll_next()`'s a continuació.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // A continuació, implementem `Stream` per al nostre `Counter`:
//!
//! impl Stream for Counter {
//!     // estarem comptant amb usize
//!     type Item = usize;
//!
//!     // poll_next() és l'únic mètode necessari
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Incrementeu el nostre recompte.Per això vam començar a zero.
//!         self.count += 1;
//!
//!         // Comproveu si hem acabat de comptar o no.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Els corrents són *mandrosos*.Això vol dir que només crear un flux no suposa una gran quantitat de _do_.Realment no passa res fins que truqueu al `next`.
//! De vegades, això és una font de confusió quan es crea un flux únicament pels seus efectes secundaris.
//! El compilador ens avisarà sobre aquest tipus de comportament:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;