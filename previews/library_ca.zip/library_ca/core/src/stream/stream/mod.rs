use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Una interfície per tractar amb iteradors asíncrons.
///
/// Aquest és el corrent principal trait.
/// Per obtenir més informació sobre el concepte de fluxos en general, consulteu el [module-level documentation].
/// En particular, és possible que vulgueu saber com fer servir [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// El tipus d`elements generats pel flux.
    type Item;

    /// Intenteu treure el següent valor d'aquest flux, registrant la tasca actual per al despertar si el valor encara no està disponible i torneu `None` si el flux s'esgota.
    ///
    /// # Valor de retorn
    ///
    /// Hi ha diversos valors de retorn possibles, cadascun dels quals indica un estat de flux diferent:
    ///
    /// - `Poll::Pending` significa que el següent valor d'aquest flux encara no està preparat.Les implementacions asseguraran que la tasca actual es notificarà quan el valor següent estigui a punt.
    ///
    /// - `Poll::Ready(Some(val))` significa que el flux ha produït amb èxit un valor, `val`, i pot produir altres valors en les trucades `poll_next` posteriors.
    ///
    /// - `Poll::Ready(None)` significa que el flux ha finalitzat i que no s'hauria de tornar a invocar `poll_next`.
    ///
    /// # Panics
    ///
    /// Un cop finalitzada una transmissió (`Ready(None)` from `poll_next`) retornat, tornar a trucar al mètode `poll_next` pot panic, bloquejar-se definitivament o provocar altres tipus de problemes; el `Stream` trait no exigeix cap efecte sobre els efectes d'aquesta trucada.
    ///
    /// No obstant això, com que el mètode `poll_next` no està marcat com a `unsafe`, s'apliquen les regles habituals de Rust: les trucades mai no han de provocar un comportament indefinit (corrupció de memòria, ús incorrecte de les funcions `unsafe` o similars), independentment de l'estat del flux.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Retorna els límits de la longitud restant del flux.
    ///
    /// En concret, `size_hint()` retorna una tupla on el primer element és el límit inferior i el segon element és el límit superior.
    ///
    /// La segona meitat de la tupla que es retorna és una [`Opció`]`<`[`usize`] `>>.
    /// Un [`None`] aquí significa que o bé no hi ha cap límit superior conegut, o bé el límit superior és més gran que [`usize`].
    ///
    /// # Notes d`implementació
    ///
    /// No s'aplica que una implementació de flux produeixi el nombre d'elements declarat.Un flux de buggy pot produir menys que el límit inferior o més que el límit superior dels elements.
    ///
    /// `size_hint()` està pensat principalment per utilitzar-se per a optimitzacions com la reserva d'espai per als elements del flux, però no s'ha de confiar en, per exemple, en ometre les comprovacions de límits en un codi no segur.
    /// Una implementació incorrecta de `size_hint()` no hauria de provocar violacions de la seguretat de la memòria.
    ///
    /// Dit això, la implementació hauria de proporcionar una estimació correcta, perquè en cas contrari seria una violació del protocol trait.
    ///
    /// La implementació per defecte retorna `(0,` ['Cap`]`)` que és correcte per a qualsevol transmissió.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}