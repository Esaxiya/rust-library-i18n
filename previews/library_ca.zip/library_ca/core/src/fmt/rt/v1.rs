//! Es tracta d`un mòdul intern utilitzat per l`ifmt!temps d'execució.Aquestes estructures s`emeten a matrius estàtics per precompilar cadenes de format abans del temps.
//!
//! Aquestes definicions són similars als seus equivalents `ct`, però difereixen en què es poden assignar estàticament i estan lleugerament optimitzades per al temps d'execució.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Possibles alineacions que es poden sol・licitar com a part d`una directiva de format.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Indicació que els continguts s`han d`alinear a l`esquerra.
    Left,
    /// Indicació que els continguts han d`estar alineats a la dreta.
    Right,
    /// Indicació que els continguts han d`estar alineats al centre.
    Center,
    /// No s'ha sol・licitat cap alineació.
    Unknown,
}

/// Utilitzat pels especificadors [width](https://doc.rust-lang.org/std/fmt/#width) i [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Especificat amb un número literal, emmagatzema el valor
    Is(usize),
    /// Especificat amb sintaxis `$` i `*`, emmagatzema l'índex a `args`
    Param(usize),
    /// Sense especificar
    Implied,
}