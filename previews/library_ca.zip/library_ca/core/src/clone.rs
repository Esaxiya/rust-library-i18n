//! El `Clone` trait per als tipus que no es poden "copiar implícitament".
//!
//! A Rust, alguns tipus simples són "implicitly copyable" i quan els assigneu o els passeu com a arguments, el receptor obtindrà una còpia, deixant el valor original al seu lloc.
//! Aquests tipus no requereixen assignació per copiar i no tenen finalitzadors (és a dir, no contenen capses de propietat ni implementen [`Drop`]), de manera que el compilador les considera barates i segures de copiar.
//!
//! Per a altres tipus, les còpies s`han de fer explícitament, per conveni, implementant el [`Clone`] trait i cridant el mètode [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Exemple bàsic d'ús:
//!
//! ```
//! let s = String::new(); // El tipus de cadena implementa el clon
//! let copy = s.clone(); // així el podem clonar
//! ```
//!
//! Per implementar fàcilment el clon trait, també podeu utilitzar `#[derive(Clone)]`.Exemple:
//!
//! ```
//! #[derive(Clone)] // afegim el clon trait a l`estructura de Morpheus
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // i ara el podem clonar!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Un trait comú per a la possibilitat de duplicar explícitament un objecte.
///
/// Difereix de [`Copy`] perquè [`Copy`] és implícit i extremadament econòmic, mentre que `Clone` sempre és explícit i pot ser o no car.
/// Per fer complir aquestes característiques, Rust no us permet reimplementar [`Copy`], però podeu reimplementar `Clone` i executar codi arbitrari.
///
/// Com que `Clone` és més general que [`Copy`], també podeu fer que qualsevol cosa que sigui [`Copy`] sigui `Clone`.
///
/// ## Derivable
///
/// Aquest trait es pot utilitzar amb `#[derive]` si tots els camps són `Clone`.La implementació `derive`d de [`Clone`] crida [`clone`] a cada camp.
///
/// [`clone`]: Clone::clone
///
/// Per a una estructura genèrica, `#[derive]` implementa `Clone` condicionalment afegint `Clone` lligat a paràmetres genèrics.
///
/// ```
/// // `derive` implementa Clone for Reading<T>quan T és Clon.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Com puc implementar `Clone`?
///
/// Els tipus [`Copy`] haurien de tenir una implementació trivial de `Clone`.Més formalment:
/// si `T: Copy`, `x: T` i `y: &T`, llavors `let x = y.clone();` és equivalent a `let x = *y;`.
/// Les implementacions manuals han de tenir cura de mantenir aquest invariant;no obstant això, el codi no segur no ha de confiar-hi per garantir la seguretat de la memòria.
///
/// Un exemple és una estructura genèrica que conté un punter de funció.En aquest cas, la implementació de `Clone` no es pot "derivar" d, però es pot implementar com:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Implementadors addicionals
///
/// A més de l [implementors listed below][impls], els tipus següents també implementen `Clone`:
///
/// * Tipus d'elements de funció (és a dir, els diferents tipus definits per a cada funció)
/// * Tipus de punter de funció (per exemple, `fn() -> i32`)
/// * Tipus de matriu, per a totes les mides, si el tipus d`element també implementa `Clone` (per exemple, `[i32; 123456]`)
/// * Tipus de tuples, si cada component també implementa `Clone` (per exemple, `()`, `(i32, bool)`)
/// * Tipus de tancament, si no capturen cap valor de l`entorn o si tots aquests valors capturats implementen `Clone` ells mateixos.
///   Tingueu en compte que les variables capturades per referència compartida sempre implementen `Clone` (fins i tot si el referent no ho fa), mentre que les variables capturades per referència mutable mai implementen `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Retorna una còpia del valor.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str implementa Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Realitza l'assignació de còpies des de `source`.
    ///
    /// `a.clone_from(&b)` és equivalent a la funcionalitat `a = b.clone()`, però es pot anul・lar per reutilitzar els recursos de `a` per evitar assignacions innecessàries.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Deriveu macro que genera un impl del trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): aquestes estructures són utilitzades únicament per#[derive] per afirmar que tots els components d'un tipus implementen Clon o Copy.
//
//
// Aquestes estructures no haurien d'aparèixer mai al codi d'usuari.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implementacions de `Clone` per a tipus primitius.
///
/// Les implementacions que no es poden descriure a Rust s`implementen a `traits::SelectionContext::copy_clone_conditions()` a `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Les referències compartides es poden clonar, però les referències mutables *no poden*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Les referències compartides es poden clonar, però les referències mutables *no poden*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}