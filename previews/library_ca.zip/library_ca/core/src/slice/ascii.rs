//! Operacions a ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Comprova si tots els bytes d'aquesta part es troben dins de l'interval ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Comprova que dues llesques no coincideixin amb majúscules i minúscules ASCII.
    ///
    /// Igual que `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, però sense assignar ni copiar temporals.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Converteix aquest segment al seu equivalent en majúscules ASCII al seu lloc.
    ///
    /// Les lletres ASCII 'a' a 'z' s`assignen a 'A' a 'Z', però les lletres que no són ASCII no canvien.
    ///
    /// Per retornar un valor en majúscula nou sense modificar-ne l'existent, utilitzeu [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Converteix aquest segment al seu equivalent ASCII en minúscula al lloc.
    ///
    /// Les lletres ASCII 'A' a 'Z' s`assignen a 'a' a 'z', però les lletres que no són ASCII no canvien.
    ///
    /// Per tornar un valor en minúscula nou sense modificar-ne l'existent, utilitzeu [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Retorna `true` si algun byte de la paraula `v` és noascii (>=128).
/// Enganxat de `../str/mod.rs`, que fa alguna cosa similar per a la validació de utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Prova ASCII optimitzada que farà servir operacions usize a la vegada en lloc d`operacions byte a la vegada (quan sigui possible).
///
/// L`algorisme que fem servir aquí és força senzill.Si `s` és massa curt, comprovem cada byte i acabem amb ell.D'una altra manera:
///
/// - Llegiu la primera paraula amb una càrrega no alineada.
/// - Alineeu el punter, llegiu les paraules següents fins acabar amb càrregues alineades.
/// - Llegiu l'últim `usize` de `s` amb una càrrega sense alinear.
///
/// Si alguna d'aquestes càrregues produeix alguna cosa per a la qual `contains_nonascii` (above) torna cert, llavors sabem que la resposta és falsa.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Si no guanyaríem res de la implementació de cada moment, tornem a un bucle escalar.
    //
    // També ho fem per a arquitectures on `size_of::<usize>()` no és suficient per alineament per a `usize`, perquè és un cas estrany de edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Sempre llegim la primera paraula sense alinear, el que significa que `align_offset` és
    // 0, tornaríem a llegir el mateix valor per a la lectura alineada.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SEGURETAT: Verifiquem `len < USIZE_SIZE` anterior.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Ho hem comprovat anteriorment, de manera implícita.
    // Tingueu en compte que `offset_to_aligned` és `align_offset` o `USIZE_SIZE`, tots dos es comproven explícitament més amunt.
    //
    debug_assert!(offset_to_aligned <= len);

    // SEGURETAT: word_ptr és el ptr usize (correctament alineat) que fem servir per llegir el fitxer
    // tros mitjà de la llesca.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` és l'índex de bytes de `word_ptr`, utilitzat per a comprovacions de final de bucle.
    let mut byte_pos = offset_to_aligned;

    // Comproveu la paranoia sobre l'alineació, ja que estem a punt de fer un munt de càrregues no alineades.
    // A la pràctica, això hauria de ser impossible excepte un error a `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Llegiu les paraules següents fins a l'última paraula alineada, excloent l'última paraula alineada per si mateixa que es realitzarà en la comprovació de la cua més tard, per assegurar-vos que la cua sempre és com a màxim `usize` a branch `byte_pos == len` addicional.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Comproveu el seny que la lectura està dins dels límits
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // I que es mantenen les nostres suposicions sobre `byte_pos`.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SEGURETAT: sabem que `word_ptr` està correctament alineat (a causa de
        // "align_offset"), i sabem que tenim prou bytes entre `word_ptr` i el final
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SEGURETAT: Sabem que `byte_pos <= len - USIZE_SIZE`, que vol dir això
        // després d'aquest `add`, `word_ptr` passarà com a màxim un darrere del final.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Comproveu el seny per assegurar-vos que realment només queda un `usize`.
    // Això ho hauria de garantir la nostra condició de bucle.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SEGURETAT: es basa en `len >= USIZE_SIZE`, que comprovem a l'inici.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}