//! Funcions gratuïtes per crear `&[T]` i `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Forma una llesca a partir d`un punter i d`una longitud.
///
/// L'argument `len` és el nombre de **elements**, no el nombre de bytes.
///
/// # Safety
///
/// El comportament no està definit si es infringeix alguna de les condicions següents:
///
/// * `data` ha de ser [valid] per a lectures de `len * mem::size_of::<T>()` de molts bytes i ha d'estar correctament alineat.Això significa en particular:
///
///     * L'interval de memòria d'aquesta part ha d'estar inclòs dins d'un sol objecte assignat.
///       Les llesques mai no poden abastar diversos objectes assignats.Vegeu [below](#incorrect-usage) per obtenir un exemple incorrecte que no es tingui en compte.
///     * `data` ha de ser nul i alineat fins i tot per a les llesques de longitud zero.
///     Una de les raons per això és que les optimitzacions de disseny d'enum poden dependre de que les referències (incloses les llesques de qualsevol longitud) estiguin alineades i no nul・les per distingir-les d'altres dades.
///     Podeu obtenir un punter que es pugui utilitzar com a `data` per a talls de longitud zero amb [`NonNull::dangling()`].
///
/// * `data` ha d'assenyalar els valors consecutius inicialitzats correctament de `len` del tipus `T`.
///
/// * La memòria a què fa referència la part retornada no s'ha de mutar durant la durada de la vida `'a`, excepte dins d'un `UnsafeCell`.
///
/// * La mida total `len * mem::size_of::<T>()` de la part no pot ser superior a `isize::MAX`.
///   Consulteu la documentació de seguretat de [`pointer::offset`].
///
/// # Caveat
///
/// La vida útil de la part retornada es dedueix del seu ús.
/// Per evitar un ús indegut accidental, es recomana vincular la vida útil a la vida útil de la font que sigui segura en el context, com ara proporcionant una funció d`ajuda que prengui la vida útil d`un valor d`amfitrió per al segment, o bé mitjançant una anotació explícita.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifestar un segment per a un sol element
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Ús incorrecte
///
/// La següent funció `join_slices` és **inadequada** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // L'afirmació anterior garanteix que `fst` i `snd` són contigus, però poden estar inclosos dins de _different allocated objects_, en aquest cas la creació d'aquest segment és un comportament indefinit.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` i `b` són diferents objectes assignats ...
///     let a = 42;
///     let b = 27;
///     // ... que, tanmateix, es pot presentar contigüament a la memòria: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Realitza la mateixa funcionalitat que [`from_raw_parts`], excepte que es retorna un segment modificable.
///
/// # Safety
///
/// El comportament no està definit si es infringeix alguna de les condicions següents:
///
/// * `data` ha de ser [valid] tant per a les lectures com per a les escriptures per a molts bytes `len * mem::size_of::<T>()`, i ha d'estar correctament alineat.Això significa en particular:
///
///     * L'interval de memòria d'aquesta part ha d'estar inclòs dins d'un sol objecte assignat.
///       Les llesques mai no poden abastar diversos objectes assignats.
///     * `data` ha de ser nul i alineat fins i tot per a les llesques de longitud zero.
///     Una de les raons per això és que les optimitzacions de disseny d'enum poden dependre de que les referències (incloses les llesques de qualsevol longitud) estiguin alineades i no nul・les per distingir-les d'altres dades.
///
///     Podeu obtenir un punter que es pugui utilitzar com a `data` per a talls de longitud zero amb [`NonNull::dangling()`].
///
/// * `data` ha d'assenyalar els valors consecutius inicialitzats correctament de `len` del tipus `T`.
///
/// * No es pot accedir a la memòria a la qual fa referència el segment retornat a través de cap altre punter (no derivat del valor de retorn) durant la durada de la vida `'a`.
///   Tant els accessos de lectura com d`escriptura estan prohibits.
///
/// * La mida total `len * mem::size_of::<T>()` de la part no pot ser superior a `isize::MAX`.
///   Consulteu la documentació de seguretat de [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Converteix una referència a T en un segment de longitud 1 (sense copiar).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Converteix una referència a T en un segment de longitud 1 (sense copiar).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}