//! Classificació de talls
//!
//! Aquest mòdul conté un algorisme d`ordenació basat en el quicksort d`Orson Peters que derrota patrons, publicat a: <https://github.com/orlp/pdqsort>
//!
//!
//! L`ordenació inestable és compatible amb libcore perquè no assigna memòria, a diferència de la nostra implementació d`ordenació estable.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Quan es deixa caure, còpies de `src` a `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SEGURETAT: Aquesta és una classe auxiliar.
        //          Consulteu el seu ús per obtenir la correcció.
        //          És a dir, cal assegurar-se que `src` i `dst` no se superposen tal com requereix `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Desplaça el primer element cap a la dreta fins que troba un element més gran o igual.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SEGURETAT: Les operacions no segures que es mostren a continuació inclouen la indexació sense comprovació limitada (`get_unchecked` i `get_unchecked_mut`)
    // i copiant la memòria (`ptr::copy_nonoverlapping`).
    //
    // a.Indexació:
    //  1. Hem comprovat la mida de la matriu a>=2.
    //  2. Tota la indexació que farem sempre és com a màxim entre {0 <= index < len}.
    //
    // b.Còpia de memòria
    //  1. Estem obtenint indicacions de referències que es garanteix que són vàlides.
    //  2. No es poden superposar perquè obtenim indicadors sobre els índexs de diferència de la porció.
    //     És a dir, `i` i `i-1`.
    //  3. Si la llesca està correctament alineada, els elements estan correctament alineats.
    //     És responsabilitat de la persona que truca assegurar-se que la llesca està correctament alineada.
    //
    // Vegeu els comentaris següents per obtenir més informació.
    unsafe {
        // Si els dos primers elements estan fora d`ordre ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Llegiu el primer element en una variable assignada a la pila.
            // Si una operació de comparació següent panics, `hole` es deixarà caure i tornarà a escriure l'element automàticament a la porció.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Mou l'element `i`-th un lloc cap a l'esquerra, desplaçant així el forat cap a la dreta.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` es deixa caure i, per tant, copia `tmp` al forat restant de `v`.
        }
    }
}

/// Desplaça l'últim element cap a l'esquerra fins que es troba amb un element més petit o igual.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SEGURETAT: Les operacions no segures que es mostren a continuació inclouen la indexació sense comprovació limitada (`get_unchecked` i `get_unchecked_mut`)
    // i copiant la memòria (`ptr::copy_nonoverlapping`).
    //
    // a.Indexació:
    //  1. Hem comprovat la mida de la matriu a>=2.
    //  2. Tota la indexació que farem sempre és com a màxim entre `0 <= index < len-1`.
    //
    // b.Còpia de memòria
    //  1. Estem obtenint indicacions de referències que es garanteix que són vàlides.
    //  2. No es poden superposar perquè obtenim indicadors sobre els índexs de diferència de la porció.
    //     És a dir, `i` i `i+1`.
    //  3. Si la llesca està correctament alineada, els elements estan correctament alineats.
    //     És responsabilitat de la persona que truca assegurar-se que la llesca està correctament alineada.
    //
    // Vegeu els comentaris següents per obtenir més informació.
    unsafe {
        // Si els dos darrers elements estan fora d'ordre ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Llegiu l'últim element en una variable assignada a la pila.
            // Si una operació de comparació següent panics, `hole` es deixarà caure i tornarà a escriure l'element automàticament a la porció.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Mou l'element `i`-th un lloc cap a la dreta, desplaçant així el forat cap a l'esquerra.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` es deixa caure i, per tant, copia `tmp` al forat restant de `v`.
        }
    }
}

/// Ordena parcialment una llesca canviant diversos elements fora d'ordre.
///
/// Retorna `true` si la secció s'ordena al final.Aquesta funció és *O*(*n*) en el pitjor dels casos.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Nombre màxim de parells adjacents fora d'ordre que es desplaçaran.
    const MAX_STEPS: usize = 5;
    // Si el segment és més curt que aquest, no canvieu cap element.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SEGURETAT: ja vam fer explícitament la comprovació de l'enllaç amb `i < len`.
        // Tota la nostra indexació posterior només es troba en el rang `0 <= index < len`
        unsafe {
            // Cerqueu el següent parell d'elements adjacents fora d'ordre.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Ja hem acabat?
        if i == len {
            return true;
        }

        // No canvieu els elements en matrius curts, ja que comporta un cost de rendiment.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Intercanvieu el parell d'elements trobats.Això els situa en un ordre correcte.
        v.swap(i - 1, i);

        // Desplaceu l'element més petit cap a l'esquerra.
        shift_tail(&mut v[..i], is_less);
        // Desplaceu l'element més gran cap a la dreta.
        shift_head(&mut v[i..], is_less);
    }

    // No s'ha aconseguit ordenar el segment en el nombre limitat de passos.
    false
}

/// Ordena una llesca mitjançant la classificació per inserció, que és el cas pitjor de *O*(*n*^ 2).
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Ordena `v` mitjançant un munt elevat, que garanteix *O*(*n*\*log(* n*)) en el pitjor dels casos.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Aquest munt binari respecta l'invariant `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Nens de `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Trieu el fill més gran.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Atureu-vos si l'invariant es manté a `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Canvieu `node` amb el fill més gran, moveu un pas cap avall i continueu tamisant.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Construeix el munt en temps lineal.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Apareix elements màxims del munt.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Particiona `v` en elements menors que `pivot`, seguits per elements majors o iguals a `pivot`.
///
///
/// Retorna el nombre d'elements més petit que `pivot`.
///
/// El particionament es realitza bloc per bloc per minimitzar el cost de les operacions de ramificació.
/// Aquesta idea es presenta al document [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Nombre d'elements d'un bloc típic.
    const BLOCK: usize = 128;

    // L'algorisme de partició repeteix els passos següents fins a la seva finalització:
    //
    // 1. Traça un bloc des del costat esquerre per identificar elements superiors o iguals al pivot.
    // 2. Traça un bloc des del costat dret per identificar elements més petits que el pivot.
    // 3. Intercanvieu els elements identificats entre el costat esquerre i el dret.
    //
    // Conservem les variables següents per a un bloc d'elements:
    //
    // 1. `block` - Nombre d'elements del bloc.
    // 2. `start` - Inicieu el punter a la matriu `offsets`.
    // 3. `end` - Puntador final a la matriu `offsets`.
    // 4. `offsets, índexs d'elements fora d'ordre dins del bloc.

    // El bloc actual al costat esquerre (de `l` a `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // El bloc actual a la part dreta (a partir de `r.sub(block_r)` to `r`).
    // SEGURETAT: La documentació de .add() esmenta específicament que `vec.as_ptr().add(vec.len())` sempre és segur "
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Quan obtinguem VLA, proveu de crear una matriu de longitud `min(v.len(), 2 * BLOCK) `
    // de dues matrius de mida fixa de longitud `BLOCK`.Els VLA poden ser més eficaços en memòria cau.

    // Retorna el nombre d'elements entre els punters `l` (inclusive) i `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Ja hem acabat amb la partició bloc per bloc quan `l` i `r` s`acosten molt.
        // A continuació, fem una mica de reparació per tal de particionar els elements restants entremig.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Nombre d'elements restants (encara no es compara amb el pivot).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Ajusteu les mides de blocs perquè el bloc esquerre i dret no es superposin, sinó que queden perfectament alineats per cobrir tot el buit restant.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Traça els elements `block_l` des del costat esquerre.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SEGURETAT: Les operacions de seguretat següents a continuació impliquen l'ús del `offset`.
                //         Segons les condicions requerides per la funció, les satisfem perquè:
                //         1. `offsets_l` està assignat en pila i, per tant, es considera objecte assignat separat.
                //         2. La funció `is_less` retorna un `bool`.
                //            Emetre un `bool` mai desbordarà `isize`.
                //         3. Hem garantit que `block_l` serà `<= BLOCK`.
                //            A més, `end_l` es va configurar inicialment en el punter d'inici de `offsets_` que es va declarar a la pila.
                //            Per tant, sabem que fins i tot en el pitjor dels casos (totes les invocacions de `is_less` retornen falses) només passarem com a màxim un byte al final.
                //        Una altra operació de seguretat aquí és la desferenciació de `elem`.
                //        Tanmateix, `elem` era inicialment el punter d'inici a la part que sempre és vàlida.
                unsafe {
                    // Comparació sense branques.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Traça els elements `block_r` des del costat dret.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SEGURETAT: Les operacions de seguretat següents a continuació impliquen l'ús del `offset`.
                //         Segons les condicions requerides per la funció, les satisfem perquè:
                //         1. `offsets_r` està assignat en pila i, per tant, es considera objecte assignat separat.
                //         2. La funció `is_less` retorna un `bool`.
                //            Emetre un `bool` mai desbordarà `isize`.
                //         3. Hem garantit que `block_r` serà `<= BLOCK`.
                //            A més, `end_r` es va configurar inicialment en el punter d'inici de `offsets_` que es va declarar a la pila.
                //            Per tant, sabem que fins i tot en el pitjor dels casos (totes les invocacions de `is_less` es tornen certes) només serem com a màxim 1 byte el final.
                //        Una altra operació de seguretat aquí és la desferenciació de `elem`.
                //        Tanmateix, `elem` inicialment era `1 *sizeof(T)` més enllà del final i el decrementem per `1* sizeof(T)` abans d`accedir-hi.
                //        A més, es va afirmar que `block_r` era inferior a `BLOCK` i, per tant, com a màxim `elem` apuntarà cap al començament de la part.
                unsafe {
                    // Comparació sense branques.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Nombre d'elements fora d'ordre que s'han d'intercanviar entre el costat esquerre i el dret.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // En lloc d`intercanviar un parell al mateix temps, és més eficient realitzar una permutació cíclica.
            // Això no és estrictament equivalent a l'intercanvi, però produeix un resultat similar utilitzant menys operacions de memòria.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Es van moure tots els elements fora d'ordre del bloc esquerre.Passa al bloc següent.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Es van moure tots els elements fora d'ordre del bloc dret.Passa al bloc anterior.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Ara només queda un bloc com a màxim (a l`esquerra o a la dreta) amb elements fora d`ordre que cal moure.
    // Aquests elements restants es poden desplaçar fins al final dins del seu bloc.
    //

    if start_l < end_l {
        // Queda el bloc esquerre.
        // Mou els elements restants fora d`ordre a l`extrema dreta.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Queda el bloc de la dreta.
        // Moveu els elements restants fora d'ordre a l'extrem esquerre.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Res més a fer, ja hem acabat.
        width(v.as_mut_ptr(), l)
    }
}

/// Particiona `v` en elements menors que `v[pivot]`, seguits per elements majors o iguals a `v[pivot]`.
///
///
/// Retorna una tupla de:
///
/// 1. Nombre d'elements inferiors a `v[pivot]`.
/// 2. És cert si `v` ja estava particionat.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Col・loqueu el pivot al començament de la llesca.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Llegiu el pivot en una variable assignada per pila per obtenir més eficiència.
        // Si es fa una operació de comparació següent panics, el pivot es tornarà a escriure automàticament a la part.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Cerqueu el primer parell d`elements fora d`ordre.
        let mut l = 0;
        let mut r = v.len();

        // SEGURETAT: La inseguretat següent implica la indexació d'una matriu.
        // Per al primer: ja fem els límits comprovant aquí amb `l < r`.
        // Per al segon: inicialment tenim `l == 0` i `r == v.len()` i hem comprovat que `l < r` en cada operació d'indexació.
        //                     A partir d`aquí sabem que `r` ha de ser com a mínim `r == l`, que es va demostrar que era vàlid des del primer.
        unsafe {
            // Cerqueu el primer element més gran o igual que el pivot.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Cerqueu l`últim element més petit que el pivot.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` surt de l'abast i escriu el pivot (que és una variable assignada a la pila) de nou a la part on estava originalment.
        // Aquest pas és fonamental per garantir la seguretat.
        //
    };

    // Col・loqueu el pivot entre les dues particions.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Particiona `v` en elements iguals a `v[pivot]` seguits d`elements superiors a `v[pivot]`.
///
/// Retorna el nombre d'elements igual al pivot.
/// Se suposa que `v` no conté elements més petits que el pivot.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Col・loqueu el pivot al començament de la llesca.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Llegiu el pivot en una variable assignada per pila per obtenir més eficiència.
    // Si es fa una operació de comparació següent panics, el pivot es tornarà a escriure automàticament a la part.
    // SEGURETAT: el punter aquí és vàlid perquè s`obté a partir d`una referència a una llesca.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Ara particioneu la llesca.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SEGURETAT: La inseguretat següent implica la indexació d'una matriu.
        // Per al primer: ja fem els límits comprovant aquí amb `l < r`.
        // Per al segon: inicialment tenim `l == 0` i `r == v.len()` i hem comprovat que `l < r` en cada operació d'indexació.
        //                     A partir d`aquí sabem que `r` ha de ser com a mínim `r == l`, que es va demostrar que era vàlid des del primer.
        unsafe {
            // Cerqueu el primer element més gran que el pivot.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Cerqueu l`últim element igual al pivot.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Ja hem acabat?
            if l >= r {
                break;
            }

            // Intercanvieu el parell d`elements fora d`ordre trobats.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Hem trobat elements `l` iguals al pivot.Afegiu-ne 1 per tenir compte del propi pivot.
    l + 1

    // `_pivot_guard` surt de l'abast i escriu el pivot (que és una variable assignada a la pila) de nou a la part on estava originalment.
    // Aquest pas és fonamental per garantir la seguretat.
}

/// Dispersa alguns elements al voltant en un intent de trencar patrons que poden provocar particions desequilibrades a la ràpida velocitat.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Generador de números aleatoris del document "Xorshift RNGs" de George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Pren nombres aleatoris mòdul d`aquest nombre.
        // El nombre s`adapta a `usize` perquè `len` no és superior a `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Alguns candidats pivots estaran a prop d`aquest índex.Fem-los aleatoris.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Generar un número aleatori mòdul `len`.
            // Tanmateix, per evitar operacions costoses, primer prenem un mòdul de potència de dos i, a continuació, disminuïm en `len` fins que s'adapti al rang `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` està garantit que sigui inferior a `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Trieu un pivot a `v` i retorna l'índex i `true` si és probable que la secció ja estigui ordenada.
///
/// És possible que els elements de `v` es tornin a ordenar durant el procés.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Longitud mínima per escollir el mètode mediana de medianes.
    // Les rodanxes més curtes utilitzen el mètode simple de mediana de tres.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Nombre màxim d'intercanvis que es poden realitzar en aquesta funció.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Tres índexs a prop dels quals escollirem un pivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Compta el nombre total d`intercanvis que estem a punt de realitzar mentre s`ordenen els índexs.
    let mut swaps = 0;

    if len >= 8 {
        // Permuta els índexs de manera que `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Permuta els índexs de manera que `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Cerca la mediana de `v[a - 1], v[a], v[a + 1]` i emmagatzema l`índex a `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Cerqueu mitgeres als barris de `a`, `b` i `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Cerqueu la mediana entre `a`, `b` i `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Es va realitzar el nombre màxim d'intercanvis.
        // El més probable és que la porció sigui descendent o majoritàriament descendent, de manera que la inversió probablement ajudarà a ordenar-la més ràpidament.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Ordena `v` recursivament.
///
/// Si el segment tenia un predecessor a la matriu original, s'especifica com a `pred`.
///
/// `limit` és el nombre de particions desequilibrades permeses abans de canviar a `heapsort`.
/// Si és zero, aquesta funció canviarà immediatament a Hacksort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Les llesques de fins a aquesta longitud s`ordenen mitjançant la classificació per inserció.
    const MAX_INSERTION: usize = 20;

    // És cert si l`últim particionament era raonablement equilibrat.
    let mut was_balanced = true;
    // És cert si l'últim particionament no barreja elements (el segment ja estava particionat).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Els talls molt curts s`ordenen mitjançant la classificació per inserció.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Si es prenien massa males opcions de pivot, simplement torneu a la pila per garantir el pitjor dels casos de `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Si l'últim particionament estava desequilibrat, proveu de trencar patrons a la part barrejant alguns elements al voltant.
        // Amb sort, aquesta vegada escollirem un pivot millor.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Trieu un pivot i intenteu endevinar si el segment ja està ordenat.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Si l'últim particionament es va equilibrar decentment i no va barrejar elements, i si la selecció del pivot prediu que la secció ja està ordenada ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Proveu d`identificar diversos elements fora d`ordre i canvieu-los a les posicions correctes.
            // Si el tall s`acaba d`ordenar completament, ja hem acabat.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Si el pivot triat és igual al predecessor, aleshores és l`element més petit de la llesca.
        // Particeu la llesca en elements iguals i elements més grans que el pivot.
        // Aquest cas sol ser atenuat quan el segment conté molts elements duplicats.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Continueu ordenant els elements superiors al pivot.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Repartiu la llesca.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Dividiu el segment en `left`, `pivot` i `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Torneu a recórrer al costat més curt només per minimitzar el nombre total de trucades recursives i consumir menys espai de pila.
        // A continuació, continueu amb el costat més llarg (això és similar a la recursió de la cua).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Ordena `v` utilitzant el quicksort ràpid que derrota patrons, que és *O*(*n*\*log(* n*)) en el pitjor dels casos.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // L`ordenació no té un comportament significatiu en els tipus de mida zero.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Limiteu el nombre de particions desequilibrades a `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Per a talls de fins a aquesta longitud probablement sigui més ràpid simplement ordenar-los.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Trieu un pivot
        let (pivot, _) = choose_pivot(v, is_less);

        // Si el pivot triat és igual al predecessor, aleshores és l`element més petit de la llesca.
        // Particeu la llesca en elements iguals i elements més grans que el pivot.
        // Aquest cas sol ser atenuat quan el segment conté molts elements duplicats.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Si hem passat el nostre índex, estem bé.
                if mid > index {
                    return;
                }

                // En cas contrari, continueu ordenant els elements superiors al pivot.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Dividiu el segment en `left`, `pivot` i `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Si mid==index, ja hem acabat, ja que partition() garanteix que tots els elements posteriors a mid són majors o iguals a mid.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // L`ordenació no té un comportament significatiu en els tipus de mida zero.No fer res.
    } else if index == v.len() - 1 {
        // Cerqueu l'element max i col・loqueu-lo a l'última posició de la matriu.
        // Aquí podem utilitzar `unwrap()` perquè sabem que v no ha d`estar buit.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Cerqueu l'element min i col・loqueu-lo a la primera posició de la matriu.
        // Aquí podem utilitzar `unwrap()` perquè sabem que v no ha d`estar buit.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}