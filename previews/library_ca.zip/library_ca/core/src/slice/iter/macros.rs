//! Macros que fan servir els iteradors de slice.

// La línia is_empty i len marca una gran diferència de rendiment
macro_rules! is_empty {
    // La forma en què codifiquem la longitud d`un iterador ZST, funciona tant per a ZST com per a no ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Per desfer-nos d'algunes comprovacions de límits (vegeu `position`), calculem la longitud d'una manera una mica inesperada.
// (Provat per `codegen/slice-position-limits-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // de vegades ens fem servir dins d'un bloc no segur

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Aquest _cannot_ utilitza `unchecked_sub` perquè depenem de l'embolcall per representar la longitud dels llargs iteradors de llesques ZST.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Sabem que `start <= end`, per tant, pot fer-ho millor que `offset_from`, que ha de tractar signat.
            // Si establim aquí les marques adequades, podem dir-ho a LLVM, cosa que ajuda a eliminar els controls de límits.
            // SEGURETAT: pel tipus invariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // En dir-li també a LLVM que els indicadors estan separats per un múltiple exacte de la mida del tipus, pot optimitzar `len() == 0` fins a `start == end` en lloc de `(end - start) < size`.
            //
            // SEGURETAT: pel tipus invariant, els punteres estan alineats de manera que
            //         la distància entre ells ha de ser múltiple de la mida del punt
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// La definició compartida dels iteradors `Iter` i `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Retorna el primer element i mou l'inici de l'iterador cap endavant en 1.
        // Millora molt el rendiment en comparació amb una funció inclinada.
        // L'iterador no ha d'estar buit.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Retorna l'últim element i mou el final de l'iterador cap enrere en 1.
        // Millora molt el rendiment en comparació amb una funció inclinada.
        // L'iterador no ha d'estar buit.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Redueix l'iterador quan T és un ZST, movent l'extrem de l'iterador cap enrere per `n`.
        // `n` no pot superar `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Funció d'ajuda per crear una part a partir de l'iterador.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SEGURETAT: l'iterador es va crear a partir d'una llesca amb punter
                // `self.ptr` i longitud `len!(self)`.
                // Això garanteix que es compleixen tots els requisits previs per a `from_raw_parts`.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Funció d`ajuda per moure l`inici de l`iterador cap endavant per elements `offset`, retornant l`inici anterior.
            //
            // No és segur perquè el desplaçament no ha de superar `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SEGURETAT: la persona que truca garanteix que `offset` no excedeix `self.len()`,
                    // per tant, aquest nou punter està dins de `self` i, per tant, es garanteix que no és nul.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Funció d`ajuda per moure el final de l`iterador cap enrere per elements `offset`, retornant el nou extrem.
            //
            // No és segur perquè el desplaçament no ha de superar `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SEGURETAT: la persona que truca garanteix que `offset` no excedeix `self.len()`,
                    // que està garantit per no desbordar un `isize`.
                    // A més, el punter resultant es troba dins dels límits de `slice`, que compleix els altres requisits de `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // es podria implementar amb talls, però això evita la comprovació de límits

                // SEGURETAT: les trucades `assume` són segures ja que el punter inicial d'un segment
                // ha de ser no nul, i les llesques sobre no ZST també han de tenir un punter final no nul.
                // La trucada a `next_unchecked!` és segura, ja que comprovem si l`iterador està buit primer.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Aquest iterador ara està buit.
                    if mem::size_of::<T>() == 0 {
                        // Ho hem de fer d'aquesta manera, ja que és possible que `ptr` mai sigui 0, però `end` podria ser-ho (a causa de l'embolcall).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SEGURETAT: end no pot ser 0 si T no és ZST perquè ptr no és 0 i end>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SEGURETAT: Estem en límits.`post_inc_start` fa el correcte fins i tot per a ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Anul・lem la implementació predeterminada, que utilitza `try_fold`, perquè aquesta implementació senzilla genera menys LLVM IR i és més ràpida de compilar.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Anul・lem la implementació predeterminada, que utilitza `try_fold`, perquè aquesta implementació senzilla genera menys LLVM IR i és més ràpida de compilar.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Anul・lem la implementació predeterminada, que utilitza `try_fold`, perquè aquesta implementació senzilla genera menys LLVM IR i és més ràpida de compilar.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Anul・lem la implementació predeterminada, que utilitza `try_fold`, perquè aquesta implementació senzilla genera menys LLVM IR i és més ràpida de compilar.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Anul・lem la implementació predeterminada, que utilitza `try_fold`, perquè aquesta implementació senzilla genera menys LLVM IR i és més ràpida de compilar.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Anul・lem la implementació predeterminada, que utilitza `try_fold`, perquè aquesta implementació senzilla genera menys LLVM IR i és més ràpida de compilar.
            // A més, el `assume` evita una comprovació de límits.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SEGURETAT: la invariant del bucle ens garanteix que estem en límits:
                        // quan `i >= n`, `self.next()` retorna `None` i el bucle es trenca.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Anul・lem la implementació predeterminada, que utilitza `try_fold`, perquè aquesta implementació senzilla genera menys LLVM IR i és més ràpida de compilar.
            // A més, el `assume` evita una comprovació de límits.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SEGURETAT: `i` ha de ser inferior a `n` ja que comença a `n`
                        // i només és decreixent.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SEGURETAT: la persona que truca ha de garantir que `i` està dins dels límits de
                // el tall subjacent, de manera que `i` no pot desbordar un `isize`, i les referències retornades es garanteixen que fan referència a un element de la llesca i, per tant, es garanteix que són vàlides.
                //
                // Tingueu en compte també que la persona que truca també garanteix que no ens tornaran a cridar amb el mateix índex i que no es crida cap altre mètode que accedirà a aquest subslice, de manera que és vàlid que la referència retornada sigui mutable en el cas de
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // es podria implementar amb talls, però això evita la comprovació de límits

                // SEGURETAT: les trucades `assume` són segures, ja que el punter d`inici d`un segment no ha de ser nul,
                // i les llesques sobre ZST que no siguin ZST també han de tenir un punter final no nul.
                // La trucada a `next_back_unchecked!` és segura, ja que comprovem si l`iterador està buit primer.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Aquest iterador ara està buit.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SEGURETAT: Estem en límits.`pre_dec_end` fa el correcte fins i tot per a ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}