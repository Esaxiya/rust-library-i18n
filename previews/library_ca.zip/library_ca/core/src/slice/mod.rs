// ignore-tidy-filelength

//! Gestió i manipulació de talls.
//!
//! Per obtenir més informació, consulteu [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Implementació pura rust memchr, extreta de rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Aquesta funció només és pública perquè no hi ha cap altra manera de provar unitats de gran quantitat.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Retorna el nombre d'elements a la part.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SEGURETAT: so constant perquè transmutem el camp de longitud com a usize (que ha de ser)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SEGURETAT: és segur perquè `&[T]` i `FatPtr<T>` tenen el mateix disseny.
            // Només `std` pot fer aquesta garantia.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Substituïu-lo per `crate::ptr::metadata(self)` quan sigui constant.
            // A partir d`aquest moment, això provoca un error "Const-stable functions can only call other const-stable functions".
            //

            // SEGURETAT: Accedir al valor des de la unió `PtrRepr` és segur ja que * const T
            // i PtrComponents<T>tenen els mateixos dissenys de memòria.
            // Només std pot fer aquesta garantia.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Retorna `true` si el segment té una longitud de 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Retorna el primer element de la llesca o `None` si està buit.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Retorna un punter mutable al primer element de la llesca o `None` si està buit.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Retorna el primer i la resta dels elements de la llesca o `None` si està buit.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Retorna el primer i la resta dels elements de la llesca o `None` si està buit.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Retorna l'últim i la resta dels elements de la llesca, o `None` si està buit.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Retorna l'últim i la resta dels elements de la llesca, o `None` si està buit.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Retorna l'últim element de la llesca o `None` si està buit.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Retorna un punter mutable a l'últim element del segment.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Retorna una referència a un element o subslice segons el tipus d'índex.
    ///
    /// - Si es dóna una posició, retorna una referència a l'element en aquesta posició o `None` si està fora de límit.
    ///
    /// - Si se li dóna un interval, retorna la subdivisió corresponent a aquest interval o `None` si està fora de límit.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Retorna una referència mutable a un element o subslice segons el tipus d'índex (vegeu [`get`]) o `None` si l'índex està fora de límit.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Retorna una referència a un element o subslice, sense fer la comprovació de límits.
    ///
    /// Per obtenir una alternativa segura, consulteu [`get`].
    ///
    /// # Safety
    ///
    /// Cridar aquest mètode amb un índex fora de límits és *[comportament indefinit]* fins i tot si no s`utilitza la referència resultant.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SEGURETAT: la persona que truca ha de complir la majoria dels requisits de seguretat per a `get_unchecked`;
        // la part no es pot referenciar perquè `self` és una referència segura.
        // El punter retornat és segur perquè les aplicacions de `SliceIndex` han de garantir-ho.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Retorna una referència mutable a un element o subslice, sense fer la comprovació de límits.
    ///
    /// Per obtenir una alternativa segura, consulteu [`get_mut`].
    ///
    /// # Safety
    ///
    /// Cridar aquest mètode amb un índex fora de límits és *[comportament indefinit]* fins i tot si no s`utilitza la referència resultant.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SEGURETAT: la persona que truca ha de complir els requisits de seguretat per a `get_unchecked_mut`;
        // la part no es pot referenciar perquè `self` és una referència segura.
        // El punter retornat és segur perquè les aplicacions de `SliceIndex` han de garantir-ho.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Retorna un punter en brut al buffer del segment.
    ///
    /// La persona que truca s'ha d'assegurar que la porció sobreviu al punter que retorna aquesta funció, o bé acabarà apuntant a la brossa.
    ///
    /// La persona que truca també s'ha d'assegurar que la memòria a què apunta el punter (non-transitively) mai s'escriu (excepte dins d'un `UnsafeCell`) mitjançant aquest punter o qualsevol altre punter derivat d'aquest.
    /// Si necessiteu mutar el contingut de la llesca, utilitzeu [`as_mut_ptr`].
    ///
    /// Si modifiqueu el contenidor al qual fa referència aquest segment, es pot reassignar la memòria intermèdia, cosa que també faria que qualsevol indicador no sigui vàlid.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Retorna un punter mutable insegur al buffer del segment.
    ///
    /// La persona que truca s'ha d'assegurar que la porció sobreviu al punter que retorna aquesta funció, o bé acabarà apuntant a la brossa.
    ///
    /// Si modifiqueu el contenidor al qual fa referència aquest segment, es pot reassignar la memòria intermèdia, cosa que també faria que qualsevol indicador no sigui vàlid.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Retorna els dos punters en brut que abasten la part.
    ///
    /// L'interval retornat està mig obert, el que significa que el punter final apunta *una passada* l'últim element del segment.
    /// D'aquesta manera, una llesca buida es representa amb dos punteres iguals i la diferència entre els dos punteres representa la mida de la llesca.
    ///
    /// Consulteu [`as_ptr`] per obtenir avisos sobre l`ús d`aquests punteres.El punter final requereix una precaució addicional, ja que no apunta cap a un element vàlid al segment.
    ///
    /// Aquesta funció és útil per interactuar amb interfícies estrangeres que utilitzen dos punters per referir-se a una gamma d'elements de la memòria, com és habitual en C++ .
    ///
    ///
    /// També pot ser útil comprovar si un punter cap a un element fa referència a un element d`aquest segment:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SEGURETAT: El `add` aquí és segur perquè:
        //
        //   - Tots dos indicadors formen part del mateix objecte, ja que també es compta amb assenyalar directament més enllà de l'objecte.
        //
        //   - La mida de la llesca mai és superior a isize::MAX bytes, tal com s`indica aquí:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - No hi ha cap embolcall involucrat, ja que les llesques no passen pel final de l'espai d'adreces.
        //
        // Consulteu la documentació de pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Retorna els dos indicadors mutables no segurs que abasten el segment.
    ///
    /// L'interval retornat està mig obert, el que significa que el punter final apunta *una passada* l'últim element del segment.
    /// D'aquesta manera, una llesca buida es representa amb dos punteres iguals i la diferència entre els dos punteres representa la mida de la llesca.
    ///
    /// Consulteu [`as_mut_ptr`] per obtenir avisos sobre l`ús d`aquests punteres.
    /// El punter final requereix una precaució addicional, ja que no apunta cap a un element vàlid al segment.
    ///
    /// Aquesta funció és útil per interactuar amb interfícies estrangeres que utilitzen dos punters per referir-se a una gamma d'elements de la memòria, com és habitual en C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // SEGURETAT: consulteu as_ptr_range() més amunt per saber per què `add` és segur.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Intercanvia dos elements a la llesca.
    ///
    /// # Arguments
    ///
    /// * a, L'índex del primer element
    /// * b, l`índex del segon element
    ///
    /// # Panics
    ///
    /// Panics si `a` o `b` estan fora de límit.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // No es poden prendre dos préstecs mutables d'un vector, de manera que utilitzeu punters en brut.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SEGURETAT: `pa` i `pb` s'han creat a partir de referències i referències mutables segures
        // als elements de la secció i, per tant, es garanteix que són vàlids i alineats.
        // Tingueu en compte que l'accés als elements darrere de `a` i `b` està marcat i es farà panic quan estigui fora de límit.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Inverteix l'ordre dels elements de la llesca, al seu lloc.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Per a tipus molt petits, totes les lectures individuals en el camí normal funcionen malament.
        // Podem fer-ho millor, donat un load/store sense alineació eficient, carregant un tros més gran i invertint un registre.
        //

        // Idealment, LLVM ho faria per nosaltres, ja que sap millor que nosaltres si les lectures no alineades són eficients (ja que això canvia entre diferents versions ARM, per exemple) i quina seria la millor mida de tros.
        // Malauradament, a partir de LLVM 4.0 (2017-05), només desenrotlla el bucle, de manera que hem de fer-ho nosaltres mateixos.
        // (Hipòtesi: la inversió és problemàtica perquè els costats es poden alinear de manera diferent (ho serà, quan la longitud sigui imparella), de manera que no hi ha manera d'emetre pre i postludis per utilitzar SIMD totalment alineats al centre.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Utilitzeu el llvm.bswap intrínsec per invertir u8s en un usize
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // SEGURETAT: Hi ha diverses coses a consultar aquí:
                //
                // - Tingueu en compte que `chunk` és 4 o 8 a causa de la verificació cfg anterior.Per tant, `chunk - 1` és positiu.
                // - La indexació amb l`índex `i` està bé, ja que garanteix la comprovació del bucle
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - La indexació amb l`índex `ln - i - chunk = ln - (i + chunk)` està bé:
                //   - `i + chunk > 0` és trivialment cert.
                //   - La comprovació del bucle garanteix:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, per tant, la resta no es redueix.
                // - Les trucades `read_unaligned` i `write_unaligned` estan bé:
                //   - `pa` apunta a l'índex `i` on `i < ln / 2 - (chunk - 1)` (vegeu més amunt) i `pb` apunta a l'índex `ln - i - chunk`, de manera que tots dos es troben almenys `chunk` a molts bytes del final de `self`.
                //
                //   - Qualsevol memòria inicialitzada és vàlida `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Utilitzeu la rotació per 16 per invertir els u16 en un u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SEGURETAT: es pot llegir un u32 sense alinear des de `i` si `i + 1 < ln`
                // (i òbviament `i < ln`), perquè cada element té 2 bytes i en llegim 4.
                //
                // `i + chunk - 1 < ln / 2` # mentre que condició
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Com que és inferior a la longitud dividida per 2, ha de tenir límits.
                //
                // Això també significa que sempre es respecta la condició `0 < i + chunk <= ln`, cosa que garanteix que el punter `pb` es pugui utilitzar amb seguretat.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SEGURETAT: `i` és inferior a la meitat de la longitud de la llesca
            // accedir a `i` i `ln - i - 1` és segur (`i` comença a 0 i no anirà més enllà de `ln / 2 - 1`).
            // Els punteres resultants `pa` i `pb` són, per tant, vàlids i alineats, i es poden llegir i escriure-hi.
            //
            //
            unsafe {
                // Intercanvi insegur per evitar la comprovació de límits en intercanvi segur.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Retorna un iterador sobre el segment.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Retorna un iterador que permet modificar cada valor.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Retorna un iterador sobre tots els windows contigus de longitud `size`.
    /// La superposició windows.
    /// Si el segment és més curt que `size`, l'iterador no retorna cap valor.
    ///
    /// # Panics
    ///
    /// Panics si `size` és 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Si el segment és més curt que `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Retorna un iterador sobre elements `chunk_size` de la porció a la vegada, a partir del començament de la porció.
    ///
    /// Els trossos són llesques i no se superposen.Si `chunk_size` no divideix la longitud de la llesca, l'últim fragment no tindrà la longitud `chunk_size`.
    ///
    /// Vegeu [`chunks_exact`] per obtenir una variant d`aquest iterador que retorna trossos d`elements `chunk_size` sempre exactament, i [`rchunks`] per al mateix iterador, però a partir del final del segment.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` és 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Retorna un iterador sobre elements `chunk_size` de la porció a la vegada, a partir del començament de la porció.
    ///
    /// Els trossos són talls que es poden modificar i no se superposen.Si `chunk_size` no divideix la longitud de la llesca, l'últim fragment no tindrà la longitud `chunk_size`.
    ///
    /// Vegeu [`chunks_exact_mut`] per obtenir una variant d`aquest iterador que retorna trossos d`elements `chunk_size` sempre exactament, i [`rchunks_mut`] per al mateix iterador, però a partir del final del segment.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` és 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Retorna un iterador sobre elements `chunk_size` de la porció a la vegada, a partir del començament de la porció.
    ///
    /// Els trossos són llesques i no se superposen.
    /// Si `chunk_size` no divideix la longitud de la llesca, s'ometran els últims elements fins a `chunk_size-1` i es poden recuperar de la funció `remainder` de l'iterador.
    ///
    ///
    /// Degut a que cada tros té exactament elements `chunk_size`, el compilador sovint pot optimitzar el codi resultant millor que en el cas de [`chunks`].
    ///
    /// Vegeu [`chunks`] per obtenir una variant d`aquest iterador que també retorna la resta com un fragment més petit i [`rchunks_exact`] per al mateix iterador, però a partir del final de la part.
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` és 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Retorna un iterador sobre elements `chunk_size` de la porció a la vegada, a partir del començament de la porció.
    ///
    /// Els trossos són talls que es poden modificar i no se superposen.
    /// Si `chunk_size` no divideix la longitud de la llesca, s'ometran els últims elements fins a `chunk_size-1` i es poden recuperar de la funció `into_remainder` de l'iterador.
    ///
    ///
    /// Degut a que cada tros té exactament elements `chunk_size`, el compilador sovint pot optimitzar el codi resultant millor que en el cas de [`chunks_mut`].
    ///
    /// Vegeu [`chunks_mut`] per obtenir una variant d`aquest iterador que també retorna la resta com un fragment més petit i [`rchunks_exact_mut`] per al mateix iterador, però a partir del final de la part.
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` és 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Divideix la porció en una porció de matrius d'elements "N", suposant que no queda cap resta.
    ///
    ///
    /// # Safety
    ///
    /// Això només es pot trucar quan
    /// - El tall es divideix exactament en trossos d'elements "N" (també conegut com `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SEGURETAT: els trossos d'un element mai no en queden
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // SEGURETAT: la longitud de la llesca (6) és múltiple de 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // No serien raonables:
    /// // deixem trossos: &[[_;5]]= slice.as_chunks_unchecked()//La longitud de la llesca no és múltiple de 5 let trossos:&[[_;0]]= slice.as_chunks_unchecked()//Mai es permeten trossos de longitud zero
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SEGURETAT: la nostra condició prèvia és exactament el que cal per anomenar-ho
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SEGURETAT: llancem una porció d'elements `new_len * N`
        // una porció de `new_len` molts trossos d'elements `N`.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Divideix la porció en una porció de matrius d'elements "N", començant pel començament de la porció, i una porció restant amb una longitud estrictament inferior a `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `N` és 0. Aquesta comprovació probablement es canviarà a un error de temps de compilació abans que aquest mètode s`estabilitzi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SEGURETAT: Ja ens hem atemorit per zero i ens assegurem amb la construcció
        // que la longitud del subslice és múltiple de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Divideix la porció en una porció de matrius d'elements "N", començant pel final de la porció, i una porció restant amb una longitud estrictament inferior a `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `N` és 0. Aquesta comprovació probablement es canviarà a un error de temps de compilació abans que aquest mètode s`estabilitzi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SEGURETAT: Ja ens hem atemorit per zero i ens assegurem amb la construcció
        // que la longitud del subslice és múltiple de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Retorna un iterador sobre elements `N` de la porció a la vegada, a partir del començament de la porció.
    ///
    /// Els trossos són referències de matriu i no se superposen.
    /// Si `N` no divideix la longitud de la llesca, s'ometran els últims elements fins a `N-1` i es poden recuperar de la funció `remainder` de l'iterador.
    ///
    ///
    /// Aquest mètode és l'equivalent genèric constant de [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics si `N` és 0. Aquesta comprovació probablement es canviarà a un error de temps de compilació abans que aquest mètode s`estabilitzi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Divideix la porció en una porció de matrius d'elements "N", suposant que no queda cap resta.
    ///
    ///
    /// # Safety
    ///
    /// Això només es pot trucar quan
    /// - El tall es divideix exactament en trossos d'elements "N" (també conegut com `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SEGURETAT: els trossos d'un element mai no en queden
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // SEGURETAT: la longitud de la llesca (6) és múltiple de 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // No serien raonables:
    /// // deixem trossos: &[[_;5]]= slice.as_chunks_unchecked_mut()//La longitud de la llesca no és múltiple de 5 let trossos:&[[_;0]]= slice.as_chunks_unchecked_mut()//Mai es permeten trossos de longitud zero
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SEGURETAT: la nostra condició prèvia és exactament el que cal per anomenar-ho
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SEGURETAT: llancem una porció d'elements `new_len * N`
        // una porció de `new_len` molts trossos d'elements `N`.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Divideix la porció en una porció de matrius d'elements "N", començant pel començament de la porció, i una porció restant amb una longitud estrictament inferior a `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `N` és 0. Aquesta comprovació probablement es canviarà a un error de temps de compilació abans que aquest mètode s`estabilitzi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SEGURETAT: Ja ens hem atemorit per zero i ens assegurem amb la construcció
        // que la longitud del subslice és múltiple de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Divideix la porció en una porció de matrius d'elements "N", començant pel final de la porció, i una porció restant amb una longitud estrictament inferior a `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `N` és 0. Aquesta comprovació probablement es canviarà a un error de temps de compilació abans que aquest mètode s`estabilitzi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SEGURETAT: Ja ens hem atemorit per zero i ens assegurem amb la construcció
        // que la longitud del subslice és múltiple de N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Retorna un iterador sobre elements `N` de la porció a la vegada, a partir del començament de la porció.
    ///
    /// Els trossos són referències de matriu mutables i no se superposen.
    /// Si `N` no divideix la longitud de la llesca, s'ometran els últims elements fins a `N-1` i es poden recuperar de la funció `into_remainder` de l'iterador.
    ///
    ///
    /// Aquest mètode és l'equivalent genèric constant de [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics si `N` és 0. Aquesta comprovació probablement es canviarà a un error de temps de compilació abans que aquest mètode s`estabilitzi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Retorna un iterador que se solapa amb windows d'elements `N` d'una llesca, a partir del començament de la llesca.
    ///
    ///
    /// Aquest és l'equivalent genèric constant de [`windows`].
    ///
    /// Si `N` és superior a la mida de la llesca, no retornarà cap windows.
    ///
    /// # Panics
    ///
    /// Panics si `N` és 0.
    /// Aquesta comprovació probablement es convertirà en un error de temps de compilació abans que aquest mètode s`estabilitzi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Retorna un iterador sobre elements `chunk_size` de la porció a la vegada, començant al final de la porció.
    ///
    /// Els trossos són llesques i no se superposen.Si `chunk_size` no divideix la longitud de la llesca, l'últim fragment no tindrà la longitud `chunk_size`.
    ///
    /// Vegeu [`rchunks_exact`] per obtenir una variant d`aquest iterador que retorna trossos d`elements `chunk_size` sempre exactament, i [`chunks`] per al mateix iterador, però a partir del començament de la part.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` és 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Retorna un iterador sobre elements `chunk_size` de la porció a la vegada, començant al final de la porció.
    ///
    /// Els trossos són talls que es poden modificar i no se superposen.Si `chunk_size` no divideix la longitud de la llesca, l'últim fragment no tindrà la longitud `chunk_size`.
    ///
    /// Vegeu [`rchunks_exact_mut`] per obtenir una variant d`aquest iterador que retorna trossos d`elements `chunk_size` sempre exactament, i [`chunks_mut`] per al mateix iterador, però a partir del començament de la part.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` és 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Retorna un iterador sobre elements `chunk_size` de la porció a la vegada, començant al final de la porció.
    ///
    /// Els trossos són llesques i no se superposen.
    /// Si `chunk_size` no divideix la longitud de la llesca, s'ometran els últims elements fins a `chunk_size-1` i es poden recuperar de la funció `remainder` de l'iterador.
    ///
    /// Degut a que cada tros té exactament elements `chunk_size`, el compilador sovint pot optimitzar el codi resultant millor que en el cas de [`chunks`].
    ///
    /// Vegeu [`rchunks`] per obtenir una variant d`aquest iterador que també retorna la resta com un fragment més petit i [`chunks_exact`] per al mateix iterador, però a partir del començament de la part.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` és 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Retorna un iterador sobre elements `chunk_size` de la porció a la vegada, començant al final de la porció.
    ///
    /// Els trossos són talls que es poden modificar i no se superposen.
    /// Si `chunk_size` no divideix la longitud de la llesca, s'ometran els últims elements fins a `chunk_size-1` i es poden recuperar de la funció `into_remainder` de l'iterador.
    ///
    /// Degut a que cada tros té exactament elements `chunk_size`, el compilador sovint pot optimitzar el codi resultant millor que en el cas de [`chunks_mut`].
    ///
    /// Vegeu [`rchunks_mut`] per obtenir una variant d`aquest iterador que també retorna la resta com un fragment més petit i [`chunks_exact_mut`] per al mateix iterador, però a partir del començament de la part.
    ///
    ///
    /// # Panics
    ///
    /// Panics si `chunk_size` és 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Retorna un iterador sobre el segment produint sèries d'elements que no se superposen mitjançant el predicat per separar-los.
    ///
    /// El predicat rep dos elements que se segueixen, significa que el predicat es crida a `slice[0]` i `slice[1]`, després a `slice[1]` i `slice[2]`, etc.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Aquest mètode es pot utilitzar per extreure les subslices ordenades:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Retorna un iterador sobre la llesca que produeix execucions d'elements mutables que no se superposen mitjançant el predicat per separar-los.
    ///
    /// El predicat rep dos elements que se segueixen, significa que el predicat es crida a `slice[0]` i `slice[1]`, després a `slice[1]` i `slice[2]`, etc.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Aquest mètode es pot utilitzar per extreure les subslices ordenades:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Divideix una llesca en dues en un índex.
    ///
    /// El primer contindrà tots els índexs de `[0, mid)` (excloent el mateix índex `mid`) i el segon contindrà tots els índexs de `[mid, len)` (excloent el mateix índex `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics si `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SEGURETAT: `[ptr; mid]` i `[mid; len]` es troben dins de `self`, que
        // compleix els requisits de `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Divideix un segment modificable en dos en un índex.
    ///
    /// El primer contindrà tots els índexs de `[0, mid)` (excloent el mateix índex `mid`) i el segon contindrà tots els índexs de `[mid, len)` (excloent el mateix índex `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics si `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SEGURETAT: `[ptr; mid]` i `[mid; len]` es troben dins de `self`, que
        // compleix els requisits de `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Divideix una llesca en dues en un índex, sense fer la comprovació de límits.
    ///
    /// El primer contindrà tots els índexs de `[0, mid)` (excloent el mateix índex `mid`) i el segon contindrà tots els índexs de `[mid, len)` (excloent el mateix índex `len`).
    ///
    ///
    /// Per obtenir una alternativa segura, consulteu [`split_at`].
    ///
    /// # Safety
    ///
    /// Cridar aquest mètode amb un índex fora de límits és *[comportament indefinit]* fins i tot si no s`utilitza la referència resultant.La persona que truca ha de garantir que `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SEGURETAT: la persona que truca ha de comprovar que `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Divideix un segment modificable en dos en un índex, sense fer la comprovació de límits.
    ///
    /// El primer contindrà tots els índexs de `[0, mid)` (excloent el mateix índex `mid`) i el segon contindrà tots els índexs de `[mid, len)` (excloent el mateix índex `len`).
    ///
    ///
    /// Per obtenir una alternativa segura, consulteu [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Cridar aquest mètode amb un índex fora de límits és *[comportament indefinit]* fins i tot si no s`utilitza la referència resultant.La persona que truca ha de garantir que `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SEGURETAT: la persona que truca ha de comprovar que `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` i `[mid; len]` no es solapen, de manera que està bé retornar una referència mutable.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Retorna un iterador sobre subslices separades per elements que coincideixen amb `pred`.
    /// L'element coincident no es troba a les subclasses.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Si es fa coincidir el primer element, una part buida serà el primer element retornat per l'iterador.
    /// De la mateixa manera, si coincideix l'últim element del segment, un segment buit serà l'últim element retornat per l'iterador:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Si dos elements coincidents són directament adjacents, hi haurà un segment buit entre ells:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Retorna un iterador sobre subslices mutables separades per elements que coincideixen amb `pred`.
    /// L'element coincident no es troba a les subclasses.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Retorna un iterador sobre subslices separades per elements que coincideixen amb `pred`.
    /// L'element coincident es troba al final de la subslice anterior com a terminador.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Si coincideix l'últim element del segment, aquest element es considerarà el finalitzador del segment anterior.
    ///
    /// Aquesta part serà l'últim element que l'iterador va retornar.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Retorna un iterador sobre subslices mutables separades per elements que coincideixen amb `pred`.
    /// L'element coincident es troba a la subslice anterior com a terminador.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Retorna un iterador sobre subslices separades per elements que coincideixen amb `pred`, començant al final del segment i treballant cap enrere.
    /// L'element coincident no es troba a les subclasses.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Igual que amb `split()`, si el primer o l'últim element coincideix, una llesca buida serà el primer (o l'últim) element retornat per l'iterador.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Retorna un iterador sobre subslices mutables separades per elements que coincideixen amb `pred`, començant al final de la llesca i treballant cap enrere.
    /// L'element coincident no es troba a les subclasses.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Retorna un iterador sobre subslices separades per elements que coincideixen amb `pred`, limitada a retornar com a màxim elements `n`.
    /// L'element coincident no es troba a les subclasses.
    ///
    /// L'últim element retornat, si n'hi ha, contindrà la resta de la porció.
    ///
    /// # Examples
    ///
    /// Imprimiu el segment dividit una vegada per nombres divisibles per 3 (és a dir, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Retorna un iterador sobre subslices separades per elements que coincideixen amb `pred`, limitada a retornar com a màxim elements `n`.
    /// L'element coincident no es troba a les subclasses.
    ///
    /// L'últim element retornat, si n'hi ha, contindrà la resta de la porció.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Retorna un iterador sobre subslices separades per elements que coincideixen amb `pred` limitada a retornar com a màxim elements `n`.
    /// Això comença al final de la llesca i funciona cap enrere.
    /// L'element coincident no es troba a les subclasses.
    ///
    /// L'últim element retornat, si n'hi ha, contindrà la resta de la porció.
    ///
    /// # Examples
    ///
    /// Imprimiu el segment dividit una vegada, començant pel final, per nombres divisibles per 3 (és a dir, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Retorna un iterador sobre subslices separades per elements que coincideixen amb `pred` limitada a retornar com a màxim elements `n`.
    /// Això comença al final de la llesca i funciona cap enrere.
    /// L'element coincident no es troba a les subclasses.
    ///
    /// L'últim element retornat, si n'hi ha, contindrà la resta de la porció.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Retorna `true` si el segment conté un element amb el valor indicat.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Si no teniu un `&T`, sinó només un `&U` tal que `T: Borrow<U>` (per exemple,
    /// `Cadena: prestat<str>`), podeu utilitzar `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // part de `String`
    /// assert!(v.iter().any(|e| e == "hello")); // cerca amb `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Retorna `true` si `needle` és un prefix del segment.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Torna sempre `true` si `needle` és un segment buit:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Retorna `true` si `needle` és un sufix de la part.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Torna sempre `true` si `needle` és un segment buit:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Retorna un subslice amb el prefix eliminat.
    ///
    /// Si la secció comença amb `prefix`, torna el subslice després del prefix, embolicat en `Some`.
    /// Si `prefix` està buit, simplement retorna la part original.
    ///
    /// Si la secció no comença amb `prefix`, retorna `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Aquesta funció haurà de tornar a escriure si i quan SlicePattern es torna més sofisticat.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Retorna una subslice amb el sufix eliminat.
    ///
    /// Si el segment finalitza amb `suffix`, torna el subslice abans del sufix, embolicat en `Some`.
    /// Si `suffix` està buit, simplement retorna la part original.
    ///
    /// Si el segment no acaba amb `suffix`, retorna `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Aquesta funció haurà de tornar a escriure si i quan SlicePattern es torna més sofisticat.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// El binari cerca aquest element ordenat per un determinat element.
    ///
    /// Si es troba el valor, es torna [`Result::Ok`], que conté l'índex de l'element coincident.
    /// Si hi ha diverses coincidències, es pot retornar qualsevol de les coincidències.
    /// Si no es troba el valor, es torna [`Result::Err`], que conté l'índex on es podria inserir un element coincident mantenint l'ordre ordenat.
    ///
    ///
    /// Vegeu també [`binary_search_by`], [`binary_search_by_key`] i [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Busca una sèrie de quatre elements.
    /// El primer es troba, amb una posició determinada de manera única;el segon i el tercer no es troben;el quart podria coincidir amb qualsevol posició del `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Si voleu inserir un element en un vector ordenat, mantenint l'ordre:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// El binari cerca aquest segment ordenat amb una funció de comparació.
    ///
    /// La funció de comparador hauria d'implementar un ordre coherent amb l'ordre de classificació de la part subjacent, retornant un codi de comanda que indiqui si el seu argument és `Less`, `Equal` o `Greater` l'objectiu desitjat.
    ///
    ///
    /// Si es troba el valor, es torna [`Result::Ok`], que conté l'índex de l'element coincident.Si hi ha diverses coincidències, es pot retornar qualsevol de les coincidències.
    /// Si no es troba el valor, es torna [`Result::Err`], que conté l'índex on es podria inserir un element coincident mantenint l'ordre ordenat.
    ///
    /// Vegeu també [`binary_search`], [`binary_search_by_key`] i [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Busca una sèrie de quatre elements.El primer es troba, amb una posició determinada de manera única;el segon i el tercer no es troben;el quart podria coincidir amb qualsevol posició del `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // SEGURETAT: la trucada és segura pels següents invariants:
            // - `mid >= 0`
            // - `mid < size`: `mid` està limitat per `[left; right)` lligat.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // La raó per la qual fem servir el flux de control if/else en lloc de coincidir es deu al fet que la coincidència reordena les operacions de comparació, que és perfectament sensible.
            //
            // Això és x86 asm per a u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// El binari cerca aquest segment ordenat amb una funció d'extracció de tecles.
    ///
    /// Suposa que la secció està ordenada per la clau, per exemple amb [`sort_by_key`] mitjançant la mateixa funció d'extracció de tecla.
    ///
    /// Si es troba el valor, es torna [`Result::Ok`], que conté l'índex de l'element coincident.
    /// Si hi ha diverses coincidències, es pot retornar qualsevol de les coincidències.
    /// Si no es troba el valor, es torna [`Result::Err`], que conté l'índex on es podria inserir un element coincident mantenint l'ordre ordenat.
    ///
    ///
    /// Vegeu també [`binary_search`], [`binary_search_by`] i [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Busca una sèrie de quatre elements en un segment de parells ordenats pels seus segons elements.
    /// El primer es troba, amb una posició determinada de manera única;el segon i el tercer no es troben;el quart podria coincidir amb qualsevol posició del `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links està permès ja que `slice::sort_by_key` està a crate `alloc` i, per tant, encara no existeix quan es construeix `core`.
    //
    // enllaços a crate: #74481.Com que les primitives només es documenten a libstd (#73423), això mai condueix a enllaços trencats a la pràctica.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Ordena la llesca, però pot no conservar l'ordre dels elements iguals.
    ///
    /// Aquest tipus és inestable (és a dir, pot reordenar elements iguals), al seu lloc (és a dir, no s'assigna) i *O*(*n*\*log(* n*)) en el pitjor dels casos.
    ///
    /// # Implementació actual
    ///
    /// L`algoritme actual es basa en [pattern-defeating quicksort][pdqsort] d`Orson Peters, que combina el cas mitjà ràpid d`escala ràpida aleatòria amb el pitjor cas ràpid d`escala forta, alhora que s`aconsegueix un temps lineal en talls amb determinats patrons.
    /// Utilitza certa aleatorització per evitar casos degenerats, però amb un seed fix per proporcionar sempre un comportament determinista.
    ///
    /// Normalment és més ràpid que l`ordenació estable, excepte en alguns casos especials, per exemple, quan la llesca consta de diverses seqüències ordenades concatenades.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Ordena el segment amb una funció de comparador, però pot no conservar l'ordre dels elements iguals.
    ///
    /// Aquest tipus és inestable (és a dir, pot reordenar elements iguals), al seu lloc (és a dir, no s'assigna) i *O*(*n*\*log(* n*)) en el pitjor dels casos.
    ///
    /// La funció de comparador ha de definir una ordenació total dels elements de la part.Si l`ordenació no és total, l`ordre dels elements no s`especifica.Un ordre és un ordre total si és així (per a tots els `a`, `b` i `c`):
    ///
    /// * total i antisimètric: exactament un de `a < b`, `a == b` o `a > b` és cert, i
    /// * transitiva, `a < b` i `b < c` implica `a < c`.El mateix s`ha de mantenir tant per a `==` com per a `>`.
    ///
    /// Per exemple, mentre que [`f64`] no implementa [`Ord`] perquè `NaN != NaN`, podem utilitzar `partial_cmp` com a funció d'ordenació quan sabem que el segment no conté cap `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Implementació actual
    ///
    /// L`algoritme actual es basa en [pattern-defeating quicksort][pdqsort] d`Orson Peters, que combina el cas mitjà ràpid d`escala ràpida aleatòria amb el pitjor cas ràpid d`escala forta, alhora que s`aconsegueix un temps lineal en talls amb determinats patrons.
    /// Utilitza certa aleatorització per evitar casos degenerats, però amb un seed fix per proporcionar sempre un comportament determinista.
    ///
    /// Normalment és més ràpid que l`ordenació estable, excepte en alguns casos especials, per exemple, quan la llesca consta de diverses seqüències ordenades concatenades.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ordenació inversa
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Ordena el segment amb una funció d`extracció de tecla, però pot no conservar l`ordre dels elements iguals.
    ///
    /// Aquest tipus és inestable (és a dir, pot reordenar elements iguals), al seu lloc (és a dir, no s'assigna) i *O*(m\* * n *\* log(*n*)) en el pitjor dels casos, on la funció de tecla és *O*(*m*).
    ///
    /// # Implementació actual
    ///
    /// L`algoritme actual es basa en [pattern-defeating quicksort][pdqsort] d`Orson Peters, que combina el cas mitjà ràpid d`escala ràpida aleatòria amb el pitjor cas ràpid d`escala forta, alhora que s`aconsegueix un temps lineal en talls amb determinats patrons.
    /// Utilitza certa aleatorització per evitar casos degenerats, però amb un seed fix per proporcionar sempre un comportament determinista.
    ///
    /// A causa de la seva estratègia de trucada de claus, és probable que [`sort_unstable_by_key`](#method.sort_unstable_by_key) sigui més lent que [`sort_by_cached_key`](#method.sort_by_cached_key) en els casos en què la funció de tecla sigui cara.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Torneu a ordenar el segment de manera que l'element de `index` estigui a la seva posició ordenada final.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Torneu a ordenar el segment amb una funció de comparació de manera que l'element de `index` estigui a la seva posició final ordenada.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Torneu a ordenar el segment amb una funció d'extracció de tecles de manera que l'element de `index` estigui a la seva posició final ordenada.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Torneu a ordenar el segment de manera que l'element de `index` estigui a la seva posició ordenada final.
    ///
    /// Aquesta reordenació té la propietat addicional que qualsevol valor de la posició `i < index` serà inferior o igual a qualsevol valor de la posició `j > index`.
    /// A més, aquesta reordenació és inestable (és a dir
    /// qualsevol nombre d'elements iguals pot acabar a la posició `index`), al seu lloc (és a dir
    /// no assigna), i *O*(*n*) en el pitjor dels casos.
    /// Aquesta funció també es coneix com "kth element" en altres biblioteques.
    /// Retorna un triplet dels valors següents: tots els elements inferiors a l`índex donat, el valor a l`índex donat i tots els elements superiors a l`índex donat.
    ///
    ///
    /// # Implementació actual
    ///
    /// L'algorisme actual es basa en la porció de selecció ràpida del mateix algoritme ràpid que s'utilitza per a [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics quan és `index >= len()`, és a dir, sempre panics a rodanxes buides.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Cerqueu la mediana
    /// v.select_nth_unstable(2);
    ///
    /// // Només ens garanteix que la part serà una de les següents, segons la forma d'ordenar l'índex especificat.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Torneu a ordenar el segment amb una funció de comparació de manera que l'element de `index` estigui a la seva posició final ordenada.
    ///
    /// Aquesta reordenació té la propietat addicional que qualsevol valor a la posició `i < index` serà inferior o igual a qualsevol valor en una posició `j > index` mitjançant la funció de comparador.
    /// A més, aquesta reordenació és inestable (és a dir, qualsevol nombre d'elements iguals pot acabar a la posició `index`), al lloc (és a dir, no s'assigna) i, en el pitjor dels casos,*O*(*n*).
    /// Aquesta funció també es coneix com "kth element" en altres biblioteques.
    /// Retorna un triplet dels valors següents: tots els elements inferiors a l`índex donat, el valor a l`índex donat i tots els elements superiors a l`índex donat, mitjançant la funció de comparador proporcionada.
    ///
    ///
    /// # Implementació actual
    ///
    /// L'algorisme actual es basa en la porció de selecció ràpida del mateix algoritme ràpid que s'utilitza per a [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics quan és `index >= len()`, és a dir, sempre panics a rodanxes buides.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Cerqueu la mediana com si la llesca estigués ordenada en ordre descendent.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Només ens garanteix que la part serà una de les següents, segons la forma d'ordenar l'índex especificat.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Torneu a ordenar el segment amb una funció d'extracció de tecles de manera que l'element de `index` estigui a la seva posició final ordenada.
    ///
    /// Aquesta reordenació té la propietat addicional que qualsevol valor a la posició `i < index` serà inferior o igual a qualsevol valor en una posició `j > index` mitjançant la funció d'extracció de tecles.
    /// A més, aquesta reordenació és inestable (és a dir, qualsevol nombre d'elements iguals pot acabar a la posició `index`), al lloc (és a dir, no s'assigna) i, en el pitjor dels casos,*O*(*n*).
    /// Aquesta funció també es coneix com "kth element" en altres biblioteques.
    /// Retorna un triplet dels valors següents: tots els elements inferiors a l`índex donat, el valor a l`índex donat i tots els elements superiors a l`índex donat, mitjançant la funció d`extracció de claus proporcionada.
    ///
    ///
    /// # Implementació actual
    ///
    /// L'algorisme actual es basa en la porció de selecció ràpida del mateix algoritme ràpid que s'utilitza per a [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics quan és `index >= len()`, és a dir, sempre panics a rodanxes buides.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Retorna la mediana com si la matriu estigués ordenada segons el valor absolut.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Només ens garanteix que la part serà una de les següents, segons la forma d'ordenar l'índex especificat.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Moveu tots els elements consecutius repetits al final de la secció segons la implementació [`PartialEq`] trait.
    ///
    ///
    /// Retorna dues llesques.El primer no conté elements repetits consecutius.
    /// El segon conté tots els duplicats en cap ordre especificat.
    ///
    /// Si la secció està ordenada, la primera secció retornada no conté duplicats.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Mou tots els elements consecutius menys el primer, al final de la llesca, que compleix una relació d'igualtat determinada.
    ///
    /// Retorna dues llesques.El primer no conté elements repetits consecutius.
    /// El segon conté tots els duplicats en cap ordre especificat.
    ///
    /// La funció `same_bucket` passa les referències a dos elements de la part i ha de determinar si els elements es comparen iguals.
    /// Els elements es passen en ordre contrari al seu ordre a la part, de manera que si `same_bucket(a, b)` retorna `true`, `a` es mou al final de la part.
    ///
    ///
    /// Si la secció està ordenada, la primera secció retornada no conté duplicats.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Tot i que tenim una referència mutable a `self`, no podem fer canvis * arbitraris.Les trucades `same_bucket` podrien ser panic, de manera que hem d'assegurar-nos que la porció estigui en un estat vàlid en tot moment.
        //
        // La manera com gestionem això és mitjançant swaps;fem una iteració per tots els elements, canviant mentre avancem de manera que al final els elements que volem conservar quedin al davant i els que vulguem rebutjar al darrere.
        // A continuació, podem dividir la llesca.
        // Aquesta operació continua sent `O(n)`.
        //
        // Exemple: Comencem en aquest estat, on `r` representa "següent
        // llegir "i `w` representa" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Comparant self[r] amb self [w-1], això no és un duplicat, de manera que canviem self[r] i self[w] (sense efecte com r==w) i després incrementem tant r com w, deixant-nos amb:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // En comparar self[r] amb self [w-1], aquest valor és un duplicat, de manera que incrementem `r` però deixem sense canvis tota la resta:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // En comparar self[r] amb self [w-1], això no és un duplicat, així que canvieu self[r] i self[w] i avanceu rw:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // No és un duplicat, repeteix:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Duplicat, advance r. End de tall.Dividir a w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SEGURETAT: la condició `while` garanteix `next_read` i `next_write`
        // són inferiors a `len`, per tant són dins de `self`.
        // `prev_ptr_write` apunta a un element abans que `ptr_write`, però `next_write` comença a 1, de manera que `prev_ptr_write` no és mai inferior a 0 i es troba dins del segment.
        // Això compleix els requisits per anul・lar la referència a `ptr_read`, `prev_ptr_write` i `ptr_write` i per utilitzar `ptr.add(next_read)`, `ptr.add(next_write - 1)` i `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` també s'incrementa com a màxim una vegada per bucle com a màxim, és a dir, no s'omet cap element quan és possible que calgui canviar-lo.
        //
        // `ptr_read` i `prev_ptr_write` mai assenyalen el mateix element.Això és necessari perquè `&mut *ptr_read`, `&mut* prev_ptr_write` sigui segur.
        // L'explicació és simplement que `next_read >= next_write` sempre és cert, per tant, `next_read > next_write - 1` també ho és.
        //
        //
        //
        //
        //
        unsafe {
            // Eviteu les comprovacions de límits mitjançant punteros en brut.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Mou tots els elements consecutius menys el primer, al final de la part que es resolen a la mateixa tecla.
    ///
    ///
    /// Retorna dues llesques.El primer no conté elements repetits consecutius.
    /// El segon conté tots els duplicats en cap ordre especificat.
    ///
    /// Si la secció està ordenada, la primera secció retornada no conté duplicats.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Gira la llesca al seu lloc de manera que els primers elements `mid` de la llesca es moguin fins al final mentre que els darrers elements `self.len() - mid` es moguin cap al davant.
    /// Després de trucar a `rotate_left`, l'element anterior a l'índex `mid` es convertirà en el primer element del segment.
    ///
    /// # Panics
    ///
    /// Aquesta funció serà panic si `mid` és superior a la longitud del tall.Tingueu en compte que `mid == self.len()` fa _not_ panic i és una rotació sense operacions.
    ///
    /// # Complexity
    ///
    /// Es fa lineal (en temps `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Girar una subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SEGURETAT: el rang `[p.add(mid) - mid, p.add(mid) + k)` és trivial
        // vàlid per llegir i escriure, tal com requereix `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Gira la llesca al seu lloc de manera que els primers elements `self.len() - k` de la llesca es moguin fins al final mentre que els darrers elements `k` es moguin cap al davant.
    /// Després de trucar a `rotate_right`, l'element anterior a l'índex `self.len() - k` es convertirà en el primer element del segment.
    ///
    /// # Panics
    ///
    /// Aquesta funció serà panic si `k` és superior a la longitud del tall.Tingueu en compte que `k == self.len()` fa _not_ panic i és una rotació sense operacions.
    ///
    /// # Complexity
    ///
    /// Es fa lineal (en temps `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Gireu una subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SEGURETAT: el rang `[p.add(mid) - mid, p.add(mid) + k)` és trivial
        // vàlid per llegir i escriure, tal com requereix `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Emplena `self` amb elements mitjançant la clonació de `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Emplena `self` amb els elements retornats convocant un tancament repetidament.
    ///
    /// Aquest mètode utilitza un tancament per crear nous valors.Si preferiu [`Clone`] un valor determinat, utilitzeu [`fill`].
    /// Si voleu utilitzar [`Default`] trait per generar valors, podeu passar [`Default::default`] com a argument.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Copia els elements de `src` a `self`.
    ///
    /// La longitud de `src` ha de ser la mateixa que `self`.
    ///
    /// Si `T` implementa `Copy`, pot ser més performant utilitzar [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Aquesta funció serà panic si les dues llesques tenen longituds diferents.
    ///
    /// # Examples
    ///
    /// Clonació de dos elements d'una llesca a una altra:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Com que les llesques han de tenir la mateixa longitud, tallem la part d'origen de quatre elements a dos.
    /// // Serà panic si no ho fem.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust aplica que només hi pot haver una referència mutable sense referències immutables a una peça de dades concreta en un àmbit concret.
    /// Per això, provar d'utilitzar `clone_from_slice` en una sola part tindrà un error de compilació:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Per solucionar-ho, podem utilitzar [`split_at_mut`] per crear dues subdivisions diferents a partir d'un segment:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Copia tots els elements de `src` a `self` mitjançant un memcpy.
    ///
    /// La longitud de `src` ha de ser la mateixa que `self`.
    ///
    /// Si `T` no implementa `Copy`, utilitzeu [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Aquesta funció serà panic si les dues llesques tenen longituds diferents.
    ///
    /// # Examples
    ///
    /// Copiant dos elements d'una llesca en una altra:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Com que les llesques han de tenir la mateixa longitud, tallem la part d'origen de quatre elements a dos.
    /// // Serà panic si no ho fem.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust aplica que només hi pot haver una referència mutable sense referències immutables a una peça de dades concreta en un àmbit concret.
    /// Per això, provar d'utilitzar `copy_from_slice` en una sola part tindrà un error de compilació:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Per solucionar-ho, podem utilitzar [`split_at_mut`] per crear dues subdivisions diferents a partir d'un segment:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // El camí del codi panic s'ha posat en una funció freda per no inflar el lloc de la trucada.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SEGURETAT: `self` és vàlid per definició per a elements `self.len()`, i `src` sí
        // comprovat per tenir la mateixa longitud.
        // Els talls no es poden superposar perquè les referències mutables són exclusives.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Copia elements d'una part de la llesca a una altra part de si mateixa, mitjançant un memmove.
    ///
    /// `src` és l'interval dins de `self` des del qual es pot copiar.
    /// `dest` és l'índex inicial de l'interval dins de `self` al qual s'ha de copiar, que tindrà la mateixa longitud que `src`.
    /// Els dos intervals poden superposar-se.
    /// Els extrems dels dos intervals han de ser inferiors o iguals a `self.len()`.
    ///
    /// # Panics
    ///
    /// Aquesta funció serà panic si un dels intervals supera el final de la porció o si el final de `src` és abans de l'inici.
    ///
    ///
    /// # Examples
    ///
    /// Copiant quatre bytes dins d'un segment:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SEGURETAT: totes les condicions de `ptr::copy` s'han comprovat anteriorment,
        // igual que els de `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Intercanvia tots els elements de `self` amb els de `other`.
    ///
    /// La longitud de `other` ha de ser la mateixa que `self`.
    ///
    /// # Panics
    ///
    /// Aquesta funció serà panic si les dues llesques tenen longituds diferents.
    ///
    /// # Example
    ///
    /// Intercanvi de dos elements entre llesques:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust aplica que només hi pot haver una referència mutable a una peça de dades concreta en un àmbit concret.
    ///
    /// Per això, provar d'utilitzar `swap_with_slice` en una sola part tindrà un error de compilació:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Per solucionar-ho, podem utilitzar [`split_at_mut`] per crear dues subdivisions diferents que es puguin modificar a partir d'un segment:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SEGURETAT: `self` és vàlid per definició per a elements `self.len()`, i `src` sí
        // comprovat per tenir la mateixa longitud.
        // Els talls no es poden superposar perquè les referències mutables són exclusives.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Funció per calcular les longituds del segment mitjà i final per a `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // El que farem amb `rest` és esbrinar quin múltiple de `U`s podem posar en un nombre més baix de`T`s.
        //
        // I quantes `T` necessitem per a cada "multiple".
        //
        // Considerem per exemple T=u8 U=u16.Després podem posar 1 U en 2 Ts.Senzill.
        // Ara, considerem per exemple un cas en què size_of: :<T>=16, mida_de::<U>=24.</u>
        // Podem col・locar 2 Us en lloc de cada 3 Ts a la porció `rest`.
        // Una mica més complicat.
        //
        // La fórmula per calcular-ho és:
        //
        // Nosaltres= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Ampliat i simplificat:
        //
        // Nosaltres=mida_de: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Per sort, ja que tot això s`avalua constantment ... el rendiment aquí no importa.
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // algoritme de stein iteratiu Encara hauríem de fer aquest `const fn` (i tornar-ho a l'algorisme recursiu si ho fem) perquè confiar en llvm per determinar tot això és ... bé, em fa incòmode.
            //
            //

            // SEGURETAT: es comprova que `a` i `b` són valors diferents de zero.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // elimineu tots els factors de 2 de b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SEGURETAT: es comprova que `b` no és zero.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Armats amb aquest coneixement, podem trobar quantes `U`s podem encabir.
        let us_len = self.len() / ts * us;
        // I quants `T` hi haurà a la part final!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Transmuteu el segment a un altre tipus, garantint que es mantingui l'alineació dels tipus.
    ///
    /// Aquest mètode divideix el segment en tres segments diferents: prefix, segment central correctament alineat d'un nou tipus i el segment de sufix.
    /// El mètode pot fer que la llesca mitjana sigui la més gran possible per a un tipus i una secció d`entrada determinats, però només el rendiment de l`algorisme hauria de dependre d`això, no de la seva correcció.
    ///
    /// Es permet que totes les dades d'entrada es retornin com a prefix o segment de sufix.
    ///
    /// Aquest mètode no té cap propòsit quan l`element d`entrada `T` o l`element de sortida `U` tenen una mida zero i retornaran el segment original sense dividir res.
    ///
    /// # Safety
    ///
    /// Aquest mètode és essencialment un `transmute` respecte als elements de la part mitjana retornada, de manera que també s'apliquen aquí totes les advertències habituals relatives a `transmute::<T, U>`.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Tingueu en compte que la major part d'aquesta funció serà avaluada constantment,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // manejar les ZST especialment, és a dir, no les manipuleu gens.
            return (self, &[], &[]);
        }

        // Primer, busqueu en quin moment ens dividim entre la primera i la segona llesca.
        // Fàcil amb ptr.align_offset.
        let ptr = self.as_ptr();
        // SEGURETAT: consulteu el mètode `align_to_mut` per obtenir el comentari detallat de seguretat.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SEGURETAT: ara `rest` està definitivament alineat, de manera que `from_raw_parts` a continuació està bé,
            // ja que la persona que truca garanteix que podem transmutar `T` a `U` amb seguretat.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Transmuteu el segment a un altre tipus, garantint que es mantingui l'alineació dels tipus.
    ///
    /// Aquest mètode divideix el segment en tres segments diferents: prefix, segment central correctament alineat d'un nou tipus i el segment de sufix.
    /// El mètode pot fer que la llesca mitjana sigui la més gran possible per a un tipus i una secció d`entrada determinats, però només el rendiment de l`algorisme hauria de dependre d`això, no de la seva correcció.
    ///
    /// Es permet que totes les dades d'entrada es retornin com a prefix o segment de sufix.
    ///
    /// Aquest mètode no té cap propòsit quan l`element d`entrada `T` o l`element de sortida `U` tenen una mida zero i retornaran el segment original sense dividir res.
    ///
    /// # Safety
    ///
    /// Aquest mètode és essencialment un `transmute` respecte als elements de la part mitjana retornada, de manera que també s'apliquen aquí totes les advertències habituals relatives a `transmute::<T, U>`.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Tingueu en compte que la major part d'aquesta funció serà avaluada constantment,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // manejar les ZST especialment, és a dir, no les manipuleu gens.
            return (self, &mut [], &mut []);
        }

        // Primer, busqueu en quin moment ens dividim entre la primera i la segona llesca.
        // Fàcil amb ptr.align_offset.
        let ptr = self.as_ptr();
        // SEGURETAT: aquí ens assegurem que utilitzarem punteres alineats per a U per a
        // resta del mètode.Això es fa passant un punter a&[T] amb una alineació orientada a U.
        // `crate::ptr::align_offset` es diu amb un punter `ptr` correctament alineat i vàlid (prové d`una referència a `self`) i amb una mida que potència de dos (ja que prové de l`alineació per a U), satisfent les seves limitacions de seguretat.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // No podem tornar a utilitzar `rest` després d'això, cosa que invalidaria el seu àlies `mut_ptr`.SEGURETAT: vegeu els comentaris de `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Comprova si s`ordenen els elements d`aquest segment.
    ///
    /// És a dir, per a cada element `a` i el seu següent element `b`, `a <= b` ha de contenir.Si el segment produeix exactament zero o un element, es retorna `true`.
    ///
    /// Tingueu en compte que si `Self::Item` només és `PartialOrd`, però no `Ord`, la definició anterior implica que aquesta funció retorna `false` si dos elements consecutius no són comparables.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Comprova si els elements d`aquest segment s`ordenen mitjançant la funció de comparador donada.
    ///
    /// En lloc d'utilitzar `PartialOrd::partial_cmp`, aquesta funció utilitza la funció `compare` donada per determinar l'ordenació de dos elements.
    /// A part d'això, equival a [`is_sorted`];consulteu la seva documentació per obtenir més informació.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Comprova si els elements d`aquest segment s`ordenen mitjançant la funció d`extracció de tecles donada.
    ///
    /// En lloc de comparar directament els elements de la llesca, aquesta funció compara les tecles dels elements, tal com determina `f`.
    /// A part d'això, equival a [`is_sorted`];consulteu la seva documentació per obtenir més informació.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Retorna l'índex del punt de partició segons el predicat donat (l'índex del primer element de la segona partició).
    ///
    /// Es suposa que la secció està particionada segons el predicat donat.
    /// Això significa que tots els elements per als quals el predicat torna cert són al començament de la part i tots els elements per als quals el predicat torna fals són al final.
    ///
    /// Per exemple, [7, 15, 3, 5, 4, 12, 6] és un particionat sota el predicat x% 2!=0 (tots els nombres senars són al principi, tots parells al final).
    ///
    /// Si aquest segment no està particionat, el resultat retornat no és especificat i no té sentit, ja que aquest mètode realitza una mena de cerca binària.
    ///
    /// Vegeu també [`binary_search`], [`binary_search_by`] i [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SEGURETAT: quan `left < right`, `left <= mid < right`.
            // Per tant, `left` sempre augmenta i `right` sempre disminueix, i se selecciona qualsevol d'ells.En ambdós casos `left <= right` està satisfet.Per tant, si `left < right` en un pas, `left <= right` queda satisfet en el següent pas.
            //
            // Per tant, sempre que `left != right`, `0 <= left < right <= len` estigui satisfet i, en aquest cas, `0 <= mid < len` també.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Els hem de tallar explícitament a la mateixa longitud
        // per facilitar que l'optimitzador elimini la comprovació dels límits.
        // Però com que no es pot confiar en nosaltres, també tenim una especialització explícita per a T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Crea un segment buit.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Crea un segment buit mutable.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Patrons en llesques, actualment, només els utilitzen `strip_prefix` i `strip_suffix`.
/// En un punt future, esperem generalitzar `core::str::Pattern` (que en el moment de l'escriptura es limita a `str`) a talls, i després aquest trait serà substituït o abolit.
///
pub trait SlicePattern {
    /// El tipus d`element de la llesca on es fa coincidir.
    type Item;

    /// Actualment, els consumidors de `SlicePattern` necessiten una porció.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}