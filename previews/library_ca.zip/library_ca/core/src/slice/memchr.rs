// Implementació original extreta de rust-memchr.
// Copyright 2015 Andrew Gallant, bluss i Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Utilitzeu truncament.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Retorna `true` si `x` conté qualsevol byte zero.
///
/// De *Matters Computational*, J. Arndt:
///
/// "La idea és restar-ne un de cadascun dels bytes i, a continuació, buscar bytes on el préstec es propagui fins al més significatiu
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Retorna el primer índex que coincideix amb el byte `x` a `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Camí ràpid per a rodanxes petites
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Cerqueu un valor de byte únic llegint dues paraules `usize` alhora.
    //
    // Divideix `text` en tres parts
    // - part inicial sense alinear, abans de la primera adreça alineada al text
    // - cos, escaneja 2 paraules alhora
    // - l'última part restant, mida de <2 paraules

    // cerqueu fins a un límit alineat
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // cerqueu el cos del text
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SEGURETAT: el predicat de mentre garanteix una distància d'almenys 2 * usize_bytes
        // entre el desplaçament i el final de la llesca.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // trenca si hi ha un byte coincident
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Cerqueu el byte després del punt en què es va aturar el bucle del cos.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Retorna l'últim índex que coincideix amb l'octet `x` a `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Cerqueu un valor de byte únic llegint dues paraules `usize` alhora.
    //
    // Divideix `text` en tres parts:
    // - cua no alineada, després de l`última adreça alineada al text,
    // - cos, escanejat per dues paraules alhora,
    // - els primers bytes restants, mida de <2 paraules.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Anomenem això només per obtenir la longitud del prefix i del sufix.
        // Al centre sempre processem dos trossos alhora.
        // SEGURETAT: la transmutació de `[u8]` a `[usize]` és segura, llevat de les diferències de mida que gestiona `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Cerqueu el cos del text i assegureu-vos que no creuem min_aligned_offset.
    // el desplaçament sempre està alineat, de manera que només és suficient provar `>` i evitar un possible desbordament.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SEGURETAT: el desplaçament comença a len, suffix.len(), sempre que sigui superior a
        // min_aligned_offset (prefix.len()) la distància restant és d'almenys 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Trenca si hi ha un byte coincident.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Cerqueu el byte abans del punt en què s'hagi aturat el bucle del cos.
    text[..offset].iter().rposition(|elt| *elt == x)
}