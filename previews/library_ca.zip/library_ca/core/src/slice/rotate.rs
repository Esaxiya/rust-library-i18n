// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Gira l'interval `[mid-left, mid+right)` de manera que l'element de `mid` es converteixi en el primer element.Equivalentment, gira els elements de l'interval `left` cap a l'esquerra o els elements `right` cap a la dreta.
///
/// # Safety
///
/// L'interval especificat ha de ser vàlid per llegir i escriure.
///
/// # Algorithm
///
/// L`algorisme 1 s`utilitza per a valors petits de `left + right` o per a `T` grans.
/// Els elements es mouen a les seves posicions finals un a un, començant per `mid - left` i avançant per passos `right` mòdul `left + right`, de manera que només es necessita un temporal.
/// Finalment, arribem de nou al `mid - left`.
/// Tanmateix, si `gcd(left + right, right)` no és 1, els passos anteriors van saltar els elements.
/// Per exemple:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Afortunadament, el nombre d`elements saltats entre els elements finalitzats sempre és igual, de manera que només podem compensar la nostra posició inicial i fer més rondes (el nombre total de rondes és el `gcd(left + right, right)` value).
///
/// El resultat final és que tots els elements es finalitzen una vegada i només una vegada.
///
/// L`algoritme 2 s`utilitza si `left + right` és gran, però `min(left, right)` és prou petit per cabre en un buffer de pila.
/// Els elements `min(left, right)` es copien a la memòria intermèdia, `memmove` s'aplica als altres i els de la memòria intermèdia es tornen a moure al forat del costat oposat d'on es van originar.
///
/// Els algorismes que es poden vectoritzar superen els anteriors una vegada que `left + right` es fa prou gran.
/// L'algoritme 1 es pot vectoritzar mitjançant un tros i realitzant moltes rondes alhora, però hi ha massa poques rondes de mitjana fins que `left + right` és enorme, i el pitjor cas d'una sola volta sempre hi és.
/// En canvi, l'algorisme 3 utilitza l'intercanvi repetitiu d'elements `min(left, right)` fins que queda un problema de rotació més petit.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// quan `left < right` canvia l'intercanvi des de l'esquerra.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. els algoritmes següents poden fallar si no es comproven aquests casos
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritme 1 Microbenchmarks indica que el rendiment mitjà dels canvis aleatoris és millor fins a aproximadament `left + right == 32`, però el rendiment del pitjor dels casos arriba fins als 16.
            // 24 va ser escollit com a punt de partida.
            // Si la mida de `T` és superior a 4 usize, aquest algorisme també supera els altres algorismes.
            //
            //
            let x = unsafe { mid.sub(left) };
            // començament de la primera ronda
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` es pot trobar prèviament calculant `gcd(left + right, right)`, però és més ràpid fer un bucle que calcula el mcd com a efecte secundari, fent la resta del tros
            //
            //
            let mut gcd = right;
            // els paràmetres de referència revelen que és més ràpid canviar temporals en tot el lloc en lloc de llegir-ne un de temporal, copiar cap enrere i, després, escriure aquest temporal al final.
            // Això es deu possiblement al fet que intercanviar o substituir temporals només utilitza una adreça de memòria al bucle en lloc de necessitar-ne gestionar dues.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // en lloc d`incrementar `i` i després comprovar si està fora dels límits, comprovem si `i` sortirà dels límits en el següent increment.
                // Això evita qualsevol embolicament de punteres o `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // final de la primera ronda
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // aquest condicional ha d'estar aquí si `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // acabar el tros amb més rondes
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` no és de tipus zero, per tant, està bé dividir per la seva mida.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritme 2 El `[T; 0]` aquí és per assegurar-se que estigui adequadament alineat per a T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritme 3 Hi ha una manera alternativa d`intercanviar que consisteix a trobar on seria l`últim intercanvi d`aquest algorisme, i intercanviar utilitzant aquest darrer tros en lloc d`intercanviar trossos adjacents com fa aquest algorisme, però aquesta manera encara és més ràpida.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algorisme 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}