use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Retorna `true` si el punter és nul.
    ///
    /// Tingueu en compte que els tipus sense mida tenen molts possibles indicadors nuls, ja que només es té en compte el punter de dades brutes, no la seva longitud, vtable, etc.
    /// Per tant, és possible que dos indicadors que siguin nuls no es comparin iguals entre si.
    ///
    /// ## Comportament durant l'avaluació de constants
    ///
    /// Quan s'utilitza aquesta funció durant l'avaluació de constants, pot retornar `false` per als indicadors que resultin nuls en temps d'execució.
    /// Concretament, quan un punter cap a una memòria es desplaça més enllà dels seus límits de manera que el punter resultant sigui nul, la funció encara retornarà `false`.
    ///
    /// No hi ha manera que CTFE conegui la posició absoluta d`aquesta memòria, de manera que no podem saber si el punter és nul o no.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Compareu-ho mitjançant un repartiment amb un punter prim, de manera que els indicadors greixos només consideren la seva part "data" com a nul・la.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Emet a un punter d'un altre tipus.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Descomponeu un punter (possiblement ampli) en components d'adreça i metadades.
    ///
    /// El punter es pot reconstruir posteriorment amb [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Retorna `None` si el punter és nul, o bé retorna una referència compartida al valor embolicat a `Some`.Si el valor no es pot inicialitzar, s'ha d'utilitzar [`as_uninit_ref`].
    ///
    /// Per a la contrapart mutable, vegeu [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Quan truqueu a aquest mètode, heu d'assegurar-vos que *el punter sigui NUL* o que sigui cert tot el següent:
    ///
    /// * El punter ha d`estar alineat correctament.
    ///
    /// * Ha de ser "dereferencable" en el sentit definit a [the module documentation].
    ///
    /// * El punter ha d`assenyalar una instància inicialitzada de `T`.
    ///
    /// * Heu de fer complir les regles d`aliasing de Rust, ja que la vida útil retornada `'a` és elegida arbitràriament i no reflecteix necessàriament la vida real real de les dades.
    ///   En particular, durant tota aquesta vida, la memòria a què apunta el punter no s'ha de mutar (excepte dins de `UnsafeCell`).
    ///
    /// Això s'aplica fins i tot si el resultat d'aquest mètode no s'utilitza.
    /// (La part sobre la inicialització encara no està del tot decidida, però fins que no sigui així, l`únic enfocament segur és assegurar-se que s`inicialitzin.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Versió nul・la sense comprovar
    ///
    /// Si esteu segur que el punter mai pot ser nul i esteu buscant algun tipus de `as_ref_unchecked` que retorni el `&T` en lloc de `Option<&T>`, sabeu que podeu desferreferir-lo directament.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SEGURETAT: la persona que truca ha de garantir que `self` és vàlid per a un
        // referència si no és nul・la.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Retorna `None` si el punter és nul, o bé retorna una referència compartida al valor embolicat a `Some`.
    /// A diferència de [`as_ref`], això no requereix que s'hagi d'inicialitzar el valor.
    ///
    /// Per a la contrapart mutable, vegeu [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Quan truqueu a aquest mètode, heu d'assegurar-vos que *el punter sigui NUL* o que sigui cert tot el següent:
    ///
    /// * El punter ha d`estar alineat correctament.
    ///
    /// * Ha de ser "dereferencable" en el sentit definit a [the module documentation].
    ///
    /// * Heu de fer complir les regles d`aliasing de Rust, ja que la vida útil retornada `'a` és elegida arbitràriament i no reflecteix necessàriament la vida real real de les dades.
    ///
    ///   En particular, durant tota aquesta vida, la memòria a què apunta el punter no s'ha de mutar (excepte dins de `UnsafeCell`).
    ///
    /// Això s'aplica fins i tot si el resultat d'aquest mètode no s'utilitza.
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SEGURETAT: la persona que truca ha de garantir que `self` compleix tots els requisits
        // requisits per a una referència.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Calcula el desplaçament d'un punter.
    ///
    /// `count` està en unitats de T;per exemple, un `count` de 3 representa un desplaçament del punter de bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Si s`incompleix alguna de les condicions següents, el resultat és Comportament indefinit:
    ///
    /// * Tant el punter inicial com el resultant han d'estar entre límits o un byte més enllà del final del mateix objecte assignat.
    /// Tingueu en compte que a Rust, cada variable (stack-allocated) es considera un objecte assignat independent.
    ///
    /// * El desplaçament calculat,**en bytes**, no pot desbordar un `isize`.
    ///
    /// * El desplaçament entre límits no pot dependre de l'espai d'adreces "wrapping around".És a dir, la suma de precisió infinita,**en bytes**, ha de cabre en una mida usada.
    ///
    /// El compilador i la biblioteca estàndard generalment intenten garantir que les assignacions no arribin mai a una mida en què un desplaçament sigui un problema.
    /// Per exemple, `Vec` i `Box` asseguren que mai no assignen més de `isize::MAX` bytes, de manera que `vec.as_ptr().add(vec.len())` sempre és segur.
    ///
    /// La majoria de les plataformes no poden ni tan sols construir aquesta assignació.
    /// Per exemple, cap plataforma de 64 bits coneguda mai pot publicar una sol・licitud de 2 <sup>63</sup> bytes a causa de les limitacions de la taula de pàgines o la divisió de l'espai d'adreces.
    /// Tanmateix, algunes plataformes de 32 i 16 bits poden publicar amb èxit una sol・licitud de més de `isize::MAX` bytes amb aspectes com l'extensió d'adreces físiques.
    ///
    /// Com a tal, la memòria adquirida directament dels assignadors o fitxers assignats a la memòria *pot* ser massa gran per manejar-la amb aquesta funció.
    ///
    /// Penseu a utilitzar [`wrapping_offset`] si aquestes limitacions són difícils de satisfer.
    /// L'únic avantatge d'aquest mètode és que permet optimitzacions de compiladors més agressives.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `offset`.
        // El punter obtingut és vàlid per a escriptures, ja que la persona que truca ha de garantir que apunti al mateix objecte assignat que `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Calcula el desplaçament d'un punter mitjançant l'aritmètica d'embolcall.
    /// `count` està en unitats de T;per exemple, un `count` de 3 representa un desplaçament del punter de bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Aquesta operació en si mateixa sempre és segura, però no ho és fer servir el punter resultant.
    ///
    /// El punter resultant roman unit al mateix objecte assignat al qual apunta `self`.
    /// *No* es pot utilitzar per accedir a un objecte assignat diferent.Tingueu en compte que a Rust, cada variable (stack-allocated) es considera un objecte assignat independent.
    ///
    /// Dit d`una altra manera, `let z = x.wrapping_offset((y as isize) - (x as isize))`*no* fa que `z` sigui igual que `y`, fins i tot si suposem que `T` té la mida `1` i no hi ha desbordament: `z` encara està unit a l`objecte al qual s`adjunta `x` i la seva derivació és Comportament indefinit tret que `x` i `y` apunta al mateix objecte assignat.
    ///
    /// En comparació amb [`offset`], aquest mètode retarda bàsicament el requisit de mantenir-se dins del mateix objecte assignat: [`offset`] és un comportament indefinit immediat quan es creuen els límits dels objectes;`wrapping_offset` produeix un punter però encara porta a Comportament indefinit si es desferencia un punter quan està fora dels límits de l'objecte al qual està unit.
    /// [`offset`] es pot optimitzar millor i, per tant, és preferible en el codi sensible al rendiment.
    ///
    /// La comprovació retardada només té en compte el valor del punter que es va referenciar, no els valors intermedis utilitzats durant el càlcul del resultat final.
    /// Per exemple, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` sempre és el mateix que `x`.En altres paraules, es permet deixar l'objecte assignat i tornar-lo a introduir més tard.
    ///
    /// Si heu de creuar els límits de l`objecte, col・loqueu el punter a un enter i feu-hi l`aritmètica.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// // Iterar amb un punter en brut en increments de dos elements
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SEGURETAT: el `arith_offset` intrínsec no té requisits previs per ser cridat.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Retorna `None` si el punter és nul, o bé retorna una referència única al valor embolicat a `Some`.Si el valor no es pot inicialitzar, s'ha d'utilitzar [`as_uninit_mut`].
    ///
    /// Per a la contrapartida compartida, consulteu [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Quan truqueu a aquest mètode, heu d'assegurar-vos que *el punter sigui NUL* o que sigui cert tot el següent:
    ///
    /// * El punter ha d`estar alineat correctament.
    ///
    /// * Ha de ser "dereferencable" en el sentit definit a [the module documentation].
    ///
    /// * El punter ha d`assenyalar una instància inicialitzada de `T`.
    ///
    /// * Heu de fer complir les regles d`aliasing de Rust, ja que la vida útil retornada `'a` és elegida arbitràriament i no reflecteix necessàriament la vida real real de les dades.
    ///   En particular, durant tota aquesta vida, la memòria a la qual apunta el punter no ha de tenir accés (llegida o escrita) a través de cap altre punter.
    ///
    /// Això s'aplica fins i tot si el resultat d'aquest mètode no s'utilitza.
    /// (La part sobre la inicialització encara no està del tot decidida, però fins que no sigui així, l`únic enfocament segur és assegurar-se que s`inicialitzin.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // S'imprimirà: "[4, 2, 3]".
    /// ```
    ///
    /// # Versió nul・la sense comprovar
    ///
    /// Si esteu segur que el punter mai pot ser nul i esteu buscant algun tipus de `as_mut_unchecked` que retorni el `&mut T` en lloc de `Option<&mut T>`, sabeu que podeu desferreferir-lo directament.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // S'imprimirà: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // SEGURETAT: la persona que truca ha de garantir que el `self` és vàlid per a
        // una referència mutable si no és nul・la.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Retorna `None` si el punter és nul, o bé retorna una referència única al valor embolicat a `Some`.
    /// A diferència de [`as_mut`], això no requereix que s'hagi d'inicialitzar el valor.
    ///
    /// Per a la contrapartida compartida, consulteu [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Quan truqueu a aquest mètode, heu d'assegurar-vos que *el punter sigui NUL* o que sigui cert tot el següent:
    ///
    /// * El punter ha d`estar alineat correctament.
    ///
    /// * Ha de ser "dereferencable" en el sentit definit a [the module documentation].
    ///
    /// * Heu de fer complir les regles d`aliasing de Rust, ja que la vida útil retornada `'a` és elegida arbitràriament i no reflecteix necessàriament la vida real real de les dades.
    ///
    ///   En particular, durant tota aquesta vida, la memòria a la qual apunta el punter no ha de tenir accés (llegida o escrita) a través de cap altre punter.
    ///
    /// Això s'aplica fins i tot si el resultat d'aquest mètode no s'utilitza.
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // SEGURETAT: la persona que truca ha de garantir que `self` compleix tots els requisits
        // requisits per a una referència.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Retorna si es garanteix que dos indicadors són iguals.
    ///
    /// En temps d'execució, aquesta funció es comporta com `self == other`.
    /// No obstant això, en alguns contextos (per exemple, avaluació en temps de compilació), no sempre és possible determinar la igualtat de dos punters, de manera que aquesta funció pot retornar `false` de manera espúria per als punters que després resultin ser iguals.
    ///
    /// Però quan retorna `true`, es garanteix que els indicadors són iguals.
    ///
    /// Aquesta funció és el mirall de [`guaranteed_ne`], però no la seva inversa.Hi ha comparacions de punteres per a les quals ambdues funcions retornen `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// El valor de retorn pot variar en funció de la versió del compilador i és possible que el codi no segur no es basi en el resultat d'aquesta funció per obtenir una solidesa.
    /// Es recomana utilitzar aquesta funció només per a optimitzacions de rendiment on els valors de retorn falsos de `false` per aquesta funció no afecten el resultat, sinó només el rendiment.
    /// No s'han explorat les conseqüències d'utilitzar aquest mètode per fer que el temps d'execució i el codi de compilació es comportin de manera diferent.
    /// Aquest mètode no s'hauria d'utilitzar per introduir aquestes diferències, i tampoc no s'hauria d'estabilitzar abans de comprendre millor aquest problema.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Torna si es garanteix que dos indicadors són desiguals.
    ///
    /// En temps d'execució, aquesta funció es comporta com `self != other`.
    /// Tanmateix, en alguns contextos (per exemple, avaluació en temps de compilació), no sempre és possible determinar la desigualtat de dos punters, de manera que aquesta funció pot retornar `false` esporiósament per als punters que després resultin ser desiguals.
    ///
    /// Però quan retorna `true`, es garanteix que els indicadors seran desiguals.
    ///
    /// Aquesta funció és el mirall de [`guaranteed_eq`], però no la seva inversa.Hi ha comparacions de punteres per a les quals ambdues funcions retornen `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// El valor de retorn pot variar en funció de la versió del compilador i és possible que el codi no segur no es basi en el resultat d'aquesta funció per obtenir una solidesa.
    /// Es recomana utilitzar aquesta funció només per a optimitzacions de rendiment on els valors de retorn falsos de `false` per aquesta funció no afecten el resultat, sinó només el rendiment.
    /// No s'han explorat les conseqüències d'utilitzar aquest mètode per fer que el temps d'execució i el codi de compilació es comportin de manera diferent.
    /// Aquest mètode no s'hauria d'utilitzar per introduir aquestes diferències, i tampoc no s'hauria d'estabilitzar abans de comprendre millor aquest problema.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Calcula la distància entre dos punteres.El valor retornat és en unitats de T: la distància en bytes es divideix per `mem::size_of::<T>()`.
    ///
    /// Aquesta funció és la inversa de [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Si s`incompleix alguna de les condicions següents, el resultat és Comportament indefinit:
    ///
    /// * Tant el punter inicial com l'altre han d'estar entre límits o un byte més enllà del final del mateix objecte assignat.
    /// Tingueu en compte que a Rust, cada variable (stack-allocated) es considera un objecte assignat independent.
    ///
    /// * Els dos indicadors han de ser *derivats d'un* punter cap al mateix objecte.
    ///   (Vegeu un exemple a continuació.)
    ///
    /// * La distància entre els punteres, en bytes, ha de ser un múltiple exacte de la mida de `T`.
    ///
    /// * La distància entre els punteres,**en bytes**, no pot desbordar un `isize`.
    ///
    /// * La distància entre límits no pot dependre de l'espai d'adreces "wrapping around".
    ///
    /// Els tipus Rust mai són superiors a les assignacions `isize::MAX` i Rust mai no s`envolten a l`espai d`adreces, de manera que dos indicadors dins d`un valor de qualsevol tipus Rust tipus `T` sempre compliran les dues darreres condicions.
    ///
    /// La biblioteca estàndard també garanteix generalment que les assignacions no arribin mai a una mida en què un desplaçament sigui preocupant.
    /// Per exemple, `Vec` i `Box` asseguren que mai no assignen més de bytes `isize::MAX`, de manera que `ptr_into_vec.offset_from(vec.as_ptr())` sempre compleix les dues darreres condicions.
    ///
    /// La majoria de les plataformes no poden ni tan sols construir una assignació tan gran.
    /// Per exemple, cap plataforma de 64 bits coneguda mai pot publicar una sol・licitud de 2 <sup>63</sup> bytes a causa de les limitacions de la taula de pàgines o la divisió de l'espai d'adreces.
    /// Tanmateix, algunes plataformes de 32 i 16 bits poden publicar amb èxit una sol・licitud de més de `isize::MAX` bytes amb aspectes com l'extensió d'adreces físiques.
    /// Com a tal, la memòria adquirida directament dels assignadors o fitxers assignats a la memòria *pot* ser massa gran per manejar-la amb aquesta funció.
    /// (Tingueu en compte que [`offset`] i [`add`] també tenen una limitació similar i, per tant, tampoc no es poden utilitzar en assignacions tan grans.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Aquesta funció és panics si `T` és un tipus ("ZST") de mida zero.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Ús incorrecte*:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Feu ptr2_other un "alias" de ptr2, però derivat de ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Com que ptr2_other i ptr2 es deriven de punteres a objectes diferents, el càlcul del seu desplaçament és un comportament indefinit, tot i que apunten a la mateixa adreça.
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Comportament sense definir
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Calcula el desplaçament des d`un punter (comoditat per a `.offset(count as isize)`).
    ///
    /// `count` està en unitats de T;per exemple, un `count` de 3 representa un desplaçament del punter de bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Si s`incompleix alguna de les condicions següents, el resultat és Comportament indefinit:
    ///
    /// * Tant el punter inicial com el resultant han d'estar entre límits o un byte més enllà del final del mateix objecte assignat.
    /// Tingueu en compte que a Rust, cada variable (stack-allocated) es considera un objecte assignat independent.
    ///
    /// * El desplaçament calculat,**en bytes**, no pot desbordar un `isize`.
    ///
    /// * El desplaçament entre límits no pot dependre de l'espai d'adreces "wrapping around".És a dir, la suma de precisió infinita ha de cabre en un `usize`.
    ///
    /// El compilador i la biblioteca estàndard generalment intenten garantir que les assignacions no arribin mai a una mida en què un desplaçament sigui un problema.
    /// Per exemple, `Vec` i `Box` asseguren que mai no assignen més de `isize::MAX` bytes, de manera que `vec.as_ptr().add(vec.len())` sempre és segur.
    ///
    /// La majoria de les plataformes no poden ni tan sols construir aquesta assignació.
    /// Per exemple, cap plataforma de 64 bits coneguda mai pot publicar una sol・licitud de 2 <sup>63</sup> bytes a causa de les limitacions de la taula de pàgines o la divisió de l'espai d'adreces.
    /// Tanmateix, algunes plataformes de 32 i 16 bits poden publicar amb èxit una sol・licitud de més de `isize::MAX` bytes amb aspectes com l'extensió d'adreces físiques.
    ///
    /// Com a tal, la memòria adquirida directament dels assignadors o fitxers assignats a la memòria *pot* ser massa gran per manejar-la amb aquesta funció.
    ///
    /// Penseu a utilitzar [`wrapping_add`] si aquestes limitacions són difícils de satisfer.
    /// L'únic avantatge d'aquest mètode és que permet optimitzacions de compiladors més agressives.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Calcula el desplaçament des d'un punter (comoditat per a.. Offset ((compta com a isize).wrapping_neg())`).
    ///
    /// `count` està en unitats de T;per exemple, un `count` de 3 representa un desplaçament del punter de bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Si s`incompleix alguna de les condicions següents, el resultat és Comportament indefinit:
    ///
    /// * Tant el punter inicial com el resultant han d'estar entre límits o un byte més enllà del final del mateix objecte assignat.
    /// Tingueu en compte que a Rust, cada variable (stack-allocated) es considera un objecte assignat independent.
    ///
    /// * El desplaçament calculat no pot superar `isize::MAX`**bytes**.
    ///
    /// * El desplaçament entre límits no pot dependre de l'espai d'adreces "wrapping around".És a dir, la suma de precisió infinita ha d`encaixar en un usize.
    ///
    /// El compilador i la biblioteca estàndard generalment intenten garantir que les assignacions no arribin mai a una mida en què un desplaçament sigui un problema.
    /// Per exemple, `Vec` i `Box` asseguren que mai no assignen més de `isize::MAX` bytes, de manera que `vec.as_ptr().add(vec.len()).sub(vec.len())` sempre és segur.
    ///
    /// La majoria de les plataformes no poden ni tan sols construir aquesta assignació.
    /// Per exemple, cap plataforma de 64 bits coneguda mai pot publicar una sol・licitud de 2 <sup>63</sup> bytes a causa de les limitacions de la taula de pàgines o la divisió de l'espai d'adreces.
    /// Tanmateix, algunes plataformes de 32 i 16 bits poden publicar amb èxit una sol・licitud de més de `isize::MAX` bytes amb aspectes com l'extensió d'adreces físiques.
    ///
    /// Com a tal, la memòria adquirida directament dels assignadors o fitxers assignats a la memòria *pot* ser massa gran per manejar-la amb aquesta funció.
    ///
    /// Penseu a utilitzar [`wrapping_sub`] si aquestes limitacions són difícils de satisfer.
    /// L'únic avantatge d'aquest mètode és que permet optimitzacions de compiladors més agressives.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Calcula el desplaçament d'un punter mitjançant l'aritmètica d'embolcall.
    /// (comoditat per a `.wrapping_offset(count as isize)`)
    ///
    /// `count` està en unitats de T;per exemple, un `count` de 3 representa un desplaçament del punter de bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Aquesta operació en si mateixa sempre és segura, però no ho és fer servir el punter resultant.
    ///
    /// El punter resultant roman unit al mateix objecte assignat al qual apunta `self`.
    /// *No* es pot utilitzar per accedir a un objecte assignat diferent.Tingueu en compte que a Rust, cada variable (stack-allocated) es considera un objecte assignat independent.
    ///
    /// Dit d`una altra manera, `let z = x.wrapping_add((y as usize) - (x as usize))`*no* fa que `z` sigui igual que `y`, fins i tot si suposem que `T` té la mida `1` i no hi ha desbordament: `z` encara està unit a l`objecte al qual s`adjunta `x` i la seva derivació és Comportament indefinit tret que `x` i `y` apunta al mateix objecte assignat.
    ///
    /// En comparació amb [`add`], aquest mètode retarda bàsicament el requisit de mantenir-se dins del mateix objecte assignat: [`add`] és un comportament indefinit immediat quan es creuen els límits dels objectes;`wrapping_add` produeix un punter però encara porta a Comportament indefinit si es desferencia un punter quan està fora dels límits de l'objecte al qual està unit.
    /// [`add`] es pot optimitzar millor i, per tant, és preferible en el codi sensible al rendiment.
    ///
    /// La comprovació retardada només té en compte el valor del punter que es va referenciar, no els valors intermedis utilitzats durant el càlcul del resultat final.
    /// Per exemple, `x.wrapping_add(o).wrapping_sub(o)` sempre és el mateix que `x`.En altres paraules, es permet deixar l'objecte assignat i tornar-lo a introduir més tard.
    ///
    /// Si heu de creuar els límits de l`objecte, col・loqueu el punter a un enter i feu-hi l`aritmètica.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// // Iterar amb un punter en brut en increments de dos elements
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Aquest bucle imprimeix "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Calcula el desplaçament d'un punter mitjançant l'aritmètica d'embolcall.
    /// (comoditat per a `.wrapping_offset ((compta com a isize).wrapping_neg())`)
    ///
    /// `count` està en unitats de T;per exemple, un `count` de 3 representa un desplaçament del punter de bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Aquesta operació en si mateixa sempre és segura, però no ho és fer servir el punter resultant.
    ///
    /// El punter resultant roman unit al mateix objecte assignat al qual apunta `self`.
    /// *No* es pot utilitzar per accedir a un objecte assignat diferent.Tingueu en compte que a Rust, cada variable (stack-allocated) es considera un objecte assignat independent.
    ///
    /// Dit d`una altra manera, `let z = x.wrapping_sub((x as usize) - (y as usize))`*no* fa que `z` sigui igual que `y`, fins i tot si suposem que `T` té la mida `1` i no hi ha desbordament: `z` encara està unit a l`objecte al qual s`adjunta `x` i la seva derivació és Comportament indefinit tret que `x` i `y` apunta al mateix objecte assignat.
    ///
    /// En comparació amb [`sub`], aquest mètode retarda bàsicament el requisit de mantenir-se dins del mateix objecte assignat: [`sub`] és un comportament indefinit immediat quan es creuen els límits dels objectes;`wrapping_sub` produeix un punter però encara porta a Comportament indefinit si es desferencia un punter quan està fora dels límits de l'objecte al qual està unit.
    /// [`sub`] es pot optimitzar millor i, per tant, és preferible en el codi sensible al rendiment.
    ///
    /// La comprovació retardada només té en compte el valor del punter que es va referenciar, no els valors intermedis utilitzats durant el càlcul del resultat final.
    /// Per exemple, `x.wrapping_add(o).wrapping_sub(o)` sempre és el mateix que `x`.En altres paraules, es permet deixar l'objecte assignat i tornar-lo a introduir més tard.
    ///
    /// Si heu de creuar els límits de l`objecte, col・loqueu el punter a un enter i feu-hi l`aritmètica.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// // Iterar utilitzant un punter en brut en increments de dos elements (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Aquest bucle imprimeix "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Estableix el valor del punter a `ptr`.
    ///
    /// En cas que `self` sigui un punter (fat) a un tipus sense mida, aquesta operació només afectarà la part del punter, mentre que per als indicadors (thin) a tipus de mida, té el mateix efecte que una simple assignació.
    ///
    /// El punter resultant tindrà la procedència de `val`, és a dir, per a un punter greix, aquesta operació és semànticament la mateixa que crear un nou punter greix amb el valor del punter de dades de `val` però les metadades de `self`.
    ///
    ///
    /// # Examples
    ///
    /// Aquesta funció és útil principalment per permetre l'aritmètica dels indicadors de bytes en indicadors potencialment greixos:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // imprimirà "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // SEGURETAT: en cas d'un punter prim, aquestes operacions són idèntiques
        // a una tasca senzilla.
        // En cas d`un indicador de greix, amb la implementació actual del disseny del punter de greix, el primer camp d`aquest punter sempre és el punter de dades, que també s`assigna.
        //
        unsafe { *thin = val };
        self
    }

    /// Llegeix el valor de `self` sense moure'l.
    /// Això deixa la memòria del `self` sense canvis.
    ///
    /// Consulteu [`ptr::read`] per obtenir informació sobre seguretat i exemples.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a ``.
        unsafe { read(self) }
    }

    /// Realitza una lectura volàtil del valor de `self` sense moure'l.Això deixa la memòria a `self` sense canvis.
    ///
    /// Les operacions volàtils tenen la intenció d'actuar sobre la memòria I/O i el compilador garanteix que no les eliminarà ni les reordenarà en altres operacions volàtils.
    ///
    ///
    /// Consulteu [`ptr::read_volatile`] per obtenir informació sobre seguretat i exemples.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Llegeix el valor de `self` sense moure'l.
    /// Això deixa la memòria del `self` sense canvis.
    ///
    /// A diferència de `read`, el punter pot estar sense alinear.
    ///
    /// Consulteu [`ptr::read_unaligned`] per obtenir informació sobre seguretat i exemples.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Copia els bytes `count * size_of<T>` de `self` a `dest`.
    /// La font i la destinació es poden superposar.
    ///
    /// NOTE: això té l'ordre d'argument *mateix* que [`ptr::copy`].
    ///
    /// Consulteu [`ptr::copy`] per obtenir informació sobre seguretat i exemples.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Copia els bytes `count * size_of<T>` de `self` a `dest`.
    /// Pot ser que la font i la destinació no es superposin.
    ///
    /// NOTE: això té l'ordre d'argument *mateix* que [`ptr::copy_nonoverlapping`].
    ///
    /// Consulteu [`ptr::copy_nonoverlapping`] per obtenir informació sobre seguretat i exemples.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Copia els bytes `count * size_of<T>` de `src` a `self`.
    /// La font i la destinació es poden superposar.
    ///
    /// NOTE: això té l'ordre d'argument *oposat* de [`ptr::copy`].
    ///
    /// Consulteu [`ptr::copy`] per obtenir informació sobre seguretat i exemples.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Copia els bytes `count * size_of<T>` de `src` a `self`.
    /// Pot ser que la font i la destinació no es superposin.
    ///
    /// NOTE: això té l'ordre d'argument *oposat* de [`ptr::copy_nonoverlapping`].
    ///
    /// Consulteu [`ptr::copy_nonoverlapping`] per obtenir informació sobre seguretat i exemples.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Executa el destructor (si n'hi ha) del valor apuntat.
    ///
    /// Consulteu [`ptr::drop_in_place`] per obtenir informació sobre seguretat i exemples.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Sobreescriu una ubicació de memòria amb el valor donat sense llegir ni deixar caure el valor anterior.
    ///
    ///
    /// Consulteu [`ptr::write`] per obtenir informació sobre seguretat i exemples.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `write`.
        unsafe { write(self, val) }
    }

    /// Invoca memset al punter especificat, configurant `count * size_of::<T>()` bytes de memòria a partir de `self` a `val`.
    ///
    ///
    /// Consulteu [`ptr::write_bytes`] per obtenir informació sobre seguretat i exemples.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Realitza una escriptura volàtil d'una ubicació de memòria amb el valor donat sense llegir ni deixar caure el valor anterior.
    ///
    /// Les operacions volàtils tenen la intenció d'actuar sobre la memòria I/O i el compilador garanteix que no les eliminarà ni les reordenarà en altres operacions volàtils.
    ///
    ///
    /// Consulteu [`ptr::write_volatile`] per obtenir informació sobre seguretat i exemples.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Sobreescriu una ubicació de memòria amb el valor donat sense llegir ni deixar caure el valor anterior.
    ///
    ///
    /// A diferència de `write`, el punter pot estar sense alinear.
    ///
    /// Consulteu [`ptr::write_unaligned`] per obtenir informació sobre seguretat i exemples.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Substitueix el valor a `self` per `src`, retornant el valor anterior, sense deixar caure cap dels dos.
    ///
    ///
    /// Consulteu [`ptr::replace`] per obtenir informació sobre seguretat i exemples.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `replace`.
        unsafe { replace(self, src) }
    }

    /// Intercanvia els valors en dues ubicacions mutables del mateix tipus, sense desinicialitzar cap.
    /// Es poden superposar, a diferència de `mem::swap`, que equival a una altra cosa.
    ///
    /// Consulteu [`ptr::swap`] per obtenir informació sobre seguretat i exemples.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `swap`.
        unsafe { swap(self, with) }
    }

    /// Calcula el desplaçament que cal aplicar al punter per alinear-lo a `align`.
    ///
    /// Si no és possible alinear el punter, la implementació retorna `usize::MAX`.
    /// És permès que la implementació torni *sempre*`usize::MAX`.
    /// Només el rendiment del vostre algorisme pot dependre d`aconseguir un desplaçament útil aquí, no de la seva exactitud.
    ///
    /// El desplaçament s'expressa en nombre d'elements `T` i no en bytes.El valor retornat es pot utilitzar amb el mètode `wrapping_add`.
    ///
    /// No hi ha cap mena de garantia que la compensació del punter no es desbordi ni vagi més enllà de l'assignació que apunta el punter.
    ///
    /// Correspon a la persona que truca assegurar-se que el desplaçament retornat és correcte en tots els termes diferents de l`alineació.
    ///
    /// # Panics
    ///
    /// La funció panics si `align` no és una potència de dos.
    ///
    /// # Examples
    ///
    /// Accedint a `u8` adjacent com a `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // mentre el punter es pot alinear mitjançant `offset`, apuntaria fora de l'assignació
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SEGURETAT: s'ha comprovat que `align` té una potència de 2 anterior
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Retorna la longitud d'una llesca en brut.
    ///
    /// El valor retornat és el nombre de **elements**, no el nombre de bytes.
    ///
    /// Aquesta funció és segura, fins i tot quan el segment en brut no es pot emetre a una referència de segment perquè el punter és nul o no alineat.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SEGURETAT: és segur perquè `*const [T]` i `FatPtr<T>` tenen el mateix disseny.
            // Només `std` pot fer aquesta garantia.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Retorna un punter en brut al buffer del segment.
    ///
    /// Això equival a emetre `self` a `*mut T`, però és més segur per al tipus.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Retorna un punter en brut a un element o subslice, sense fer la comprovació de límits.
    ///
    /// Cridar aquest mètode amb un índex fora de límits o quan `self` no es pot referenciar és *[comportament indefinit]* fins i tot si no es fa servir el punter resultant.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SEGURETAT: la persona que truca s'assegura que `self` no es pot referenciar i que `index` es troba dins dels límits.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Retorna `None` si el punter és nul, o bé retorna un segment compartit al valor embolicat a `Some`.
    /// A diferència de [`as_ref`], això no requereix que s'hagi d'inicialitzar el valor.
    ///
    /// Per a la contrapart mutable, vegeu [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Quan truqueu a aquest mètode, heu d'assegurar-vos que *el punter sigui NUL* o que sigui cert tot el següent:
    ///
    /// * El punter ha de ser [valid] per a lectures de `ptr.len() * mem::size_of::<T>()` de molts bytes i ha d`estar correctament alineat.Això significa en particular:
    ///
    ///     * L'interval de memòria d'aquesta part ha d'estar inclòs dins d'un sol objecte assignat.
    ///       Les llesques mai no poden abastar diversos objectes assignats.
    ///
    ///     * El punter ha d`estar alineat fins i tot per a rodanxes de longitud zero.
    ///     Una de les raons per això és que les optimitzacions de disseny d'enum poden dependre de que les referències (incloses les llesques de qualsevol longitud) estiguin alineades i no nul・les per distingir-les d'altres dades.
    ///
    ///     Podeu obtenir un punter que es pugui utilitzar com a `data` per a talls de longitud zero amb [`NonNull::dangling()`].
    ///
    /// * La mida total `ptr.len() * mem::size_of::<T>()` de la part no pot ser superior a `isize::MAX`.
    ///   Consulteu la documentació de seguretat de [`pointer::offset`].
    ///
    /// * Heu de fer complir les regles d`aliasing de Rust, ja que la vida útil retornada `'a` és elegida arbitràriament i no reflecteix necessàriament la vida real real de les dades.
    ///   En particular, durant tota aquesta vida, la memòria a què apunta el punter no s'ha de mutar (excepte dins de `UnsafeCell`).
    ///
    /// Això s'aplica fins i tot si el resultat d'aquest mètode no s'utilitza.
    ///
    /// Vegeu també [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Retorna `None` si el punter és nul, o bé retorna un segment únic al valor embolicat a `Some`.
    /// A diferència de [`as_mut`], això no requereix que s'hagi d'inicialitzar el valor.
    ///
    /// Per a la contrapartida compartida, consulteu [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Quan truqueu a aquest mètode, heu d'assegurar-vos que *el punter sigui NUL* o que sigui cert tot el següent:
    ///
    /// * El punter ha de ser [valid] per a les lectures i escriptures per a molts bytes `ptr.len() * mem::size_of::<T>()`, i ha d`estar correctament alineat.Això significa en particular:
    ///
    ///     * L'interval de memòria d'aquesta part ha d'estar inclòs dins d'un sol objecte assignat.
    ///       Les llesques mai no poden abastar diversos objectes assignats.
    ///
    ///     * El punter ha d`estar alineat fins i tot per a rodanxes de longitud zero.
    ///     Una de les raons per això és que les optimitzacions de disseny d'enum poden dependre de que les referències (incloses les llesques de qualsevol longitud) estiguin alineades i no nul・les per distingir-les d'altres dades.
    ///
    ///     Podeu obtenir un punter que es pugui utilitzar com a `data` per a talls de longitud zero amb [`NonNull::dangling()`].
    ///
    /// * La mida total `ptr.len() * mem::size_of::<T>()` de la part no pot ser superior a `isize::MAX`.
    ///   Consulteu la documentació de seguretat de [`pointer::offset`].
    ///
    /// * Heu de fer complir les regles d`aliasing de Rust, ja que la vida útil retornada `'a` és elegida arbitràriament i no reflecteix necessàriament la vida real real de les dades.
    ///   En particular, durant tota aquesta vida, la memòria a la qual apunta el punter no ha de tenir accés (llegida o escrita) a través de cap altre punter.
    ///
    /// Això s'aplica fins i tot si el resultat d'aquest mètode no s'utilitza.
    ///
    /// Vegeu també [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Igualtat per als indicadors
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}