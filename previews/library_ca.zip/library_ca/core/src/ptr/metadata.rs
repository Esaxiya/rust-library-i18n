#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Proporciona el tipus de metadades del punter de qualsevol tipus apuntat.
///
/// # Metadades del punter
///
/// Es pot considerar que els tipus de punter sense processar i els tipus de referència a Rust estan formats per dues parts:
/// un punter de dades que conté l'adreça de memòria del valor i algunes metadades.
///
/// Per als tipus de mida estàtica (que implementen el `Sized` traits), així com per als tipus `extern`, es diu que els punteres són "prims": les metadades són de mida zero i el seu tipus és `()`.
///
///
/// Es diu que els indicadors de [dynamically-sized types][dst] són "amples" o "greixos", ja que tenen metadades de mida diferent de zero:
///
/// * Per a les estructures l'últim camp de les quals és un DST, les metadades són les metadades de l'últim camp
/// * Per al tipus `str`, les metadades són la longitud en bytes que `usize`
/// * Per als tipus de segment com `[T]`, les metadades són la longitud dels elements com `usize`
/// * Per a objectes trait com `dyn SomeTrait`, les metadades són [`DynMetadata<Self>`][DynMetadata] (per exemple, `DynMetadata<dyn SomeTrait>`)
///
/// A future, el llenguatge Rust pot obtenir nous tipus de tipus que tenen metadades de punter diferents.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # El `Pointee` trait
///
/// El punt d`aquest trait és el seu tipus associat a `Metadata`, que és `()` o `usize` o `DynMetadata<_>` tal com s`ha descrit anteriorment.
/// S`implementa automàticament per a tots els tipus.
/// Es pot suposar que s`implementa en un context genèric, fins i tot sense un límit corresponent.
///
/// # Usage
///
/// Els indicadors sense format es poden descompondre en l'adreça de dades i els components de metadades amb el seu mètode [`to_raw_parts`].
///
/// Com a alternativa, només es poden extreure metadades amb la funció [`metadata`].
/// Es pot passar una referència a [`metadata`] i coaccionar-la implícitament.
///
/// Es pot tornar a posar un punter (possibly-wide) des de la seva adreça i metadades amb [`from_raw_parts`] o [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// El tipus de metadades en punteres i referències a `Self`.
    #[lang = "metadata_type"]
    // NOTE: Mantingueu trait bounds a `static_assert_expected_bounds_for_metadata`
    //
    // en `library/core/src/ptr/metadata.rs` sincronitzat amb els d`aquí:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Els indicadors de tipus que implementen aquest àlies trait són "prims".
///
/// Això inclou els tipus de mida estàtica i els tipus `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: no l'estabilitzeu abans que els àlies trait siguin estables en la llengua?
pub trait Thin = Pointee<Metadata = ()>;

/// Extreu el component de metadades d'un punter.
///
/// Els valors del tipus `*mut T`, `&T` o `&mut T` es poden passar directament a aquesta funció ja que impliquen implícitament a `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SEGURETAT: Accedir al valor des de la unió `PtrRepr` és segur ja que * const T
    // i PtrComponents<T>tenen els mateixos dissenys de memòria.
    // Només std pot fer aquesta garantia.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Forma un punter en brut (possibly-wide) a partir d'una adreça de dades i metadades.
///
/// Aquesta funció és segura, però el punter retornat no és necessàriament segur per a la desferència.
/// Per obtenir segments, consulteu la documentació de [`slice::from_raw_parts`] per obtenir requisits de seguretat.
/// Per als objectes trait, les metadades han de provenir d'un punter cap al mateix tipus suprimit subjacent.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SEGURETAT: Accedir al valor des de la unió `PtrRepr` és segur ja que * const T
    // i PtrComponents<T>tenen els mateixos dissenys de memòria.
    // Només std pot fer aquesta garantia.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Realitza la mateixa funcionalitat que [`from_raw_parts`], excepte que es retorna un punter `*mut` en brut, a diferència d`un punter `* const` en brut.
///
///
/// Consulteu la documentació de [`from_raw_parts`] per obtenir més informació.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SEGURETAT: Accedir al valor des de la unió `PtrRepr` és segur ja que * const T
    // i PtrComponents<T>tenen els mateixos dissenys de memòria.
    // Només std pot fer aquesta garantia.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Es necessita una implementació manual per evitar el límit `T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Es necessita una implementació manual per evitar el límit `T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Les metadades d`un tipus d`objecte `Dyn = dyn SomeTrait` trait.
///
/// És un punter cap a una taula vtable (taula de trucades virtuals) que representa tota la informació necessària per manipular el tipus de formigó emmagatzemat dins d`un objecte trait.
/// La taula vtable, que inclou especialment:
///
/// * mida del tipus
/// * alineació de tipus
/// * un punter a la impl. `drop_in_place` del tipus (pot ser un no-op per a dades antigues)
/// * apunta a tots els mètodes per a la implementació del tipus de trait
///
/// Tingueu en compte que els tres primers són especials perquè són necessaris per assignar, deixar anar i repartir qualsevol objecte trait.
///
/// És possible anomenar aquesta estructura amb un paràmetre de tipus que no sigui un objecte `dyn` trait (per exemple `DynMetadata<u64>`) però no obtenir un valor significatiu d'aquesta estructura.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// El prefix comú de totes les vtables.El segueixen els indicadors de funció per als mètodes trait.
///
/// Detall d`implementació privada de `DynMetadata::size_of`, etc.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Retorna la mida del tipus associat a aquesta taula vtable.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Retorna l'alineació del tipus associat a aquesta taula vtable.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Retorna la mida i l'alineació junts com un `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SEGURETAT: el compilador va emetre aquesta taula vtable per a un tipus concret Rust que
        // se sap que té un disseny vàlid.El mateix fonament que a `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Es necessiten implements manuals per evitar límits `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}