//! Gestioneu manualment la memòria mitjançant punteres sense processar.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Moltes funcions d`aquest mòdul prenen com a arguments els indicadors en brut i els llegeixen o els escriuen.Perquè això sigui segur, aquests indicadors han de ser *vàlids*.
//! El fet que un punter sigui vàlid depèn de l'operació per a la qual s'utilitza (llegir o escriure) i de l'extensió de la memòria a la qual s'accedeix (és a dir, quants bytes són read/written).
//! La majoria de les funcions utilitzen `*mut T` i `* const T` per accedir només a un valor únic, en aquest cas la documentació omet la mida i suposa implícitament que són bytes `size_of::<T>()`.
//!
//! Les regles precises de validesa encara no estan determinades.Les garanties que s`ofereixen en aquest moment són molt mínimes:
//!
//! * Un punter [null]*mai* és vàlid, ni tan sols per als accessos de [size zero][zst].
//! * Perquè un punter sigui vàlid, és necessari, però no sempre, que el punter sigui *desferenciable*: l'interval de memòria de la mida donada començant pel punter ha d'estar dins dels límits d'un sol objecte assignat.
//!
//! Tingueu en compte que a Rust, cada variable (stack-allocated) es considera un objecte assignat independent.
//! * Fins i tot per a operacions de [size zero][zst], el punter no ha d`estar apuntant cap a la memòria desassignada, és a dir, la desassignació fa que els indicadors no siguin vàlids fins i tot per a operacions de mida zero.
//! Tanmateix, emetre qualsevol enter *literal* que no sigui zero a un punter és vàlid per a accessos de mida zero, fins i tot si hi ha memòria en aquesta adreça i es reparteix.
//! Això correspon a escriure el vostre propi assignador: assignar objectes de mida zero no és molt difícil.
//! La forma canònica d'obtenir un punter vàlid per a accessos de mida zero és [`NonNull::dangling`].
//! * Tots els accessos realitzats per les funcions d`aquest mòdul són *no atòmics* en el sentit de [atomic operations] que s`utilitza per sincronitzar entre fils.
//! Això significa que és un comportament indefinit realitzar dos accessos simultanis a la mateixa ubicació des de fils diferents tret que tots dos accessos només es llegeixin des de la memòria.
//! Tingueu en compte que això inclou explícitament [`read_volatile`] i [`write_volatile`]: els accessos volàtils no es poden utilitzar per a la sincronització entre fils.
//! * El resultat d`emetre una referència a un punter és vàlid mentre l`objecte subjacent estigui actiu i no s`utilitzi cap referència (només punteres en brut) per accedir a la mateixa memòria.
//!
//! Aquests axiomes, juntament amb un ús acurat de [`offset`] per a l'aritmètica del punter, són suficients per implementar correctament moltes coses útils en codi no segur.
//! Finalment, es proporcionaran garanties més fortes, ja que s'estan determinant les regles [aliasing].
//! Per obtenir més informació, consulteu el [book] i la secció de la referència dedicada al [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Els punters en brut vàlids definits anteriorment no necessàriament estan alineats correctament (on l'alineació "proper" està definida pel tipus de punt, és a dir, `*const T` ha d'estar alineat a `mem::align_of::<T>()`).
//! Tanmateix, la majoria de funcions requereixen que els seus arguments estiguin correctament alineats i faran constar explícitament aquest requisit a la seva documentació.
//! Les excepcions notables a això són [`read_unaligned`] i [`write_unaligned`].
//!
//! Quan una funció requereix un alineament adequat, ho fa fins i tot si l'accés té la mida 0, és a dir, fins i tot si no es toca la memòria.Penseu en utilitzar [`NonNull::dangling`] en aquests casos.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Executa el destructor (si n'hi ha) del valor apuntat.
///
/// Això equival semànticament a trucar a [`ptr::read`] i descartar el resultat, però té els següents avantatges:
///
/// * *Es requereix* utilitzar `drop_in_place` per deixar caure tipus sense mida com objectes trait, perquè no es poden llegir a la pila i deixar-los caure normalment.
///
/// * És més amable per a l`optimitzador fer-ho amb [`ptr::read`] quan es deixa caure la memòria assignada manualment (per exemple, en les implementacions de `Box`/`Rc`/`Vec`), ja que el compilador no necessita demostrar que és correcte eliminar la còpia.
///
///
/// * Es pot utilitzar per deixar caure dades [pinned] quan `T` no és `repr(packed)` (les dades fixades no s'han de moure abans de deixar-les caure).
///
/// Els valors no alineats no es poden deixar col・locats al lloc, primer s'han de copiar a una ubicació alineada amb [`ptr::read_unaligned`].Per a les estructures empaquetades, aquest moviment es realitza automàticament pel compilador.
/// Això significa que els camps de les estructures empaquetades no es deixen caure al seu lloc.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// El comportament no està definit si es infringeix alguna de les condicions següents:
///
/// * `to_drop` ha de ser [valid] tant per a les lectures com per a les escriptures.
///
/// * `to_drop` han d`estar correctament alineats.
///
/// * El valor que apunta `to_drop` ha de ser vàlid per deixar-lo caure, cosa que pot significar que ha de mantenir invariants addicionals, depèn del tipus.
///
/// A més, si `T` no és [`Copy`], l'ús del valor apuntat després de trucar a `drop_in_place` pot provocar un comportament indefinit.Tingueu en compte que `*to_drop = foo` compta com un ús, ja que farà que el valor es tiri de nou.
/// [`write()`] es pot utilitzar per sobreescriure dades sense que es deixin de banda.
///
/// Tingueu en compte que, fins i tot si `T` té la mida `0`, el punter no ha de ser NULL i està alineat correctament.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Traieu manualment l`últim element d`un vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Obteniu un punter en brut fins a l'últim element de `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Escurceu `v` per evitar que es caigui l`últim element.
///     // Primer ho fem, per evitar problemes si el `drop_in_place` està per sota de panics.
///     v.set_len(1);
///     // Sense una trucada `drop_in_place`, l`últim element no es deixaria caure mai i la memòria que gestiona es filtraria.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Assegureu-vos que s'hagi retirat l'últim element.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Tingueu en compte que el compilador realitza aquesta còpia automàticament quan deixa caure les estructures empaquetades, és a dir, normalment no us heu de preocupar d`aquests problemes tret que truqueu manualment a `drop_in_place`.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // El codi aquí no té importància, és substituït per la cola de gota real del compilador.
    //

    // SEGURETAT: vegeu el comentari anterior
    unsafe { drop_in_place(to_drop) }
}

/// Crea un punter sense processar nul.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Crea un punter en brut mutable nul.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Es necessita una implementació manual per evitar el límit `T: Clone`.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Es necessita una implementació manual per evitar el límit `T: Copy`.
impl<T> Copy for FatPtr<T> {}

/// Forma una llesca en brut a partir d`un punter i d`una longitud.
///
/// L'argument `len` és el nombre de **elements**, no el nombre de bytes.
///
/// Aquesta funció és segura, però l'ús del valor de retorn no és segur.
/// Consulteu la documentació de [`slice::from_raw_parts`] per obtenir els requisits de seguretat de les llesques.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // creeu un punter de llesca quan comenceu amb un punter al primer element
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SEGURETAT: l'accés al valor des de la unió `Repr` és segur des de * const [T]
        //
        // i FatPtr tenen els mateixos dissenys de memòria.Només std pot fer aquesta garantia.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Realitza la mateixa funcionalitat que [`slice_from_raw_parts`], excepte que es retorna un segment mutable en brut, a diferència d`un segment immutable en brut.
///
///
/// Consulteu la documentació de [`slice_from_raw_parts`] per obtenir més informació.
///
/// Aquesta funció és segura, però l'ús del valor de retorn no és segur.
/// Consulteu la documentació de [`slice::from_raw_parts_mut`] per obtenir els requisits de seguretat de les llesques.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // assigneu un valor a un índex de la part
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SEGURETAT: Accedir al valor des de la unió `Repr` és segur ja que * mut [T]
        // i FatPtr tenen els mateixos dissenys de memòria
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Intercanvia els valors en dues ubicacions mutables del mateix tipus, sense desinicialitzar cap.
///
/// Però, per a les dues excepcions següents, aquesta funció és semànticament equivalent a [`mem::swap`]:
///
///
/// * Opera en punteres en brut en lloc de referències.
/// Quan hi hagi referències disponibles, caldria preferir [`mem::swap`].
///
/// * Els dos valors assenyalats poden superposar-se.
/// Si els valors es superposen, s'utilitzarà la regió de memòria superposada de `x`.
/// Això es demostra en el segon exemple següent.
///
/// # Safety
///
/// El comportament no està definit si es infringeix alguna de les condicions següents:
///
/// * Tant `x` com `y` han de ser [valid] tant per a les lectures com per a les escriptures.
///
/// * Tant `x` com `y` han d'estar correctament alineats.
///
/// Tingueu en compte que, fins i tot si `T` té la mida `0`, els punteres no han de ser NULS i estan alineats correctament.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Intercanvi de dues regions que no se superposen:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // això és `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // això és `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Intercanvi de dues regions superposades:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // això és `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // això és `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Els índexs `1..3` del segment es superposen entre `x` i `y`.
///     // Els resultats raonables serien per a ells `[2, 3]`, de manera que els índexs `0..3` són `[1, 2, 3]` (coincideixen amb `y` abans que `swap`);o perquè siguin `[0, 1]` de manera que els índexs `1..4` siguin `[0, 1, 2]` (coincideixin amb `x` abans que `swap`).
/////
///     // Aquesta implementació es defineix per fer aquesta última elecció.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Doneu-nos una mica d`espai lliure per treballar.
    // No ens hem de preocupar de les gotes: `MaybeUninit` no fa res quan es deixa caure.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Realitzeu l'intercanvi de SEGURETAT: la persona que truca ha de garantir que `x` i `y` són vàlids per escriure i estan alineats correctament.
    // `tmp` no es pot superposar ni `x` ni `y` perquè `tmp` s'acaba d'assignar a la pila com a objecte assignat independent.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` i `y` es poden superposar
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Canvia els bytes `count * size_of::<T>()` entre les dues regions de memòria que comencen per `x` i `y`.
/// Les dues regions *no* s'han * de superposar.
///
/// # Safety
///
/// El comportament no està definit si es infringeix alguna de les condicions següents:
///
/// * Tant `x` com `y` han de ser [valid] tant per a les lectures com per a les escriptures del compte *
///   mida_de: :<T>() `bytes.
///
/// * Tant `x` com `y` han d'estar correctament alineats.
///
/// * La regió de la memòria que comença a `x` amb una mida de `count *
///   mida_de: :<T>() Els bytes *no* poden * superposar-se a la regió de memòria que comença a `y` amb la mateixa mida.
///
/// Tingueu en compte que, fins i tot si la mida efectivament copiada (`count * size_of: :<T>()`) és `0`, els punteres no han de ser NULS i estan correctament alineats.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SEGURETAT: la persona que truca ha de garantir que `x` i `y` ho són
    // vàlid per a escriptures i adequadament alineat.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Per als tipus menors que l'optimització de blocs que es mostren a continuació, només cal canviar directament per evitar pessimitzar el codegen.
    //
    if mem::size_of::<T>() < 32 {
        // SEGURETAT: la persona que truca ha de garantir que `x` i `y` són vàlids
        // per a escriptures, adequadament alineades i sense superposició.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // L'enfocament aquí és utilitzar simd per canviar de manera eficient x.
    // Les proves revelen que intercanviar 32 bytes o 64 bytes alhora és el més eficient per als processadors Intel Haswell E.
    // LLVM és més capaç d`optimitzar si donem a una estructura un #[repr(simd)], encara que en realitat no utilitzem aquesta estructura directament.
    //
    //
    // FIXME repr(simd) trencat a emscripten i redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Feu un bucle per xyy, copiant-los `Block` a la vegada. L'optimitzador hauria de desenrotllar completament el bucle per a la majoria de tipus NB
    // No podem utilitzar un bucle for, ja que l`implicador `range` crida a `mem::swap` recursivament
    //
    let mut i = 0;
    while i + block_size <= len {
        // Creeu una mica de memòria no inicialitzada com a espai de zero. La declaració de `t` aquí evita l'alineació de la pila quan aquest bucle no s'utilitza
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SEGURETAT: com a `i < len` i com a persona que truca ha de garantir que `x` i `y` són vàlids
        // per a bytes `len`, `x + i` i `y + i` han de ser adreces vàlides, que compleixin el contracte de seguretat per a `add`.
        //
        // A més, la persona que truca ha de garantir que `x` i `y` són vàlids per a escriptures, adequadament alineats i no superposats, cosa que compleix el contracte de seguretat per a `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Canvieu un bloc de bytes de xy, utilitzant t com a memòria intermèdia temporal. Això s'hauria d'optimitzar en operacions SIMD eficients quan estiguessin disponibles
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Intercanvieu els bytes restants
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SEGURETAT: vegeu el comentari de seguretat anterior.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Mou `src` al `dst` apuntat, retornant el valor anterior de `dst`.
///
/// Cap valor es deixa caure.
///
/// Aquesta funció és semànticament equivalent a [`mem::replace`], tret que opera en punteres en brut en lloc de referències.
/// Quan hi hagi referències disponibles, caldria preferir [`mem::replace`].
///
/// # Safety
///
/// El comportament no està definit si es infringeix alguna de les condicions següents:
///
/// * `dst` ha de ser [valid] tant per a les lectures com per a les escriptures.
///
/// * `dst` han d`estar correctament alineats.
///
/// * `dst` ha d'assenyalar un valor inicialitzat correctament del tipus `T`.
///
/// Tingueu en compte que, fins i tot si `T` té la mida `0`, el punter no ha de ser NULL i està alineat correctament.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` tindria el mateix efecte sense requerir el bloc no segur.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SEGURETAT: la persona que truca ha de garantir que `dst` és vàlid
    // emès a una referència mutable (vàlida per a escriptures, alineada, inicialitzada) i no pot superposar-se a `src`, ja que `dst` ha d'assenyalar un objecte assignat diferent.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // no es pot superposar
    }
    src
}

/// Llegeix el valor de `src` sense moure'l.Això deixa la memòria a `src` sense canvis.
///
/// # Safety
///
/// El comportament no està definit si es infringeix alguna de les condicions següents:
///
/// * `src` ha de ser [valid] per a les lectures.
///
/// * `src` han d`estar correctament alineats.Utilitzeu [`read_unaligned`] si no és així.
///
/// * `src` ha d'assenyalar un valor inicialitzat correctament del tipus `T`.
///
/// Tingueu en compte que, fins i tot si `T` té la mida `0`, el punter no ha de ser NULL i està alineat correctament.
///
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Implementeu manualment [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Creeu una còpia a bits del valor a `a` a `tmp`.
///         let tmp = ptr::read(a);
///
///         // Sortir en aquest punt (ja sigui retornant explícitament o trucant a una funció a la qual panics) provocaria la caiguda del valor a `tmp` mentre `a` encara fa referència al mateix valor.
///         // Això podria provocar un comportament indefinit si `T` no és `Copy`.
/////
/////
///
///         // Creeu una còpia a bits del valor a `b` a `a`.
///         // Això és segur perquè les referències mutables no poden àlies.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Com es va esmentar anteriorment, sortir d`aquí podria provocar un comportament indefinit perquè `a` i `b` fan referència al mateix valor.
/////
///
///         // Mou `tmp` a `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` s'ha mogut (`write` s'apropia del seu segon argument), de manera que aquí no es deixa res implícit.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Propietat del valor retornat
///
/// `read` crea una còpia a bits de `T`, independentment de si `T` és [`Copy`].
/// Si `T` no és [`Copy`], utilitzar tant el valor retornat com el valor de `*src` pot infringir la seguretat de la memòria.
/// Tingueu en compte que l'assignació a `*src` compta com a ús perquè intentarà baixar el valor a `* src`.
///
/// [`write()`] es pot utilitzar per sobreescriure dades sense que es deixin de banda.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` ara apunta a la mateixa memòria subjacent que `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // L'assignació a `s2` fa que es baixi el seu valor original.
///     // Més enllà d`aquest punt, ja no s`ha d`utilitzar `s`, ja que s`ha alliberat la memòria subjacent.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Si s`assigna a `s`, es tornaria a deixar caure el valor anterior, cosa que provocaria un comportament indefinit.
/////
///     // s= String::from("bar");//ERROR
///
///     // `ptr::write` es pot utilitzar per sobreescriure un valor sense deixar-lo caure.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SEGURETAT: la persona que truca ha de garantir que l `src` és vàlid per a lectures.
    // `src` no es pot superposar a `tmp` perquè `tmp` s'acaba d'assignar a la pila com a objecte assignat independent.
    //
    //
    // A més, com que acabem d`escriure un valor vàlid a `tmp`, està garantit que s`inicialitzarà correctament.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Llegeix el valor de `src` sense moure'l.Això deixa la memòria a `src` sense canvis.
///
/// A diferència de [`read`], `read_unaligned` funciona amb punteres no alineats.
///
/// # Safety
///
/// El comportament no està definit si es infringeix alguna de les condicions següents:
///
/// * `src` ha de ser [valid] per a les lectures.
///
/// * `src` ha d'assenyalar un valor inicialitzat correctament del tipus `T`.
///
/// Igual que [`read`], `read_unaligned` crea una còpia a bit de `T`, independentment de si `T` és [`Copy`].
/// Si `T` no és [`Copy`], podeu utilitzar [violate memory safety][read-ownership] tant amb el valor retornat com amb el valor de `*src`.
///
/// Tingueu en compte que, fins i tot si `T` té la mida `0`, el punter no ha de ser NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## En estructures `packed`
///
/// Actualment és impossible crear punteres sense processar a camps no alineats d`una estructura empaquetada.
///
/// Si intenteu crear un punter en brut a un camp struct `unaligned` amb una expressió com ara `&packed.unaligned as *const FieldType`, es crea una referència intermedia sense alinear abans de convertir-la en un punter en brut.
///
/// Que aquesta referència sigui temporal i es faci immediatament no té conseqüència, ja que el compilador sempre espera que les referències estiguin correctament alineades.
/// Com a resultat, fer servir `&packed.unaligned as *const FieldType` provoca un comportament immediat* no definit * al vostre programa.
///
/// Un exemple del que no s`ha de fer i de com es relaciona això amb `read_unaligned` és:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Aquí intentem agafar l'adreça d'un enter de 32 bits que no està alineat.
///     let unaligned =
///         // Aquí es crea una referència temporal no alineada que resulta en un comportament indefinit independentment de si s`utilitza o no la referència.
/////
///         &packed.unaligned
///         // Emetre a un punter en brut no ajuda;l'error ja va passar.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Tanmateix, és segur accedir a camps no alineats directament amb, per exemple, `packed.unaligned`.
///
///
///
///
///
///
// FIXME: Actualitzeu documents basats en el resultat de RFC #2582 i els amics.
/// # Examples
///
/// Llegiu un valor d'ús d'un buffer de bytes:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SEGURETAT: la persona que truca ha de garantir que l `src` és vàlid per a lectures.
    // `src` no es pot superposar a `tmp` perquè `tmp` s'acaba d'assignar a la pila com a objecte assignat independent.
    //
    //
    // A més, com que acabem d`escriure un valor vàlid a `tmp`, està garantit que s`inicialitzarà correctament.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Sobreescriu una ubicació de memòria amb el valor donat sense llegir ni deixar caure el valor anterior.
///
/// `write` no deixa caure el contingut de `dst`.
/// Això és segur, però pot filtrar assignacions o recursos, per la qual cosa s`ha de procurar no sobreescriure un objecte que s`hauria de deixar caure.
///
///
/// A més, no deixa caure `src`.Semànticament, `src` es mou a la ubicació assenyalada per `dst`.
///
/// Això és adequat per inicialitzar memòria no inicialitzada o sobreescriure la memòria que ha estat prèviament [`read`].
///
/// # Safety
///
/// El comportament no està definit si es infringeix alguna de les condicions següents:
///
/// * `dst` ha de ser [valid] per a les escriptures.
///
/// * `dst` han d`estar correctament alineats.Utilitzeu [`write_unaligned`] si no és així.
///
/// Tingueu en compte que, fins i tot si `T` té la mida `0`, el punter no ha de ser NULL i està alineat correctament.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Implementeu manualment [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Creeu una còpia a bits del valor a `a` a `tmp`.
///         let tmp = ptr::read(a);
///
///         // Sortir en aquest punt (ja sigui retornant explícitament o trucant a una funció a la qual panics) provocaria la caiguda del valor a `tmp` mentre `a` encara fa referència al mateix valor.
///         // Això podria provocar un comportament indefinit si `T` no és `Copy`.
/////
/////
///
///         // Creeu una còpia a bits del valor a `b` a `a`.
///         // Això és segur perquè les referències mutables no poden àlies.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Com es va esmentar anteriorment, sortir d`aquí podria provocar un comportament indefinit perquè `a` i `b` fan referència al mateix valor.
/////
///
///         // Mou `tmp` a `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` s'ha mogut (`write` s'apropia del seu segon argument), de manera que aquí no es deixa res implícit.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Estem trucant directament als agents intrínsecs per evitar les trucades de funcions al codi generat, ja que `intrinsics::copy_nonoverlapping` és una funció d`embolcall.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SEGURETAT: la persona que truca ha de garantir que `dst` és vàlid per a escriptures.
    // `dst` no es pot superposar a `src` perquè la persona que truca té accés mutable a `dst` mentre `src` és propietat d'aquesta funció.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Sobreescriu una ubicació de memòria amb el valor donat sense llegir ni deixar caure el valor anterior.
///
/// A diferència de [`write()`], el punter pot estar sense alinear.
///
/// `write_unaligned` no deixa caure el contingut de `dst`.Això és segur, però pot filtrar assignacions o recursos, per la qual cosa s`ha de procurar no sobreescriure un objecte que s`hauria de deixar caure.
///
/// A més, no deixa caure `src`.Semànticament, `src` es mou a la ubicació assenyalada per `dst`.
///
/// Això és adequat per inicialitzar memòria no inicialitzada o sobreescriure memòria que s'hagi llegit prèviament amb [`read_unaligned`].
///
/// # Safety
///
/// El comportament no està definit si es infringeix alguna de les condicions següents:
///
/// * `dst` ha de ser [valid] per a les escriptures.
///
/// Tingueu en compte que, fins i tot si `T` té la mida `0`, el punter no ha de ser NULL.
///
/// [valid]: self#safety
///
/// ## En estructures `packed`
///
/// Actualment és impossible crear punteres sense processar a camps no alineats d`una estructura empaquetada.
///
/// Si intenteu crear un punter en brut a un camp struct `unaligned` amb una expressió com ara `&packed.unaligned as *const FieldType`, es crea una referència intermedia sense alinear abans de convertir-la en un punter en brut.
///
/// Que aquesta referència sigui temporal i es faci immediatament no té conseqüència, ja que el compilador sempre espera que les referències estiguin correctament alineades.
/// Com a resultat, fer servir `&packed.unaligned as *const FieldType` provoca un comportament immediat* no definit * al vostre programa.
///
/// Un exemple del que no s`ha de fer i de com es relaciona això amb `write_unaligned` és:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Aquí intentem agafar l'adreça d'un enter de 32 bits que no està alineat.
///     let unaligned =
///         // Aquí es crea una referència temporal no alineada que resulta en un comportament indefinit independentment de si s`utilitza o no la referència.
/////
///         &mut packed.unaligned
///         // Emetre a un punter en brut no ajuda;l'error ja va passar.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Tanmateix, és segur accedir a camps no alineats directament amb, per exemple, `packed.unaligned`.
///
///
///
///
///
///
///
///
///
// FIXME: Actualitzeu documents basats en el resultat de RFC #2582 i els amics.
/// # Examples
///
/// Escriviu un valor d`utilització a un buffer de bytes:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SEGURETAT: la persona que truca ha de garantir que `dst` és vàlid per a escriptures.
    // `dst` no es pot superposar a `src` perquè la persona que truca té accés mutable a `dst` mentre `src` és propietat d'aquesta funció.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Estem trucant directament a l`intrínsec per evitar trucades de funció al codi generat.
        intrinsics::forget(src);
    }
}

/// Realitza una lectura volàtil del valor de `src` sense moure'l.Això deixa la memòria a `src` sense canvis.
///
/// Les operacions volàtils tenen la intenció d'actuar sobre la memòria I/O i el compilador garanteix que no les eliminarà ni les reordenarà en altres operacions volàtils.
///
/// # Notes
///
/// Rust no té actualment un model de memòria rigorosament definit formalment, de manera que la semàntica precisa del que significa "volatile" aquí està subjecta a canvis al llarg del temps.
/// Dit això, la semàntica gairebé sempre acabarà sent bastant similar a [C11's definition of volatile][c11].
///
/// El compilador no hauria de canviar l'ordre relatiu o el nombre d'operacions de memòria volàtils.
/// Tanmateix, les operacions de memòria volàtils en tipus de mida zero (per exemple, si es passa un tipus de mida zero a `read_volatile`) són noops i es poden ignorar.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// El comportament no està definit si es infringeix alguna de les condicions següents:
///
/// * `src` ha de ser [valid] per a les lectures.
///
/// * `src` han d`estar correctament alineats.
///
/// * `src` ha d'assenyalar un valor inicialitzat correctament del tipus `T`.
///
/// Igual que [`read`], `read_volatile` crea una còpia a bit de `T`, independentment de si `T` és [`Copy`].
/// Si `T` no és [`Copy`], podeu utilitzar [violate memory safety][read-ownership] tant amb el valor retornat com amb el valor de `*src`.
/// Tanmateix, emmagatzemar tipus que no són [[Copia]] a la memòria volàtil és gairebé segur que és incorrecte.
///
/// Tingueu en compte que, fins i tot si `T` té la mida `0`, el punter no ha de ser NULL i està alineat correctament.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Igual que a C, si una operació és volàtil no té cap influència en les qüestions relacionades amb l'accés simultani des de diversos fils.Els accessos volàtils es comporten exactament com els accessos no atòmics en aquest sentit.
///
/// En particular, una carrera entre un `read_volatile` i qualsevol operació d'escriptura en la mateixa ubicació té un comportament indefinit.
///
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // No entrar en pànic per reduir l'impacte del codegen.
        abort();
    }
    // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Realitza una escriptura volàtil d'una ubicació de memòria amb el valor donat sense llegir ni deixar caure el valor anterior.
///
/// Les operacions volàtils tenen la intenció d'actuar sobre la memòria I/O i el compilador garanteix que no les eliminarà ni les reordenarà en altres operacions volàtils.
///
/// `write_volatile` no deixa caure el contingut de `dst`.Això és segur, però pot filtrar assignacions o recursos, per la qual cosa s`ha de procurar no sobreescriure un objecte que s`hauria de deixar caure.
///
/// A més, no deixa caure `src`.Semànticament, `src` es mou a la ubicació assenyalada per `dst`.
///
/// # Notes
///
/// Rust no té actualment un model de memòria rigorosament definit formalment, de manera que la semàntica precisa del que significa "volatile" aquí està subjecta a canvis al llarg del temps.
/// Dit això, la semàntica gairebé sempre acabarà sent bastant similar a [C11's definition of volatile][c11].
///
/// El compilador no hauria de canviar l'ordre relatiu o el nombre d'operacions de memòria volàtils.
/// Tanmateix, les operacions de memòria volàtils en tipus de mida zero (per exemple, si es passa un tipus de mida zero a `write_volatile`) són noops i es poden ignorar.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// El comportament no està definit si es infringeix alguna de les condicions següents:
///
/// * `dst` ha de ser [valid] per a les escriptures.
///
/// * `dst` han d`estar correctament alineats.
///
/// Tingueu en compte que, fins i tot si `T` té la mida `0`, el punter no ha de ser NULL i està alineat correctament.
///
/// [valid]: self#safety
///
/// Igual que a C, si una operació és volàtil no té cap influència en les qüestions relacionades amb l'accés simultani des de diversos fils.Els accessos volàtils es comporten exactament com els accessos no atòmics en aquest sentit.
///
/// En particular, una carrera entre un `write_volatile` i qualsevol altra operació (lectura o escriptura) en la mateixa ubicació té un comportament indefinit.
///
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // No entrar en pànic per reduir l'impacte del codegen.
        abort();
    }
    // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Alineeu el punter `p`.
///
/// Calculeu el desplaçament (en termes d'elements de pas `stride`) que s'ha d'aplicar al punter `p` de manera que el punter `p` s'alinea amb `a`.
///
/// Note: Aquesta implementació s'ha adaptat acuradament per no a panic.És UB per això a panic.
/// L'únic canvi real que es pot fer aquí és el canvi de `INV_TABLE_MOD_16` i les constants associades.
///
/// Si alguna vegada decidim fer possible la trucada a l`intrínsec amb `a` que no sigui una potència de dos, probablement serà més prudent canviar a una implementació ingènua en lloc d`intentar adaptar-la per adaptar-se a aquest canvi.
///
///
/// Qualsevol pregunta aneu a@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): L`ús directe d`aquests productes intrínsecs millora significativament el codegen a nivell d`opció <=
    // 1, on les versions del mètode d'aquestes operacions no estan incloses.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Calculeu inversa modular multiplicativa de `x` mòdul `m`.
    ///
    /// Aquesta implementació està dissenyada per a `align_offset` i té les condicions prèvies següents:
    ///
    /// * `m` és un poder de dos;
    /// * `x < m`; (si és `x ≥ m`, introduïu-lo en `x % m`)
    ///
    /// La implementació d'aquesta funció no serà panic.Sempre.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Taula inversa modular multiplicativa mòdul 2⁴=16.
        ///
        /// Tingueu en compte que aquesta taula no conté valors on no existeix inversa (és a dir, per a `0⁻¹ mod 16`, `2⁻¹ mod 16`, etc.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Mòdul destinat al `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SEGURETAT: cal que `m` sigui una potència de dos, per tant diferent de zero.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Iterem "up" mitjançant la fórmula següent:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // fins a 2²ⁿ ≥ m.Després podem reduir al nostre `m` desitjat prenent el resultat `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Tingueu en compte que aquí fem servir operacions d`embolcall intencionadament: la fórmula original utilitza, per exemple, la resta `mod n`.
                // En canvi, està completament bé fer-los `mod usize::MAX`, de totes maneres prenem el resultat `mod n` al final.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SEGURETAT: `a` és una potència de dos, per tant, no és nul・la.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` case es pot calcular més senzillament mitjançant `-p (mod a)`, però en fer-ho inhibeix la capacitat de LLVM de seleccionar instruccions com `lea`.En canvi, calculem
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // que distribueix les operacions al voltant del portador, però pessimitzant suficientment `and` perquè LLVM pugui utilitzar les diverses optimitzacions que coneix.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Ja està alineat.Visca!
        return 0;
    } else if stride == 0 {
        // Si el punter no està alineat i l'element té una mida zero, llavors cap quantitat d'elements mai alinearà el punter.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SEGURETAT: a és potència de dos, per tant, no és nul・la.stride==0 majúscules i minúscules es gestionen més amunt.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SEGURETAT: gcdpow té un límit superior que és com a màxim el nombre de bits en un usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SEGURETAT: el mcd sempre és major o igual a 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Aquest branch resol la següent equació de congruència lineal:
        //
        // ` p + so = 0 mod a `
        //
        // `p` aquí teniu el valor del punter, `s`, pas de `T`, desplaçament `o` a `T`s i `a`, l'alineació sol・licitada.
        //
        // Amb `g = gcd(a, s)`, i la condició anterior que afirma que `p` també és divisible per `g`, podem denotar `a' = a/g`, `s' = s/g`, `p' = p/g`, llavors això esdevé equivalent a:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // El primer terme és "the relative alignment of `p` to `a`" (dividit pel `g`), el segon terme és "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (dividit de nou per `g`).
        //
        // La divisió per `g` és necessària per fer la inversa ben formada si `a` i `s` no són coprimos.
        //
        // A més, el resultat produït per aquesta solució no és "minimal", per tant, és necessari agafar el resultat `o mod lcm(s, a)`.Podem substituir `lcm(s, a)` per només un `a'`.
        //
        //
        //
        //
        //

        // SEGURETAT: `gcdpow` té un límit superior no superior al nombre de 0 bits posteriors a `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SEGURETAT: `a2` no és nul.Desplaçar `a` per `gcdpow` no pot desplaçar cap dels bits establerts
        // a `a` (de la qual en té exactament un).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SEGURETAT: `gcdpow` té un límit superior no superior al nombre de 0 bits posteriors a `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SEGURETAT: `gcdpow` té un límit superior no superior al nombre de 0 bits posteriors
        // `a`.
        // A més, la resta no es pot desbordar, perquè `a2 = a >> gcdpow` sempre serà estrictament superior a `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SEGURETAT: `a2` és una potència de dos, com s'ha demostrat anteriorment.`s2` és estrictament inferior a `a2`
        // perquè `(s % a) >> gcdpow` és estrictament inferior a `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // No es pot alinear en absolut.
    usize::MAX
}

/// Compara indicadors en brut per a la igualtat.
///
/// Això és el mateix que utilitzar l'operador `==`, però menys genèric:
/// els arguments han de ser punteres en brut `*const T`, no qualsevol cosa que implementi `PartialEq`.
///
/// Es pot utilitzar per comparar referències `&T` (que coaccionen a `*const T` implícitament) per la seva adreça en lloc de comparar els valors als quals assenyalen (que és el que fa la implementació `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Les llesques també es comparen per la seva longitud (indicadors de greix):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits també es compara per la seva implementació:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Els indicadors tenen adreces iguals.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Els objectes tenen adreces iguals, però `Trait` té implementacions diferents.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // La conversió de la referència a un `*const u8` es compara per adreça.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash un punter cru.
///
/// Això es pot utilitzar per resumir una referència `&T` (que coacciona a `*const T` implícitament) per la seva adreça en lloc del valor que apunta (que és el que fa la implementació `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Implementacions per a indicadors de funcions
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: El repartiment intermedi com a ús és necessari per a AVR
                // de manera que l'espai d'adreces del punter de la funció d'origen es conservi al punter de la funció final.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: El repartiment intermedi com a ús és necessari per a AVR
                // de manera que l'espai d'adreces del punter de la funció d'origen es conservi al punter de la funció final.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // No hi ha funcions variadiques amb 0 paràmetres
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Creeu un punter en brut `const` a un lloc, sense crear cap referència intermèdia.
///
/// La creació d`una referència amb `&`/`&mut` només es permet si el punter està correctament alineat i apunta a les dades inicialitzades.
/// Per als casos en què aquests requisits no es compleixin, s'haurien d'utilitzar indicadors en brut.
/// Tanmateix, `&expr as *const _` crea una referència abans de llançar-la a un punter en brut, i aquesta referència està subjecta a les mateixes regles que la resta de referències.
///
/// Aquesta macro pot crear un punter en brut *sense* crear una referència primer.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` crearia una referència no alineada i, per tant, seria un comportament indefinit.
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Creeu un punter en brut `mut` a un lloc, sense crear cap referència intermèdia.
///
/// La creació d`una referència amb `&`/`&mut` només es permet si el punter està correctament alineat i apunta a les dades inicialitzades.
/// Per als casos en què aquests requisits no es compleixin, s'haurien d'utilitzar indicadors en brut.
/// Tanmateix, `&mut expr as *mut _` crea una referència abans de llançar-la a un punter en brut, i aquesta referència està subjecta a les mateixes regles que la resta de referències.
///
/// Aquesta macro pot crear un punter en brut *sense* crear una referència primer.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` crearia una referència no alineada i, per tant, seria un comportament indefinit.
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` força a copiar el camp en lloc de crear una referència.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}