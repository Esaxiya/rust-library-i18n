use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Un embolcall al voltant d`un `*mut T` brut que no és nul que indica que el propietari d`aquest embolcall és propietari del referent.
/// Útil per construir abstraccions com `Box<T>`, `Vec<T>`, `String` i `HashMap<K, V>`.
///
/// A diferència de `*mut T`, `Unique<T>` es comporta "as if", ja que era una instància de `T`.
/// Implementa `Send`/`Sync` si `T` és `Send`/`Sync`.
/// També implica el tipus de fortes garanties d`aliasing que pot esperar una instància de `T`:
/// el referent del punter no s'ha de modificar sense un camí d'accés únic al seu propietari únic.
///
/// Si no esteu segur de si és correcte utilitzar `Unique` per als vostres propòsits, penseu en utilitzar `NonNull`, que té una semàntica més feble.
///
///
/// A diferència de `*mut T`, el punter sempre ha de ser nul, fins i tot si el punter mai no es desferencia.
/// Això és perquè les enumeracions puguin utilitzar aquest valor prohibit com a discriminant: `Option<Unique<T>>` té la mateixa mida que `Unique<T>`.
/// Tanmateix, el punter encara pot penjar si no es desferencia.
///
/// A diferència de `*mut T`, `Unique<T>` és covariant sobre `T`.
/// Això sempre ha de ser correcte per a qualsevol tipus que compleixi els requisits d'aliasing d'Unic.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: aquest marcador no té conseqüències per a la variància, però és necessari
    // perquè Dropck entengui que lògicament som propietaris d`un `T`.
    //
    // Per obtenir més informació, vegeu:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` els indicadors són `Send` si `T` és `Send` perquè les dades a què fan referència no tenen cap tipus d'alias.
/// Tingueu en compte que aquesta invariant d`aliasing no és aplicada pel sistema de tipus;l'abstracció que utilitza l `Unique` l'ha d'aplicar.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` els indicadors són `Sync` si `T` és `Sync` perquè les dades a què fan referència no tenen cap tipus d'alias.
/// Tingueu en compte que aquesta invariant d`aliasing no és aplicada pel sistema de tipus;l'abstracció que utilitza l `Unique` l'ha d'aplicar.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Crea un nou `Unique` penjant, però ben alineat.
    ///
    /// Això és útil per inicialitzar tipus que assignen mandrosament, com fa `Vec::new`.
    ///
    /// Tingueu en compte que el valor del punter pot representar un punter vàlid a un `T`, cosa que significa que no s'ha d'utilitzar com a valor sentinella "not yet initialized".
    /// Els tipus que s`assignen mandrosament han de fer un seguiment de la inicialització per altres mitjans.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SEGURETAT: mem::align_of() retorna un punter vàlid i no nul.El
        // es compleixen les condicions per trucar a new_unchecked().
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Crea un nou `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` no ha de ser nul.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SEGURETAT: la persona que truca ha de garantir que `ptr` no és nul.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Crea un `Unique` nou si `ptr` no és nul.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SEGURETAT: el punter ja s'ha comprovat i no és nul.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Adquireix el punter `*mut` subjacent.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Diferencia el contingut.
    ///
    /// El temps de vida resultant està obligat a si mateix, de manera que es comporta com a "as if", en realitat era una instància de T que es pren prestat.
    /// Si cal una vida més llarga de (unbound), utilitzeu `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SEGURETAT: la persona que truca ha de garantir que `self` compleix tots els requisits
        // requisits per a una referència.
        unsafe { &*self.as_ptr() }
    }

    /// Desferencia mútuament el contingut.
    ///
    /// El temps de vida resultant està obligat a si mateix, de manera que es comporta com a "as if", en realitat era una instància de T que es pren prestat.
    /// Si cal una vida més llarga de (unbound), utilitzeu `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SEGURETAT: la persona que truca ha de garantir que `self` compleix tots els requisits
        // requisits per a una referència mutable.
        unsafe { &mut *self.as_ptr() }
    }

    /// Emet a un punter d'un altre tipus.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SEGURETAT: Unique::new_unchecked() crea un nou producte únic i les seves necessitats
        // el punter donat no serà nul.
        // Com que estem passant un mateix com a punter, no pot ser nul.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SEGURETAT: una referència mutable no pot ser nul・la
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}