use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` però no zero i covariant.
///
/// Sovint això és el correcte que s`utilitza quan es construeixen estructures de dades amb punteres en brut, però en última instància és més perillós d`utilitzar a causa de les seves propietats addicionals.Si no esteu segur de fer servir `NonNull<T>`, només cal que utilitzeu `*mut T`.
///
/// A diferència de `*mut T`, el punter no ha de ser sempre nul, fins i tot si el punter mai no es fa referència.Això és perquè les enumeracions puguin utilitzar aquest valor prohibit com a discriminant: `Option<NonNull<T>>` té la mateixa mida que `* mut T`.
/// Tanmateix, el punter encara pot penjar si no es desferencia.
///
/// A diferència de `*mut T`, `NonNull<T>` va ser escollit per ser covariant sobre `T`.Això fa possible utilitzar `NonNull<T>` quan es construeixen tipus covariants, però introdueix el risc de serietat si s`utilitza en un tipus que en realitat no hauria de ser covariant.
/// (L'opció oposada es va fer per a `*mut T` tot i que tècnicament la insolència només es podria causar mitjançant la crida a funcions no segures.)
///
/// La covariància és correcta per a la majoria d`abstraccions segures, com ara `Box`, `Rc`, `Arc`, `Vec` i `LinkedList`.És el cas perquè proporcionen una API pública que segueix les regles mutables XOR compartides normals de Rust.
///
/// Si el vostre tipus no pot ser covariant amb seguretat, heu d'assegurar-vos que conté algun camp addicional per proporcionar invariancia.Sovint aquest camp serà de tipus [`PhantomData`] com `PhantomData<Cell<T>>` o `PhantomData<&'a mut T>`.
///
/// Fixeu-vos que `NonNull<T>` té una instància `From` per a `&T`.Tanmateix, això no modifica el fet que la mutació a través d'un (punter derivat d'una referència compartida) sigui un comportament indefinit tret que la mutació es produeixi dins d'un [`UnsafeCell<T>`].El mateix passa amb la creació d`una referència mutable a partir d`una referència compartida.
///
/// Quan utilitzeu aquesta instància `From` sense `UnsafeCell<T>`, és responsabilitat vostra assegurar-vos que mai no es crida `as_mut` i que `as_ptr` mai no s`utilitza per a la mutació.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` els indicadors no són `Send` perquè les dades a què fan referència poden estar aliasitzades.
// Nota: aquesta aplicació no és necessària, però hauria de proporcionar millors missatges d'error.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` els indicadors no són `Sync` perquè les dades a què fan referència poden estar aliasitzades.
// Nota: aquesta aplicació no és necessària, però hauria de proporcionar millors missatges d'error.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Crea un nou `NonNull` penjant, però ben alineat.
    ///
    /// Això és útil per inicialitzar tipus que assignen mandrosament, com fa `Vec::new`.
    ///
    /// Tingueu en compte que el valor del punter pot representar un punter vàlid a un `T`, cosa que significa que no s'ha d'utilitzar com a valor sentinella "not yet initialized".
    /// Els tipus que s`assignen mandrosament han de fer un seguiment de la inicialització per altres mitjans.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SEGURETAT: mem::align_of() retorna un ús diferent de zero que després es genera
        // a un * mut T.
        // Per tant, `ptr` no és nul i es compleixen les condicions per trucar a new_unchecked().
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Retorna una referència compartida al valor.A diferència de [`as_ref`], això no requereix que s'hagi d'inicialitzar el valor.
    ///
    /// Per a la contrapart mutable, vegeu [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// En trucar a aquest mètode, heu d'assegurar-vos que es compleixin tot el següent:
    ///
    /// * El punter ha d`estar alineat correctament.
    ///
    /// * Ha de ser "dereferencable" en el sentit definit a [the module documentation].
    ///
    /// * Heu de fer complir les regles d`aliasing de Rust, ja que la vida útil retornada `'a` és elegida arbitràriament i no reflecteix necessàriament la vida real real de les dades.
    ///
    ///   En particular, durant tota aquesta vida, la memòria a què apunta el punter no s'ha de mutar (excepte dins de `UnsafeCell`).
    ///
    /// Això s'aplica fins i tot si el resultat d'aquest mètode no s'utilitza.
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SEGURETAT: la persona que truca ha de garantir que `self` compleix tots els requisits
        // requisits per a una referència.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Retorna referències úniques al valor.A diferència de [`as_mut`], això no requereix que s'hagi d'inicialitzar el valor.
    ///
    /// Per a la contrapartida compartida, consulteu [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// En trucar a aquest mètode, heu d'assegurar-vos que es compleixin tot el següent:
    ///
    /// * El punter ha d`estar alineat correctament.
    ///
    /// * Ha de ser "dereferencable" en el sentit definit a [the module documentation].
    ///
    /// * Heu de fer complir les regles d`aliasing de Rust, ja que la vida útil retornada `'a` és elegida arbitràriament i no reflecteix necessàriament la vida real real de les dades.
    ///
    ///   En particular, durant tota aquesta vida, la memòria a la qual apunta el punter no ha de tenir accés (llegida o escrita) a través de cap altre punter.
    ///
    /// Això s'aplica fins i tot si el resultat d'aquest mètode no s'utilitza.
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SEGURETAT: la persona que truca ha de garantir que `self` compleix tots els requisits
        // requisits per a una referència.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Crea un nou `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` no ha de ser nul.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SEGURETAT: la persona que truca ha de garantir que `ptr` no és nul.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Crea un `NonNull` nou si `ptr` no és nul.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SEGURETAT: el punter ja està marcat i no és nul
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Realitza la mateixa funcionalitat que [`std::ptr::from_raw_parts`], excepte que es retorna un punter `NonNull`, a diferència d`un punter `*const` en brut.
    ///
    ///
    /// Consulteu la documentació de [`std::ptr::from_raw_parts`] per obtenir més informació.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SEGURETAT: el resultat de `ptr::from::raw_parts_mut` no és nul perquè `data_address` ho és.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Descomponeu un punter (possiblement ampli) en components d'adreça i metadades.
    ///
    /// El punter es pot reconstruir posteriorment amb [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Adquireix el punter `*mut` subjacent.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Retorna una referència compartida al valor.Si el valor no es pot inicialitzar, s'ha d'utilitzar [`as_uninit_ref`].
    ///
    /// Per a la contrapart mutable, vegeu [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// En trucar a aquest mètode, heu d'assegurar-vos que es compleixin tot el següent:
    ///
    /// * El punter ha d`estar alineat correctament.
    ///
    /// * Ha de ser "dereferencable" en el sentit definit a [the module documentation].
    ///
    /// * El punter ha d`assenyalar una instància inicialitzada de `T`.
    ///
    /// * Heu de fer complir les regles d`aliasing de Rust, ja que la vida útil retornada `'a` és elegida arbitràriament i no reflecteix necessàriament la vida real real de les dades.
    ///
    ///   En particular, durant tota aquesta vida, la memòria a què apunta el punter no s'ha de mutar (excepte dins de `UnsafeCell`).
    ///
    /// Això s'aplica fins i tot si el resultat d'aquest mètode no s'utilitza.
    /// (La part sobre la inicialització encara no està del tot decidida, però fins que no sigui així, l`únic enfocament segur és assegurar-se que s`inicialitzin.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SEGURETAT: la persona que truca ha de garantir que `self` compleix tots els requisits
        // requisits per a una referència.
        unsafe { &*self.as_ptr() }
    }

    /// Retorna una referència única al valor.Si el valor no es pot inicialitzar, s'ha d'utilitzar [`as_uninit_mut`].
    ///
    /// Per a la contrapartida compartida, consulteu [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// En trucar a aquest mètode, heu d'assegurar-vos que es compleixin tot el següent:
    ///
    /// * El punter ha d`estar alineat correctament.
    ///
    /// * Ha de ser "dereferencable" en el sentit definit a [the module documentation].
    ///
    /// * El punter ha d`assenyalar una instància inicialitzada de `T`.
    ///
    /// * Heu de fer complir les regles d`aliasing de Rust, ja que la vida útil retornada `'a` és elegida arbitràriament i no reflecteix necessàriament la vida real real de les dades.
    ///
    ///   En particular, durant tota aquesta vida, la memòria a la qual apunta el punter no ha de tenir accés (llegida o escrita) a través de cap altre punter.
    ///
    /// Això s'aplica fins i tot si el resultat d'aquest mètode no s'utilitza.
    /// (La part sobre la inicialització encara no està del tot decidida, però fins que no sigui així, l`únic enfocament segur és assegurar-se que s`inicialitzin.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SEGURETAT: la persona que truca ha de garantir que `self` compleix tots els requisits
        // requisits per a una referència mutable.
        unsafe { &mut *self.as_ptr() }
    }

    /// Emet a un punter d'un altre tipus.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SEGURETAT: `self` és un punter `NonNull` que necessàriament no és nul
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Crea un segment cru no nul des d'un punter prim i una longitud.
    ///
    /// L'argument `len` és el nombre de **elements**, no el nombre de bytes.
    ///
    /// Aquesta funció és segura, però la desferenciació del valor retornat no és segura.
    /// Consulteu la documentació de [`slice::from_raw_parts`] per obtenir els requisits de seguretat de les llesques.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // creeu un punter de llesca quan comenceu amb un punter al primer element
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Tingueu en compte que aquest exemple demostra artificialment l'ús d'aquest mètode, però `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SEGURETAT: `data` és un punter `NonNull` que necessàriament no és nul
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Retorna la longitud d'una llesca en brut no nul・la.
    ///
    /// El valor retornat és el nombre de **elements**, no el nombre de bytes.
    ///
    /// Aquesta funció és segura, fins i tot quan el segment brut no nul no es pot referenciar a un segment perquè el punter no té una adreça vàlida.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Retorna un punter no nul al buffer del segment.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SEGURETAT: sabem que `self` no és nul.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Retorna un punter en brut al buffer del segment.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Retorna una referència compartida a un segment de valors possiblement no inicialitzats.A diferència de [`as_ref`], això no requereix que s'hagi d'inicialitzar el valor.
    ///
    /// Per a la contrapart mutable, vegeu [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// En trucar a aquest mètode, heu d'assegurar-vos que es compleixin tot el següent:
    ///
    /// * El punter ha de ser [valid] per a lectures de `ptr.len() * mem::size_of::<T>()` de molts bytes i ha d`estar correctament alineat.Això significa en particular:
    ///
    ///     * L'interval de memòria d'aquesta part ha d'estar inclòs dins d'un sol objecte assignat.
    ///       Les llesques mai no poden abastar diversos objectes assignats.
    ///
    ///     * El punter ha d`estar alineat fins i tot per a rodanxes de longitud zero.
    ///     Una de les raons per això és que les optimitzacions de disseny d'enum poden dependre de que les referències (incloses les llesques de qualsevol longitud) estiguin alineades i no nul・les per distingir-les d'altres dades.
    ///
    ///     Podeu obtenir un punter que es pugui utilitzar com a `data` per a talls de longitud zero amb [`NonNull::dangling()`].
    ///
    /// * La mida total `ptr.len() * mem::size_of::<T>()` de la part no pot ser superior a `isize::MAX`.
    ///   Consulteu la documentació de seguretat de [`pointer::offset`].
    ///
    /// * Heu de fer complir les regles d`aliasing de Rust, ja que la vida útil retornada `'a` és elegida arbitràriament i no reflecteix necessàriament la vida real real de les dades.
    ///   En particular, durant tota aquesta vida, la memòria a què apunta el punter no s'ha de mutar (excepte dins de `UnsafeCell`).
    ///
    /// Això s'aplica fins i tot si el resultat d'aquest mètode no s'utilitza.
    ///
    /// Vegeu també [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Retorna una referència única a un segment de valors possiblement no inicialitzats.A diferència de [`as_mut`], això no requereix que s'hagi d'inicialitzar el valor.
    ///
    /// Per a la contrapartida compartida, consulteu [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// En trucar a aquest mètode, heu d'assegurar-vos que es compleixin tot el següent:
    ///
    /// * El punter ha de ser [valid] per a les lectures i escriptures per a molts bytes `ptr.len() * mem::size_of::<T>()`, i ha d`estar correctament alineat.Això significa en particular:
    ///
    ///     * L'interval de memòria d'aquesta part ha d'estar inclòs dins d'un sol objecte assignat.
    ///       Les llesques mai no poden abastar diversos objectes assignats.
    ///
    ///     * El punter ha d`estar alineat fins i tot per a rodanxes de longitud zero.
    ///     Una de les raons per això és que les optimitzacions de disseny d'enum poden dependre de que les referències (incloses les llesques de qualsevol longitud) estiguin alineades i no nul・les per distingir-les d'altres dades.
    ///
    ///     Podeu obtenir un punter que es pugui utilitzar com a `data` per a talls de longitud zero amb [`NonNull::dangling()`].
    ///
    /// * La mida total `ptr.len() * mem::size_of::<T>()` de la part no pot ser superior a `isize::MAX`.
    ///   Consulteu la documentació de seguretat de [`pointer::offset`].
    ///
    /// * Heu de fer complir les regles d`aliasing de Rust, ja que la vida útil retornada `'a` és elegida arbitràriament i no reflecteix necessàriament la vida real real de les dades.
    ///   En particular, durant tota aquesta vida, la memòria a la qual apunta el punter no ha de tenir accés (llegida o escrita) a través de cap altre punter.
    ///
    /// Això s'aplica fins i tot si el resultat d'aquest mètode no s'utilitza.
    ///
    /// Vegeu també [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Això és segur ja que `memory` és vàlid per a lectures i escriptures per a molts bytes de `memory.len()`.
    /// // Tingueu en compte que no es permet trucar a `memory.as_mut()` aquí, ja que és possible que no s`inicialitzi el contingut.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Retorna un punter en brut a un element o subslice, sense fer la comprovació de límits.
    ///
    /// Cridar aquest mètode amb un índex fora de límits o quan `self` no es pot referenciar és *[comportament indefinit]* fins i tot si no es fa servir el punter resultant.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SEGURETAT: la persona que truca s'assegura que `self` no es pot referenciar i que `index` es troba dins dels límits.
        // Com a conseqüència, el punter resultant no pot ser NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SEGURETAT: Un punter únic no pot ser nul, de manera que les condicions per a
        // new_unchecked() són respectats.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SEGURETAT: una referència mutable no pot ser nul・la.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SEGURETAT: una referència no pot ser nul・la, de manera que les condicions per a
        // new_unchecked() són respectats.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}