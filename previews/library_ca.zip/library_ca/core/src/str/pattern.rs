//! La cadena API Patró.
//!
//! L'API Patró proporciona un mecanisme genèric per utilitzar diferents tipus de patrons quan es busca a través d'una cadena.
//!
//! Per obtenir més informació, consulteu traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] i [`DoubleEndedSearcher`].
//!
//! Tot i que aquesta API és inestable, s`exposa mitjançant API estables del tipus [`str`].
//!
//! # Examples
//!
//! [`Pattern`] és [implemented][pattern-impls] a l'API estable per a [`&str`][`str`], [`char`], talls de [`char`] i funcions i tancaments que implementen `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // patró de caràcters
//! assert_eq!(s.find('n'), Some(2));
//! // patró de tall de caràcters
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // patró de tancament
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Un patró de corda.
///
/// Un `Pattern<'a>` expressa que el tipus d'implementació es pot utilitzar com a patró de cadena per cercar en un [`&'a str`][str].
///
/// Per exemple, tant `'a'` com `"aa"` són patrons que coincidirien a l'índex `1` de la cadena `"baaaab"`.
///
/// El propi trait actua com a constructor per a un tipus [`Searcher`] associat, que realitza el treball real de trobar les ocurrències del patró en una cadena.
///
///
/// Depenent del tipus de patró, el comportament de mètodes com [`str::find`] i [`str::contains`] pot canviar.
/// La taula següent descriu alguns d`aquests comportaments.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Cercador associat d'aquest patró
    type Searcher: Searcher<'a>;

    /// Construeix el cercador associat des de `self` i `haystack` per cercar-hi.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Comprova si el patró coincideix en qualsevol lloc del paller
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Comprova si el patró coincideix a la part frontal del paller
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Comprova si el patró coincideix a la part posterior del paller
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Elimina el patró de la part davantera del paller, si coincideix.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // SEGURETAT: se sap que `Searcher` retorna índexs vàlids.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Elimina el patró de la part posterior del paller, si coincideix.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // SEGURETAT: se sap que `Searcher` retorna índexs vàlids.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Resultat de la trucada a [`Searcher::next()`] o [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Expressa que s`ha trobat una coincidència del patró a `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Expressa que `haystack[a..b]` s'ha rebutjat com a possible concordança del patró.
    ///
    /// Tingueu en compte que hi pot haver més d'un `Reject` entre dos `Match`es, no hi ha cap requisit perquè es combinin en un.
    ///
    ///
    Reject(usize, usize),
    /// Expressa que s`ha visitat cada byte del paller, acabant la iteració.
    ///
    Done,
}

/// Un cercador d'un patró de cadena.
///
/// Aquest trait proporciona mètodes per cercar coincidències que no se superposin d'un patró que comença des de la (left) frontal d'una cadena.
///
/// Serà implementat pels tipus `Searcher` associats del [`Pattern`] trait.
///
/// El trait està marcat com a insegur perquè els índexs retornats pels mètodes [`next()`][Searcher::next] han de situar-se en límits vàlids de utf8 al paller.
/// Això permet als consumidors d`aquest trait tallar el paller sense comprovacions de temps d`execució addicionals.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter per cercar la cadena subjacent
    ///
    /// Tornarà sempre el mateix [`&str`][str].
    fn haystack(&self) -> &'a str;

    /// Realitza el següent pas de cerca a partir de la part frontal.
    ///
    /// - Retorna [`Match(a, b)`][SearchStep::Match] si `haystack[a..b]` coincideix amb el patró.
    /// - Retorna [`Reject(a, b)`][SearchStep::Reject] si `haystack[a..b]` no pot coincidir amb el patró, ni tan sols parcialment.
    /// - Retorna [`Done`][SearchStep::Done] si s'ha visitat cada byte del paller.
    ///
    /// El flux de valors [`Match`][SearchStep::Match] i [`Reject`][SearchStep::Reject] fins a un [`Done`][SearchStep::Done] contindrà intervals d'índexs adjacents, que no es superposen, que cobreixen tot el paller i que es posen en límits utf8.
    ///
    ///
    /// Un resultat [`Match`][SearchStep::Match] ha de contenir tot el patró coincident, tot i que els resultats [`Reject`][SearchStep::Reject] es poden dividir en molts fragments adjacents arbitraris.Els dos intervals poden tenir una longitud zero.
    ///
    /// Com a exemple, el patró `"aaa"` i el paller `"cbaaaaab"` poden produir el flux
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Troba el següent resultat [`Match`][SearchStep::Match].Vegeu [`next()`][Searcher::next].
    ///
    /// A diferència de [`next()`][Searcher::next], no hi ha cap garantia que els intervals retornats d'aquest i [`next_reject`][Searcher::next_reject] se superposin.
    /// Es retornarà `(start_match, end_match)`, on start_match és l`índex d`on comença el partit i end_match és l`índex després del final del partit.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Troba el següent resultat [`Reject`][SearchStep::Reject].Vegeu [`next()`][Searcher::next] i [`next_match()`][Searcher::next_match].
    ///
    /// A diferència de l [`next()`][Searcher::next], no hi ha cap garantia que els intervals retornats d'aquest i [`next_match`][Searcher::next_match] se superposin.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Un cercador invers per a un patró de cadena.
///
/// Aquest trait proporciona mètodes per cercar coincidències que no se superposin d'un patró a partir de la (right) posterior d'una cadena.
///
/// S`implementarà mitjançant els tipus [`Searcher`] associats de l [`Pattern`] trait si el patró admet cercar-lo des de la part posterior.
///
///
/// Els intervals d'índexs retornats per aquest trait no estan obligats a coincidir exactament amb els de la cerca directa al revés.
///
/// Per la raó per la qual aquest trait està marcat com a insegur, vegeu-lo com a pare trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Realitza el següent pas de cerca a partir de la part posterior.
    ///
    /// - Retorna [`Match(a, b)`][SearchStep::Match] si `haystack[a..b]` coincideix amb el patró.
    /// - Retorna [`Reject(a, b)`][SearchStep::Reject] si `haystack[a..b]` no pot coincidir amb el patró, ni tan sols parcialment.
    /// - Retorna [`Done`][SearchStep::Done] si s'ha visitat cada byte del paller
    ///
    /// El flux de valors [`Match`][SearchStep::Match] i [`Reject`][SearchStep::Reject] fins a un [`Done`][SearchStep::Done] contindrà intervals d'índexs adjacents, que no es superposen, que cobreixen tot el paller i que es posen en límits utf8.
    ///
    ///
    /// Un resultat [`Match`][SearchStep::Match] ha de contenir tot el patró coincident, tot i que els resultats [`Reject`][SearchStep::Reject] es poden dividir en molts fragments adjacents arbitraris.Els dos intervals poden tenir una longitud zero.
    ///
    /// Com a exemple, el patró `"aaa"` i el paller `"cbaaaaab"` poden produir el flux `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Troba el següent resultat [`Match`][SearchStep::Match].
    /// Vegeu [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Troba el següent resultat [`Reject`][SearchStep::Reject].
    /// Vegeu [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Un marcador trait per expressar que es pot utilitzar un [`ReverseSearcher`] per a una implementació [`DoubleEndedIterator`].
///
/// Per a això, la implementació de [`Searcher`] i [`ReverseSearcher`] ha de complir aquestes condicions:
///
/// - Tots els resultats de `next()` han de ser idèntics als resultats de `next_back()` en ordre invers.
/// - `next()` i `next_back()` han de comportar-se com els dos extrems d'un rang de valors, és a dir, no poden "walk past each other".
///
/// # Examples
///
/// `char::Searcher` és un `DoubleEndedSearcher` perquè cercar un [`char`] només requereix mirar-ne un a la vegada, que es comporta igual des dels dos extrems.
///
/// `(&str)::Searcher` no és un `DoubleEndedSearcher` perquè el patró `"aa"` del paller `"aaa"` coincideix amb `"[aa]a"` o `"a[aa]"`, depenent de quin costat es busca.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl
/////////////////////////////////////////////////////////////////////////////

/// Tipus associat per a `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // invariant de seguretat: `finger`/`finger_back` ha de ser un índex de bytes utf8 vàlid de `haystack`. Aquest invariant es pot trencar *dins de* next_match i next_match_back, però han de sortir amb els dits als límits vàlids dels punts de codi.
    //
    //
    /// `finger` és l'índex de bytes actual de la cerca directa.
    /// Imagineu que existeix abans del byte al seu índex, és a dir
    /// `haystack[finger]` és el primer byte de la llesca que hem d'inspeccionar durant la cerca directa
    ///
    finger: usize,
    /// `finger_back` és l'índex de bytes actual de la cerca inversa.
    /// Imagineu que existeix després del byte al seu índex, és a dir
    /// haystack [finger_back, 1] és l'últim byte de la llesca que hem d'inspeccionar durant la cerca directa (i, per tant, el primer byte que s'ha d'inspeccionar en trucar a next_back()).
    ///
    finger_back: usize,
    /// El personatge que es busca
    needle: char,

    // invariant de seguretat: `utf8_size` ha de ser inferior a 5
    /// El nombre de bytes `needle` ocupa quan es codifica a utf8.
    utf8_size: usize,
    /// Una còpia codificada utf8 del `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // SEGURETAT: 1-4 garanteix la seguretat de `get_unchecked`
        // 1. `self.finger` i `self.finger_back` es mantenen als límits unicode (això és invariant)
        // 2. `self.finger >= 0` ja que comença a 0 i només augmenta
        // 3. `self.finger < self.finger_back` perquè en cas contrari, el caràcter `iter` retornaria `SearchStep::Done`
        // 4.
        // `self.finger` arriba abans del final del paller perquè `self.finger_back` comença al final i només disminueix
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // afegiu un desplaçament de bytes del caràcter actual sense tornar a codificar com a utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // aconsegueix el paller després de l'últim personatge trobat
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // l`últim byte de l`agulla codificada utf8 SEGURETAT: tenim un invariant que `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // El nou dit és l`índex del byte que hem trobat, més un, ja que hem memoritzat l`últim byte del caràcter.
                //
                // Tingueu en compte que això no sempre ens dóna un dit sobre un límit UTF8.
                // Si *no* hem trobat el nostre caràcter, és possible que hàgim indexat el byte no definitiu d'un caràcter de 3 o 4 bytes.
                // No podem passar al següent byte inicial vàlid perquè un caràcter com ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` ens farà trobar sempre el segon byte en cercar el tercer.
                //
                //
                // Tot i això, està totalment bé.
                // Tot i que tenim la invariant que self.finger es troba en un límit UTF8, aquest invariant no es basa en aquest mètode (es basa en CharSearcher::next()).
                //
                // Només sortim d`aquest mètode quan arribem al final de la cadena o si trobem alguna cosa.Quan trobem alguna cosa, el `finger` es fixarà en un límit UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // no he trobat res, surt
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // deixeu que next_reject utilitzi la implementació per defecte des del Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // SEGURETAT: vegeu el comentari sobre next() anterior
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // restar el desplaçament de bytes del caràcter actual sense tornar a codificar com a utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // fes servir el paller, però no inclou l'últim personatge cercat
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // l`últim byte de l`agulla codificada utf8 SEGURETAT: tenim un invariant que `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // hem buscat una llesca que ha estat compensada per self.finger, afegiu self.finger per recuperar l'índex original
                //
                let index = self.finger + index;
                // memrchr retornarà l'índex del byte que volem trobar.
                // En cas de tenir un caràcter ASCII, és realment si desitgem que el nostre nou dit sigui ("after" el caràcter trobat en el paradigma de la iteració inversa).
                //
                // Per als caràcters multibyte, hem de saltar pel nombre de bytes que tenen més que ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // mou el dit cap a abans del caràcter trobat (és a dir, al seu índex inicial)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Aquí no podem utilitzar finger_back=index, mida + 1.
                // Si trobem l'últim caràcter d'un caràcter de mida diferent (o el byte mitjà d'un caràcter diferent), hem de reduir el finger_back a `index`.
                // Això fa que `finger_back` tingui el potencial de deixar de ser en un límit, però està bé, ja que només sortim d'aquesta funció en un límit o quan s'ha cercat completament el paller.
                //
                //
                // A diferència de next_match, això no té el problema dels bytes repetits a utf-8 perquè estem buscant l'últim byte i només podem haver trobat l'últim byte quan cerquem a l'inrevés.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // no he trobat res, surt
                return None;
            }
        }
    }

    // deixeu que next_reject_back utilitzi la implementació per defecte des del Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Cerca caràcters que siguin iguals a un [`char`] determinat.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Implica un embolcall MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Compareu les longituds de l'iterador de llesques de bytes interns per trobar la longitud del caràcter actual
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Compareu les longituds de l'iterador de llesques de bytes interns per trobar la longitud del caràcter actual
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Implica per a [char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Canviar/Eliminar a causa de l'ambigüitat del significat.

/// Tipus associat per a `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Cerca caràcters que siguin iguals a qualsevol dels [`char`] del segment.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl per F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Tipus associat per a `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Cerca de [`char`] que coincideixin amb el predicat donat.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl per a&&str
/////////////////////////////////////////////////////////////////////////////

/// Delegats a la impl. `&str`
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl per &str
/////////////////////////////////////////////////////////////////////////////

/// Cerca de subcadres sense assignació.
///
/// Manejarà el patró `""` com a retorns de coincidències buides a cada límit de caràcters.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Comprova si el patró coincideix a la part frontal del paller.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Elimina el patró de la part davantera del paller, si coincideix.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // SEGURETAT: s'acaba de verificar que existeix el prefix.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Comprova si el patró coincideix a la part posterior del paller.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Elimina el patró de la part posterior del paller, si coincideix.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // SEGURETAT: s'acaba de verificar que existeix el sufix.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Cercador de subcadres de dues vies
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Tipus associat per a `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // l'agulla buida rebutja tots els caràcters i fa coincidir cada cadena buida entre ells
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher produeix índexs *Match* vàlids que es divideixen als límits de caràcters sempre que es correspongui correctament i que el paller i l'agulla siguin vàlids UTF-8 *Els rebuigs* de l'algorisme poden caure en qualsevol índex, però els guiarem manualment fins al límit de caràcters següent, de manera que siguin segurs per a utf-8.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // vés al límit de caràcters següent
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // escriviu casos `true` i `false` per animar el compilador a especialitzar els dos casos per separat.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // vés al límit de caràcters següent
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // escriviu `true` i `false`, com `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// L'estat intern de l'algoritme de cerca de cadenes de dues vies.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// índex de factorització crítica
    crit_pos: usize,
    /// índex crític de factorització de l`agulla invertida
    crit_pos_back: usize,
    period: usize,
    /// `byteset` és una extensió (no forma part de l'algorisme bidireccional);
    /// és un "fingerprint" de 64 bits on cada conjunt de bits `j` correspon a un (byte i 63)==j present a l'agulla.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// índex en agulla abans de la qual ja hem coincidit
    memory: usize,
    /// índex en agulla després del qual ja hem coincidit
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Una explicació particularment llegible del que passa aquí es troba al llibre "Text Algorithms" de Crochemore i Rytter, capítol 13.
        // Vegeu específicament el codi per a "Algorithm CP" a la pàg.
        // 323.
        //
        // El que passa és que tenim una factorització crítica (u, v) de l`agulla i volem determinar si u és un sufix de&v [.. punt].
        // Si és així, fem servir "Algorithm CP1".
        // En cas contrari, fem servir "Algorithm CP2", que està optimitzat quan el període de l`agulla és gran.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // cas de període curt: el període és exacte calculeu una factorització crítica separada per a l'agulla invertida x=u 'v' on | v '|<period(x).
            //
            // Això s`accelera ja que es coneix el període.
            // Tingueu en compte que un cas com x= "acba" es pot tenir en compte exactament cap endavant (crit_pos=1, període=3) mentre es té en compte el període aproximat a la inversa (crit_pos=2, període=2).
            // Utilitzem la factorització inversa donada però mantenim el període exacte.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // cas de llarg període: tenim una aproximació al període real i no fem servir la memorització.
            //
            //
            // Aproximar el període per límit inferior max(|u|, |v|) + 1.
            // La factorització crítica és eficaç per utilitzar tant per a la cerca directa com inversa.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Valor fictici per indicar que el període és llarg
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Una de les idees principals de Two-Way és que dividim l'agulla en dues meitats, (u, v), i comencem a intentar trobar v al paller escanejant d'esquerra a dreta.
    // Si v coincideix, intentem fer coincidir u escanejant de dreta a esquerra.
    // Fins on podem saltar quan ens trobem amb un desajust es basa en el fet que (u, v) és una factorització crítica per a l`agulla.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` utilitza `self.position` com a cursor
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Comproveu que tenim espai per cercar en posició + agulla_last no pot desbordar-se si suposem que les rodanxes estan limitades per l`interval d`isize
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Saltar ràpidament per parts grans que no estiguin relacionades amb la nostra subcadena
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Veure si la part dreta de l`agulla coincideix
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Veure si la part esquerra de l`agulla coincideix
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Hem trobat una coincidència!
            let match_pos = self.position;

            // Note: afegiu self.period en lloc de needle.len() per tenir coincidències superposades
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // s'estableix a needle.len(), self.period per a coincidències superposades
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Segueix les idees a `next()`.
    //
    // Les definicions són simètriques, amb period(x) = period(reverse(x)) i local_period(u, v) = local_period(reverse(v), reverse(u)), de manera que si (u, v) és una factorització crítica, també ho és (reverse(v), reverse(u)).
    //
    //
    // Per al cas invers, hem calculat una factorització crítica x=u 'v' (camp `crit_pos_back`).Necessitem | u |<period(x) per al cas directe i per tant | v '|<period(x) per al revés.
    //
    // Per buscar a la inversa a través del paller, cerquem cap endavant a través d`un paller invertit amb una agulla invertida, coincidint primer amb u 'i després amb v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` utilitza `self.end` com a cursor, de manera que `next()` i `next_back()` són independents.
        //
        let old_end = self.end;
        'search: loop {
            // Comproveu que al final hi hagi espai per cercar, needle.len() s`enrotllarà quan ja no hi hagi espai, però a causa dels límits de longitud de la llesca, no es pot tornar a endinsar fins a la longitud del paller.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Saltar ràpidament per parts grans que no estiguin relacionades amb la nostra subcadena
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Veure si la part esquerra de l`agulla coincideix
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Veure si la part dreta de l`agulla coincideix
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Hem trobat una coincidència!
            let match_pos = self.end - needle.len();
            // Note: sub self.period en lloc de needle.len() per tenir coincidències superposades
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Calculeu el sufix màxim de `arr`.
    //
    // El sufix màxim és una possible factorització crítica (u, v) de `arr`.
    //
    // Retorna (`i`, `p`) on `i` és l'índex inicial de v i `p` és el període de v.
    //
    // `order_greater` determina si l'ordre lèxic és `<` o `>`.
    // Les dues ordres s'han de calcular: l'ordenació amb el `i` més gran proporciona una factorització crítica.
    //
    //
    // Per als casos de períodes llargs, el període resultant no és exacte (és massa curt).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Correspon a la i del diari
        let mut right = 1; // Correspon a j al document
        let mut offset = 0; // Correspon a k del document, però a partir de 0
        // per coincidir amb la indexació basada en 0.
        let mut period = 1; // Correspon a la p del paper

        while let Some(&a) = arr.get(right + offset) {
            // `left` seran entrants quan `right` estigui.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // El sufix és més petit, fins al moment el prefix sencer.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Avançar mitjançant la repetició del període actual.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // El sufix és més gran, comenceu de nou des de la ubicació actual.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Calculeu el sufix màxim del revers de `arr`.
    //
    // El sufix màxim és una possible factorització crítica (u ', v') de `arr`.
    //
    // Retorna `i` on `i` és l'índex inicial de v ', des de la part posterior;
    // torna immediatament quan s'arriba a un període de `known_period`.
    //
    // `order_greater` determina si l'ordre lèxic és `<` o `>`.
    // Les dues ordres s'han de calcular: l'ordenació amb el `i` més gran proporciona una factorització crítica.
    //
    //
    // Per als casos de períodes llargs, el període resultant no és exacte (és massa curt).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Correspon a la i del diari
        let mut right = 1; // Correspon a j al document
        let mut offset = 0; // Correspon a k del document, però a partir de 0
        // per coincidir amb la indexació basada en 0.
        let mut period = 1; // Correspon a la p del paper
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // El sufix és més petit, fins al moment el prefix sencer.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Avançar mitjançant la repetició del període actual.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // El sufix és més gran, comenceu de nou des de la ubicació actual.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy permet a l'algoritme saltar les coincidències el més ràpidament possible o bé treballar en un mode en què emet Rebutja relativament ràpidament.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Vés a coincidir els intervals el més ràpidament possible
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emet Rebutges regularment
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}