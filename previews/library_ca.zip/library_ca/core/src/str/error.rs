//! Defineix el tipus d'error utf8.

use crate::fmt;

/// Errors que es poden produir en intentar interpretar una seqüència de [`u8`] com una cadena.
///
/// Com a tal, la família de funcions i mètodes `from_utf8` tant per a [`String`] com per a [`&str`] s utilitzen aquest error, per exemple.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Els mètodes d'aquest tipus d'error es poden utilitzar per crear funcionalitats similars a `String::from_utf8_lossy` sense assignar memòria dinàmica:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Retorna l'índex de la cadena donada fins a la qual s'ha verificat UTF-8 vàlid.
    ///
    /// És l'índex màxim tal que `from_utf8(&input[..index])` retornaria `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// use std::str;
    ///
    /// // alguns bytes no vàlids, en un vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 retorna un Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // el segon byte no és vàlid aquí
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Proporciona més informació sobre l'error:
    ///
    /// * `None`: s'ha arribat al final de l'entrada inesperadament.
    ///   `self.valid_up_to()` és d'1 a 3 bytes des del final de l'entrada.
    ///   Si s'està descodificant incrementalment un flux de bytes (com ara un fitxer o un sòcol de xarxa), aquest podria ser un `char` vàlid la seqüència de bytes UTF-8 de la qual abasta diversos fragments.
    ///
    ///
    /// * `Some(len)`: s'ha trobat un byte inesperat.
    ///   La longitud proporcionada és la de la seqüència de bytes no vàlida que comença a l'índex donat per `valid_up_to()`.
    ///   La descodificació s'hauria de reprendre després d'aquesta seqüència (després d'inserir un [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) en cas de descodificació amb pèrdues.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// S'ha produït un error en analitzar un `bool` amb [`from_str`]
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}