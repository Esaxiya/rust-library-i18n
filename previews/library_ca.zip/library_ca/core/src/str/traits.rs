//! Implementacions Trait per a `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Implementa l`ordenació de cordes.
///
/// Les cadenes s`ordenen [lexicographically](Ord#lexicographical-comparison) pel seu valor de bytes.
/// Això ordena punts de codi Unicode en funció de les seves posicions als gràfics de codis.
/// Això no és necessàriament el mateix que l'ordre "alphabetical", que varia segons l'idioma i la configuració regional.
/// L`ordenació de les cadenes d`acord amb els estàndards acceptats culturalment requereix dades específiques de la configuració local que estiguin fora de l`abast del tipus `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Implementa operacions de comparació en cadenes.
///
/// Les cadenes es comparen [lexicographically](Ord#lexicographical-comparison) pels seus valors de bytes.
/// Això compara els punts de codi Unicode en funció de les seves posicions als gràfics de codis.
/// Això no és necessàriament el mateix que l'ordre "alphabetical", que varia segons l'idioma i la configuració regional.
/// La comparació de cadenes d`acord amb els estàndards acceptats culturalment requereix dades específiques de l`entorn local que estiguin fora de l`abast del tipus `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Implementa la segmentació de cadenes amb la sintaxi `&self[..]` o `&mut self[..]`.
///
/// Retorna un segment de tota la cadena, és a dir, retorna `&self` o `&mut self`.Equival a `&self [0 ..
/// len] `o`&mut self [0 ..
/// len]`.
/// A diferència d'altres operacions d'indexació, això mai no pot panic.
///
/// Aquesta operació és *O*(1).
///
/// Abans de 1.20.0, aquestes operacions d'indexació encara eren compatibles amb la implementació directa de `Index` i `IndexMut`.
///
/// Equival a `&self[0 .. len]` o `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Implementa la segmentació de cadenes amb la sintaxi `&self[begin .. end]` o `&mut self[begin .. end]`.
///
/// Retorna un segment de la cadena donada del rang de bytes [`begin`, `end`).
///
/// Aquesta operació és *O*(1).
///
/// Abans de 1.20.0, aquestes operacions d'indexació encara eren compatibles amb la implementació directa de `Index` i `IndexMut`.
///
/// # Panics
///
/// Panics si `begin` o `end` no apunta al desplaçament de bytes inicial d'un caràcter (tal com es defineix per `is_char_boundary`), si `begin > end` o si `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // aquests seran panic:
/// // el byte 2 es troba dins de `ö`:
/// // &s [2 ..3];
///
/// // el byte 8 es troba dins de `老`&s [1 ..
/// // 8];
///
/// // el byte 100 està fora de la cadena&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SEGURETAT: acaba de comprovar que `start` i `end` es troben en un límit de caràcters,
            // i estem passant una referència segura, de manera que el valor de retorn també serà un.
            // També hem comprovat els límits de caràcters, de manera que és vàlid UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SEGURETAT: acaba de comprovar que `start` i `end` es troben en un límit de caràcters.
            // Sabem que el punter és únic perquè el vam obtenir de `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SEGURETAT: la persona que truca garanteix que `self` es troba en els límits de `slice`
        // que compleix totes les condicions per a `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SEGURETAT: vegeu els comentaris de `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary comprova que l'índex es troba a [0, .len()] no pot reutilitzar `get` com s'ha indicat anteriorment, a causa d'un problema de NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SEGURETAT: acaba de comprovar que `start` i `end` es troben en un límit de caràcters,
            // i estem passant una referència segura, de manera que el valor de retorn també serà un.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Implementa la segmentació de cadenes amb la sintaxi `&self[.. end]` o `&mut self[.. end]`.
///
/// Retorna un segment de la cadena donada de l'interval de bytes [`0`, `end`).
/// Equival a `&self[0 .. end]` o `&mut self[0 .. end]`.
///
/// Aquesta operació és *O*(1).
///
/// Abans de 1.20.0, aquestes operacions d'indexació encara eren compatibles amb la implementació directa de `Index` i `IndexMut`.
///
/// # Panics
///
/// Panics si `end` no apunta al desplaçament de bytes inicial d'un caràcter (tal com es defineix per `is_char_boundary`), o si `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SEGURETAT: acaba de comprovar que `end` es troba en un límit de caràcters,
            // i estem passant una referència segura, de manera que el valor de retorn també serà un.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SEGURETAT: acaba de comprovar que `end` es troba en un límit de caràcters,
            // i estem passant una referència segura, de manera que el valor de retorn també serà un.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SEGURETAT: acaba de comprovar que `end` es troba en un límit de caràcters,
            // i estem passant una referència segura, de manera que el valor de retorn també serà un.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Implementa la segmentació de cadenes amb la sintaxi `&self[begin ..]` o `&mut self[begin ..]`.
///
/// Retorna un segment de la cadena donada del rang de bytes [`begin`, `len`).Equival a `&self [comença ..
/// len] `o`&mut self [començar ..
/// len]`.
///
/// Aquesta operació és *O*(1).
///
/// Abans de 1.20.0, aquestes operacions d'indexació encara eren compatibles amb la implementació directa de `Index` i `IndexMut`.
///
/// # Panics
///
/// Panics si `begin` no apunta al desplaçament de bytes inicial d'un caràcter (tal com es defineix per `is_char_boundary`), o si `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SEGURETAT: acaba de comprovar que `start` es troba en un límit de caràcters,
            // i estem passant una referència segura, de manera que el valor de retorn també serà un.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SEGURETAT: acaba de comprovar que `start` es troba en un límit de caràcters,
            // i estem passant una referència segura, de manera que el valor de retorn també serà un.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SEGURETAT: la persona que truca garanteix que `self` es troba en els límits de `slice`
        // que compleix totes les condicions per a `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SEGURETAT: idèntica a `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SEGURETAT: acaba de comprovar que `start` es troba en un límit de caràcters,
            // i estem passant una referència segura, de manera que el valor de retorn també serà un.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Implementa la segmentació de cadenes amb la sintaxi `&self[begin ..= end]` o `&mut self[begin ..= end]`.
///
/// Retorna un segment de la cadena donada de l'interval de bytes [`begin`, `end`].Equival a `&self [begin .. end + 1]` o `&mut self[begin .. end + 1]`, tret que `end` tingui el valor màxim per a `usize`.
///
/// Aquesta operació és *O*(1).
///
/// # Panics
///
/// Panics si `begin` no apunta al desplaçament de bytes inicials d`un caràcter (tal com es defineix per `is_char_boundary`), si `end` no apunta al desplaçament de bytes finals d`un caràcter (`end + 1` és un desplaçament de bytes inicials o igual a `len`), si `begin > end`, o si `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Implementa la segmentació de cadenes amb la sintaxi `&self[..= end]` o `&mut self[..= end]`.
///
/// Retorna una llesca de la cadena donada del rang de bytes [0, `end`].
/// Equival a `&self [0 .. end + 1]`, excepte si `end` té el valor màxim per a `usize`.
///
/// Aquesta operació és *O*(1).
///
/// # Panics
///
/// Panics si `end` no apunta al desplaçament de bytes finals d'un caràcter (`end + 1` és un desplaçament de bytes inicial definit per `is_char_boundary` o igual a `len`) o si `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Analitzeu un valor d'una cadena
///
/// El mètode [`from_str`] de `FromStr` s'utilitza sovint implícitament mitjançant el mètode [`parse`] de [`str`].
/// Consulteu la documentació de [`analitzar`] per obtenir exemples.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` no té un paràmetre de vida útil, de manera que només podeu analitzar els tipus que no contenen un paràmetre de vida útil.
///
/// En altres paraules, podeu analitzar un `i32` amb `FromStr`, però no un `&i32`.
/// Podeu analitzar una estructura que conté un `i32`, però no una que contingui un `&i32`.
///
/// # Examples
///
/// Implementació bàsica de `FromStr` en un exemple de tipus `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// L'error associat que es pot retornar de l'anàlisi.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Analitza una cadena `s` per retornar un valor d'aquest tipus.
    ///
    /// Si l'anàlisi té èxit, torneu el valor dins de [`Ok`]; en cas contrari, quan la cadena no tingui un format, torneu un error específic a l'interior de [`Err`].
    /// El tipus d'error és específic per a la implementació de trait.
    ///
    /// # Examples
    ///
    /// Ús bàsic amb [`i32`], un tipus que implementa `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Analitzeu un `bool` des d'una cadena.
    ///
    /// Ofereix un `Result<bool, ParseBoolError>`, perquè `s` pot ser o no realment analitzable.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Tingueu en compte que, en molts casos, el mètode `.parse()` a `str` és més adequat.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}