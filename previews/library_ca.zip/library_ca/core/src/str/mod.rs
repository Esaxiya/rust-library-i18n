//! Manipulació de cordes.
//!
//! Per obtenir més informació, consulteu el mòdul [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. fora dels límits
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. començar <=acabar
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. límit de caràcters
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // troba el personatge
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` ha de ser inferior a len i un límit char
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Retorna la longitud de `self`.
    ///
    /// Aquesta longitud és en bytes, no en [`char`] ni en grafemes.
    /// Dit d`una altra manera, potser no és el que un humà considera la longitud de la corda.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // fancy f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Retorna `true` si `self` té una longitud de zero bytes.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Comprova que `index`-th byte és el primer byte d'una seqüència de punts de codi UTF-8 o el final de la cadena.
    ///
    ///
    /// L'inici i el final de la cadena (quan es considera que `index== self.len()`) són límits.
    ///
    /// Retorna `false` si `index` és superior a `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // inici de `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // segon byte de `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // tercer byte de `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 i len sempre estan bé.
        // Feu una prova de 0 explícitament per tal que pugui optimitzar la comprovació fàcilment i ometeu la lectura de dades de cadenes per a aquest cas.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Això és una màgia de bits equivalent a: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Converteix un segment de cadena en un segment de bytes.
    /// Per tornar a convertir el segment de bytes en un segment de cadena, utilitzeu la funció [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SEGURETAT: so constant perquè transmutem dos tipus amb el mateix disseny
        unsafe { mem::transmute(self) }
    }

    /// Converteix un segment de cadena mutable en un segment de byte mutable.
    ///
    /// # Safety
    ///
    /// La persona que truca ha de garantir que el contingut de la secció sigui vàlid UTF-8 abans que finalitzi el préstec i s'utilitzi l `str` subjacent.
    ///
    ///
    /// L'ús d'un `str` el contingut del qual no és vàlid UTF-8 té un comportament indefinit.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SEGURETAT: el repartiment de `&str` a `&[u8]` és segur des de `str`
        // té el mateix disseny que `&[u8]` (només libstd pot fer aquesta garantia).
        // La desreferència del punter és segura, ja que prové d'una referència mutable que es garanteix que és vàlida per a les escriptures.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Converteix un segment de cadena en un punter en brut.
    ///
    /// Com que les llesques de cadena són una llesca de bytes, el punter en brut apunta a un [`u8`].
    /// Aquest punter assenyalarà el primer byte de la secció de cadena.
    ///
    /// La persona que truca ha de garantir que mai no s`escrigui el punter retornat.
    /// Si necessiteu mutar el contingut de la secció de cadena, utilitzeu [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Converteix un segment de cadena mutable en un punter en brut.
    ///
    /// Com que les llesques de cadena són una llesca de bytes, el punter en brut apunta a un [`u8`].
    /// Aquest punter assenyalarà el primer byte de la secció de cadena.
    ///
    /// És responsabilitat vostra assegurar-vos que la secció de cadena només es modifiqui de manera que sigui vàlida UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Retorna una subslice de `str`.
    ///
    /// Aquesta és l`alternativa sense pànic a la indexació del `str`.
    /// Retorna [`None`] sempre que l'operació d'indexació equivalent seria panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // índexs no als límits de la seqüència UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // fora dels límits
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Retorna un subslice mutable de `str`.
    ///
    /// Aquesta és l`alternativa sense pànic a la indexació del `str`.
    /// Retorna [`None`] sempre que l'operació d'indexació equivalent seria panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // longitud correcta
    /// assert!(v.get_mut(0..5).is_some());
    /// // fora dels límits
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Retorna una subdivisió no verificada de `str`.
    ///
    /// Aquesta és l'alternativa no marcada a la indexació del `str`.
    ///
    /// # Safety
    ///
    /// Els trucadors d'aquesta funció són responsables que es compleixin aquestes condicions prèvies:
    ///
    /// * L`índex inicial no ha de superar l`índex final;
    /// * Els índexs han d'estar dins dels límits de la part original;
    /// * Els índexs han de situar-se als límits de la seqüència UTF-8.
    ///
    /// Si no ho feu, el segment de cadena retornat pot fer referència a memòria no vàlida o infringir els invariants comunicats pel tipus `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `get_unchecked`;
        // la part no es pot referenciar perquè `self` és una referència segura.
        // El punter retornat és segur perquè les aplicacions de `SliceIndex` han de garantir-ho.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Retorna un subslice mutable i sense verificar de `str`.
    ///
    /// Aquesta és l'alternativa no marcada a la indexació del `str`.
    ///
    /// # Safety
    ///
    /// Els trucadors d'aquesta funció són responsables que es compleixin aquestes condicions prèvies:
    ///
    /// * L`índex inicial no ha de superar l`índex final;
    /// * Els índexs han d'estar dins dels límits de la part original;
    /// * Els índexs han de situar-se als límits de la seqüència UTF-8.
    ///
    /// Si no ho feu, el segment de cadena retornat pot fer referència a memòria no vàlida o infringir els invariants comunicats pel tipus `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `get_unchecked_mut`;
        // la part no es pot referenciar perquè `self` és una referència segura.
        // El punter retornat és segur perquè les aplicacions de `SliceIndex` han de garantir-ho.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Crea una secció de cadena a partir d'una altra secció de cadena, ignorant les comprovacions de seguretat.
    ///
    /// Això generalment no es recomana, utilitzeu-ho amb precaució.Per obtenir una alternativa segura, consulteu [`str`] i [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Aquesta nova part va de `begin` a `end`, inclòs `begin`, però excloent `end`.
    ///
    /// Per obtenir una secció de cadena mutable, consulteu el mètode [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Les persones que truquen a aquesta funció són responsables que es compleixin tres condicions prèvies:
    ///
    /// * `begin` no pot superar `end`.
    /// * `begin` i `end` han de ser posicions de bytes dins de la secció de cadena.
    /// * `begin` i `end` ha de situar-se als límits de la seqüència UTF-8.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `get_unchecked`;
        // la part no es pot referenciar perquè `self` és una referència segura.
        // El punter retornat és segur perquè les aplicacions de `SliceIndex` han de garantir-ho.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Crea una secció de cadena a partir d'una altra secció de cadena, ignorant les comprovacions de seguretat.
    /// Això generalment no es recomana, utilitzeu-ho amb precaució.Per obtenir una alternativa segura, consulteu [`str`] i [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Aquesta nova part va de `begin` a `end`, inclòs `begin`, però excloent `end`.
    ///
    /// Per obtenir una secció de cadena immutable, consulteu el mètode [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Les persones que truquen a aquesta funció són responsables que es compleixin tres condicions prèvies:
    ///
    /// * `begin` no pot superar `end`.
    /// * `begin` i `end` han de ser posicions de bytes dins de la secció de cadena.
    /// * `begin` i `end` ha de situar-se als límits de la seqüència UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // SEGURETAT: la persona que truca ha de mantenir el contracte de seguretat per a `get_unchecked_mut`;
        // la part no es pot referenciar perquè `self` és una referència segura.
        // El punter retornat és segur perquè les aplicacions de `SliceIndex` han de garantir-ho.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Divideix un segment de cadena en dos en un índex.
    ///
    /// L'argument, `mid`, hauria de ser un desplaçament de bytes des de l'inici de la cadena.
    /// També ha d`estar al límit d`un punt de codi UTF-8.
    ///
    /// Les dues llesques retornades van des de l'inici de la secció de cadena fins a `mid` i de `mid` fins al final de la secció de cadena.
    ///
    /// Per obtenir llesques de cadena mutables, consulteu el mètode [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics si `mid` no es troba en un límit de punt de codi UTF-8 o si ha passat el final de l'últim punt de codi de la secció de cadena.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary comprova que l'índex es troba a [0, .len()]
        if self.is_char_boundary(mid) {
            // SEGURETAT: acaba de comprovar que `mid` es troba en un límit de caràcters.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Divideix un segment de cadena mutable en dos en un índex.
    ///
    /// L'argument, `mid`, hauria de ser un desplaçament de bytes des de l'inici de la cadena.
    /// També ha d`estar al límit d`un punt de codi UTF-8.
    ///
    /// Les dues llesques retornades van des de l'inici de la secció de cadena fins a `mid` i de `mid` fins al final de la secció de cadena.
    ///
    /// Per obtenir llesques de cadena immutables, consulteu el mètode [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics si `mid` no es troba en un límit de punt de codi UTF-8 o si ha passat el final de l'últim punt de codi de la secció de cadena.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary comprova que l'índex es troba a [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SEGURETAT: acaba de comprovar que `mid` es troba en un límit de caràcters.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Retorna un iterador sobre el [`char`] s d'un segment de cadena.
    ///
    /// Com que un segment de cadena consta de UTF-8 vàlid, podem iterar a través d'un segment de cadena per [`char`].
    /// Aquest mètode retorna aquest iterador.
    ///
    /// És important recordar que [`char`] representa un valor escalar Unicode i pot no coincidir amb la vostra idea del que és un 'character'.
    ///
    /// La iteració sobre clústers de grafemes pot ser el que realment voleu.
    /// Aquesta funcionalitat no la proporciona la biblioteca estàndard de Rust, comproveu crates.io.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Recordeu, és possible que [`char`] s no coincideixi amb la vostra intuïció sobre els personatges:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // no 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Retorna un iterador sobre el [`char`] s d'un segment de cadena i les seves posicions.
    ///
    /// Com que un segment de cadena consta de UTF-8 vàlid, podem iterar a través d'un segment de cadena per [`char`].
    /// Aquest mètode retorna un iterador tant d'aquests [`char`], com de les seves posicions de bytes.
    ///
    /// L'iterador produeix tuples.La posició és primera, el [`char`] és segon.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Recordeu, és possible que [`char`] s no coincideixi amb la vostra intuïció sobre els personatges:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // no (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // tingueu en compte el 3 aquí, l'últim personatge ocupava dos bytes
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Un iterador sobre els bytes d'un segment de cadena.
    ///
    /// Com que una llesca de cadena consisteix en una seqüència de bytes, podem fer una iteració a través d`una secció de cadena per bytes.
    /// Aquest mètode retorna aquest iterador.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Divideix un segment de cadena per espais en blanc.
    ///
    /// L'iterador retornat retornarà les llesques de cadena que siguin subdivisions de la secció de cadena original, separades per qualsevol quantitat d'espai en blanc.
    ///
    ///
    /// 'Whitespace' es defineix d'acord amb els termes de la propietat bàsica derivada d'Unicode `White_Space`.
    /// Si només voleu dividir en espais en blanc ASCII, utilitzeu [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Es consideren tot tipus d`espais en blanc:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Divideix un segment de cadena per espais en blanc ASCII.
    ///
    /// L'iterador retornat retornarà les llesques de cadena que siguin subdivisions de la secció de cadena original, separades per qualsevol quantitat d'espai en blanc ASCII.
    ///
    ///
    /// Per dividir-lo per Unicode `Whitespace`, utilitzeu [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Es consideren tot tipus d'espais en blanc ASCII:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Un iterador sobre les línies d'una cadena, com a talls de cadena.
    ///
    /// Les línies es finalitzen amb una nova línia (`\n`) o amb un retorn de carro amb una alimentació de línia (`\r\n`).
    ///
    /// El final de línia final és opcional.
    /// Una cadena que acaba amb un final de línia final retornarà les mateixes línies que una cadena idèntica d'una altra manera sense un final de línia final.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// El final de línia final no és obligatori:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Un iterador sobre les línies d'una cadena.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Retorna un iterador de `u16` sobre la cadena codificada com a UTF-16.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Retorna `true` si el patró donat coincideix amb una subdivisió d'aquest segment de cadena.
    ///
    /// Retorna `false` si no ho fa.
    ///
    /// El [pattern] pot ser un `&str`, [`char`], una porció de [`char`] s, o una funció o tancament que determini si coincideix un caràcter.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Retorna `true` si el patró donat coincideix amb un prefix d'aquest segment de cadena.
    ///
    /// Retorna `false` si no ho fa.
    ///
    /// El [pattern] pot ser un `&str`, [`char`], una porció de [`char`] s, o una funció o tancament que determini si coincideix un caràcter.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Retorna `true` si el patró donat coincideix amb un sufix d'aquest segment de cadena.
    ///
    /// Retorna `false` si no ho fa.
    ///
    /// El [pattern] pot ser un `&str`, [`char`], una porció de [`char`] s, o una funció o tancament que determini si coincideix un caràcter.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Retorna l'índex de bytes del primer caràcter d'aquest segment de cadena que coincideix amb el patró.
    ///
    /// Retorna [`None`] si el patró no coincideix.
    ///
    /// El [pattern] pot ser un `&str`, [`char`], una porció de [`char`] s, o una funció o tancament que determini si coincideix un caràcter.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Patrons simples:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Patrons més complexos que fan servir estils i tancaments sense punts:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// No trobar el patró:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Retorna l'índex de bytes del primer caràcter de la coincidència més dreta del patró en aquest segment de cadena.
    ///
    /// Retorna [`None`] si el patró no coincideix.
    ///
    /// El [pattern] pot ser un `&str`, [`char`], una porció de [`char`] s, o una funció o tancament que determini si coincideix un caràcter.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Patrons simples:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Patrons més complexos amb tancaments:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// No trobar el patró:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Un iterador sobre les subcadenes d`aquest segment de cadena, separat per caràcters coincidents amb un patró.
    ///
    /// El [pattern] pot ser un `&str`, [`char`], una porció de [`char`] s, o una funció o tancament que determini si coincideix un caràcter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportament iterador
    ///
    /// L'iterador retornat serà un [`DoubleEndedIterator`] si el patró permet una cerca inversa i la cerca forward/reverse produeix els mateixos elements.
    /// Això és cert per, per exemple, [`char`], però no per a `&str`.
    ///
    /// Si el patró permet una cerca inversa, però els seus resultats poden diferir d'una cerca directa, es pot utilitzar el mètode [`rsplit`].
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Patrons simples:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Si el patró és un segment de caràcters, es divideix en cada ocurrència de qualsevol dels caràcters:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Un patró més complex, amb un tancament:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Si una cadena conté diversos separadors contigus, acabareu amb cadenes buides a la sortida:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Els separadors contigus estan separats per la cadena buida.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Els separadors al començament o al final d'una cadena estan veïnats per cadenes buides.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Quan s`utilitza la cadena buida com a separador, separa tots els caràcters de la cadena, juntament amb el principi i el final de la cadena.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Els separadors contigus poden provocar un comportament sorprenent quan s`utilitza l`espai en blanc com a separador.Aquest codi és correcte:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// _not_ us proporciona:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Utilitzeu [`split_whitespace`] per a aquest comportament.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Un iterador sobre les subcadenes d`aquest segment de cadena, separat per caràcters coincidents amb un patró.
    /// Es diferencia de l'iterador produït per `split` perquè `split_inclusive` deixa la peça coincident com a terminador de la subcadena.
    ///
    ///
    /// El [pattern] pot ser un `&str`, [`char`], una porció de [`char`] s, o una funció o tancament que determini si coincideix un caràcter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Si coincideix l'últim element de la cadena, aquest element es considerarà el terminador de la subcadena anterior.
    /// Aquesta subcadena serà l'últim element retornat per l'iterador.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Un iterador sobre les subcadenes de la secció de cadena donada, separada per caràcters coincidents amb un patró i cedits en ordre invers.
    ///
    /// El [pattern] pot ser un `&str`, [`char`], una porció de [`char`] s, o una funció o tancament que determini si coincideix un caràcter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportament iterador
    ///
    /// L'iterador retornat requereix que el patró admeti una cerca inversa i serà un [`DoubleEndedIterator`] si una cerca forward/reverse produeix els mateixos elements.
    ///
    ///
    /// Per a la iteració frontal, es pot utilitzar el mètode [`split`].
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Patrons simples:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Un patró més complex, amb un tancament:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Un iterador sobre les subcadenes del segment de cadena donat, separat per caràcters coincidents amb un patró.
    ///
    /// El [pattern] pot ser un `&str`, [`char`], una porció de [`char`] s, o una funció o tancament que determini si coincideix un caràcter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Equival a [`split`], excepte que la cadena final se salta si està buida.
    ///
    /// [`split`]: str::split
    ///
    /// Aquest mètode es pot utilitzar per a dades de cadena que són _terminated_, en lloc de _separated_ per un patró.
    ///
    /// # Comportament iterador
    ///
    /// L'iterador retornat serà un [`DoubleEndedIterator`] si el patró permet una cerca inversa i la cerca forward/reverse produeix els mateixos elements.
    /// Això és cert per, per exemple, [`char`], però no per a `&str`.
    ///
    /// Si el patró permet una cerca inversa, però els seus resultats poden diferir d'una cerca directa, es pot utilitzar el mètode [`rsplit_terminator`].
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Un iterador sobre les subcadenes de `self`, separat per caràcters que coincideixen amb un patró i que es produeix en ordre invers.
    ///
    /// El [pattern] pot ser un `&str`, [`char`], una porció de [`char`] s, o una funció o tancament que determini si coincideix un caràcter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Equival a [`split`], excepte que la cadena final se salta si està buida.
    ///
    /// [`split`]: str::split
    ///
    /// Aquest mètode es pot utilitzar per a dades de cadena que són _terminated_, en lloc de _separated_ per un patró.
    ///
    /// # Comportament iterador
    ///
    /// L'iterador retornat requereix que el patró admeti una cerca inversa i tindrà un doble final si una cerca forward/reverse produeix els mateixos elements.
    ///
    ///
    /// Per a la iteració frontal, es pot utilitzar el mètode [`split_terminator`].
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Un iterador sobre les subcadenes del segment de cadena donat, separat per un patró, restringit a retornar com a màxim elements `n`.
    ///
    /// Si es retornen les subcadenes `n`, l'última subcadena (la cadena `n`a) contindrà la resta de la cadena.
    ///
    /// El [pattern] pot ser un `&str`, [`char`], una porció de [`char`] s, o una funció o tancament que determini si coincideix un caràcter.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportament iterador
    ///
    /// L'iterador retornat no tindrà una doble finalitat perquè no és eficient de suportar.
    ///
    /// Si el patró permet fer una cerca inversa, es pot utilitzar el mètode [`rsplitn`].
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Patrons simples:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Un patró més complex, amb un tancament:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Un iterador sobre les subcadenes d'aquest segment de cadena, separat per un patró, començant des del final de la cadena, restringit a retornar com a màxim elements `n`.
    ///
    ///
    /// Si es retornen les subcadenes `n`, l'última subcadena (la cadena `n`a) contindrà la resta de la cadena.
    ///
    /// El [pattern] pot ser un `&str`, [`char`], una porció de [`char`] s, o una funció o tancament que determini si coincideix un caràcter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportament iterador
    ///
    /// L'iterador retornat no tindrà una doble finalitat perquè no és eficient de suportar.
    ///
    /// Per dividir des de la part frontal, es pot utilitzar el mètode [`splitn`].
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Patrons simples:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Un patró més complex, amb un tancament:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Divideix la cadena en la primera aparició del delimitador especificat i retorna el prefix abans del delimitador i el sufix després del delimitador.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Divideix la cadena de l'última aparició del delimitador especificat i retorna el prefix abans del delimitador i el sufix després del delimitador.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Un iterador sobre les coincidències disjuntes d'un patró dins del segment de cadena donat.
    ///
    /// El [pattern] pot ser un `&str`, [`char`], una porció de [`char`] s, o una funció o tancament que determini si coincideix un caràcter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportament iterador
    ///
    /// L'iterador retornat serà un [`DoubleEndedIterator`] si el patró permet una cerca inversa i la cerca forward/reverse produeix els mateixos elements.
    /// Això és cert per, per exemple, [`char`], però no per a `&str`.
    ///
    /// Si el patró permet una cerca inversa, però els seus resultats poden diferir d'una cerca directa, es pot utilitzar el mètode [`rmatches`].
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Un iterador sobre les coincidències disjuntes d'un patró dins d'aquest segment de cadena, es va produir en ordre invers.
    ///
    /// El [pattern] pot ser un `&str`, [`char`], una porció de [`char`] s, o una funció o tancament que determini si coincideix un caràcter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportament iterador
    ///
    /// L'iterador retornat requereix que el patró admeti una cerca inversa i serà un [`DoubleEndedIterator`] si una cerca forward/reverse produeix els mateixos elements.
    ///
    ///
    /// Per a la iteració frontal, es pot utilitzar el mètode [`matches`].
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Un iterador sobre les coincidències disjuntes d'un patró dins d'aquest segment de cadena, així com l'índex en què comença la coincidència.
    ///
    /// Per a les coincidències de `pat` dins de `self` que es superposen, només es retornen els índexs corresponents a la primera coincidència.
    ///
    /// El [pattern] pot ser un `&str`, [`char`], una porció de [`char`] s, o una funció o tancament que determini si coincideix un caràcter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportament iterador
    ///
    /// L'iterador retornat serà un [`DoubleEndedIterator`] si el patró permet una cerca inversa i la cerca forward/reverse produeix els mateixos elements.
    /// Això és cert per, per exemple, [`char`], però no per a `&str`.
    ///
    /// Si el patró permet una cerca inversa, però els seus resultats poden diferir d'una cerca directa, es pot utilitzar el mètode [`rmatch_indices`].
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // només el primer `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Un iterador sobre les coincidències disjuntes d'un patró dins de `self`, es va produir en ordre invers juntament amb l'índex de la coincidència.
    ///
    /// Per a les coincidències de `pat` dins de `self` que es superposen, només es retornen els índexs corresponents a l'última coincidència.
    ///
    /// El [pattern] pot ser un `&str`, [`char`], una porció de [`char`] s, o una funció o tancament que determini si coincideix un caràcter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportament iterador
    ///
    /// L'iterador retornat requereix que el patró admeti una cerca inversa i serà un [`DoubleEndedIterator`] si una cerca forward/reverse produeix els mateixos elements.
    ///
    ///
    /// Per a la iteració frontal, es pot utilitzar el mètode [`match_indices`].
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // només l'últim `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Retorna una secció de cadena amb l'espai en blanc principal i final eliminat.
    ///
    /// 'Whitespace' es defineix d'acord amb els termes de la propietat bàsica derivada d'Unicode `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Retorna una secció de cadena amb l'espai en blanc principal eliminat.
    ///
    /// 'Whitespace' es defineix d'acord amb els termes de la propietat bàsica derivada d'Unicode `White_Space`.
    ///
    /// # Direccionalitat del text
    ///
    /// Una cadena és una seqüència de bytes.
    /// `start` en aquest context significa la primera posició d'aquesta cadena de bytes;per a un idioma d`esquerra a dreta com l`anglès o el rus, aquest serà el costat esquerre i, per als idiomes de dreta a esquerra com l`àrab o l`hebreu, aquest serà el costat dret.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Retorna un segment de cadena amb l'espai en blanc eliminat.
    ///
    /// 'Whitespace' es defineix d'acord amb els termes de la propietat bàsica derivada d'Unicode `White_Space`.
    ///
    /// # Direccionalitat del text
    ///
    /// Una cadena és una seqüència de bytes.
    /// `end` en aquest context significa l'última posició d'aquesta cadena de bytes;per a un idioma d`esquerra a dreta com l`anglès o el rus, aquest serà el costat dret i, per als idiomes de dreta a esquerra com l`àrab o l`hebreu, aquest serà el costat esquerre.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Retorna una secció de cadena amb l'espai en blanc principal eliminat.
    ///
    /// 'Whitespace' es defineix d'acord amb els termes de la propietat bàsica derivada d'Unicode `White_Space`.
    ///
    /// # Direccionalitat del text
    ///
    /// Una cadena és una seqüència de bytes.
    /// 'Left' en aquest context significa la primera posició d'aquesta cadena de bytes;per a un idioma com l'àrab o l'hebreu que són de "dreta a esquerra" en lloc de "d'esquerra a dreta", aquest serà el costat _right_, no l'esquerra.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Retorna un segment de cadena amb l'espai en blanc eliminat.
    ///
    /// 'Whitespace' es defineix d'acord amb els termes de la propietat bàsica derivada d'Unicode `White_Space`.
    ///
    /// # Direccionalitat del text
    ///
    /// Una cadena és una seqüència de bytes.
    /// 'Right' en aquest context significa l'última posició d'aquesta cadena de bytes;per a un idioma com l'àrab o l'hebreu que són de "dreta a esquerra" en lloc de "d'esquerra a dreta", aquest serà el costat _left_, no el dret.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Retorna una secció de cadena amb tots els prefixos i sufixos que coincideixen amb un patró eliminat repetidament.
    ///
    /// El [pattern] pot ser un [`char`], una porció de [`char`] s, o una funció o tancament que determina si coincideix un caràcter.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Patrons simples:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Un patró més complex, amb un tancament:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Recordeu la primera coincidència coneguda, corregiu-la a continuació si
            // l'últim partit és diferent
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SEGURETAT: se sap que `Searcher` retorna índexs vàlids.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Retorna una secció de cadena amb tots els prefixos que coincideixen amb un patró eliminat repetidament.
    ///
    /// El [pattern] pot ser un `&str`, [`char`], una porció de [`char`] s, o una funció o tancament que determini si coincideix un caràcter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Direccionalitat del text
    ///
    /// Una cadena és una seqüència de bytes.
    /// `start` en aquest context significa la primera posició d'aquesta cadena de bytes;per a un idioma d`esquerra a dreta com l`anglès o el rus, aquest serà el costat esquerre i, per als idiomes de dreta a esquerra com l`àrab o l`hebreu, aquest serà el costat dret.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SEGURETAT: se sap que `Searcher` retorna índexs vàlids.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Retorna una secció de cadena amb el prefix eliminat.
    ///
    /// Si la cadena comença amb el patró `prefix`, retorna la subcadena després del prefix, embolicada en `Some`.
    /// A diferència de `trim_start_matches`, aquest mètode elimina el prefix exactament una vegada.
    ///
    /// Si la cadena no comença amb `prefix`, retorna `None`.
    ///
    /// El [pattern] pot ser un `&str`, [`char`], una porció de [`char`] s, o una funció o tancament que determini si coincideix un caràcter.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Retorna una secció de cadena amb el sufix eliminat.
    ///
    /// Si la cadena acaba amb el patró `suffix`, retorna la subcadena abans del sufix, embolicada en `Some`.
    /// A diferència de `trim_end_matches`, aquest mètode elimina el sufix exactament una vegada.
    ///
    /// Si la cadena no acaba amb `suffix`, retorna `None`.
    ///
    /// El [pattern] pot ser un `&str`, [`char`], una porció de [`char`] s, o una funció o tancament que determini si coincideix un caràcter.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Retorna una secció de cadena amb tots els sufixos que coincideixen amb un patró eliminat repetidament.
    ///
    /// El [pattern] pot ser un `&str`, [`char`], una porció de [`char`] s, o una funció o tancament que determini si coincideix un caràcter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Direccionalitat del text
    ///
    /// Una cadena és una seqüència de bytes.
    /// `end` en aquest context significa l'última posició d'aquesta cadena de bytes;per a un idioma d`esquerra a dreta com l`anglès o el rus, aquest serà el costat dret i, per als idiomes de dreta a esquerra com l`àrab o l`hebreu, aquest serà el costat esquerre.
    ///
    ///
    /// # Examples
    ///
    /// Patrons simples:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Un patró més complex, amb un tancament:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SEGURETAT: se sap que `Searcher` retorna índexs vàlids.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Retorna una secció de cadena amb tots els prefixos que coincideixen amb un patró eliminat repetidament.
    ///
    /// El [pattern] pot ser un `&str`, [`char`], una porció de [`char`] s, o una funció o tancament que determini si coincideix un caràcter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Direccionalitat del text
    ///
    /// Una cadena és una seqüència de bytes.
    /// 'Left' en aquest context significa la primera posició d'aquesta cadena de bytes;per a un idioma com l'àrab o l'hebreu que són de "dreta a esquerra" en lloc de "d'esquerra a dreta", aquest serà el costat _right_, no l'esquerra.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Retorna una secció de cadena amb tots els sufixos que coincideixen amb un patró eliminat repetidament.
    ///
    /// El [pattern] pot ser un `&str`, [`char`], una porció de [`char`] s, o una funció o tancament que determini si coincideix un caràcter.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Direccionalitat del text
    ///
    /// Una cadena és una seqüència de bytes.
    /// 'Right' en aquest context significa l'última posició d'aquesta cadena de bytes;per a un idioma com l'àrab o l'hebreu que són de "dreta a esquerra" en lloc de "d'esquerra a dreta", aquest serà el costat _left_, no el dret.
    ///
    ///
    /// # Examples
    ///
    /// Patrons simples:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Un patró més complex, amb un tancament:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Analitza aquest segment de cadena en un altre tipus.
    ///
    /// Com que `parse` és tan general, pot causar problemes amb la inferència de tipus.
    /// Com a tal, `parse` és una de les poques vegades que veureu la sintaxi afectuosament coneguda com 'turbofish': `::<>`.
    ///
    /// Això ajuda l'algorisme d'inferència a entendre específicament de quin tipus intenteu analitzar.
    ///
    /// `parse` pot analitzar qualsevol tipus que implementi el [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Tornarà [`Err`] si no és possible analitzar aquest segment de cadena en el tipus desitjat.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Ús bàsic
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Utilitzant l 'turbofish' en lloc d'anotar `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// No s'ha pogut analitzar:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Comprova si tots els caràcters d'aquesta cadena es troben dins de l'interval ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Aquí podem tractar cada byte com a caràcter: tots els caràcters multibyte comencen amb un byte que no es troba en el rang ascii, de manera que ja ens detindrem aquí.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Comprova que dues cadenes no coincideixin amb majúscules i minúscules ASCII.
    ///
    /// Igual que `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, però sense assignar ni copiar temporals.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Converteix aquesta cadena al seu equivalent en majúscules ASCII.
    ///
    /// Les lletres ASCII 'a' a 'z' s`assignen a 'A' a 'Z', però les lletres que no són ASCII no canvien.
    ///
    /// Per retornar un valor en majúscula nou sense modificar-ne l'existent, utilitzeu [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // SEGURETAT: segur perquè transmutem dos tipus amb el mateix disseny.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Converteix aquesta cadena al seu equivalent en minúscules ASCII.
    ///
    /// Les lletres ASCII 'A' a 'Z' s`assignen a 'a' a 'z', però les lletres que no són ASCII no canvien.
    ///
    /// Per tornar un valor en minúscula nou sense modificar-ne l'existent, utilitzeu [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // SEGURETAT: segur perquè transmutem dos tipus amb el mateix disseny.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Torneu un iterador que s'escapi de cada caràcter de `self` amb [`char::escape_debug`].
    ///
    ///
    /// Note: només s`escaparan els punts de codi de grafema ampliats que comencen la cadena.
    ///
    /// # Examples
    ///
    /// Com a iterador:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilitzant `println!` directament:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Tots dos són equivalents a:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Utilitzant `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Torneu un iterador que s'escapi de cada caràcter de `self` amb [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Com a iterador:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilitzant `println!` directament:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Tots dos són equivalents a:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Utilitzant `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Torneu un iterador que s'escapi de cada caràcter de `self` amb [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Com a iterador:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilitzant `println!` directament:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Tots dos són equivalents a:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Utilitzant `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Crea un fitxer buit
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Crea un fitxer mutable buit
    #[inline]
    fn default() -> Self {
        // SEGURETAT: la cadena buida és vàlida UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Un tipus fn denominable i clonable
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // SEGURETAT: no és segur
        unsafe { from_utf8_unchecked(bytes) }
    };
}