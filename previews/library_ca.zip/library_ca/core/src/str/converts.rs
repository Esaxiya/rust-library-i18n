//! Maneres de crear un `str` a partir de la divisió de bytes.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Converteix un segment de bytes en un segment de cadena.
///
/// Un tall de cadena ([`&str`]) està format per bytes ([`u8`]) i un tall de bytes ([`&[u8]`][byteslice]) està format per bytes, de manera que aquesta funció converteix els dos.
/// No tots els talls de bytes són talls de cadena vàlids, però: [`&str`] requereix que sigui UTF-8 vàlid.
/// `from_utf8()` comprova que els bytes són UTF-8 vàlids i, a continuació, fa la conversió.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Si esteu segur que la secció de bytes és vàlida UTF-8 i no voleu incórrer en la sobrecàrrega de la comprovació de validesa, hi ha una versió no segura d'aquesta funció, [`from_utf8_unchecked`], que té el mateix comportament, però omet la comprovació.
///
///
/// Si necessiteu un `String` en lloc d`un `&str`, tingueu en compte el [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Com que podeu assignar un `[u8; N]` en pila i en podeu prendre un [`&[u8]`][byteslice], aquesta funció és una manera de tenir una cadena assignada en pila.Hi ha un exemple d'això a la secció d'exemples següent.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Retorna `Err` si el segment no és UTF-8 amb una descripció de per què el segment proporcionat no és UTF-8.
///
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// use std::str;
///
/// // alguns bytes, en un vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Sabem que aquests bytes són vàlids, així que només cal que utilitzeu `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Bytes incorrectes:
///
/// ```
/// use std::str;
///
/// // alguns bytes no vàlids, en un vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Consulteu els documents de [`Utf8Error`] per obtenir més informació sobre els tipus d`errors que es poden retornar.
///
/// Un "stack allocated string":
///
/// ```
/// use std::str;
///
/// // alguns bytes, en una matriu assignada a la pila
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Sabem que aquests bytes són vàlids, així que només cal que utilitzeu `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SEGURETAT: només heu executat la validació.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Converteix un segment de bytes mutable en un segment de cadena mutable.
///
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" com a vector mutable
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Com sabem, aquests bytes són vàlids, podem utilitzar `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Bytes incorrectes:
///
/// ```
/// use std::str;
///
/// // Alguns bytes no vàlids en un vector mutable
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Consulteu els documents de [`Utf8Error`] per obtenir més informació sobre els tipus d`errors que es poden retornar.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SEGURETAT: només heu executat la validació.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Converteix un segment de bytes en un segment de cadena sense comprovar que la cadena conté UTF-8 vàlid.
///
/// Consulteu la versió segura, [`from_utf8`], per obtenir més informació.
///
/// # Safety
///
/// Aquesta funció no és segura perquè no comprova que els bytes que se li passen siguin vàlids UTF-8.
/// Si es infringeix aquesta restricció, es produeix un comportament indefinit, ja que la resta de Rust assumeix que [`&str`] s són UTF-8 vàlids.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// use std::str;
///
/// // alguns bytes, en un vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SEGURETAT: la persona que truca ha de garantir que els bytes `v` són vàlids UTF-8.
    // També es basa en que `&str` i `&[u8]` tinguin el mateix disseny.
    unsafe { mem::transmute(v) }
}

/// Converteix un segment de bytes en un segment de cadena sense comprovar que la cadena conté UTF-8 vàlid;versió mutable.
///
///
/// Consulteu la versió immutable, [`from_utf8_unchecked()`] per obtenir més informació.
///
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SEGURETAT: la persona que truca ha de garantir que els bytes `v`
    // són vàlids UTF-8, per tant, la transmissió a `*mut str` és segura.
    // A més, la desferència del punter és segura perquè aquest punter prové d'una referència que es garanteix que és vàlida per a les escriptures.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}