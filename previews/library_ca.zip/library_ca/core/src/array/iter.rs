//! Defineix l'iterador propietat de `IntoIter` per a matrius.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Un iterador [array] per valor.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Aquesta és la matriu que estem iterant.
    ///
    /// Elements amb índex `i` en què encara no s'ha produït `alive.start <= i < alive.end` i són entrades de matriu vàlides.
    /// Els elements amb índexs `i < alive.start` o `i >= alive.end` ja s`han produït i ja no s`hi pot accedir.Aquests elements morts poden fins i tot estar en un estat completament no inicialitzat.
    ///
    ///
    /// Per tant, els invariants són:
    /// - `data[alive]` està viu (és a dir, conté elements vàlids)
    /// - `data[..alive.start]` i `data[alive.end..]` han mort (és a dir, els elements ja estaven llegits i ja no s'han de tocar!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Els elements de `data` que encara no s`han cedit.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Crea un iterador nou sobre el `array` donat.
    ///
    /// *Nota*: aquest mètode podria quedar obsolet a future, després de [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // El tipus de `value` és un `i32` aquí, en lloc de `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SEGURETAT: el transmutat aquí és realment segur.Els documents de `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` es garanteix que tindrà la mateixa mida i alineació
        // > com `T`.
        //
        // Els documents fins i tot mostren un transmutat des d`una matriu de `MaybeUninit<T>` a una matriu de `T`.
        //
        //
        // Amb això, aquesta inicialització satisfà els invariants.

        // FIXME(LukasKalbertodt): utilitzeu `mem::transmute` aquí, un cop funcioni amb const genèrics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Fins aleshores, podem utilitzar `mem::transmute_copy` per crear una còpia a mida com a tipus diferent i, a continuació, oblidar `array` perquè no es deixi caure.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Retorna una part immutable de tots els elements que encara no s'han cedit.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SEGURETAT: sabem que tots els elements de `alive` estan inicialitzats correctament.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Retorna un segment mutable de tots els elements que encara no s'han cedit.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SEGURETAT: sabem que tots els elements de `alive` estan inicialitzats correctament.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Obteniu el següent índex des de la part frontal.
        //
        // Augmentar `alive.start` en 1 manté la invariant respecte a `alive`.
        // Tanmateix, a causa d`aquest canvi, per poc temps, la zona viva ja no és `data[alive]`, sinó `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Llegiu l'element de la matriu.
            // SEGURETAT: `idx` és un índex de l'antiga regió "alive" del
            // matriu.Llegir aquest element significa que ara `data[idx]` es considera mort (és a dir, no el toqueu).
            // Com que `idx` va ser l'inici de la zona viva, la zona viva ara torna a ser `data[alive]`, restaurant tots els invariants.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Obteniu el següent índex de la part posterior.
        //
        // Disminuir `alive.end` en 1 manté la invariant respecte a `alive`.
        // Tanmateix, a causa d`aquest canvi, per poc temps, la zona viva ja no és `data[alive]`, sinó `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Llegiu l'element de la matriu.
            // SEGURETAT: `idx` és un índex de l'antiga regió "alive" del
            // matriu.Llegir aquest element significa que ara `data[idx]` es considera mort (és a dir, no el toqueu).
            // Com que `idx` era el final de la zona viva, la zona viva ara torna a ser `data[alive]`, restaurant tots els invariants.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SEGURETAT: és segur: `as_mut_slice` retorna exactament la sub-secció
        // d`elements que encara no s`han mogut i que queden per deixar caure.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Mai es desbordarà a causa de la invariant `vivo.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// De fet, l'iterador informa de la longitud correcta.
// El nombre d'elements "alive" (que encara es generaran) és la longitud de l'interval `alive`.
// Aquest rang es redueix en longitud tant a `next` com a `next_back`.
// Sempre es decrementa en 1 en aquests mètodes, però només si es retorna `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Tingueu en compte que no necessitem coincidir exactament amb el mateix interval viu, de manera que només podem clonar-lo en offset 0 independentment d`on estigui `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Clona tots els elements vius.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Escriviu un clon a la nova matriu i actualitzeu el seu interval viu.
            // Si cloneu panics, deixarem els elements anteriors correctament.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Imprimiu només els elements que encara no s'han cedit: ja no podem accedir als elements cedits.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}