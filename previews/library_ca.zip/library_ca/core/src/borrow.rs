//! Un mòdul per treballar amb dades manllevades.

#![stable(feature = "rust1", since = "1.0.0")]

/// Un trait per al préstec de dades.
///
/// A Rust, és habitual proporcionar diferents representacions d`un tipus per a diferents casos d`ús.
/// Per exemple, la ubicació i la gestió d'emmagatzematge d'un valor es poden triar específicament com a adequades per a un ús concret mitjançant tipus de punter com [`Box<T>`] o [`Rc<T>`].
/// Més enllà d`aquests embolcalls genèrics que es poden utilitzar amb qualsevol tipus, alguns tipus ofereixen facetes opcionals que ofereixen una funcionalitat potencialment costosa.
/// Un exemple per a aquest tipus és [`String`], que afegeix la possibilitat d'estendre una cadena al [`str`] bàsic.
/// Això requereix mantenir informació addicional innecessària per a una cadena senzilla i immutable.
///
/// Aquests tipus proporcionen accés a les dades subjacents mitjançant referències al tipus d`aquestes dades.Es diu que estan"prestats com" aquest tipus.
/// Per exemple, un [`Box<T>`] es pot demanar prestat com a `T` mentre que un [`String`] es pot demanar prestat com a `str`.
///
/// Els tipus expressen que es poden manllevar com a algun tipus `T` implementant `Borrow<T>`, proporcionant una referència a un `T` en el mètode [`borrow`] de trait.Un tipus es pot demanar prestat de forma gratuïta en diversos tipus diferents.
/// Si vol agafar préstecs mutables com a tipus, permetent modificar les dades subjacents, també pot implementar [`BorrowMut<T>`].
///
/// A més, quan es proporcionen implementacions per a traits addicionals, cal considerar si s`han de comportar idènticament als del tipus subjacent com a conseqüència d`actuar com a representació d`aquest tipus subjacent.
/// El codi genèric sol utilitzar `Borrow<T>` quan es basa en el comportament idèntic d`aquestes implementacions addicionals de trait.
/// Aquests traits probablement apareixeran com a trait bounds addicionals.
///
/// En particular, `Eq`, `Ord` i `Hash` han de ser equivalents per als valors de préstec i de propietat: `x.borrow() == y.borrow()` hauria de donar el mateix resultat que `x == y`.
///
/// Si el codi genèric només ha de funcionar per a tots els tipus que puguin proporcionar una referència al tipus relacionat `T`, sovint és millor utilitzar [`AsRef<T>`] ja que hi ha més tipus que el poden implementar amb seguretat.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Com a recopilació de dades, [`HashMap<K, V>`] posseeix claus i valors.Si les dades reals de la clau estan embolicades en un tipus de gestió d'algun tipus, no obstant això, hauria de ser possible cercar un valor mitjançant una referència a les dades de la clau.
/// Per exemple, si la clau és una cadena, és probable que s'emmagatzemi amb el mapa de hash com a [`String`], mentre que hauria de ser possible cercar amb un [`&str`][`str`].
/// Per tant, `insert` ha de funcionar amb un `String` mentre que `get` ha de poder utilitzar un `&str`.
///
/// Lleugerament simplificades, les parts rellevants de `HashMap<K, V>` tenen aquest aspecte:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // camps omesos
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Tot el mapa de hash és genèric sobre un tipus de clau `K`.Com que aquestes claus s`emmagatzemen amb el mapa de hash, aquest tipus ha de ser propietari de les dades de la clau.
/// En inserir un parell clau-valor, al mapa se li proporciona un `K` com aquest i ha de trobar el dipòsit de hash correcte i comprovar si la clau ja està present basant-se en aquest `K`.Per tant, requereix `K: Hash + Eq`.
///
/// Tanmateix, quan cerqueu un valor al mapa, haureu de proporcionar una referència a un `K`, ja que la clau per cercar hauria de crear sempre aquest valor de propietat.
/// Per a les claus de cadena, això significaria que cal crear un valor `String` només per a la cerca de casos en què només estigui disponible un `str`.
///
/// En canvi, el mètode `get` és genèric sobre el tipus de dades clau subjacent, anomenat `Q` a la signatura del mètode anterior.Indica que `K` manlleva com a `Q` en requerir-lo.
/// En requerir addicionalment `Q: Hash + Eq`, indica el requisit que `K` i `Q` tinguin implementacions de `Hash` i `Eq` traits que produeixin resultats idèntics.
///
/// La implementació de `get` es basa sobretot en implementacions idèntiques de `Hash` en determinar el dipòsit de hash de la clau trucant a `Hash::hash` al valor `Q` tot i que va inserir la clau basant-se en el valor de hash calculat a partir del valor `K`.
///
///
/// Com a conseqüència, el mapa de hash es trenca si un `K` que envolta un valor `Q` produeix un hash diferent de `Q`.Per exemple, imagineu-vos que teniu un tipus que envolta una cadena però que compara lletres ASCII ignorant el seu cas:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Com que dos valors iguals han de produir el mateix valor hash, la implementació de `Hash` també ha d`ignorar el cas ASCII:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Pot `CaseInsensitiveString` implementar `Borrow<str>`?Certament, pot proporcionar una referència a un segment de cadena mitjançant la seva cadena de propietat continguda.
/// Però com que la seva implementació `Hash` difereix, es comporta de manera diferent de `str` i, per tant, no ha d`implementar `Borrow<str>`.
/// Si vol permetre l'accés d'altres persones a l `str` subjacent, ho pot fer mitjançant `AsRef<str>`, que no comporta cap requisit addicional.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Préstecs immutables d'un valor de propietat.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// Un trait per demanar préstecs mutus.
///
/// Com a complement de [`Borrow<T>`], aquest trait permet que un tipus prengui préstecs com a tipus subjacent proporcionant una referència mutable.
/// Vegeu [`Borrow<T>`] per obtenir més informació sobre els préstecs com un altre tipus.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Endeutament mutu d'un valor de propietat.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}