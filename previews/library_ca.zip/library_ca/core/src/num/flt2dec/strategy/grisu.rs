//! Adaptació Rust de l'algorisme Grisu3 descrit a "Impressió de números de coma flotant de forma ràpida i precisa amb nombres enters" [^ 1].
//! Utilitza aproximadament 1 KB de taula precomputada i, al seu torn, és molt ràpid per a la majoria d`entrades.
//!
//! [^1]: Florian Loitsch.2010. Impressió de números de coma flotant ràpidament i
//!   amb precisió amb nombres enters.SIGPLAN No.45, 6 (juny de 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// vegeu els comentaris a `format_shortest_opt` per obtenir la justificació.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Donat `x > 0`, retorna `(k, 10^k)` tal que `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// La implementació del mode més curt per a Grisu.
///
/// Retorna `None` quan en cas contrari retornaria una representació inexacta.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // necessitem almenys tres bits de precisió addicional

    // comenceu pels valors normalitzats amb l'exponent compartit
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // trobeu qualsevol `cached = 10^minusk` tal que `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // com que `plus` està normalitzat, això significa `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // tenint en compte les nostres opcions de `ALPHA` i `GAMMA`, això posa `plus * cached` en `[4, 2^32)`.
    //
    // òbviament, és desitjable maximitzar `GAMMA - ALPHA`, de manera que no necessitem moltes potències emmagatzemades a la memòria cau de 10, però hi ha algunes consideracions:
    //
    //
    // 1. volem mantenir `floor(plus * cached)` dins de `u32`, ja que necessita una divisió costosa.
    //    (això no és realment evitable, es necessita resta per a l'estimació de la precisió.)
    // 2.
    // la resta de `floor(plus * cached)` es multiplica repetidament per 10 i no s'hauria de desbordar.
    //
    // el primer dóna `64 + GAMMA <= 32`, mentre que el segon dóna `10 * 2^-ALPHA <= 2^64`;
    // -60 i -32 és l'abast màxim amb aquesta restricció, i V8 també els utilitza.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // escala fps.això dóna l'error màxim d'1 ulp (demostrat a partir del teorema 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-interval real de menys
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // superior a `minus`, `v` i `plus` són aproximacions *quantitzades*(error <1 ulp).
    // com que no sabem que l'error és positiu o negatiu, fem servir dues aproximacions espaiades per igual i tenim l'error màxim de 2 ulpes.
    //
    // el "unsafe region" és un interval liberal que inicialment generem.
    // el "safe region" és un interval conservador que només acceptem.
    // Comencem amb la reproducció correcta dins de la regió no segura i intentem trobar la reproducció més propera a `v`, que també es troba dins de la regió segura.
    // si no podem, desistim.
    //
    let plus1 = plus.f + 1;
    // deixem plus0 = plus.f, 1;//només per a explicació, deixeu minus0 = minus.f + 1;//només per a explicació
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // exponent compartit

    // divideix `plus1` en parts fraccionades i integrals.
    // es garanteix que les parts integrals s`adapten a u32, ja que la potència emmagatzemada a la memòria cau garanteix `plus < 2^32` i `plus.f` normalitzat sempre és inferior a `2^64 - 2^4` a causa del requisit de precisió.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // calculeu el `10^max_kappa` més gran com a màxim `plus1` (per tant `plus1 < 10^(max_kappa+1)`).
    // aquest és un límit superior de `kappa` a continuació.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Teorema 6.2: si `k` és el màxim s enter
    // `0 <= y mod 10^k <= y - x`,              llavors `V = floor(y / 10^k) * 10^k` es troba a `[x, y]` i una de les representacions més curtes (amb el nombre mínim de dígits significatius) en aquest interval.
    //
    //
    // trobeu la longitud de dígits `kappa` entre `(minus1, plus1)` segons el teorema 6.2.
    // Es pot adoptar el teorema 6.2 per excloure `x` si es requereix `y mod 10^k < y - x`.
    // (per exemple, `x` =32000, `y` =32777; `kappa` =2 ja que `y mod 10 ^ 3=777 <y, x=777`.) l'algorisme es basa en la fase de verificació posterior per excloure `y`.
    //
    let delta1 = plus1 - minus1;
    // deixem delta1int=(delta1>> e) com a usize;//només per a explicació
    let delta1frac = delta1 & ((1 << e) - 1);

    // representar les parts integrals, mentre es comprova la precisió a cada pas.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // dígits encara per renderitzar
    loop {
        // sempre tenim com a mínim un dígit per representar, com a invariants `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (se segueix que `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // divideix `remainder` per `10^kappa`.tots dos estan escalats per `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; hem trobat el `kappa` correcte.
            let ten_kappa = (ten_kappa as u64) << e; // escala 10 ^ kappa de tornada a l'exponent compartit
            return round_and_weed(
                // SEGURETAT: vam inicialitzar aquesta memòria més amunt.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // trencar el bucle quan hem representat tots els dígits integrals.
        // el nombre exacte de dígits és `max_kappa + 1` com `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // restaurar invariants
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // representar parts fraccionades, mentre es comprova la precisió a cada pas.
    // aquesta vegada confiem en multiplicacions repetides, ja que la divisió perdrà la precisió.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // el següent dígit hauria de ser significatiu ja que ho hem provat abans de trencar invariants, on `m = max_kappa + 1` (nombre de dígits a la part integral):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // no desbordarà, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // divideix `remainder` per `10^kappa`.
        // tots dos estan escalats per `2^e / 10^kappa`, de manera que aquest últim està implícit aquí.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // divisor implícit
            return round_and_weed(
                // SEGURETAT: vam inicialitzar aquesta memòria més amunt.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // restaurar invariants
        kappa -= 1;
        remainder = r;
    }

    // hem generat tots els dígits significatius de `plus1`, però no estic segur de si és l'òptim.
    // per exemple, si `minus1` és 3,14153 ... i `plus1` és 3,14158 ..., hi ha 5 representacions més curtes diferents de 3.14154 a 3.14158, però només en tenim la més gran.
    // hem de reduir successivament l'últim dígit i comprovar si aquesta és la reproducció òptima.
    // hi ha com a màxim 9 candidats (..1 a ..9), de manera que és bastant ràpid.(Fase "rounding")
    //
    // la funció comprova si aquest "optimal" repr és realment dins dels rangs d'ulp i, a més, és possible que el "second-to-optimal" repr sigui realment òptim a causa de l'error d'arrodoniment.
    // en qualsevol dels dos casos, retorna `None`.
    // (Fase "weeding")
    //
    // tots els arguments aquí s`escalen pel valor comú (però implícit) `k`, de manera que:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (i també, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (i també, `threshold > plus1v` d'invariants anteriors)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // produeixen dues aproximacions a `v` (en realitat `plus1 - v`) dins de les ulpes 1.5.
        // la representació resultant ha de ser la representació més propera a totes dues.
        //
        // aquí s'utilitza `plus1 - v` ja que es fan càlculs respecte a `plus1` per evitar overflow/underflow (d'aquí els noms aparentment intercanviats).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // reduïu l'últim dígit i atureu-vos a la representació més propera a `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // treballem amb els dígits aproximats `w(n)`, que inicialment és igual a `plus1 - plus1 % 10^kappa`.després d'executar el cos del bucle `n` vegades, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // establim `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (per tant, `rest= plus1w(0)`) per simplificar les comprovacions.
            // tingueu en compte que `plus1w(n)` sempre augmenta.
            //
            // tenim tres condicions per acabar.qualsevol d'ells farà que el bucle no pugui continuar, però tenim almenys una representació vàlida que és la més propera a `v + 1 ulp`.
            // els designarem com a TC1 a TC3 per brevetat.
            //
            // TC1: `w(n) <= v + 1 ulp`, és a dir, aquesta és la darrera reproducció que pot ser la més propera.
            // això equival a `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // combinat amb TC2 (que comprova si `w(n+1)` is valid), això evita el possible desbordament en el càlcul de `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, és a dir, la següent reproduïció definitivament no arrodoneix a `v`.
            // això equival a `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // la part esquerra pot desbordar-se, però coneixem `threshold > plus1v`, per tant, si TC1 és fals, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` i podem provar amb seguretat si és `threshold - plus1w(n) < 10^kappa`.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, és a dir, la següent repr
            // no és més a prop de `v + 1 ulp` que la reproducció actual.
            // donat `z(n) = plus1v_up - plus1w(n)`, es converteix en `abs(z(n)) <= abs(z(n+1))`.de nou suposant que TC1 és fals, tenim `z(n) > 0`.tenim dos casos a considerar:
            //
            // - quan `z(n+1) >= 0`: TC3 es converteix en `z(n) <= z(n+1)`.
            // a mesura que `plus1w(n)` augmenta, `z(n)` hauria de disminuir i això és clarament fals.
            // - quan `z(n+1) < 0`:
            //   - TC3a: la condició prèvia és `plus1v_up < plus1w(n) + 10^kappa`.suposant que TC2 és fals, `threshold >= plus1w(n) + 10^kappa` per tant no es pot desbordar.
            //   - TC3b: TC3 es converteix en `z(n) <= -z(n+1)`, és a dir, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   el TC1 negat dóna `plus1v_up > plus1w(n)`, de manera que no pot desbordar-se ni submergir-se quan es combina amb TC3a.
            //
            // en conseqüència, hauríem d'aturar-nos quan `TC1 || TC2 || (TC3a && TC3b)`.el següent és igual a la seva inversa, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // la reproducció més curta no pot acabar amb `0`
                plus1w += ten_kappa;
            }
        }

        // comproveu si aquesta representació també és la representació més propera a `v - 1 ulp`.
        //
        // això és simplement igual a les condicions de finalització de `v + 1 ulp`, amb tot `plus1v_up` substituït per `plus1v_down`.
        // l`anàlisi de desbordament és igual.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // ara tenim la representació més propera a `v` entre `plus1` i `minus1`.
        // això és massa liberal, però, així que rebutgem qualsevol `w(n)` no entre `plus0` i `minus0`, és a dir, `plus1 - plus1w(n) <= minus0` o `plus1 - plus1w(n) >= plus0`.
        // utilitzem els fets que `threshold = plus1 - minus1` i `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// La implementació del mode més curt per a Grisu amb Dragon fallback.
///
/// S`ha d`utilitzar en la majoria dels casos.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SEGURETAT: el comprovador de préstecs no és prou intel・ligent per permetre`ns utilitzar `buf`
    // a la segona branch, de manera que rentem la vida aquí.
    // Però només tornem a utilitzar `buf` si `format_shortest_opt` va retornar `None`, així que està bé.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// La implementació de manera fixa i exacta per a Grisu.
///
/// Retorna `None` quan en cas contrari retornaria una representació inexacta.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // necessitem almenys tres bits de precisió addicional
    assert!(!buf.is_empty());

    // normalitzar i escalar `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // divideix `v` en parts fraccionades i integrals.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // tant el `v` antic com el nou `v` (escalat per `10^-k`) tenen un error de <1 ulp (teorema 5.1).
    // com que no sabem que l'error és positiu o negatiu, fem servir dues aproximacions espaiades per igual i tenim l'error màxim de 2 ulpes (igual al cas més curt).
    //
    //
    // l'objectiu és trobar la sèrie de dígits arrodonits exactament que són comuns tant a `v - 1 ulp` com a `v + 1 ulp`, de manera que tinguem la màxima confiança.
    // si això no és possible, no sabem quina és la sortida correcta per a `v`, de manera que desistim i retrocedim.
    //
    // `err` aquí es defineix com a `1 ulp * 2^e` (el mateix que l'ULP a `vfrac`), i l'escalarem sempre que `v` s'escali.
    //
    //
    //
    let mut err = 1;

    // calculeu el `10^max_kappa` més gran com a màxim `v` (per tant `v < 10^(max_kappa+1)`).
    // aquest és un límit superior de `kappa` a continuació.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // si treballem amb la limitació de l`últim dígit, hem d`escurçar la memòria intermèdia abans de la representació real per evitar un doble arrodoniment.
    //
    // Tingueu en compte que hem de tornar a ampliar la memòria intermèdia quan es produeix l'arrodoniment.
    let len = if exp <= limit {
        // Vaja, ni tan sols podem produir * un dígit.
        // això és possible quan, per exemple, tenim alguna cosa com 9.5 i s'està redonant a 10.
        //
        // en principi podem trucar immediatament a `possibly_round` amb una memòria intermèdia buida, però escalar `max_ten_kappa << e` per 10 pot provocar un desbordament.
        //
        // per tant, estem sent descuidats aquí i ampliem l'interval d'errors en un factor de 10.
        // això augmentarà la taxa de falsos negatius, però només molt,*molt* lleugerament;
        // només pot importar notablement quan la mantissa supera els 60 bits.
        //
        // SEGURETAT: `len=0`, de manera que l`obligació d`haver inicialitzat aquesta memòria és trivial.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // representar parts integrals.
    // l'error és completament fraccionat, de manera que no cal que ho comprovem en aquesta part.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // dígits encara per renderitzar
    loop {
        // sempre tenim com a mínim un dígit per convertir invariants:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (se segueix que `remainder = vint % 10^(kappa+1)`)
        //
        //

        // divideix `remainder` per `10^kappa`.tots dos estan escalats per `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // el buffer està ple?executeu el pas rodó amb la resta.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SEGURETAT: hem inicialitzat `len` molts bytes.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // trencar el bucle quan hem representat tots els dígits integrals.
        // el nombre exacte de dígits és `max_kappa + 1` com `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // restaurar invariants
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // representar parts fraccionàries.
    //
    // en principi podem continuar fins a l'últim dígit disponible i comprovar-ne l'exactitud.
    // per desgràcia, estem treballant amb els enters de mida finita, de manera que necessitem algun criteri per detectar el desbordament.
    // V8 utilitza `remainder > err`, que es fa fals quan els primers dígits significatius de `i` de `v - 1 ulp` i `v` difereixen.
    // tanmateix, això rebutja massa dades vàlides.
    //
    // atès que la fase posterior té una detecció de desbordament correcta, en lloc d'això fem servir un criteri més ajustat:
    // continuem fins que `err` supera `10^kappa / 2`, de manera que l'abast entre `v - 1 ulp` i `v + 1 ulp` conté definitivament dues o més representacions arrodonides.
    //
    // això passa amb les dues primeres comparacions de `possibly_round`, com a referència.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invariants, on `m = max_kappa + 1` (nombre de dígits a la part integral):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // no desbordarà, `2^e * 10 < 2^64`
        err *= 10; // no desbordarà, `err * 10 < 2^e * 5 < 2^64`

        // divideix `remainder` per `10^kappa`.
        // tots dos estan escalats per `2^e / 10^kappa`, de manera que aquest últim està implícit aquí.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // el buffer està ple?executeu el pas rodó amb la resta.
        if i == len {
            // SEGURETAT: hem inicialitzat `len` molts bytes.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // restaurar invariants
        remainder = r;
    }

    // un càlcul addicional no serveix de res (el `possibly_round` falla definitivament), així que ens rendim.
    return None;

    // hem generat tots els dígits sol・licitats de `v`, que haurien de ser iguals als dígits corresponents de `v - 1 ulp`.
    // ara comprovem si hi ha una representació única compartida tant per `v - 1 ulp` com per `v + 1 ulp`;pot ser igual als dígits generats o a la versió arrodonida d'aquests dígits.
    //
    // si l'interval conté diverses representacions de la mateixa longitud, no podem estar segurs i hauríem de retornar `None`.
    //
    // tots els arguments aquí s`escalen pel valor comú (però implícit) `k`, de manera que:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // SEGURETAT: s'han d'inicialitzar els primers bytes `len` de `buf`.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (per a la referència, la línia de punts indica el valor exacte per a possibles representacions en un nombre determinat de dígits.)
        //
        //
        // l'error és massa gran que hi ha almenys tres representacions possibles entre `v - 1 ulp` i `v + 1 ulp`.
        // no podem determinar quina és correcta.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // de fet, 1/2 ulp és suficient per introduir dues possibles representacions.
        // (recordeu que necessitem una representació única tant per a `v - 1 ulp` com per a "v + 1 ulp".) això no es desbordarà, ja que `ulp < ten_kappa` des de la primera comprovació.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // si `v + 1 ulp` està més a prop de la representació arrodonida cap avall (que ja és a `buf`), podem tornar amb seguretat.
        // tingueu en compte que `v - 1 ulp`*pot* ser inferior a la representació actual, però com a `1 ulp < 10^kappa / 2`, aquesta condició és suficient:
        // la distància entre `v - 1 ulp` i la representació actual no pot superar `10^kappa / 2`.
        //
        // la condició és igual a `remainder + ulp < 10^kappa / 2`.
        // ja que això pot desbordar-se fàcilment, primer comproveu si `remainder < 10^kappa / 2`.
        // ja hem comprovat que `ulp < 10^kappa / 2`, de manera que sempre que `10^kappa` no es desbordi al cap i a la fi, la segona comprovació està bé.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SEGURETAT: el nostre interlocutor va inicialitzar aquesta memòria.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------resta------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // per altra banda, si `v - 1 ulp` està més a prop de la representació arrodonida, hauríem d'arrodonir-la i tornar-la.
        // pel mateix motiu, no cal que comproveu `v + 1 ulp`.
        //
        // la condició és igual a `remainder - ulp >= 10^kappa / 2`.
        // novament comprovem primer si `remainder > ulp` (tingueu en compte que no és `remainder >= ulp`, ja que `10^kappa` mai és zero).
        //
        // també tingueu en compte que `remainder - ulp <= 10^kappa`, de manera que la segona comprovació no desborda.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // SEGURETAT: el nostre interlocutor ha d`haver inicialitzat aquesta memòria.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // només afegiu un dígit addicional quan se us demani la precisió fixa.
                // també hem de comprovar que, si el buffer original estava buit, el dígit addicional només es pot afegir quan `exp == limit` (majúscula edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // SEGURETAT: nosaltres i el nostre interlocutor vam inicialitzar aquesta memòria.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // en cas contrari, estem condemnats (és a dir, alguns valors entre `v - 1 ulp` i `v + 1 ulp` s`arrodoneixen cap avall i d`altres s`arrodoneixen cap amunt) i desistim.
        //
        None
    }
}

/// La implementació de manera exacta i fixa per a Grisu amb Dragon fallback.
///
/// S`ha d`utilitzar en la majoria dels casos.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SEGURETAT: el comprovador de préstecs no és prou intel・ligent per permetre`ns utilitzar `buf`
    // a la segona branch, de manera que rentem la vida aquí.
    // Però només tornem a utilitzar `buf` si `format_exact_opt` va retornar `None`, així que està bé.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}