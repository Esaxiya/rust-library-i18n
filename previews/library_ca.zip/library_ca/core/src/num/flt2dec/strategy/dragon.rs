//! Traducció Rust gairebé directa (però lleugerament optimitzada) de la figura 3 de "Impressió de números de coma flotant de forma ràpida i precisa" [^ 1].
//!
//!
//! [^1]: Burger, RG i Dybvig, RK 1996. Impressió de números de coma flotant
//!   de forma ràpida i precisa.SIGPLAN No.31, 5 (maig de 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// matrius precalculats de `Digit`s per a 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// només es pot utilitzar quan `x < 16 * scale`;`scaleN` hauria de ser `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// La implementació del mode més curt per a Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // se sap que el número `v` al format és:
    // - igual a `mant * 2^exp`;
    // - precedit de `(mant - 2 *minus)* 2^exp` en el tipus original;i
    // - seguit de `(mant + 2 *plus)* 2^exp` en el tipus original.
    //
    // òbviament, `minus` i `plus` no poden ser zero.(per a infinits, fem servir valors fora de rang.) també suposem que es genera almenys un dígit, és a dir, `mant` tampoc no pot ser zero.
    //
    // això també significa que qualsevol número entre `low = (mant - minus)*2^exp` i `high = (mant + plus)* 2^exp` maparà a aquest número exacte de coma flotant, amb límits inclosos quan la mantissa original era parella (és a dir, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` és `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // estimeu `k_0` a partir d`entrades originals que satisfacin `10^(k_0-1) < high <= 10^(k_0+1)`.
    // el límit ajustat `k` que satisfà `10^(k-1) < high <= 10^k` es calcula més tard.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // converteix `{mant, plus, minus} * 2^exp` en la forma fraccionària de manera que:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // divideix `mant` per `10^k`.ara `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // reparació quan `mant + plus > scale` (o `>=`).
    // en realitat no estem modificant `scale`, ja que podem saltar la multiplicació inicial.
    // ara `scale < mant + plus <= scale * 10` i estem preparats per generar dígits.
    //
    // tingueu en compte que `d[0]`*pot* ser zero, quan `scale - plus < mant < scale`.
    // en aquest cas, la condició d'arrodoniment (`up` a continuació) s'activarà immediatament.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // equivalent a una escala `scale` per 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // memòria cau `(2, 4, 8) * scale` per a la generació de dígits.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invariants, on `d[0..n-1]` són dígits generats fins ara:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (per tant, `mant / scale < 10`) on `d[i..j]` és una abreviatura de `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // generar un dígit: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // es tracta d`una descripció simplificada de l`algoritme Dragon modificat.
        // per a la seva comoditat, s'ometen moltes derivacions intermèdies i arguments de completesa.
        //
        // Comenceu amb invariants modificats, ja que hem actualitzat `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // suposem que `d[0..n-1]` és la representació més curta entre `low` i `high`, és a dir, `d[0..n-1]` compleix amb els dos següents, però `d[0..n-2]` no:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivitat: dígits arrodonits a `v`);i
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (l'últim dígit és correcte).
        //
        // la segona condició es simplifica a `2 * mant <= scale`.
        // resoldre invariants en termes de `mant`, `low` i `high` proporciona una versió més senzilla de la primera condició: `-plus < mant < minus`.
        // des de `-plus < 0 <= mant`, tenim la representació més curta correcta quan `mant < minus` i `2 * mant <= scale`.
        // (el primer es converteix en `mant <= minus` quan la mantissa original és parella).
        //
        // quan el segon no es manté (`2 * mant> scale`), hem d'augmentar l'últim dígit.
        // això és suficient per restaurar aquesta condició: ja sabem que la generació de dígits garanteix `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // en aquest cas, la primera condició es converteix en `-plus < mant - scale < minus`.
        // des de `mant < scale` després de la generació, tenim `scale < mant + plus`.
        // (de nou, això es converteix en `scale <= mant + plus` quan la mantissa original és parella).
        //
        // en resum:
        // - atureu i arrodoneu `down` (mantingueu els dígits tal qual) quan `mant < minus` (o `<=`).
        // - atura i arrodoneix `up` (augmenta l'últim dígit) quan `scale < mant + plus` (o `<=`).
        // - segueix generant d'una altra manera.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // tenim la representació més curta, procediu a l`arrodoniment

        // restaura els invariants.
        // això fa que l'algoritme acabi sempre: `minus` i `plus` sempre augmenten, però `mant` es retalla al mòdul `scale` i `scale` és fix.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // l'arrodoniment cap amunt passa quan i) només es va activar la condició d'arrodoniment o ii) es van activar les dues condicions i el trencament d'empat prefereix arrodonir-se.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // si l'arrodoniment cap amunt canvia la longitud, també hauria de canviar l'exponent.
        // sembla que aquesta condició és molt difícil de satisfer (possiblement impossible), però aquí estem sent segurs i coherents.
        //
        // SEGURETAT: vam inicialitzar aquesta memòria més amunt.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // SEGURETAT: vam inicialitzar aquesta memòria més amunt.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// La implementació de manera exacta i fixa per a Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // estimeu `k_0` a partir d`entrades originals que satisfacin `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // divideix `mant` per `10^k`.ara `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // reparació quan `mant + plus >= scale`, on `plus / scale = 10^-buf.len() / 2`.
    // per tal de mantenir el bignum de mida fixa, realment fem servir `mant + floor(plus) >= scale`.
    // en realitat no estem modificant `scale`, ja que podem saltar la multiplicació inicial.
    // de nou amb l'algorisme més curt, `d[0]` pot ser zero, però finalment s'arrodonirà cap amunt.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // equivalent a una escala `scale` per 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // si treballem amb la limitació de l`últim dígit, hem d`escurçar la memòria intermèdia abans de la representació real per evitar un doble arrodoniment.
    //
    // Tingueu en compte que hem de tornar a ampliar la memòria intermèdia quan es produeix l'arrodoniment.
    let mut len = if k < limit {
        // Vaja, ni tan sols podem produir * un dígit.
        // això és possible quan, per exemple, tenim alguna cosa com 9.5 i s'està redonant a 10.
        // retornem un buffer buit, amb l'excepció del cas d'arrodoniment posterior que es produeix quan `k == limit` i ha de produir exactament un dígit.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // memòria cau `(2, 4, 8) * scale` per a la generació de dígits.
        // (Pot ser car, de manera que no els calculeu quan la memòria intermèdia estigui buida).
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // els següents dígits són tots els zeros, ens aturem aquí *no* intenteu fer arrodoniments.més aviat, empleneu els dígits restants.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // SEGURETAT: vam inicialitzar aquesta memòria més amunt.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // arrodonint cap amunt si ens aturem enmig de dígits si els dígits següents són exactament 5000 ..., comproveu el dígit anterior i intenteu arrodonir-lo a parell (és a dir, eviteu arrodonir-lo quan el dígit anterior sigui parell).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // SEGURETAT: S`inicialitza `buf[len-1]`.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // si l'arrodoniment cap amunt canvia la longitud, també hauria de canviar l'exponent.
        // però se'ns ha demanat un nombre fix de dígits, així que no modifiqueu la memòria intermèdia ...
        // SEGURETAT: vam inicialitzar aquesta memòria més amunt.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... tret que se'ns demani la precisió fixa.
            // també hem de comprovar que, si el buffer original estava buit, el dígit addicional només es pot afegir quan `k == limit` (majúscula edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // SEGURETAT: vam inicialitzar aquesta memòria més amunt.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}