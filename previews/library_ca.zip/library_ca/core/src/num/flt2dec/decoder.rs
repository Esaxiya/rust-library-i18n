//! Decodifica un valor de coma flotant en parts individuals i intervals d'errors.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Valor finit sense signe descodificat, tal que:
///
/// - El valor original és igual a `mant * 2^exp`.
///
/// - Qualsevol número de `(mant - minus)*2^exp` a `(mant + plus)* 2^exp` arrodonirà al valor original.
/// L`abast només s`inclou quan `inclusive` és `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// La mantissa escamada.
    pub mant: u64,
    /// El rang d'errors més baix.
    pub minus: u64,
    /// L'interval superior d'errors.
    pub plus: u64,
    /// L'exponent compartit a la base 2.
    pub exp: i16,
    /// És cert quan l'interval d'errors és inclòs.
    ///
    /// A IEEE 754, això és cert quan la mantissa original era uniforme.
    pub inclusive: bool,
}

/// Valor sense signe descodificat.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinitats, positives o negatives.
    Infinite,
    /// Zero, positiu o negatiu.
    Zero,
    /// Nombres finits amb camps descodificats més.
    Finite(Decoded),
}

/// Un tipus de coma flotant que es pot "descodificar" d.
pub trait DecodableFloat: RawFloat + Copy {
    /// El valor positiu normalitzat mínim.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Retorna un signe (cert quan és negatiu) i el valor `FullDecoded` d'un número de coma flotant donat.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // veïns: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode sempre conserva l'exponent, de manera que la mantissa s'escala per als subnormals.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // veïns: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // on maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // veïns: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}