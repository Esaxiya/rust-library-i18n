//! Bit jugant en flotants IEEE 754 positius.Els números negatius no es manegen ni necessiten.
//! Els números normals de coma flotant tenen una representació canònica com (frac, exp) tal que el valor és 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) on N és el nombre de bits.
//!
//! Els subnormals són una mica diferents i estranys, però s`aplica el mateix principi.
//!
//! Aquí, però, els representem com (sig, k) amb f positiu, de manera que el valor és f *
//! 2 <sup>e</sup> .A més d`explicitar el "hidden bit", això canvia l`exponent per l`anomenat mantissa shift.
//!
//! Dit d'una altra manera, normalment els flotadors s'escriuen com a (1), però aquí s'escriuen com a (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Anomenem (1) la **representació fraccional** i (2) la **representació integral**.
//!
//! Moltes funcions d`aquest mòdul només gestionen números normals.Les rutines dec2flt prenen de manera conservadora el camí lent universalment correcte (algorisme M) per a nombres molt petits i molt grans.
//! Aquest algorisme només necessita next_float() que maneja subnormals i zeros.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Un ajudant trait per evitar duplicar bàsicament tot el codi de conversió per `f32` i `f64`.
///
/// Consulteu el comentari del document del mòdul pare per saber per què és necessari.
///
/// **Mai no s'hauria d'implementar** per a altres tipus ni s'hauria d'utilitzar fora del mòdul dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Tipus utilitzat per `to_bits` i `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Realitza una transmutació en brut a un enter.
    fn to_bits(self) -> Self::Bits;

    /// Realitza una transmutació en brut des d`un nombre enter.
    fn from_bits(v: Self::Bits) -> Self;

    /// Retorna la categoria en què es troba aquest número.
    fn classify(self) -> FpCategory;

    /// Retorna la mantissa, l'exponent i el signe com a enters.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Descodifica el flotador.
    fn unpack(self) -> Unpacked;

    /// Emet des d'un petit enter que es pot representar exactament.
    /// Panic si no es pot representar el nombre enter, l'altre codi d'aquest mòdul s'assegura de no deixar que això passi mai.
    fn from_int(x: u64) -> Self;

    /// Obté el valor 10 <sup>e</sup> d'una taula precomputada.
    /// Panics per a `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// El que diu el nom.
    /// És més fàcil fer codi dur que fer malabars amb els intrínsecs i esperar que la constant LLVM el doblegi.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Un límit conservador als dígits decimals de les entrades que no pot produir desbordament ni zero ni
    /// subnormals.Probablement l`exponent decimal del valor normal màxim, d`aquí ve el nom.
    const MAX_NORMAL_DIGITS: usize;

    /// Quan el dígit decimal més significatiu té un valor de lloc superior a aquest, el nombre és arrodonit a l'infinit.
    ///
    const INF_CUTOFF: i64;

    /// Quan el dígit decimal més significatiu té un valor de lloc inferior a aquest, el nombre és arrodonit a zero.
    ///
    const ZERO_CUTOFF: i64;

    /// El nombre de bits de l'exponent.
    const EXP_BITS: u8;

    /// El nombre de bits del significat,*inclòs* el bit ocult.
    const SIG_BITS: u8;

    /// El nombre de bits del significat,*excloent* el bit ocult.
    const EXPLICIT_SIG_BITS: u8;

    /// El màxim exponent legal en la representació fraccionada.
    const MAX_EXP: i16;

    /// L'exponent legal mínim en la representació fraccionada, excloent els subnormals.
    const MIN_EXP: i16;

    /// `MAX_EXP` per a la representació integral, és a dir, amb el canvi aplicat.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` codificat (és a dir, amb biaix de desplaçament)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` per a la representació integral, és a dir, amb el canvi aplicat.
    const MIN_EXP_INT: i16;

    /// El màxim significat normalitzat en representació integral.
    const MAX_SIG: u64;

    /// El mínim significat normalitzat en representació integral.
    const MIN_SIG: u64;
}

// Sobretot una solució alternativa per a #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Retorna la mantissa, l'exponent i el signe com a enters.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Biaix d`exponent + desplaçament de mantissa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe no està segur de si `as` arrodoneix correctament a totes les plataformes.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Retorna la mantissa, l'exponent i el signe com a enters.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Biaix d`exponent + desplaçament de mantissa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe no està segur de si `as` arrodoneix correctament a totes les plataformes.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Converteix un `Fp` al tipus flotant de màquina més proper.
/// No gestiona resultats subnormals.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f té 64 bits, de manera que xe té un canvi de mantissa de 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Arrodoneix el significat de 64 bits a T::SIG_BITS bits amb la meitat de parell.
/// No gestiona el desbordament d'exponent.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Ajusteu el canvi de mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Invers de `RawFloat::unpack()` per a números normalitzats.
/// Panics si el significant o l'exponent no són vàlids per als números normalitzats.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Traieu el bit amagat
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Ajusteu l'exponent per al biaix de l'exponent i el canvi de mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Deixeu el bit de signe a 0 ("+"), tots els nostres números són positius
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Construeix un subnormal.Es permet una mantissa de 0 i construeix zero.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // L'exponent codificat és 0, el bit de signe és 0, de manera que només hem de reinterpretar els bits.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Aproximar un bignum amb Fp.Ronda dins de 0.5 ULP amb mitja parella.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Vam tallar tots els bits abans de l`índex `start`, és a dir, efectivament canviem a la dreta per una quantitat de `start`, de manera que aquest també és l`exponent que necessitem.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Rodó (half-to-even) en funció dels bits truncats.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Troba el nombre de punt flotant més gran estrictament més petit que l'argument.
/// No maneja subnormals, zero o expulsió inferior.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Trobeu el nombre de punt flotant més petit estrictament més gran que l'argument.
// Aquesta operació és saturant, és a dir, next_float(inf) ==inf.
// A diferència de la majoria de codi d`aquest mòdul, aquesta funció gestiona zero, subnormals i infinits.
// Tanmateix, com tots els altres codis d`aquí, no tracta de NaN ni de nombres negatius.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Sembla massa bo per ser cert, però funciona.
        // 0.0 es codifica com la paraula totalment zero.Les subnormals són 0x000m ... m on m és la mantissa.
        // En particular, la subnormal més petita és 0x0 ... 01 i la més gran és 0x000F ... F.
        // El nombre normal més petit és 0x0010 ... 0, de manera que aquest cas de cantonada també funciona.
        // Si l`increment desborda la mantissa, el bit de transport incrementa l`exponent com volem i els bits de mantissa es tornen nuls.
        // A causa de la convenció de bits ocults, això també és exactament el que volem.
        // Finalment, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}