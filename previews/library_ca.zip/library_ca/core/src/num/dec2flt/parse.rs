//! Validació i descomposició d'una cadena decimal del formulari:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! En altres paraules, sintaxi estàndard de coma flotant, amb dues excepcions: cap signe i cap maneig de "inf" i "NaN".Aquests són gestionats per la funció de controlador (super::dec2flt).
//!
//! Tot i que reconèixer entrades vàlides és relativament fàcil, aquest mòdul també ha de rebutjar les innombrables variacions invàlides, mai panic, i realitzar nombroses comprovacions en què es basen els altres mòduls per no panic (o desbordament) al seu torn.
//!
//! Per empitjorar les coses, tot el que passa en una sola passada per sobre de l'entrada.
//! Per tant, aneu amb compte a l`hora de modificar qualsevol cosa i comproveu-ho amb els altres mòduls.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Les parts interessants d`una cadena decimal.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// L`exponent decimal es garanteix que té menys de 18 dígits decimals.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Comprova si la cadena d'entrada és un número de punt flotant vàlid i, si és així, localitzeu-ne la part integral, la part fraccionada i l'exponent.
/// No maneja rètols.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // No hi ha dígits abans de 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Necessitem almenys un sol dígit abans o després del punt.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Brossa final després de la part fraccionària
            }
        }
        _ => Invalid, // Brossa final després de la primera cadena de dígits
    }
}

/// Talla els dígits decimals fins al primer caràcter que no és de dígits.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Extracció d'exponent i comprovació d'errors.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Trast brossa després de l'exponent
    }
    if number.is_empty() {
        return Invalid; // Exponent buit
    }
    // En aquest punt, segur que tenim una cadena de dígits vàlida.Pot ser massa llarg per posar-lo en un `i64`, però si és tan enorme, l`entrada és certament nul・la o infinita.
    // Com que cada zero dels dígits decimals només ajusta l'exponent per +/-1, a exp=10 ^ 18 l'entrada hauria de ser de 17 exabytes (!) de zeros per arribar fins i tot a distància de ser finita.
    //
    // Aquest no és exactament un cas d`ús que hem d`atendre.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}