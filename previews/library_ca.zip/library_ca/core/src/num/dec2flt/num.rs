//! Funcions d'utilitat per a bignums que no tenen massa sentit per convertir-se en mètodes.

// FIXME El nom d'aquest mòdul és una mica lamentable, ja que altres mòduls també importen `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Comproveu si truncar tots els bits menys significatius que `ones_place` introdueix un error relatiu inferior, igual o superior a 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Si tots els bits restants són zero, és= 0.5 ULP, en cas contrari> 0.5 Si no hi ha més bits (half_bit==0), el següent també retorna igualment.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Converteix una cadena ASCII que només conté dígits decimals en un `u64`.
///
/// No realitza comprovacions de desbordament ni de caràcters invàlids, de manera que si la persona que truca no té cura, el resultat és fals i pot panic (tot i que no serà `unsafe`).
/// A més, les cadenes buides es tracten com zero.
/// Aquesta funció existeix perquè
///
/// 1. utilitzar `FromStr` a `&[u8]` requereix `from_utf8_unchecked`, que és dolent, i
/// 2. reunir els resultats de `integral.parse()` i `fractional.parse()` és més complicat que tota aquesta funció.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Converteix una cadena de dígits ASCII en bignum.
///
/// Igual que `from_str_unchecked`, aquesta funció es basa en l'analitzador per eliminar les xifres que no són de dígits.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Desenvolupa un bignum en un enter de 64 bits.Panics si el nombre és massa gran.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Extreu un interval de bits.

/// L`índex 0 és el bit menys significatiu i l`interval està mig obert com de costum.
/// Panics si se li demana que extregui més bits dels que encaixen al tipus de retorn.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}