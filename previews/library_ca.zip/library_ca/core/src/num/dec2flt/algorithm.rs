//! Els diversos algoritmes del paper.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Nombre de bits significatius en Fp
const P: u32 = 64;

// Simplement emmagatzemem la millor aproximació per a *tots* els exponents, de manera que es pot ometre la variable "h" i les condicions associades.
// Això canvia el rendiment d'un parell de quilobytes d'espai.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// En la majoria de les arquitectures, les operacions de coma flotant tenen una mida de bits explícita, per tant, la precisió del càlcul es determina sobre una base per operació.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// A x86, la x87 FPU s'utilitza per a operacions flotants si les extensions SSE/SSE2 no estan disponibles.
// La x87 FPU funciona amb 80 bits de precisió per defecte, el que significa que les operacions s'arrodoniran a 80 bits fent que es produeixi un doble arrodoniment quan els valors es representin finalment com a
//
// 32/64 valors flotants de bits.Per superar-ho, es pot configurar la paraula de control FPU de manera que els càlculs es realitzin amb la precisió desitjada.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Una estructura que s`utilitza per conservar el valor original de la paraula de control FPU, de manera que es pot restaurar quan es deixa caure l`estructura.
    ///
    ///
    /// La x87 FPU és un registre de 16 bits que té els camps següents:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// La documentació de tots els camps està disponible al Manual del desenvolupador de programari IA-32 Architectures (volum 1).
    ///
    /// L'únic camp rellevant per al codi següent és PC, Precision Control.
    /// Aquest camp determina la precisió de les operacions realitzades per la FPU.
    /// Es pot configurar en:
    ///  - 0b00, precisió única, és a dir, 32 bits
    ///  - 0b10, de doble precisió, és a dir, de 64 bits
    ///  - 0b11, doble precisió ampliada, és a dir, 80 bits (estat per defecte) El valor 0b01 està reservat i no s'ha d'utilitzar.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SEGURETAT: la instrucció `fldcw` s'ha auditat per poder funcionar correctament
        // qualsevol `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Estem utilitzant la sintaxi ATT per admetre LLVM 8 i LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Estableix el camp de precisió de la FPU a `T` i retorna un `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Calculeu el valor del camp de control de precisió adequat per a `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bits
            8 => 0x0200, // 64 bits
            _ => 0x0300, // per defecte, 80 bits
        };

        // Obteniu el valor original de la paraula de control per restaurar-la més endavant, quan es deixi caure l'estructura `FPUControlWord` SEGURETAT: la instrucció `fnstcw` s'ha auditat per poder funcionar correctament amb qualsevol `u16`.
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Estem utilitzant la sintaxi ATT per admetre LLVM 8 i LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Establiu la paraula de control a la precisió desitjada.
        // Això s`aconsegueix emmascarant l`antiga precisió (bits 8 i 9, 0x300) i substituint-la per la bandera de precisió calculada anteriorment.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// El camí ràpid de Bellerophon utilitzant enters i flotants de mida màquina.
///
/// Això s'extreu en una funció independent perquè es pugui intentar abans de construir un bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Comparem el valor exacte amb MAX_SIG a la vora del final, es tracta només d`un rebuig ràpid i econòmic (i també allibera la resta del codi de preocupar-se pel desbordament).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // El camí ràpid depèn fonamentalment de que l`aritmètica estigui arrodonida al nombre correcte de bits sense cap arrodoniment intermedi.
    // A x86 (sense SSE ni SSE2), es necessita canviar la precisió de la pila FPU x87 perquè arrodoneixi directament el bit 64/32.
    // La funció `set_precision` s'encarrega d'establir la precisió en arquitectures que requereixen configurar-la canviant l'estat global (com la paraula de control de la XP1X FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // El cas e <0 no es pot plegar a l'altra branch.
    // Les potències negatives resulten en una part fraccionària que es repeteix en binari, que és arrodonida, cosa que provoca errors reals (i de tant en tant força significatius!) En el resultat final.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// L`algoritme Bellerophon és un codi trivial justificat per una anàlisi numèrica no trivial.
///
/// Arrodoneix "f" a un float amb un significat de 64 bits i el multiplica per la millor aproximació de `10^e` (en el mateix format de coma flotant).Sovint, això és suficient per obtenir el resultat correcte.
/// No obstant això, quan el resultat és a prop de la meitat del camí entre dos flotadors (ordinary) adjacents, l'error d'arrodoniment compost de multiplicar dues aproximacions significa que el resultat pot estar apagat per uns quants bits.
/// Quan això passa, l'algorisme R iteratiu soluciona les coses.
///
/// L "close to halfway" ondulat a mà es fa precís mitjançant l'anàlisi numèrica del document.
/// En paraules de Clinger:
///
/// > Slop, expressat en unitats del bit menys significatiu, és un límit inclusiu de l'error
/// > acumulat durant el càlcul en coma flotant de l`aproximació a f * 10 ^ e.(Slop és
/// > no és un límit per al veritable error, però limita la diferència entre l'aproximació z i
/// > la millor aproximació possible que utilitzi p bits de significant.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Els casos abs(e) <log5(2^N) són a fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // La inclinació és prou gran per marcar la diferència en arrodonir a n bits?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Un algorisme iteratiu que millora una aproximació en coma flotant de `f * 10^e`.
///
/// Cada iteració aconsegueix una unitat en el darrer lloc més a prop, cosa que, per descomptat, triga molt a convergir si `z0` està fins i tot lleugerament apagat.
/// Afortunadament, quan s`utilitza com a alternativa per a Bellerophon, l`aproximació inicial és com a màxim un ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Trobeu enters enters positius `x`, `y` tals que `x / y` sigui exactament `(f *10^e) / (m* 2^k)`.
        // Això no només evita tractar els signes de `e` i `k`, sinó que també eliminem la potència de dos comuns a `10^e` i `2^k` per fer els números més petits.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Això s`escriu una mica incòmode perquè els nostres bignums no admeten nombres negatius, de manera que fem servir el valor absolut + informació del signe.
        // La multiplicació amb m_digits no es pot desbordar.
        // Si `x` o `y` són prou grans com per preocupar-nos del desbordament, també són prou grans perquè `make_ratio` hagi reduït la fracció en un factor de 2 ^ 64 o més.
        //
        //
        let (d2, d_negative) = if x >= y {
            // No necessiteu més x, deseu un clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Encara necessiteu y, feu una còpia.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Donats `x = f` i `y = m`, on `f` representen dígits decimals d'entrada com és habitual i `m` és el significat d'una aproximació en coma flotant, feu que la proporció `x / y` sigui igual a `(f *10^e) / (m* 2^k)`, possiblement reduïda per una potència de dos.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, excepte que reduïm la fracció per una potència de dos.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Això no es pot desbordar perquè requereix `e` positiu i `k` negatiu, cosa que només pot passar per valors extremadament propers a 1, el que significa que `e` i `k` seran relativament petits.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Tampoc no es pot desbordar, vegeu més amunt.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), reduint-se de nou per una potència comuna de dos.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Conceptualment, l'algorisme M és la forma més senzilla de convertir un decimal en un float.
///
/// Formem una proporció que és igual a `f * 10^e`, donant potències de dos fins a donar un significat flotant vàlid.
/// L'exponent binari `k` és el nombre de vegades que hem multiplicat el numerador o el denominador per dos, és a dir, en tot moment `f *10^e` és igual a `(u / v)* 2^k`.
/// Quan hàgim descobert la significació, només cal arrodonir-la inspeccionant la resta de la divisió, que es fa a les funcions d`ajuda més endavant.
///
///
/// Aquest algorisme és molt lent, fins i tot amb l'optimització descrita a `quick_start()`.
/// Tanmateix, és l`algoritme més senzill d`adaptar-se a resultats de desbordament, subflujo i subnormals.
/// Aquesta implementació s`apodera quan Bellerophon i Algorithm R estan desbordats.
/// La detecció del desbordament i desbordament és fàcil: la proporció encara no és significativa dins del rang, però s`ha assolit l`exponent minimum/maximum.
/// En cas de desbordament, simplement retornem infinit.
///
/// Manejar el subfluor i els subnormals és més complicat.
/// Un gran problema és que, amb l`exponent mínim, la proporció encara pot ser massa gran per a un significant.
/// Vegeu underflow() per obtenir més informació.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME possible optimització: generalitzeu big_to_fp perquè puguem fer l'equivalent de fp_to_float(big_to_fp(u)) aquí, només sense el doble arrodoniment.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Hem d'aturar-nos com a mínim exponent, si esperem fins a `k < T::MIN_EXP_INT`, ens desconnectaríem per un factor de dos.
            // Malauradament, això vol dir que hem de distingir majúscules i minúscules amb l'exponent mínim.
            // FIXME troba una formulació més elegant, però executeu la prova `tiny-pow10` per assegurar-vos que és realment correcta.
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Salta la majoria de les iteracions de l'algorisme comprovant la longitud de bits.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // La longitud de bits és una estimació del logaritme de la base dos i log(u / v) = log(u), log(v).
    // L'estimació està desactivada com a màxim 1, però sempre és infravalorada, de manera que l'error de log(u) i log(v) té el mateix signe i es cancel・la (si tots dos són grans).
    // Per tant, l'error per a log(u / v) també és un màxim.
    // La proporció objectiu és aquella en què u/v es troba en un significand dins del rang.Per tant, la nostra condició de terminació és log2(u / v), sent els bits significatius i plus/minus.
    // FIXME Mirar el segon bit podria millorar l'estimació i evitar algunes divisions més.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Influència o subnormal.Deixeu-lo a la funció principal.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Desbordament.Deixeu-lo a la funció principal.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // La proporció no és un significat dins de l'interval i amb l'exponent mínim, de manera que hem d'arrodonir l'excés de bits i ajustar l'exponent en conseqüència.
    // El valor real ara és el següent:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(representat per rem)
    //
    // Per tant, quan els bits arrodonits són!= 0.5 ULP, decideixen l`arrodoniment pel seu compte.
    // Quan són iguals i la resta no és zero, el valor encara s`ha d`arrodonir cap amunt.
    // Només quan els bits arrodonits són 1/2 i la resta és nul・la, tenim una situació igualada.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Arrodonit ordinari, ofuscat per haver d`arrodonir segons la resta d`una divisió.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}