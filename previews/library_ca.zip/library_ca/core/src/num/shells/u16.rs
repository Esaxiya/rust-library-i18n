//! Constants per al tipus enter de 16 bits sense signar.
//!
//! *[See also the `u16` primitive type][u16].*
//!
//! El nou codi hauria d`utilitzar les constants associades directament al tipus primitiu.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u16`"
)]

int_module! { u16 }