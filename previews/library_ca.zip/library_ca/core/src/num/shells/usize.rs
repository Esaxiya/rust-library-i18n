//! Constants per al tipus enter sense signar de mida punter.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! El nou codi hauria d`utilitzar les constants associades directament al tipus primitiu.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }