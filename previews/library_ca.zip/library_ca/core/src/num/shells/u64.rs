//! Constants per al tipus enter sense signe de 64 bits.
//!
//! *[See also the `u64` primitive type][u64].*
//!
//! El nou codi hauria d`utilitzar les constants associades directament al tipus primitiu.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u64`"
)]

int_module! { u64 }