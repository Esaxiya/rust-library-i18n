//! Constants per al tipus enter signat de mida punter.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! El nou codi hauria d`utilitzar les constants associades directament al tipus primitiu.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }