//! Tipus d'error per a la conversió a tipus integrals.

use crate::convert::Infallible;
use crate::fmt;

/// El tipus d'error es torna quan falla una conversió de tipus integral comprovada.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Feu coincidir en lloc de coaccionar per assegurar-vos que el codi com `From<Infallible> for TryFromIntError` anterior continuarà funcionant quan `Infallible` es converteixi en un àlies de `!`.
        //
        //
        match never {}
    }
}

/// Un error que es pot retornar en analitzar un nombre enter.
///
/// Aquest error s'utilitza com a tipus d'error per a les funcions `from_str_radix()` en els tipus enters primers, com ara [`i8::from_str_radix`].
///
/// # Causes potencials
///
/// Entre altres causes, `ParseIntError` es pot llançar a causa de l'espai en blanc principal o final a la cadena, per exemple, quan s'obté a partir de l'entrada estàndard.
///
/// L'ús del mètode [`str::trim()`] garanteix que no quedi cap espai en blanc abans de l'anàlisi.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum per emmagatzemar els diversos tipus d'errors que poden provocar un error en analitzar un nombre enter.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// El valor que s`analitza és buit.
    ///
    /// Entre altres causes, aquesta variant es construirà en analitzar una cadena buida.
    Empty,
    /// Conté un dígit no vàlid en el seu context.
    ///
    /// Entre altres causes, aquesta variant es construirà en analitzar una cadena que conté un caràcter que no sigui ASCII.
    ///
    /// Aquesta variant també es construeix quan un `+` o `-` es troba fora de lloc dins d'una cadena, ja sigui per si mateix o al centre d'un número.
    ///
    ///
    InvalidDigit,
    /// L'enter és massa gran per emmagatzemar-lo en un tipus enter de destinació.
    PosOverflow,
    /// L'enter és massa petit per emmagatzemar-lo en un tipus enter objectiu.
    NegOverflow,
    /// El valor era zero
    ///
    /// Aquesta variant s'emetrà quan la cadena d'anàlisi tingui un valor zero, cosa que seria il・legal per als tipus diferents de zero.
    ///
    Zero,
}

impl ParseIntError {
    /// Mostra la causa detallada de l`anàlisi d`un error enter.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}