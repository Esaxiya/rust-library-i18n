//! Traits per a conversions entre tipus.
//!
//! El traits d`aquest mòdul proporciona una manera de convertir d`un tipus a un altre.
//! Cada trait té un propòsit diferent:
//!
//! - Implementeu el [`AsRef`] trait per obtenir conversions barates de referència a referència
//! - Implementeu el [`AsMut`] trait per obtenir conversions barates de mutable a mutable
//! - Implementeu [`From`] trait per consumir conversions valor-valor
//! - Implementeu el [`Into`] trait per consumir conversions valor-valor en tipus fora del crate actual.
//! - Els [`TryFrom`] i [`TryInto`] traits es comporten com els [`From`] i [`Into`], però s`han d`implementar quan la conversió pot fallar.
//!
//! Les traits d`aquest mòdul s`utilitzen sovint com a trait bounds per a funcions genèriques, de manera que s`admeten arguments de diversos tipus.Consulteu la documentació de cada trait per obtenir exemples.
//!
//! Com a autor de la biblioteca, sempre heu de preferir implementar [`From<T>`][`From`] o [`TryFrom<T>`][`TryFrom`] en lloc de [`Into<U>`][`Into`] o [`TryInto<U>`][`TryInto`], ja que [`From`] i [`TryFrom`] proporcionen una major flexibilitat i ofereixen implementacions equivalents de [`Into`] o [`TryInto`] de forma gratuïta, gràcies a una implementació de manta a la biblioteca estàndard.
//! En orientar una versió anterior a Rust 1.41, pot ser que sigui necessari implementar [`Into`] o [`TryInto`] directament quan es converteixi a un tipus fora del crate actual.
//!
//! # Implementacions genèriques
//!
//! - [`AsRef`] i [`AsMut`] autoreferència si el tipus intern és una referència
//! - [`Des de ']` <U>per a T`implica [`Into`]`</u><T><U>per a U`</u>
//! - [`TryFrom`]`<U>per a T` implica [`TryInto`]`</u><T><U>per a U`</u>
//! - [`From`] i [`Into`] són reflexius, el que significa que tots els tipus poden `into` per si mateixos i `from` per si mateixos
//!
//! Vegeu cada trait per obtenir exemples d`ús.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// La funció identitària.
///
/// Dues coses són importants a tenir en compte sobre aquesta funció:
///
/// - No sempre equival a un tancament com `|x| x`, ja que el tancament pot obligar `x` a un tipus diferent.
///
/// - Moveu l'entrada `x` passada a la funció.
///
/// Tot i que pot semblar estrany tenir una funció que només retorni l'entrada, hi ha alguns usos interessants.
///
///
/// # Examples
///
/// Utilitzar `identity` per no fer res en una seqüència d`altres funcions interessants:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Suposem que afegir-ne una és una funció interessant.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Utilitzant `identity` com a cas base "do nothing" en condicional:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Feu coses més interessants ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Utilitzant `identity` per conservar les variants `Some` d'un iterador de `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Solia fer una conversió barata de referència a referència.
///
/// Aquest trait és similar al [`AsMut`] que s`utilitza per convertir entre referències mutables.
/// Si heu de fer una conversió costosa, és millor implementar [`From`] amb el tipus `&T` o escriure una funció personalitzada.
///
/// `AsRef` té la mateixa signatura que [`Borrow`], però [`Borrow`] és diferent en alguns aspectes:
///
/// - A diferència de `AsRef`, [`Borrow`] té un implante de manta per a qualsevol `T` i es pot utilitzar per acceptar una referència o un valor.
/// - [`Borrow`] també requereix que [`Hash`], [`Eq`] i [`Ord`] per al valor prestat siguin equivalents als del valor posseït.
/// Per aquest motiu, si voleu manllevar només un sol camp d'una estructura, podeu implementar `AsRef`, però no [`Borrow`].
///
/// **Note: Aquest trait no pot fallar **.Si la conversió pot fallar, utilitzeu un mètode dedicat que retorni un [`Option<T>`] o un [`Result<T, E>`].
///
/// # Implementacions genèriques
///
/// - `AsRef` autoreferències si el tipus intern és una referència o una referència mutable (per exemple: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// En utilitzar trait bounds podem acceptar arguments de diferents tipus sempre que es puguin convertir al tipus especificat `T`.
///
/// Per exemple: en crear una funció genèrica que pren un `AsRef<str>`, expressem que volem acceptar totes les referències que es puguin convertir a [`&str`] com a argument.
/// Com que tant [`String`] com [`&str`] implementen `AsRef<str>`, podem acceptar tots dos com a argument d'entrada.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Realitza la conversió.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// S'utilitzava per fer una conversió de referència mutable a mutable barata.
///
/// Aquest trait és similar al [`AsRef`], però s`utilitza per convertir entre referències mutables.
/// Si heu de fer una conversió costosa, és millor implementar [`From`] amb el tipus `&mut T` o escriure una funció personalitzada.
///
/// **Note: Aquest trait no pot fallar **.Si la conversió pot fallar, utilitzeu un mètode dedicat que retorni un [`Option<T>`] o un [`Result<T, E>`].
///
/// # Implementacions genèriques
///
/// - `AsMut` autoreferències si el tipus intern és una referència mutable (per exemple: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Utilitzant `AsMut` com a trait bound per a una funció genèrica, podem acceptar totes les referències mutables que es poden convertir al tipus `&mut T`.
/// Com que [`Box<T>`] implementa `AsMut<T>`, podem escriure una funció `add_one` que prengui tots els arguments que es puguin convertir a `&mut u64`.
/// Com que [`Box<T>`] implementa `AsMut<T>`, `add_one` també accepta arguments de tipus `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Realitza la conversió.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Una conversió valor-valor que consumeix el valor d`entrada.El contrari de [`From`].
///
/// S`ha d`evitar implementar [`Into`] i implementar [`From`].
/// La implementació de [`From`] proporciona automàticament una implementació de [`Into`] gràcies a la implementació de manta a la biblioteca estàndard.
///
/// Preferiu utilitzar [`Into`] sobre [`From`] quan especifiqueu trait bounds en una funció genèrica per assegurar-vos que també es puguin utilitzar els tipus que només implementen [`Into`].
///
/// **Note: Aquest trait no pot fallar **.Si la conversió pot fallar, utilitzeu [`TryInto`].
///
/// # Implementacions genèriques
///
/// - ["Des de"] `<T>per a U` implica `Into<U> for T`
/// - [`Into`] és reflexiu, el que significa que s`implementa `Into<T> for T`
///
/// # Implementació de [`Into`] per a conversions a tipus externs en versions antigues de Rust
///
/// Abans de Rust 1.41, si el tipus de destinació no formava part del crate actual, no podríeu implementar [`From`] directament.
/// Per exemple, agafeu aquest codi:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Això fallarà en compilar-se en versions anteriors del llenguatge perquè les regles orfes de Rust solien ser una mica més estrictes.
/// Per evitar-ho, podeu implementar [`Into`] directament:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// És important entendre que [`Into`] no proporciona una implementació [`From`] (com ho fa [`From`] amb [`Into`]).
/// Per tant, sempre heu d`intentar implementar [`From`] i després tornar a [`Into`] si [`From`] no es pot implementar.
///
/// # Examples
///
/// [`String`] implementa [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Per tal d`expressar que volem que una funció genèrica agafi tots els arguments que es puguin convertir en un tipus especificat `T`, podem utilitzar un trait bound de [`Into`]`<T>'.
///
/// Per exemple: La funció `is_hello` pren tots els arguments que es poden convertir en un [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Realitza la conversió.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// S`utilitza per fer conversions de valor a valor mentre es consumeix el valor d`entrada.És el recíproc de [`Into`].
///
/// Sempre s`ha de preferir implementar `From` per sobre de [`Into`] perquè implementar `From` proporciona automàticament una implementació de [`Into`] gràcies a la implementació de manta a la biblioteca estàndard.
///
///
/// Només implementeu [`Into`] quan s'orienta a una versió anterior a Rust 1.41 i es converteix a un tipus fora del crate actual.
/// `From` no va poder fer aquest tipus de conversions en versions anteriors a causa de les regles orfes de Rust.
/// Consulteu [`Into`] per obtenir més detalls.
///
/// Preferiu utilitzar [`Into`] abans que fer servir `From` quan especifiqueu trait bounds en una funció genèrica.
/// D'aquesta manera, els tipus que implementen directament [`Into`] també es poden utilitzar com a arguments.
///
/// El `From` també és molt útil a l`hora de gestionar errors.Quan es construeix una funció capaç de fallar, el tipus de retorn generalment serà de la forma `Result<T, E>`.
/// El `From` trait simplifica la gestió d'errors en permetre a una funció retornar un únic tipus d'error que encapsuli diversos tipus d'errors.Consulteu la secció "Examples" i [the book][book] per obtenir més informació.
///
/// **Note: Aquest trait no pot fallar **.Si la conversió pot fallar, utilitzeu [`TryFrom`].
///
/// # Implementacions genèriques
///
/// - `From<T> for U` implica [`Into`]`<U>per a T`</u>
/// - `From` és reflexiu, el que significa que s`implementa `From<T> for T`
///
/// # Examples
///
/// [`String`] implementa `From<&str>`:
///
/// Una conversió explícita d'un `&str` a una cadena es fa de la següent manera:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Mentre es realitza la gestió d'errors, sovint és útil implementar `From` per al vostre propi tipus d'error.
/// En convertir els tipus d`errors subjacents al nostre propi tipus d`error personalitzat que encapsula el tipus d`error subjacent, podem retornar un únic tipus d`error sense perdre informació sobre la causa subjacent.
/// L'operador '?' converteix automàticament el tipus d'error subjacent al nostre tipus d'error personalitzat trucant a `Into<CliError>::into` que es proporciona automàticament en implementar `From`.
/// A continuació, el compilador dedueix quina implementació de `Into` s'hauria d'utilitzar.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Realitza la conversió.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Un intent de conversió que consumeix `self`, que pot costar o no.
///
/// Els autors de biblioteques no haurien d`implementar directament aquest trait, però haurien de preferir implementar el [`TryFrom`] trait, que ofereix una major flexibilitat i proporciona una implementació `TryInto` equivalent de forma gratuïta, gràcies a una implementació general a la biblioteca estàndard.
/// Per obtenir més informació sobre això, consulteu la documentació de [`Into`].
///
/// # Implementació de `TryInto`
///
/// Això pateix les mateixes restriccions i raonaments que la implementació de [`Into`]; consulteu-hi per obtenir més informació.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// El tipus retornat en cas d'error de conversió.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Realitza la conversió.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Conversions de tipus senzilles i segures que poden fallar de manera controlada en algunes circumstàncies.És el recíproc de [`TryInto`].
///
/// Això és útil quan feu una conversió de tipus que pot tenir èxit trivial, però també pot necessitar un tractament especial.
/// Per exemple, no hi ha cap manera de convertir un [`i64`] en un [`i32`] mitjançant [`From`] trait, perquè un [`i64`] pot contenir un valor que un [`i32`] no pot representar i, per tant, la conversió perdria dades.
///
/// Això es pot manejar truncant l [`i64`] a un [`i32`] (donant bàsicament el valor del mòdul ['i64`] [`i32::MAX`]) o simplement retornant [`i32::MAX`], o mitjançant algun altre mètode.
/// El [`From`] trait està dissenyat per a conversions perfectes, de manera que el `TryFrom` trait informa el programador quan una conversió de tipus pot anar malament i els permet decidir com gestionar-la.
///
/// # Implementacions genèriques
///
/// - `TryFrom<T> for U` implica [`TryInto`]`<U>per a T`</u>
/// - [`try_from`] és reflexiu, el que significa que `TryFrom<T> for T` està implementat i no pot fallar; el tipus `Error` associat per trucar a `T::try_from()` amb un valor del tipus `T` és [`Infallible`].
/// Quan el tipus [`!`] està estabilitzat, [`Infallible`] i [`!`] seran equivalents.
///
/// `TryFrom<T>` es pot implementar de la següent manera:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Tal com es descriu, [`i32`] implementa `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Trunca silenciosament `big_number`, requereix detectar i gestionar el truncament després del fet.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Retorna un error perquè `big_number` és massa gran per cabre en un `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Retorna `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// El tipus retornat en cas d'error de conversió.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Realitza la conversió.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS GENÈRICS
////////////////////////////////////////////////////////////////////////////////

// A mesura que s'eleva
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Com a elevadors superiors a &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): substituïu els impls anteriors per&/&mut pel següent més general:
// // Com a ascensors sobre Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Talla> AsRef <U>per a D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut s'eleva per sobre de &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): substituïu l'imprès anterior per &mut pel següent més general:
// // AsMut s`eleva sobre DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Talla> AsMut <U>per a D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// De implica Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (i, per tant, Into) és reflexiu
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Nota d'estabilitat:** Aquesta aplicació encara no existeix, però som "reserving space" per afegir-la al future.
/// Vegeu [rust-lang/rust#64715][#64715] per obtenir més informació.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): feu una correcció de principis.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom implica TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Les conversions infal・libles equivalen semànticament a les conversions fal・libles amb un tipus d`error deshabitat.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS DE FORMIGÓ
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// EL TIPUS D'ERROR SENSE ERRORS
////////////////////////////////////////////////////////////////////////////////

/// El tipus d'error per als errors que mai no es poden produir.
///
/// Com que aquest enum no té cap variant, mai no pot existir un valor d`aquest tipus.
/// Això pot ser útil per a les API genèriques que utilitzen [`Result`] i parametritzen el tipus d'error, per indicar que el resultat sempre és [`Ok`].
///
/// Per exemple, [`TryFrom`] trait (conversió que retorna un [`Result`]) té una implementació general per a tots els tipus en què existeix una implementació inversa de [`Into`].
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Compatibilitat Future
///
/// Aquesta enum té el mateix paper que [the `!`“never”type][never], que és inestable en aquesta versió de Rust.
/// Quan `!` s'estabilitzi, tenim previst convertir `Infallible` en un àlies de tipus:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... i finalment desaprofitarà `Infallible`.
///
/// Tanmateix, hi ha un cas en què es pot utilitzar la sintaxi `!` abans que `!` s'estabilitzi com a tipus complet: en la posició del tipus de retorn d'una funció.
/// En concret, són possibles implementacions per a dos tipus de punteres de funció diferents:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Com que `Infallible` és un enum, aquest codi és vàlid.
/// Tanmateix, quan `Infallible` es converteixi en un àlies del never type, els dos `impl`s començaran a superposar-se i, per tant, seran desautoritzats per les regles de coherència trait de la llengua.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}