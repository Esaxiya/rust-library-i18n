#![stable(feature = "duration_core", since = "1.25.0")]

//! Quantificació temporal.
//!
//! Example:
//!
//! ```
//! use std::time::Duration;
//!
//! let five_seconds = Duration::new(5, 0);
//! // ambdues declaracions són equivalents
//! assert_eq!(Duration::new(5, 0), Duration::from_secs(5));
//! ```

use crate::fmt;
use crate::iter::Sum;
use crate::ops::{Add, AddAssign, Div, DivAssign, Mul, MulAssign, Sub, SubAssign};

const NANOS_PER_SEC: u32 = 1_000_000_000;
const NANOS_PER_MILLI: u32 = 1_000_000;
const NANOS_PER_MICRO: u32 = 1_000;
const MILLIS_PER_SEC: u64 = 1_000;
const MICROS_PER_SEC: u64 = 1_000_000;

/// Un tipus `Duration` per representar un període de temps, normalment utilitzat per a temps d`espera del sistema.
///
/// Cada `Duration` està compost per un nombre sencer de segons i una part fraccionària representada en nanosegons.
/// Si el sistema subjacent no admet una precisió de nivell de nanosegons, les API que enllacen un temps d'espera del sistema normalment arrodoniran el nombre de nanosegons.
///
/// ["Durada"] implementa molts traits comuns, inclosos [`Add`], [`Sub`] i altres [`ops`] traits.Implementa [`Default`] retornant un `Duration` de longitud zero.
///
/// [`ops`]: crate::ops
///
/// # Examples
///
/// ```
/// use std::time::Duration;
///
/// let five_seconds = Duration::new(5, 0);
/// let five_seconds_and_five_nanos = five_seconds + Duration::new(0, 5);
///
/// assert_eq!(five_seconds_and_five_nanos.as_secs(), 5);
/// assert_eq!(five_seconds_and_five_nanos.subsec_nanos(), 5);
///
/// let ten_millis = Duration::from_millis(10);
/// ```
///
/// # Format dels valors `Duration`
///
/// `Duration` intencionadament no té una aplicació `Display`, ja que hi ha diverses maneres de formatar períodes de temps per facilitar la llegibilitat humana.
/// `Duration` proporciona un implement `Debug` que mostra la precisió completa del valor.
///
/// La sortida `Debug` utilitza el sufix no ASCII "µs" per a microsegons.
/// Si la sortida del vostre programa pot aparèixer en contextos que no es poden basar en la compatibilitat Unicode completa, us recomanem que formateu vosaltres mateixos objectes `Duration` o bé utilitzeu un crate.
///
///
///
///
///
///
///
#[stable(feature = "duration", since = "1.3.0")]
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Default)]
pub struct Duration {
    secs: u64,
    nanos: u32, // Sempre 0 <=nanos <NANOS_PER_SEC
}

impl Duration {
    /// La durada d`un segon.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::SECOND, Duration::from_secs(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const SECOND: Duration = Duration::from_secs(1);

    /// La durada d`un mil・lisegon.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MILLISECOND, Duration::from_millis(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MILLISECOND: Duration = Duration::from_millis(1);

    /// La durada d`un microsegon.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MICROSECOND, Duration::from_micros(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MICROSECOND: Duration = Duration::from_micros(1);

    /// La durada d`un nanosegon.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::NANOSECOND, Duration::from_nanos(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const NANOSECOND: Duration = Duration::from_nanos(1);

    /// Una durada de zero temps.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// let duration = Duration::ZERO;
    /// assert!(duration.is_zero());
    /// assert_eq!(duration.as_nanos(), 0);
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    pub const ZERO: Duration = Duration::from_nanos(0);

    /// La durada màxima.
    ///
    /// És aproximadament igual a una durada de 584.942.417.355 anys.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MAX, Duration::new(u64::MAX, 1_000_000_000 - 1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MAX: Duration = Duration::new(u64::MAX, NANOS_PER_SEC - 1);

    /// Crea un nou `Duration` a partir del nombre especificat de segons sencers i nanosegons addicionals.
    ///
    /// Si el nombre de nanosegons és superior a 1.000 milions (el nombre de nanosegons en un segon), es traslladarà als segons proporcionats.
    ///
    ///
    /// # Panics
    ///
    /// Aquest constructor serà panic si el transport dels nanosegons desborda el comptador de segons.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let five_seconds = Duration::new(5, 0);
    /// ```
    ///
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn new(secs: u64, nanos: u32) -> Duration {
        let secs = match secs.checked_add((nanos / NANOS_PER_SEC) as u64) {
            Some(secs) => secs,
            None => panic!("overflow in Duration::new"),
        };
        let nanos = nanos % NANOS_PER_SEC;
        Duration { secs, nanos }
    }

    /// Crea un nou `Duration` a partir del nombre especificat de segons sencers.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_secs(5);
    ///
    /// assert_eq!(5, duration.as_secs());
    /// assert_eq!(0, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_secs(secs: u64) -> Duration {
        Duration { secs, nanos: 0 }
    }

    /// Crea un nou `Duration` a partir del nombre especificat de mil・lisegons.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(2569);
    ///
    /// assert_eq!(2, duration.as_secs());
    /// assert_eq!(569_000_000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_millis(millis: u64) -> Duration {
        Duration {
            secs: millis / MILLIS_PER_SEC,
            nanos: ((millis % MILLIS_PER_SEC) as u32) * NANOS_PER_MILLI,
        }
    }

    /// Crea un nou `Duration` a partir del nombre especificat de microsegons.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_000_002);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(2000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_from_micros", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_micros(micros: u64) -> Duration {
        Duration {
            secs: micros / MICROS_PER_SEC,
            nanos: ((micros % MICROS_PER_SEC) as u32) * NANOS_PER_MICRO,
        }
    }

    /// Crea un nou `Duration` a partir del nombre especificat de nanosegons.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_nanos(1_000_000_123);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(123, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_nanos(nanos: u64) -> Duration {
        Duration {
            secs: nanos / (NANOS_PER_SEC as u64),
            nanos: (nanos % (NANOS_PER_SEC as u64)) as u32,
        }
    }

    /// Es torna cert si aquest `Duration` no abasta cap temps.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert!(Duration::ZERO.is_zero());
    /// assert!(Duration::new(0, 0).is_zero());
    /// assert!(Duration::from_nanos(0).is_zero());
    /// assert!(Duration::from_secs(0).is_zero());
    ///
    /// assert!(!Duration::new(1, 1).is_zero());
    /// assert!(!Duration::from_nanos(1).is_zero());
    /// assert!(!Duration::from_secs(1).is_zero());
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    #[inline]
    pub const fn is_zero(&self) -> bool {
        self.secs == 0 && self.nanos == 0
    }

    /// Retorna el nombre de _whole_ segons que conté aquest `Duration`.
    ///
    /// El valor retornat no inclou la part fraccionària (nanosecond) de la durada, que es pot obtenir mitjançant [`subsec_nanos`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_secs(), 5);
    /// ```
    ///
    /// Per determinar el nombre total de segons representat per l `Duration`, utilitzeu `as_secs` en combinació amb [`subsec_nanos`]:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    ///
    /// assert_eq!(5.730023852,
    ///            duration.as_secs() as f64
    ///            + duration.subsec_nanos() as f64 * 1e-9);
    /// ```
    ///
    /// [`subsec_nanos`]: Duration::subsec_nanos
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn as_secs(&self) -> u64 {
        self.secs
    }

    /// Retorna la part fraccionada d'aquest `Duration`, en mil・lisegons sencers.
    ///
    /// Aquest mètode **no** retorna la durada de la representació en mil・lisegons.
    /// El nombre retornat sempre representa una porció fraccionada de segon (és a dir, és inferior a mil).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5432);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_millis(), 432);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_millis(&self) -> u32 {
        self.nanos / NANOS_PER_MILLI
    }

    /// Retorna la part fraccionada d'aquest `Duration`, en microsegons sencers.
    ///
    /// Aquest mètode **no** retorna la durada de la durada quan es representa amb microsegons.
    /// El nombre retornat sempre representa una porció fraccionada d'un segon (és a dir, és inferior a un milió).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_234_567);
    /// assert_eq!(duration.as_secs(), 1);
    /// assert_eq!(duration.subsec_micros(), 234_567);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_micros(&self) -> u32 {
        self.nanos / NANOS_PER_MICRO
    }

    /// Retorna la part fraccionada d'aquest `Duration`, en nanosegons.
    ///
    /// Aquest mètode **no** retorna la durada de la durada quan està representat per nanosegons.
    /// El nombre retornat sempre representa una porció fraccionada de segon (és a dir, és inferior a mil milions).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5010);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_nanos(), 10_000_000);
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn subsec_nanos(&self) -> u32 {
        self.nanos
    }

    /// Retorna el nombre total de mil・lisegons sencers que conté aquest `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_millis(), 5730);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_millis(&self) -> u128 {
        self.secs as u128 * MILLIS_PER_SEC as u128 + (self.nanos / NANOS_PER_MILLI) as u128
    }

    /// Retorna el nombre total de microsegons sencers que conté aquest `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_micros(), 5730023);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_micros(&self) -> u128 {
        self.secs as u128 * MICROS_PER_SEC as u128 + (self.nanos / NANOS_PER_MICRO) as u128
    }

    /// Retorna el nombre total de nanosegons que conté aquest `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_nanos(), 5730023852);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_nanos(&self) -> u128 {
        self.secs as u128 * NANOS_PER_SEC as u128 + self.nanos as u128
    }

    /// S'ha comprovat l'addició `Duration`.
    /// Calcula `self + other`, retornant [`None`] si es produeix un desbordament.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).checked_add(Duration::new(0, 1)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(1, 0).checked_add(Duration::new(u64::MAX, 0)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_add(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_add(rhs.secs) {
            let mut nanos = self.nanos + rhs.nanos;
            if nanos >= NANOS_PER_SEC {
                nanos -= NANOS_PER_SEC;
                if let Some(new_secs) = secs.checked_add(1) {
                    secs = new_secs;
                } else {
                    return None;
                }
            }
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// Addició saturada de `Duration`.
    /// Calcula `self + other`, retornant [`Duration::MAX`] si es produeix un desbordament.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).saturating_add(Duration::new(0, 1)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(1, 0).saturating_add(Duration::new(u64::MAX, 0)), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_add(self, rhs: Duration) -> Duration {
        match self.checked_add(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// S'ha comprovat la resta `Duration`.
    /// Calcula `self - other`, retornant [`None`] si el resultat seria negatiu o si es produïa un desbordament.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).checked_sub(Duration::new(0, 0)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(0, 0).checked_sub(Duration::new(0, 1)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_sub(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_sub(rhs.secs) {
            let nanos = if self.nanos >= rhs.nanos {
                self.nanos - rhs.nanos
            } else {
                if let Some(sub_secs) = secs.checked_sub(1) {
                    secs = sub_secs;
                    self.nanos + NANOS_PER_SEC - rhs.nanos
                } else {
                    return None;
                }
            };
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// Resta saturant de `Duration`.
    /// Calcula `self - other`, retornant [`Duration::ZERO`] si el resultat seria negatiu o si es produïa un desbordament.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).saturating_sub(Duration::new(0, 0)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(0, 0).saturating_sub(Duration::new(0, 1)), Duration::ZERO);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_sub(self, rhs: Duration) -> Duration {
        match self.checked_sub(rhs) {
            Some(res) => res,
            None => Duration::ZERO,
        }
    }

    /// Comprovació de la multiplicació `Duration`.
    /// Calcula `self * other`, retornant [`None`] si es produeix un desbordament.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).checked_mul(2), Some(Duration::new(1, 2)));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).checked_mul(2), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_mul(self, rhs: u32) -> Option<Duration> {
        // Multipliqueu els nanosegons com a u64, perquè no es pot desbordar d'aquesta manera.
        let total_nanos = self.nanos as u64 * rhs as u64;
        let extra_secs = total_nanos / (NANOS_PER_SEC as u64);
        let nanos = (total_nanos % (NANOS_PER_SEC as u64)) as u32;
        if let Some(s) = self.secs.checked_mul(rhs as u64) {
            if let Some(secs) = s.checked_add(extra_secs) {
                debug_assert!(nanos < NANOS_PER_SEC);
                return Some(Duration { secs, nanos });
            }
        }
        None
    }

    /// Multiplicació `Duration` saturada.
    /// Calcula `self * other`, retornant [`Duration::MAX`] si es produeix un desbordament.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).saturating_mul(2), Duration::new(1, 2));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).saturating_mul(2), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_mul(self, rhs: u32) -> Duration {
        match self.checked_mul(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// S'ha comprovat la divisió `Duration`.
    /// Calcula `self / other`, retornant [`None`] si `other == 0`.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(2, 0).checked_div(2), Some(Duration::new(1, 0)));
    /// assert_eq!(Duration::new(1, 0).checked_div(2), Some(Duration::new(0, 500_000_000)));
    /// assert_eq!(Duration::new(2, 0).checked_div(0), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_div(self, rhs: u32) -> Option<Duration> {
        if rhs != 0 {
            let secs = self.secs / (rhs as u64);
            let carry = self.secs - secs * (rhs as u64);
            let extra_nanos = carry * (NANOS_PER_SEC as u64) / (rhs as u64);
            let nanos = self.nanos / rhs + (extra_nanos as u32);
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// Retorna el nombre de segons que conté aquest `Duration` com a `f64`.
    /// El valor retornat inclou la part fraccionària (nanosecond) de la durada.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f64(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f64(&self) -> f64 {
        (self.secs as f64) + (self.nanos as f64) / (NANOS_PER_SEC as f64)
    }

    /// Retorna el nombre de segons que conté aquest `Duration` com a `f32`.
    /// El valor retornat inclou la part fraccionària (nanosecond) de la durada.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f32(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f32(&self) -> f32 {
        (self.secs as f32) + (self.nanos as f32) / (NANOS_PER_SEC as f32)
    }

    /// Crea un nou `Duration` a partir del nombre especificat de segons representat com a `f64`.
    ///
    /// # Panics
    /// Aquest constructor serà panic si `secs` no és finit, negatiu o desborda `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f64(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f64(secs: f64) -> Duration {
        const MAX_NANOS_F64: f64 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f64;
        let nanos = secs * (NANOS_PER_SEC as f64);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F64 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// Crea un nou `Duration` a partir del nombre especificat de segons representat com a `f32`.
    ///
    /// # Panics
    /// Aquest constructor serà panic si `secs` no és finit, negatiu o desborda `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f32(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f32(secs: f32) -> Duration {
        const MAX_NANOS_F32: f32 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f32;
        let nanos = secs * (NANOS_PER_SEC as f32);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F32 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// Multiplies `Duration` per `f64`.
    /// # Panics
    /// Aquest mètode serà panic si el resultat no és finit, negatiu o desborda `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.mul_f64(3.14), Duration::new(8, 478_000_000));
    /// assert_eq!(dur.mul_f64(3.14e5), Duration::new(847_800, 0));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(rhs * self.as_secs_f64())
    }

    /// Multiplies `Duration` per `f32`.
    /// # Panics
    /// Aquest mètode serà panic si el resultat no és finit, negatiu o desborda `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // tingueu en compte que, a causa d'errors d'arrodoniment, el resultat és lleugerament diferent de l 8.478 i el 847800.0
    /////
    /// assert_eq!(dur.mul_f32(3.14), Duration::new(8, 478_000_640));
    /// assert_eq!(dur.mul_f32(3.14e5), Duration::new(847799, 969_120_256));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(rhs * self.as_secs_f32())
    }

    /// Divideix `Duration` per `f64`.
    /// # Panics
    /// Aquest mètode serà panic si el resultat no és finit, negatiu o desborda `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.div_f64(3.14), Duration::new(0, 859_872_611));
    /// // tingueu en compte que s`utilitza truncament, no arrodoniment
    /// assert_eq!(dur.div_f64(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(self.as_secs_f64() / rhs)
    }

    /// Divideix `Duration` per `f32`.
    /// # Panics
    /// Aquest mètode serà panic si el resultat no és finit, negatiu o desborda `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // tingueu en compte que, a causa d'errors d'arrodoniment, el resultat és lleugerament diferent del 0.859_872_611
    /////
    /// assert_eq!(dur.div_f32(3.14), Duration::new(0, 859_872_576));
    /// // tingueu en compte que s`utilitza truncament, no arrodoniment
    /// assert_eq!(dur.div_f32(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(self.as_secs_f32() / rhs)
    }

    /// Divideix `Duration` per `Duration` i torna `f64`.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f64(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f64(self, rhs: Duration) -> f64 {
        self.as_secs_f64() / rhs.as_secs_f64()
    }

    /// Divideix `Duration` per `Duration` i torna `f32`.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f32(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f32(self, rhs: Duration) -> f32 {
        self.as_secs_f32() / rhs.as_secs_f32()
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Add for Duration {
    type Output = Duration;

    fn add(self, rhs: Duration) -> Duration {
        self.checked_add(rhs).expect("overflow when adding durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl AddAssign for Duration {
    fn add_assign(&mut self, rhs: Duration) {
        *self = *self + rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Sub for Duration {
    type Output = Duration;

    fn sub(self, rhs: Duration) -> Duration {
        self.checked_sub(rhs).expect("overflow when subtracting durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl SubAssign for Duration {
    fn sub_assign(&mut self, rhs: Duration) {
        *self = *self - rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Mul<u32> for Duration {
    type Output = Duration;

    fn mul(self, rhs: u32) -> Duration {
        self.checked_mul(rhs).expect("overflow when multiplying duration by scalar")
    }
}

#[stable(feature = "symmetric_u32_duration_mul", since = "1.31.0")]
impl Mul<Duration> for u32 {
    type Output = Duration;

    fn mul(self, rhs: Duration) -> Duration {
        rhs * self
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl MulAssign<u32> for Duration {
    fn mul_assign(&mut self, rhs: u32) {
        *self = *self * rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Div<u32> for Duration {
    type Output = Duration;

    fn div(self, rhs: u32) -> Duration {
        self.checked_div(rhs).expect("divide by zero error when dividing duration by scalar")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl DivAssign<u32> for Duration {
    fn div_assign(&mut self, rhs: u32) {
        *self = *self / rhs;
    }
}

macro_rules! sum_durations {
    ($iter:expr) => {{
        let mut total_secs: u64 = 0;
        let mut total_nanos: u64 = 0;

        for entry in $iter {
            total_secs =
                total_secs.checked_add(entry.secs).expect("overflow in iter::sum over durations");
            total_nanos = match total_nanos.checked_add(entry.nanos as u64) {
                Some(n) => n,
                None => {
                    total_secs = total_secs
                        .checked_add(total_nanos / NANOS_PER_SEC as u64)
                        .expect("overflow in iter::sum over durations");
                    (total_nanos % NANOS_PER_SEC as u64) + entry.nanos as u64
                }
            };
        }
        total_secs = total_secs
            .checked_add(total_nanos / NANOS_PER_SEC as u64)
            .expect("overflow in iter::sum over durations");
        total_nanos = total_nanos % NANOS_PER_SEC as u64;
        Duration { secs: total_secs, nanos: total_nanos as u32 }
    }};
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl Sum for Duration {
    fn sum<I: Iterator<Item = Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl<'a> Sum<&'a Duration> for Duration {
    fn sum<I: Iterator<Item = &'a Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_debug_impl", since = "1.27.0")]
impl fmt::Debug for Duration {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        /// Formata un número de coma flotant en notació decimal.
        ///
        /// El número es dóna com a `integer_part` i una part fraccionada.
        /// El valor de la part fraccionària és `fractional_part / divisor`.
        /// Per tant, `integer_part` =3, `fractional_part` =12 i `divisor` =100 representa el nombre `3.012`.
        /// S'ometen zeros finals.
        ///
        /// `divisor` no ha de ser superior a 100_000_000.
        /// També hauria de ser una potència de 10, tota la resta no té sentit.
        /// `fractional_part` ha de ser inferior a `10 * divisor`.
        fn fmt_decimal(
            f: &mut fmt::Formatter<'_>,
            mut integer_part: u64,
            mut fractional_part: u32,
            mut divisor: u32,
        ) -> fmt::Result {
            // Codifiqueu la part fraccionària en una memòria intermèdia temporal.
            // El buffer només ha de contenir 9 elements, perquè `fractional_part` ha de ser inferior a 10 ^ 9.
            //
            // La memòria intermèdia es completa amb dígits '0' per simplificar el codi següent.
            let mut buf = [b'0'; 9];

            // El següent dígit s`escriu en aquesta posició
            let mut pos = 0;

            // Continuem escrivint dígits a la memòria intermèdia mentre queden dígits diferents de zero i encara no hem escrit prou dígits.
            //
            while fractional_part > 0 && pos < f.precision().unwrap_or(9) {
                // Escriviu un nou dígit al buffer
                buf[pos] = b'0' + (fractional_part / divisor) as u8;

                fractional_part %= divisor;
                divisor /= 10;
                pos += 1;
            }

            // Si s`especifica una precisió <9, pot haver-hi alguns dígits diferents de zero que no s`hagin escrit al buffer.
            // En aquest cas, hem de realitzar arrodoniments perquè coincideixin amb la semàntica d`imprimir números normals de coma flotant.
            // Tot i això, només hem de fer feina quan arrodoneixem cap amunt.
            // Això passa si el primer dígit dels restants és>=5.
            //
            //
            if fractional_part > 0 && fractional_part >= divisor * 5 {
                // Arrodoneu el número que conté el buffer.
                // Passem pel buffer cap enrere i seguim el transport.
                let mut rev_pos = pos;
                let mut carry = true;
                while carry && rev_pos > 0 {
                    rev_pos -= 1;

                    // Si el dígit de la memòria intermèdia no és '9', només haurem d`incrementar-lo i ja podem aturar-lo (ja que ja no tenim cap transport).
                    // En cas contrari, el configurem a '0' (overflow) i continuem.
                    //
                    //
                    if buf[rev_pos] < b'9' {
                        buf[rev_pos] += 1;
                        carry = false;
                    } else {
                        buf[rev_pos] = b'0';
                    }
                }

                // Si encara tenim el bit de port definit, vol dir que establim la memòria intermèdia sencera a '0 i necessitem incrementar la part sencera.
                //
                //
                if carry {
                    integer_part += 1;
                }
            }

            // Determineu el final de la memòria intermèdia: si s`estableix la precisió, només farem servir tants dígits de la memòria intermèdia (amb límit de 9).
            // Si no està configurat, només fem servir tots els dígits fins a l'últim que no sigui zero.
            //
            let end = f.precision().map(|p| crate::cmp::min(p, 9)).unwrap_or(pos);

            // Si no hem emès cap dígit fraccionari i la precisió no s'ha definit en un valor diferent de zero, no imprimirem el punt decimal.
            //
            if end == 0 {
                write!(f, "{}", integer_part)
            } else {
                // SEGURETAT: només estem escrivint dígits ASCII al buffer i així va ser
                // inicialitzat amb '0', de manera que conté UTF8 vàlid.
                let s = unsafe { crate::str::from_utf8_unchecked(&buf[..end]) };

                // Si l'usuari sol・licita una precisió> 9, al final finalitzem els 0.
                let w = f.precision().unwrap_or(pos);
                write!(f, "{}.{:0<width$}", integer_part, s, width = w)
            }
        }

        // Imprimiu el signe '+' principal si se sol・licita
        if f.sign_plus() {
            write!(f, "+")?;
        }

        if self.secs > 0 {
            fmt_decimal(f, self.secs, self.nanos, NANOS_PER_SEC / 10)?;
            f.write_str("s")
        } else if self.nanos >= NANOS_PER_MILLI {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MILLI) as u64,
                self.nanos % NANOS_PER_MILLI,
                NANOS_PER_MILLI / 10,
            )?;
            f.write_str("ms")
        } else if self.nanos >= NANOS_PER_MICRO {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MICRO) as u64,
                self.nanos % NANOS_PER_MICRO,
                NANOS_PER_MICRO / 10,
            )?;
            f.write_str("µs")
        } else {
            fmt_decimal(f, self.nanos as u64, 0, 1)?;
            f.write_str("ns")
        }
    }
}