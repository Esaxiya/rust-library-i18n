Panics el fil actual.

Això permet que un programa finalitzi immediatament i proporcioni comentaris a qui truca del programa.
`panic!` s'hauria d'utilitzar quan un programa arriba a un estat irrecuperable.

Aquesta macro és la manera perfecta d`afirmar condicions en exemples de codi i en proves.
`panic!` està estretament lligat amb el mètode `unwrap` de les enumeracions [`Option`][ounwrap] i [`Result`][runwrap].
Les dues implementacions criden `panic!` quan estan configurades en variants [`None`] o [`Err`].

Quan utilitzeu `panic!()`, podeu especificar una càrrega útil de cadena que es construeix mitjançant la sintaxi [`format!`].
Aquesta càrrega útil s'utilitza quan s'injecta el panic al fil Rust de trucada, cosa que provoca que el fil sigui totalment panic.

El comportament del `std` hook per defecte, és a dir
el codi que s'executa directament després d'invocar el panic és imprimir la càrrega útil del missatge a `stderr` juntament amb la informació file/line/column de la trucada `panic!()`.

Podeu anul・lar el panic hook amb [`std::panic::set_hook()`].
Dins del hook es pot accedir a un panic com un `&dyn Any + Send`, que conté un `&str` o un `String` per a invocacions `panic!()` habituals.
Per a panic amb un valor d'un altre tipus, es pot utilitzar [`panic_any`].

[`Result`] enum sol ser una millor solució per recuperar-se dels errors que utilitzar la macro `panic!`.
Aquesta macro s'ha d'utilitzar per evitar continuar utilitzant valors incorrectes, com ara de fonts externes.
Trobareu informació detallada sobre la gestió d`errors al [book].

Vegeu també la macro [`compile_error!`] per obtenir errors durant la compilació.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Implementació actual

Si el fil principal panics finalitzarà tots els vostres fils i acabarà el programa amb el codi `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





