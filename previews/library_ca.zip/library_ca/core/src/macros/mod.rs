#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // S'expandeix a `$crate::panic::panic_2015` o `$crate::panic::panic_2021` en funció de l'edició de la persona que truca.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Afirma que dues expressions són iguals entre si (amb [`PartialEq`]).
///
/// A panic, aquesta macro imprimirà els valors de les expressions amb les seves representacions de depuració.
///
///
/// Igual que [`assert!`], aquesta macro té un segon formulari, on es pot proporcionar un missatge panic personalitzat.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Els reborrows següents són intencionats.
                    // Sense ells, la ranura de la pila del préstec s`inicialitza fins i tot abans de comparar els valors, cosa que provoca una desacceleració notable.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Els reborrows següents són intencionats.
                    // Sense ells, la ranura de la pila del préstec s`inicialitza fins i tot abans de comparar els valors, cosa que provoca una desacceleració notable.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Afirma que dues expressions no són iguals entre si (amb [`PartialEq`]).
///
/// A panic, aquesta macro imprimirà els valors de les expressions amb les seves representacions de depuració.
///
///
/// Igual que [`assert!`], aquesta macro té un segon formulari, on es pot proporcionar un missatge panic personalitzat.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Els reborrows següents són intencionats.
                    // Sense ells, la ranura de la pila del préstec s`inicialitza fins i tot abans de comparar els valors, cosa que provoca una desacceleració notable.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Els reborrows següents són intencionats.
                    // Sense ells, la ranura de la pila del préstec s`inicialitza fins i tot abans de comparar els valors, cosa que provoca una desacceleració notable.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Afirma que una expressió booleana és `true` en temps d'execució.
///
/// Això invocarà la macro [`panic!`] si l'expressió proporcionada no es pot avaluar a `true` en temps d'execució.
///
/// Igual que [`assert!`], aquesta macro també té una segona versió, on es pot proporcionar un missatge panic personalitzat.
///
/// # Uses
///
/// A diferència de [`assert!`], les sentències `debug_assert!` només estan habilitades per defecte en versions no optimitzades.
/// Una compilació optimitzada no executarà sentències `debug_assert!` tret que `-C debug-assertions` es passi al compilador.
/// Això fa que `debug_assert!` sigui útil per a comprovacions massa costoses per a ser presents en una versió de versió, però que poden ser útils durant el desenvolupament.
/// Sempre es comprova el resultat de l'expansió de `debug_assert!`.
///
/// Una afirmació sense comprovar permet que un programa en un estat inconsistent continuï executant-se, cosa que pot tenir conseqüències inesperades, però no introdueix inseguretat sempre que això només passi en el codi segur.
///
/// No obstant això, el cost de rendiment de les afirmacions no es mesura en general.
/// Per tant, només es recomana substituir [`assert!`] per `debug_assert!` després d'un perfilat complet i, el que és més important, només amb un codi segur.
///
/// # Examples
///
/// ```
/// // el missatge panic per a aquestes afirmacions és el valor encadenat de l'expressió donada.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // una funció molt senzilla
/// debug_assert!(some_expensive_computation());
///
/// // afirmar amb un missatge personalitzat
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Afirma que dues expressions són iguals entre si.
///
/// A panic, aquesta macro imprimirà els valors de les expressions amb les seves representacions de depuració.
///
/// A diferència de [`assert_eq!`], les sentències `debug_assert_eq!` només estan habilitades per defecte en versions no optimitzades.
/// Una compilació optimitzada no executarà sentències `debug_assert_eq!` tret que `-C debug-assertions` es passi al compilador.
/// Això fa que `debug_assert_eq!` sigui útil per a comprovacions massa costoses per a ser presents en una versió de versió, però que poden ser útils durant el desenvolupament.
///
/// Sempre es comprova el resultat de l'expansió de `debug_assert_eq!`.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Afirma que dues expressions no són iguals entre si.
///
/// A panic, aquesta macro imprimirà els valors de les expressions amb les seves representacions de depuració.
///
/// A diferència de [`assert_ne!`], les sentències `debug_assert_ne!` només estan habilitades per defecte en versions no optimitzades.
/// Una compilació optimitzada no executarà sentències `debug_assert_ne!` tret que `-C debug-assertions` es passi al compilador.
/// Això fa que `debug_assert_ne!` sigui útil per a comprovacions massa costoses per a ser presents en una versió de versió, però que poden ser útils durant el desenvolupament.
///
/// Sempre es comprova el resultat de l'expansió de `debug_assert_ne!`.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Retorna si l'expressió donada coincideix amb algun dels patrons donats.
///
/// Igual que en una expressió `match`, el patró es pot seguir opcionalment per `if` i una expressió de protecció que tingui accés a noms lligats pel patró.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Desenfoca un resultat o propaga el seu error.
///
/// S'ha afegit l'operador `?` per substituir `try!` i s'hauria d'utilitzar en el seu lloc.
/// A més, `try` és una paraula reservada a Rust 2018, de manera que, si l`heu d`utilitzar, haureu d`utilitzar el [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` coincideix amb el [`Result`] donat.En el cas de la variant `Ok`, l'expressió té el valor del valor ajustat.
///
/// En el cas de la variant `Err`, recupera l`error intern.A continuació, `try!` realitza la conversió mitjançant `From`.
/// Això proporciona una conversió automàtica entre errors especialitzats i errors més generals.
/// L'error resultant es torna immediatament.
///
/// A causa del retorn anticipat, `try!` només es pot utilitzar en funcions que retornen [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // El mètode preferit per retornar ràpidament els errors
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // El mètode anterior d'errors de retorn ràpid
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Això equival a:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Escriu dades formatades en una memòria intermèdia.
///
/// Aquesta macro accepta un 'writer', una cadena de format i una llista d'arguments.
/// Els arguments es formataran segons la cadena de format especificada i el resultat es passarà a l'escriptor.
/// L'escriptor pot tenir qualsevol valor amb un mètode `write_fmt`;en general, això prové d'una implementació del [`fmt::Write`] o del [`io::Write`] trait.
/// La macro retorna el que retorni el mètode `write_fmt`;normalment un [`fmt::Result`] o un [`io::Result`].
///
/// Vegeu [`std::fmt`] per obtenir més informació sobre la sintaxi de la cadena de format.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Un mòdul pot importar tant `std::fmt::Write` com `std::io::Write` i trucar a `write!` en objectes que implementin qualsevol, ja que els objectes normalment no implementen tots dos.
///
/// Tot i això, el mòdul ha d`importar el traits qualificat perquè els seus noms no entrin en conflicte:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // utilitza fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // utilitza io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Aquesta macro també es pot utilitzar en configuracions de `no_std`.
/// En una configuració de `no_std`, sou responsable dels detalls d`implementació dels components.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Escriviu dades formatades a una memòria intermèdia, amb una nova línia afegida.
///
/// A totes les plataformes, la nova línia és només el caràcter LINE FEED (`\n`/`U+000A`) (no hi ha CARRIAGE RETURN (`\r`/`U+000D`) addicional.
///
/// Per obtenir més informació, consulteu [`write!`].Per obtenir informació sobre la sintaxi de la cadena de format, consulteu [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Un mòdul pot importar tant `std::fmt::Write` com `std::io::Write` i trucar a `write!` en objectes que implementin qualsevol, ja que els objectes normalment no implementen tots dos.
/// Tot i això, el mòdul ha d`importar el traits qualificat perquè els seus noms no entrin en conflicte:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // utilitza fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // utilitza io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Indica un codi inaccessible.
///
/// Això és útil sempre que el compilador no pugui determinar que no es pugui accedir a cap codi.Per exemple:
///
/// * Coincideix els braços amb les condicions de protecció.
/// * Bucles que finalitzen dinàmicament.
/// * Iteradors que finalitzen dinàmicament.
///
/// Si la determinació que no es pot accedir al codi resulta incorrecte, el programa finalitza immediatament amb un [`panic!`].
///
/// La contrapartida insegura d'aquesta macro és la funció [`unreachable_unchecked`], que provocarà un comportament indefinit si s'arriba al codi.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Això sempre serà [`panic!`].
///
/// # Examples
///
/// Braços de partit:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // error de compilació si es comenta
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // una de les implementacions més pobres de x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Indica el codi no implementat en pànic amb un missatge de "not implemented".
///
/// Això permet que el vostre codi faci una comprovació de tipus, cosa que és útil si feu prototips o implementeu un trait que requereixi diversos mètodes que no teniu previst utilitzar tots.
///
/// La diferència entre `unimplemented!` i [`todo!`] és que, mentre que `todo!` transmet la intenció d`implementar la funcionalitat més endavant i el missatge és "not yet implemented", `unimplemented!` no fa cap afirmació.
/// El seu missatge és "not implemented".
/// També alguns IDE marcaran "tot!" S.
///
/// # Panics
///
/// Això sempre serà [`panic!`] perquè `unimplemented!` és només una abreviatura de `panic!` amb un missatge específic fix.
///
/// Igual que `panic!`, aquesta macro té un segon formulari per mostrar valors personalitzats.
///
/// # Examples
///
/// Suposem que tenim un trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Volem implementar `Foo` per a 'MyStruct', però per alguna raó només té sentit implementar la funció `bar()`.
/// `baz()` i `qux()` encara haurà de ser definit a la nostra implementació de `Foo`, però podem utilitzar `unimplemented!` a les seves definicions per permetre que el nostre codi es compili.
///
/// Encara volem que el nostre programa deixi d`executar-se si s`assoleixen els mètodes no implementats.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // No té cap sentit per a `baz` un `MyStruct`, de manera que no tenim cap lògica aquí.
/////
///         // Es mostrarà "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Aquí tenim una lògica, podem afegir un missatge a no implementat.per mostrar la nostra omissió.
///         // Es mostrarà: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Indica el codi inacabat.
///
/// Això pot ser útil si feu prototipus i només voleu comprovar el vostre tipus de codi.
///
/// La diferència entre [`unimplemented!`] i `todo!` és que, mentre que `todo!` transmet la intenció d`implementar la funcionalitat més endavant i el missatge és "not yet implemented", `unimplemented!` no fa cap afirmació.
/// El seu missatge és "not implemented".
/// També alguns IDE marcaran "tot!" S.
///
/// # Panics
///
/// Això sempre serà [`panic!`].
///
/// # Examples
///
/// Aquí teniu un exemple d'algun codi en curs.Tenim un trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Volem implementar `Foo` en un dels nostres tipus, però també volem treballar només amb `bar()`.Per tal que es compili el nostre codi, hem d`implementar `baz()`, de manera que puguem utilitzar `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // la implementació va aquí
///     }
///
///     fn baz(&self) {
///         // no ens preocupem per implementar baz() per ara
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // ni tan sols utilitzem baz(), així que està bé.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definicions de macros integrades.
///
/// La majoria de les propietats de la macro (estabilitat, visibilitat, etc.) s`extreuen del codi font aquí, a excepció de les funcions d`expansió que transformen les entrades de macro en sortides, aquestes funcions les proporciona el compilador.
///
///
pub(crate) mod builtin {

    /// Fa que la compilació falli amb el missatge d'error donat quan es troba.
    ///
    /// Aquesta macro s'hauria d'utilitzar quan un crate utilitza una estratègia de compilació condicional per proporcionar millors missatges d'error en condicions errònies.
    ///
    /// És la forma de compilador de [`panic!`], però emet un error durant la *compilació* en lloc del *temps d'execució*.
    ///
    /// # Examples
    ///
    /// Dos exemples d`aquest tipus són les macros i els entorns `#[cfg]`.
    ///
    /// Emetre un millor error del compilador si es passa una macro a valors no vàlids
    /// Sense el branch final, el compilador encara emetria un error, però el missatge de l`error no mencionaria els dos valors vàlids.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Emet un error del compilador si una de les funcions no està disponible.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Construeix paràmetres per a les altres macros de format de cadena.
    ///
    /// Aquesta macro funciona prenent una cadena literal de format que conté `{}` per a cada argument addicional passat.
    /// `format_args!` prepara els paràmetres addicionals per garantir que la sortida es pugui interpretar com una cadena i canonitzi els arguments en un sol tipus.
    /// Qualsevol valor que implementi [`Display`] trait es pot passar a `format_args!`, igual que qualsevol implementació [`Debug`] es pot passar a un `{:?}` dins de la cadena de format.
    ///
    ///
    /// Aquesta macro produeix un valor del tipus [`fmt::Arguments`].Aquest valor es pot passar a les macros de [`std::fmt`] per realitzar una redirecció útil.
    /// Totes les altres macros de format ([`format!`], [`write!`], [`println!`], etc.) es representen mitjançant aquesta.
    /// `format_args!`, a diferència de les seves macros derivades, evita les assignacions de pila.
    ///
    /// Podeu utilitzar el valor [`fmt::Arguments`] que retorna `format_args!` en contextos `Debug` i `Display`, tal com es mostra a continuació.
    /// L'exemple també mostra que els formats `Debug` i `Display` tenen el mateix: la cadena de format interpolada a `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Per obtenir més informació, consulteu la documentació a [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Igual que `format_args`, però al final afegeix una nova línia.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Inspecciona una variable d'entorn en temps de compilació.
    ///
    /// Aquesta macro s'ampliarà fins al valor de la variable d'entorn anomenada en el moment de la compilació, donant una expressió de tipus `&'static str`.
    ///
    ///
    /// Si la variable d'entorn no està definida, s'emetrà un error de compilació.
    /// Per no emetre cap error de compilació, utilitzeu la macro [`option_env!`].
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Podeu personalitzar el missatge d'error passant una cadena com a segon paràmetre:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Si la variable d'entorn `documentation` no està definida, obtindreu l'error següent:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Opcionalment inspecciona una variable d'entorn en temps de compilació.
    ///
    /// Si la variable d'entorn anomenada és present en el moment de la compilació, aquesta s'expandirà a una expressió de tipus `Option<&'static str>` el valor de la qual sigui `Some` del valor de la variable d'entorn.
    /// Si la variable d'entorn no és present, s'ampliarà fins a `None`.
    /// Consulteu [`Option<T>`][Option] per obtenir més informació sobre aquest tipus.
    ///
    /// Mai s`emet un error de temps de compilació quan s`utilitza aquesta macro, independentment de si la variable d`entorn és present o no.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatena els identificadors en un identificador.
    ///
    /// Aquesta macro pren qualsevol nombre d'identificadors separats per comes i els concatena tots en un, donant una expressió que és un identificador nou.
    /// Tingueu en compte que la higiene fa que aquesta macro no pugui capturar variables locals.
    /// A més, com a regla general, les macros només es permeten en posicions d`elements, sentències o expressions.
    /// Això vol dir que, tot i que podeu utilitzar aquesta macro per referir-vos a variables, funcions o mòduls existents, etc., no en podeu definir una de nova.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (novetat, diversió, nom) { }//no es pot utilitzar d'aquesta manera!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatena els literals en un segment de cadena estàtica.
    ///
    /// Aquesta macro pren qualsevol nombre de literals separats per comes, donant una expressió de tipus `&'static str` que representa tots els literals concatenats d'esquerra a dreta.
    ///
    ///
    /// Els literals de punt enter i flotant s`ordenen per poder concatenar-se.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// S'expandeix al número de línia en què s'ha invocat.
    ///
    /// Amb [`column!`] i [`file!`], aquestes macros proporcionen informació de depuració per als desenvolupadors sobre la ubicació dins de la font.
    ///
    /// L'expressió ampliada té tipus `u32` i es basa en 1, de manera que la primera línia de cada fitxer avalua a 1, la segona a 2, etc.
    /// Això és coherent amb els missatges d'error dels compiladors habituals o dels editors populars.
    /// La línia retornada *no és necessàriament* la línia de la mateixa invocació `line!`, sinó la primera invocació de macro que condueix a la invocació de la macro `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// S'expandeix al número de columna en què s'ha invocat.
    ///
    /// Amb [`line!`] i [`file!`], aquestes macros proporcionen informació de depuració per als desenvolupadors sobre la ubicació dins de la font.
    ///
    /// L`expressió ampliada té el tipus `u32` i es basa en 1, de manera que la primera columna de cada línia s`avalua a 1, la segona a 2, etc.
    /// Això és coherent amb els missatges d'error dels compiladors habituals o dels editors populars.
    /// La columna retornada *no és necessàriament* la línia de la mateixa invocació `column!`, sinó la primera invocació de macro que condueix a la invocació de la macro `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// S'expandeix al nom del fitxer en què s'ha invocat.
    ///
    /// Amb [`line!`] i [`column!`], aquestes macros proporcionen informació de depuració per als desenvolupadors sobre la ubicació dins de la font.
    ///
    /// L'expressió expandida té el tipus `&'static str` i el fitxer retornat no és la invocació de la macro `file!`, sinó la primera invocació de macro que condueix a la invocació de la macro `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringifica els seus arguments.
    ///
    /// Aquesta macro donarà una expressió de tipus `&'static str` que és la stringificació de tots els tokens passats a la macro.
    /// No hi ha restriccions a la sintaxi de la invocació de macro.
    ///
    /// Tingueu en compte que els resultats ampliats de l'entrada tokens poden canviar a future.Heu de tenir precaució si confieu en la sortida.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Inclou un fitxer codificat UTF-8 com a cadena.
    ///
    /// El fitxer es troba en relació amb el fitxer actual (de manera similar a com es troben els mòduls).
    /// El camí proporcionat s`interpreta de manera específica de la plataforma en el moment de la compilació.
    /// Per tant, per exemple, una invocació amb un camí Windows que contingui barres ininterrompudes `\` no es compilaria correctament a Unix.
    ///
    ///
    /// Aquesta macro donarà una expressió de tipus `&'static str` que és el contingut del fitxer.
    ///
    /// # Examples
    ///
    /// Suposem que hi ha dos fitxers al mateix directori amb el contingut següent:
    ///
    /// Fitxer 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fitxer 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Si compileu 'main.rs' i executeu el binari resultant, s`imprimirà "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inclou un fitxer com a referència a una matriu de bytes.
    ///
    /// El fitxer es troba en relació amb el fitxer actual (de manera similar a com es troben els mòduls).
    /// El camí proporcionat s`interpreta de manera específica de la plataforma en el moment de la compilació.
    /// Per tant, per exemple, una invocació amb un camí Windows que contingui barres ininterrompudes `\` no es compilaria correctament a Unix.
    ///
    ///
    /// Aquesta macro donarà una expressió de tipus `&'static [u8; N]` que és el contingut del fitxer.
    ///
    /// # Examples
    ///
    /// Suposem que hi ha dos fitxers al mateix directori amb el contingut següent:
    ///
    /// Fitxer 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fitxer 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Si compileu 'main.rs' i executeu el binari resultant, s`imprimirà "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// S'expandeix a una cadena que representa la ruta del mòdul actual.
    ///
    /// El camí actual del mòdul es pot considerar com la jerarquia dels mòduls que porten a la còpia de seguretat del crate root.
    /// El primer component del camí retornat és el nom del crate que s'està compilant actualment.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Avalua les combinacions booleanes de senyaladors de configuració en temps de compilació.
    ///
    /// A més de l'atribut `#[cfg]`, aquesta macro es proporciona per permetre l'avaluació de l'expressió booleana dels indicadors de configuració.
    /// Això sovint condueix a un codi menys duplicat.
    ///
    /// La sintaxi donada a aquesta macro és la mateixa sintaxi que l'atribut [`cfg`].
    ///
    /// `cfg!`, a diferència de `#[cfg]`, no elimina cap codi i només es valora com a vertader o fals.
    /// Per exemple, tots els blocs d'una expressió if/else han de ser vàlids quan s'utilitza `cfg!` per a la condició, independentment del que estigui avaluant `cfg!`.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Analitza un fitxer com a expressió o element segons el context.
    ///
    /// El fitxer es troba en relació amb el fitxer actual (de manera similar a com es troben els mòduls).El camí proporcionat s`interpreta de manera específica de la plataforma en el moment de la compilació.
    /// Per tant, per exemple, una invocació amb un camí Windows que contingui barres ininterrompudes `\` no es compilaria correctament a Unix.
    ///
    /// L`ús d`aquesta macro sovint és una mala idea, perquè si el fitxer s`analitza com a expressió, es col・locarà al codi circumdant de forma antihigiènica.
    /// Això podria fer que les variables o funcions siguin diferents del que esperava el fitxer si hi ha variables o funcions que tinguin el mateix nom al fitxer actual.
    ///
    ///
    /// # Examples
    ///
    /// Suposem que hi ha dos fitxers al mateix directori amb el contingut següent:
    ///
    /// Fitxer 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Fitxer 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Si compileu 'main.rs' i executeu el binari resultant, s`imprimirà "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Afirma que una expressió booleana és `true` en temps d'execució.
    ///
    /// Això invocarà la macro [`panic!`] si l'expressió proporcionada no es pot avaluar a `true` en temps d'execució.
    ///
    /// # Uses
    ///
    /// Les afirmacions sempre es comproven tant a les versions de depuració com de versió, i no es poden desactivar.
    /// Consulteu [`debug_assert!`] per obtenir les afirmacions que no estan habilitades a les versions de versions per defecte.
    ///
    /// El codi no segur pot confiar en `assert!` per aplicar invariants en temps d'execució que, si es infringeixen, poden provocar inseguretat.
    ///
    /// Altres casos d'ús de `assert!` inclouen provar i aplicar els invariants en temps d'execució en codi segur (la violació de la qual no pot resultar en seguretat).
    ///
    ///
    /// # Missatges personalitzats
    ///
    /// Aquesta macro té un segon formulari, on es pot proporcionar un missatge panic personalitzat amb o sense arguments per al format.
    /// Consulteu [`std::fmt`] per obtenir la sintaxi d`aquest formulari.
    /// Les expressions utilitzades com a arguments de format només s`avaluaran si l`afirmació falla.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // el missatge panic per a aquestes afirmacions és el valor encadenat de l'expressió donada.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // una funció molt senzilla
    ///
    /// assert!(some_computation());
    ///
    /// // afirmar amb un missatge personalitzat
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Muntatge en línia.
    ///
    /// Llegiu el [unstable book] per utilitzar-lo.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Muntatge en línia d`estil LLVM.
    ///
    /// Llegiu el [unstable book] per utilitzar-lo.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Muntatge en línia a nivell de mòdul.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Les impressions van passar tokens a la sortida estàndard.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Activa o desactiva la funcionalitat de rastreig utilitzada per depurar altres macros.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Macro d`atribut que s`utilitza per aplicar macros derivades.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Macro d'atribut aplicada a una funció per convertir-la en una prova unitària.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Macro d'atribut aplicada a una funció per convertir-la en una prova de referència.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Detall d`implementació de les macros `#[test]` i `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Macro d'atribut aplicada a una estàtica per registrar-la com a assignador global.
    ///
    /// Vegeu també [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Conserva l'element al qual s'aplica si es pot accedir al camí de pas i el elimina d'una altra manera.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Expandeix tots els atributs `#[cfg]` i `#[cfg_attr]` del fragment de codi al qual s'aplica.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// No utilitzeu els detalls d'implementació inestables del compilador `rustc`.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// No utilitzeu els detalls d'implementació inestables del compilador `rustc`.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}