#![stable(feature = "core_hint", since = "1.27.0")]

//! Suggeriments per al compilador que afecten la manera com s`ha d`emetre o optimitzar el codi.
//! Els consells poden ser temps de compilació o temps d'execució.

use crate::intrinsics;

/// Informa al compilador que no es pot arribar a aquest punt del codi, cosa que permet optimitzar més.
///
/// # Safety
///
/// Arribar a aquesta funció és completament *comportament indefinit*(UB).En particular, el compilador assumeix que tota la UB no ha de passar mai i, per tant, eliminarà totes les branques que arribin a una trucada a `unreachable_unchecked()`.
///
/// Com tots els casos d`UB, si aquesta suposició resulta errònia, és a dir, la trucada `unreachable_unchecked()` és realment accessible entre tots els fluxos de control possibles, el compilador aplicarà l`estratègia d`optimització incorrecta i, fins i tot, pot fins i tot corrompre codi aparentment no relacionat, provocant problemes de depuració.
///
///
/// Utilitzeu aquesta funció només quan pugueu demostrar que el codi mai no l'anomenarà.
/// En cas contrari, penseu en utilitzar la macro [`unreachable!`], que no permet optimitzacions, però que panic s'executi.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` sempre és positiu (no zero), per tant, `checked_div` mai no retornarà `None`.
/////
///     // Per tant, la resta branch no és accessible.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SEGURETAT: el contracte de seguretat per a `intrinsics::unreachable` és obligatori
    // ser confirmat per la persona que truca.
    unsafe { intrinsics::unreachable() }
}

/// Emet una instrucció de màquina per indicar al processador que s`executa en un bucle de centrifugació d`espera ocupada ("bloqueig de centrifugat").
///
/// En rebre el senyal de spin-loop, el processador pot optimitzar el seu comportament, per exemple, estalviant energia o canviant els fils hyper.
///
/// Aquesta funció és diferent de [`thread::yield_now`], que cedeix directament al planificador del sistema, mentre que `spin_loop` no interactua amb el sistema operatiu.
///
/// Un cas d'ús comú per a `spin_loop` és implementar un gir optimista acotat en un bucle CAS en primitives de sincronització.
/// Per evitar problemes com la inversió de prioritats, es recomana que el bucle de gir es finalitzi després d'una quantitat finita d'iteracions i es faci un bloqueig apropiat.
///
///
/// **Nota**: a les plataformes que no admeten la recepció de suggeriments de spin-loop, aquesta funció no fa res.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Un valor atòmic compartit que els fils utilitzaran per coordinar-se
/// let live = Arc::new(AtomicBool::new(false));
///
/// // En un fil de fons, finalment establirem el valor
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Feu una mica de feina i, a continuació, feu que el valor sigui viu
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // De tornada al nostre fil actual, esperem a establir el valor
/// while !live.load(Ordering::Acquire) {
///     // El bucle de gir és una pista per a la CPU que estem esperant, però probablement no per molt de temps
/////
///     hint::spin_loop();
/// }
///
/// // El valor està definit
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SEGURETAT: l'attr `cfg` garanteix que només l'executem als objectius x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SEGURETAT: l'attr `cfg` garanteix que només l'executem als objectius x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SEGURETAT: l'attr `cfg` garanteix que només l'executem als objectius aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SEGURETAT: l'attr `cfg` garanteix que només l'executem en objectius de braç
            // amb suport per a la funció v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Una funció d'identitat que *__ fa __* al compilador un pessimisme màxim del que podria fer `black_box`.
///
/// A diferència de [`std::convert::identity`], es recomana a un compilador Rust que assumeixi que `black_box` pot utilitzar `dummy` de qualsevol manera vàlida que es permeti al codi Rust sense introduir comportament indefinit al codi de trucada.
///
/// Aquesta propietat fa que `black_box` sigui útil per escriure codi en què no es desitgin certes optimitzacions, com ara els benchmarks.
///
/// Tingueu en compte, però, que `black_box` només es proporciona (i només es pot proporcionar) en base a "best-effort".La mesura en què pot bloquejar les optimitzacions pot variar en funció de la plataforma i del backend de codi-gen utilitzat.
/// Els programes no poden confiar en `black_box` per a la *correcció* de cap manera.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Necessitem "use", d'alguna manera, l'argument que LLVM no pot introspectar i, en objectius que el suporten, normalment podem aprofitar el muntatge en línia per fer-ho.
    // La interpretació de LLVM del muntatge en línia és que, bé, és una caixa negra.
    // Aquesta no és la implementació més gran, ja que probablement desoptimitza més del que volem, però fins ara és prou bona.
    //
    //

    #[cfg(not(miri))] // Això és només un suggeriment, per tant, està bé saltar-lo a Miri.
    // SEGURETAT: el conjunt en línia és sense operacions.
    unsafe {
        // FIXME: No es pot utilitzar `asm!` perquè no admet MIPS i altres arquitectures.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}