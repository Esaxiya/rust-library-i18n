//! El libcore prelude
//!
//! Aquest mòdul està pensat per a usuaris de libcore que no enllacen també amb libstd.
//! Aquest mòdul s`importa per defecte quan s`utilitza `#![no_std]` de la mateixa manera que el prelude de la biblioteca estàndard.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// La versió 2015 del nucli prelude.
///
/// Vegeu el [module-level documentation](self) per obtenir més informació.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// La versió 2018 del nucli prelude.
///
/// Vegeu el [module-level documentation](self) per obtenir més informació.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// La versió 2021 del nucli prelude.
///
/// Vegeu el [module-level documentation](self) per obtenir més informació.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Afegiu més coses.
}