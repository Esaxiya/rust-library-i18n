//! # La biblioteca bàsica Rust
//!
//! La biblioteca bàsica Rust és la base lliure de dependències [^ free] de [The Rust Standard Library](../std/index.html).
//! És la cola portàtil entre el llenguatge i les seves biblioteques, que defineix els blocs intrínsecs i primitius de tot el codi Rust.
//!
//! No enllaça cap biblioteca de pujada, no hi ha biblioteques del sistema ni hi ha cap libc.
//!
//! [^free]: Strictly parlant, hi ha alguns símbols que són necessaris però
//!          no sempre són necessaris.
//!
//! La biblioteca principal és *mínima*: ni tan sols és conscient de l'assignació de pila, ni proporciona simultàniaitat ni I/O.
//! Aquestes coses requereixen una integració de plataformes i aquesta biblioteca és agnòstica de la plataforma.
//!
//! # Com s'utilitza la biblioteca principal
//!
//! Tingueu en compte que actualment tots aquests detalls no es consideren estables.
//!
//!
//!
// FIXME: Empleneu-me amb més detalls quan es resolgui la interfície
//! Aquesta biblioteca es basa en l'assumpció d'alguns símbols existents:
//!
//! * `memcpy`, `memcmp`, `memset`, són rutines de memòria bàsiques que solen generar LLVM.
//! A més, aquesta biblioteca pot fer trucades explícites a aquestes funcions.
//! Les seves signatures són les mateixes que es troben a C.
//!   Aquestes funcions són sovint proporcionades pel sistema libc, però també les pot proporcionar el [compiler-builtins crate](https://crates.io/crates/compiler_builtins).
//!
//!
//! * `rust_begin_panic` - Aquesta funció té quatre arguments, un `fmt::Arguments`, un `&'static str` i dos `u32`.
//! Aquests quatre arguments dicten el missatge panic, el fitxer en què es va invocar panic i la línia i la columna que hi ha dins del fitxer.
//! Correspon als consumidors d`aquesta biblioteca bàsica definir aquesta funció panic;només es requereix no tornar mai.
//! Això requereix un atribut `lang` anomenat `panic_impl`.
//!
//! * `rust_eh_personality` - és utilitzat pels mecanismes de fallada del compilador.
//! Sovint, això es relaciona amb la funció de personalitat de GCC, però es pot assegurar que crates que no activa un panic no es diu mai a aquesta funció.
//! L'atribut `lang` s'anomena `eh_personality`.
//!
//!
//!

// Com que libcore defineix molts elements fonamentals de llenguatge, totes les proves es publiquen en un crate separat, libcoretest, per evitar problemes estranys.
//
// Aquí explícitament#[cfg]-out de tot aquest crate quan provem.
// Si no ho fem, tant l`artefacte de prova generat com el libtest enllaçat (que inclou transitòriament libcore) definiran el mateix conjunt d`elements de lang i això provocarà l`error E0152 "found duplicate lang item".
//
// Vegeu el debat a #50466 per obtenir més informació.
//
// Aquesta cfg no afectarà les proves del document.
//
//
#![cfg(not(test))]
#![stable(feature = "core", since = "1.6.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![no_core]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(asm)]
#![feature(cfg_target_has_atomic)]
#![feature(const_heap)]
#![feature(const_alloc_layout)]
#![feature(const_assert_type)]
#![feature(const_discriminant)]
#![feature(const_cell_into_inner)]
#![feature(const_intrinsic_copy)]
#![feature(const_intrinsic_forget)]
#![feature(const_float_classify)]
#![feature(const_float_bits_conv)]
#![feature(const_int_unchecked_arith)]
#![feature(const_mut_refs)]
#![feature(const_refs_to_cell)]
#![feature(const_cttz)]
#![feature(const_panic)]
#![feature(const_pin)]
#![feature(const_fn)]
#![feature(const_fn_union)]
#![feature(const_impl_trait)]
#![feature(const_fn_floating_point_arithmetic)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(const_option)]
#![feature(const_precise_live_drops)]
#![feature(const_ptr_offset)]
#![feature(const_ptr_offset_from)]
#![feature(const_ptr_read)]
#![feature(const_ptr_write)]
#![feature(const_raw_ptr_comparison)]
#![feature(const_raw_ptr_deref)]
#![feature(const_slice_from_raw_parts)]
#![feature(const_slice_ptr_len)]
#![feature(const_size_of_val)]
#![feature(const_swap)]
#![feature(const_align_of_val)]
#![feature(const_type_id)]
#![feature(const_type_name)]
#![feature(const_likely)]
#![feature(const_unreachable_unchecked)]
#![feature(const_maybe_uninit_assume_init)]
#![feature(const_maybe_uninit_as_ptr)]
#![feature(custom_inner_attributes)]
#![feature(decl_macro)]
#![feature(doc_cfg)]
#![feature(doc_spotlight)]
#![feature(duration_consts_2)]
#![feature(duration_saturating_ops)]
#![feature(extended_key_value_attributes)]
#![feature(extern_types)]
#![feature(fundamental)]
#![feature(intra_doc_pointers)]
#![feature(intrinsics)]
#![feature(lang_items)]
#![feature(link_llvm_intrinsics)]
#![feature(llvm_asm)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(exhaustive_patterns)]
#![feature(no_core)]
#![feature(auto_traits)]
#![feature(or_patterns)]
#![feature(prelude_import)]
#![cfg_attr(not(bootstrap), feature(ptr_metadata))]
#![feature(repr_simd, platform_intrinsics)]
#![feature(rustc_attrs)]
#![feature(simd_ffi)]
#![feature(min_specialization)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(stmt_expr_attributes)]
#![feature(str_split_as_str)]
#![feature(str_split_inclusive_as_str)]
#![feature(trait_alias)]
#![feature(transparent_unions)]
#![feature(try_blocks)]
#![feature(unboxed_closures)]
#![feature(unsized_fn_params)]
#![feature(unwind_attributes)]
#![feature(variant_count)]
#![feature(tbm_target_feature)]
#![feature(sse4a_target_feature)]
#![feature(arm_target_feature)]
#![feature(powerpc_target_feature)]
#![feature(mips_target_feature)]
#![feature(aarch64_target_feature)]
#![feature(wasm_target_feature)]
#![feature(avx512_target_feature)]
#![feature(cmpxchg16b_target_feature)]
#![feature(rtm_target_feature)]
#![feature(f16c_target_feature)]
#![feature(hexagon_target_feature)]
#![feature(const_fn_transmute)]
#![feature(abi_unadjusted)]
#![feature(adx_target_feature)]
#![feature(external_doc)]
#![feature(associated_type_bounds)]
#![feature(const_caller_location)]
#![feature(slice_ptr_get)]
#![feature(no_niche)] // rust-lang/rust#68303
#![feature(int_error_matching)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![deny(unsafe_op_in_unsafe_fn)]

#[prelude_import]
#[allow(unused)]
use prelude::v1::*;

#[cfg(not(test))] // Vegeu #65860
#[macro_use]
mod macros;

#[macro_use]
mod internal_macros;

#[path = "num/shells/int_macros.rs"]
#[macro_use]
mod int_macros;

#[path = "num/shells/i128.rs"]
pub mod i128;
#[path = "num/shells/i16.rs"]
pub mod i16;
#[path = "num/shells/i32.rs"]
pub mod i32;
#[path = "num/shells/i64.rs"]
pub mod i64;
#[path = "num/shells/i8.rs"]
pub mod i8;
#[path = "num/shells/isize.rs"]
pub mod isize;

#[path = "num/shells/u128.rs"]
pub mod u128;
#[path = "num/shells/u16.rs"]
pub mod u16;
#[path = "num/shells/u32.rs"]
pub mod u32;
#[path = "num/shells/u64.rs"]
pub mod u64;
#[path = "num/shells/u8.rs"]
pub mod u8;
#[path = "num/shells/usize.rs"]
pub mod usize;

#[path = "num/f32.rs"]
pub mod f32;
#[path = "num/f64.rs"]
pub mod f64;

#[macro_use]
pub mod num;

/* The libcore prelude, not as all-encompassing as the libstd prelude */

pub mod prelude;

/* Core modules for ownership management */

pub mod hint;
pub mod intrinsics;
pub mod mem;
pub mod ptr;

/* Core language traits */

pub mod borrow;
pub mod clone;
pub mod cmp;
pub mod convert;
pub mod default;
pub mod marker;
pub mod ops;

/* Core types and methods on primitives */

pub mod any;
pub mod array;
pub mod ascii;
pub mod cell;
pub mod char;
pub mod ffi;
pub mod iter;
#[unstable(feature = "once_cell", issue = "74465")]
pub mod lazy;
pub mod option;
pub mod panic;
pub mod panicking;
pub mod pin;
pub mod raw;
pub mod result;
#[unstable(feature = "async_stream", issue = "79024")]
pub mod stream;
pub mod sync;

pub mod fmt;
pub mod hash;
pub mod slice;
pub mod str;
pub mod time;

pub mod unicode;

/* Async */
pub mod future;
pub mod task;

/* Heap memory allocator trait */
#[allow(missing_docs)]
pub mod alloc;

// note: no necessita ser públic
mod bool;
mod tuple;
mod unit;

#[stable(feature = "core_primitive", since = "1.43.0")]
pub mod primitive;

// Tireu el `core_arch` crate directament a libcore.El contingut de `core_arch` es troba en un dipòsit diferent: rust-lang/stdarch.
//
// `core_arch` depèn de libcore, però el contingut d'aquest mòdul està configurat de manera que, tirant-lo directament d'aquí, funcioni de manera que el crate utilitzi aquest crate com a libcore.
//
//
//
#[path = "../../stdarch/crates/core_arch/src/mod.rs"]
#[allow(
    missing_docs,
    missing_debug_implementations,
    dead_code,
    unused_imports,
    unsafe_op_in_unsafe_fn
)]
#[cfg_attr(bootstrap, allow(non_autolinks))]
#[cfg_attr(not(bootstrap), allow(rustdoc::non_autolinks))]
// FIXME: Aquesta anotació s'hauria de traslladar a rust-lang/stdarch després que es produeixi clashing_extern_declarations
// fusionat.Actualment no es pot fer perquè el bootstrap falla ja que el lint encara no s'ha definit.
#[allow(clashing_extern_declarations)]
#[unstable(feature = "stdsimd", issue = "48556")]
mod core_arch;

#[stable(feature = "simd_arch", since = "1.27.0")]
pub use core_arch::arch;