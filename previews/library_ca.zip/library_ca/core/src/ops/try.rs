/// Un trait per personalitzar el comportament de l'operador `?`.
///
/// Un tipus que implementa `Try` és aquell que té una manera canònica de veure-ho en termes d'una dicotomia success/failure.
/// Aquest trait permet extreure aquests valors d`èxit o fracàs d`una instància existent i crear una instància nova a partir d`un valor d`èxit o fracàs.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// El tipus d`aquest valor quan es considera correcte.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// El tipus d`aquest valor quan es visualitza com a fallit.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Aplica l'operador "?".Un retorn de `Ok(t)` significa que l'execució hauria de continuar amb normalitat i el resultat de `?` és el valor `t`.
    /// Un retorn de `Err(e)` significa que l'execució hauria de ser branch a la `catch` més íntima que l'envolta, o bé tornar de la funció.
    ///
    /// Si es retorna un resultat `Err(e)`, el valor `e` serà "wrapped" en el tipus de retorn de l'àmbit adjunt (que ha d'implementar ell mateix `Try`).
    ///
    /// En concret, es retorna el valor `X::from_error(From::from(e))`, on `X` és el tipus de retorn de la funció adjunta.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Incorporeu un valor d'error per construir el resultat compost.
    /// Per exemple, `Result::Err(x)` i `Result::from_error(x)` són equivalents.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Incorporeu un valor OK per construir el resultat compost.
    /// Per exemple, `Result::Ok(x)` i `Result::from_ok(x)` són equivalents.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}