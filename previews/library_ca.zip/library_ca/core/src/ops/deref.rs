/// S'utilitza per a operacions de desferenciació immutables, com ara `*v`.
///
/// A més d`utilitzar-se per a operacions de desferenciació explícites amb l`operador (unary) `*` en contextos immutables, el compilador també utilitza implícitament `Deref` en moltes circumstàncies.
/// Aquest mecanisme s`anomena ['`Deref` coercion'][more].
/// En contextos mutables, s`utilitza [`DerefMut`].
///
/// La implementació de `Deref` per als indicadors intel・ligents facilita l`accés a les dades que hi ha al darrere, motiu pel qual implementen `Deref`.
/// D'altra banda, les regles relatives a `Deref` i [`DerefMut`] van ser dissenyades específicament per adaptar-se als indicadors intel・ligents.
/// Per això,**"Deref" només s'hauria d'implementar per als indicadors intel・ligents** per evitar confusions.
///
/// Per motius similars,**aquest trait no hauria de fallar mai**.El fracàs durant la desferenciació pot ser extremadament confús quan s`invoca implícitament `Deref`.
///
/// # Més informació sobre la coacció `Deref`
///
/// Si `T` implementa `Deref<Target = U>` i `x` és un valor del tipus `T`, llavors:
///
/// * En contextos immutables, `*x` (on `T` no és ni una referència ni un punter en brut) és equivalent a `* Deref::deref(&x)`.
/// * Els valors del tipus `&T` es coaccionen als valors del tipus `&U`
/// * `T` implícitament implementa tots els mètodes (immutable) del tipus `U`.
///
/// Per obtenir més informació, visiteu [the chapter in *The Rust Programming Language*][book] i les seccions de referència sobre [the dereference operator][ref-deref-op], [method resolution] i [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Una estructura amb un únic camp a la qual s`accedeix desferenciant l`estructura.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// El tipus resultant després de la desferenciació.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Diferencia el valor.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// S`utilitza per a operacions de desferenciació mutables, com en `*v = 1;`.
///
/// A més d`utilitzar-se per a operacions de desferenciació explícites amb l`operador (unary) `*` en contextos mutables, el compilador també utilitza implícitament `DerefMut` en moltes circumstàncies.
/// Aquest mecanisme s`anomena ['`Deref` coercion'][more].
/// En contextos immutables, s'utilitza [`Deref`].
///
/// La implementació de `DerefMut` per als indicadors intel・ligents fa que sigui convenient la mutació de les dades que hi ha al darrere, per això implementen `DerefMut`.
/// D'altra banda, les regles relatives a [`Deref`] i `DerefMut` van ser dissenyades específicament per adaptar-se als indicadors intel・ligents.
/// Per això,**"DerefMut" només s'hauria d'implementar per als indicadors intel・ligents** per evitar confusions.
///
/// Per motius similars,**aquest trait no hauria de fallar mai**.El fracàs durant la desferenciació pot ser extremadament confús quan s`invoca implícitament `DerefMut`.
///
/// # Més informació sobre la coacció `Deref`
///
/// Si `T` implementa `DerefMut<Target = U>` i `x` és un valor del tipus `T`, llavors:
///
/// * En contextos mutables, `*x` (on `T` no és ni una referència ni un punter en brut) és equivalent a `* DerefMut::deref_mut(&mut x)`.
/// * Els valors del tipus `&mut T` es coaccionen als valors del tipus `&mut U`
/// * `T` implícitament implementa tots els mètodes (mutable) del tipus `U`.
///
/// Per obtenir més informació, visiteu [the chapter in *The Rust Programming Language*][book] i les seccions de referència sobre [the dereference operator][ref-deref-op], [method resolution] i [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Una estructura amb un únic camp que es pot modificar desferenciant l`estructura.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Desferencia mútuament el valor.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Indica que es pot utilitzar una estructura com a receptor de mètode, sense la característica `arbitrary_self_types`.
///
/// Això s`implementa mitjançant tipus de punter stdlib com `Box<T>`, `Rc<T>`, `&T` i `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}