/// La versió de l`operador de trucades que pren un receptor immutable.
///
/// Les instàncies de `Fn` es poden trucar repetidament sense estat mutant.
///
/// *Aquest trait (`Fn`) no s'ha de confondre amb [function pointers] (`fn`).*
///
/// `Fn` s`implementa automàticament mitjançant tancaments que només prenen referències immutables a variables capturades o no capturen res, així com (safe) [function pointers] (amb algunes advertències, consulteu la seva documentació per obtenir més detalls).
///
/// A més, per a qualsevol tipus `F` que implementi `Fn`, `&F` també implementa `Fn`.
///
/// Com que tant [`FnMut`] com [`FnOnce`] són supertrets de `Fn`, qualsevol instància de `Fn` es pot utilitzar com a paràmetre on s'espera un [`FnMut`] o [`FnOnce`].
///
/// Utilitzeu `Fn` com a límit quan vulgueu acceptar un paràmetre de tipus similar a la funció i necessiteu trucar-lo repetidament i sense estat mutant (per exemple, quan el crideu simultàniament).
/// Si no necessiteu requisits tan estrictes, utilitzeu [`FnMut`] o [`FnOnce`] com a límit.
///
/// Consulteu el [chapter on closures in *The Rust Programming Language*][book] per obtenir més informació sobre aquest tema.
///
/// També cal destacar la sintaxi especial per a `Fn` traits (per exemple,
/// `Fn(usize, bool) -> utilitzar ").Els interessats en els detalls tècnics d`això poden consultar [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Convocatòria de tancament
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Utilitzant un paràmetre `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // de manera que regex pot confiar en aquest `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Realitza l'operació de trucada.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// La versió de l`operador de trucades que pren un receptor mutable.
///
/// Les instàncies de `FnMut` es poden trucar repetidament i poden mutar l'estat.
///
/// `FnMut` s'implementa automàticament mitjançant tancaments que prenen referències mutables a variables capturades, així com tots els tipus que implementen [`Fn`], per exemple, (safe) [function pointers] (ja que `FnMut` és un superretrat de [`Fn`]).
/// A més, per a qualsevol tipus `F` que implementi `FnMut`, `&mut F` també implementa `FnMut`.
///
/// Com que [`FnOnce`] és un superretrat de `FnMut`, es pot utilitzar qualsevol instància de `FnMut` allà on s`espera un [`FnOnce`], i com que [`Fn`] és un subtret de `FnMut`, es pot utilitzar qualsevol instància de [`Fn`] on s`espera `FnMut`.
///
/// Utilitzeu `FnMut` com a lligat quan vulgueu acceptar un paràmetre de tipus similar a la funció i necessiteu trucar-lo repetidament, tot permetent que muti l'estat.
/// Si no voleu que el paràmetre muti l'estat, utilitzeu [`Fn`] com a límit;si no cal trucar-lo repetidament, utilitzeu [`FnOnce`].
///
/// Consulteu el [chapter on closures in *The Rust Programming Language*][book] per obtenir més informació sobre aquest tema.
///
/// També cal destacar la sintaxi especial per a `Fn` traits (per exemple,
/// `Fn(usize, bool) -> utilitzar ").Els interessats en els detalls tècnics d`això poden consultar [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Convocatòria d`un tancament de captura mútua
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Utilitzant un paràmetre `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // de manera que regex pot confiar en aquest `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Realitza l'operació de trucada.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// La versió de l`operador de trucades que pren un receptor per valor.
///
/// Es poden trucar a instàncies de `FnOnce`, però és possible que no es puguin trucar diverses vegades.Per això, si l'únic que es coneix d'un tipus és que implementa `FnOnce`, només es pot trucar una vegada.
///
/// `FnOnce` s'implementa automàticament mitjançant tancaments que poden consumir variables capturades, així com tots els tipus que implementen [`FnMut`], per exemple, (safe) [function pointers] (ja que `FnOnce` és un superretrat de [`FnMut`]).
///
///
/// Com que tant [`Fn`] com [`FnMut`] són subtraits de `FnOnce`, es pot utilitzar qualsevol instància de [`Fn`] o [`FnMut`] allà on s'espera un `FnOnce`.
///
/// Utilitzeu `FnOnce` com a límit quan vulgueu acceptar un paràmetre de tipus similar a la funció i només cal que el crideu una vegada.
/// Si heu de trucar al paràmetre repetidament, utilitzeu [`FnMut`] com a límit;si també el necessiteu per no mutar l'estat, utilitzeu [`Fn`].
///
/// Consulteu el [chapter on closures in *The Rust Programming Language*][book] per obtenir més informació sobre aquest tema.
///
/// També cal destacar la sintaxi especial per a `Fn` traits (per exemple,
/// `Fn(usize, bool) -> utilitzar ").Els interessats en els detalls tècnics d`això poden consultar [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Utilitzant un paràmetre `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` consumeix les seves variables capturades, de manera que no es pot executar més d'una vegada.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Si intenteu tornar a invocar `func()`, apareixerà un error `use of moved value` per a `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` ja no es pot invocar en aquest moment
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // de manera que regex pot confiar en aquest `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// El tipus retornat després que s'utilitzi l'operador de trucades.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Realitza l'operació de trucada.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}