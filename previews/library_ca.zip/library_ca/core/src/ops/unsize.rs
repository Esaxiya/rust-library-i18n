use crate::marker::Unsize;

/// Trait que indica que es tracta d'un punter o d'un embolcall per a un, on es pot realitzar un redimensionament al punt.
///
/// Consulteu [DST coercion RFC][dst-coerce] i [the nomicon entry on coercion][nomicon-coerce] per obtenir més informació.
///
/// Per als tipus de punteres integrats, els indicadors a `T` coaccionaran a indicadors a `U` si `T: Unsize<U>` mitjançant la conversió d'un punter prim a un punter greix.
///
/// Per als tipus personalitzats, la coacció aquí funciona coaccionant `Foo<T>` a `Foo<U>` sempre que existeixi una impl. De `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Aquesta aplicació només es pot escriure si `Foo<T>` només té un únic camp de dades no fantasma que inclou `T`.
/// Si el tipus d'aquest camp és `Bar<T>`, ha d'existir una implementació de `CoerceUnsized<Bar<U>> for Bar<T>`.
/// La coacció funcionarà coaccionant el camp `Bar<T>` a `Bar<U>` i emplenant la resta de camps des de `Foo<T>` per crear un `Foo<U>`.
/// Això permetrà aprofundir efectivament en un camp de punter i coaccionar-lo.
///
/// Generalment, per als indicadors intel・ligents implementareu `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, amb un `?Sized` opcional lligat al mateix `T`.
/// Per als tipus d`embolcall que incorporen directament `T` com `Cell<T>` i `RefCell<T>`, podeu implementar directament `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Això deixarà funcionar coaccions de tipus com `Cell<Box<T>>`.
///
/// [`Unsize`][unsize] s'utilitza per marcar tipus que es poden coaccionar a DST si hi ha darrere dels punteres.El compilador implementa automàticament.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// S'utilitza per a la seguretat d'objectes, per comprovar que es pot enviar el tipus de receptor d'un mètode.
///
/// Un exemple d'implementació de trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}