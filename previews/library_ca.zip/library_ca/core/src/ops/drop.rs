/// Codi personalitzat dins del destructor.
///
/// Quan ja no cal un valor, Rust executarà un "destructor" en aquest valor.
/// La forma més comuna en què ja no es necessita un valor és quan surt de l'abast.Els destructors encara poden funcionar en altres circumstàncies, però ens centrarem en l'abast dels exemples aquí.
/// Per obtenir informació sobre alguns d`aquests altres casos, consulteu la secció [the reference] sobre destructors.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Aquest destructor consta de dos components:
/// - Una trucada a `Drop::drop` per aquest valor, si aquest `Drop` especial trait està implementat per al seu tipus.
/// - El "drop glue" generat automàticament que crida recursivament als destructors de tots els camps d`aquest valor.
///
/// Com que Rust crida automàticament als destructors de tots els camps continguts, no cal que implementeu `Drop` en la majoria dels casos.
/// Però hi ha alguns casos en què és útil, per exemple, per als tipus que gestionen directament un recurs.
/// Aquest recurs pot ser memòria, pot ser un descriptor de fitxers, pot ser un sòcol de xarxa.
/// Quan ja no s'utilitzi un valor d'aquest tipus, hauria de "clean up" el seu recurs alliberant la memòria o tancant el fitxer o el sòcol.
/// Aquesta és la feina d`un destructor i, per tant, la de `Drop::drop`.
///
/// ## Examples
///
/// Per veure els destructors en acció, fem una ullada al programa següent:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust primer trucarà a `Drop::drop` per a `_x` i després per a `_x.one` i `_x.two`, el que significa que executant això s`imprimirà
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Fins i tot si eliminem la implementació de `Drop` per a `HasTwoDrop`, encara es diuen els destructors dels seus camps.
/// Això es traduiria en
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## No podeu trucar a `Drop::drop` vosaltres mateixos
///
/// Com que `Drop::drop` s'utilitza per netejar un valor, pot ser perillós utilitzar aquest valor després de cridar el mètode.
/// Com que `Drop::drop` no es fa propietari de la seva entrada, Rust evita el mal ús en no permetre trucar directament a `Drop::drop`.
///
/// En altres paraules, si proveu de trucar explícitament a `Drop::drop` a l'exemple anterior, obtindreu un error del compilador.
///
/// Si voleu trucar explícitament al destructor d'un valor, es pot utilitzar [`mem::drop`].
///
/// [`mem::drop`]: drop
///
/// ## Ordre de caiguda
///
/// Quina de les nostres dues `HasDrop` cau primer, però?Per a les estructures, és el mateix ordre que es declara: primer `one`, després `two`.
/// Si voleu provar-ho vosaltres mateixos, podeu modificar `HasDrop` anterior per contenir algunes dades, com ara un nombre enter, i després utilitzar-lo al `println!` dins de `Drop`.
/// Aquest comportament està garantit pel llenguatge.
///
/// A diferència de les estructures, les variables locals es deixen caure en ordre invers:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Això s'imprimirà
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Consulteu [the reference] per obtenir les regles completes.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` i `Drop` són exclusius
///
/// No podeu implementar [`Copy`] i `Drop` en el mateix tipus.El compilador duplica implícitament els tipus `Copy`, de manera que és molt difícil predir quan i amb quina freqüència s`executaran els destructors.
///
/// Com a tals, aquests tipus no poden tenir destructors.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Executa el destructor per a aquest tipus.
    ///
    /// Aquest mètode s'anomena implícitament quan el valor surt fora de l'abast i no es pot anomenar explícitament (es tracta d'un error del compilador [E0040]).
    /// Tot i això, la funció [`mem::drop`] del prelude es pot utilitzar per cridar a la implementació de l'argument `Drop`.
    ///
    /// Quan s'ha cridat aquest mètode, `self` encara no s'ha repartit.
    /// Això només passa un cop finalitzat el mètode.
    /// Si no fos el cas, `self` seria una referència penjant.
    ///
    /// # Panics
    ///
    /// Tenint en compte que un [`panic!`] trucarà a `drop` mentre es desenrotlla, és probable que qualsevol [`panic!`] en una implementació `drop` s'avorti.
    ///
    /// Tingueu en compte que, fins i tot si aquest panics, es considera que el valor és eliminat;
    /// no heu de fer que es torni a trucar a `drop`.
    /// Normalment, el compilador gestiona això automàticament, però quan s`utilitza un codi no segur, de vegades es pot produir sense voler, sobretot quan s`utilitza [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}