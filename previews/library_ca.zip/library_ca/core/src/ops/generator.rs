use crate::marker::Unpin;
use crate::pin::Pin;

/// El resultat d`una represa del generador.
///
/// Aquest enum es retorna del mètode `Generator::resume` i indica els possibles valors de retorn d`un generador.
/// Actualment, això correspon a un punt de suspensió (`Yielded`) o a un punt de terminació (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// El generador suspès amb un valor.
    ///
    /// Aquest estat indica que s'ha suspès un generador i que normalment correspon a una sentència `yield`.
    /// El valor proporcionat en aquesta variant correspon a l'expressió passada a `yield` i permet als generadors proporcionar un valor cada vegada que produeixen.
    ///
    ///
    Yielded(Y),

    /// El generador es completa amb un valor de retorn.
    ///
    /// Aquest estat indica que un generador ha acabat l'execució amb el valor proporcionat.
    /// Una vegada que un generador ha retornat `Complete`, es considera un error del programador tornar a trucar a `resume`.
    ///
    Complete(R),
}

/// El trait implementat per tipus de generadors integrats.
///
/// Els generadors, també anomenats coroutines, són actualment una característica de llenguatge experimental a Rust.
/// Els generadors afegits a [RFC 2033] estan destinats actualment a proporcionar principalment un element bàsic per a la sintaxi async/await, però probablement s`estendran a proporcionar també una definició ergonòmica per als iteradors i altres primitives.
///
///
/// La sintaxi i la semàntica dels generadors són inestables i requeriran una RFC addicional per a l'estabilització.En aquest moment, però, la sintaxi és semblant al tancament:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Es pot trobar més documentació sobre generadors al llibre inestable.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// El tipus de valor que genera aquest generador.
    ///
    /// Aquest tipus associat correspon a l'expressió `yield` i als valors que es poden retornar cada vegada que es produeix un generador.
    ///
    /// Per exemple, un iterador-com-un-generador probablement tindria aquest tipus com a `T`, amb el tipus iterat.
    ///
    type Yield;

    /// El tipus de valor que retorna aquest generador.
    ///
    /// Això correspon al tipus retornat d'un generador amb una sentència `return` o implícitament com a última expressió d'un literal del generador.
    /// Per exemple, futures utilitzaria això com a `Result<T, E>` ja que representa un future completat.
    ///
    ///
    type Return;

    /// Reprèn l'execució d'aquest generador.
    ///
    /// Aquesta funció reprendrà l'execució del generador o començarà l'execució si encara no ho ha fet.
    /// Aquesta trucada tornarà a l'últim punt de suspensió del generador, reprenent l'execució a partir de l'últim `yield`.
    /// El generador continuarà executant-se fins que cedeixi o retorni, moment en què aquesta funció tornarà.
    ///
    /// # Valor de retorn
    ///
    /// L'enumeració `GeneratorState` retornada d'aquesta funció indica en quin estat es troba el generador en tornar.
    /// Si es retorna la variant `Yielded`, el generador ha arribat a un punt de suspensió i s'ha obtingut un valor.
    /// Els generadors en aquest estat estan disponibles per reprendre`s en un moment posterior.
    ///
    /// Si es retorna `Complete`, el generador ha acabat completament amb el valor proporcionat.No és vàlid que es reprengui el generador de nou.
    ///
    /// # Panics
    ///
    /// Aquesta funció pot panic si es crida després que la variant `Complete` s'hagi retornat anteriorment.
    /// Tot i que els literals del generador en l'idioma es garanteixen a panic quan es reprèn després de `Complete`, això no està garantit per a totes les implementacions de `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}