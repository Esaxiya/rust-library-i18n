//! Operadors sobrecarregables.
//!
//! La implementació d`aquestes traits us permet sobrecarregar alguns operadors.
//!
//! Alguns d'aquests traits són importats per prelude, de manera que estan disponibles a tots els programes Rust.Només es poden sobrecarregar els operadors recolzats per traits.
//! Per exemple, l'operador d'addició (`+`) es pot sobrecarregar mitjançant l [`Add`] trait, però com que l'operador d'assignació (`=`) no té cap suport trait, no hi ha manera de sobrecarregar la seva semàntica.
//! A més, aquest mòdul no proporciona cap mecanisme per crear operadors nous.
//! Si es requereixen una sobrecàrrega sense trets o operadors personalitzats, hauríeu de mirar macros o connectors de compilador per ampliar la sintaxi de Rust.
//!
//! Les implementacions de l`operador traits no haurien de ser sorprenents en els seus respectius contextos, tenint en compte els seus significats habituals i [operator precedence].
//! Per exemple, quan s`implementa [`Mul`], l`operació hauria de tenir alguna semblança amb la multiplicació (i compartir propietats esperades com l`associativitat).
//!
//! Tingueu en compte que els operadors `&&` i `||` fan curtcircuit, és a dir, només avaluen el seu segon operand si contribueix al resultat.Com que aquest comportament no es pot aplicar a traits, `&&` i `||` no són compatibles amb els operadors de sobrecàrrega.
//!
//! Molts dels operadors prenen els seus operands per valor.En contextos no genèrics que impliquen tipus integrats, normalment no és un problema.
//! No obstant això, l'ús d'aquests operadors en codi genèric requereix certa atenció si s'han de reutilitzar valors en lloc de deixar que els operadors els consumeixin.Una opció és utilitzar ocasionalment [`clone`].
//! Una altra opció és confiar en els tipus implicats que proporcionen implementacions addicionals de l'operador per a referències.
//! Per exemple, per a un tipus `T` definit per l'usuari que se suposa que admet l'addició, probablement sigui una bona idea que tant `T` com `&T` implementin el traits [`Add<T>`][`Add`] i [`Add<&T>`][`Add`] de manera que es pugui escriure codi genèric sense clonar innecessàriament.
//!
//!
//! # Examples
//!
//! Aquest exemple crea una estructura `Point` que implementa [`Add`] i [`Sub`] i, a continuació, demostra sumar i restar dos `Point`s.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Consulteu la documentació de cada trait per obtenir un exemple d`implementació.
//!
//! [`Fn`], [`FnMut`] i [`FnOnce`] traits s`implementen per tipus que es poden invocar com a funcions.Tingueu en compte que [`Fn`] pren `&self`, [`FnMut`] pren `&mut self` i [`FnOnce`] pren `self`.
//! Aquests corresponen als tres tipus de mètodes que es poden invocar en una instància: trucada per referència, trucada per referència mutable i trucada per valor.
//! L'ús més comú d'aquests traits és actuar com a límit a funcions de nivell superior que prenen funcions o tancaments com a arguments.
//!
//! Prenent un [`Fn`] com a paràmetre:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Prenent un [`FnMut`] com a paràmetre:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Prenent un [`FnOnce`] com a paràmetre:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` consumeix les seves variables capturades, de manera que no es pot executar més d'una vegada
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Si intenteu tornar a invocar `func()`, apareixerà un error `use of moved value` per a `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` ja no es pot invocar en aquest moment
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;