//! Contenidors mutibles compartibles.
//!
//! La seguretat de la memòria Rust es basa en aquesta regla: donat un objecte `T`, només és possible tenir un dels següents:
//!
//! - Tenir diverses referències immutables (`&T`) a l'objecte (també conegut com a **aliasing**).
//! - Tenir una referència mutable ("&mut T") a l'objecte (també coneguda com a **mutabilitat**).
//!
//! Això és aplicat pel compilador Rust.Tot i això, hi ha situacions en què aquesta regla no és prou flexible.De vegades, es requereix tenir diverses referències a un objecte i, tot i així, mutar-lo.
//!
//! Existeixen contenidors mutables compartibles per permetre la mutabilitat de manera controlada, fins i tot en presència d'aliasing.Tant [`Cell<T>`] com [`RefCell<T>`] permeten fer-ho de manera única.
//! Tanmateix, ni `Cell<T>` ni `RefCell<T>` són segurs per a fils (no implementen [`Sync`]).
//! Si heu de fer aliasing i mutació entre diversos fils, és possible utilitzar tipus [`Mutex<T>`], [`RwLock<T>`] o [`atomic`].
//!
//! Els valors dels tipus `Cell<T>` i `RefCell<T>` poden ser mutats mitjançant referències compartides (és a dir
//! el tipus comú `&T`), mentre que la majoria dels tipus Rust només es poden mutar mitjançant referències úniques ("&mut T").
//! Diem que `Cell<T>` i `RefCell<T>` proporcionen "mutabilitat interior", en contrast amb els tipus típics de Rust que presenten "mutabilitat heretada".
//!
//! Els tipus de cèl・lules tenen dos colors: `Cell<T>` i `RefCell<T>`.`Cell<T>` implementa la mutabilitat interior movent valors dins i fora del `Cell<T>`.
//! Per utilitzar referències en lloc de valors, cal utilitzar el tipus `RefCell<T>`, adquirint un bloqueig d'escriptura abans de mutar.`Cell<T>` proporciona mètodes per recuperar i canviar el valor interior actual:
//!
//!  - Per als tipus que implementen [`Copy`], el mètode [`get`](Cell::get) recupera el valor interior actual.
//!  - Per als tipus que implementen [`Default`], el mètode [`take`](Cell::take) substitueix el valor interior actual per [`Default::default()`] i retorna el valor substituït.
//!  - Per a tots els tipus, el mètode [`replace`](Cell::replace) substitueix el valor interior actual i retorna el valor substituït i el mètode [`into_inner`](Cell::into_inner) consumeix el `Cell<T>` i retorna el valor interior.
//!  A més, el mètode [`set`](Cell::set) substitueix el valor interior, deixant de banda el valor substituït.
//!
//! `RefCell<T>` utilitza la vida de Rust per implementar un `endeutament dinàmic`, un procés pel qual es pot reclamar un accés temporal, exclusiu i mutable al valor intern.
//! Préstecs per a `RefCell<T>Les"s es fan un seguiment"en temps d'execució", a diferència dels tipus de referència nadius de Rust, que es realitzen un seguiment complet estàtic, en temps de compilació.
//! Com que els préstecs `RefCell<T>` són dinàmics, és possible intentar demanar prestat un valor que ja es pot demanar mutament;quan això passa, resulta el fil panic.
//!
//! # Quan escollir la mutabilitat interior
//!
//! La mutabilitat heretada més comuna, on s`ha de tenir accés únic per mutar un valor, és un dels elements clau del llenguatge que permet a Rust raonar fermament sobre l`aliasing de punter, prevenint estàticament els errors de fallades.
//! Per això, es prefereix la mutabilitat heretada i la mutabilitat interior és una darrera opció.
//! Atès que els tipus de cèl・lules permeten la mutació allà on no es permetria, hi ha ocasions en què la mutabilitat interior pot ser adequada, o fins i tot s'ha d'utilitzar *, per exemple
//!
//! * Presentació de la mutabilitat 'inside' d'alguna cosa immutable
//! * Detalls d`implementació de mètodes lògicament immutables.
//! * Implementacions mutants de [`Clone`].
//!
//! ## Presentació de la mutabilitat 'inside' d'alguna cosa immutable
//!
//! Molts tipus de punteres intel・ligents compartits, inclosos [`Rc<T>`] i [`Arc<T>`], proporcionen contenidors que es poden clonar i compartir entre diverses parts.
//! Com que els valors continguts poden tenir àlies multiples, només es poden demanar prestats amb `&`, no amb `&mut`.
//! Sense cel・les seria impossible mutar les dades d`aquests punteres intel・ligents.
//!
//! Aleshores, és molt habitual posar un `RefCell<T>` dins de tipus de punter compartit per reintroduir la mutabilitat:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Creeu un bloc nou per limitar l'abast del préstec dinàmic
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Tingueu en compte que si no haguéssim deixat fora de l'abast el préstec anterior de la memòria cau, el préstec posterior provocaria un fil dinàmic panic.
//!     //
//!     // Aquest és el principal perill d'utilitzar `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Tingueu en compte que aquest exemple utilitza `Rc<T>` i no `Arc<T>`.`RefCell<T>`s són per a escenaris de fil únic.Penseu en utilitzar [`RwLock<T>`] o [`Mutex<T>`] si necessiteu mutabilitat compartida en una situació de diversos fils.
//!
//! ## Detalls d`implementació de mètodes lògicament immutables
//!
//! De tant en tant pot ser desitjable no exposar en una API que hi hagi una mutació "under the hood".
//! Això pot ser perquè lògicament l'operació és immutable, però, per exemple, la memòria cau obliga la implementació a realitzar una mutació;o perquè heu d'utilitzar la mutació per implementar un mètode trait que es va definir originalment per prendre `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // El càlcul car és aquí
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Implementacions mutants de `Clone`
//!
//! Aquest és simplement un cas especial, però comú, de l`anterior: mutabilitat d`amagatall per a operacions que semblen immutables.
//! S'espera que el mètode [`clone`](Clone::clone) no canviï el valor font i es declara que pren `&self`, no `&mut self`.
//! Per tant, qualsevol mutació que passi al mètode `clone` ha d'utilitzar tipus de cel・les.
//! Per exemple, [`Rc<T>`] manté els seus recomptes de referència dins d'un `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Una ubicació de memòria mutable.
///
/// # Examples
///
/// En aquest exemple, podeu veure que `Cell<T>` habilita la mutació dins d'una estructura immutable.
/// En altres paraules, habilita "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ERROR: `my_struct` és immutable
/// // my_struct.regular_field =valor_nou;
///
/// // FUNCIONA: encara que `my_struct` és immutable, `special_field` és un `Cell`,
/// // que sempre es pot mutar
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Vegeu el [module-level documentation](self) per obtenir més informació.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Crea un `Cell<T>`, amb el valor `Default` per a T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Crea un nou `Cell` que conté el valor donat.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Estableix el valor contingut.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Intercanvia els valors de dues cel・les.
    /// La diferència amb `std::mem::swap` és que aquesta funció no requereix referència `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // SEGURETAT: pot ser arriscat si es crida des de fils separats, però `Cell`
        // és `!Sync`, de manera que això no passarà.
        // Això tampoc invalidarà cap indicador, ja que `Cell` s'assegura que res més apuntarà cap a cap d'aquests `Cell`s.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Substitueix el valor contingut per `val` i retorna l'antic valor contingut.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // SEGURETAT: això pot provocar curses de dades si es crida des d'un fil separat,
        // però `Cell` és `!Sync`, de manera que això no passarà.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Desenfoca el valor.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Retorna una còpia del valor contingut.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // SEGURETAT: això pot provocar curses de dades si es crida des d'un fil separat,
        // però `Cell` és `!Sync`, de manera que això no passarà.
        unsafe { *self.value.get() }
    }

    /// Actualitza el valor contingut mitjançant una funció i retorna el valor nou.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Retorna un punter en brut a les dades subjacents en aquesta cel・la.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Retorna una referència mutable a les dades subjacents.
    ///
    /// Aquesta trucada presta `Cell` mutablement (en temps de compilació), cosa que garanteix que posseïm l'única referència.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Retorna un `&Cell<T>` d'un `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // SEGURETAT: `&mut` garanteix un accés únic.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Pren el valor de la cel・la, deixant `Default::default()` al seu lloc.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Retorna un `&[Cell<T>]` d'un `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // SEGURETAT: `Cell<T>` té el mateix disseny de memòria que `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Una ubicació de memòria mutable amb regles de préstec comprovades dinàmicament
///
/// Vegeu el [module-level documentation](self) per obtenir més informació.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Un error retornat per [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Un error retornat per [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Els valors positius representen el nombre de `Ref` actius.Els valors negatius representen el nombre de `RefMut` actius.
// Diversos "RefMut" només poden estar actius alhora si fan referència a components diferents que no se superposen d'un `RefCell` (per exemple, diferents intervals d'una llesca).
//
// `Ref` i `RefMut` són ambdues dimensions, de manera que probablement mai no hi haurà prou "Ref" o "RefMut" per desbordar la meitat del rang `usize`.
// Per tant, un `BorrowFlag` probablement mai desbordarà ni desbordarà.
// Tanmateix, això no és una garantia, ja que un programa patològic es podria crear repetidament i després mem::forget `Ref`s o`RefMut`s.
// Per tant, tot el codi ha de comprovar explícitament si hi ha desbordament i desbordament per evitar inseguretat o, almenys, comportar-se correctament en cas que es produeixi desbordament o desbordament (per exemple, vegeu BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Crea un nou `RefCell` que conté `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Consumeix el `RefCell`, retornant el valor ajustat.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Com que aquesta funció pren `self` (el `RefCell`) per valor, el compilador verifica estàticament que actualment no està prestat.
        //
        self.value.into_inner()
    }

    /// Substitueix el valor ajustat per un de nou, retornant el valor antic, sense desinicialitzar-ne cap.
    ///
    ///
    /// Aquesta funció correspon a [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics si el valor està prestat actualment.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Substitueix el valor ajustat per un de nou calculat a partir de `f`, retornant el valor antic, sense desinicialitzar-ne cap.
    ///
    ///
    /// # Panics
    ///
    /// Panics si el valor està prestat actualment.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Intercanvia el valor ajustat de `self` amb el valor ajustat de `other`, sense desinicialitzar-ne cap.
    ///
    ///
    /// Aquesta funció correspon a [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics si el valor de qualsevol dels `RefCell` està prestat actualment.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Manlleva de forma immutable el valor combinat.
    ///
    /// El préstec dura fins que el `Ref` retornat surt de l'abast.
    /// Es poden treure diversos préstecs immutables alhora.
    ///
    /// # Panics
    ///
    /// Panics si actualment el valor es presta mutablement.
    /// Per a una variant sense pànic, utilitzeu [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Un exemple de panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Presta de forma immutable el valor ajustat, retornant un error si actualment el valor es presta mutablement.
    ///
    ///
    /// El préstec dura fins que el `Ref` retornat surt de l'abast.
    /// Es poden treure diversos préstecs immutables alhora.
    ///
    /// Aquesta és la variant sense pànic de [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // SEGURETAT: `BorrowRef` garanteix que només hi hagi accés immutable
            // al valor en préstec.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Endeutament mutu del valor inclòs.
    ///
    /// El préstec dura fins al `RefMut` retornat o tots els `RefMut` derivats del seu abast de sortida.
    ///
    /// El valor no es pot demanar prestat mentre aquest préstec està actiu.
    ///
    /// # Panics
    ///
    /// Panics si el valor està prestat actualment.
    /// Per a una variant sense pànic, utilitzeu [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Un exemple de panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Endeute mutament el valor ajustat, retornant un error si el valor està prestat actualment.
    ///
    ///
    /// El préstec dura fins al `RefMut` retornat o tots els `RefMut` derivats del seu abast de sortida.
    /// El valor no es pot demanar prestat mentre aquest préstec està actiu.
    ///
    /// Aquesta és la variant sense pànic de [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // SEGURETAT: `BorrowRef` garanteix un accés únic.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Retorna un punter en brut a les dades subjacents en aquesta cel・la.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Retorna una referència mutable a les dades subjacents.
    ///
    /// Aquesta trucada presta `RefCell` de forma mutada (en temps de compilació), de manera que no cal fer controls dinàmics.
    ///
    /// Tanmateix, tingueu precaució: aquest mètode espera que `self` sigui mutable, cosa que normalment no és el cas quan s`utilitza un `RefCell`.
    ///
    /// Mireu el mètode [`borrow_mut`] si `self` no és mutable.
    ///
    /// A més, tingueu en compte que aquest mètode només és per a circumstàncies especials i que normalment no és el que voleu.
    /// En cas de dubte, utilitzeu [`borrow_mut`].
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Desfeu l'efecte de les proteccions filtrades sobre l'estat de préstec del `RefCell`.
    ///
    /// Aquesta trucada és similar a [`get_mut`] però més especialitzada.
    /// Presta `RefCell` mutablement per garantir que no existeixin préstecs i després restableix l'estat de seguiment dels préstecs compartits.
    /// Això és rellevant si s`han filtrat alguns préstecs `Ref` o `RefMut`.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Presta de forma immutable el valor ajustat, retornant un error si actualment el valor es presta mutablement.
    ///
    /// # Safety
    ///
    /// A diferència de `RefCell::borrow`, aquest mètode no és segur perquè no retorna un `Ref`, deixant així el senyal de préstec intacte.
    /// El préstec mutu del `RefCell` mentre la referència retornada per aquest mètode és viva és un comportament indefinit.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // SEGURETAT: comprovem que ara ningú no escriu activament, però sí
            // la responsabilitat de la persona que truca per assegurar-se que ningú escrigui fins que la referència retornada ja no s'utilitzi.
            // A més, `self.value.get()` fa referència al valor propietat de `self` i, per tant, es garanteix que serà vàlid durant tota la vida de `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Pren el valor ajustat i deixa `Default::default()` al seu lloc.
    ///
    /// # Panics
    ///
    /// Panics si el valor està prestat actualment.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics si actualment el valor es presta mutablement.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Crea un `RefCell<T>`, amb el valor `Default` per a T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics si el valor de qualsevol dels `RefCell` està prestat actualment.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics si el valor de qualsevol dels `RefCell` està prestat actualment.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics si el valor de qualsevol dels `RefCell` està prestat actualment.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics si el valor de qualsevol dels `RefCell` està prestat actualment.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics si el valor de qualsevol dels `RefCell` està prestat actualment.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics si el valor de qualsevol dels `RefCell` està prestat actualment.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics si el valor de qualsevol dels `RefCell` està prestat actualment.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // L`increment de l`endeutament pot resultar en un valor sense lectura (<=0) en aquests casos:
            // 1. Era <0, és a dir, hi ha préstecs d`escriptura, de manera que no podem permetre un préstec de lectura a causa de les regles d`aliasing de referència de Rust
            // 2.
            // Era isize::MAX (la quantitat màxima de préstecs de lectura) i es va desbordar a isize::MIN (la quantitat màxima de préstecs d`escriptura), de manera que no podem permetre un préstec de lectura addicional perquè isize no pot representar tants préstecs de lectura (això només pot passar si mem::forget més que una petita quantitat constant de`Ref`s, cosa que no és una bona pràctica)
            //
            //
            //
            //
            None
        } else {
            // L`augment del préstec pot resultar en un valor de lectura (> 0) en aquests casos:
            // 1. Era=0, és a dir, no es va manllevar i estem prenent el primer préstec de lectura
            // 2. Era> 0 i <isize::MAX, és a dir
            // hi havia préstecs de lectura, i isize és prou gran per representar tenir un préstec de lectura més
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Com que existeix aquest Ref, sabem que el senyal de préstec és un préstec de lectura.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Eviteu que el comptador de préstecs es desbordi en un préstec per escrit.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Embolica una referència prestada a un valor en una caixa `RefCell`.
/// Un tipus d'embolcall per a un valor prestat immutablement d'un `RefCell<T>`.
///
/// Vegeu el [module-level documentation](self) per obtenir més informació.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Copia un `Ref`.
    ///
    /// El `RefCell` ja està en préstec immutable, de manera que això no pot fallar.
    ///
    /// Aquesta és una funció associada que cal utilitzar com a `Ref::clone(...)`.
    /// Una implementació de `Clone` o un mètode interferiria amb l`ús generalitzat de `r.borrow().clone()` per clonar el contingut d`un `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Crea un nou `Ref` per a un component de les dades prestades.
    ///
    /// El `RefCell` ja està en préstec immutable, de manera que això no pot fallar.
    ///
    /// Aquesta és una funció associada que cal utilitzar com a `Ref::map(...)`.
    /// Un mètode interferiria amb els mètodes del mateix nom en el contingut d'un `RefCell` utilitzat a través de `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Crea un nou `Ref` per a un component opcional de les dades prestades.
    /// La protecció original es retorna com a `Err(..)` si el tancament torna `None`.
    ///
    /// El `RefCell` ja està en préstec immutable, de manera que això no pot fallar.
    ///
    /// Aquesta és una funció associada que cal utilitzar com a `Ref::filter_map(...)`.
    /// Un mètode interferiria amb els mètodes del mateix nom en el contingut d'un `RefCell` utilitzat a través de `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Divideix un `Ref` en diversos "Ref" per a diferents components de les dades prestades.
    ///
    /// El `RefCell` ja està en préstec immutable, de manera que això no pot fallar.
    ///
    /// Aquesta és una funció associada que cal utilitzar com a `Ref::map_split(...)`.
    /// Un mètode interferiria amb els mètodes del mateix nom en el contingut d'un `RefCell` utilitzat a través de `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Converteix en una referència a les dades subjacents.
    ///
    /// El `RefCell` subjacent no es podrà tornar a manllevar mai més i sempre apareixerà ja manejable.
    ///
    /// No és una bona idea filtrar més que un nombre constant de referències.
    /// El `RefCell` es pot tornar a manllevar de forma immutable si només s`ha produït un nombre menor de fuites en total.
    ///
    /// Aquesta és una funció associada que cal utilitzar com a `Ref::leak(...)`.
    /// Un mètode interferiria amb els mètodes del mateix nom en el contingut d'un `RefCell` utilitzat a través de `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // En oblidar aquest Ref, ens assegurem que el comptador de préstecs del RefCell no pugui tornar a UNUSED durant el període de vida `'b`.
        // El restabliment de l`estat de seguiment de referència requeriria una referència única al RefCell prestat.
        // No es poden crear més referències mutables des de la cel・la original.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Crea un nou `RefMut` per a un component de les dades prestades, per exemple, una variant enum.
    ///
    /// El `RefCell` ja està manllevat, de manera que no pot fallar.
    ///
    /// Aquesta és una funció associada que cal utilitzar com a `RefMut::map(...)`.
    /// Un mètode interferiria amb els mètodes del mateix nom en el contingut d'un `RefCell` utilitzat a través de `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): arreglar el xec de préstec
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Crea un nou `RefMut` per a un component opcional de les dades prestades.
    /// La protecció original es retorna com a `Err(..)` si el tancament torna `None`.
    ///
    /// El `RefCell` ja està manllevat, de manera que no pot fallar.
    ///
    /// Aquesta és una funció associada que cal utilitzar com a `RefMut::filter_map(...)`.
    /// Un mètode interferiria amb els mètodes del mateix nom en el contingut d'un `RefCell` utilitzat a través de `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): arreglar el xec de préstec
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SEGURETAT: la funció manté una referència exclusiva durant la durada
        // de la seva trucada a través de `orig`, i el punter només es fa referència a l`interior de la trucada de funció i mai no permet escapar la referència exclusiva.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SEGURETAT: igual que l'anterior.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Divideix un `RefMut` en diversos `RefMut` per a diferents components de les dades prestades.
    ///
    /// El `RefCell` subjacent es mantindrà en préstec mutable fins que els dos "RefMut" retornats surtin de l'abast.
    ///
    /// El `RefCell` ja està manllevat, de manera que no pot fallar.
    ///
    /// Aquesta és una funció associada que cal utilitzar com a `RefMut::map_split(...)`.
    /// Un mètode interferiria amb els mètodes del mateix nom en el contingut d'un `RefCell` utilitzat a través de `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Converteix en una referència mutable a les dades subjacents.
    ///
    /// El `RefCell` subjacent no es pot tornar a manllevar i sempre apareixerà ja manllevat, cosa que fa que la referència retornada sigui l'única a l'interior.
    ///
    ///
    /// Aquesta és una funció associada que cal utilitzar com a `RefMut::leak(...)`.
    /// Un mètode interferiria amb els mètodes del mateix nom en el contingut d'un `RefCell` utilitzat a través de `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // En oblidar aquest BorrowRefMut, ens assegurem que el comptador de préstecs del RefCell no pugui tornar a UNUSED durant el període de vida `'b`.
        // El restabliment de l`estat de seguiment de referència requeriria una referència única al RefCell prestat.
        // No es poden crear més referències des de la cel・la original dins d`aquesta vida útil, cosa que fa que el préstec actual sigui l`única referència per a la vida restant.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: A diferència de BorrowRefMut::clone, es crida new per crear la inicial
        // referència mutable, de manera que actualment no hi ha d`haver referències existents.
        // Per tant, mentre el clon augmenta el recompte mutable, aquí només permetem explícitament passar d'UNUSED a UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Clona un `BorrowRefMut`.
    //
    // Això només és vàlid si s`utilitza cada `BorrowRefMut` per fer un seguiment d`una referència mutable a un interval diferent i no superposat de l`objecte original.
    //
    // Això no es troba en una aplicació Clone, de manera que el codi no ho crida implícitament.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Eviteu que el comptador de préstecs no es desbordi.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Un tipus d`embolcall per a un valor mutament manllevat d`un `RefCell<T>`.
///
/// Vegeu el [module-level documentation](self) per obtenir més informació.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// El nucli primitiu per a la mutabilitat interior a Rust.
///
/// Si teniu una referència `&T`, normalment a Rust el compilador realitza optimitzacions basant-se en el coneixement que `&T` apunta a dades immutables.Mutar aquestes dades, per exemple mitjançant un àlies o transmutant un `&T` en un `&mut T`, es considera un comportament indefinit.
/// `UnsafeCell<T>` desactiva la garantia d`immutabilitat per a `&T`: una referència compartida `&UnsafeCell<T>` pot apuntar a dades que s`estan mutant.Això s`anomena "interior mutability".
///
/// La resta de tipus que permeten la mutabilitat interna, com ara `Cell<T>` i `RefCell<T>`, utilitzen internament `UnsafeCell` per embolicar les seves dades.
///
/// Tingueu en compte que `UnsafeCell` només afecta la garantia d`immutabilitat de les referències compartides.La garantia d'unicitat per a referències mutables no es veu afectada.No hi ha *cap* forma legal d'obtenir l'aliasing `&mut`, ni tan sols amb `UnsafeCell<T>`.
///
/// La pròpia API `UnsafeCell` és tècnicament molt senzilla: [`.get()`] us proporciona un punter en brut `*mut T` al seu contingut.Depèn de _you_ com a dissenyador d`abstraccions utilitzar correctament aquest punter en brut.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Les regles d`aliasing precises de Rust estan una mica en moviment, però els punts principals no són controvertits:
///
/// - Si creeu una referència segura amb la vida `'a` (ja sigui una referència `&T` o `&mut T`) que sigui accessible mitjançant un codi segur (per exemple, perquè l`heu retornat), no heu d`accedir a les dades de cap manera que contradigui aquesta referència per a la resta de `'a`.
/// Per exemple, això vol dir que si treieu el `*mut T` d'un `UnsafeCell<T>` i el torneu a un `&T`, les dades de `T` han de romandre immutables (per exemple, totes les dades `UnsafeCell` trobades a `T`, per descomptat) fins que caduqui la vida útil d'aquesta referència.
/// De la mateixa manera, si creeu una referència `&mut T` que s`allibera al codi segur, no heu d`accedir a les dades del `UnsafeCell` fins que caduqui aquesta referència.
///
/// - En tot moment, heu d`evitar les curses de dades.Si diversos fils tenen accés al mateix `UnsafeCell`, qualsevol escriptura ha de tenir una relació adequada abans que tots els altres accessos (o utilitzar atòmics).
///
/// Per ajudar-vos a dissenyar adequadament, els següents escenaris es declaren explícitament legals per al codi de fil únic:
///
/// 1. Una referència `&T` es pot alliberar al codi segur i allà pot coexistir amb altres referències `&T`, però no amb un `&mut T`
///
/// 2. Es pot alliberar una referència `&mut T` al codi segur sempre que no hi convisquin cap altre `&mut T` ni `&T`.Un `&mut T` sempre ha de ser únic.
///
/// Tingueu en compte que, tot i mutar el contingut d'un `&UnsafeCell<T>` (fins i tot mentre altres referències `&UnsafeCell<T>` són àlies de la cel・la), està bé (sempre que apliqueu els invariants anteriors d'alguna altra manera), encara és un comportament indefinit tenir diversos àlies `&mut UnsafeCell<T>`.
/// És a dir, `UnsafeCell` és un embolcall dissenyat per tenir una interacció especial amb _shared_ accesses (_i.e._, mitjançant una referència `&UnsafeCell<_>`);no hi ha cap mena de màgia quan es tracta de _exclusive_ accesses (_e.g._, mitjançant un `&mut UnsafeCell<_>`): ni la cel・la ni el valor embolicat poden estar aliats durant la durada d'aquest préstec `&mut`.
///
/// Ho mostra l'accessor [`.get_mut()`], que és un _safe_ getter que proporciona un `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Aquí teniu un exemple que mostra com mutar profundament el contingut d`un `UnsafeCell<_>` tot i haver-hi múltiples referències que aliasen la cel・la:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Obteniu referències múltiples/simultànies/compartides al mateix `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // SEGURETAT: dins d'aquest àmbit no hi ha altres referències als continguts de "x",
///     // de manera que el nostre és efectivament únic.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- manllevar-+
///     *p1_exclusive += 27; // |
/// } // <---------- no pot anar més enllà d`aquest punt -------------------+
///
/// unsafe {
///     // SEGURETAT: dins d'aquest àmbit ningú espera tenir accés exclusiu als continguts de "x",
///     // de manera que podem tenir diversos accessos compartits simultàniament.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// L'exemple següent mostra el fet que l'accés exclusiu a un `UnsafeCell<T>` implica accés exclusiu al seu `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // amb accessos exclusius,
///                         // `UnsafeCell` és un embolcall transparent sense operacions, de manera que no necessiteu `unsafe` aquí.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Obteniu una referència única comprovada en temps de compilació a `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Amb una referència exclusiva, podem mutar els continguts de forma gratuïta.
/// *p_unique.get_mut() = 0;
/// // O, equivalentment:
/// x = UnsafeCell::new(0);
///
/// // Quan posseïm el valor, podem extreure'n el contingut gratuïtament.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Construeix una nova instància de `UnsafeCell` que ajustarà el valor especificat.
    ///
    ///
    /// Tot l`accés al valor intern mitjançant mètodes és `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Desenfoca el valor.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Obté un punter mutable al valor ajustat.
    ///
    /// Això es pot convertir en un punter de qualsevol tipus.
    /// Assegureu-vos que l`accés sigui únic (no hi hagi referències actives, es pugui modificar o no) en emetre a `&mut T` i assegureu-vos que no hi hagi mutacions ni àlies mutables en passar a `&T`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Només podem emetre el punter de `UnsafeCell<T>` a `T` a causa de #[repr(transparent)].
        // Això explota l'estat especial de libstd, no hi ha cap garantia per al codi d'usuari que funcioni a les versions future del compilador.
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Retorna una referència mutable a les dades subjacents.
    ///
    /// Aquesta trucada presta el `UnsafeCell` mutablement (en temps de compilació), cosa que garanteix que posseïm l'única referència.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Obté un punter mutable al valor ajustat.
    /// La diferència amb [`get`] és que aquesta funció accepta un punter en brut, que és útil per evitar la creació de referències temporals.
    ///
    /// El resultat es pot emetre a un punter de qualsevol tipus.
    /// Assegureu-vos que l'accés sigui únic (no hi ha referències actives, es pot modificar o no) en emetre a `&mut T` i assegureu-vos que no hi hagi mutacions ni àlies mutables en emetre's a `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// La inicialització gradual d`un `UnsafeCell` requereix `raw_get`, ja que per trucar a `get` caldria crear una referència a dades no inicialitzades:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Només podem emetre el punter de `UnsafeCell<T>` a `T` a causa de #[repr(transparent)].
        // Això explota l'estat especial de libstd, no hi ha cap garantia per al codi d'usuari que funcioni a les versions future del compilador.
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Crea un `UnsafeCell`, amb el valor `Default` per a T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}