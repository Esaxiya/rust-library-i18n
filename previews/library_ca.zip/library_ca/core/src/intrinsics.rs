//! Intrínsecs del compilador.
//!
//! Les definicions corresponents es mostren en `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Les implementacions constants corresponents es troben a `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intrínsecs
//!
//! Note: qualsevol canvi en la constància dels elements intrínsecs s'ha de discutir amb l'equip lingüístic.
//! Això inclou canvis en l'estabilitat de la constància.
//!
//! Per tal de fer un intrínsec usable en temps de compilació, cal copiar la implementació de <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> a `compiler/rustc_mir/src/interpret/intrinsics.rs` i afegir un `#[rustc_const_unstable(feature = "foo", issue = "01234")]` a l'intrínsec.
//!
//!
//! Si se suposa que s'utilitza un intrínsec des d'un `const fn` amb un atribut `rustc_const_stable`, també l'atribut de l'intrínsec ha de ser `rustc_const_stable`.
//! Aquest canvi no s'hauria de fer sense la consulta de T-lang, perquè proporciona una característica al llenguatge que no es pot replicar al codi d'usuari sense el suport del compilador.
//!
//! # Volatiles
//!
//! Els sistemes intrínsecs volàtils proporcionen operacions destinades a actuar sobre la memòria I/O, que el compilador garanteix que no reordenarà a través d'altres sistemes intrínsecs volàtils.Consulteu la documentació LLVM a [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Els intrínsecs atòmics proporcionen operacions atòmiques habituals en paraules màquina, amb múltiples possibles ordres de memòria.Obeeixen la mateixa semàntica que C++ 11.Consulteu la documentació LLVM a [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Una actualització ràpida de l`ordenació de memòria:
//!
//! * Adquirir, una barrera per adquirir un pany.Les lectures i escriptures posteriors tenen lloc després de la barrera.
//! * Alliberament, una barrera per alliberar un pany.Les lectures i escriptures anteriors tenen lloc abans de la barrera.
//! * Es garanteix que les operacions seqüencialment consistents i seqüencialment coherents passin per ordre.Aquest és el mode estàndard per treballar amb tipus atòmics i equival al `volatile` de Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Aquestes importacions s`utilitzen per simplificar els enllaços intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SEGURETAT: vegeu `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // Tingueu en compte que aquests elements intrínsecs prenen indicadors sense processar perquè muten la memòria aliasitzada, cosa que no és vàlida per a `&` ni `&mut`.
    //

    /// Emmagatzema un valor si el valor actual és el mateix que el valor `old`.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `compare_exchange` passant [`Ordering::SeqCst`] com a paràmetres `success` i `failure`.
    ///
    /// Per exemple, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Emmagatzema un valor si el valor actual és el mateix que el valor `old`.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `compare_exchange` passant [`Ordering::Acquire`] com a paràmetres `success` i `failure`.
    ///
    /// Per exemple, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Emmagatzema un valor si el valor actual és el mateix que el valor `old`.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `compare_exchange` passant [`Ordering::Release`] com a `success` i [`Ordering::Relaxed`] com a paràmetres `failure`.
    /// Per exemple, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Emmagatzema un valor si el valor actual és el mateix que el valor `old`.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `compare_exchange` passant [`Ordering::AcqRel`] com a `success` i [`Ordering::Acquire`] com a paràmetres `failure`.
    /// Per exemple, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Emmagatzema un valor si el valor actual és el mateix que el valor `old`.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `compare_exchange` passant [`Ordering::Relaxed`] com a paràmetres `success` i `failure`.
    ///
    /// Per exemple, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Emmagatzema un valor si el valor actual és el mateix que el valor `old`.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `compare_exchange` passant [`Ordering::SeqCst`] com a `success` i [`Ordering::Relaxed`] com a paràmetres `failure`.
    /// Per exemple, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Emmagatzema un valor si el valor actual és el mateix que el valor `old`.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `compare_exchange` passant [`Ordering::SeqCst`] com a `success` i [`Ordering::Acquire`] com a paràmetres `failure`.
    /// Per exemple, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Emmagatzema un valor si el valor actual és el mateix que el valor `old`.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `compare_exchange` passant [`Ordering::Acquire`] com a `success` i [`Ordering::Relaxed`] com a paràmetres `failure`.
    /// Per exemple, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Emmagatzema un valor si el valor actual és el mateix que el valor `old`.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `compare_exchange` passant [`Ordering::AcqRel`] com a `success` i [`Ordering::Relaxed`] com a paràmetres `failure`.
    /// Per exemple, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Emmagatzema un valor si el valor actual és el mateix que el valor `old`.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `compare_exchange_weak` passant [`Ordering::SeqCst`] com a paràmetres `success` i `failure`.
    ///
    /// Per exemple, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Emmagatzema un valor si el valor actual és el mateix que el valor `old`.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `compare_exchange_weak` passant [`Ordering::Acquire`] com a paràmetres `success` i `failure`.
    ///
    /// Per exemple, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Emmagatzema un valor si el valor actual és el mateix que el valor `old`.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `compare_exchange_weak` passant [`Ordering::Release`] com a `success` i [`Ordering::Relaxed`] com a paràmetres `failure`.
    /// Per exemple, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Emmagatzema un valor si el valor actual és el mateix que el valor `old`.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `compare_exchange_weak` passant [`Ordering::AcqRel`] com a `success` i [`Ordering::Acquire`] com a paràmetres `failure`.
    /// Per exemple, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Emmagatzema un valor si el valor actual és el mateix que el valor `old`.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `compare_exchange_weak` passant [`Ordering::Relaxed`] com a paràmetres `success` i `failure`.
    ///
    /// Per exemple, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Emmagatzema un valor si el valor actual és el mateix que el valor `old`.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `compare_exchange_weak` passant [`Ordering::SeqCst`] com a `success` i [`Ordering::Relaxed`] com a paràmetres `failure`.
    /// Per exemple, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Emmagatzema un valor si el valor actual és el mateix que el valor `old`.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `compare_exchange_weak` passant [`Ordering::SeqCst`] com a `success` i [`Ordering::Acquire`] com a paràmetres `failure`.
    /// Per exemple, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Emmagatzema un valor si el valor actual és el mateix que el valor `old`.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `compare_exchange_weak` passant [`Ordering::Acquire`] com a `success` i [`Ordering::Relaxed`] com a paràmetres `failure`.
    /// Per exemple, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Emmagatzema un valor si el valor actual és el mateix que el valor `old`.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `compare_exchange_weak` passant [`Ordering::AcqRel`] com a `success` i [`Ordering::Relaxed`] com a paràmetres `failure`.
    /// Per exemple, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Carrega el valor actual del punter.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `load` passant [`Ordering::SeqCst`] com a `order`.
    /// Per exemple, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Carrega el valor actual del punter.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `load` passant [`Ordering::Acquire`] com a `order`.
    /// Per exemple, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Carrega el valor actual del punter.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `load` passant [`Ordering::Relaxed`] com a `order`.
    /// Per exemple, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Emmagatzema el valor a la ubicació de memòria especificada.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `store` passant [`Ordering::SeqCst`] com a `order`.
    /// Per exemple, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Emmagatzema el valor a la ubicació de memòria especificada.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `store` passant [`Ordering::Release`] com a `order`.
    /// Per exemple, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Emmagatzema el valor a la ubicació de memòria especificada.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `store` passant [`Ordering::Relaxed`] com a `order`.
    /// Per exemple, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Emmagatzema el valor a la ubicació de memòria especificada, retornant el valor antic.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `swap` passant [`Ordering::SeqCst`] com a `order`.
    /// Per exemple, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Emmagatzema el valor a la ubicació de memòria especificada, retornant el valor antic.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `swap` passant [`Ordering::Acquire`] com a `order`.
    /// Per exemple, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Emmagatzema el valor a la ubicació de memòria especificada, retornant el valor antic.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `swap` passant [`Ordering::Release`] com a `order`.
    /// Per exemple, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Emmagatzema el valor a la ubicació de memòria especificada, retornant el valor antic.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `swap` passant [`Ordering::AcqRel`] com a `order`.
    /// Per exemple, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Emmagatzema el valor a la ubicació de memòria especificada, retornant el valor antic.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `swap` passant [`Ordering::Relaxed`] com a `order`.
    /// Per exemple, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// S'afegeix al valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_add` passant [`Ordering::SeqCst`] com a `order`.
    /// Per exemple, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// S'afegeix al valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_add` passant [`Ordering::Acquire`] com a `order`.
    /// Per exemple, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// S'afegeix al valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_add` passant [`Ordering::Release`] com a `order`.
    /// Per exemple, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// S'afegeix al valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_add` passant [`Ordering::AcqRel`] com a `order`.
    /// Per exemple, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// S'afegeix al valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_add` passant [`Ordering::Relaxed`] com a `order`.
    /// Per exemple, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Restar del valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_sub` passant [`Ordering::SeqCst`] com a `order`.
    /// Per exemple, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Restar del valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_sub` passant [`Ordering::Acquire`] com a `order`.
    /// Per exemple, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Restar del valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_sub` passant [`Ordering::Release`] com a `order`.
    /// Per exemple, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Restar del valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_sub` passant [`Ordering::AcqRel`] com a `order`.
    /// Per exemple, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Restar del valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_sub` passant [`Ordering::Relaxed`] com a `order`.
    /// Per exemple, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// A bits i amb el valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_and` passant [`Ordering::SeqCst`] com a `order`.
    /// Per exemple, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// A bits i amb el valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_and` passant [`Ordering::Acquire`] com a `order`.
    /// Per exemple, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// A bits i amb el valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_and` passant [`Ordering::Release`] com a `order`.
    /// Per exemple, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// A bits i amb el valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_and` passant [`Ordering::AcqRel`] com a `order`.
    /// Per exemple, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// A bits i amb el valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_and` passant [`Ordering::Relaxed`] com a `order`.
    /// Per exemple, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// NAND a bits i amb el valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible al tipus [`AtomicBool`] mitjançant el mètode `fetch_nand` passant [`Ordering::SeqCst`] com a `order`.
    /// Per exemple, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// NAND a bits i amb el valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible al tipus [`AtomicBool`] mitjançant el mètode `fetch_nand` passant [`Ordering::Acquire`] com a `order`.
    /// Per exemple, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// NAND a bits i amb el valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible al tipus [`AtomicBool`] mitjançant el mètode `fetch_nand` passant [`Ordering::Release`] com a `order`.
    /// Per exemple, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// NAND a bits i amb el valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible al tipus [`AtomicBool`] mitjançant el mètode `fetch_nand` passant [`Ordering::AcqRel`] com a `order`.
    /// Per exemple, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// NAND a bits i amb el valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible al tipus [`AtomicBool`] mitjançant el mètode `fetch_nand` passant [`Ordering::Relaxed`] com a `order`.
    /// Per exemple, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// A bits o amb el valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_or` passant [`Ordering::SeqCst`] com a `order`.
    /// Per exemple, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// A bits o amb el valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_or` passant [`Ordering::Acquire`] com a `order`.
    /// Per exemple, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// A bits o amb el valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_or` passant [`Ordering::Release`] com a `order`.
    /// Per exemple, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// A bits o amb el valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_or` passant [`Ordering::AcqRel`] com a `order`.
    /// Per exemple, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// A bits o amb el valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_or` passant [`Ordering::Relaxed`] com a `order`.
    /// Per exemple, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Xor a bits amb el valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_xor` passant [`Ordering::SeqCst`] com a `order`.
    /// Per exemple, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Xor a bits amb el valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_xor` passant [`Ordering::Acquire`] com a `order`.
    /// Per exemple, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Xor a bits amb el valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_xor` passant [`Ordering::Release`] com a `order`.
    /// Per exemple, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Xor a bits amb el valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_xor` passant [`Ordering::AcqRel`] com a `order`.
    /// Per exemple, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Xor a bits amb el valor actual, retornant el valor anterior.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en els tipus [`atomic`] mitjançant el mètode `fetch_xor` passant [`Ordering::Relaxed`] com a `order`.
    /// Per exemple, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Màxim amb el valor actual mitjançant una comparació signada.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible als tipus enters signats [`atomic`] mitjançant el mètode `fetch_max` passant [`Ordering::SeqCst`] com a `order`.
    /// Per exemple, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Màxim amb el valor actual mitjançant una comparació signada.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible als tipus enters signats [`atomic`] mitjançant el mètode `fetch_max` passant [`Ordering::Acquire`] com a `order`.
    /// Per exemple, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Màxim amb el valor actual mitjançant una comparació signada.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible als tipus enters signats [`atomic`] mitjançant el mètode `fetch_max` passant [`Ordering::Release`] com a `order`.
    /// Per exemple, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Màxim amb el valor actual mitjançant una comparació signada.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible als tipus enters signats [`atomic`] mitjançant el mètode `fetch_max` passant [`Ordering::AcqRel`] com a `order`.
    /// Per exemple, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Màxim amb el valor actual.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible als tipus enters signats [`atomic`] mitjançant el mètode `fetch_max` passant [`Ordering::Relaxed`] com a `order`.
    /// Per exemple, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Mínim amb el valor actual mitjançant una comparació signada.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible als tipus enters signats [`atomic`] mitjançant el mètode `fetch_min` passant [`Ordering::SeqCst`] com a `order`.
    /// Per exemple, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínim amb el valor actual mitjançant una comparació signada.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible als tipus enters signats [`atomic`] mitjançant el mètode `fetch_min` passant [`Ordering::Acquire`] com a `order`.
    /// Per exemple, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínim amb el valor actual mitjançant una comparació signada.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible als tipus enters signats [`atomic`] mitjançant el mètode `fetch_min` passant [`Ordering::Release`] com a `order`.
    /// Per exemple, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínim amb el valor actual mitjançant una comparació signada.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible als tipus enters signats [`atomic`] mitjançant el mètode `fetch_min` passant [`Ordering::AcqRel`] com a `order`.
    /// Per exemple, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínim amb el valor actual mitjançant una comparació signada.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible als tipus enters signats [`atomic`] mitjançant el mètode `fetch_min` passant [`Ordering::Relaxed`] com a `order`.
    /// Per exemple, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Mínim amb el valor actual mitjançant una comparació sense signar.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible als tipus enters sense signar [`atomic`] mitjançant el mètode `fetch_min` passant [`Ordering::SeqCst`] com a `order`.
    /// Per exemple, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínim amb el valor actual mitjançant una comparació sense signar.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible als tipus enters sense signar [`atomic`] mitjançant el mètode `fetch_min` passant [`Ordering::Acquire`] com a `order`.
    /// Per exemple, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínim amb el valor actual mitjançant una comparació sense signar.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible als tipus enters sense signar [`atomic`] mitjançant el mètode `fetch_min` passant [`Ordering::Release`] com a `order`.
    /// Per exemple, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínim amb el valor actual mitjançant una comparació sense signar.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible als tipus enters sense signar [`atomic`] mitjançant el mètode `fetch_min` passant [`Ordering::AcqRel`] com a `order`.
    /// Per exemple, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mínim amb el valor actual mitjançant una comparació sense signar.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible als tipus enters sense signar [`atomic`] mitjançant el mètode `fetch_min` passant [`Ordering::Relaxed`] com a `order`.
    /// Per exemple, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Màxim amb el valor actual mitjançant una comparació sense signar.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible als tipus enters sense signar [`atomic`] mitjançant el mètode `fetch_max` passant [`Ordering::SeqCst`] com a `order`.
    /// Per exemple, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Màxim amb el valor actual mitjançant una comparació sense signar.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible als tipus enters sense signar [`atomic`] mitjançant el mètode `fetch_max` passant [`Ordering::Acquire`] com a `order`.
    /// Per exemple, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Màxim amb el valor actual mitjançant una comparació sense signar.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible als tipus enters sense signar [`atomic`] mitjançant el mètode `fetch_max` passant [`Ordering::Release`] com a `order`.
    /// Per exemple, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Màxim amb el valor actual mitjançant una comparació sense signar.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible als tipus enters sense signar [`atomic`] mitjançant el mètode `fetch_max` passant [`Ordering::AcqRel`] com a `order`.
    /// Per exemple, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Màxim amb el valor actual mitjançant una comparació sense signar.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible als tipus enters sense signar [`atomic`] mitjançant el mètode `fetch_max` passant [`Ordering::Relaxed`] com a `order`.
    /// Per exemple, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// El `prefetch` intrínsec és un suggeriment per al generador de codi per inserir una instrucció de prefetch si és compatible;en cas contrari, és un no-op.
    /// Els prefets no tenen cap efecte sobre el comportament del programa, però poden canviar les seves característiques de rendiment.
    ///
    /// L'argument `locality` ha de ser un enter constant i és un especificador de localitat temporal que va des de (0), sense localitat, fins a (3), manteniment extremadament local a la memòria cau.
    ///
    ///
    /// Aquest intrínsec no té una contrapart estable.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// El `prefetch` intrínsec és un suggeriment per al generador de codi per inserir una instrucció de prefetch si és compatible;en cas contrari, és un no-op.
    /// Els prefets no tenen cap efecte sobre el comportament del programa, però poden canviar les seves característiques de rendiment.
    ///
    /// L'argument `locality` ha de ser un enter constant i és un especificador de localitat temporal que va des de (0), sense localitat, fins a (3), manteniment extremadament local a la memòria cau.
    ///
    ///
    /// Aquest intrínsec no té una contrapart estable.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// El `prefetch` intrínsec és un suggeriment per al generador de codi per inserir una instrucció de prefetch si és compatible;en cas contrari, és un no-op.
    /// Els prefets no tenen cap efecte sobre el comportament del programa, però poden canviar les seves característiques de rendiment.
    ///
    /// L'argument `locality` ha de ser un enter constant i és un especificador de localitat temporal que va des de (0), sense localitat, fins a (3), manteniment extremadament local a la memòria cau.
    ///
    ///
    /// Aquest intrínsec no té una contrapart estable.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// El `prefetch` intrínsec és un suggeriment per al generador de codi per inserir una instrucció de prefetch si és compatible;en cas contrari, és un no-op.
    /// Els prefets no tenen cap efecte sobre el comportament del programa, però poden canviar les seves característiques de rendiment.
    ///
    /// L'argument `locality` ha de ser un enter constant i és un especificador de localitat temporal que va des de (0), sense localitat, fins a (3), manteniment extremadament local a la memòria cau.
    ///
    ///
    /// Aquest intrínsec no té una contrapart estable.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Una tanca atòmica.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en [`atomic::fence`] passant [`Ordering::SeqCst`] com a `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Una tanca atòmica.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en [`atomic::fence`] passant [`Ordering::Acquire`] com a `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Una tanca atòmica.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en [`atomic::fence`] passant [`Ordering::Release`] com a `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Una tanca atòmica.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en [`atomic::fence`] passant [`Ordering::AcqRel`] com a `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Una barrera de memòria només per a compiladors.
    ///
    /// El compilador no reordenarà mai els accessos a la memòria a través d`aquesta barrera, però no s`emetran instruccions.
    /// Això és adequat per a operacions en el mateix fil que es poden evitar, com ara quan interactueu amb gestors de senyals.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en [`atomic::compiler_fence`] passant [`Ordering::SeqCst`] com a `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Una barrera de memòria només per a compiladors.
    ///
    /// El compilador no reordenarà mai els accessos a la memòria a través d`aquesta barrera, però no s`emetran instruccions.
    /// Això és adequat per a operacions en el mateix fil que es poden evitar, com ara quan interactueu amb gestors de senyals.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en [`atomic::compiler_fence`] passant [`Ordering::Acquire`] com a `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Una barrera de memòria només per a compiladors.
    ///
    /// El compilador no reordenarà mai els accessos a la memòria a través d`aquesta barrera, però no s`emetran instruccions.
    /// Això és adequat per a operacions en el mateix fil que es poden evitar, com ara quan interactueu amb gestors de senyals.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en [`atomic::compiler_fence`] passant [`Ordering::Release`] com a `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Una barrera de memòria només per a compiladors.
    ///
    /// El compilador no reordenarà mai els accessos a la memòria a través d`aquesta barrera, però no s`emetran instruccions.
    /// Això és adequat per a operacions en el mateix fil que es poden evitar, com ara quan interactueu amb gestors de senyals.
    ///
    /// La versió estabilitzada d`aquest intrínsec està disponible en [`atomic::compiler_fence`] passant [`Ordering::AcqRel`] com a `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Màgia intrínseca que deriva el seu significat d`atributs units a la funció.
    ///
    /// Per exemple, dataflow utilitza això per injectar afirmacions estàtiques de manera que `rustc_peek(potentially_uninitialized)` realment comprovaria que el flux de dades realment calculés que no està inicialitzat en aquest punt del flux de control.
    ///
    ///
    /// Aquest intrínsec no s'ha d'utilitzar fora del compilador.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Interromp l'execució del procés.
    ///
    /// Una versió més fàcil d'utilitzar i estable d'aquesta operació és [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Informa l`optimitzador que no es pot accedir a aquest punt del codi, cosa que permet optimitzacions addicionals.
    ///
    /// NB, això és molt diferent de la macro `unreachable!()`: a diferència de la macro, que panics s'executa, és *comportament indefinit* arribar al codi marcat amb aquesta funció.
    ///
    ///
    /// La versió estabilitzada d`aquest intrínsec és [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Informa a l`optimitzador que una condició sempre és certa.
    /// Si la condició és falsa, el comportament no està definit.
    ///
    /// No es genera cap codi per a aquest intrínsec, però l`optimitzador intentarà preservar-lo (i el seu estat) entre passades, cosa que pot interferir amb l`optimització del codi circumdant i reduir el rendiment.
    /// No s`ha d`utilitzar si l`optimitzador pot descobrir l`invariant tot sol, o si no permet optimitzacions significatives.
    ///
    /// Aquest intrínsec no té una contrapart estable.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Suggeriments per al compilador que és probable que la condició branch sigui certa.
    /// Retorna el valor que se li ha passat.
    ///
    /// Qualsevol ús que no sigui amb instruccions `if` probablement no tindrà efecte.
    ///
    /// Aquest intrínsec no té una contrapart estable.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Suggeriments per al compilador que és probable que la condició branch sigui falsa.
    /// Retorna el valor que se li ha passat.
    ///
    /// Qualsevol ús que no sigui amb instruccions `if` probablement no tindrà efecte.
    ///
    /// Aquest intrínsec no té una contrapart estable.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Executa una trampa de punts d'interrupció per a la inspecció d'un depurador.
    ///
    /// Aquest intrínsec no té una contrapart estable.
    pub fn breakpoint();

    /// La mida d`un tipus en bytes.
    ///
    /// Més concretament, es tracta del desplaçament en bytes entre elements successius del mateix tipus, inclòs el farciment d'alineació.
    ///
    ///
    /// La versió estabilitzada d`aquest intrínsec és [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// L'alineació mínima d'un tipus.
    ///
    /// La versió estabilitzada d`aquest intrínsec és [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// L'alineació preferida d'un tipus.
    ///
    /// Aquest intrínsec no té una contrapart estable.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// La mida del valor referenciat en bytes.
    ///
    /// La versió estabilitzada d`aquest intrínsec és [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// L'alineació necessària del valor a què fa referència.
    ///
    /// La versió estabilitzada d`aquest intrínsec és [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Obté un segment de cadena estàtica que conté el nom d'un tipus.
    ///
    /// La versió estabilitzada d`aquest intrínsec és [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Obté un identificador que és exclusiu globalment del tipus especificat.
    /// Aquesta funció retornarà el mateix valor per a un tipus independentment de qualsevol crate en què s'invoqui.
    ///
    ///
    /// La versió estabilitzada d`aquest intrínsec és [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Una protecció per a funcions insegures que mai no es poden executar si `T` està deshabitat:
    /// Això farà estàticament panic o no farà res.
    ///
    /// Aquest intrínsec no té una contrapart estable.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Una protecció per a funcions no segures que mai no es poden executar si `T` no permet la inicialització zero: això farà estàticament panic o no farà res.
    ///
    ///
    /// Aquest intrínsec no té una contrapart estable.
    pub fn assert_zero_valid<T>();

    /// Una protecció per a funcions insegures que mai no es poden executar si `T` té patrons de bits no vàlids: això farà estàticament panic o no farà res.
    ///
    ///
    /// Aquest intrínsec no té una contrapart estable.
    pub fn assert_uninit_valid<T>();

    /// Obté una referència a un `Location` estàtic que indica on es va cridar.
    ///
    /// Penseu a utilitzar [`core::panic::Location::caller`](crate::panic::Location::caller) al seu lloc.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Mou un valor fora de l'abast sense executar cola de gota.
    ///
    /// Això existeix exclusivament per a [`mem::forget_unsized`];`forget` normal utilitza `ManuallyDrop` al seu lloc.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Reinterpreta els bits d'un valor d'un tipus com un altre tipus.
    ///
    /// Els dos tipus han de tenir la mateixa mida.
    /// Ni l'original ni el resultat poden ser un [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` és semànticament equivalent a un moviment bit a bit d'un tipus a un altre.Copia els bits del valor font al valor de destinació i després oblida l'original.
    /// És equivalent a C's `memcpy` sota el capó, igual que `transmute_copy`.
    ///
    /// Com que `transmute` és una operació de valor secundari, l'alineació dels *propis valors transmutats* no és preocupant.
    /// Com passa amb qualsevol altra funció, el compilador ja garanteix que `T` i `U` estiguin correctament alineats.
    /// Tanmateix, quan es transmeten valors que *apunten a un altre lloc*(com ara punteres, referències, quadres ...), la persona que truca ha de garantir l'alineació adequada dels valors apuntats.
    ///
    /// `transmute` és **increïblement** insegur.Hi ha una gran quantitat de maneres de provocar [undefined behavior][ub] amb aquesta funció.`transmute` hauria de ser l`últim recurs absolut.
    ///
    /// El [nomicon](../../nomicon/transmutes.html) té documentació addicional.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Hi ha algunes coses per a les quals `transmute` és realment útil.
    ///
    /// Convertir un punter en un punter de funció.Això no és * portable per a màquines on els indicadors de funció i els indicadors de dades tenen mides diferents.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Ampliar la vida útil o escurçar una vida invariable.Això és avançat, molt insegur Rust.
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// No us desespereu: molts usos de `transmute` es poden aconseguir per altres mitjans.
    /// A continuació es mostren les aplicacions habituals de `transmute` que es poden substituir per construccions més segures.
    ///
    /// Convertir bytes(`&[u8]`) en brut a `u32`, `f64`, etc.:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // utilitzeu `u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // o utilitzeu `u32::from_le_bytes` o `u32::from_be_bytes` per especificar l`endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Convertir un punter en un `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Utilitzeu un repartiment `as`
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Convertir un `*mut T` en un `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Utilitzeu un reborrow en el seu lloc
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Convertir un `&mut T` en un `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Ara, ajunteu `as` i torneu a tenir en compte, tingueu en compte que l'encadenament de `as` `as` no és transitiu
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Convertir un `&str` en un `&[u8]`:
    ///
    /// ```
    /// // aquesta no és una bona manera de fer-ho.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Podeu utilitzar `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // O bé, feu servir una cadena de bytes, si teniu control sobre la cadena literal
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Convertir un `Vec<&T>` en un `Vec<Option<&T>>`.
    ///
    /// Per transmutar el tipus intern del contingut d'un contenidor, heu d'assegurar-vos que no infringiu cap dels invariants del contenidor.
    /// Per a `Vec`, això significa que tant la mida *com l'alineació* dels tipus interiors han de coincidir.
    /// Altres contenidors poden dependre de la mida del tipus, l'alineació o fins i tot el `TypeId`, en aquest cas la transmutació no seria possible sense violar els invariants dels contenidors.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // cloneu el vector ja que els tornarem a utilitzar més endavant
    /// let v_clone = v_orig.clone();
    ///
    /// // Utilitzant transmutació: es basa en el disseny de dades no especificat de `Vec`, que és una mala idea i pot provocar un comportament indefinit.
    /////
    /// // Tot i això, no es pot copiar.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Aquesta és la manera segura suggerida.
    /// // No obstant això, copia tot el vector en una nova matriu.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Aquesta és la forma segura de no copiar, no segura, de "transmuting" a `Vec`, sense confiar en el disseny de dades.
    /// // En lloc de trucar literalment a `transmute`, realitzem un repartiment de punter, però pel que fa a la conversió del tipus interior original (`&i32`) al nou (`Option<&i32>`), té totes les mateixes advertències.
    /////
    /// // A més de la informació proporcionada anteriorment, també consulteu la documentació [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Actualitzeu-ho quan vec_into_raw_parts s'estabilitzi.
    ///     // Assegureu-vos que el vector original no es deixa caure.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Implementació de `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Hi ha diverses maneres de fer-ho i hi ha diversos problemes amb la següent manera (transmute).
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // primer: el transmutat no és segur;tot el que comprova és que T i
    ///         // U tenen la mateixa mida.
    ///         // En segon lloc, aquí mateix, teniu dues referències mutables que apunten a la mateixa memòria.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Això elimina els problemes de seguretat del tipus;`&mut *`* només *us proporcionarà un `&mut T` d'un `&mut T` o `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // tanmateix, encara teniu dues referències mutables que apunten a la mateixa memòria.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Així ho fa la biblioteca estàndard.
    /// // Aquest és el millor mètode, si cal fer alguna cosa així
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Ara té tres referències mutables que apunten a la mateixa memòria.`slice`, el valor ret.0 i el valor ret.1.
    ///         // `slice` mai no s'utilitza després de `let ptr = ...`, de manera que es pot tractar com "dead" i, per tant, només teniu dos talls reals mutables.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Tot i que això fa que la const intrínseca sigui estable, tenim algun codi personalitzat a const fn
    // comprovacions que impedeixen el seu ús dins de `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Retorna `true` si el tipus real indicat com a `T` requereix cola de gota;retorna `false` si el tipus real proporcionat per `T` implementa `Copy`.
    ///
    ///
    /// Si el tipus real no requereix cap cola ni implementa `Copy`, el valor de retorn d'aquesta funció no s'especifica.
    ///
    /// La versió estabilitzada d`aquest intrínsec és [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Calcula el desplaçament d'un punter.
    ///
    /// Això s`implementa com a intrínsec per evitar la conversió a i des d`un enter, ja que la conversió llençaria informació d`aliasing.
    ///
    /// # Safety
    ///
    /// Tant el punter inicial com el resultant han d'estar entre límits o un byte més enllà del final d'un objecte assignat.
    /// Si el punter està fora dels límits o es produeix un desbordament aritmètic, qualsevol altre ús del valor retornat comportarà un comportament indefinit.
    ///
    ///
    /// La versió estabilitzada d`aquest intrínsec és [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Calcula el desplaçament d'un punter, que pot ser ajustat.
    ///
    /// Això s`implementa com a intrínsec per evitar la conversió a i des d`un enter, ja que la conversió inhibeix certes optimitzacions.
    ///
    /// # Safety
    ///
    /// A diferència de l`intrínsec `offset`, aquest intrínsec no restringeix el punter resultant per apuntar cap a un objecte assignat o passar-ne un byte i s`ajusta amb l`aritmètica del complement de dos.
    /// El valor resultant no és necessàriament vàlid per utilitzar-se per accedir realment a la memòria.
    ///
    /// La versió estabilitzada d`aquest intrínsec és [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Equival a l`intrínsec `llvm.memcpy.p0i8.0i8.*` adequat, amb una mida de `count`*`size_of::<T>()` i una alineació de
    ///
    /// `min_align_of::<T>()`
    ///
    /// El paràmetre volàtil s'estableix en `true`, de manera que no s'optimitzarà tret que la mida sigui igual a zero.
    ///
    /// Aquest intrínsec no té una contrapart estable.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Equival a la intrínseca `llvm.memmove.p0i8.0i8.*` adequada, amb una mida de `count* size_of::<T>()` i una alineació de
    ///
    /// `min_align_of::<T>()`
    ///
    /// El paràmetre volàtil s'estableix en `true`, de manera que no s'optimitzarà tret que la mida sigui igual a zero.
    ///
    /// Aquest intrínsec no té una contrapart estable.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Equival a l`intrínsec `llvm.memset.p0i8.*` adequat, amb una mida de `count* size_of::<T>()` i una alineació de `min_align_of::<T>()`.
    ///
    ///
    /// El paràmetre volàtil s'estableix en `true`, de manera que no s'optimitzarà tret que la mida sigui igual a zero.
    ///
    /// Aquest intrínsec no té una contrapart estable.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Realitza una càrrega volàtil des del punter `src`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Realitza un emmagatzematge volàtil al punter `dst`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Realitza una càrrega volàtil des del punter `src` No cal alinear el punter.
    ///
    ///
    /// Aquest intrínsec no té una contrapart estable.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Realitza un emmagatzematge volàtil al punter `dst`.
    /// No cal que el punter estigui alineat.
    ///
    /// Aquest intrínsec no té una contrapart estable.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Retorna l'arrel quadrada d'un `f32`
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Retorna l'arrel quadrada d'un `f64`
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Augmenta un `f32` a una potència sencera.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Augmenta un `f64` a una potència sencera.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Retorna el sinus d'un `f32`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Retorna el sinus d'un `f64`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Retorna el cosinus d'un `f32`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Retorna el cosinus d'un `f64`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Augmenta un `f32` a un `f32` de potència.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Augmenta un `f64` a un `f64` de potència.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Retorna l'exponent d'un `f32`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Retorna l'exponent d'un `f64`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Retorna 2 elevat a la potència d'un `f32`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Retorna 2 elevat a la potència d'un `f64`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Retorna el logaritme natural d'un `f32`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Retorna el logaritme natural d'un `f64`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Retorna el logaritme base 10 d'un `f32`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Retorna el logaritme base 10 d'un `f64`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Retorna el logaritme de base 2 d'un `f32`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Retorna el logaritme de base 2 d'un `f64`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Retorna `a * b + c` per als valors `f32`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Retorna `a * b + c` per als valors `f64`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Retorna el valor absolut d'un `f32`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Retorna el valor absolut d'un `f64`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Retorna el mínim de dos valors `f32`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Retorna el mínim de dos valors `f64`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Retorna el màxim de dos valors `f32`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Retorna el màxim de dos valors `f64`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Copia el signe de `y` a `x` per als valors `f32`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Copia el signe de `y` a `x` per als valors `f64`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Retorna el nombre enter més gran inferior o igual a un `f32`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Retorna el nombre enter més gran inferior o igual a un `f64`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Retorna el nombre enter més petit superior o igual a un `f32`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Retorna el nombre enter més petit superior o igual a un `f64`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Retorna la part sencera d'un `f32`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Retorna la part sencera d'un `f64`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Retorna el nombre enter més proper a un `f32`.
    /// Pot generar una excepció de punt flotant inexacta si l'argument no és un nombre enter.
    pub fn rintf32(x: f32) -> f32;
    /// Retorna el nombre enter més proper a un `f64`.
    /// Pot generar una excepció de punt flotant inexacta si l'argument no és un nombre enter.
    pub fn rintf64(x: f64) -> f64;

    /// Retorna el nombre enter més proper a un `f32`.
    ///
    /// Aquest intrínsec no té una contrapart estable.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Retorna el nombre enter més proper a un `f64`.
    ///
    /// Aquest intrínsec no té una contrapart estable.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Retorna el nombre enter més proper a un `f32`.Arrodoneix casos a mig camí de zero.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Retorna el nombre enter més proper a un `f64`.Arrodoneix casos a mig camí de zero.
    ///
    /// La versió estabilitzada d`aquest intrínsec és
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Addició flotant que permet optimitzacions basades en regles algebraiques.
    /// Podem suposar que les entrades són finites.
    ///
    /// Aquest intrínsec no té una contrapart estable.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Resta flotant que permet optimitzacions basades en regles algebraiques.
    /// Podem suposar que les entrades són finites.
    ///
    /// Aquest intrínsec no té una contrapart estable.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Multiplicació flotant que permet optimitzacions basades en regles algebraiques.
    /// Podem suposar que les entrades són finites.
    ///
    /// Aquest intrínsec no té una contrapart estable.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Divisió flotant que permet optimitzacions basades en regles algebraiques.
    /// Podem suposar que les entrades són finites.
    ///
    /// Aquest intrínsec no té una contrapart estable.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Restes flotants que permeten optimitzacions basades en regles algebraiques.
    /// Podem suposar que les entrades són finites.
    ///
    /// Aquest intrínsec no té una contrapart estable.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Convertiu amb fptoui/fptosi de LLVM, que pot tornar indefinit per a valors fora de l'interval
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Estabilitzat com [`f32::to_int_unchecked`] i [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Retorna el nombre de bits establert en un tipus enter `T`
    ///
    /// Les versions estabilitzades d`aquest intrínsec estan disponibles a les primitives enteres mitjançant el mètode `count_ones`.
    /// Per exemple,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Retorna el nombre de bits inicials no definits (zeroes) en un tipus enter `T`.
    ///
    /// Les versions estabilitzades d`aquest intrínsec estan disponibles a les primitives enteres mitjançant el mètode `leading_zeros`.
    /// Per exemple,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// Un `x` amb el valor `0` retornarà l'amplada de bits de `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Igual que `ctlz`, però no és segur ja que retorna `undef` quan se li dóna un `x` amb el valor `0`.
    ///
    ///
    /// Aquest intrínsec no té una contrapart estable.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Retorna el nombre de bits no definits finals (zeroes) en un tipus enter `T`.
    ///
    /// Les versions estabilitzades d`aquest intrínsec estan disponibles a les primitives enteres mitjançant el mètode `trailing_zeros`.
    /// Per exemple,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// Un `x` amb el valor `0` retornarà l'amplada de bits de `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Igual que `cttz`, però no és segur ja que retorna `undef` quan se li dóna un `x` amb el valor `0`.
    ///
    ///
    /// Aquest intrínsec no té una contrapart estable.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Inverteix els bytes en un tipus enter `T`.
    ///
    /// Les versions estabilitzades d`aquest intrínsec estan disponibles a les primitives enteres mitjançant el mètode `swap_bytes`.
    /// Per exemple,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Inverteix els bits en un tipus enter `T`.
    ///
    /// Les versions estabilitzades d`aquest intrínsec estan disponibles a les primitives enteres mitjançant el mètode `reverse_bits`.
    /// Per exemple,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Realitza l'addició d'enters marcats.
    ///
    /// Les versions estabilitzades d`aquest intrínsec estan disponibles a les primitives enteres mitjançant el mètode `overflowing_add`.
    /// Per exemple,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Realitza la resta entera comprovada
    ///
    /// Les versions estabilitzades d`aquest intrínsec estan disponibles a les primitives enteres mitjançant el mètode `overflowing_sub`.
    /// Per exemple,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Realitza la multiplicació de nombres enters comprovats
    ///
    /// Les versions estabilitzades d`aquest intrínsec estan disponibles a les primitives enteres mitjançant el mètode `overflowing_mul`.
    /// Per exemple,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Realitza una divisió exacta, donant lloc a un comportament indefinit quan `x % y != 0` o `y == 0` o `x == T::MIN && y == -1`
    ///
    ///
    /// Aquest intrínsec no té una contrapart estable.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Realitza una divisió sense comprovar, resultant en un comportament indefinit quan `y == 0` o `x == T::MIN && y == -1`
    ///
    ///
    /// Els embolcalls segurs d`aquest intrínsec estan disponibles a les primitives enteres mitjançant el mètode `checked_div`.
    /// Per exemple,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Retorna la resta d'una divisió sense comprovar, el que resulta en un comportament indefinit quan `y == 0` o `x == T::MIN && y == -1`
    ///
    ///
    /// Els embolcalls segurs d`aquest intrínsec estan disponibles a les primitives enteres mitjançant el mètode `checked_rem`.
    /// Per exemple,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Realitza un desplaçament a l'esquerra sense marcar, resultant en un comportament indefinit quan `y < 0` o `y >= N`, on N és l'amplada de T en bits.
    ///
    ///
    /// Els embolcalls segurs d`aquest intrínsec estan disponibles a les primitives enteres mitjançant el mètode `checked_shl`.
    /// Per exemple,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Realitza un desplaçament cap a la dreta sense comprovar, resultant en un comportament indefinit quan `y < 0` o `y >= N`, on N és l`amplada de T en bits.
    ///
    ///
    /// Els embolcalls segurs d`aquest intrínsec estan disponibles a les primitives enteres mitjançant el mètode `checked_shr`.
    /// Per exemple,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Retorna el resultat d'una addició no marcada, que comporta un comportament indefinit quan `x + y > T::MAX` o `x + y < T::MIN`.
    ///
    ///
    /// Aquest intrínsec no té una contrapart estable.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Retorna el resultat d'una resta sense comprovar, resultant en un comportament indefinit quan `x - y > T::MAX` o `x - y < T::MIN`.
    ///
    ///
    /// Aquest intrínsec no té una contrapart estable.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Retorna el resultat d'una multiplicació sense comprovar, que comporta un comportament indefinit quan `x *y > T::MAX` o `x* y < T::MIN`.
    ///
    ///
    /// Aquest intrínsec no té una contrapart estable.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Realitza la rotació cap a l'esquerra.
    ///
    /// Les versions estabilitzades d`aquest intrínsec estan disponibles a les primitives enteres mitjançant el mètode `rotate_left`.
    /// Per exemple,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Realitza la rotació cap a la dreta.
    ///
    /// Les versions estabilitzades d`aquest intrínsec estan disponibles a les primitives enteres mitjançant el mètode `rotate_right`.
    /// Per exemple,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Retorna (a + b) mod 2 <sup>N</sup>, on N és l'amplada de T en bits.
    ///
    /// Les versions estabilitzades d`aquest intrínsec estan disponibles a les primitives enteres mitjançant el mètode `wrapping_add`.
    /// Per exemple,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Retorna (a, b) el mod 2 <sup>N</sup>, on N és l'amplada de T en bits.
    ///
    /// Les versions estabilitzades d`aquest intrínsec estan disponibles a les primitives enteres mitjançant el mètode `wrapping_sub`.
    /// Per exemple,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Retorna (a * b) el mod 2 <sup>N</sup>, on N és l'amplada de T en bits.
    ///
    /// Les versions estabilitzades d`aquest intrínsec estan disponibles a les primitives enteres mitjançant el mètode `wrapping_mul`.
    /// Per exemple,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Calcula `a + b`, saturant-se als límits numèrics.
    ///
    /// Les versions estabilitzades d`aquest intrínsec estan disponibles a les primitives enteres mitjançant el mètode `saturating_add`.
    /// Per exemple,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Calcula `a - b`, saturant-se als límits numèrics.
    ///
    /// Les versions estabilitzades d`aquest intrínsec estan disponibles a les primitives enteres mitjançant el mètode `saturating_sub`.
    /// Per exemple,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Retorna el valor del discriminant per a la variant a 'v';
    /// si `T` no té cap discriminant, retorna `0`.
    ///
    /// La versió estabilitzada d`aquest intrínsec és [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Retorna el nombre de variants del model `T` emès a un `usize`;
    /// si `T` no té variants, retorna `0`.Es comptaran les variants deshabitades.
    ///
    /// La versió estabilitzada d'aquest intrínsec és [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Construcció "try catch" de Rust que invoca el punter de funció `try_fn` amb el punter de dades `data`.
    ///
    /// El tercer argument és una funció anomenada si es produeix un panic.
    /// Aquesta funció porta el punter de dades i un punter a l'objecte d'excepció específic de la destinació que s'ha capturat.
    ///
    /// Per obtenir més informació, consulteu la font del compilador i la implementació de captures de std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Emet una botiga `!nontemporal` segons LLVM (consulteu els seus documents).
    /// Probablement mai es tornarà estable.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Consulteu la documentació de `<*const T>::offset_from` per obtenir més informació.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Consulteu la documentació de `<*const T>::guaranteed_eq` per obtenir més informació.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Consulteu la documentació de `<*const T>::guaranteed_ne` per obtenir més informació.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Assignar en el moment de la compilació.No s'ha de trucar en temps d'execució.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Algunes funcions es defineixen aquí perquè s`han fet disponibles per error en aquest mòdul a stable.
// Vegeu <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` també pertany a aquesta categoria, però no es pot embolicar a causa de la comprovació que `T` i `U` tenen la mateixa mida.)
//

/// Comprova si `ptr` està correctament alineat respecte a `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Copia els bytes `count *size_of::<T>()` de `src` a `dst`.* La font i la destinació no s'han de superposar.
///
/// Per a regions de memòria que es puguin superposar, utilitzeu [`copy`].
///
/// `copy_nonoverlapping` és semànticament equivalent a C's [`memcpy`], però amb l'ordre dels arguments canviat.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// El comportament no està definit si es infringeix alguna de les condicions següents:
///
/// * `src` ha de ser [valid] per a lectures de bytes `count * size_of::<T>()`.
///
/// * `dst` ha de ser [valid] per a escriptures de bytes `count * size_of::<T>()`.
///
/// * Tant `src` com `dst` han d'estar correctament alineats.
///
/// * La regió de la memòria que comença a `src` amb una mida de `count *
///   mida_de: :<T>() Els bytes *no* poden * superposar-se a la regió de memòria que comença a `dst` amb la mateixa mida.
///
/// Igual que [`read`], `copy_nonoverlapping` crea una còpia a bit de `T`, independentment de si `T` és [`Copy`].
/// Si `T` no és [`Copy`], usant *ambdós* els valors de la regió que comencen per `*src` i la regió que comença per `* dst` poden ser [violate memory safety][read-ownership].
///
///
/// Tingueu en compte que, fins i tot si la mida efectivament copiada (`count * size_of: :<T>()`) és `0`, els punteres no han de ser NULS i estan correctament alineats.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Implementeu manualment [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Moveu tots els elements de `src` a `dst`, deixant `src` buit.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Assegureu-vos que `dst` tingui la capacitat suficient per contenir tot `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // La trucada a compensar sempre és segura perquè `Vec` mai no assignarà més de `isize::MAX` bytes.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Trunqueu `src` sense deixar caure el contingut.
///         // Primer ho fem, per evitar problemes per si hi ha alguna cosa més avall de panics.
///         src.set_len(0);
///
///         // Les dues regions no es poden superposar perquè les referències mutables no són àlies i dos vectors diferents no poden posseir la mateixa memòria.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Notifiqueu a `dst` que ara conté el contingut de `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Realitzeu aquestes comprovacions només en temps d'execució
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // No entrar en pànic per reduir l'impacte del codegen.
        abort();
    }*/

    // SEGURETAT: el contracte de seguretat per a `copy_nonoverlapping` ha de ser
    // confirmat per la persona que truca.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Copia els bytes `count * size_of::<T>()` de `src` a `dst`.La font i la destinació es poden superposar.
///
/// Si la font i la destinació *mai* no es superposaran, es pot utilitzar [`copy_nonoverlapping`].
///
/// `copy` és semànticament equivalent a C's [`memmove`], però amb l'ordre dels arguments canviat.
/// La còpia es fa com si els bytes es copiessin de `src` a una matriu temporal i després es copiessin de la matriu a `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// El comportament no està definit si es infringeix alguna de les condicions següents:
///
/// * `src` ha de ser [valid] per a lectures de bytes `count * size_of::<T>()`.
///
/// * `dst` ha de ser [valid] per a escriptures de bytes `count * size_of::<T>()`.
///
/// * Tant `src` com `dst` han d'estar correctament alineats.
///
/// Igual que [`read`], `copy` crea una còpia a bit de `T`, independentment de si `T` és [`Copy`].
/// Si `T` no és [`Copy`], podeu utilitzar [violate memory safety][read-ownership] tant els valors de la regió que comencen per `*src` com la regió que comença per `* dst`.
///
///
/// Tingueu en compte que, fins i tot si la mida efectivament copiada (`count * size_of: :<T>()`) és `0`, els punteres no han de ser NULS i estan correctament alineats.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Creeu eficientment un Rust vector a partir d`un buffer no segur:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` ha d`estar alineat correctament pel seu tipus i diferent de zero.
/// /// * `ptr` ha de ser vàlid per a lectures d'elements contigus de `elts` de tipus `T`.
/// /// * Aquests elements no s'han d'utilitzar després de trucar a aquesta funció tret que sigui `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SEGURETAT: la nostra condició prèvia garanteix que la font estigui alineada i vàlida,
///     // i `Vec::with_capacity` ens assegura que tenim espai útil per escriure-les.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SEGURETAT: El vam crear amb aquesta capacitat abans,
///     // i l'anterior `copy` ha inicialitzat aquests elements.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Realitzeu aquestes comprovacions només en temps d'execució
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // No entrar en pànic per reduir l'impacte del codegen.
        abort();
    }*/

    // SEGURETAT: el contractant de seguretat per a `copy` ha de ser confirmat per la persona que truca.
    unsafe { copy(src, dst, count) }
}

/// Estableix els bytes de memòria `count * size_of::<T>()` a partir de `dst` a `val`.
///
/// `write_bytes` és similar a C's [`memset`], però estableix els bytes `count * size_of::<T>()` a `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// El comportament no està definit si es infringeix alguna de les condicions següents:
///
/// * `dst` ha de ser [valid] per a escriptures de bytes `count * size_of::<T>()`.
///
/// * `dst` han d`estar correctament alineats.
///
/// A més, la persona que truca ha de garantir que l`escriptura de bytes `count * size_of::<T>()` a la regió de memòria donada tingui com a resultat un valor vàlid de `T`.
/// L`ús d`una regió de memòria escrita com a `T` que conté un valor no vàlid de `T` és un comportament indefinit.
///
/// Tingueu en compte que, fins i tot si la mida efectivament copiada (`count * size_of: :<T>()`) és `0`, el punter no ha de ser NULL i està correctament alineat.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Creació d'un valor no vàlid:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Fugeix el valor retingut anteriorment sobreescrivint el `Box<T>` amb un punter nul.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // En aquest moment, utilitzar o deixar caure `v` provoca un comportament indefinit.
/// // drop(v); // ERROR
///
/// // Fins i tot es filtra `v` "uses" i, per tant, té un comportament indefinit.
/// // mem::forget(v); // ERROR
///
/// // De fet, `v` no és vàlid d'acord amb els invariants de disseny de tipus bàsic, de manera que *qualsevol* operació que el toqui té un comportament indefinit.
/////
/// // deixem v2 =v;//ERROR
///
/// unsafe {
///     // En canvi, posem un valor vàlid
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Ara la caixa està bé
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SEGURETAT: el contractant de seguretat per a `write_bytes` ha de ser confirmat per la persona que truca.
    unsafe { write_bytes(dst, val, count) }
}