use crate::iter::{FusedIterator, TrustedLen};

/// Crea un nou iterador que repeteix elements del tipus `A` sense fi aplicant el tancament proporcionat, el repetidor, `F: FnMut() -> A`.
///
/// La funció `repeat_with()` crida una vegada i una altra al repetidor.
///
/// Els iteradors infinits com `repeat_with()` s'utilitzen sovint amb adaptadors com [`Iterator::take()`], per tal de fer-los finits.
///
/// Si el tipus d'element de l'iterador que necessiteu implementa [`Clone`] i no està malament mantenir l'element font a la memòria, hauríeu d'utilitzar la funció [`repeat()`].
///
///
/// Un iterador produït per `repeat_with()` no és un [`DoubleEndedIterator`].
/// Si necessiteu `repeat_with()` per tornar un [`DoubleEndedIterator`], obriu un problema de GitHub explicant el vostre cas d`ús.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// use std::iter;
///
/// // suposem que tenim un valor d'un tipus que no és `Clone` o que encara no vol tenir a la memòria perquè és car:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // un valor particular per sempre:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Mitjançant mutacions i passant a finits:
///
/// ```rust
/// use std::iter;
///
/// // Del zero a la tercera potència de dos:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... i ara ja hem acabat
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Un iterador que repeteix elements del tipus `A` sense fi aplicant el tancament `F: FnMut() -> A` proporcionat.
///
///
/// Aquest `struct` està creat per la funció [`repeat_with()`].
/// Consulteu-ne la documentació per obtenir més informació.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}