use crate::iter::{FusedIterator, TrustedLen};

/// Crea un iterador que genera mandrosament un valor exactament una vegada invocant el tancament proporcionat.
///
/// Normalment s`utilitza per adaptar un generador de valor únic a un [`chain()`] d`altres tipus d`iteració.
/// Potser teniu un iterador que ho cobreix gairebé tot, però necessiteu un cas especial addicional.
/// Potser teniu una funció que funciona en iteradors, però només cal processar un valor.
///
/// A diferència de [`once()`], aquesta funció generarà mandrós el valor a petició.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// use std::iter;
///
/// // un és el nombre més solitari
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // només una, això és tot el que aconseguim
/// assert_eq!(None, one.next());
/// ```
///
/// Encadenat juntament amb un altre iterador.
/// Diguem que volem repetir cada fitxer del directori `.foo`, però també un fitxer de configuració,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // hem de convertir d'un iterador de DirEntry-s a un iterador de PathBufs, de manera que fem servir el mapa
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ara, el nostre iterador només per al nostre fitxer de configuració
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // encadenar els dos iteradors junts en un gran iterador
/// let files = dirs.chain(config);
///
/// // això ens proporcionarà tots els fitxers de .foo i .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Un iterador que produeix un únic element del tipus `A` aplicant el tancament `F: FnOnce() -> A` proporcionat.
///
///
/// Aquest `struct` està creat per la funció [`once_with()`].
/// Consulteu-ne la documentació per obtenir més informació.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}