use crate::fmt;

/// Crea un iterador nou on cada iteració crida el tancament proporcionat `F: FnMut() -> Option<T>`.
///
/// Això permet crear un iterador personalitzat amb qualsevol comportament sense utilitzar la sintaxi més detallada de crear un tipus dedicat i implementar-hi el [`Iterator`] trait.
///
/// Tingueu en compte que l'iterador `FromFn` no fa suposicions sobre el comportament del tancament i, per tant, de manera conservadora no implementa [`FusedIterator`] ni anul・la [`Iterator::size_hint()`] des del seu `(0, None)` predeterminat.
///
///
/// El tancament pot utilitzar captures i el seu entorn per fer un seguiment de l`estat a través de les iteracions.Depenent de com s'utilitzi l'iterador, és possible que calgui especificar la paraula clau [`move`] al tancament.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Tornem a implementar el contador iterador de [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Incrementeu el nostre recompte.Per això vam començar a zero.
///     count += 1;
///
///     // Comproveu si hem acabat de comptar o no.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Un iterador on cada iteració crida el tancament proporcionat `F: FnMut() -> Option<T>`.
///
/// Aquest `struct` està creat per la funció [`iter::from_fn()`].
/// Consulteu-ne la documentació per obtenir més informació.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}