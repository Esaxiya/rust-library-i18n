use crate::iter::{FusedIterator, TrustedLen};

/// Crea un iterador que produeix un element exactament una vegada.
///
/// Normalment s`utilitza per adaptar un valor únic a un [`chain()`] d`altres tipus d`iteració.
/// Potser teniu un iterador que ho cobreix gairebé tot, però necessiteu un cas especial addicional.
/// Potser teniu una funció que funciona en iteradors, però només cal processar un valor.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// use std::iter;
///
/// // un és el nombre més solitari
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // només una, això és tot el que aconseguim
/// assert_eq!(None, one.next());
/// ```
///
/// Encadenat juntament amb un altre iterador.
/// Diguem que volem repetir cada fitxer del directori `.foo`, però també un fitxer de configuració,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // hem de convertir d'un iterador de DirEntry-s a un iterador de PathBufs, de manera que fem servir el mapa
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ara, el nostre iterador només per al nostre fitxer de configuració
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // encadenar els dos iteradors junts en un gran iterador
/// let files = dirs.chain(config);
///
/// // això ens proporcionarà tots els fitxers de .foo i .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Un iterador que produeix un element exactament una vegada.
///
/// Aquest `struct` està creat per la funció [`once()`].Consulteu-ne la documentació per obtenir més informació.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}