use crate::iter::{FusedIterator, TrustedLen};

/// Crea un iterador nou que repeteix infinitament un sol element.
///
/// La funció `repeat()` repeteix un sol valor una i altra vegada.
///
/// Els iteradors infinits com `repeat()` s'utilitzen sovint amb adaptadors com [`Iterator::take()`], per tal de fer-los finits.
///
/// Si el tipus d'element de l'iterador que necessiteu no implementa `Clone` o si no voleu mantenir l'element repetit a la memòria, podeu utilitzar la funció [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// use std::iter;
///
/// // el número quatre 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // sí, encara en són quatre
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Anar finit amb [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // aquest darrer exemple va ser massa de quatre.Només en tenim quatre quatre.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... i ara ja hem acabat
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Un iterador que repeteix un element sense parar.
///
/// Aquest `struct` està creat per la funció [`repeat()`].Consulteu-ne la documentació per obtenir més informació.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}