//! Iteració externa composable.
//!
//! Si us heu trobat amb una col・lecció d'alguna mena i necessiteu fer una operació amb els elements d'aquesta col・lecció, us trobareu ràpidament amb 'iterators'.
//! Els iteradors s`utilitzen molt en el codi idiomàtic Rust, de manera que val la pena familiaritzar-se amb ells.
//!
//! Abans d`explicar-ne més, parlem de com s`estructura aquest mòdul:
//!
//! # Organization
//!
//! Aquest mòdul s`organitza en gran part per tipus:
//!
//! * [Traits] són la part central: aquests traits defineixen quin tipus d`iteradors existeixen i què podeu fer amb ells.Els mètodes d`aquests traits val la pena dedicar-hi un temps d`estudi addicional.
//! * [Functions] proporcionar algunes maneres útils de crear alguns iteradors bàsics.
//! * [Structs] sovint són els tipus de retorn dels diversos mètodes del traits d'aquest mòdul.Normalment voldreu veure el mètode que crea el `struct`, en lloc del `struct` en si.
//! Per obtenir més informació sobre per què, consulteu "[Implementing Iterator](#implementation-iterator)".
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Això és!Aprofundim en els iteradors.
//!
//! # Iterator
//!
//! El cor i l`ànima d`aquest mòdul és el [`Iterator`] trait.El nucli de [`Iterator`] té aquest aspecte:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Un iterador té un mètode, [`next`], que quan es crida, retorna una [`Opció`]`<Item>'.
//! [`next`] retornarà [`Some(Item)`] sempre que hi hagi elements i, un cop esgotats tots, retornarà `None` per indicar que la iteració ha finalitzat.
//! Els iteradors individuals poden optar per reprendre la iteració i, per tant, trucar de nou a [`next`] pot o no tornar a retornar [`Some(Item)`] en algun moment (per exemple, vegeu [`TryIter`]).
//!
//!
//! La definició completa de [`Iterator`] també inclou una sèrie d'altres mètodes, però són mètodes predeterminats, basats en [`next`], de manera que els obteniu de forma gratuïta.
//!
//! Els iteradors també es poden compondre i és freqüent encadenar-los per fer formes de processament més complexes.Consulteu la secció [Adapters](#adapters) següent per obtenir més informació.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Les tres formes d'iteració
//!
//! Hi ha tres mètodes comuns que poden crear iteradors a partir d'una col・lecció:
//!
//! * `iter()`, que itera sobre `&T`.
//! * `iter_mut()`, que itera sobre `&mut T`.
//! * `into_iter()`, que itera sobre `T`.
//!
//! Diverses coses de la biblioteca estàndard poden implementar una o més de les tres, si escau.
//!
//! # Implementació de l'iterador
//!
//! Crear un iterador propi implica dos passos: crear un `struct` per mantenir l'estat de l'iterador i implementar [`Iterator`] per a aquest `struct`.
//! És per això que hi ha tantes `struct`s en aquest mòdul: n'hi ha una per a cada iterador i adaptador d'iterador.
//!
//! Fem un iterador anomenat `Counter` que compta de `1` a `5`:
//!
//! ```
//! // En primer lloc, l`estructura:
//!
//! /// Un iterador que compta d'un a cinc
//! struct Counter {
//!     count: usize,
//! }
//!
//! // volem que el nostre recompte comenci per un, així que afegim un mètode new() per ajudar-lo.
//! // Això no és estrictament necessari, però és convenient.
//! // Tingueu en compte que iniciem `count` a zero, veurem per què a la implementació `next()`'s a continuació.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // A continuació, implementem `Iterator` per al nostre `Counter`:
//!
//! impl Iterator for Counter {
//!     // estarem comptant amb usize
//!     type Item = usize;
//!
//!     // next() és l'únic mètode necessari
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Incrementeu el nostre recompte.Per això vam començar a zero.
//!         self.count += 1;
//!
//!         // Comproveu si hem acabat de comptar o no.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // I ara ja el podem utilitzar!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Trucar al [`next`] d`aquesta manera es repeteix.Rust té una construcció que pot trucar a [`next`] al vostre iterador, fins que arriba a `None`.Repassem el següent.
//!
//! Tingueu en compte també que `Iterator` proporciona una implementació per defecte de mètodes com `nth` i `fold` que criden `next` internament.
//! Tanmateix, també és possible escriure una implementació personalitzada de mètodes com `nth` i `fold` si un iterador els pot calcular de manera més eficient sense trucar a `next`.
//!
//! # `for` bucles i `IntoIterator`
//!
//! La sintaxi del bucle `for` de Rust és en realitat sucre per als iteradors.Aquí teniu un exemple bàsic de `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! S`imprimiran els números d`un a cinc, cadascun en la seva pròpia línia.Però notareu alguna cosa aquí: mai no vam trucar a res al nostre vector per produir un iterador.Què dóna?
//!
//! Hi ha un trait a la biblioteca estàndard per convertir alguna cosa en un iterador: [`IntoIterator`].
//! Aquest trait té un mètode, [`into_iter`], que converteix la cosa que implementa [`IntoIterator`] en un iterador.
//! Vegem de nou aquest bucle `for` i en què el compilador el converteix:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust elimina aquest sucre en:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! En primer lloc, anomenem `into_iter()` al valor.A continuació, coincidim amb l'iterador que torna, trucant a [`next`] una vegada i una altra fins que veiem un `None`.
//! En aquest moment, `break` sortim del bucle i ja hem acabat la iteració.
//!
//! Aquí hi ha una mica més subtil: la biblioteca estàndard conté una interessant implementació de [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! En altres paraules, tots [`Iterator`] implementen [`IntoIterator`], només tornant ells mateixos.Això significa dues coses:
//!
//! 1. Si escriviu un [`Iterator`], el podeu utilitzar amb un bucle `for`.
//! 2. Si esteu creant una col・lecció, la implementació de [`IntoIterator`] permetrà utilitzar la vostra col・lecció amb el bucle `for`.
//!
//! # Iterant per referència
//!
//! Com que [`into_iter()`] pren `self` per valor, l'ús d'un bucle `for` per repetir una col・lecció consumeix aquesta col・lecció.Sovint, potser voldreu repetir una col・lecció sense consumir-la.
//! Moltes col・leccions ofereixen mètodes que proporcionen iteradors sobre referències, anomenades convencionalment `iter()` i `iter_mut()` respectivament:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` encara és propietat d'aquesta funció.
//! ```
//!
//! Si un tipus de col・lecció `C` proporciona `iter()`, normalment també implementa `IntoIterator` per a `&C`, amb una implementació que només crida `iter()`.
//! De la mateixa manera, una col・lecció `C` que proporciona `iter_mut()` generalment implementa `IntoIterator` per `&mut C` delegant a `iter_mut()`.Això permet una taquigrafia convenient:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // igual que `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // igual que `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Tot i que moltes col・leccions ofereixen `iter()`, no totes ofereixen `iter_mut()`.
//! Per exemple, la mutació de les claus d'un [`HashSet<T>`] o [`HashMap<K, V>`] pot posar la col・lecció en un estat inconsistent si canvia el hash de la clau, de manera que aquestes col・leccions només ofereixen `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Les funcions que prenen un [`Iterator`] i retornen un altre [`Iterator`] se solen anomenar "adaptadors iteradors", ja que són una forma de "adaptador"
//! pattern'.
//!
//! Els adaptadors iteradors habituals inclouen [`map`], [`take`] i [`filter`].
//! Per obtenir més informació, consulteu la seva documentació.
//!
//! Si hi ha un adaptador d'iterador panics, l'iterador estarà en un estat no especificat (però segur per a la memòria).
//! Tampoc no es garanteix que aquest estat es mantingui igual a les versions de Rust, de manera que heu d'evitar confiar en els valors exactes retornats per un iterador que va entrar en pànic.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Els iteradors (i l'iterador [adapters](#adapters)) són *mandrosos*). Això vol dir que només crear un iterador no suposa una gran quantitat de _do_. Realment no passa res fins que truqueu a [`next`].
//! De vegades, això és una font de confusió quan es crea un iterador únicament pels seus efectes secundaris.
//! Per exemple, el mètode [`map`] crida un tancament de cada element que repeteix:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Això no imprimirà cap valor, ja que només hem creat un iterador en lloc d`utilitzar-lo.El compilador ens avisarà sobre aquest tipus de comportament:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! La forma idiomàtica d`escriure un [`map`] per als seus efectes secundaris consisteix a fer servir un bucle `for` o trucar al mètode [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Una altra manera habitual d`avaluar un iterador és utilitzar el mètode [`collect`] per produir una nova col・lecció.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Els iteradors no han de ser finits.Com a exemple, un interval obert és un iterador infinit:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! És habitual utilitzar l'adaptador d'iterador [`take`] per convertir un iterador infinit en un finit:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Això imprimirà els números de `0` a `4`, cadascun a la seva línia.
//!
//! Tingueu en compte que els mètodes en iteradors infinits, fins i tot aquells per als quals es pot determinar matemàticament un resultat en temps finit, poden no acabar.
//! En concret, els mètodes com [`min`], que en el cas general requereixen recórrer tots els elements de l'iterador, probablement no tornaran amb èxit per a cap iterador infinit.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh no!Un bucle infinit!
//! // `ones.min()` causa un bucle infinit, de manera que no arribarem a aquest punt.
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;