/// Un iterador que en sap la longitud exacta.
///
/// Molts ["iteradors"] no saben quantes vegades repetiran, però sí.
/// Si un iterador sap quantes vegades pot iterar, pot ser útil proporcionar accés a aquesta informació.
/// Per exemple, si voleu fer una iteració cap enrere, un bon començament és saber on és el final.
///
/// En implementar un `ExactSizeIterator`, també heu d'implementar [`Iterator`].
/// En fer-ho, la implementació de [`Iterator::size_hint`]*ha de* retornar la mida exacta de l'iterador.
///
/// El mètode [`len`] té una implementació predeterminada, de manera que normalment no l`haureu d`implementar.
/// Tanmateix, és possible que pugueu proporcionar una implementació més performant que la predeterminada, de manera que anul・lar-la en aquest cas té sentit.
///
///
/// Tingueu en compte que aquest trait és un trait segur i, per tant,*no* i *no pot* garantir que la longitud retornada sigui correcta.
/// Això significa que el codi `unsafe`**no ha de** confiar en la correcció de [`Iterator::size_hint`].
/// El [`TrustedLen`](super::marker::TrustedLen) trait inestable i insegur proporciona aquesta garantia addicional.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// // un rang finit sap exactament quantes vegades iterarà
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Al [module-level docs], vam implementar un [`Iterator`], `Counter`.
/// Implantem `ExactSizeIterator` també per a això:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Podem calcular fàcilment el nombre restant d`iteracions.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // I ara ja el podem utilitzar!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Retorna la longitud exacta de l'iterador.
    ///
    /// La implementació garanteix que l'iterador retornarà exactament `len()` més vegades un valor [`Some(T)`], abans de retornar [`None`].
    ///
    /// Aquest mètode té una implementació per defecte, de manera que normalment no l`heu d`implementar directament.
    /// Tot i això, si podeu proporcionar una implementació més eficient, podeu fer-ho.
    /// Vegeu els documents [trait-level] per obtenir un exemple.
    ///
    /// Aquesta funció té les mateixes garanties de seguretat que la funció [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// // un rang finit sap exactament quantes vegades iterarà
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Aquesta afirmació és excessivament defensiva, però comprova la invariant
        // garantit per trait.
        // Si aquest trait fos rust-intern, podríem utilitzar debug_assert !;assert_eq!també comprovarà totes les implementacions de l'usuari de Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Retorna `true` si l'iterador està buit.
    ///
    /// Aquest mètode té una implementació predeterminada amb [`ExactSizeIterator::len()`], de manera que no cal que ho implementeu vosaltres mateixos.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}