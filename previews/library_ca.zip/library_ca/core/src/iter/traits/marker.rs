/// Un iterador que sempre continua produint `None` quan s`esgota.
///
/// La trucada següent a un iterador fusionat que ha retornat `None` un cop es garanteix que tornarà [`None`] de nou.
/// Aquest trait hauria de ser implementat per tots els iteradors que es comportin d`aquesta manera perquè permet optimitzar [`Iterator::fuse()`].
///
///
/// Note: En general, no heu d`utilitzar `FusedIterator` en límits genèrics si necessiteu un iterador fusionat.
/// En lloc d`això, només haureu de trucar al [`Iterator::fuse()`] a l`iterador.
/// Si l'iterador ja està fusionat, l'embolcall addicional [`Fuse`] serà un no operatiu sense cap penalització de rendiment.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Un iterador que informa d'una longitud exacta mitjançant size_hint.
///
/// L'iterador informa d'un suggeriment de mida en què és exacta (el límit inferior és igual al límit superior) o bé el límit superior és [`None`].
///
/// El límit superior només ha de ser [`None`] si la longitud real de l'iterador és superior a [`usize::MAX`].
/// En aquest cas, el límit inferior ha de ser [`usize::MAX`], donant lloc a un [`Iterator::size_hint()`] de `(usize::MAX, None)`.
///
/// L'iterador ha de produir exactament el nombre d'elements que ha informat o divergit abans d'arribar al final.
///
/// # Safety
///
/// Aquest trait només s'ha d'implementar quan es mantingui el contracte.
/// Els consumidors d`aquest trait han d`inspeccionar el límit superior [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Un iterador que en produir un article haurà pres almenys un element del seu [`SourceIter`] subjacent.
///
/// Cridar a qualsevol mètode que faci avançar l'iterador, per exemple
/// [`next()`] o [`try_fold()`], garanteix que per a cada pas s'ha mogut almenys un valor de la font subjacent de l'iterador i que es podria inserir el resultat de la cadena d'iterador al seu lloc, suposant que les restriccions estructurals de la font permetin una inserció d'aquest tipus.
///
/// En altres paraules, aquest trait indica que es pot recollir una canonada iteradora al seu lloc.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}