use crate::ops::{ControlFlow, Try};

/// Un iterador capaç de produir elements dels dos extrems.
///
/// Una cosa que implementa `DoubleEndedIterator` té una capacitat addicional sobre alguna cosa que implementa [`Iterator`]: la possibilitat de treure també `Item` de la part posterior i del frontal.
///
///
/// És important tenir en compte que tant l`anada com la tornada funcionen en el mateix rang i no es creuen: la iteració s`acaba quan es troben al mig.
///
/// De manera similar al protocol [`Iterator`], una vegada que un `DoubleEndedIterator` retorna [`None`] des d'un [`next_back()`], tornar-lo a trucar pot tornar o no tornar [`Some`].
/// [`next()`] i [`next_back()`] són intercanviables per a aquest propòsit.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Elimina i retorna un element del final de l'iterador.
    ///
    /// Retorna `None` quan ja no hi ha elements.
    ///
    /// Els documents [trait-level] contenen més detalls.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Els elements produïts pels mètodes de "DoubleEndedIterator" poden diferir dels que produeixen els mètodes de ["Iterator"]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Avança l'iterador des de la part posterior per elements `n`.
    ///
    /// `advance_back_by` és la versió inversa de [`advance_by`].Aquest mètode ometrà amb entusiasme els elements `n` començant per la part posterior, trucant a [`next_back`] fins a `n` vegades fins que es trobi amb [`None`].
    ///
    /// `advance_back_by(n)` retornarà [`Ok(())`] si l'iterador avança amb èxit mitjançant elements `n`, o [`Err(k)`] si es troba [`None`], on `k` és el nombre d'elements que avança l'iterador abans de quedar-se sense elements (és a dir,
    /// la longitud de l'iterador).
    /// Tingueu en compte que `k` sempre és inferior a `n`.
    ///
    /// La trucada a `advance_back_by(0)` no consumeix cap element i sempre torna [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // només s'ha omès `&3`
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Retorna l'element `n 'del final de l'iterador.
    ///
    /// Aquesta és essencialment la versió invertida de [`Iterator::nth()`].
    /// Tot i que com la majoria d`operacions d`indexació, el recompte comença des de zero, de manera que `nth_back(0)` retorna el primer valor del final, `nth_back(1)` el segon, etc.
    ///
    ///
    /// Tingueu en compte que es consumiran tots els elements entre el final i l`element retornat, inclòs l`element retornat.
    /// Això també significa que trucar `nth_back(0)` diverses vegades al mateix iterador retornarà elements diferents.
    ///
    /// `nth_back()` retornarà [`None`] si `n` és superior o igual a la longitud de l'iterador.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Cridar `nth_back()` diverses vegades no rebobina l'iterador:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Retornant `None` si hi ha menys d'elements `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Aquesta és la versió inversa de [`Iterator::try_fold()`]: pren elements que comencen des de la part posterior de l'iterador.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Com que es va fer un curtcircuit, els elements restants encara estan disponibles a través de l'iterador.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Un mètode iterador que redueix els elements de l`iterador a un valor final únic, començant per la part posterior.
    ///
    /// Aquesta és la versió inversa de [`Iterator::fold()`]: pren elements que comencen des de la part posterior de l'iterador.
    ///
    /// `rfold()` pren dos arguments: un valor inicial i un tancament amb dos arguments: un 'accumulator' i un element.
    /// El tancament retorna el valor que hauria de tenir l`acumulador per a la següent iteració.
    ///
    /// El valor inicial és el valor que tindrà l`acumulador en la primera trucada.
    ///
    /// Després d'aplicar aquest tancament a tots els elements de l'iterador, `rfold()` retorna l'acumulador.
    ///
    /// De vegades aquesta operació s`anomena 'reduce' o 'inject'.
    ///
    /// El plegat és útil sempre que tingueu una col・lecció d`alguna cosa i en vulgueu obtenir un valor únic.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // la suma de tots els elements d'un
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Aquest exemple construeix una cadena, començant per un valor inicial i continuant amb cada element des del darrere fins al davant:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Cerca un element d`un iterador des de la part posterior que satisfaci un predicat.
    ///
    /// `rfind()` fa un tancament que retorna `true` o `false`.
    /// Aplica aquest tancament a cada element de l'iterador, començant pel final i, si algun d'ells retorna `true`, `rfind()` retorna [`Some(element)`].
    /// Si tots retornen `false`, torna [`None`].
    ///
    /// `rfind()` està en curtcircuit;en altres paraules, deixarà de processar-se tan bon punt el tancament retorni `true`.
    ///
    /// Com que `rfind()` pren una referència i molts iteradors repeteixen les referències, això condueix a una situació possiblement confusa en què l'argument és una referència doble.
    ///
    /// Podeu veure aquest efecte als exemples següents, amb `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Aturar-se al primer `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // encara podem utilitzar `iter`, ja que hi ha més elements.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}