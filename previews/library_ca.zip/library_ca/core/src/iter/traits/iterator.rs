// ignore-tidy-filelength Aquest fitxer consisteix gairebé exclusivament en la definició de `Iterator`.
// No ho podem dividir en diversos fitxers.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Una interfície per tractar amb iteradors.
///
/// Aquest és el principal iterador trait.
/// Per obtenir més informació sobre el concepte d'iteradors en general, consulteu el [module-level documentation].
/// En particular, és possible que vulgueu saber com fer servir [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// El tipus d`elements que s`estan iterant.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Avança l'iterador i retorna el valor següent.
    ///
    /// Retorna [`None`] quan ha finalitzat la iteració.
    /// Les implementacions d'iteradors individuals poden optar per reprendre la iteració i, per tant, trucar de nou a `next()` pot acabar o no tornar a retornar [`Some(Item)`] en algun moment.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Una trucada a next() retorna el següent valor ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... i després Cap un cop acabat.
    /// assert_eq!(None, iter.next());
    ///
    /// // Més trucades poden retornar o no `None`.Aquí, sempre ho faran.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Retorna els límits de la longitud restant de l'iterador.
    ///
    /// En concret, `size_hint()` retorna una tupla on el primer element és el límit inferior i el segon element és el límit superior.
    ///
    /// La segona meitat de la tupla que es retorna és una [`Opció`]`<`[`usize`] `>>.
    /// Un [`None`] aquí significa que o bé no hi ha cap límit superior conegut, o bé el límit superior és més gran que [`usize`].
    ///
    /// # Notes d`implementació
    ///
    /// No s'aplica que una implementació d'iterador produeixi el nombre d'elements declarat.Un iterador de buggy pot produir menys que el límit inferior o més que el límit superior dels elements.
    ///
    /// `size_hint()` està pensat principalment per utilitzar-se per a optimitzacions com la reserva d`espai per als elements de l`iterador, però no s`ha de confiar en, per exemple, en ometre les comprovacions de límits en codi no segur.
    /// Una implementació incorrecta de `size_hint()` no hauria de provocar violacions de la seguretat de la memòria.
    ///
    /// Dit això, la implementació hauria de proporcionar una estimació correcta, perquè en cas contrari seria una violació del protocol trait.
    ///
    /// La implementació per defecte retorna `(0,` ['Cap`]`)` que és correcte per a qualsevol iterador.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Un exemple més complex:
    ///
    /// ```
    /// // Els nombres parells de zero a deu.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Podríem iterar de zero a deu vegades.
    /// // Saber que són cinc exactament no seria possible sense executar filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Afegim cinc números més amb chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // ara ambdós límits s`incrementen en cinc
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Tornant `None` per a un límit superior:
    ///
    /// ```
    /// // un iterador infinit no té límit superior i el límit inferior màxim possible
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Consumeix l'iterador, comptant el nombre d'iteracions i retornant-lo.
    ///
    /// Aquest mètode cridarà [`next`] repetidament fins que es trobi [`None`], retornant el nombre de vegades que ha vist [`Some`].
    /// Tingueu en compte que s'ha de trucar a [`next`] almenys una vegada, fins i tot si l'iterador no té cap element.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Comportament de desbordament
    ///
    /// El mètode no protegeix contra els desbordaments, de manera que el recompte d`elements d`un iterador amb més de [`usize::MAX`] produeix un resultat incorrecte o bé panics.
    ///
    /// Si les afirmacions de depuració estan habilitades, es garanteix un panic.
    ///
    /// # Panics
    ///
    /// Aquesta funció pot ser panic si l'iterador té més de [`usize::MAX`] elements.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Consumeix l'iterador, retornant l'últim element.
    ///
    /// Aquest mètode avaluarà l'iterador fins que retorni [`None`].
    /// Mentre ho fa, fa un seguiment de l`element actual.
    /// Després de retornar [`None`], `last()` retornarà l'últim element que va veure.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Avança els elements de l'iterador per `n`.
    ///
    /// Aquest mètode ometrà amb entusiasme els elements `n` trucant a [`next`] fins a `n` vegades fins que es trobi [`None`].
    ///
    /// `advance_by(n)` retornarà [`Ok(())`][Ok] si l'iterador avança amb èxit per elements `n`, o [`Err(k)`][Err] si es troba [`None`], on `k` és el nombre d'elements que avança l'iterador abans de quedar-se sense elements (és a dir,
    /// la longitud de l'iterador).
    /// Tingueu en compte que `k` sempre és inferior a `n`.
    ///
    /// La trucada a `advance_by(0)` no consumeix cap element i sempre torna [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // només s'ha omès `&4`
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Retorna l'element `n` de l'iterador.
    ///
    /// Com la majoria d'operacions d'indexació, el recompte comença des de zero, de manera que `nth(0)` retorna el primer valor, `nth(1)` el segon, etc.
    ///
    /// Tingueu en compte que tots els elements anteriors, així com l'element retornat, es consumiran des de l'iterador.
    /// Això vol dir que es descartaran els elements anteriors i que, si es crida `nth(0)` diverses vegades al mateix iterador, es tornaran elements diferents.
    ///
    ///
    /// `nth()` retornarà [`None`] si `n` és superior o igual a la longitud de l'iterador.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Cridar `nth()` diverses vegades no rebobina l'iterador:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Retornant `None` si hi ha menys d'elements `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Crea un iterador a partir del mateix punt, però augmentant la quantitat donada a cada iteració.
    ///
    /// Nota 1: El primer element de l'iterador sempre es retornarà, independentment del pas donat.
    ///
    /// Nota 2: El moment en què s`extreuen els elements ignorats no està fixat.
    /// `StepBy` es comporta com la seqüència `next(), nth(step-1), nth(step-1),…`, però també és lliure de comportar-se com la seqüència
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Quina manera s`utilitza pot canviar per a alguns iteradors per motius de rendiment.
    /// La segona forma avançarà l'iterador abans i pot consumir més articles.
    ///
    /// `advance_n_and_return_first` és l'equivalent a:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// El mètode serà panic si el pas donat és `0`.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Agafa dos iteradors i crea un iterador nou sobre els dos en seqüència.
    ///
    /// `chain()` retornarà un nou iterador que primer iterarà els valors del primer iterador i després els valors del segon iterador.
    ///
    /// En altres paraules, uneix dos iteradors junts, en cadena.🔗
    ///
    /// [`once`] s'utilitza habitualment per adaptar un valor únic a una cadena d'altres tipus d'iteració.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Com que l`argument de `chain()` utilitza [`IntoIterator`], podem passar qualsevol cosa que es pugui convertir en un [`Iterator`], no només en un [`Iterator`].
    /// Per exemple, les llesques (`&[T]`) implementen [`IntoIterator`] i, per tant, es poden passar directament a `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Si treballeu amb l'API Windows, és possible que vulgueu convertir [`OsStr`] a `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// "Cremallera" dos iteradors en un sol iterador de parells.
    ///
    /// `zip()` retorna un nou iterador que iterarà sobre altres dos iteradors, retornant una tupla on el primer element prové del primer iterador i el segon element prové del segon iterador.
    ///
    ///
    /// En altres paraules, divideix dos iteradors junts, en un de sol.
    ///
    /// Si qualsevol iterador retorna [`None`], [`next`] de l'iterador comprimit retornarà [`None`].
    /// Si el primer iterador retorna [`None`], `zip` farà un curtcircuit i `next` no es cridarà al segon iterador.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Com que l`argument de `zip()` utilitza [`IntoIterator`], podem passar qualsevol cosa que es pugui convertir en un [`Iterator`], no només en un [`Iterator`].
    /// Per exemple, les llesques (`&[T]`) implementen [`IntoIterator`] i, per tant, es poden passar directament a `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` s'utilitza sovint per comprimir un iterador infinit a un finit.
    /// Això funciona perquè l'iterador finit acabarà retornant [`None`], acabant la cremallera.Comprimir amb `(0..)` pot semblar molt a [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Crea un iterador nou que col・loca una còpia de `separator` entre els elements adjacents de l'iterador original.
    ///
    /// En cas que `separator` no implementi [`Clone`] o hagi de ser calculat cada vegada, utilitzeu [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // El primer element de `a`.
    /// assert_eq!(a.next(), Some(&100)); // El separador.
    /// assert_eq!(a.next(), Some(&1));   // El següent element de `a`.
    /// assert_eq!(a.next(), Some(&100)); // El separador.
    /// assert_eq!(a.next(), Some(&2));   // L'últim element de `a`.
    /// assert_eq!(a.next(), None);       // L'iterador ha finalitzat.
    /// ```
    ///
    /// `intersperse` pot ser molt útil per unir els elements d'un iterador mitjançant un element comú:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Crea un iterador nou que col・loca un element generat per `separator` entre els elements adjacents de l'iterador original.
    ///
    /// El tancament es cridarà exactament una vegada que es col・loqui un element entre dos elements adjacents de l'iterador subjacent;
    /// específicament, no es diu el tancament si l'iterador subjacent produeix menys de dos ítems i després que es produeixi l'últim ítem.
    ///
    ///
    /// Si l'element de l'iterador implementa [`Clone`], pot ser més fàcil utilitzar [`intersperse`].
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // El primer element de `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // El separador.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // El següent element de `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // El separador.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // L'últim element de `v`.
    /// assert_eq!(it.next(), None);               // L'iterador ha finalitzat.
    /// ```
    ///
    /// `intersperse_with` es pot utilitzar en situacions en què cal calcular el separador:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // El tancament manlleva mutalment el seu context per generar un element.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Pren un tancament i crea un iterador que crida aquest tancament a cada element.
    ///
    /// `map()` transforma un iterador en un altre, mitjançant el seu argument:
    /// una cosa que implementa [`FnMut`].Produeix un nou iterador que anomena aquest tancament a cada element de l'iterador original.
    ///
    /// Si sou bons pensant en tipus, podeu pensar en `map()` així:
    /// Si teniu un iterador que us proporciona elements d'algun tipus `A` i voleu un iterador d'algun altre tipus `B`, podeu utilitzar `map()`, passant un tancament que prengui un `A` i en retorni un `B`.
    ///
    ///
    /// `map()` és conceptualment similar a un bucle [`for`].Tanmateix, com que `map()` és mandrós, s`utilitza millor quan ja esteu treballant amb altres iteradors.
    /// Si feu algun tipus de bucle per obtenir un efecte secundari, es considera més idiomàtic utilitzar [`for`] que `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Si feu algun tipus d`efecte secundari, preferiu [`for`] a `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // no feu això:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // ni tan sols s`executarà, ja que és mandrós.Rust us avisarà sobre això.
    ///
    /// // En el seu lloc, utilitzeu per a:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Crida un tancament de cada element d'un iterador.
    ///
    /// Això equival a utilitzar un bucle [`for`] a l'iterador, tot i que `break` i `continue` no són possibles a partir d'un tancament.
    /// En general, és més idiomàtic utilitzar un bucle `for`, però és possible que `for_each` sigui més llegible quan es processen elements al final de cadenes d'iteradors més llargues.
    ///
    /// En alguns casos, `for_each` també pot ser més ràpid que un bucle, ja que utilitzarà la iteració interna en adaptadors com `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Per a un exemple tan petit, un bucle `for` pot ser més net, però `for_each` pot ser preferible per mantenir un estil funcional amb iteradors més llargs:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Crea un iterador que utilitza un tancament per determinar si s`ha de cedir un element.
    ///
    /// Donat un element, el tancament ha de retornar `true` o `false`.L'iterador retornat només donarà els elements per als quals el tancament es torna cert.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Com que el tancament passat a `filter()` pren una referència i molts iteradors repeteixen les referències, això condueix a una situació possiblement confusa, on el tipus de tancament és una referència doble:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // necessiteu dos * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// En general, és habitual utilitzar la desestructuració per argumentar per eliminar-ne un:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // ambdos i *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// o ambdós:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // dos &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// d`aquestes capes.
    ///
    /// Tingueu en compte que `iter.filter(f).next()` equival a `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Crea un iterador que filtra i mapa.
    ///
    /// L'iterador retornat només produeix el "valor" per al qual el tancament subministrat retorna `Some(value)`.
    ///
    /// `filter_map` es pot utilitzar per fer cadenes de [`filter`] i [`map`] més concises.
    /// L'exemple següent mostra com es pot escurçar un `map().filter().map()` a una sola trucada a `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Aquí teniu el mateix exemple, però amb [`filter`] i [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Crea un iterador que proporciona el recompte d`iteracions actuals i el valor següent.
    ///
    /// L'iterador retornat dóna parells `(i, val)`, on `i` és l'índex actual d'iteració i `val` és el valor retornat per l'iterador.
    ///
    ///
    /// `enumerate()` manté el seu recompte com a [`usize`].
    /// Si voleu comptar per un nombre enter diferent, la funció [`zip`] proporciona una funcionalitat similar.
    ///
    /// # Comportament de desbordament
    ///
    /// El mètode no protegeix els desbordaments, de manera que enumerar més d`elements [`usize::MAX`] produeix un resultat incorrecte o bé panics.
    /// Si les afirmacions de depuració estan habilitades, es garanteix un panic.
    ///
    /// # Panics
    ///
    /// L'iterador retornat pot ser panic si l'índex a retornar desbordaria un [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Crea un iterador que pot utilitzar [`peek`] per mirar el següent element de l'iterador sense consumir-lo.
    ///
    /// Afegeix un mètode [`peek`] a un iterador.Consulteu la seva documentació per obtenir més informació.
    ///
    /// Tingueu en compte que l'iterador subjacent encara està avançat quan es crida [`peek`] per primera vegada: per recuperar l'element següent, [`next`] es demana a l'iterador subjacent, per tant, es produeixen efectes secundaris (és a dir,
    ///
    /// qualsevol cosa que no sigui obtenir el següent valor) del mètode [`next`].
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ens permet veure el future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // podem peek() diverses vegades, l'iterador no avançarà
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // un cop acabat l'iterador, també ho fa peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Crea un iterador que [`skip '] s elements basats en un predicat.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` pren un tancament com a argument.Anomenarà aquest tancament a cada element de l'iterador i ignorarà els elements fins que retorni `false`.
    ///
    /// Després de retornar `false`, s'ha acabat la tasca `skip_while()`'s i es produeixen la resta d'elements.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Com que el tancament passat a `skip_while()` pren una referència i molts iteradors repeteixen les referències, això condueix a una situació possiblement confusa, on el tipus de l'argument de tancament és una referència doble:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // necessiteu dos * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Aturar-se després d'un `false` inicial:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // tot i que això hauria estat fals, ja que ja en tenim un, el skip_while() ja no s'utilitza
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Crea un iterador que genera elements basats en un predicat.
    ///
    /// `take_while()` pren un tancament com a argument.Anomenarà aquest tancament a cada element de l'iterador i produirà elements mentre retorni `true`.
    ///
    /// Després de retornar `false`, s'ha acabat la tasca `take_while()`'s i s'ignoren la resta d'elements.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Com que el tancament passat a `take_while()` pren una referència i molts iteradors repeteixen les referències, això condueix a una situació possiblement confusa, on el tipus de tancament és una referència doble:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // necessiteu dos * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Aturar-se després d'un `false` inicial:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Tenim més elements inferiors a zero, però com que ja tenim un fals, take_while() ja no s`utilitza
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Com que `take_while()` ha de mirar el valor per veure si s'ha d'incloure o no, els consumidors d'iteradors veuran que s'elimina:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// L `3` ja no hi és, ja que es va consumir per veure si la iteració s'hauria d'aturar, però no es va tornar a col・locar a l'iterador.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Crea un iterador que produeix elements basats en un predicat i mapes.
    ///
    /// `map_while()` pren un tancament com a argument.
    /// Anomenarà aquest tancament a cada element de l'iterador i produirà elements mentre retorni [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Aquí teniu el mateix exemple, però amb [`take_while`] i [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Aturar-se després d'un [`None`] inicial:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Tenim més elements que podrien cabre a u32 (4, 5), però `map_while` va retornar `None` per `-3` (ja que `predicate` va retornar `None`) i `collect` s`atura al primer `None` que es va trobar.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Com que `map_while()` ha de mirar el valor per veure si s'ha d'incloure o no, els consumidors d'iteradors veuran que s'elimina:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// L `-3` ja no hi és, ja que es va consumir per veure si la iteració s'hauria d'aturar, però no es va tornar a col・locar a l'iterador.
    ///
    /// Tingueu en compte que, a diferència de [`take_while`], aquest iterador **no** està fusionat.
    /// Tampoc no s'especifica què retorna aquest iterador després de retornar el primer [`None`].
    /// Si necessiteu un iterador fusionat, utilitzeu [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Crea un iterador que salta els primers elements `n`.
    ///
    /// Un cop consumits, es produeixen la resta d`elements.
    /// En lloc de substituir aquest mètode directament, substituïu el mètode `nth`.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Crea un iterador que produeix els seus primers elements `n`.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` s'utilitza sovint amb un iterador infinit, per fer-lo finit:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Si hi ha menys elements `n` disponibles, `take` es limitarà a la mida de l'iterador subjacent:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Un adaptador d'iterador similar al [`fold`] que manté l'estat intern i produeix un nou iterador.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` pren dos arguments: un valor inicial que sembra l'estat intern i un tancament amb dos arguments, el primer és una referència mutable a l'estat intern i el segon un element iterador.
    ///
    /// El tancament es pot assignar a l'estat intern per compartir l'estat entre iteracions.
    ///
    /// En la iteració, el tancament s'aplicarà a cada element de l'iterador i el valor de retorn del tancament, un [`Option`], el produeix l'iterador.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // cada iteració, multiplicarem l'estat per l'element
    ///     *state = *state * x;
    ///
    ///     // després, cedirem la negació de l`Estat
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Crea un iterador que funciona com un mapa, però que aplana l'estructura imbricada.
    ///
    /// L'adaptador [`map`] és molt útil, però només quan l'argument de tancament produeix valors.
    /// Si produeix un iterador, hi haurà una capa addicional d`indirecció.
    /// `flat_map()` eliminarà aquesta capa addicional per si sola.
    ///
    /// Podeu pensar en `flat_map(f)` com l'equivalent semàntic de [`map`] ping, i després [`aplanar`] com en `map(f).flatten()`.
    ///
    /// Una altra manera de pensar sobre `flat_map()`: el tancament de [`map`] retorna un element per a cada element i el tancament de `flat_map()`'s retorna un iterador per a cada element.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() retorna un iterador
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Crea un iterador que aplana l'estructura imbricada.
    ///
    /// Això és útil quan teniu un iterador d'iteradors o un iterador de coses que es poden convertir en iteradors i voleu eliminar un nivell d'indirecció.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Assignació i aplanament:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() retorna un iterador
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// També podeu reescriure això en termes de [`flat_map()`], que és preferible en aquest cas, ja que transmet la intenció més clarament:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() retorna un iterador
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// L'aplanament només elimina un nivell de nidificació a la vegada:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Aquí veiem que `flatten()` no realitza un aplanament "deep".
    /// En canvi, només s`elimina un nivell de nidificació.És a dir, si `flatten()` és una matriu tridimensional, el resultat serà bidimensional i no unidimensional.
    /// Per obtenir una estructura unidimensional, heu de tornar a `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Crea un iterador que finalitza després del primer [`None`].
    ///
    /// Després que un iterador retorni [`None`], les trucades future poden produir o no [`Some(T)`] de nou.
    /// `fuse()` adapta un iterador, assegurant-se que després de donar un [`None`], sempre retornarà [`None`] per sempre.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// // un iterador que alterna entre Alguns i Cap
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // si és parell, Some(i32), altrament Cap
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // podem veure el nostre iterador anant i venint
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // tanmateix, un cop el fusionem ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // sempre retornarà `None` després de la primera vegada.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Fa alguna cosa amb cada element d'un iterador, passant el valor.
    ///
    /// Quan utilitzeu iteradors, sovint els encadenareu diversos.
    /// Mentre esteu treballant en aquest codi, és possible que vulgueu comprovar què passa a diverses parts de la canonada.Per fer-ho, inseriu una trucada a `inspect()`.
    ///
    /// És més comú que `inspect()` s`utilitzi com a eina de depuració que no existeixi al vostre codi final, però les aplicacions poden resultar útils en determinades situacions en què cal registrar errors abans de descartar-los.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // aquesta seqüència iteradora és complexa.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // afegim algunes trucades inspect() per investigar què passa
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Això imprimirà:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Errors de registre abans de descartar-los:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Això imprimirà:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Presta un iterador en lloc de consumir-lo.
    ///
    /// Això és útil per permetre l'aplicació d'adaptadors d'iterador mentre es manté la propietat de l'iterador original.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // si intentem tornar a utilitzar-lo, no funcionarà.
    /// // La línia següent indica "error: ús del valor mogut: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // ho intentem de nou
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // en canvi, afegim un .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // ara està molt bé:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Transforma un iterador en una col・lecció.
    ///
    /// `collect()` pot prendre qualsevol cosa iterable i convertir-lo en una col・lecció rellevant.
    /// Aquest és un dels mètodes més potents de la biblioteca estàndard, que s`utilitza en diversos contextos.
    ///
    /// El patró més bàsic en què s`utilitza `collect()` és convertir una col・lecció en una altra.
    /// Agafeu una col・lecció, truqueu-hi [`iter`], feu un munt de transformacions i, després, feu `collect()`.
    ///
    /// `collect()` també pot crear instàncies de tipus que no són col・leccions típiques.
    /// Per exemple, es pot construir un [`String`] a partir de [`char`] s, i es pot recollir un iterador d'articles [`Result<T, E>`][`Result`] a `Result<Collection<T>, E>`.
    ///
    /// Vegeu els exemples següents per obtenir més informació.
    ///
    /// Com que `collect()` és tan general, pot causar problemes amb la inferència de tipus.
    /// Com a tal, `collect()` és una de les poques vegades que veureu la sintaxi afectuosament coneguda com 'turbofish': `::<>`.
    /// Això ajuda l'algorisme d'inferència a entendre específicament en quina col・lecció intenteu col・leccionar.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Tingueu en compte que necessitàvem el `: Vec<i32>` a la part esquerra.Això es deu al fet que podríem recollir, per exemple, un [`VecDeque<T>`]:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Utilitzant l 'turbofish' en lloc d'anotar `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Com que `collect()` només es preocupa per allò que recolliu, encara podeu utilitzar un suggeriment de tipus parcial, `_`, amb el peix turbo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Utilitzant `collect()` per fer un [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Si teniu una llista de [`Resultat<T, E>`][`Resultat`] s, podeu utilitzar `collect()` per veure si alguna d'elles ha fallat:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ens dóna el primer error
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ens dóna la llista de respostes
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Consumeix un iterador, creant-ne dues col・leccions.
    ///
    /// El predicat passat a `partition()` pot retornar `true` o `false`.
    /// `partition()` retorna un parell, tots els elements pels quals ha retornat `true` i tots els elements pels quals ha retornat `false`.
    ///
    ///
    /// Vegeu també [`is_partitioned()`] i [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Reordena els elements d`aquest iterador *al lloc* d`acord amb el predicat donat, de manera que tots els que retornen `true` precedeixen a tots els que retornen `false`.
    ///
    /// Retorna el nombre d'elements `true` trobats.
    ///
    /// L'ordre relatiu dels elements particionats no es manté.
    ///
    /// Vegeu també [`is_partitioned()`] i [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Partició al lloc entre parells i probabilitats
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: ens hauríem de preocupar pel desbordament del recompte?L'única manera de tenir més de
        // `usize::MAX` les referències mutables són amb ZST, que no són útils per particionar ...

        // Aquestes funcions de tancament "factory" existeixen per evitar la genericitat a `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Cerqueu repetidament el primer `false` i canvieu-lo amb el darrer `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Comprova si els elements d'aquest iterador estan particionats d'acord amb el predicat donat, de manera que tots els que retornen `true` precedeixen a tots els que retornen `false`.
    ///
    ///
    /// Vegeu també [`partition()`] i [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // O bé tots els elements proven `true`, o bé la primera clàusula s`atura a `false` i comprovem que no hi hagi més elements `true` després.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Un mètode iterador que aplica una funció sempre que torni amb èxit, produint un únic valor final.
    ///
    /// `try_fold()` pren dos arguments: un valor inicial i un tancament amb dos arguments: un 'accumulator' i un element.
    /// El tancament o bé torna amb el valor que hauria de tenir l`acumulador per a la següent iteració, o bé torna un error, amb un valor d`error que es propaga de nou a la persona que truca immediatament (short-circuiting).
    ///
    ///
    /// El valor inicial és el valor que tindrà l`acumulador en la primera trucada.Si s'aplica el tancament amb èxit contra tots els elements de l'iterador, `try_fold()` retorna l'acumulador final com a èxit.
    ///
    /// El plegat és útil sempre que tingueu una col・lecció d`alguna cosa i en vulgueu obtenir un valor únic.
    ///
    /// # Nota als implementadors
    ///
    /// Diversos dels altres mètodes (forward) tenen implementacions per defecte en termes d`aquest, així que intenteu implementar-ho explícitament si pot fer alguna cosa millor que la implementació per defecte del bucle `for`.
    ///
    /// En particular, proveu de tenir aquesta trucada `try_fold()` a les parts internes a partir de les quals es compon aquest iterador.
    /// Si es necessiten diverses trucades, l'operador `?` pot ser convenient per encadenar el valor de l'acumulador, però tingueu en compte els invariants que s'hagin de mantenir abans d'aquests retorns anticipats.
    /// Aquest és un mètode `&mut self`, de manera que cal repetir la iteració després d'haver produït un error aquí.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // la suma comprovada de tots els elements de la matriu
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Aquesta suma es desborda en afegir l'element 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Com que es va fer un curtcircuit, els elements restants encara estan disponibles a través de l'iterador.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Un mètode iterador que aplica una funció fal・lible a cada element de l'iterador, aturant-se en el primer error i retornant aquest error.
    ///
    ///
    /// Això també es pot considerar com la forma fal・lible de [`for_each()`] o com la versió sense estat de [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Es va fer un curtcircuit, de manera que la resta d`elements continuen a l`iterador:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Plega tots els elements en un acumulador aplicant una operació, retornant el resultat final.
    ///
    /// `fold()` pren dos arguments: un valor inicial i un tancament amb dos arguments: un 'accumulator' i un element.
    /// El tancament retorna el valor que hauria de tenir l`acumulador per a la següent iteració.
    ///
    /// El valor inicial és el valor que tindrà l`acumulador en la primera trucada.
    ///
    /// Després d'aplicar aquest tancament a tots els elements de l'iterador, `fold()` retorna l'acumulador.
    ///
    /// De vegades aquesta operació s`anomena 'reduce' o 'inject'.
    ///
    /// El plegat és útil sempre que tingueu una col・lecció d`alguna cosa i en vulgueu obtenir un valor únic.
    ///
    /// Note: És possible que `fold()` i mètodes similars que recorren tot l'iterador no acabin en iteradors infinits, fins i tot en traits per als quals es pot determinar un resultat en temps finit.
    ///
    /// Note: [`reduce()`] es pot utilitzar per utilitzar el primer element com a valor inicial, si el tipus d`acumulador i el tipus d`element són els mateixos.
    ///
    /// # Nota als implementadors
    ///
    /// Diversos dels altres mètodes (forward) tenen implementacions per defecte en termes d`aquest, així que intenteu implementar-ho explícitament si pot fer alguna cosa millor que la implementació per defecte del bucle `for`.
    ///
    ///
    /// En particular, proveu de tenir aquesta trucada `fold()` a les parts internes a partir de les quals es compon aquest iterador.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // la suma de tots els elements de la matriu
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Anem a través de cada pas de la iteració aquí:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// I així, el nostre resultat final, `6`.
    ///
    /// És habitual que les persones que no han utilitzat molt els iteradors utilitzen un bucle `for` amb una llista de coses per generar un resultat.Aquests es poden convertir en `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // per a bucle:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // són iguals
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Redueix els elements a un sol, aplicant repetidament una operació reductora.
    ///
    /// Si l'iterador està buit, retorna [`None`];en cas contrari, retorna el resultat de la reducció.
    ///
    /// Per als iteradors amb almenys un element, això és el mateix que [`fold()`] amb el primer element de l'iterador com a valor inicial, plegant-hi tots els elements posteriors.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Cerqueu el valor màxim:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Prova si cada element de l'iterador coincideix amb un predicat.
    ///
    /// `all()` fa un tancament que retorna `true` o `false`.Aplica aquest tancament a cada element de l'iterador i, si tots retornen `true`, també ho fa `all()`.
    /// Si algun d'ells retorna `false`, retorna `false`.
    ///
    /// `all()` està en curtcircuit;en altres paraules, deixarà de processar-se tan aviat com trobi un `false`, ja que passi el que passi més, el resultat també serà `false`.
    ///
    ///
    /// Un iterador buit retorna `true`.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Aturar-se al primer `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // encara podem utilitzar `iter`, ja que hi ha més elements.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Prova si algun element de l'iterador coincideix amb un predicat.
    ///
    /// `any()` fa un tancament que retorna `true` o `false`.Aplica aquest tancament a cada element de l'iterador i, si algun d'ells retorna `true`, també ho fa `any()`.
    /// Si tots retornen `false`, torna `false`.
    ///
    /// `any()` està en curtcircuit;en altres paraules, deixarà de processar-se tan aviat com trobi un `true`, ja que passi el que passi més, el resultat també serà `true`.
    ///
    ///
    /// Un iterador buit retorna `false`.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Aturar-se al primer `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // encara podem utilitzar `iter`, ja que hi ha més elements.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Cerca un element d`un iterador que satisfaci un predicat.
    ///
    /// `find()` fa un tancament que retorna `true` o `false`.
    /// Aplica aquest tancament a cada element de l'iterador i, si algun d'ells retorna `true`, `find()` retorna [`Some(element)`].
    /// Si tots retornen `false`, torna [`None`].
    ///
    /// `find()` està en curtcircuit;en altres paraules, deixarà de processar-se tan bon punt el tancament retorni `true`.
    ///
    /// Com que `find()` pren una referència i molts iteradors repeteixen les referències, això condueix a una situació possiblement confusa en què l'argument és una referència doble.
    ///
    /// Podeu veure aquest efecte als exemples següents, amb `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Aturar-se al primer `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // encara podem utilitzar `iter`, ja que hi ha més elements.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Tingueu en compte que `iter.find(f)` equival a `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Aplica la funció als elements de l'iterador i retorna el primer resultat que no és cap.
    ///
    ///
    /// `iter.find_map(f)` equival a `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Aplica la funció als elements de l'iterador i retorna el primer resultat vertader o el primer error.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Cerca un element en un iterador, retornant-ne l`índex.
    ///
    /// `position()` fa un tancament que retorna `true` o `false`.
    /// Aplica aquest tancament a cada element de l'iterador i, si un d'ells retorna `true`, `position()` retorna [`Some(index)`].
    /// Si tots ells retornen `false`, retorna [`None`].
    ///
    /// `position()` està en curtcircuit;en altres paraules, deixarà de processar-se tan aviat com trobi un `true`.
    ///
    /// # Comportament de desbordament
    ///
    /// El mètode no protegeix els desbordaments, de manera que si hi ha més de [`usize::MAX`] elements que no coincideixen, produeix un resultat incorrecte o bé panics.
    ///
    /// Si les afirmacions de depuració estan habilitades, es garanteix un panic.
    ///
    /// # Panics
    ///
    /// Aquesta funció pot ser panic si l'iterador té més de `usize::MAX` elements que no coincideixen.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Aturar-se al primer `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // encara podem utilitzar `iter`, ja que hi ha més elements.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // L'índex retornat depèn de l'estat de l'iterador
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Cerca un element en un iterador des de la dreta, retornant-ne l`índex.
    ///
    /// `rposition()` fa un tancament que retorna `true` o `false`.
    /// Aplica aquest tancament a cada element de l'iterador, a partir del final, i si un d'ells retorna `true`, `rposition()` retorna [`Some(index)`].
    ///
    /// Si tots ells retornen `false`, retorna [`None`].
    ///
    /// `rposition()` està en curtcircuit;en altres paraules, deixarà de processar-se tan aviat com trobi un `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Aturar-se al primer `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // encara podem utilitzar `iter`, ja que hi ha més elements.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Aquí no cal fer una comprovació de desbordament, ja que `ExactSizeIterator` implica que el nombre d`elements s`adapta a un `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Retorna l'element màxim d'un iterador.
    ///
    /// Si diversos elements són igualment màxims, es retorna l'últim element.
    /// Si l'iterador està buit, es torna [`None`].
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Retorna l'element mínim d'un iterador.
    ///
    /// Si diversos elements són igualment mínims, es torna el primer element.
    /// Si l'iterador està buit, es torna [`None`].
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Retorna l'element que dóna el valor màxim de la funció especificada.
    ///
    ///
    /// Si diversos elements són igualment màxims, es retorna l'últim element.
    /// Si l'iterador està buit, es torna [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Retorna l'element que dóna el valor màxim respecte a la funció de comparació especificada.
    ///
    ///
    /// Si diversos elements són igualment màxims, es retorna l'últim element.
    /// Si l'iterador està buit, es torna [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Retorna l'element que dóna el valor mínim de la funció especificada.
    ///
    ///
    /// Si diversos elements són igualment mínims, es torna el primer element.
    /// Si l'iterador està buit, es torna [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Retorna l'element que dóna el valor mínim respecte a la funció de comparació especificada.
    ///
    ///
    /// Si diversos elements són igualment mínims, es torna el primer element.
    /// Si l'iterador està buit, es torna [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Inverteix la direcció d'un iterador.
    ///
    /// Normalment, els iteradors s'itereixen d'esquerra a dreta.
    /// Després d'utilitzar `rev()`, un iterador iterarà de dreta a esquerra.
    ///
    /// Això només és possible si l'iterador té un final, de manera que `rev()` només funciona als [`DoubleEndedIterator '].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Converteix un iterador de parells en un parell de contenidors.
    ///
    /// `unzip()` consumeix tot un iterador de parells, produint dues col・leccions: una a partir dels elements esquerrans dels parells i una a partir dels elements adequats.
    ///
    ///
    /// Aquesta funció és, en cert sentit, l'oposada a [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Crea un iterador que copia tots els seus elements.
    ///
    /// Això és útil quan teniu un iterador superior a `&T`, però necessiteu un iterador superior a `T`.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // copiat és el mateix que .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Crea un iterador que [`clona`] s tots els seus elements.
    ///
    /// Això és útil quan teniu un iterador superior a `&T`, però necessiteu un iterador superior a `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // clonat és el mateix que .map(|&x| x), per als enters
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Repeteix un iterador sense fi.
    ///
    /// En lloc d`aturar-se a [`None`], l`iterador començarà de nou, des del principi.Després d'iterar de nou, començarà de nou al principi.I un altre cop.
    /// I un altre cop.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Suma els elements d'un iterador.
    ///
    /// Agafa cada element, els suma i torna el resultat.
    ///
    /// Un iterador buit retorna el valor zero del tipus.
    ///
    /// # Panics
    ///
    /// Quan es crida a `sum()` i es retorna un tipus enter primitiu, aquest mètode serà panic si el desbordament de càlcul i les afirmacions de depuració estan habilitades.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Repeteix tot l'iterador, multiplicant tots els elements
    ///
    /// Un iterador buit retorna l`únic valor del tipus.
    ///
    /// # Panics
    ///
    /// Quan es crida a `product()` i es torna un tipus enter primitiu, el mètode serà panic si el desbordament de càlcul i les afirmacions de depuració estan habilitades.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compara els elements d`aquest [`Iterator`] amb els d`un altre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compara els elements d`aquest [`Iterator`] amb els d`un altre respecte a la funció de comparació especificada.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compara els elements d`aquest [`Iterator`] amb els d`un altre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compara els elements d`aquest [`Iterator`] amb els d`un altre respecte a la funció de comparació especificada.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Determina si els elements d`aquest [`Iterator`] són iguals als d`un altre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Determina si els elements d`aquest [`Iterator`] són iguals als d`un altre respecte a la funció d`igualtat especificada.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Determina si els elements d`aquest [`Iterator`] són desiguals als d`un altre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Determina si els elements d`aquest [`Iterator`] són [lexicographically](Ord#lexicographical-comparison) menys que els d`un altre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Determina si els elements d`aquest [`Iterator`] són [lexicographically](Ord#lexicographical-comparison) menys o iguals als d`un altre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Determina si els elements d`aquest [`Iterator`] són [lexicographically](Ord#lexicographical-comparison) més grans que els d`un altre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Determina si els elements d`aquest [`Iterator`] són [lexicographically](Ord#lexicographical-comparison) majors o iguals als d`un altre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Comprova si s`ordenen els elements d`aquest iterador.
    ///
    /// És a dir, per a cada element `a` i el seu següent element `b`, `a <= b` ha de contenir.Si l'iterador produeix exactament zero o un element, es retorna `true`.
    ///
    /// Tingueu en compte que si `Self::Item` només és `PartialOrd`, però no `Ord`, la definició anterior implica que aquesta funció retorna `false` si dos elements consecutius no són comparables.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Comprova si els elements d`aquest iterador s`ordenen mitjançant la funció de comparador donada.
    ///
    /// En lloc d'utilitzar `PartialOrd::partial_cmp`, aquesta funció utilitza la funció `compare` donada per determinar l'ordenació de dos elements.
    /// A part d'això, equival a [`is_sorted`];consulteu la seva documentació per obtenir més informació.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Comprova si els elements d`aquest iterador s`ordenen mitjançant la funció d`extracció de claus donada.
    ///
    /// En lloc de comparar directament els elements de l'iterador, aquesta funció compara les claus dels elements, tal com determina `f`.
    /// A part d'això, equival a [`is_sorted`];consulteu la seva documentació per obtenir més informació.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Vegeu [TrustedRandomAccess]
    // El nom inusual és evitar col・lisions de noms en la resolució del mètode. Vegeu #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}