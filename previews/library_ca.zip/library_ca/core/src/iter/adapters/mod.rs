use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Aquest trait proporciona accés transitiu a l'escenari font en una canonada d'adaptador-interador en les condicions que
/// * el mateix iterador font `S` implementa `SourceIter<Source = S>`
/// * hi ha una implementació de delegació d'aquest trait per a cada adaptador a la canonada entre l'origen i el consumidor de canalització.
///
/// Quan la font és una estructura iteradora propietària (comunament anomenada `IntoIter`), això pot ser útil per especialitzar implementacions [`FromIterator`] o recuperar els elements restants després que s'hagi esgotat parcialment un iterador.
///
///
/// Tingueu en compte que les implementacions no necessàriament han de proporcionar accés a la font més interna d`un canalització.Un adaptador intermedi amb estat pot avaluar amb ànsia una part de la canonada i exposar el seu emmagatzematge intern com a font.
///
/// El trait no és segur perquè els implementadors han de mantenir propietats de seguretat addicionals.
/// Vegeu [`as_inner`] per obtenir més informació.
///
/// # Examples
///
/// Recuperació d'una font parcialment consumida:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Una etapa d'origen en una canonada d'iterador.
    type Source: Iterator;

    /// Recupereu l'origen d'una canonada d'iterador.
    ///
    /// # Safety
    ///
    /// Les implementacions de han de retornar la mateixa referència mutable durant la seva vida útil, tret que la substitueixi una persona que truca.
    /// Les persones que truquen només poden substituir la referència quan aturen la iteració i deixen caure la canonada de l'iterador després d'extreure la font.
    ///
    /// Això significa que els adaptadors iteradors poden confiar en que la font no canvia durant la iteració, però no poden confiar-hi en les seves implementacions Drop.
    ///
    /// La implementació d`aquest mètode significa que els adaptadors renuncien a l`accés exclusivament privat a la seva font i només poden confiar en les garanties basades en els tipus de receptors de mètodes.
    /// La manca d'accés restringit també requereix que els adaptadors hagin de mantenir l'API pública de la font, fins i tot quan tinguin accés a les seves funcions internes.
    ///
    /// Al seu torn, les persones que truquen han d`esperar que la font es trobi en qualsevol estat que sigui compatible amb la seva API pública, ja que els adaptadors situats entre ella i la font tenen el mateix accés.
    /// En particular, un adaptador pot haver consumit més elements dels estrictament necessaris.
    ///
    /// L`objectiu general d`aquests requisits és deixar que el consumidor utilitzi una canonada
    /// * tot el que queda a la font després que la iteració s'hagi aturat
    /// * la memòria que ha quedat inutilitzada en avançar un iterador consumidor
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Un adaptador d'iterador que produeix una sortida sempre que l'iterador subjacent produeixi valors `Result::Ok`.
///
///
/// Si es produeix un error, l'iterador s'atura i l'error s'emmagatzema.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Processar l'iterador donat com si obtingués un `T` en lloc d'un `Result<T, _>`.
/// Qualsevol error aturarà l`iterador intern i el resultat global serà un error.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}