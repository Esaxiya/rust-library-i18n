use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Un tipus d'embolcall per construir instàncies no inicialitzades de `T`.
///
/// # Invariant d'inicialització
///
/// El compilador, en general, assumeix que una variable s`inicialitza correctament segons els requisits del tipus de variable.Per exemple, una variable de tipus de referència ha d`estar alineada i no és NULL.
/// Es tracta d`un invariant que s`ha de confirmar *sempre*, fins i tot amb un codi no segur.
/// Com a conseqüència, la inicialització zero d'una variable de tipus de referència provoca [undefined behavior][ub] instantani, independentment de si aquesta referència s'utilitza per accedir a la memòria:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // comportament indefinit⚠️
/// // El codi equivalent amb `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // comportament indefinit⚠️
/// ```
///
/// El compilador explota això per obtenir diverses optimitzacions, com ara evitar verificacions en temps d'execució i optimitzar el disseny `enum`.
///
/// De la mateixa manera, la memòria totalment no inicialitzada pot tenir qualsevol contingut, mentre que un `bool` sempre ha de ser `true` o `false`.Per tant, crear un `bool` no inicialitzat és un comportament indefinit:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // comportament indefinit⚠️
/// // El codi equivalent amb `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // comportament indefinit⚠️
/// ```
///
/// A més, la memòria no inicialitzada és especial perquè no té un valor fix ("fixed" que significa "it won't change without being written to").Llegir el mateix byte no inicialitzat diverses vegades pot donar resultats diferents.
/// Això fa que el comportament no definit sigui tenir dades no inicialitzades en una variable, fins i tot si aquesta variable té un tipus enter, que d'una altra manera pot contenir qualsevol patró de bits *fix*:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // comportament indefinit⚠️
/// // El codi equivalent amb `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // comportament indefinit⚠️
/// ```
/// (Tingueu en compte que les regles entorn dels nombres enters no inicialitzats encara no s`han finalitzat, però fins que s`aconsegueixin, és aconsellable evitar-les.)
///
/// A més, recordeu que la majoria dels tipus tenen invariants addicionals més enllà de ser considerats inicialitzats a nivell de tipus.
/// Per exemple, un [`Vec<T>`] inicialitzat amb "1" es considera inicialitzat (segons la implementació actual; això no constitueix una garantia estable) perquè l'únic requisit que el compilador coneix al respecte és que el punter de dades no sigui nul.
/// La creació d`aquest `Vec<T>` no provoca un comportament indefinit *immediat*, sinó que provoca un comportament indefinit amb les operacions més segures (inclosa la caiguda).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` serveix per habilitar un codi no segur per tractar dades no inicialitzades.
/// És un senyal al compilador que indica que les dades aquí *no* podrien ser inicialitzades:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Creeu una referència explícitament no inicialitzada.
/// // El compilador sap que les dades dins d'un `MaybeUninit<T>` poden no ser vàlides i, per tant, no són UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Establiu-lo a un valor vàlid.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Extraieu les dades inicialitzades: això només es permet *després de* inicialitzar correctament `x`.
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Aleshores, el compilador sap no fer cap suposició o optimització incorrecta sobre aquest codi.
///
/// Podeu pensar que `MaybeUninit<T>` és una mica semblant a `Option<T>`, però sense cap seguiment en temps d'execució i sense cap de les verificacions de seguretat.
///
/// ## out-pointers
///
/// Podeu utilitzar `MaybeUninit<T>` per implementar "out-pointers": en lloc de retornar dades d'una funció, passeu-hi un punter a una memòria (uninitialized) per posar el resultat.
/// Això pot ser útil quan és important per a la persona que truca controlar com s'assigna la memòria emmagatzemada del resultat i voleu evitar moviments innecessaris.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` no deixa caure el contingut antic, cosa important.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Ara sabem que `v` està inicialitzat.Això també assegura que el vector caigui correctament.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Inicialització d`una matriu element per element
///
/// `MaybeUninit<T>` es pot utilitzar per inicialitzar una matriu gran element per element:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Creeu una matriu no inicialitzada de `MaybeUninit`.
///     // El `assume_init` és segur perquè el tipus que pretenem haver inicialitzat aquí és un munt de "MaybeUninit", que no requereixen inicialització.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Deixar caure un `MaybeUninit` no fa res.
///     // Per tant, l`ús de l`assignació de punter en brut en lloc de `ptr::write` no provoca la caiguda de l`antic valor no inicialitzat.
/////
///     // A més, si hi ha un panic durant aquest bucle, tenim una fuita de memòria, però no hi ha cap problema de seguretat de memòria.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Tot està inicialitzat.
///     // Transmet la matriu al tipus inicialitzat.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// També podeu treballar amb matrius parcialment inicialitzats, que es poden trobar en estructures de dades de baix nivell.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Creeu una matriu no inicialitzada de `MaybeUninit`.
/// // El `assume_init` és segur perquè el tipus que pretenem haver inicialitzat aquí és un munt de "MaybeUninit", que no requereixen inicialització.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Compteu el nombre d'elements que hem assignat.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Per a cada element de la matriu, deixeu anar si l'hem assignat.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Inicialització d`una estructura camp per camp
///
/// Podeu utilitzar `MaybeUninit<T>` i la macro [`std::ptr::addr_of_mut`] per inicialitzar les estructures camp per camp:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Inicialització del camp `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Inicialització del camp `list` Si hi ha un panic aquí, el `String` del camp `name` es perd.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Tots els camps estan inicialitzats, de manera que trucem a `assume_init` per obtenir un Foo inicialitzat.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` es garanteix que tindrà la mateixa mida, alineació i ABI que `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Tanmateix, recordeu que un tipus *que conté* un `MaybeUninit<T>` no és necessàriament el mateix disseny;Rust no garanteix en general que els camps d'un `Foo<T>` tinguin el mateix ordre que un `Foo<U>`, fins i tot si `T` i `U` tenen la mateixa mida i alineació.
///
/// A més, perquè qualsevol valor de bit és vàlid per a un `MaybeUninit<T>`, el compilador no pot aplicar optimitzacions non-zero/niche-filling, cosa que pot resultar en una mida més gran:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Si `T` és segur per a FFI, també ho serà `MaybeUninit<T>`.
///
/// Tot i que `MaybeUninit` és `#[repr(transparent)]` (el que indica que garanteix la mateixa mida, alineació i ABI que `T`), això *no* modifica cap de les advertències anteriors.
/// `Option<T>` i `Option<MaybeUninit<T>>` poden tenir mides diferents i els tipus que continguin un camp del tipus `T` es poden distribuir (i dimensionar) de manera diferent que si aquest camp fos `MaybeUninit<T>`.
/// `MaybeUninit` és un tipus d'unió i `#[repr(transparent)]` en unions és inestable (vegeu [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Amb el pas del temps, les garanties exactes de `#[repr(transparent)]` en unions poden evolucionar i `MaybeUninit` pot quedar-se o no `#[repr(transparent)]`.
/// Dit això, `MaybeUninit<T>`*sempre* garantirà que té la mateixa mida, alineació i ABI que `T`;és que la manera com implementa `MaybeUninit` aquesta garantia pot evolucionar.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Element de Lang perquè puguem embolicar-ne altres tipus.Això és útil per als generadors.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // En no trucar al `T::clone()`, no podem saber si estem prou inicialitzats per a això.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Crea un nou `MaybeUninit<T>` inicialitzat amb el valor indicat.
    /// És segur trucar al [`assume_init`] pel valor retornat d`aquesta funció.
    ///
    /// Tingueu en compte que deixar caure un `MaybeUninit<T>` mai no cridarà el codi de caiguda de "T"
    /// És responsabilitat vostra assegurar-vos que `T` es deixa caure si es va inicialitzar.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Crea un nou `MaybeUninit<T>` en un estat no inicialitzat.
    ///
    /// Tingueu en compte que deixar caure un `MaybeUninit<T>` mai no cridarà el codi de caiguda de "T"
    /// És responsabilitat vostra assegurar-vos que `T` es deixa caure si es va inicialitzar.
    ///
    /// Vegeu el [type-level documentation][MaybeUninit] per obtenir alguns exemples.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Creeu una nova matriu d`elements `MaybeUninit<T>`, en un estat no inicialitzat.
    ///
    /// Note: en una versió future Rust, aquest mètode pot ser innecessari quan la sintaxi literal de la matriu permet [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// A continuació, l'exemple següent pot utilitzar `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Retorna una part (possiblement més petita) de dades que realment s'ha llegit
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SEGURETAT: un `[MaybeUninit<_>; LEN]` no inicialitzat és vàlid.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Crea un nou `MaybeUninit<T>` en un estat no inicialitzat, amb la memòria omplerta de bytes `0`.Depèn de `T` si això ja permet una inicialització adequada.
    ///
    /// Per exemple, `MaybeUninit<usize>::zeroed()` s'inicialitza, però `MaybeUninit<&'static i32>::zeroed()` no ho és perquè les referències no han de ser nul・les.
    ///
    /// Tingueu en compte que deixar caure un `MaybeUninit<T>` mai no cridarà el codi de caiguda de "T"
    /// És responsabilitat vostra assegurar-vos que `T` es deixa caure si es va inicialitzar.
    ///
    /// # Example
    ///
    /// Ús correcte d'aquesta funció: inicialitzar una estructura amb zero, on tots els camps de l'estructura poden contenir el patró de bits 0 com a valor vàlid.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// Ús *incorrecte* d'aquesta funció: trucar a `x.zeroed().assume_init()` quan `0` no és un patró de bits vàlid per al tipus:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Dins d`un parell, creem un `NotZero` que no té un discriminant vàlid.
    /// // Es tracta d`un comportament indefinit.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SEGURETAT: `u.as_mut_ptr()` apunta a la memòria assignada.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Estableix el valor del `MaybeUninit<T>`.
    /// Això sobreescriu qualsevol valor anterior sense deixar-lo caure, així que tingueu cura de no utilitzar-lo dues vegades tret que vulgueu ometre l'execució del destructor.
    ///
    /// Per a la vostra comoditat, això també retorna una referència mutable als continguts (ara inicialitzats amb seguretat) de `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SEGURETAT: Acabem d'inicialitzar aquest valor.
        unsafe { self.assume_init_mut() }
    }

    /// Obté un punter al valor contingut.
    /// Llegir des d`aquest punter o convertir-lo en una referència és un comportament indefinit tret que s`inicialitzi l `MaybeUninit<T>`.
    /// L`escriptura a la memòria a què apunta aquest punter (non-transitively) té un comportament indefinit (excepte dins d`un `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Ús correcte d'aquest mètode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Creeu una referència al `MaybeUninit<T>`.Està bé perquè el vam inicialitzar.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// Ús *incorrecte* d'aquest mètode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Hem creat una referència a un vector no inicialitzat.Es tracta d`un comportament indefinit.⚠️
    /// ```
    ///
    /// (Tingueu en compte que les regles sobre les referències a dades no inicialitzades encara no s`han finalitzat, però fins que ho siguin, és recomanable evitar-les.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` i `ManuallyDrop` són `repr(transparent)`, de manera que podem llançar el punter.
        self as *const _ as *const T
    }

    /// Obté un punter mutable al valor contingut.
    /// Llegir des d`aquest punter o convertir-lo en una referència és un comportament indefinit tret que s`inicialitzi l `MaybeUninit<T>`.
    ///
    /// # Examples
    ///
    /// Ús correcte d'aquest mètode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Creeu una referència al `MaybeUninit<Vec<u32>>`.
    /// // Està bé perquè el vam inicialitzar.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// Ús *incorrecte* d'aquest mètode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Hem creat una referència a un vector no inicialitzat.Es tracta d`un comportament indefinit.⚠️
    /// ```
    ///
    /// (Tingueu en compte que les regles sobre les referències a dades no inicialitzades encara no s`han finalitzat, però fins que ho siguin, és recomanable evitar-les.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` i `ManuallyDrop` són `repr(transparent)`, de manera que podem llançar el punter.
        self as *mut _ as *mut T
    }

    /// Extreu el valor del contenidor `MaybeUninit<T>`.Aquesta és una bona manera d`assegurar-se que les dades s`anul・laran, ja que l `T` resultant està sotmès al tractament habitual de la caiguda.
    ///
    /// # Safety
    ///
    /// Correspon a la persona que truca garantir que el `MaybeUninit<T>` realment es troba en un estat inicialitzat.Cridar-ho quan el contingut encara no està inicialitzat completament provoca un comportament immediat i indefinit.
    /// El [type-level documentation][inv] conté més informació sobre aquesta invariant d'inicialització.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// A més, recordeu que la majoria dels tipus tenen invariants addicionals més enllà de ser considerats inicialitzats a nivell de tipus.
    /// Per exemple, un [`Vec<T>`] inicialitzat amb "1" es considera inicialitzat (segons la implementació actual; això no constitueix una garantia estable) perquè l'únic requisit que el compilador coneix al respecte és que el punter de dades no sigui nul.
    ///
    /// La creació d`aquest `Vec<T>` no provoca un comportament indefinit *immediat*, sinó que provoca un comportament indefinit amb les operacions més segures (inclosa la caiguda).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Ús correcte d'aquest mètode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// Ús *incorrecte* d'aquest mètode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` encara no s'havia inicialitzat, de manera que aquesta última línia va provocar un comportament indefinit.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SEGURETAT: la persona que truca ha de garantir que s`inicialitza `self`.
        // Això també significa que `self` ha de ser una variant `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Llegeix el valor del contenidor `MaybeUninit<T>`.L `T` resultant està subjecte al tractament habitual de caigudes.
    ///
    /// Sempre que sigui possible, és preferible utilitzar [`assume_init`], cosa que impedeix duplicar el contingut de l `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Correspon a la persona que truca garantir que el `MaybeUninit<T>` realment es troba en un estat inicialitzat.Cridar-ho quan el contingut encara no està inicialitzat completament provoca un comportament indefinit.
    /// El [type-level documentation][inv] conté més informació sobre aquesta invariant d'inicialització.
    ///
    /// A més, això deixa una còpia de les mateixes dades al `MaybeUninit<T>`.
    /// Quan utilitzeu diverses còpies de les dades (trucant a `assume_init_read` diverses vegades, o primer trucant a `assume_init_read` i després a [`assume_init`]), és la vostra responsabilitat assegurar-vos que aquestes dades es puguin duplicar.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Ús correcte d'aquest mètode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` és `Copy`, de manera que podem llegir diverses vegades.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Duplicar un valor `None` està bé, de manera que és possible que llegim diverses vegades.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// Ús *incorrecte* d'aquest mètode:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Ara hem creat dues còpies del mateix vector, donant lloc a un free️ de doble lliure quan tots dos es deixen caure.
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SEGURETAT: la persona que truca ha de garantir que s`inicialitza `self`.
        // La lectura des de `self.as_ptr()` és segura, ja que s`hauria d`inicialitzar `self`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Elimina el valor contingut al seu lloc.
    ///
    /// Si teniu la propietat de l `MaybeUninit`, podeu utilitzar [`assume_init`].
    ///
    /// # Safety
    ///
    /// Correspon a la persona que truca garantir que el `MaybeUninit<T>` realment es troba en un estat inicialitzat.Cridar-ho quan el contingut encara no està inicialitzat completament provoca un comportament indefinit.
    ///
    /// A més, cal satisfer tots els invariants addicionals del tipus `T`, ja que la implementació `Drop` de `T` (o els seus membres) pot confiar-hi.
    /// Per exemple, un [`Vec<T>`] inicialitzat amb "1" es considera inicialitzat (segons la implementació actual; això no constitueix una garantia estable) perquè l'únic requisit que el compilador coneix al respecte és que el punter de dades no sigui nul.
    ///
    /// Deixar de banda aquest `Vec<T>` provocarà un comportament indefinit.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SEGURETAT: la persona que truca ha de garantir que s'inicialitza `self` i
        // satisfà tots els invariants de `T`.
        // Deixar el valor al seu lloc és segur si és així.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Obté una referència compartida al valor contingut.
    ///
    /// Això pot ser útil quan volem accedir a un `MaybeUninit` que s'hagi inicialitzat però que no tingui la propietat del `MaybeUninit` (impedint l'ús de `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Cridar-ho quan el contingut encara no s`ha inicialitzat completament provoca un comportament indefinit: correspon a la persona que truca garantir que l `MaybeUninit<T>` realment es troba en un estat inicialitzat.
    ///
    ///
    /// # Examples
    ///
    /// ### Ús correcte d'aquest mètode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Inicialitzar `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Ara que se sap que el nostre `MaybeUninit<_>` està inicialitzat, està bé crear-ne una referència compartida:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SEGURETAT: s'ha inicialitzat `x`.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### Usos *incorrectes* d'aquest mètode:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Hem creat una referència a un vector no inicialitzat.Es tracta d`un comportament indefinit.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Inicialitzeu el `MaybeUninit` amb `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Referència a un `Cell<bool>` no inicialitzat: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SEGURETAT: la persona que truca ha de garantir que s`inicialitza `self`.
        // Això també significa que `self` ha de ser una variant `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Obté una referència (unique) mutable al valor contingut.
    ///
    /// Això pot ser útil quan volem accedir a un `MaybeUninit` que s'hagi inicialitzat però que no tingui la propietat del `MaybeUninit` (impedint l'ús de `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Cridar-ho quan el contingut encara no s`ha inicialitzat completament provoca un comportament indefinit: correspon a la persona que truca garantir que l `MaybeUninit<T>` realment es troba en un estat inicialitzat.
    /// Per exemple, `.assume_init_mut()` no es pot utilitzar per inicialitzar un `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Ús correcte d'aquest mètode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Inicialitza *tots* els bytes del buffer d'entrada.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Inicialitzar `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Ara sabem que s'ha inicialitzat `buf`, de manera que podríem `.assume_init()`.
    /// // Tanmateix, utilitzar `.assume_init()` pot provocar un `memcpy` dels 2048 bytes.
    /// // Per afirmar que el nostre buffer s'ha inicialitzat sense copiar-lo, actualitzem el `&mut MaybeUninit<[u8; 2048]>` a un `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // SEGURETAT: s'ha inicialitzat `buf`.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Ara podem utilitzar `buf` com a segment normal:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### Usos *incorrectes* d'aquest mètode:
    ///
    /// No podeu utilitzar `.assume_init_mut()` per inicialitzar un valor:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Hem creat una referència (mutable) a un `bool` no inicialitzat.
    ///     // Es tracta d`un comportament indefinit.⚠️
    /// }
    /// ```
    ///
    /// Per exemple, no podeu [`Read`] en una memòria intermèdia no inicialitzada:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) referència a la memòria no inicialitzada!
    ///                             // Es tracta d`un comportament indefinit.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Tampoc no podeu utilitzar l'accés directe al camp per fer la inicialització gradual camp per camp:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referència a la memòria no inicialitzada!
    ///                  // Es tracta d`un comportament indefinit.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referència a la memòria no inicialitzada!
    ///                  // Es tracta d`un comportament indefinit.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Actualment confiem en que l'anterior és incorrecte, és a dir, tenim referències a dades no inicialitzades (per exemple, a `libcore/fmt/float.rs`).
    // Hauríem de prendre una decisió final sobre les normes abans de l'estabilització.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SEGURETAT: la persona que truca ha de garantir que s`inicialitza `self`.
        // Això també significa que `self` ha de ser una variant `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Extreu els valors d'una matriu de contenidors `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Correspon a la persona que truca garantir que tots els elements de la matriu es troben en un estat inicialitzat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SEGURETAT: Ara és segur ja que inicialitzem tots els elements
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * La persona que truca garanteix que tots els elements de la matriu s`inicialitzen
        // * `MaybeUninit<T>` i T es garanteix que tenen el mateix disseny
        // * Potser Unint no cau, de manera que no hi ha cap doble lliure i, per tant, la conversió és segura
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Suposant que tots els elements estan inicialitzats, obtingueu-ne una porció.
    ///
    /// # Safety
    ///
    /// Correspon a la persona que truca garantir que els elements `MaybeUninit<T>` realment es troben en un estat inicialitzat.
    ///
    /// Cridar-ho quan el contingut encara no està inicialitzat completament provoca un comportament indefinit.
    ///
    /// Consulteu [`assume_init_ref`] per obtenir més detalls i exemples.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SEGURETAT: emetre un segment a un `*const [T]` és segur, ja que la persona que truca ho garanteix
        // `slice` s'inicialitza i es garanteix que "MayBayUninit" tindrà el mateix disseny que `T`.
        // El punter obtingut és vàlid ja que fa referència a la memòria propietat de `slice` que és una referència i, per tant, es garanteix que serà vàlida per a les lectures.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Suposant que tots els elements estiguin inicialitzats, obteniu-los un segment modificable.
    ///
    /// # Safety
    ///
    /// Correspon a la persona que truca garantir que els elements `MaybeUninit<T>` realment es troben en un estat inicialitzat.
    ///
    /// Cridar-ho quan el contingut encara no està inicialitzat completament provoca un comportament indefinit.
    ///
    /// Consulteu [`assume_init_mut`] per obtenir més detalls i exemples.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SEGURETAT: similar a les notes de seguretat per a `slice_get_ref`, però tenim un
        // referència mutable que també es garanteix que és vàlida per a escriptures.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Obté un punter al primer element de la matriu.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Obté un punter mutable al primer element de la matriu.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Copia els elements de `src` a `this`, retornant una referència mutable als continguts ara initalitzats de `this`.
    ///
    /// Si `T` no implementa `Copy`, utilitzeu [`write_slice_cloned`]
    ///
    /// Això és similar al [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Aquesta funció serà panic si les dues llesques tenen longituds diferents.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SEGURETAT: acabem de copiar tots els elements de len a la capacitat de recanvi
    /// // els primers elements src.len() del vec són vàlids ara.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SEGURETAT: &[T] i&[MaybeUninit<T>] tenen el mateix disseny
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SEGURETAT: Els elements vàlids s`acaben de copiar a `this`, de manera que s`inicialitzen
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Clona els elements de `src` a `this`, retornant una referència mutable als continguts ja initalitzats de `this`.
    /// No es deixarà caure cap element ja initalitzat.
    ///
    /// Si `T` implementa `Copy`, utilitzeu [`write_slice`]
    ///
    /// Això és similar al [`slice::clone_from_slice`], però no deixa caure els elements existents.
    ///
    /// # Panics
    ///
    /// Aquesta funció serà panic si les dues llesques tenen longituds diferents, o si la implementació de `Clone` panics.
    ///
    /// Si hi ha un panic, s'eliminaran els elements ja clonats.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SEGURETAT: acabem de clonar tots els elements de len a la capacitat de recanvi
    /// // els primers elements src.len() del vec són vàlids ara.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // a diferència de copy_from_slice, això no crida clone_from_slice a la llesca, això es deu al fet que `MaybeUninit<T: Clone>` no implementa Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SEGURETAT: aquesta part crua només contindrà objectes inicialitzats
                // per això, es permet deixar-lo caure.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Els hem de tallar explícitament a la mateixa longitud
        // perquè s`eliminin els controls de límits i l`optimitzador generarà memcpy per a casos senzills (per exemple, T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // cal protecció b/c panic pot passar durant un clon
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SEGURETAT: Els elements vàlids s`acaben d`escriure a `this`, de manera que s`inicialitzen
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}