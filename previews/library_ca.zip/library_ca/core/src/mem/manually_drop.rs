use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Un embolcall per impedir que el compilador cridi automàticament al destructor de `T`.
/// Aquest embolcall té un cost 0.
///
/// `ManuallyDrop<T>` està subjecte a les mateixes optimitzacions de disseny que `T`.
/// Com a conseqüència, no té cap efecte en les suposicions que el compilador fa sobre el seu contingut.
/// Per exemple, inicialitzar un `ManuallyDrop<&mut T>` amb [`mem::zeroed`] és un comportament indefinit.
/// Si heu de gestionar dades no inicialitzades, utilitzeu [`MaybeUninit<T>`].
///
/// Tingueu en compte que l'accés al valor dins d'un `ManuallyDrop<T>` és segur.
/// Això significa que un `ManuallyDrop<T>` el contingut del qual s'ha retirat no s'ha d'exposar a través d'una API de seguretat pública.
/// En conseqüència, `ManuallyDrop::drop` no és segur.
///
/// # `ManuallyDrop` i deixar anar la comanda.
///
/// Rust té un valor [drop order] ben definit.
/// Per assegurar-vos que els camps o els locals es deixin caure en un ordre específic, torneu a ordenar les declaracions de manera que l'ordre de descàrrega implícita sigui el correcte.
///
/// És possible utilitzar `ManuallyDrop` per controlar l'ordre de baixada, però requereix un codi poc segur i és difícil de fer correctament en presència de desenrotllament.
///
///
/// Per exemple, si voleu assegurar-vos que es deixi caure un camp específic després dels altres, converteix-lo en l'últim camp d'una estructura:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` es retirarà després de `children`.
///     // Rust garanteix que els camps es deixin caure en l'ordre de declaració.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Ajusteu un valor que es deixarà caure manualment.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Encara podeu utilitzar el valor de manera segura
    /// assert_eq!(*x, "Hello");
    /// // Però `Drop` no s`executarà aquí
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Extreu el valor del contenidor `ManuallyDrop`.
    ///
    /// Això permet que el valor es tiri de nou.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Això fa caure el `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Trau el valor del contenidor `ManuallyDrop<T>`.
    ///
    /// Aquest mètode està destinat principalment a moure els valors en caiguda.
    /// En lloc d'utilitzar [`ManuallyDrop::drop`] per deixar caure el valor manualment, podeu utilitzar aquest mètode per agafar el valor i utilitzar-lo com vulgueu.
    ///
    /// Sempre que sigui possible, és preferible utilitzar [`into_inner`][`ManuallyDrop::into_inner`], cosa que impedeix duplicar el contingut de l `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Aquesta funció mou semànticament el valor contingut sense impedir un ús addicional, deixant sense canvis l'estat d'aquest contenidor.
    /// És responsabilitat vostra assegurar-vos que aquest `ManuallyDrop` no es torni a utilitzar.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SEGURETAT: estem llegint des d'una referència, que està garantida
        // per ser vàlid per a lectures.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Elimina manualment el valor contingut.Això és exactament equivalent a trucar a [`ptr::drop_in_place`] amb un punter al valor contingut.
    /// Com a tal, tret que el valor contingut sigui una estructura empaquetada, el destructor es cridarà al lloc sense moure el valor i, per tant, es pot utilitzar per deixar caure dades [pinned] de manera segura.
    ///
    /// Si teniu la propietat del valor, podeu utilitzar [`ManuallyDrop::into_inner`].
    ///
    /// # Safety
    ///
    /// Aquesta funció executa el destructor del valor contingut.
    /// A part dels canvis fets pel propi destructor, la memòria es manté inalterada i, pel que fa al compilador, encara manté un patró de bits vàlid per al tipus `T`.
    ///
    ///
    /// Tanmateix, aquest valor "zombie" no s`ha d`exposar al codi segur i no s`ha de cridar aquesta funció més d`una vegada.
    /// Si utilitzeu un valor després d`haver-lo suprimit o deixar-lo caure diverses vegades, podeu provocar un comportament indefinit (segons el que faci `drop`).
    /// Normalment, el sistema de tipus ho impedeix, però els usuaris de `ManuallyDrop` han de mantenir aquestes garanties sense l'assistència del compilador.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SEGURETAT: estem deixant caure el valor assenyalat per una referència mutable
        // que es garanteix que serà vàlid per a escriptures.
        // Correspon a la persona que truca assegurar-se que `slot` no es torni a deixar caure.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}