//! Funcions bàsiques per tractar la memòria.
//!
//! Aquest mòdul conté funcions per consultar la mida i l'alineació dels tipus, inicialitzar i manipular la memòria.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Adopta la propietat i "forgets" sobre el valor **sense executar el seu destructor**.
///
/// Qualsevol recurs gestionat pel valor, com ara la memòria dinàmica o un controlador de fitxers, perdurarà per sempre en un estat inaccessible.Tot i això, no garanteix que els indicadors d`aquesta memòria continuïn sent vàlids.
///
/// * Si voleu filtrar memòria, consulteu [`Box::leak`].
/// * Si voleu obtenir un punter en brut a la memòria, consulteu [`Box::into_raw`].
/// * Si voleu eliminar un valor correctament, executant-ne el destructor, consulteu [`mem::drop`].
///
/// # Safety
///
/// `forget` no està marcat com a `unsafe`, perquè les garanties de seguretat de Rust no inclouen la garantia que els destructors funcionaran sempre.
/// Per exemple, un programa pot crear un cicle de referència mitjançant [`Rc`][rc] o trucar a [`process::exit`][exit] per sortir sense executar destructors.
/// Per tant, permetre `mem::forget` des de codi segur no canvia fonamentalment les garanties de seguretat de Rust.
///
/// Dit això, normalment no és desitjable filtrar recursos com ara memòria o objectes I/O.
/// La necessitat sorgeix en alguns casos d`ús especialitzats per a codi FFI o no segur, però fins i tot llavors, normalment es prefereix [`ManuallyDrop`].
///
/// Com que es pot oblidar un valor, qualsevol codi `unsafe` que escriviu ha de permetre aquesta possibilitat.No podeu retornar un valor i esperar que la persona que truca necessàriament executi el destructor del valor.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// L'ús canònic segur de `mem::forget` és eludir un destructor de valor implementat per `Drop` trait.Per exemple, això filtrarà un `File`, és a dir
/// recuperar l'espai ocupat per la variable però mai tancar el recurs del sistema subjacent:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Això és útil quan la propietat del recurs subjacent es va transferir prèviament a codi fora de Rust, per exemple mitjançant la transmissió del descriptor de fitxers en brut al codi C.
///
/// # Relació amb `ManuallyDrop`
///
/// Tot i que `mem::forget` també es pot utilitzar per transferir la propietat de *memòria*, fer-ho és propens a errors.
/// [`ManuallyDrop`] s'hauria d'utilitzar en el seu lloc.Penseu, per exemple, en aquest codi:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Construïu un `String` utilitzant el contingut de `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // fuita `v` perquè la seva memòria ara és gestionada per `s`
/// mem::forget(v);  // ERROR, v no és vàlid i no s`ha de passar a una funció
/// assert_eq!(s, "Az");
/// // `s` es deixa implícitament i es reparteix la seva memòria.
/// ```
///
/// Hi ha dos problemes amb l'exemple anterior:
///
/// * Si s'afegís més codi entre la construcció de `String` i la invocació de `mem::forget()`, un panic dins d'ell causaria un doble lliure perquè la mateixa memòria és gestionada tant per `v` com per `s`.
/// * Després de trucar a `v.as_mut_ptr()` i transmetre la propietat de les dades a `s`, el valor `v` no és vàlid.
/// Fins i tot quan un valor s`acaba de moure a `mem::forget` (que no l`inspeccionarà), alguns tipus tenen requisits estrictes sobre els seus valors que els fan invàlids quan es pengen o ja no són propietat.
/// L`ús de valors no vàlids de qualsevol manera, inclòs el seu pas o retorn de funcions, constitueix un comportament indefinit i pot trencar les suposicions fetes pel compilador.
///
/// Canviar a `ManuallyDrop` evita tots dos problemes:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Abans de desmuntar `v` a les seves parts en brut, assegureu-vos que no caigui.
/////
/// let mut v = ManuallyDrop::new(v);
/// // Ara desmunteu `v`.Aquestes operacions no poden panic, de manera que no hi pot haver cap fuita.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Finalment, creeu un `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` es deixa implícitament i es reparteix la seva memòria.
/// ```
///
/// `ManuallyDrop` impedeix robustament el doble lliure perquè desactivem el destructor de `v` abans de fer qualsevol altra cosa.
/// `mem::forget()` no ho permet perquè consumeix el seu argument, cosa que ens obliga a trucar-lo només després d`extreure qualsevol cosa que necessitem de `v`.
/// Fins i tot si s`introduís un panic entre la construcció de `ManuallyDrop` i la construcció de la cadena (cosa que no pot passar al codi tal com es mostra), donaria lloc a una fuita i no a un doble lliure.
/// Dit d`una altra manera, `ManuallyDrop` falla al costat de la filtració en lloc d`errar al costat de la caiguda (doble).
///
/// A més, `ManuallyDrop` ens impedeix haver de fer "touch" `v` després de transferir la propietat a `s`; s`evita per complet el pas final d`interaccionar amb `v` per disposar-ne sense executar el destructor.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Igual que [`forget`], però també accepta valors sense mida.
///
/// Aquesta funció és només una calçada destinada a eliminar-se quan la funció `unsized_locals` s`estabilitzi.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Retorna la mida d'un tipus en bytes.
///
/// Més específicament, es tracta del desplaçament en bytes entre elements successius en una matriu amb aquest tipus d'element, inclòs el farciment d'alineació.
///
/// Per tant, per a qualsevol tipus `T` i longitud `n`, `[T; n]` té una mida de `n * size_of::<T>()`.
///
/// En general, la mida d`un tipus no és estable entre les recopilacions, però sí que hi ha tipus específics, com ara les primitives.
///
/// La taula següent mostra la mida de les primitives.
///
/// Escriviu |mida_de: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 caràcters |4
///
/// A més, `usize` i `isize` tenen la mateixa mida.
///
/// Tots els tipus `*const T`, `&T`, `Box<T>`, `Option<&T>` i `Option<Box<T>>` tenen la mateixa mida.
/// Si `T` és de mida, tots aquests tipus tenen la mateixa mida que `usize`.
///
/// La mutabilitat d`un punter no canvia la seva mida.Com a tals, `&T` i `&mut T` tenen la mateixa mida.
/// De la mateixa manera per a `*const T` i `* mut T`.
///
/// # Mida dels elements `#[repr(C)]`
///
/// La representació `C` per als elements té un disseny definit.
/// Amb aquest disseny, la mida dels elements també és estable sempre que tots els camps tinguin una mida estable.
///
/// ## Mida dels Structs
///
/// Per a `structs`, la mida està determinada per l'algoritme següent.
///
/// Per a cada camp de l'estructura ordenat per ordre de declaració:
///
/// 1. Afegiu la mida del camp.
/// 2. Arrodoneu la mida actual al múltiple més proper del [alignment] del següent camp.
///
/// Finalment, arrodoneu la mida de l`estructura al múltiple més proper del seu [alignment].
/// L'alineació de l'estructura sol ser l'alineació més gran de tots els seus camps;això es pot canviar amb l'ús de `repr(align(N))`.
///
/// A diferència de l `C`, les estructures de mida zero no s`arrodoneixen a un byte de mida.
///
/// ## Mida dels ingressos
///
/// Les entrades que no contenen dades diferents del discriminant tenen la mateixa mida que les entrades C a la plataforma per a la qual es compilen.
///
/// ## Mida dels sindicats
///
/// La mida d`una unió és la mida del seu camp més gran.
///
/// A diferència de l `C`, les unions de mida zero no s`arrodoneixen a un byte de mida.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Alguns primitius
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Algunes matrius
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Igualtat de mida del punter
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Utilitzant `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // La mida del primer camp és 1, de manera que afegiu-ne 1.La mida és 1.
/// // L'alineació del segon camp és 2, de manera que afegiu-ne 1 a la mida del farciment.La mida és de 2.
/// // La mida del segon camp és 2, de manera que afegiu-ne 2.La mida és de 4.
/// // L'alineació del tercer camp és 1, de manera que afegiu 0 a la mida del farciment.La mida és de 4.
/// // La mida del tercer camp és 1, de manera que afegiu-ne 1.La mida és de 5.
/// // Finalment, l'alineació de l'estructura és 2 (perquè l'alineació més gran entre els seus camps és 2), de manera que afegiu-ne 1 a la mida del farciment.
/// // La mida és de 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Les estructures de tuples segueixen les mateixes regles.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Tingueu en compte que la reordenació dels camps pot reduir la mida.
/// // Podem eliminar tots dos bytes de farciment posant `third` abans que `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // La mida de la unió és la mida del camp més gran.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Retorna la mida del valor apuntat en bytes.
///
/// Normalment és el mateix que `size_of::<T>()`.
/// Tanmateix, quan `T`*no té* una mida coneguda estàticament, per exemple, un segment [`[T]`][slice] o un [trait object], es pot utilitzar `size_of_val` per obtenir la mida coneguda dinàmicament.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SEGURETAT: `val` és una referència, per tant, és un punter en brut vàlid
    unsafe { intrinsics::size_of_val(val) }
}

/// Retorna la mida del valor apuntat en bytes.
///
/// Normalment és el mateix que `size_of::<T>()`.Tanmateix, quan `T`*no té* una mida coneguda estàticament, per exemple, un segment [`[T]`][slice] o un [trait object], es pot utilitzar `size_of_val_raw` per obtenir la mida coneguda dinàmicament.
///
/// # Safety
///
/// Aquesta funció només es pot trucar amb seguretat si es compleixen les condicions següents:
///
/// - Si `T` és `Sized`, sempre es pot trucar amb seguretat a aquesta funció.
/// - Si la cua sense mida de `T` és:
///     - un [slice], llavors la longitud de la cua de tall ha de ser un enter inicialitzat i la mida del *valor sencer*(longitud de la cua dinàmica + prefix de mida estàtica) ha de cabre a `isize`.
///     - un [trait object], la part vtable del punter ha d`assenyalar una taula vtable vàlida adquirida per una coacció de mida, i la mida del *valor sencer*(longitud de la cua dinàmica + prefix de mida estàtica) ha d`adaptar-se a `isize`.
///
///     - un (unstable) [extern type], llavors aquesta funció és sempre segura per trucar, però pot ser que panic o, de qualsevol altra manera, torni el valor incorrecte, ja que no es coneix el disseny del tipus extern.
///     Aquest és el mateix comportament que [`size_of_val`] en una referència a un tipus amb una cua de tipus extern.
///     - en cas contrari, no es permet conservar aquesta funció.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SEGURETAT: la persona que truca ha de proporcionar un punter en brut vàlid
    unsafe { intrinsics::size_of_val(val) }
}

/// Retorna l'alineació mínima requerida per [ABI] d'un tipus.
///
/// Totes les referències a un valor del tipus `T` han de ser múltiples d`aquest número.
///
/// Aquest és l'alineament utilitzat per als camps struct.Pot ser més petit que l'alineació preferida.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Retorna l'alineació mínima requerida per [ABI] del tipus de valor al qual apunta `val`.
///
/// Totes les referències a un valor del tipus `T` han de ser múltiples d`aquest número.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SEGURETAT: val és una referència, per tant és un punter en brut vàlid
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Retorna l'alineació mínima requerida per [ABI] d'un tipus.
///
/// Totes les referències a un valor del tipus `T` han de ser múltiples d`aquest número.
///
/// Aquest és l'alineament utilitzat per als camps struct.Pot ser més petit que l'alineació preferida.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Retorna l'alineació mínima requerida per [ABI] del tipus de valor al qual apunta `val`.
///
/// Totes les referències a un valor del tipus `T` han de ser múltiples d`aquest número.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SEGURETAT: val és una referència, per tant és un punter en brut vàlid
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Retorna l'alineació mínima requerida per [ABI] del tipus de valor al qual apunta `val`.
///
/// Totes les referències a un valor del tipus `T` han de ser múltiples d`aquest número.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Aquesta funció només es pot trucar amb seguretat si es compleixen les condicions següents:
///
/// - Si `T` és `Sized`, sempre es pot trucar amb seguretat a aquesta funció.
/// - Si la cua sense mida de `T` és:
///     - un [slice], llavors la longitud de la cua de tall ha de ser un enter inicialitzat i la mida del *valor sencer*(longitud de la cua dinàmica + prefix de mida estàtica) ha de cabre a `isize`.
///     - un [trait object], la part vtable del punter ha d`assenyalar una taula vtable vàlida adquirida per una coacció de mida, i la mida del *valor sencer*(longitud de la cua dinàmica + prefix de mida estàtica) ha d`adaptar-se a `isize`.
///
///     - un (unstable) [extern type], llavors aquesta funció és sempre segura per trucar, però pot ser que panic o, de qualsevol altra manera, torni el valor incorrecte, ja que no es coneix el disseny del tipus extern.
///     Aquest és el mateix comportament que [`align_of_val`] en una referència a un tipus amb una cua de tipus extern.
///     - en cas contrari, no es permet conservar aquesta funció.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SEGURETAT: la persona que truca ha de proporcionar un punter en brut vàlid
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Retorna `true` si importa deixar caure valors del tipus `T`.
///
/// Aquest és purament un suggeriment d'optimització i es pot implementar de manera conservadora:
/// pot retornar `true` per als tipus que realment no cal deixar de banda.
/// Com a tal, retornar sempre `true` seria una implementació vàlida d'aquesta funció.Tanmateix, si aquesta funció realment retorna `false`, podeu estar segur que deixar caure `T` no té cap efecte secundari.
///
/// Les implementacions de baix nivell, com ara les col・leccions, que necessiten deixar manualment les seves dades, haurien d`utilitzar aquesta funció per evitar intentar innecessàriament deixar caure tot el seu contingut quan es destrueixin.
///
/// Això pot no fer cap diferència en les versions de versions (on es detecta i elimina fàcilment un bucle que no té efectes secundaris), però sovint suposa un gran guany per a les versions de depuració.
///
/// Tingueu en compte que [`drop_in_place`] ja realitza aquesta comprovació, de manera que si la vostra càrrega de treball es pot reduir a un nombre reduït de trucades [`drop_in_place`], no és necessari fer-ne servir.
/// En particular, tingueu en compte que podeu x00x una porció, i que farà una única comprovació de needs_drop per a tots els valors.
///
/// Tipus com Vec, per tant, només `drop_in_place(&mut self[..])` sense utilitzar `needs_drop` explícitament.
/// Tipus com [`HashMap`], en canvi, han de deixar caure els valors d`un en un i han d`utilitzar aquesta API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Aquí teniu un exemple de com una col・lecció pot fer ús de `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // deixeu anar les dades
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Retorna el valor del tipus `T` representat pel patró de bytes totalment zero.
///
/// Això significa que, per exemple, el byte de farciment a `(u8, u16)` no necessàriament està a zero.
///
/// No es garanteix que un patró de bytes totalment zero representi un valor vàlid d'algun tipus `T`.
/// Per exemple, el patró de bytes totalment nul no és un valor vàlid per als tipus de referència (`&T`, `&mut T`) i els indicadors de funcions.
/// L'ús de `zeroed` en aquests tipus provoca un [undefined behavior][ub] immediat perquè [the Rust compiler assumes][inv] indica que sempre hi ha un valor vàlid en una variable que considera inicialitzada.
///
///
/// Això té el mateix efecte que [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// De vegades, és útil per a FFI, però generalment s`ha d`evitar.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Ús correcte d'aquesta funció: inicialitzar un enter amb zero.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// Ús *incorrecte* d'aquesta funció: inicialització d'una referència amb zero.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Comportament sense definir.
/// let _y: fn() = unsafe { mem::zeroed() }; // I un altre cop!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SEGURETAT: la persona que truca ha de garantir que un valor totalment nul és vàlid per a `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Ignora les comprovacions inicials de memòria normals de Rust fent veure que produeix un valor de tipus `T`, mentre no fa res.
///
/// **Aquesta funció està obsoleta.** Utilitzeu [`MaybeUninit<T>`].
///
/// El motiu de la depreciació és que la funció bàsicament no es pot utilitzar correctament: té el mateix efecte que [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Com explica el [`assume_init` documentation][assume_init], [the Rust compiler assumes][inv] que els valors s`inicialitzen correctament.
/// Com a conseqüència, trucar per exemple
/// `mem::uninitialized::<bool>()` provoca un comportament immediat i indefinit per retornar un `bool` que no és definitivament ni `true` ni `false`.
/// La memòria pitjor, realment no inicialitzada, com la que es retorna aquí, és especial, ja que el compilador sap que no té un valor fix.
/// Això fa que el comportament no definit sigui tenir dades no inicialitzades en una variable, fins i tot si aquesta variable té un tipus enter.
/// (Tingueu en compte que les regles entorn dels nombres enters no inicialitzats encara no s`han finalitzat, però fins que s`aconsegueixin, és aconsellable evitar-les.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SEGURETAT: la persona que truca ha de garantir que un valor unititzat és vàlid per a `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Intercanvia els valors en dues ubicacions mutables, sense desinicialitzar cap.
///
/// * Si voleu canviar amb un valor per defecte o fals, consulteu [`take`].
/// * Si voleu canviar amb un valor passat, retornant el valor anterior, consulteu [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SEGURETAT: els punteres en brut s'han creat a partir de referències mutables segures que satisfan tots els fitxers
    // restriccions a `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Substitueix `dest` pel valor per defecte de `T`, retornant el valor `dest` anterior.
///
/// * Si voleu substituir els valors de dues variables, consulteu [`swap`].
/// * Si voleu substituir-lo per un valor passat en lloc del valor per defecte, consulteu [`replace`].
///
/// # Examples
///
/// Un exemple senzill:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` permet fer-se propietari d'un camp struct substituint-lo per un valor "empty".
/// Sense `take` podeu trobar problemes com aquests:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Tingueu en compte que `T` no necessàriament implementa [`Clone`], de manera que ni tan sols pot clonar i restablir `self.buf`.
/// Però `take` es pot utilitzar per desvincular el valor original de `self.buf` de `self`, permetent la seva devolució:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Mou `src` al `dest` a què es fa referència, retornant el valor anterior de `dest`.
///
/// Cap valor es deixa caure.
///
/// * Si voleu substituir els valors de dues variables, consulteu [`swap`].
/// * Si voleu substituir-lo per un valor per defecte, consulteu [`take`].
///
/// # Examples
///
/// Un exemple senzill:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` permet consumir un camp struct substituint-lo per un altre valor.
/// Sense `replace` podeu trobar problemes com aquests:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Tingueu en compte que `T` no necessàriament implementa [`Clone`], de manera que ni tan sols podem clonar `self.buf[i]` per evitar el moviment.
/// Però `replace` es pot utilitzar per desvincular el valor original d'aquest índex de `self`, cosa que permet retornar-lo:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SEGURETAT: llegim des de `dest`, però hi escrivim directament `src`,
    // de manera que el valor antic no es duplica.
    // Res no es deixa caure i res no pot panic aquí.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Disposa d'un valor.
///
/// Això ho fa trucant a la implementació de l'argument de [`Drop`][drop].
///
/// Això efectivament no fa res per als tipus que implementen `Copy`, per exemple
/// integers.
/// Aquests valors es copien i _then_ es mou a la funció, de manera que el valor persisteix després d'aquesta trucada a la funció.
///
///
/// Aquesta funció no és màgica;es defineix literalment com
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Com que `_x` es mou a la funció, es deixa automàticament abans que la funció torni.
///
/// [drop]: Drop
///
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // deixeu anar explícitament el vector
/// ```
///
/// Com que [`RefCell`] aplica les regles de préstec en temps d'execució, `drop` pot alliberar un préstec [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // renuncia al préstec mutable d`aquesta ranura
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Els enters i altres tipus que implementen [`Copy`] no es veuen afectats per `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // es mou i es deixa caure una còpia de `x`
/// drop(y); // es mou i es deixa caure una còpia de `y`
///
/// println!("x: {}, y: {}", x, y.0); // encara disponible
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Interpreta `src` com el tipus `&U` i després llegeix `src` sense moure el valor contingut.
///
/// Aquesta funció assumirà amb seguretat que el punter `src` és vàlid per a bytes [`size_of::<U>`][size_of] transmutant `&T` a `&U` i llegint el `&U` (excepte que això es fa d`una manera correcta fins i tot quan `&U` fa requisits d`alineació més estrictes que `&T`).
/// També crearà una còpia del valor contingut de manera insegura en lloc de sortir de `src`.
///
/// No és un error en temps de compilació si `T` i `U` tenen mides diferents, però es recomana invocar aquesta funció només si `T` i `U` tenen la mateixa mida.Aquesta funció activa [undefined behavior][ub] si `U` és més gran que `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Copieu les dades de 'foo_array' i tracteu-les com un 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Modifiqueu les dades copiades
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // El contingut de 'foo_array' no hauria d`haver canviat
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Si U té un requisit d'alineació més alt, és possible que src no estigui adequadament alineat.
    if align_of::<U>() > align_of::<T>() {
        // SEGURETAT: `src` és una referència que es garanteix que és vàlida per a lectures.
        // La persona que truca ha de garantir que la transmutació real és segura.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SEGURETAT: `src` és una referència que es garanteix que és vàlida per a lectures.
        // Acabem de comprovar que `src as *const U` estava correctament alineat.
        // La persona que truca ha de garantir que la transmutació real és segura.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Tipus opac que representa el discriminant d'una enum.
///
/// Consulteu la funció [`discriminant`] en aquest mòdul per obtenir més informació.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Aquestes implementacions trait no es poden derivar perquè no volem límits a T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Retorna un valor que identifica de manera única la variant enum a `v`.
///
/// Si `T` no és un enum, cridar a aquesta funció no comportarà un comportament indefinit, però el valor de retorn no s'especifica.
///
///
/// # Stability
///
/// El discriminant d'una variant d'enum pot canviar si la definició d'enum canvia.
/// Un discriminant d'algunes variants no canviarà entre les compilacions amb el mateix compilador.
///
/// # Examples
///
/// Es pot utilitzar per comparar les enumeracions que contenen dades, sense tenir en compte les dades reals:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Retorna el nombre de variants del tipus enum `T`.
///
/// Si `T` no és un enum, cridar a aquesta funció no comportarà un comportament indefinit, però el valor de retorn no s'especifica.
/// Igualment, si `T` és un enum amb més variants que `usize::MAX`, el valor de retorn no s'especifica.
/// Es comptaran les variants deshabitades.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}