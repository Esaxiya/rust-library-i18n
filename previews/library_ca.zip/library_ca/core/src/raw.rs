#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Conté definicions estructurals per al disseny dels tipus integrats del compilador.
//!
//! Es poden utilitzar com a objectius de transmutats en codi no segur per manipular directament les representacions en brut.
//!
//!
//! La seva definició sempre ha de coincidir amb l`ABI definida a `rustc_middle::ty::layout`.
//!

/// La representació d'un objecte trait com `&dyn SomeTrait`.
///
/// Aquesta estructura té el mateix disseny que els tipus com `&dyn SomeTrait` i `Box<dyn AnotherTrait>`.
///
/// `TraitObject` està garantit perquè coincideixi amb els dissenys, però no és el tipus d'objectes trait (per exemple, els camps no són accessibles directament en un `&dyn SomeTrait`) ni controla aquest disseny (canviar la definició no canviarà el disseny d'un `&dyn SomeTrait`).
///
/// Només està dissenyat per ser utilitzat per un codi no segur que necessiti manipular els detalls de baix nivell.
///
/// No hi ha manera de referir-se a tots els objectes trait de manera genèrica, de manera que l'única manera de crear valors d'aquest tipus és amb funcions com [`std::mem::transmute`][transmute].
/// De la mateixa manera, l'única manera de crear un objecte trait veritable a partir d'un valor `TraitObject` és amb `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// És molt probable que la sintetització d`un objecte trait amb tipus no coincidents (un on la taula vt no correspongui al tipus de valor al qual apunta el punter de dades) comporti un comportament indefinit.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // un exemple trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // deixeu que el compilador faci un objecte trait
/// let object: &dyn Foo = &value;
///
/// // mireu la representació crua
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // el punter de dades és l'adreça de `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // construïu un objecte nou, assenyalant un `i32` diferent, tenint cura d'utilitzar la taula vtable `i32` de `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // hauria de funcionar com si haguéssim construït directament un objecte trait a partir de `other_value`
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}