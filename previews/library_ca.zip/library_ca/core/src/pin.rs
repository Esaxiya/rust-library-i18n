//! Tipus que fixen les dades a la seva ubicació a la memòria.
//!
//! De vegades és útil tenir objectes que no es moguin garantits, en el sentit que la seva ubicació a la memòria no canvia i, per tant, es pot confiar.
//! Un exemple excel・lent d`aquest escenari seria la construcció d`estructures autoreferencials, ja que el fet de moure un objecte amb indicadors cap a ell mateix les invalidaria, cosa que podria provocar un comportament indefinit.
//!
//! A un nivell elevat, un [`Pin<P>`] garanteix que el punt de qualsevol tipus de punter `P` tingui una ubicació estable a la memòria, és a dir, que no es pugui moure a cap altre lloc i que la seva memòria no es pugui repartir fins que no quedi.Diem que el punt és "pinned".Les coses es tornen més subtils quan es discuteixen els tipus que combinen dades fixades amb dades no fixades;[see below](#projections-and-structural-pinning) per obtenir més informació.
//!
//! Per defecte, tots els tipus de Rust són mòbils.
//! Rust permet passar tots els tipus per valor, i els tipus de punter intel・ligents comuns com [`Box<T>`] i `&mut T` permeten substituir i moure els valors que contenen: podeu sortir d'un [`Box<T>`] o podeu utilitzar [`mem::swap`].
//! [`Pin<P>`] embolcalla un punter tipus `P`, de manera que [`Pin`]`<`[`Box`] `<T>>`funciona com un ordinari
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>>`es deixa caure, també ho fa el seu contingut i la memòria queda
//!
//! desassignat.De la mateixa manera, ["Pin"] "<&mut T>" s'assembla molt a `&mut T`.Tanmateix, [`Pin<P>`] no permet als clients obtenir realment un [`Box<T>`] o `&mut T` a les dades fixades, la qual cosa implica que no podeu utilitzar operacions com [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` necessita `&mut T`, però no ho podem aconseguir.
//!     // Estem atrapats, no podem canviar el contingut d`aquestes referències.
//!     // Podríem utilitzar `Pin::get_unchecked_mut`, però això no és segur per un motiu:
//!     // no se'ns permet utilitzar-lo per treure coses del `Pin`.
//! }
//! ```
//!
//! Val la pena reiterar que [`Pin<P>`]*no* canvia el fet que un compilador Rust considera que tots els tipus són mòbils.[`mem::swap`] es pot trucar a qualsevol `T`.En canvi, [`Pin<P>`] impedeix que es moguin certs *valors*(assenyalats per punteres embolicats en [`Pin<P>`]), cosa que fa impossible cridar mètodes que requereixen `&mut T` (com [`mem::swap`]).
//!
//! [`Pin<P>`] es pot utilitzar per embolicar qualsevol tipus de punter `P` i, per tant, interactua amb [`Deref`] i [`DerefMut`].Un [`Pin<P>`] on s'ha de considerar `P: Deref` com un "`P`-style pointer" a un `P::Target` fixat; per tant, un [`Pin`]`<`[`Box`] `<T>>`és un punter de propietat a un `T` fixat i un [`Pin`] `<` [`Rc`]`<T>>`és un punter comptable de referència a un `T` fixat.
//! Per tal de ser correcte, [`Pin<P>`] es basa en les implementacions de [`Deref`] i [`DerefMut`] per no sortir del seu paràmetre `self` i només tornar un punter a les dades fixades quan es crida a un punter fixat.
//!
//! # `Unpin`
//!
//! Molts tipus sempre es poden moure lliurement, fins i tot quan es fixen, perquè no depenen de tenir una adreça estable.Això inclou tots els tipus bàsics (com ara [`bool`], [`i32`] i referències), així com els tipus que consisteixen únicament en aquests tipus.Els tipus als quals no els importa fixar-se implementen el [`Unpin`] auto-trait, que cancel・la l`efecte de [`Pin<P>`].
//! Per a `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`i [`Box<T>`] funcionen de manera idèntica, igual que [`Pin`] `<&mut T>` i `&mut T`.
//!
//! Tingueu en compte que la fixació i [`Unpin`] només afecten el tipus apuntat `P::Target`, no el punter tipus `P` en si que es va embolicar a [`Pin<P>`].Per exemple, si [`Box<T>`] és [`Unpin`] o no, no té cap efecte sobre el comportament de [`Pin`]`<`[`Box`] `<T>>`(aquí, `T` és el tipus apuntat).
//!
//! # Exemple: estructura autoreferencial
//!
//! Abans d`entrar en més detalls per explicar les garanties i les opcions associades a `Pin<T>`, discutim alguns exemples de com es podria utilitzar.
//! No dubteu en [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Es tracta d`una estructura autoreferencial perquè el camp de la secció apunta al camp de dades.
//! // No podem informar-ho al compilador amb una referència normal, ja que aquest patró no es pot descriure amb les regles habituals de préstec.
//! //
//! // En lloc d'això, fem servir un punter en brut, encara que se sap que no és nul, ja que sabem que apunta a la cadena.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Per assegurar-nos que les dades no es mouen quan torna la funció, les col・loquem al muntatge on quedaran durant la vida de l'objecte i l'única manera d'accedir-hi seria mitjançant un punter.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // només creem el punter un cop les dades estiguin al seu lloc, ja que ja s'haurien mogut fins i tot abans de començar
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // sabem que això és segur perquè modificar un camp no mou tota l'estructura
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // El punter hauria d`assenyalar la ubicació correcta, sempre que l`estructura no s`hagi mogut.
//! //
//! // Mentrestant, som lliures de moure el punter.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Com que el nostre tipus no implementa Unpin, això no compilarà:
//! // let mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Exemple: llista intrusiva doblement enllaçada
//!
//! En una llista intrusiva doblement enllaçada, la col・lecció en realitat no assigna la memòria als elements en si.
//! Els clients controlen l`assignació i els elements poden viure en un marc de pila més curt que el que fa la col・lecció.
//!
//! Per fer que aquest treball funcioni, tots els elements tenen indicacions sobre el seu predecessor i successor a la llista.Els elements només es poden afegir quan es fixen, perquè el fet de moure els elements invalidaria els indicadors.D'altra banda, la implementació [`Drop`] d'un element de llista enllaçat ajudarà els indicadors del seu predecessor i successor per eliminar-se de la llista.
//!
//! De manera crucial, hem de poder confiar en la crida de [`drop`].Si un element es pot distribuir o invalidar d'una altra manera sense trucar a [`drop`], els indicadors dels elements veïns quedarien invàlids, cosa que trencaria l'estructura de dades.
//!
//! Per tant, la fixació també inclou una garantia relacionada amb ["drop"].
//!
//! # `Drop` guarantee
//!
//! El propòsit de fixar és poder confiar en la col・locació d'algunes dades a la memòria.
//! Per fer que això funcioni, no es limita només a moure les dades;també es restringeix la desassignació, la reutilització o la invalidació de la memòria utilitzada per emmagatzemar les dades.
//! Concretament, per a les dades fixades heu de mantenir invariable que *la seva memòria no quedarà invalidada ni reutilitzada des del moment en què es fixa fins que es diu [`drop`]*.Només un cop [`drop`] torna o panics, la memòria es pot reutilitzar.
//!
//! La memòria pot ser "invalidated" mitjançant una repartició, però també substituint un [`Some(v)`] per [`None`] o trucant a [`Vec::set_len`] a "kill" alguns elements d'un vector.Es pot reutilitzar utilitzant [`ptr::write`] per sobreescriure-la sense trucar primer al destructor.Res d`això està permès per a dades fixades sense trucar a [`drop`].
//!
//! Aquest és exactament el tipus de garantia que la intrusiva llista enllaçada de la secció anterior ha de funcionar correctament.
//!
//! Tingueu en compte que aquesta garantia *no* significa que la memòria no fuig.Encara està completament bé no trucar mai a [`drop`] a un element fixat (per exemple, encara es pot trucar a [`mem::forget`] amb un [`Pin`]`<`[`Box`] `<T>>`).A l'exemple de la llista doblement enllaçada, aquest element només quedaria a la llista.Tanmateix, no podeu alliberar ni tornar a utilitzar l`emmagatzematge *sense trucar a [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Si el vostre tipus utilitza fixació (com ara els dos exemples anteriors), heu de tenir precaució a l`hora d`implementar [`Drop`].La funció [`drop`] requereix `&mut self`, però això s'anomena *fins i tot si el vostre tipus s'havia fixat prèviament*.És com si el compilador anomenés automàticament [`Pin::get_unchecked_mut`].
//!
//! Això mai no pot causar cap problema en el codi segur perquè la implementació d`un tipus que depengui de la fixació requereix un codi no segur, però tingueu en compte que decidir fer ús de la fixació al vostre tipus (per exemple, implementant alguna operació a [`Pin`]` <&Self> `o [` Pin`]`<&mut Self>`) també té conseqüències per a la vostra implementació de [`Drop`]: si s'ha pogut fixar un element del vostre tipus, heu de tractar [`Drop`] com implícitament que prenia [`Pin`]` <&mut Jo> `.
//!
//!
//! Per exemple, podeu implementar `Drop` de la següent manera:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` està bé perquè sabem que aquest valor no es tornarà a fer servir després de deixar-lo caure.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // El codi de caiguda real va aquí.
//!         }
//!     }
//! }
//! ```
//!
//! La funció `inner_drop` té el tipus que hauria de tenir [`drop`] *, de manera que assegureu-vos que no utilitzeu accidentalment `self`/`this` d'una manera que estigui en conflicte amb la fixació.
//!
//! A més, si el vostre tipus és `#[repr(packed)]`, el compilador mourà automàticament els camps per deixar-los caure.Fins i tot podria fer-ho per als camps que estiguin suficientment alineats.Com a conseqüència, no podeu fer servir fixacions amb un tipus `#[repr(packed)]`.
//!
//! # Projeccions i fixació estructural
//!
//! Quan es treballa amb estructures fixades, sorgeix la pregunta de com es pot accedir als camps d`aquesta estructura en un mètode que només necessita [`Pin`]` <&mut Struct> `.
//! L`enfocament habitual és escriure mètodes d`ajuda (les anomenades *projeccions*) que converteixen [`Pin`]`<&mut Struct>`en una referència al camp, però quin tipus ha de tenir aquesta referència?És [`Pin`]`<&Mut Field>`o `&mut Field`?
//! La mateixa pregunta sorgeix amb els camps d'un `enum`, i també quan es consideren tipus container/wrapper com [`Vec<T>`], [`Box<T>`] o [`RefCell<T>`].
//! (Aquesta pregunta s'aplica tant a referències mutables com a referències compartides, només fem servir el cas més comú de referències mutables aquí per il・lustrar-les)
//!
//! Resulta que en realitat correspon a l'autor de l'estructura de dades decidir si la projecció fixada per a un camp concret converteix [`Pin`]`<&mut Struct>`en [`Pin`] `<&mut Field>` o `&mut Field`.Hi ha algunes limitacions, però, i la restricció més important és la *consistència*:
//! tots els camps es poden projectar *o bé* amb una referència fixada,*o bé* eliminar el fixació com a part de la projecció.
//! Si tots dos es fan pel mateix camp, probablement no serà correcte.
//!
//! Com a autor d'una estructura de dades, heu de decidir per a cada camp si fixeu "propagates" a aquest camp o no.
//! El fixació que es propaga també s'anomena "structural", perquè segueix l'estructura del tipus.
//! A les subseccions següents, es descriuen les consideracions que cal fer per a qualsevol de les opcions.
//!
//! ## Fixar *no és* estructural per a `field`
//!
//! Pot semblar contrari a la intuïció que el camp d`una estructura fixada no es pugui fixar, però en realitat aquesta és l`opció més senzilla: si mai no es crea un [`Pin`]`<&Mut Field>`, res no pot sortir malament.Per tant, si decidiu que algun camp no té fixacions estructurals, tot el que heu d`assegurar és que mai no creeu una referència fixada a aquest camp.
//!
//! Els camps sense fixació estructural poden tenir un mètode de projecció que converteixi [`Pin`]`<&mut Struct>`en `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Està bé perquè `field` mai es considera fixat.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! També podeu fer `impl Unpin for Struct`*encara que* el tipus de `field` no sigui [`Unpin`].El que pensa aquest tipus sobre la fixació no és rellevant quan no es crea mai cap [[Pin]] `<&mut Field>`.
//!
//! ## Fixar *és* estructural per a `field`
//!
//! L'altra opció és decidir que fixar és "structural" per a `field`, és a dir, si l'estructura està fixada, també ho serà el camp.
//!
//! Això permet escriure una projecció que crea un [`Pin`]`<&mut Field>`, donant testimoni que el camp està fixat:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Està bé perquè `field` està fixat quan `self` ho és.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! No obstant això, la fixació estructural inclou alguns requisits addicionals:
//!
//! 1. L'estructura només ha de ser [`Unpin`] si tots els camps estructurals són [`Unpin`].Aquest és el valor per defecte, però [`Unpin`] és un trait segur, de manera que, com a autor de l'estructura, és responsabilitat vostra *no* afegir alguna cosa com `impl<T> Unpin for Struct<T>`.
//! (Tingueu en compte que per afegir una operació de projecció cal un codi no segur, de manera que el fet que [`Unpin`] sigui un trait segur no trenca el principi que només us heu de preocupar de tot això si utilitzeu `no segur '.)
//! 2. El destructor de l'estructura no ha de moure els camps estructurals del seu argument.Aquest és el punt exacte que es va plantejar al [previous section][drop-impl]: `drop` pren `&mut self`, però és possible que l'estructura (i, per tant, els seus camps) s'hagi fixat abans.
//!     Heu de garantir que no moveu cap camp dins de la vostra implementació [`Drop`].
//!     En particular, tal com s'ha explicat anteriorment, això significa que la vostra estructura *no* ha de ser `#[repr(packed)]`.
//!     Consulteu aquesta secció per escriure [`drop`] de manera que el compilador us pugui ajudar a no trencar accidentalment els fixacions.
//! 3. Heu d'assegurar-vos que manteniu l [`Drop` guarantee][drop-guarantee]:
//!     un cop fixada la vostra estructura, la memòria que conté el contingut no es sobreescriu ni es reparteix sense trucar als destructors del contingut.
//!     Això pot ser complicat, com ho demostra [`VecDeque<T>`]: el destructor de [`VecDeque<T>`] pot fallar en trucar a [`drop`] en tots els elements si un dels destructors panics.Això infringeix la garantia [`Drop`], ja que pot provocar la deslocalització d'elements sense que es cridi el seu destructor.([`VecDeque<T>`] no té projeccions de fixació, de manera que això no causa molèsties.)
//! 4. No heu d'oferir cap altra operació que pugui fer que les dades surtin dels camps estructurals quan es fixa el vostre tipus.Per exemple, si l'estructura conté un [`Option<T>`] i hi ha una operació semblant a "prendre" amb el tipus `fn(Pin<&mut Struct<T>>) -> Option<T>`, aquesta operació es pot utilitzar per treure un `T` d'un `Struct<T>` fixat, cosa que significa que el fixació no pot ser estructural per al camp que conté aquest dades.
//!
//!     Per obtenir un exemple més complex de moure dades d'un tipus fixat, imagineu-vos si [`RefCell<T>`] tenia un mètode `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Aleshores podríem fer el següent:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Això és catastròfic, vol dir que primer podem fixar el contingut de l [`RefCell<T>`] (mitjançant `RefCell::get_pin_mut`) i després moure aquest contingut mitjançant la referència mutable que hem obtingut més tard.
//!
//! ## Examples
//!
//! Per a un tipus com [`Vec<T>`], les dues possibilitats (fixació estructural o no) tenen sentit.
//! Un [`Vec<T>`] amb fixació estructural podria tenir mètodes `get_pin`/`get_pin_mut` per obtenir referències fixades a elements.Tanmateix,*no* podria * permetre trucar a [`pop`][Vec::pop] en un [`Vec<T>`] fixat perquè això mouria el contingut (fixat estructuralment).Tampoc no podia permetre [`push`][Vec::push], que podria reassignar i, per tant, també moure el contingut.
//!
//! Un [`Vec<T>`] sense fixació estructural podria ser `impl<T> Unpin for Vec<T>`, perquè el contingut mai no es fixa i el propi [`Vec<T>`] també està bé si es mou.
//! En aquest moment, la fixació no té cap efecte en el vector.
//!
//! A la biblioteca estàndard, els tipus de punter generalment no tenen fixacions estructurals i, per tant, no ofereixen projeccions de fixació.És per això que `Box<T>: Unpin` val per a tots els `T`.
//! És lògic fer-ho per als tipus de punter, perquè el fet de moure el `Box<T>` en realitat no mou el `T`: el [`Box<T>`] es pot moure lliurement (també conegut com `Unpin`) fins i tot si el `T` no ho és.De fet, fins i tot [`Pin`]`<`[`Box`] `<T>>`i [`Pin`] `<&mut T>` sempre són ells mateixos [`Unpin`], per la mateixa raó: el seu contingut (el `T`) està fixat, però els propis indicadors es poden moure sense moure les dades fixades.
//! Tant per a [`Box<T>`] com per a [`Pin`]`<`[`Box`] `<T>>`, si el contingut està fixat és totalment independent que el punter estigui fixat, és a dir, que el fixació *no sigui* estructural.
//!
//! En implementar un combinador [`Future`], normalment necessiteu fixacions estructurals per al futures imbricat, ja que necessiteu obtenir referències fixades a elles per trucar a [`poll`].
//! Però si el combinador conté altres dades que no necessiten ser fixades, podeu fer que aquests camps no siguin estructurals i, per tant, accedir-hi lliurement amb una referència mutable fins i tot quan només tingueu [`Pin`]`<&mut Self>`(com com en la vostra pròpia implementació [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Un punter fixat.
///
/// Es tracta d'un embolcall al voltant d'una mena de punter que fa que el punter "pin" tingui el seu valor, evitant que es mogui el valor a què fa referència aquell punter a menys que implementi [`Unpin`].
///
///
/// *Consulteu la documentació del [`pin` module] per obtenir una explicació sobre el fixació.*
///
/// [`pin` module]: self
///
// Note: el `Clone` derivat a continuació provoca insolència ja que és possible implementar-lo
// `Clone` per a referències mutables.
// Consulteu <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> per obtenir més detalls.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Les implementacions següents no es deriven per evitar problemes de solidesa.
// `&self.pointer` no hauria de ser accessible per a implementacions trait no fiables.
//
// Consulteu <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> per obtenir més detalls.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Construeix un nou `Pin<P>` al voltant d'un punter a algunes dades d'un tipus que implementi [`Unpin`].
    ///
    /// A diferència de `Pin::new_unchecked`, aquest mètode és segur perquè el punter `P` fa referència a un tipus [`Unpin`], que cancel・la les garanties de fixació.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SEGURETAT: el valor assenyalat és `Unpin` i, per tant, no té requisits
        // al voltant de fixar.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Desenfora aquest `Pin<P>` retornant el punter subjacent.
    ///
    /// Això requereix que les dades d`aquest `Pin` siguin [`Unpin`], de manera que puguem ignorar els invariants de fixació quan els desemboliqueu.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Construeix un nou `Pin<P>` al voltant d'una referència a algunes dades d'un tipus que pugui implementar o no `Unpin`.
    ///
    /// Si `pointer` anul・la les referències a un tipus `Unpin`, s'hauria d'utilitzar `Pin::new`.
    ///
    /// # Safety
    ///
    /// Aquest constructor no és segur perquè no podem garantir que es fixin les dades assenyalades per `pointer`, és a dir, que no es mouran ni es invalidarà el seu emmagatzematge fins que no es deixin de banda.
    /// Si el `Pin<P>` construït no garanteix que es fixin les dades a què apunta `P`, això suposa una infracció del contracte de l'API i pot comportar un comportament indefinit en operacions posteriors de (safe).
    ///
    /// En utilitzar aquest mètode, feu una promise sobre les implementacions `P::Deref` i `P::DerefMut`, si existeixen.
    /// El més important, no han de sortir dels arguments `self`: `Pin::as_mut` i `Pin::as_ref` trucaran a `DerefMut::deref_mut` i `Deref::deref`*al punter fixat* i esperen que aquests mètodes mantinguin els invariants de fixació.
    /// A més, trucant a aquest mètode, promise que les referències a les referències `P` no es tornaran a treure;en particular, no ha de ser possible obtenir un `&mut P::Target` i després sortir d'aquesta referència (utilitzant, per exemple, [`mem::swap`]).
    ///
    ///
    /// Per exemple, trucar a `Pin::new_unchecked` en un `&'a mut T` no és segur perquè, tot i que podeu fixar-lo durant el període de vida determinat `'a`, no teniu control sobre si es manté fixat un cop finalitza `'a`:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Això hauria de significar que el punt `a` no es pot moure mai més.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // L'adreça de `a` va canviar a la ranura de pila de "b", de manera que `a` es va moure tot i que prèviament l'hem fixat.Hem incomplert el contracte de l'API de fixació.
    /////
    /// }
    /// ```
    ///
    /// Un valor, un cop fixat, ha de romandre fixat per sempre (tret que el seu tipus implementi `Unpin`).
    ///
    /// De la mateixa manera, trucar a `Pin::new_unchecked` amb un `Rc<T>` no és segur perquè hi pot haver àlies de les mateixes dades que no estiguin subjectes a les restriccions de fixació:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Això hauria de significar que el apunt no es pot moure mai més.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Ara bé, si `x` era l'única referència, tenim una referència mutable a les dades que hem fixat més amunt, que podríem utilitzar per moure-les tal com hem vist a l'exemple anterior.
    ///     // Hem incomplert el contracte de l'API de fixació.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Obté una referència compartida fixada des d'aquest punter fixat.
    ///
    /// Aquest és un mètode genèric per anar de `&Pin<Pointer<T>>` a `Pin<&T>`.
    /// És segur perquè, com a part del contracte de `Pin::new_unchecked`, el apunt no es pot moure després de crear `Pin<Pointer<T>>`.
    ///
    /// "Malicious" les implementacions de `Pointer::Deref` també estan descartades pel contracte de `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SEGURETAT: consulteu la documentació sobre aquesta funció
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Desenfora aquest `Pin<P>` retornant el punter subjacent.
    ///
    /// # Safety
    ///
    /// Aquesta funció no és segura.Heu de garantir que continuareu tractant el punter `P` com a fixat després de trucar a aquesta funció, de manera que es puguin mantenir els invariants del tipus `Pin`.
    /// Si el codi que utilitza l `P` resultant no continua mantenint els invariants de fixació, això suposa una violació del contracte de l'API i pot comportar un comportament indefinit en operacions (safe) posteriors.
    ///
    ///
    /// Si les dades subjacents són [`Unpin`], s'hauria d'utilitzar [`Pin::into_inner`].
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Obté una referència mutable fixada des d'aquest punter fixat.
    ///
    /// Aquest és un mètode genèric per anar de `&mut Pin<Pointer<T>>` a `Pin<&mut T>`.
    /// És segur perquè, com a part del contracte de `Pin::new_unchecked`, el apunt no es pot moure després de crear `Pin<Pointer<T>>`.
    ///
    /// "Malicious" les implementacions de `Pointer::DerefMut` també estan descartades pel contracte de `Pin::new_unchecked`.
    ///
    /// Aquest mètode és útil quan feu diverses trucades a funcions que consumeixen el tipus fixat.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // fer quelcom
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` consumeix `self`, de manera que torneu a demanar l `Pin<&mut Self>` a través de `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SEGURETAT: consulteu la documentació sobre aquesta funció
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Assigna un valor nou a la memòria darrere de la referència fixada.
    ///
    /// Això sobreescriu les dades fixades, però està bé: el seu destructor s'executa abans de sobreescriure's, de manera que no es infringeix cap garantia de fixació.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Construeix un nou pin assignant el valor interior.
    ///
    /// Per exemple, si voleu obtenir un `Pin` d'un camp d'alguna cosa, podeu utilitzar-lo per accedir a aquest camp en una línia de codi.
    /// No obstant això, hi ha diversos gotchas amb aquests "pinning projections";
    /// consulteu la documentació [`pin` module] per obtenir més detalls sobre aquest tema.
    ///
    /// # Safety
    ///
    /// Aquesta funció no és segura.
    /// Heu de garantir que les dades que retorneu no es mouran mentre el valor de l`argument no es mogui (per exemple, perquè és un dels camps d`aquest valor), i també que no sortiu de l`argument que rebeu a la funció interior.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SEGURETAT: el contracte de seguretat per a `new_unchecked` ha de ser
        // confirmat per la persona que truca.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Obté una referència compartida d'un pin.
    ///
    /// Això és segur perquè no és possible sortir d`una referència compartida.
    /// Pot semblar que hi hagi un problema amb la mutabilitat interior: de fet,*és* possible treure un `T` d'un `&RefCell<T>`.
    /// Tot i això, no és un problema sempre que no existeixi cap `Pin<&T>` que apunti a les mateixes dades i `RefCell<T>` no us permeti crear una referència fixada al seu contingut.
    ///
    /// Consulteu la discussió sobre ["pinning projections"] per obtenir més detalls.
    ///
    /// Note: `Pin` també implementa `Deref` a l'objectiu, que es pot utilitzar per accedir al valor intern.
    /// Tanmateix, `Deref` només proporciona una referència que es manté durant el préstec del `Pin`, no la vida del `Pin` en si.
    /// Aquest mètode permet convertir l `Pin` en una referència amb la mateixa vida útil que l `Pin` original.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Converteix aquest `Pin<&mut T>` en un `Pin<&T>` amb la mateixa vida útil.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Obté una referència mutable a les dades dins d`aquest `Pin`.
    ///
    /// Això requereix que les dades d`aquest `Pin` siguin `Unpin`.
    ///
    /// Note: `Pin` també implementa `DerefMut` a les dades, que es poden utilitzar per accedir al valor intern.
    /// Tanmateix, `DerefMut` només proporciona una referència que es manté durant el préstec del `Pin`, no la vida del `Pin` en si.
    ///
    /// Aquest mètode permet convertir l `Pin` en una referència amb la mateixa vida útil que l `Pin` original.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Obté una referència mutable a les dades dins d`aquest `Pin`.
    ///
    /// # Safety
    ///
    /// Aquesta funció no és segura.
    /// Heu de garantir que mai no traureu les dades de la referència mutable que rebeu quan truqueu a aquesta funció, de manera que es puguin mantenir els invariants del tipus `Pin`.
    ///
    ///
    /// Si les dades subjacents són `Unpin`, s'hauria d'utilitzar `Pin::get_mut`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Construeix un nou pin assignant el valor interior.
    ///
    /// Per exemple, si voleu obtenir un `Pin` d'un camp d'alguna cosa, podeu utilitzar-lo per accedir a aquest camp en una línia de codi.
    /// No obstant això, hi ha diversos gotchas amb aquests "pinning projections";
    /// consulteu la documentació [`pin` module] per obtenir més detalls sobre aquest tema.
    ///
    /// # Safety
    ///
    /// Aquesta funció no és segura.
    /// Heu de garantir que les dades que retorneu no es mouran mentre el valor de l`argument no es mogui (per exemple, perquè és un dels camps d`aquest valor), i també que no sortiu de l`argument que rebeu a la funció interior.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SEGURETAT: la persona que truca és responsable de no moure el fitxer
        // valor d`aquesta referència.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SEGURETAT: ja que es garanteix que no té el valor de `this`
        // desactivada, aquesta trucada a `new_unchecked` és segura.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Obteniu una referència fixada a partir d'una referència estàtica.
    ///
    /// Això és segur, ja que `T` es manlleva durant tota la vida del `'static`, que no s`acaba mai.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SEGURETAT: El préstec estàtic garanteix que les dades no seran
        // moved/invalidated fins que es deixa caure (que no ho és mai).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Obteniu una referència mutable fixada d'una referència mutable estàtica.
    ///
    /// Això és segur, ja que `T` es manlleva durant tota la vida del `'static`, que no s`acaba mai.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SEGURETAT: El préstec estàtic garanteix que les dades no seran
        // moved/invalidated fins que es deixa caure (que no ho és mai).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: això significa que qualsevol impl de `CoerceUnsized` que permeti la coacció
// un tipus que impliqui `Deref<Target=impl !Unpin>` a un tipus que impliqui `Deref<Target=Unpin>` no és correcte.
// Tanmateix, qualsevol implícit d`aquest tipus no seria raonable per altres motius, de manera que només hem de tenir cura de no permetre que aquests implícits aterrin a std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}