//! API d'assignació de memòria

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// L'error `AllocError` indica un error d'assignació que pot ser degut a l'esgotament dels recursos o a alguna cosa errònia en combinar els arguments d'entrada donats amb aquest assignador.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (ho necessitem per a la implementació posterior de l'error trait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Una implementació de `Allocator` pot assignar, créixer, reduir i distribuir blocs arbitraris de dades descrits a través de [`Layout`][].
///
/// `Allocator` està dissenyat per implementar-se en ZST, referències o punters intel・ligents perquè no es pot moure un assignador com `MyAlloc([u8; N])` sense actualitzar els punteros a la memòria assignada.
///
/// A diferència de [`GlobalAlloc`][], es permeten assignacions de mida zero a `Allocator`.
/// Si un assignador subjacent no admet això (com jemalloc) o retorna un punter nul (com ara `libc::malloc`), la implementació l'ha de capturar.
///
/// ### Memòria assignada actualment
///
/// Alguns dels mètodes requereixen que un bloc de memòria estigui *assignat actualment* mitjançant un assignador.Això significa que:
///
/// * [`allocate`], [`grow`] o [`shrink`] retornaven prèviament l'adreça inicial d'aquest bloc de memòria i
///
/// * el bloc de memòria no s'ha deslocalitzat posteriorment, on els blocs es distribueixen directament passant-se a [`deallocate`] o bé es canvien passant-se a [`grow`] o [`shrink`] que retorna `Ok`.
///
/// Si `grow` o `shrink` han retornat `Err`, el punter passat serà vàlid.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Ajust de memòria
///
/// Alguns dels mètodes requereixen que un disseny *s`adapti a* un bloc de memòria.
/// El que significa per a un disseny a "fit" un bloc de memòria significa (o de manera equivalent, per a un bloc de memòria a "fit" un disseny) és que han de complir-se les condicions següents:
///
/// * El bloc s'ha d'assignar amb la mateixa alineació que [`layout.align()`] i
///
/// * El [`layout.size()`] proporcionat ha de situar-se en el rang `min ..= max`, on:
///   - `min` és la mida del disseny utilitzat més recentment per assignar el bloc i
///   - `max` és la darrera mida real retornada de [`allocate`], [`grow`] o [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Els blocs de memòria retornats des d`un assignador han d`indicar memòria vàlida i conservar-ne la validesa fins que es retiri la instància i tots els seus clons,
///
/// * clonar o moure l`assignador no ha d`invalidar els blocs de memòria retornats d`aquest assignador.Un assignador clonat s'ha de comportar com el mateix assignador i
///
/// * qualsevol punter a un bloc de memòria que sigui [*currently allocated*] es pot passar a qualsevol altre mètode de l'assignador.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Intenta assignar un bloc de memòria.
    ///
    /// Si té èxit, retorna un [`NonNull<[u8]>`][NonNull] que compleix la mida i les garanties d'alineació de `layout`.
    ///
    /// El bloc retornat pot tenir una mida més gran que l'especificada per `layout.size()` i pot tenir el contingut inicialitzat o no.
    ///
    /// # Errors
    ///
    /// El retorn de `Err` indica que la memòria s'ha esgotat o que `layout` no compleix les restriccions de mida o d'alineació de l'assignador.
    ///
    /// Es recomana que les implementacions retornin `Err` en esgotar la memòria en lloc de prendre pànic o avortar, però no és un requisit estricte.
    /// (Concretament: és *legal* implementar aquest trait a la part superior d'una biblioteca d'assignació nativa subjacent que avorta en esgotar la memòria.)
    ///
    /// Es recomana als clients que desitgin avortar el càlcul en resposta a un error d'assignació a trucar a la funció [`handle_alloc_error`], en lloc d'invocar directament `panic!` o similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Es comporta com `allocate`, però també garanteix que la memòria retornada s'inicialitzi a zero.
    ///
    /// # Errors
    ///
    /// El retorn de `Err` indica que la memòria s'ha esgotat o que `layout` no compleix les restriccions de mida o d'alineació de l'assignador.
    ///
    /// Es recomana que les implementacions retornin `Err` en esgotar la memòria en lloc de prendre pànic o avortar, però no és un requisit estricte.
    /// (Concretament: és *legal* implementar aquest trait a la part superior d'una biblioteca d'assignació nativa subjacent que avorta en esgotar la memòria.)
    ///
    /// Es recomana als clients que desitgin avortar el càlcul en resposta a un error d'assignació a trucar a la funció [`handle_alloc_error`], en lloc d'invocar directament `panic!` o similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SEGURETAT: `alloc` retorna un bloc de memòria vàlid
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Distribueix la memòria a què fa referència `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` ha de denotar un bloc de memòria [*currently allocated*] mitjançant aquest assignador i
    /// * `layout` ha de [*fit*] aquest bloc de memòria.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Intenta ampliar el bloc de memòria.
    ///
    /// Retorna un nou [`NonNull<[u8]>`][NonNull] que conté un punter i la mida real de la memòria assignada.El punter és adequat per contenir les dades descrites per `new_layout`.
    /// Per aconseguir-ho, l'assignador pot ampliar l'assignació a què fa referència `ptr` per adaptar-se al nou disseny.
    ///
    /// Si torna `Ok`, la propietat del bloc de memòria a què fa referència `ptr` s'ha transferit a aquest assignador.
    /// És possible que la memòria s`hagi alliberat o no, i s`hauria de considerar inutilitzable tret que es tornés a transferir a la persona que truca mitjançant el valor de retorn d`aquest mètode.
    ///
    /// Si aquest mètode retorna `Err`, la propietat del bloc de memòria no s'ha transferit a aquest assignador i el contingut del bloc de memòria no es modifica.
    ///
    /// # Safety
    ///
    /// * `ptr` ha de denotar un bloc de memòria [*currently allocated*] mitjançant aquest assignador.
    /// * `old_layout` ha de ser [*fit*] aquest bloc de memòria (l'argument `new_layout` no cal que encaixi).
    /// * `new_layout.size()` ha de ser superior o igual a `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Retorna `Err` si el nou disseny no compleix les restriccions de mida i alineació de l'assignador, o si falla el creixement d'una altra manera.
    ///
    /// Es recomana que les implementacions retornin `Err` en esgotar la memòria en lloc de prendre pànic o avortar, però no és un requisit estricte.
    /// (Concretament: és *legal* implementar aquest trait a la part superior d'una biblioteca d'assignació nativa subjacent que avorta en esgotar la memòria.)
    ///
    /// Es recomana als clients que desitgin avortar el càlcul en resposta a un error d'assignació a trucar a la funció [`handle_alloc_error`], en lloc d'invocar directament `panic!` o similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SEGURETAT: perquè `new_layout.size()` ha de ser superior o igual a
        // `old_layout.size()`, tant l'assignació de memòria antiga com la nova són vàlides per a lectures i escriptures per a bytes `old_layout.size()`.
        // A més, com que l`assignació antiga encara no estava repartida, no es pot superposar a `new_ptr`.
        // Per tant, la trucada a `copy_nonoverlapping` és segura.
        // La persona que truca ha de confirmar el contracte de seguretat del `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Es comporta com `grow`, però també garanteix que els nous continguts es posin a zero abans de ser retornats.
    ///
    /// El bloc de memòria contindrà el contingut següent després d'una trucada correcta a
    /// `grow_zeroed`:
    ///   * Els bytes `0..old_layout.size()` es conserven de l'assignació original.
    ///   * Els bytes `old_layout.size()..old_size` es conservaran o es posaran a zero, en funció de la implementació de l`assignador.
    ///   `old_size` fa referència a la mida del bloc de memòria anterior a la trucada `grow_zeroed`, que pot ser més gran que la mida sol・licitada originalment quan es va assignar.
    ///   * Els bytes `old_size..new_size` es posen a zero.`new_size` fa referència a la mida del bloc de memòria retornat per la trucada `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` ha de denotar un bloc de memòria [*currently allocated*] mitjançant aquest assignador.
    /// * `old_layout` ha de ser [*fit*] aquest bloc de memòria (l'argument `new_layout` no cal que encaixi).
    /// * `new_layout.size()` ha de ser superior o igual a `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Retorna `Err` si el nou disseny no compleix les restriccions de mida i alineació de l'assignador, o si falla el creixement d'una altra manera.
    ///
    /// Es recomana que les implementacions retornin `Err` en esgotar la memòria en lloc de prendre pànic o avortar, però no és un requisit estricte.
    /// (Concretament: és *legal* implementar aquest trait a la part superior d'una biblioteca d'assignació nativa subjacent que avorta en esgotar la memòria.)
    ///
    /// Es recomana als clients que desitgin avortar el càlcul en resposta a un error d'assignació a trucar a la funció [`handle_alloc_error`], en lloc d'invocar directament `panic!` o similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SEGURETAT: perquè `new_layout.size()` ha de ser superior o igual a
        // `old_layout.size()`, tant l'assignació de memòria antiga com la nova són vàlides per a lectures i escriptures per a bytes `old_layout.size()`.
        // A més, com que l`assignació antiga encara no estava repartida, no es pot superposar a `new_ptr`.
        // Per tant, la trucada a `copy_nonoverlapping` és segura.
        // La persona que truca ha de confirmar el contracte de seguretat del `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Intenta reduir el bloc de memòria.
    ///
    /// Retorna un nou [`NonNull<[u8]>`][NonNull] que conté un punter i la mida real de la memòria assignada.El punter és adequat per contenir les dades descrites per `new_layout`.
    /// Per aconseguir-ho, l'assignador pot reduir l'assignació a què fa referència `ptr` per adaptar-la al nou disseny.
    ///
    /// Si torna `Ok`, la propietat del bloc de memòria a què fa referència `ptr` s'ha transferit a aquest assignador.
    /// És possible que la memòria s`hagi alliberat o no, i s`hauria de considerar inutilitzable tret que es tornés a transferir a la persona que truca mitjançant el valor de retorn d`aquest mètode.
    ///
    /// Si aquest mètode retorna `Err`, la propietat del bloc de memòria no s'ha transferit a aquest assignador i el contingut del bloc de memòria no es modifica.
    ///
    /// # Safety
    ///
    /// * `ptr` ha de denotar un bloc de memòria [*currently allocated*] mitjançant aquest assignador.
    /// * `old_layout` ha de ser [*fit*] aquest bloc de memòria (l'argument `new_layout` no cal que encaixi).
    /// * `new_layout.size()` ha de ser menor o igual a `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Retorna `Err` si el nou disseny no compleix les restriccions de mida i alineació de l'assignador, o si falla la reducció.
    ///
    /// Es recomana que les implementacions retornin `Err` en esgotar la memòria en lloc de prendre pànic o avortar, però no és un requisit estricte.
    /// (Concretament: és *legal* implementar aquest trait a la part superior d'una biblioteca d'assignació nativa subjacent que avorta en esgotar la memòria.)
    ///
    /// Es recomana als clients que desitgin avortar el càlcul en resposta a un error d'assignació a trucar a la funció [`handle_alloc_error`], en lloc d'invocar directament `panic!` o similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SEGURETAT: perquè `new_layout.size()` ha de ser inferior o igual a
        // `old_layout.size()`, tant l'assignació de memòria antiga com la nova són vàlides per a lectures i escriptures per a bytes `new_layout.size()`.
        // A més, com que l`assignació antiga encara no estava repartida, no es pot superposar a `new_ptr`.
        // Per tant, la trucada a `copy_nonoverlapping` és segura.
        // La persona que truca ha de confirmar el contracte de seguretat del `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Crea un adaptador "by reference" per a aquesta instància de `Allocator`.
    ///
    /// L'adaptador retornat també implementa `Allocator` i simplement ho demanarà en préstec.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SEGURETAT: el contractant de seguretat ha de ser confirmat per la persona que truca
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURETAT: el contractant de seguretat ha de ser confirmat per la persona que truca
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURETAT: el contractant de seguretat ha de ser confirmat per la persona que truca
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURETAT: el contractant de seguretat ha de ser confirmat per la persona que truca
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}