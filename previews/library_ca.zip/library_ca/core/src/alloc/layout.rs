use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Tot i que aquesta funció s'utilitza en un sol lloc i es podria incloure la seva implementació, els intents anteriors de fer-ho van fer que rustc fos més lent:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Disseny d'un bloc de memòria.
///
/// Una instància de `Layout` descriu un disseny particular de memòria.
/// Creeu un `Layout` com a entrada per donar a un assignador.
///
/// Tots els dissenys tenen una mida associada i una alineació de potència de dos.
///
/// (Tingueu en compte que els dissenys *no* són obligatoris per tenir una mida diferent de zero, tot i que `GlobalAlloc` requereix que totes les sol・licituds de memòria siguin de mida nul・la.
/// Una persona que truca ha de garantir que es compleixin condicions com aquesta, utilitzar assignadors específics amb requisits més solts o utilitzar la interfície `Allocator` més intel・ligent.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // mida del bloc de memòria sol・licitat, mesurat en bytes.
    size_: usize,

    // alineació del bloc de memòria sol・licitat, mesurat en bytes.
    // ens assegurem que sempre és una potència de dos, perquè les API com `posix_memalign` ho requereixen i és una restricció raonable imposar als constructors de disseny.
    //
    //
    // (Tanmateix, no requerim de manera anàloga `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Construeix un `Layout` a partir d'un determinat `size` i `align`, o retorna `LayoutError` si no es compleix alguna de les condicions següents:
    ///
    /// * `align` no ha de ser zero,
    ///
    /// * `align` ha de ser una potència de dos,
    ///
    /// * `size`, quan s'arrodoneix al múltiple més proper de `align`, no s'ha de desbordar (és a dir, el valor arrodonit ha de ser inferior o igual a `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (la potència de dos implica alinear!=0.)

        // La mida arrodonida és:
        //   size_rounded_up=(size + align, 1)&! (align, 1);
        //
        // Sabem des de dalt que s`alinea!=0.
        // Si afegir (alinear, 1) no desborda, arrodonir cap amunt estarà bé.
        //
        // Per contra,&-masking with! (Align, 1) només restarà bits d'ordre baix.
        // Per tant, si es produeix un desbordament amb la suma, la màscara&no pot restar prou per desfer aquest desbordament.
        //
        //
        // Més amunt implica que la comprovació del desbordament de sumacions és necessària i suficient.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SEGURETAT: les condicions per a `from_size_align_unchecked` han estat
        // comprovat més amunt.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Crea un disseny, ignorant totes les comprovacions.
    ///
    /// # Safety
    ///
    /// Aquesta funció no és segura ja que no verifica les condicions prèvies de [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SEGURETAT: la persona que truca ha de garantir que `align` sigui superior a zero.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// La mida mínima en bytes per a un bloc de memòria d`aquest disseny.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// L'alineació mínima de bytes per a un bloc de memòria d'aquest disseny.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Construeix un `Layout` adequat per mantenir un valor de tipus `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SEGURETAT: l'alineació està garantida per Rust per ser una potència de dos i
        // es garanteix que el combinat mida + alineació s`adapta al nostre espai d`adreces.
        // Com a resultat, utilitzeu el constructor no marcat aquí per evitar inserir codi que panics si no està prou optimitzat.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produeix un disseny que descriu un registre que es podria utilitzar per assignar l'estructura de suport per a `T` (que podria ser un trait o un altre tipus sense mida com una llesca).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SEGURETAT: consulteu els motius a `new` per saber per què s`utilitza la variant no segura
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produeix un disseny que descriu un registre que es podria utilitzar per assignar l'estructura de suport per a `T` (que podria ser un trait o un altre tipus sense mida com una llesca).
    ///
    /// # Safety
    ///
    /// Aquesta funció només es pot trucar amb seguretat si es compleixen les condicions següents:
    ///
    /// - Si `T` és `Sized`, sempre es pot trucar amb seguretat a aquesta funció.
    /// - Si la cua sense mida de `T` és:
    ///     - un [slice], llavors la longitud de la cua de tall ha de ser un enter intialitzat i la mida del *valor sencer*(longitud de la cua dinàmica + prefix de mida estàtica) ha de cabre a `isize`.
    ///     - un [trait object], llavors la part vtable del punter ha d`assenyalar una taula vtable vàlida per al tipus `T` adquirida per una coersió sense mida, i la mida del *valor sencer*(longitud de la cua dinàmica + prefix de mida estàtica) ha d`adaptar-se a `isize`.
    ///
    ///     - un (unstable) [extern type], llavors aquesta funció és sempre segura per trucar, però pot ser que panic o, de qualsevol altra manera, torni el valor incorrecte, ja que no es coneix el disseny del tipus extern.
    ///     Aquest és el mateix comportament que [`Layout::for_value`] en una referència a una cua de tipus extern.
    ///     - en cas contrari, no es permet conservar aquesta funció.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SEGURETAT: passem els requisits previs d`aquestes funcions a la persona que truca
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SEGURETAT: consulteu els motius a `new` per saber per què s`utilitza la variant no segura
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Crea un `NonNull` penjant, però ben alineat per a aquest disseny.
    ///
    /// Tingueu en compte que el valor del punter pot representar un punter vàlid, cosa que significa que no s'ha d'utilitzar com a valor sentinella "not yet initialized".
    /// Els tipus que s`assignen mandrosament han de fer un seguiment de la inicialització per altres mitjans.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SEGURETAT: es garanteix que l'alineament no és zero
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Crea un disseny que descriu el registre que pot contenir un valor del mateix disseny que `self`, però que també està alineat amb l'alineació `align` (mesurada en bytes).
    ///
    ///
    /// Si `self` ja compleix l'alineació prescrita, retorna `self`.
    ///
    /// Tingueu en compte que aquest mètode no afegeix cap farciment a la mida general, independentment de si el disseny retornat té un alineament diferent.
    /// En altres paraules, si `K` té la mida 16, `K.align_to(32)`*encara* tindrà la mida 16.
    ///
    /// Retorna un error si la combinació de `self.size()` i l `align` donat infringeix les condicions llistades a [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Retorna la quantitat de farciment que hem d'inserir després de `self` per assegurar-nos que l'adreça següent compleixi `align` (mesurada en bytes).
    ///
    /// per exemple, si `self.size()` és 9, llavors `self.padding_needed_for(4)` retorna 3, perquè aquest és el nombre mínim de bytes de farciment necessaris per obtenir una adreça de 4 alineats (suposant que el bloc de memòria corresponent comença en una adreça de 4 alineats).
    ///
    ///
    /// El valor retornat d`aquesta funció no té cap significat si `align` no és una potència de dos.
    ///
    /// Tingueu en compte que la utilitat del valor retornat requereix que `align` sigui inferior o igual a l'alineació de l'adreça inicial per a tot el bloc de memòria assignat.Una manera de satisfer aquesta restricció és assegurar el `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // El valor arrodonit és:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // i després retornem la diferència de farciment: `len_rounded_up - len`.
        //
        // Utilitzem aritmètica modular a tot:
        //
        // 1. align està garantit que és> 0, de manera que align, 1 sempre és vàlid.
        //
        // 2.
        // `len + align - 1` es pot desbordar com a màxim `align - 1`, de manera que la màscara&amb `!(align - 1)` assegurarà que, en cas de desbordament, `len_rounded_up` serà 0.
        //
        //    Així, el farciment retornat, quan s`afegeix a `len`, produeix 0, que satisfà trivialment l`alineació `align`.
        //
        // (Per descomptat, els intents d`assignar blocs de memòria que tinguin una mida i un desbordament de farciment de la manera anterior haurien de fer que l`assignador produeixi un error de totes maneres.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Crea un disseny arrodonint la mida d'aquest disseny fins a un múltiple de l'alineació del disseny.
    ///
    ///
    /// Això equival a afegir el resultat de `padding_needed_for` a la mida actual del disseny.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Això no es pot desbordar.Citant la invariant del disseny:
        // > `size`, quan s'arrodoneix al múltiple més proper de `align`,
        // > no s'ha de desbordar (és a dir, el valor arrodonit ha de ser inferior a
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Crea un disseny que descriu el registre de les instàncies `n` de `self`, amb una quantitat adequada de farciment entre cadascuna per assegurar-se que cada instància tingui la mida i l'alineació sol・licitades.
    /// Si té èxit, retorna `(k, offs)` on `k` és el disseny de la matriu i `offs` és la distància entre l'inici de cada element de la matriu.
    ///
    /// En cas de desbordament aritmètic, retorna `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Això no es pot desbordar.Citant la invariant del disseny:
        // > `size`, quan s'arrodoneix al múltiple més proper de `align`,
        // > no s'ha de desbordar (és a dir, el valor arrodonit ha de ser inferior a
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SEGURETAT: self.align ja se sap que és vàlid i alloc_size ho ha estat
        // encoixinat ja.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Crea un disseny que descriu el registre de `self` seguit de `next`, incloent qualsevol farciment necessari per assegurar-se que `next` estarà correctament alineat, però *no hi ha farciment final*.
    ///
    /// Per fer coincidir el disseny de representació C `repr(C)`, haureu de trucar a `pad_to_align` després d`ampliar el disseny amb tots els camps.
    /// (No hi ha manera de coincidir amb el disseny de representació Rust per defecte `repr(Rust)`, as it is unspecified.)
    ///
    /// Tingueu en compte que l`alineació del disseny resultant serà la màxima de les de `self` i `next`, per tal d`assegurar l`alineació d`ambdues parts.
    ///
    /// Retorna `Ok((k, offset))`, on `k` és el disseny del registre concatenat i `offset` és la ubicació relativa, en bytes, de l'inici del `next` incrustat dins del registre concatenat (suposant que el registre mateix comença amb el desplaçament 0).
    ///
    ///
    /// En cas de desbordament aritmètic, retorna `LayoutError`.
    ///
    /// # Examples
    ///
    /// Per calcular el disseny d'una estructura `#[repr(C)]` i els desplaçaments dels camps a partir dels dissenys dels seus camps:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Recordeu finalitzar amb `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // prova que funciona
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Crea un disseny que descriu el registre de les instàncies `n` de `self`, sense cap farciment entre cada instància.
    ///
    /// Tingueu en compte que, a diferència de `repeat`, `repeat_packed` no garanteix que les instàncies repetides de `self` estiguin correctament alineades, fins i tot si una instància determinada de `self` està correctament alineada.
    /// En altres paraules, si el disseny retornat per `repeat_packed` s'utilitza per assignar una matriu, no es garanteix que tots els elements de la matriu estiguin alineats correctament.
    ///
    /// En cas de desbordament aritmètic, retorna `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Crea un disseny que descriu el registre de `self` seguit de `next` sense farciment addicional entre els dos.
    /// Com que no s'insereix cap farciment, l'alineació de `next` és irrellevant i no s'incorpora *en absolut* al disseny resultant.
    ///
    ///
    /// En cas de desbordament aritmètic, retorna `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Crea un disseny que descriu el registre d'un `[T; n]`.
    ///
    /// En cas de desbordament aritmètic, retorna `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Els paràmetres donats a `Layout::from_size_align` o a algun altre constructor `Layout` no compleixen les seves limitacions documentades.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (ho necessitem per a la implementació posterior de l'error trait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}