use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Un assignador de memòria que es pot registrar com a predeterminat de la biblioteca estàndard mitjançant l'atribut `#[global_allocator]`.
///
/// Alguns dels mètodes requereixen que un bloc de memòria estigui *assignat actualment* mitjançant un assignador.Això significa que:
///
/// * anteriorment, una trucada anterior va retornar l'adreça inicial d'aquest bloc de memòria a un mètode d'assignació com `alloc` i
///
/// * el bloc de memòria no s'ha deslocalitzat posteriorment, on els blocs es reparteixen ja sigui passant-se a un mètode de repartiment com `dealloc` o passant-se a un mètode de reassignació que retorna un punter que no és nul.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// El `GlobalAlloc` trait és un `unsafe` trait per diversos motius i els implementadors han de garantir que compleixin aquests contractes:
///
/// * És un comportament indefinit si es desenrotllen els assignadors globals.Aquesta restricció es pot retirar a future, però actualment un panic de qualsevol d'aquestes funcions pot provocar inseguretat en la memòria.
///
/// * `Layout` les consultes i els càlculs en general han de ser correctes.Les persones que truquen a aquest trait poden confiar en els contractes definits en cada mètode i els implementadors han de garantir que aquests contractes siguin certs.
///
/// * És possible que no confieu en les assignacions realment realitzades, fins i tot si hi ha assignacions de pila explícites a la font.
/// L'optimitzador pot detectar assignacions no utilitzades que pot eliminar completament o passar a la pila i, per tant, mai invocar l'assignador.
/// L'optimitzador pot suposar a més que l'assignació és infal・lible, de manera que el codi que solia fallar a causa de fallades de l'assignador ara pot funcionar de sobte perquè l'optimitzador treballava en funció de la necessitat d'una assignació.
/// Més concretament, l'exemple de codi següent no és correcte, independentment de si el vostre assignador personalitzat permet comptar quantes assignacions han passat.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Tingueu en compte que les optimitzacions esmentades anteriorment no són l'única que es pot aplicar.Generalment, pot no confiar en que es produeixin assignacions de pila si es poden eliminar sense canviar el comportament del programa.
///   Si les assignacions es produeixen o no, no forma part del comportament del programa, fins i tot si es podria detectar mitjançant un assignador que fa un seguiment de les assignacions mitjançant la impressió o que tingui efectes secundaris.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Assigneu la memòria tal com es descriu al `layout` donat.
    ///
    /// Retorna un punter a la memòria recentment assignada o nul per indicar un error d'assignació.
    ///
    /// # Safety
    ///
    /// Aquesta funció no és segura perquè es pot produir un comportament indefinit si la persona que truca no assegura que `layout` tingui una mida diferent de zero.
    ///
    /// (Els subtraits d'extensió poden proporcionar límits més específics al comportament, per exemple, garantir una adreça sentinella o un punter nul en resposta a una sol・licitud d'assignació de mida zero).
    ///
    /// Es pot inicialitzar o no el bloc de memòria assignat.
    ///
    /// # Errors
    ///
    /// Retornar un punter nul indica que la memòria s'ha esgotat o que `layout` no compleix les restriccions de mida o d'alineació d'aquest assignador.
    ///
    /// Es recomana a les implementacions que tornin nul・les en esgotar la memòria en lloc d`avortar, però no és un requisit estricte.
    /// (Concretament: és *legal* implementar aquest trait a la part superior d'una biblioteca d'assignació nativa subjacent que avorta en esgotar la memòria.)
    ///
    /// Es recomana als clients que desitgin avortar el càlcul en resposta a un error d'assignació a trucar a la funció [`handle_alloc_error`], en lloc d'invocar directament `panic!` o similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Repartiu el bloc de memòria al punter `ptr` donat amb el `layout` donat.
    ///
    /// # Safety
    ///
    /// Aquesta funció no és segura perquè es pot produir un comportament no definit si la persona que truca no garanteix tot el següent:
    ///
    ///
    /// * `ptr` ha de denotar un bloc de memòria assignat actualment mitjançant aquest assignador,
    ///
    /// * `layout` ha de ser el mateix disseny que es va utilitzar per assignar aquest bloc de memòria.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Es comporta com `alloc`, però també garanteix que el contingut es posi a zero abans de tornar.
    ///
    /// # Safety
    ///
    /// Aquesta funció no és segura pels mateixos motius que el `alloc`.
    /// Tanmateix, es garanteix que el bloc assignat de memòria serà inicialitzat.
    ///
    /// # Errors
    ///
    /// Retornar un punter nul indica que la memòria s'ha esgotat o que `layout` no compleix les restriccions de mida o d'alineació de l'assignador, igual que a `alloc`.
    ///
    /// Es recomana als clients que desitgin avortar el càlcul en resposta a un error d'assignació a trucar a la funció [`handle_alloc_error`], en lloc d'invocar directament `panic!` o similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SEGURETAT: el contractant de seguretat per a `alloc` ha de ser confirmat per la persona que truca.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SEGURETAT: a mesura que s'ha assignat correctament, la regió des de `ptr`
            // de mida `size` es garanteix que serà vàlid per a escriptures.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Redueix o fa créixer un bloc de memòria fins al `new_size` donat.
    /// El bloc està descrit pel punter `ptr` i `layout` donats.
    ///
    /// Si això retorna un punter que no és nul, la propietat del bloc de memòria a què fa referència `ptr` s'ha transferit a aquest assignador.
    /// És possible que la memòria s`hagi repartit o no, i s`hauria de considerar inutilitzable (tret que, per descomptat, es tornés a transferir a la persona que truca mitjançant el valor de retorn d`aquest mètode).
    /// El nou bloc de memòria s`assigna amb `layout`, però amb l `size` actualitzat a `new_size`.
    /// Aquest nou disseny s'hauria d'utilitzar quan es repartís el nou bloc de memòria amb `dealloc`.
    /// Es garanteix que l'interval `0..min(layout.size(), new_size) del nou bloc de memòria tindrà els mateixos valors que el bloc original.
    ///
    /// Si aquest mètode torna nul, la propietat del bloc de memòria no s'ha transferit a aquest assignador i el contingut del bloc de memòria no es modifica.
    ///
    /// # Safety
    ///
    /// Aquesta funció no és segura perquè es pot produir un comportament no definit si la persona que truca no garanteix tot el següent:
    ///
    /// * `ptr` s'ha d'assignar actualment mitjançant aquest assignador,
    ///
    /// * `layout` ha de ser el mateix disseny que es va utilitzar per assignar aquest bloc de memòria,
    ///
    /// * `new_size` ha de ser superior a zero.
    ///
    /// * `new_size`, quan s'arrodoneix al múltiple més proper de `layout.align()`, no s'ha de desbordar (és a dir, el valor arrodonit ha de ser inferior a `usize::MAX`).
    ///
    /// (Els subtraits d'extensió poden proporcionar límits més específics al comportament, per exemple, garantir una adreça sentinella o un punter nul en resposta a una sol・licitud d'assignació de mida zero).
    ///
    /// # Errors
    ///
    /// Retorna nul si el nou disseny no compleix les restriccions de mida i alineació de l'assignador o si falla la reassignació.
    ///
    /// Es recomana a les implementacions que tornin nul・les en esgotar la memòria en lloc de prendre pànic o avortar, però no és un requisit estricte.
    /// (Concretament: és *legal* implementar aquest trait a la part superior d'una biblioteca d'assignació nativa subjacent que avorta en esgotar la memòria.)
    ///
    /// Es recomana als clients que desitgin avortar el càlcul en resposta a un error de reassignació a trucar a la funció [`handle_alloc_error`], en lloc d'invocar directament `panic!` o similar.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SEGURETAT: la persona que truca ha de garantir que el `new_size` no es desbordi.
        // `layout.align()` prové d'un `Layout` i, per tant, es garanteix que és vàlid.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SEGURETAT: la persona que truca ha de garantir que `new_layout` sigui superior a zero.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SEGURETAT: el bloc assignat anteriorment no pot superposar-se al nou bloc assignat.
            // La persona que truca ha de confirmar el contracte de seguretat del `dealloc`.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}