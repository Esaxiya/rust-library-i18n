#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// Un `RawWaker` permet a l`implementador d`un executor de tasques crear un [`Waker`] que proporciona un comportament de despertador personalitzat.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Consisteix en un punter de dades i un [virtual function pointer table (vtable)][vtable] que personalitza el comportament del `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Un indicador de dades, que es pot utilitzar per emmagatzemar dades arbitràries segons el requeriment de l'executor.
    /// Això podria ser, per exemple
    /// un punter esborrat de tipus a un `Arc` associat a la tasca.
    /// El valor d'aquest camp es passa a totes les funcions que formen part del vtable com a primer paràmetre.
    ///
    data: *const (),
    /// Taula de punter de funció virtual que personalitza el comportament d`aquest waker.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Crea un nou `RawWaker` a partir del punter `data` i `vtable` proporcionats.
    ///
    /// El punter `data` es pot utilitzar per emmagatzemar dades arbitràries segons el requeriment de l'executor.Això podria ser, per exemple
    /// un punter esborrat de tipus a un `Arc` associat a la tasca.
    /// El valor d'aquest punter es passarà a totes les funcions que formen part del `vtable` com a primer paràmetre.
    ///
    /// El `vtable` personalitza el comportament d'un `Waker` que es crea a partir d'un `RawWaker`.
    /// Per a cada operació del `Waker`, es cridarà la funció associada al `vtable` del `RawWaker` subjacent.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Una taula de punter de funció virtual (vtable) que especifica el comportament d'un [`RawWaker`].
///
/// El punter que es passa a totes les funcions de la taula vtable és el punter `data` de l'objecte [`RawWaker`] adjunt.
///
/// Les funcions dins d'aquesta estructura només es pretenen cridar al punter `data` d'un objecte [`RawWaker`] construït correctament des de la implementació [`RawWaker`].
/// Cridar una de les funcions contingudes mitjançant qualsevol altre punter `data` provocarà un comportament indefinit.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Aquesta funció es cridarà quan es cloni l [`RawWaker`], per exemple, quan es cloni l [`Waker`] en què s'emmagatzema l [`RawWaker`].
    ///
    /// La implementació d'aquesta funció ha de conservar tots els recursos necessaris per a aquesta instància addicional d'un [`RawWaker`] i la tasca associada.
    /// Cridar a `wake` al [`RawWaker`] resultant hauria de provocar un despert de la mateixa tasca que l [`RawWaker`] original hauria despertat.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Aquesta funció es cridarà quan es cridi `wake` a l [`Waker`].
    /// Ha de despertar la tasca associada a aquest [`RawWaker`].
    ///
    /// La implementació d'aquesta funció ha d'assegurar-se d'alliberar els recursos associats a aquesta instància d'un [`RawWaker`] i a la tasca associada.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Aquesta funció es cridarà quan es cridi `wake_by_ref` a l [`Waker`].
    /// Ha de despertar la tasca associada a aquest [`RawWaker`].
    ///
    /// Aquesta funció és similar a `wake`, però no ha de consumir el punter de dades proporcionat.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Aquesta funció es crida quan es deixa caure un [`RawWaker`].
    ///
    /// La implementació d'aquesta funció ha d'assegurar-se d'alliberar els recursos associats a aquesta instància d'un [`RawWaker`] i a la tasca associada.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Crea un nou `RawWakerVTable` a partir de les funcions `clone`, `wake`, `wake_by_ref` i `drop` proporcionades.
    ///
    /// # `clone`
    ///
    /// Aquesta funció es cridarà quan es cloni l [`RawWaker`], per exemple, quan es cloni l [`Waker`] en què s'emmagatzema l [`RawWaker`].
    ///
    /// La implementació d'aquesta funció ha de conservar tots els recursos necessaris per a aquesta instància addicional d'un [`RawWaker`] i la tasca associada.
    /// Cridar a `wake` al [`RawWaker`] resultant hauria de provocar un despert de la mateixa tasca que l [`RawWaker`] original hauria despertat.
    ///
    /// # `wake`
    ///
    /// Aquesta funció es cridarà quan es cridi `wake` a l [`Waker`].
    /// Ha de despertar la tasca associada a aquest [`RawWaker`].
    ///
    /// La implementació d'aquesta funció ha d'assegurar-se d'alliberar els recursos associats a aquesta instància d'un [`RawWaker`] i a la tasca associada.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Aquesta funció es cridarà quan es cridi `wake_by_ref` a l [`Waker`].
    /// Ha de despertar la tasca associada a aquest [`RawWaker`].
    ///
    /// Aquesta funció és similar a `wake`, però no ha de consumir el punter de dades proporcionat.
    ///
    /// # `drop`
    ///
    /// Aquesta funció es crida quan es deixa caure un [`RawWaker`].
    ///
    /// La implementació d'aquesta funció ha d'assegurar-se d'alliberar els recursos associats a aquesta instància d'un [`RawWaker`] i a la tasca associada.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// El `Context` d'una tasca asíncrona.
///
/// Actualment, `Context` només serveix per proporcionar accés a un `&Waker` que es pot utilitzar per activar la tasca actual.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Assegureu-vos que la prova future contra els canvis de la variància força la vida invariant (les vides de la posició de l`argument són contravariants mentre que les de la posició de retorn són covariantes).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Creeu un `Context` nou des d'un `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Retorna una referència al `Waker` per a la tasca actual.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// Un `Waker` és un gestor per despertar una tasca notificant al seu executor que està preparat per executar-se.
///
/// Aquest identificador encapsula una instància [`RawWaker`], que defineix el comportament de despertador específic de l'executor.
///
///
/// Implementa [`Clone`], [`Send`] i [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Desactiveu la tasca associada a aquest `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // La trucada de despertat real es delega mitjançant una trucada de funció virtual a la implementació definida per l'executor.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // No truqueu al `drop`: el waker serà consumit per `wake`.
        crate::mem::forget(self);

        // SEGURETAT: això és segur perquè `Waker::from_raw` és l'única manera
        // inicialitzar `wake` i `data` que requereixin que l'usuari reconegui que el contracte de `RawWaker` es manté.
        //
        unsafe { (wake)(data) };
    }

    /// Desactiveu la tasca associada a aquest `Waker` sense consumir el `Waker`.
    ///
    /// Això és similar al `wake`, però pot ser una mica menys eficient en el cas que estigui disponible un `Waker` propietat.
    /// S`ha de preferir aquest mètode a trucar al `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // La trucada de despertat real es delega mitjançant una trucada de funció virtual a la implementació definida per l'executor.
        //

        // SEGURETAT: vegeu `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Retorna `true` si aquest `Waker` i un altre `Waker` han despertat la mateixa tasca.
    ///
    /// Aquesta funció funciona sobre la base del millor esforç i pot ser falsa fins i tot quan els `Waker` despertarien la mateixa tasca.
    /// Tanmateix, si aquesta funció retorna `true`, es garanteix que el `Waker` despertarà la mateixa tasca.
    ///
    /// Aquesta funció s'utilitza principalment amb finalitats d'optimització.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Crea un nou `Waker` a partir de [`RawWaker`].
    ///
    /// El comportament del `Waker` retornat no està definit si no es manté el contracte definit a la documentació de [`RawWaker`] i [`RawWakerVTable`].
    ///
    /// Per tant, aquest mètode no és segur.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SEGURETAT: això és segur perquè `Waker::from_raw` és l'única manera
            // inicialitzar `clone` i `data` que requereixin que l'usuari reconegui que el contracte de [`RawWaker`] es manté.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SEGURETAT: això és segur perquè `Waker::from_raw` és l'única manera
        // inicialitzar `drop` i `data` que requereixin que l'usuari reconegui que el contracte de `RawWaker` es manté.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}