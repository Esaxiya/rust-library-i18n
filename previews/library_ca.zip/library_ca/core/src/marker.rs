//! traits primitiu i tipus que representen propietats bàsiques dels tipus.
//!
//! Els tipus Rust es poden classificar de diverses maneres útils segons les seves propietats intrínseques.
//! Aquestes classificacions es representen com a traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Tipus que es poden transferir a través dels límits del fil.
///
/// Aquest trait s'implementa automàticament quan el compilador determina que és adequat.
///
/// Un exemple d'un tipus que no és "Envia" és el punter [`rc::Rc`][`Rc`] de recompte de referències.
/// Si dos fils intenten clonar [`Rc`] que apunten al mateix valor de referència comptada, podrien intentar actualitzar el recompte de referència al mateix temps, que és [undefined behavior][ub] perquè [`Rc`] no utilitza operacions atòmiques.
///
/// El seu cosí [`sync::Arc`][arc] utilitza operacions atòmiques (incorrent en despeses generals) i, per tant, és `Send`.
///
/// Consulteu [the Nomicon](../../nomicon/send-and-sync.html) per obtenir més detalls.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Tipus amb una mida constant coneguda en el moment de la compilació.
///
/// Tots els paràmetres de tipus tenen un límit implícit de `Sized`.La sintaxi especial `?Sized` es pot utilitzar per eliminar aquest límit si no és adequat.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//error: la mida no està implementada per a [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// L'única excepció és el tipus implícit `Self` d'un trait.
/// Un trait no té un límit `Sized` implícit ja que és incompatible amb [objecte trait] on, per definició, el trait necessita treballar amb tots els implementadors possibles i, per tant, podria tenir qualsevol mida.
///
///
/// Tot i que Rust us permetrà vincular `Sized` a un trait, no el podreu utilitzar per formar un objecte trait més endavant:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // deixem y: &dyn Barra= &Impl;//error: el trait `Bar` no es pot convertir en un objecte
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // per defecte, per exemple, que requereix que `[T]: !Default` sigui avaluable
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Tipus que poden ser "unsized" a un tipus de mida dinàmica.
///
/// Per exemple, el tipus de matriu de mida `[i8; 2]` implementa `Unsize<[i8]>` i `Unsize<dyn fmt::Debug>`.
///
/// Totes les implementacions de `Unsize` són proporcionades automàticament pel compilador.
///
/// `Unsize` està implementat per a:
///
/// - `[T; N]` és `Unsize<[T]>`
/// - `T` és `Unsize<dyn Trait>` quan `T: Trait`
/// - `Foo<..., T, ...>` és `Unsize<Foo<..., U, ...>>` si:
///   - `T: Unsize<U>`
///   - Foo és una estructura
///   - Només l'últim camp de `Foo` té un tipus que inclou `T`
///   - `T` no forma part del tipus de cap altre camp
///   - `Bar<T>: Unsize<Bar<U>>`, si l'últim camp de `Foo` té el tipus `Bar<T>`
///
/// `Unsize` s'utilitza juntament amb [`ops::CoerceUnsized`] per permetre que els contenidors "user-defined" com [`Rc`] continguin tipus de mida dinàmica.
/// Consulteu [DST coercion RFC][RFC982] i [the nomicon entry on coercion][nomicon-coerce] per obtenir més informació.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// trait obligatori per a les constants que s`utilitzen en les coincidències de patrons.
///
/// Qualsevol tipus que derivi `PartialEq` implementa automàticament aquest trait,*independentment* de si els seus paràmetres tipus implementen `Eq`.
///
/// Si un element `const` conté algun tipus que no implementa aquest trait, llavors aquest tipus (1.) no implementa `PartialEq` (el que significa que la constant no proporcionarà aquest mètode de comparació, que la generació de codi suposa que està disponible), o bé (2.) implementa *el seu propi* versió de `PartialEq` (que suposem que no s'ajusta a una comparació d'igualtat estructural).
///
///
/// En qualsevol dels dos escenaris anteriors, rebutgem l'ús d'aquesta constant en una concordança de patrons.
///
/// Vegeu també [structural match RFC][RFC1445] i [issue 63438] que van motivar la migració del disseny basat en atributs a aquest trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// trait obligatori per a les constants que s`utilitzen en les coincidències de patrons.
///
/// Qualsevol tipus que derivi `Eq` implementa automàticament aquest trait,*independentment* de si els seus paràmetres de tipus implementen `Eq`.
///
/// Es tracta d`un hack per solucionar una limitació del nostre sistema de tipus.
///
/// # Background
///
/// Volem exigir que els tipus de constants que s`utilitzen en les coincidències de patrons tinguin l`atribut `#[derive(PartialEq, Eq)]`.
///
/// En un món més ideal, podríem comprovar aquest requisit comprovant només que el tipus donat implementa tant el `StructuralPartialEq` trait *com* el `Eq` trait.
/// Tanmateix, podeu tenir ADT * ** `derive(PartialEq, Eq)` i ser un cas que vulguem que el compilador accepti, tot i que el tipus de constant no implementa `Eq`.
///
/// És a dir, un cas com aquest:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (El problema del codi anterior és que `Wrap<fn(&())>` no implementa `PartialEq` ni `Eq`, perquè `per <'a> fn(&'a _)` does not implement those traits.)
///
/// Per tant, no podem confiar en la comprovació ingènua de `StructuralPartialEq` i només de `Eq`.
///
/// Com a problema per solucionar-ho, fem servir dos traits injectats per cadascun dels dos derivats (`#[derive(PartialEq)]` i `#[derive(Eq)]`) i comprovem que tots dos estiguin presents com a part de la comprovació de la concordança estructural.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Tipus els valors dels quals es poden duplicar simplement copiant bits.
///
/// Per defecte, els enllaços variables tenen "moure semàntica".En altres paraules:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` s'ha mogut a `y` i, per tant, no es pot utilitzar
///
/// // println! ("{: ?}", x);//error: ús del valor mogut
/// ```
///
/// Tanmateix, si un tipus implementa `Copy`, en canvi té "semàntica de còpia":
///
/// ```
/// // Podem obtenir una implementació `Copy`.
/// // `Clone` també és obligatori, ja que és un superretrat de `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` és una còpia de `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// És important tenir en compte que en aquests dos exemples, l'única diferència és si es pot accedir a `x` després de l'assignació.
/// Sota el capó, tant una còpia com un moviment poden provocar que es copiïn bits a la memòria, tot i que de vegades s`optimitza.
///
/// ## Com puc implementar `Copy`?
///
/// Hi ha dues maneres d'implementar `Copy` al vostre tipus.El més senzill és utilitzar `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// També podeu implementar `Copy` i `Clone` manualment:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Hi ha una petita diferència entre ambdues: l`estratègia `derive` també col・locarà un `Copy` lligat a paràmetres de tipus, cosa que no sempre es desitja.
///
/// ## Quina diferència hi ha entre `Copy` i `Clone`?
///
/// Les còpies es produeixen de manera implícita, per exemple com a part d'una tasca `y = x`.El comportament de `Copy` no és sobrecarregable;sempre és una còpia senzilla i senzilla.
///
/// La clonació és una acció explícita, `x.clone()`.La implementació de [`Clone`] pot proporcionar qualsevol comportament específic de tipus necessari per duplicar valors de forma segura.
/// Per exemple, la implementació de [`Clone`] per a [`String`] necessita copiar la memòria intermèdia de cadena apuntada a l'emmagatzematge dinàmic.
/// Una simple còpia a bit de bits dels valors [`String`] només copiaria el punter, cosa que donarà lloc a una doble lliure.
/// Per aquest motiu, [`String`] és [`Clone`] però no `Copy`.
///
/// [`Clone`] és un superretrat de `Copy`, de manera que tot el que sigui `Copy` també ha d'implementar [`Clone`].
/// Si un tipus és `Copy`, la seva implementació [`Clone`] només ha de retornar `*self` (vegeu l'exemple anterior).
///
/// ## Quan el meu tipus pot ser `Copy`?
///
/// Un tipus pot implementar `Copy` si tots els seus components implementen `Copy`.Per exemple, aquesta estructura pot ser `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Una estructura pot ser `Copy` i [`i32`] és `Copy`, per tant `Point` és elegible per ser `Copy`.
/// Per contra, tingueu en compte
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// L'estructura `PointList` no pot implementar `Copy`, perquè [`Vec<T>`] no és `Copy`.Si intentem obtenir una implementació `Copy`, obtindrem un error:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Les referències compartides (`&T`) també són `Copy`, de manera que un tipus pot ser `Copy`, fins i tot quan conté referències compartides de tipus `T` que no són * `Copy`.
/// Penseu en la següent estructura, que pot implementar `Copy`, perquè només conté una *referència compartida* al nostre tipus que no és "Copia" `PointList` des de dalt:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Quan *no* el meu tipus pot ser `Copy`?
///
/// Alguns tipus no es poden copiar amb seguretat.Per exemple, copiar `&mut T` crearia una referència mutable aliat.
/// La còpia de [`String`] duplicaria la responsabilitat de gestionar la memòria intermèdia de [[String]], donant lloc a un doble lliure.
///
/// Generalitzant aquest últim cas, qualsevol tipus que implementi [`Drop`] no pot ser `Copy`, ja que gestiona alguns recursos a més dels seus propis bytes [`size_of::<T>`].
///
/// Si intenteu implementar `Copy` en una estructura o enum que contingui dades que no siguin "Copiar", obtindreu l'error [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Quan *el meu tipus* ha de ser `Copy`?
///
/// En general, si el vostre tipus _can_ implementa `Copy`, hauria de ser-ho.
/// Tingueu en compte, però, que la implementació de `Copy` forma part de l'API pública del vostre tipus.
/// Si el tipus pot no ser "Copia" a future, pot ser prudent ometre la implementació `Copy` ara, per evitar un canvi d'API trencador.
///
/// ## Implementadors addicionals
///
/// A més de l [implementors listed below][impls], els tipus següents també implementen `Copy`:
///
/// * Tipus d'elements de funció (és a dir, els diferents tipus definits per a cada funció)
/// * Tipus de punter de funció (per exemple, `fn() -> i32`)
/// * Tipus de matriu, per a totes les mides, si el tipus d`element també implementa `Copy` (per exemple, `[i32; 123456]`)
/// * Tipus de tuples, si cada component també implementa `Copy` (per exemple, `()`, `(i32, bool)`)
/// * Tipus de tancament, si no capturen cap valor de l`entorn o si tots aquests valors capturats implementen `Copy` ells mateixos.
///   Tingueu en compte que les variables capturades per referència compartida sempre implementen `Copy` (fins i tot si el referent no ho fa), mentre que les variables capturades per referència mutable mai implementen `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Això permet copiar un tipus que no implementi `Copy` a causa de límits de vida insatisfets (copiar `A<'_>` quan només `A<'static>: Copy` i `A<'_>: Clone`).
// Tenim aquest atribut aquí de moment només perquè hi ha força especialitzacions existents a `Copy` que ja existeixen a la biblioteca estàndard i no hi ha manera de tenir aquest comportament amb seguretat ara mateix.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Deriveu macro que genera un impl del trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Tipus per als quals és segur compartir referències entre fils.
///
/// Aquest trait s'implementa automàticament quan el compilador determina que és adequat.
///
/// La definició precisa és: un tipus `T` és [`Sync`] si i només si `&T` és [`Send`].
/// Dit d`una altra manera, si no hi ha possibilitat de [undefined behavior][ub] (incloses les curses de dades) en passar referències `&T` entre fils.
///
/// Com seria d`esperar, els tipus primitius com [`u8`] i [`f64`] són tots [`Sync`], i també ho són els tipus d`agregats simples que els contenen, com tuples, estructures i enums.
/// Altres exemples de tipus bàsics [`Sync`] inclouen tipus "immutable" com `&T` i aquells amb mutabilitat heretada simple, com ara [`Box<T>`][box], [`Vec<T>`][vec] i la majoria dels altres tipus de col・lecció.
///
/// (Els paràmetres genèrics han de ser [`Sync`] perquè el contenidor sigui ["Sincronitza").
///
/// Una conseqüència una mica sorprenent de la definició és que `&mut T` és `Sync` (si `T` és `Sync`) tot i que sembla que podria proporcionar una mutació no sincronitzada.
/// El truc és que una referència mutable darrere d`una referència compartida (és a dir, `& &mut T`) es converteix en només de lectura, com si es tractés d`un `& &T`.
/// Per tant, no hi ha risc de cursa de dades.
///
/// Els tipus que no són `Sync` són aquells que tenen "interior mutability" en un format que no és apte per a fils, com ara [`Cell`][cell] i [`RefCell`][refcell].
/// Aquests tipus permeten la mutació del seu contingut fins i tot mitjançant una referència compartida i immutable.
/// Per exemple, el mètode `set` a [`Cell<T>`][cell] pren `&self`, de manera que només requereix una referència compartida [`&Cell<T>`][cell].
/// El mètode no realitza cap sincronització, de manera que [`Cell`][cell] no pot ser `Sync`.
///
/// Un altre exemple d'un tipus que no és "Sync" és el punter [`Rc`][rc] per al recompte de referències.
/// Tenint en compte qualsevol referència [`&Rc<T>`][rc], podeu clonar un nou [`Rc<T>`][rc], modificant els recomptes de referència de manera no atòmica.
///
/// Per als casos en què es necessiti una mutabilitat interior segura per a fils, Rust proporciona [atomic data types], a més de bloqueig explícit mitjançant [`sync::Mutex`][mutex] i [`sync::RwLock`][rwlock].
/// Aquests tipus garanteixen que qualsevol mutació no pugui causar curses de dades, per tant els tipus són `Sync`.
/// De la mateixa manera, [`sync::Arc`][arc] proporciona un analògic segur de fils de [`Rc`][rc].
///
/// Qualsevol tipus amb mutabilitat interior també ha d'utilitzar l'embolcall [`cell::UnsafeCell`][unsafecell] al voltant de l value(s) que es pot mutar mitjançant una referència compartida.
/// No fer això és [undefined behavior][ub].
/// Per exemple, ["transmutar"][transmutar]-ing de `&T` a `&mut T` no és vàlid.
///
/// Consulteu [the Nomicon][nomicon-send-and-sync] per obtenir més informació sobre `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): un cop el suport per afegir notes a `rustc_on_unimplemented` es posa en versió beta, i s'ha ampliat per comprovar si hi ha un tancament en qualsevol lloc de la cadena de requisits, amplieu-lo com a tal (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Tipus de mida zero que s'utilitza per marcar les coses que tenen un "act like" i que posseeixen un `T`.
///
/// Si afegiu un camp `PhantomData<T>` al vostre tipus, el compilador indica que el vostre tipus actua com si emmagatzemés un valor del tipus `T`, encara que realment no ho faci.
/// Aquesta informació s'utilitza quan es calculen determinades propietats de seguretat.
///
/// Per obtenir una explicació més profunda sobre com utilitzar `PhantomData<T>`, consulteu [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Una nota espantosa 👻👻👻
///
/// Tot i que tots dos tenen noms espantosos, `PhantomData` i "tipus fantasma" estan relacionats, però no són idèntics.Un paràmetre de tipus fantasma és simplement un paràmetre de tipus que no s`utilitza mai.
/// A Rust, sovint això fa que el compilador es queixa i la solució és afegir un ús de "dummy" mitjançant `PhantomData`.
///
/// # Examples
///
/// ## Paràmetres de vida útil no utilitzats
///
/// Potser el cas d'ús més comú de `PhantomData` és una estructura que té un paràmetre de vida inutilitzat, normalment com a part d'algun codi no segur.
/// Per exemple, aquí hi ha una estructura `Slice` que té dos indicadors de tipus `*const T`, que presumiblement apunten a una matriu en algun lloc:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// La intenció és que les dades subjacents només siguin vàlides durant tota la vida de `'a`, de manera que `Slice` no hauria de sobreviure a `'a`.
/// Tanmateix, aquesta intenció no s`expressa al codi, ja que no hi ha cap ús de la vida útil `'a` i, per tant, no està clar a quines dades s`aplica.
/// Podem corregir-ho dient al compilador que actuï *com si* l`estructura `Slice` contingués una referència `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Això també requereix al seu torn l`anotació `T: 'a`, cosa que indica que les referències a `T` són vàlides durant tota la vida útil `'a`.
///
/// En inicialitzar un `Slice`, simplement proporcioneu el valor `PhantomData` per al camp `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Paràmetres de tipus no utilitzats
///
/// De vegades passa que teniu paràmetres de tipus no utilitzats que indiquen a quin tipus de dades és una estructura "tied", tot i que aquestes dades no es troben a la mateixa estructura.
/// Aquí hi ha un exemple en què això sorgeix amb [FFI].
/// La interfície externa utilitza mànecs de tipus `*mut ()` per referir-se als valors Rust de diferents tipus.
/// Seguim el tipus Rust mitjançant un paràmetre de tipus fantasma a l`estructura `ExternalResource` que embolcalla un identificador.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Propietat i comprovació de la baixa
///
/// Si afegiu un camp del tipus `PhantomData<T>`, indica que el vostre tipus posseeix dades del tipus `T`.Al seu torn, això implica que quan es deixa caure el tipus, pot deixar caure una o més instàncies del tipus `T`.
/// Això afecta a l'anàlisi [drop check] del compilador Rust.
///
/// Si la vostra estructura de fet no és *propietària* de les dades del tipus `T`, és millor utilitzar un tipus de referència, com ara `PhantomData<&'a T>` (ideally) o `PhantomData<*const T>` (si no s'aplica la vida útil), per no indicar la propietat.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// trait intern del compilador utilitzat per indicar el tipus de discriminants enum.
///
/// Aquest trait s`implementa automàticament per a tots els tipus i no afegeix cap garantia al [`mem::Discriminant`].
/// Transmetre entre `DiscriminantKind::Discriminant` i `mem::Discriminant` és un **comportament indefinit**.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// El tipus de discriminant, que ha de satisfer el trait bounds requerit per `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compilador intern trait utilitzat per determinar si un tipus conté cap `UnsafeCell` internament, però no mitjançant una indirecta.
///
/// Això afecta, per exemple, si un `static` d'aquest tipus es col・loca a la memòria estàtica de només lectura o a la memòria estàtica d'escriptura.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Tipus que es poden moure amb seguretat després de ser fixats.
///
/// El propi Rust no té cap noció de tipus immobles i considera que els moviments (per exemple, mitjançant assignació o [`mem::replace`]) sempre són segurs.
///
/// El tipus [`Pin`][Pin] s'utilitza per evitar moviments pel sistema de tipus.Els punteros `P<T>` embolicats a l`embolcall [`Pin<P<T>>`][Pin] no es poden treure.
/// Consulteu la documentació [`pin` module] per obtenir més informació sobre la fixació.
///
/// La implementació de `Unpin` trait per a `T` elimina les restriccions de fixar el tipus, cosa que permet treure `T` de [`Pin<P<T>>`][Pin] amb funcions com [`mem::replace`].
///
///
/// `Unpin` no té cap conseqüència per a les dades no fixades.
/// En particular, [`mem::replace`] mou les dades `!Unpin` amb alegria (funciona per a qualsevol `&mut T`, no només quan `T: Unpin`).
/// Tot i això, no podeu utilitzar [`mem::replace`] en dades embolicades dins d'un [`Pin<P<T>>`][Pin] perquè no podeu obtenir el `&mut T` que necessiteu per a això, i *això* és el que fa funcionar aquest sistema.
///
/// Així, per exemple, això només es pot fer en els tipus que implementen `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Necessitem una referència mutable per trucar a `mem::replace`.
/// // Podem obtenir aquesta referència mitjançant (implicitly) invocant `Pin::deref_mut`, però això només és possible perquè `String` implementa `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Aquest trait s`implementa automàticament per a gairebé tots els tipus.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Un tipus de marcador que no implementa `Unpin`.
///
/// Si un tipus conté un `PhantomPinned`, no implementarà `Unpin` per defecte.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementacions de `Copy` per a tipus primitius.
///
/// Les implementacions que no es poden descriure a Rust s`implementen a `traits::SelectionContext::copy_clone_conditions()` a `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Les referències compartides es poden copiar, però les referències mutables *no*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}