#![stable(feature = "futures_api", since = "1.36.0")]

//! Valors asíncrons.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Aquest tipus és necessari perquè:
///
/// a) Els generadors no poden implementar `for<'a, 'b> Generator<&'a mut Context<'b>>`, de manera que hem de passar un punter en brut (vegeu <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Els punteres RAW i `NonNull` no són `Send` ni `Sync`, de manera que també es convertiria en un future non-Send/Sync, i no ho volem.
///
/// També simplifica la reducció HIR de `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Emboliqueu un generador en un future.
///
/// Aquesta funció retorna un `GenFuture` a sota, però l`amaga a `impl Trait` per donar millors missatges d`error (`impl Future` en lloc de `GenFuture<[closure.....]>`).
///
// Es tracta de `const` per evitar errors addicionals després de recuperar-nos de `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Ens basem en el fet que async/await futures són inamovibles per tal de crear préstecs autoreferencials al generador subjacent.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // SEGURETAT: segur perquè som !Unpin + !Drop, i això només és una projecció de camp.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Repreneu el generador convertint el `&mut Context` en un punter en brut `NonNull`.
            // La reducció del `.await` tornarà a convertir-lo amb seguretat en un `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // SEGURETAT: la persona que truca ha de garantir que `cx.0` és un punter vàlid
    // que compleix tots els requisits per obtenir una referència mutable.
    unsafe { &mut *cx.0.as_ptr().cast() }
}