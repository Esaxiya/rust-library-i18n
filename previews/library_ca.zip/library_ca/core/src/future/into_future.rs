use crate::future::Future;

/// Conversió en un `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// La sortida que future produirà en acabar.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// En quin tipus de future estem convertint això?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Crea un future a partir d'un valor.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}