#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Un futur Z0 representa un càlcul asíncron.
///
/// Un future és un valor que potser encara no ha acabat de computar.
/// Aquest tipus de "asynchronous value" fa possible que un fil continuï fent tasques útils mentre espera que el valor estigui disponible.
///
///
/// # El mètode `poll`
///
/// El mètode bàsic de future, `poll`,*intenta* resoldre future en un valor final.
/// Aquest mètode no es bloqueja si el valor no està preparat.
/// En lloc d'això, està previst que es desperti la tasca actual quan sigui possible avançar més fent "poll" de nou.
/// El `context` passat al mètode `poll` pot proporcionar un [`Waker`], que és un gestor per despertar la tasca actual.
///
/// Quan utilitzeu un future, generalment no truqueu directament a `poll`, sinó al valor `.await`.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// El tipus de valor produït en finalitzar-se.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Intenteu resoldre el future a un valor final, registrant la tasca actual per al despertador si el valor encara no està disponible.
    ///
    /// # Valor de retorn
    ///
    /// Aquesta funció retorna:
    ///
    /// - [`Poll::Pending`] si el future encara no està preparat
    /// - [`Poll::Ready(val)`] amb el resultat `val` d'aquest future si ha acabat amb èxit.
    ///
    /// Un cop hagi acabat un future, els clients no haurien de tornar-lo a `poll`.
    ///
    /// Quan un future encara no està preparat, `poll` retorna `Poll::Pending` i emmagatzema un clon del [`Waker`] copiat del [`Context`] actual.
    /// Aquest [`Waker`] es desperta després que el future pugui avançar.
    /// Per exemple, un future que espera que es pugui llegir un sòcol trucaria a `.clone()` a l [`Waker`] i l`emmagatzemaria.
    /// Quan arriba un senyal que indica que el sòcol es pot llegir, es crida a [`Waker::wake`] i es desperta la tasca del sòcol future.
    /// Un cop despertada una tasca, hauria de tornar a intentar `poll` el future, que pot produir o no un valor final.
    ///
    /// Tingueu en compte que en diverses trucades a `poll`, només el [`Waker`] del [`Context`] passat a la trucada més recent s'ha de programar per rebre un despertador.
    ///
    /// # Característiques del temps d'execució
    ///
    /// Futures només és *inert*;s'han de fer "enquestes" activament * per avançar, és a dir, que cada vegada que es desperti la tasca actual, s'ha de tornar a "activar" fins a futures que encara tingui interès.
    ///
    /// La funció `poll` no es crida repetidament en un bucle estret, sinó que només s`ha de cridar quan el future indica que està preparat per avançar (trucant al `wake()`).
    /// Si esteu familiaritzat amb les descàrregues de `poll(2)` o `select(2)` a Unix, val la pena assenyalar que futures normalment *no* pateix els mateixos problemes de "all wakeups must poll all events";són més semblants a `epoll(4)`.
    ///
    /// Una implementació de `poll` s`ha d`esforçar per tornar ràpidament i no s`ha de bloquejar.Tornar ràpidament evita obstruir innecessàriament fils o bucles d'esdeveniments.
    /// Si abans se sap que una trucada a `poll` pot acabar trigant una estona, el treball s'ha de descarregar a un grup de fils (o alguna cosa similar) per garantir que `poll` pugui tornar ràpidament.
    ///
    /// # Panics
    ///
    /// Un cop s'hagi completat un future (retornat `Ready` des de `poll`), tornar a trucar al mètode `poll` pot panic, bloquejar-lo definitivament o provocar altres tipus de problemes;el `Future` trait no exigeix cap efecte sobre els efectes d'aquesta trucada.
    /// Tanmateix, com que el mètode `poll` no està marcat com a `unsafe`, s'apliquen les regles habituals de Rust: les trucades mai no han de provocar un comportament indefinit (corrupció de memòria, ús incorrecte de les funcions `unsafe` o similars), independentment de l'estat de future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}