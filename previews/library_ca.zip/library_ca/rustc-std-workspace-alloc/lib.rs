#![feature(no_core)]
#![no_core]

// Vegeu rustc-std-workspace-core per saber per què es necessita aquest crate.

// Canvieu el nom del crate per evitar entrar en conflicte amb el mòdul alloc de liballoc.
extern crate alloc as foo;

pub use foo::*;