//! Implementació de Rust panics mitjançant avortaments de procés
//!
//! En comparació amb la implementació mitjançant desenrotllament, aquest crate és *molt* més simple!Dit això, no és tan versàtil, però aquí va!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" la càrrega útil i la càrrega a l'avortament corresponent de la plataforma en qüestió.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // trucar a std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // A Windows, utilitzeu el mecanisme __fastfail específic del processador.A Windows 8 i versions posteriors, això acabarà el procés immediatament sense executar cap controlador d`excepcions en procés.
            // En versions anteriors de Windows, aquesta seqüència d`instruccions es tractarà com una infracció d`accés, donant per finalitzat el procés però sense necessàriament passar per alt tots els controladors d`excepcions.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: es tracta de la mateixa implementació que en `abort_internal` de libstd
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Això ... és una mica estrany.El tl; dr;és que això es requereix per enllaçar correctament, l'explicació més llarga és a continuació.
//
// Ara mateix, els fitxers binaris de libcore/libstd que enviem estan compilats amb `-C panic=unwind`.Això es fa per garantir que els fitxers binaris siguin al màxim compatibles amb tantes situacions com sigui possible.
// El compilador, però, requereix un "personality function" per a totes les funcions compilades amb `-C panic=unwind`.Aquesta funció de personalitat està codificada amb el símbol `rust_eh_personality` i està definida per l'element lang `eh_personality`.
//
// So...
// per què no només definiu aquest element lang aquí?Bona pregunta!La manera com s`uneixen els temps d`execució de panic és en realitat una mica subtil ja que són "sort of" a la botiga crate del compilador, però només s`enllacen si un altre no està realment enllaçat.
//
// Això acaba volent dir que tant aquest crate com el panic_unwind crate poden aparèixer al magatzem crate del compilador i, si ambdós defineixen l`element lang `eh_personality`, es produirà un error.
//
// Per gestionar això, el compilador només requereix que el `eh_personality` estigui definit si el temps d'execució panic que s'enllaça és el temps d'execució de desenrotllament i, en cas contrari, no cal definir-lo (amb raó).
// En aquest cas, però, aquesta biblioteca només defineix aquest símbol, de manera que hi ha almenys alguna personalitat en algun lloc.
//
// Bàsicament, aquest símbol només es defineix per connectar-se a binaris libcore/libstd, però mai no s'hauria de cridar, ja que no enllaçem en cap moment d'execució.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // A x86_64-pc-windows-gnu fem servir la nostra pròpia funció de personalitat que ha de retornar `ExceptionContinueSearch` mentre passem tots els nostres fotogrames.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // De forma similar a l'anterior, això correspon a l'element `eh_catch_typeinfo` lang que només s'utilitza a Emscripten actualment.
    //
    // Com que panics no genera excepcions i les excepcions estrangeres són actualment UB amb -C panic=avortar (tot i que pot estar subjecte a canvis), les trucades catch_unwind mai no utilitzaran aquest tipus d'informació.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Aquests dos són anomenats pels nostres objectes d'inici a i686-pc-windows-gnu, però no necessiten fer res, de manera que els cossos són nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}