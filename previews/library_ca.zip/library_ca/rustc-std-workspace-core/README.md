# El `rustc-std-workspace-core` crate

Aquest crate és un crate petit i buit que simplement depèn de `libcore` i reexporta tot el seu contingut.
El crate és el nucli de permetre que la biblioteca estàndard depengui de crates de crates.io

Crates a crates.io que depèn de la biblioteca estàndard, ha de dependre del `rustc-std-workspace-core` crate de crates.io, que està buit.

Utilitzem `[patch]` per substituir-lo a aquest crate d`aquest dipòsit.
Com a resultat, crates a crates.io dibuixarà una dependència edge a `libcore`, la versió definida en aquest dipòsit.
Això hauria de dibuixar totes les vores de dependència per garantir que Cargo construeixi crates amb èxit.

Tingueu en compte que crates a crates.io ha de dependre d`aquest crate amb el nom `core` perquè tot funcioni correctament.Per fer-ho, poden utilitzar:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Mitjançant l'ús de la tecla `package`, el crate es canvia a `core`, és a dir, tindrà un aspecte similar

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

quan Cargo invoca el compilador, satisfent la directiva `extern crate core` implícita injectada pel compilador.




