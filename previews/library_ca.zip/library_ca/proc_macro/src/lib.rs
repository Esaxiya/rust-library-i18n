//! Una biblioteca de suport per a autors de macros quan es defineixen noves macros.
//!
//! Aquesta biblioteca, proporcionada per la distribució estàndard, proporciona els tipus consumits a les interfícies de definicions de macro definides procedimentalment, com ara les macros de funció `#[proc_macro]`, els atributs de macro `#[proc_macro_attribute]` i els atributs derivats personalitzats "#[proc_macro_derive]".
//!
//!
//! Vegeu [the book] per obtenir més informació.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Determina si proc_macro s'ha fet accessible al programa en execució actual.
///
/// El proc_macro crate només està pensat per al seu ús dins de la implementació de macros procedimentals.Totes les funcions d'aquest crate panic si s'invoca des de fora d'una macro procedimental, com ara des d'un script de compilació o un test unitari o un binari Rust ordinari.
///
/// Tenint en compte les biblioteques Rust que estan dissenyades per admetre casos d'ús tant macro com no, `proc_macro::is_available()` proporciona una manera sense pànic de detectar si la infraestructura necessària per utilitzar l'API de proc_macro està actualment disponible.
/// Retorna cert si s'invoca des de l'interior d'una macro procedimental, és fals si s'invoca des de qualsevol altre binari.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// El tipus principal proporcionat per aquest crate, que representa un flux abstracte de tokens, o, més concretament, una seqüència d`arbres token.
/// El tipus proporciona interfícies per iterar sobre aquests arbres token i, al contrari, recollir un nombre d'arbres token en un flux.
///
///
/// Això és tant l'entrada com la sortida de les definicions `#[proc_macro]`, `#[proc_macro_attribute]` i `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// S'ha retornat un error de `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Retorna un `TokenStream` buit que no conté arbres token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Comprova si aquest `TokenStream` està buit.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Intenta trencar la cadena en tokens i analitzar-les en un flux token.
/// Pot fallar per diversos motius, per exemple, si la cadena conté delimitadors desequilibrats o caràcters que no existeixen en l'idioma.
///
/// Tots els tokens del flux analitzat obtenen abastos `Span::call_site()`.
///
/// NOTE: alguns errors poden provocar panics en lloc de retornar `LexError`.Ens reservem el dret de canviar aquests errors a `LexError`s més endavant.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, el pont només proporciona `to_string`, implementeu `fmt::Display` basat en ell (el revers de la relació habitual entre tots dos).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Imprimeix el flux token com una cadena que se suposa que pot convertir-se sense pèrdues en el mateix flux token (módulo abasta), excepte possiblement `TokenTree: : Group`s amb delimitadors `Delimiter::None` i literals numèrics negatius.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Imprimeix token en un formulari convenient per a la depuració.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Crea un flux token que conté un sol arbre token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Recopila diversos arbres token en un sol flux.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Una operació "flattening" en fluxos token, recopila arbres token de diversos fluxos token en un únic flux.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Utilitzeu una implementació if/when optimitzada possible.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Detalls d`implementació pública per al tipus `TokenStream`, com ara els iteradors.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Un iterador de `TokenTree` de`TokenStream`.
    /// La iteració és "shallow", per exemple, l'iterador no es repeteix en grups delimitats i retorna grups sencers com a arbres token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` accepta tokens arbitrària i s`expandeix en un `TokenStream` que descriu l`entrada.
/// Per exemple, `quote!(a + b)` produirà una expressió que, quan s`avaluarà, construirà el `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// L'anul・lació de la cita es fa amb `$` i funciona prenent el següent identificador únic com a terme sense citar.
/// Per citar el propi `$`, utilitzeu `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Una regió de codi font, juntament amb informació d`expansió de macro.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Crea un nou `Diagnostic` amb el `message` donat a l'interval `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Un interval que es resol al lloc de definició de macros.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// El lapse de la invocació de la macro procedimental actual.
    /// Els identificadors creats amb aquest interval es resoldran com si estiguessin escrits directament a la ubicació de la trucada de macro (higiene del lloc de trucades) i altres codis del lloc de trucades de macro també hi podran fer referència.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Un interval que representa la higiene de `macro_rules` i, de vegades, es resol al lloc de definició de macro (variables locals, etiquetes, `$crate`) i, de vegades, al lloc de trucades de macro (tota la resta).
    ///
    /// La ubicació de l'interval es pren des del lloc de trucades.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// El fitxer font original al qual apunta aquest abast.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// El `Span` per al tokens de l'anterior expansió de macro a partir de la qual es va generar `self`, si n'hi hagués.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// El lapse del codi font d'origen des del qual s'ha generat `self`.
    /// Si aquest `Span` no es va generar a partir d'altres expansions de macro, el valor de retorn és el mateix que `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Obté el line/column inicial al fitxer origen per a aquest interval.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Obté la final line/column al fitxer origen per a aquest interval.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Crea un nou interval que inclou `self` i `other`.
    ///
    /// Retorna `None` si `self` i `other` provenen de fitxers diferents.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Crea un nou interval amb la mateixa informació line/column que `self`, però que resol símbols com si fos a `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Crea un nou interval amb el mateix comportament de resolució de nom que `self`, però amb la informació line/column de `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Es compara amb els trams per veure si són iguals.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Retorna el text d'origen darrere d'un lapse.
    /// Es conserva el codi font original, inclosos els espais i els comentaris.
    /// Només retorna un resultat si l'espai correspon al codi font real.
    ///
    /// Note: El resultat observable d'una macro només s'ha de basar en el tokens i no en aquest text d'origen.
    ///
    /// El resultat d'aquesta funció és el millor esforç que es pot utilitzar només per al diagnòstic.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Imprimeix un espai en un formulari convenient per a la depuració.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Un parell línia-columna que representa l`inici o el final d`un `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// La línia indexada 1 del fitxer origen en què s'inicia o acaba l'espai (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// La columna indexada en 0 (en caràcters UTF-8) del fitxer origen en què s'inicia o acaba l'espai (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// El fitxer font d`un determinat `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Obté el camí d'accés a aquest fitxer font.
    ///
    /// ### Note
    /// Si l`extensió de codi associada a aquest `SourceFile` ha estat generada per una macro externa, és possible que aquesta macro no sigui una ruta real del sistema de fitxers.
    /// Utilitzeu [`is_real`] per comprovar-ho.
    ///
    /// Tingueu en compte també que, fins i tot si `is_real` retorna `true`, si es va passar `--remap-path-prefix` a la línia d'ordres, pot ser que el camí donat no sigui vàlid.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Retorna `true` si aquest fitxer font és un fitxer font real i no és generat per l'expansió d'una macro externa.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Es tracta d`un hack fins que s`implementen els espais d`intercalació i podem tenir fitxers font reals per als espais generats en macros externes.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Un sol token o una seqüència delimitada d'arbres token (per exemple, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Un flux token envoltat de delimitadors de claudàtors.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Un identificador.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Un sol caràcter de puntuació (`+`, `,`, `$`, etc.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Un caràcter literal (`'a'`), cadena (`"hello"`), número (`2.3`), etc.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Torna l'espai d'aquest arbre, delegant al mètode `span` del token contingut o d'un flux delimitat.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Configura l'espai per a *només aquest token*.
    ///
    /// Tingueu en compte que si aquest token és un `Group`, aquest mètode no configurarà l`abast de cadascun dels tokens interns, simplement delegarà al mètode `set_span` de cada variant.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Imprimeix l'arbre token en un formulari convenient per a la depuració.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Cadascun d'aquests té el nom al tipus struct a la depuració derivada, de manera que no us molesteu amb una capa addicional d'indirecció
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, el pont només proporciona `to_string`, implementeu `fmt::Display` basat en ell (el revers de la relació habitual entre tots dos).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Imprimeix l'arbre token com una cadena que se suposa que es pot convertir sense pèrdues en el mateix arbre token (módulo abasta), excepte possiblement `TokenTree: : Group`s amb delimitadors `Delimiter::None` i literals numèrics negatius.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Un flux token delimitat.
///
/// Un `Group` conté internament un `TokenStream` que està envoltat de `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Descriu com es delimita una seqüència d'arbres token.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Un delimitador implícit, que pot aparèixer, per exemple, al voltant de tokens provinent d`un "macro variable" `$var`.
    /// És important preservar les prioritats de l'operador en casos com `$var * 3` on `$var` és `1 + 2`.
    /// És possible que els delimitadors implícits no sobrevisquin a l'anada i la tornada d'un flux token a través d'una cadena.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Crea un nou `Group` amb el delimitador i el flux token donats.
    ///
    /// Aquest constructor establirà l'interval d'aquest grup a `Span::call_site()`.
    /// Per canviar l'interval, podeu utilitzar el mètode `set_span` següent.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Retorna el delimitador d'aquest `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Retorna el `TokenStream` de tokens que es delimita en aquest `Group`.
    ///
    /// Tingueu en compte que el flux token retornat no inclou el delimitador retornat anteriorment.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Retorna l'espai dels delimitadors d'aquest flux token, que abasta tot el `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Retorna l'espai que apunta al delimitador d'obertura d'aquest grup.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Retorna l'espai que apunta al delimitador de tancament d'aquest grup.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Configura l'abast dels delimitadors d'aquest grup, però no els seus tokens interns.
    ///
    /// Aquest mètode **no** establirà l'interval de tots els tokens interns que abasta aquest grup, sinó que només establirà l'interval del delimitador tokens al nivell del `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, el pont només proporciona `to_string`, implementeu `fmt::Display` basat en ell (el revers de la relació habitual entre tots dos).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Imprimeix el grup com una cadena que hauria de ser convertible sense pèrdues en el mateix grup (módulo abasta), excepte possiblement `TokenTree: : Group` amb delimitadors `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// Un `Punct` és un caràcter de puntuació únic com `+`, `-` o `#`.
///
/// Els operadors de caràcters múltiples com `+=` es representen com dues instàncies de `Punct` amb formes diferents de `Spacing` retornades.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Si a un `Punct` el segueix immediatament un altre `Punct` o el segueix un altre token o un espai en blanc.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// per exemple, `+` és `Alone` a `+ =`, `+ident` o `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// per exemple, `+` és `Joint` a `+=` o `'#`.
    /// A més, les cometes simples `'` poden unir-se amb identificadors per formar la vida `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Crea un nou `Punct` a partir del caràcter i de l'espaiat donats.
    /// L'argument `ch` ha de ser un caràcter de puntuació vàlid permès per l'idioma, en cas contrari la funció serà panic.
    ///
    /// El `Punct` retornat tindrà la durada predeterminada de `Span::call_site()`, que es pot configurar amb el mètode `set_span` següent.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Retorna el valor d'aquest caràcter de puntuació com a `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Retorna l'espaiat d'aquest caràcter de puntuació, indicant si immediatament el segueix un altre `Punct` al flux token, de manera que es poden combinar potencialment en un operador de diversos caràcters (`Joint`), o bé el segueix algun altre token o l'espai en blanc (`Alone`), de manera que l'operador té certament va acabar.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Retorna l'espai d'aquest caràcter de puntuació.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configureu l'interval d'aquest caràcter de puntuació.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, el pont només proporciona `to_string`, implementeu `fmt::Display` basat en ell (el revers de la relació habitual entre tots dos).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Imprimeix el caràcter de puntuació com una cadena que hauria de ser convertible sense pèrdues en el mateix caràcter.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Un identificador (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Crea un nou `Ident` amb el `string` donat, així com el `span` especificat.
    /// L'argument `string` ha de ser un identificador vàlid permès per l'idioma (incloses les paraules clau, per exemple, `self` o `fn`).En cas contrari, la funció serà panic.
    ///
    /// Tingueu en compte que `span`, actualment a rustc, configura la informació d`higiene d`aquest identificador.
    ///
    /// A partir d`aquest moment, `Span::call_site()` opta explícitament a la higiene de "call-site", cosa que significa que els identificadors creats amb aquest interval es resoldran com si estiguessin escrits directament a la ubicació de la trucada de macro i un altre codi al lloc de la trucada de macro es pugui referir a ells també.
    ///
    ///
    /// Els períodes posteriors com `Span::def_site()` permetran optar per la higiene "definition-site", cosa que significa que els identificadors creats amb aquest interval es resoldran a la ubicació de la definició de macro i que altres codis al lloc de trucades de macro no podran fer-hi referència.
    ///
    /// A causa de la importància actual de la higiene, aquest constructor, a diferència d'altres tokens, requereix que s'especifiqui un `Span` a la construcció.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Igual que `Ident::new`, però crea un identificador en brut (`r#ident`).
    /// L'argument `string` és un identificador vàlid permès per l'idioma (incloses les paraules clau, per exemple, `fn`).
    /// Paraules clau que es poden utilitzar en segments de camins (per exemple,
    /// `self`, "super") no s'admeten i provocaran un panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Retorna l'espai d'aquest `Ident`, que inclou tota la cadena retornada per [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configura l'abast d'aquest `Ident`, possiblement canviant el seu context d'higiene.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, el pont només proporciona `to_string`, implementeu `fmt::Display` basat en ell (el revers de la relació habitual entre tots dos).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Imprimeix l'identificador com una cadena que hauria de ser convertible sense pèrdues al mateix identificador.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Una cadena literal (`"hello"`), cadena de bytes (`b"hello"`), caràcter (`'a'`), caràcter de byte (`b'a'`), un nombre enter o de coma flotant amb o sense sufix (`1 ', `1u8`, `2.3`, `2.3f32`).
///
/// Els literals booleans com `true` i `false` no pertanyen aquí, són `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Crea un literal enter complet amb sufix amb el valor especificat.
        ///
        /// Aquesta funció crearà un nombre enter com `1u32` on el valor enter especificat és la primera part del token i la integral també es sufix al final.
        /// Els literals creats a partir de nombres negatius poden no sobreviure a anades i tornades a través de `TokenStream` o cadenes i es poden dividir en dos tokens (`-` i literal positiu).
        ///
        ///
        /// Els literals creats mitjançant aquest mètode tenen l`espai `Span::call_site()` per defecte, que es pot configurar amb el mètode `set_span` següent.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Crea un literal enter enter sense sufix amb el valor especificat.
        ///
        /// Aquesta funció crearà un nombre enter com `1` on el valor enter especificat és la primera part del token.
        /// No s`especifica cap sufix en aquest token, el que significa que invocacions com `Literal::i8_unsuffixed(1)` són equivalents a `Literal::u32_unsuffixed(1)`.
        /// Els literals creats a partir de nombres negatius poden no sobreviure a les restrips a través de `TokenStream` o cadenes i es poden dividir en dos tokens (`-` i literal positiu).
        ///
        ///
        /// Els literals creats mitjançant aquest mètode tenen l`espai `Span::call_site()` per defecte, que es pot configurar amb el mètode `set_span` següent.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Crea un nou literal de coma flotant sense sufixar.
    ///
    /// Aquest constructor és similar a aquells com `Literal::i8_unsuffixed`, on el valor del flotador s`emet directament al token però no s`utilitza cap sufix, de manera que es pot deduir que serà un `f64` més endavant al compilador.
    ///
    /// Els literals creats a partir de nombres negatius poden no sobreviure a les restrips a través de `TokenStream` o cadenes i es poden dividir en dos tokens (`-` i literal positiu).
    ///
    /// # Panics
    ///
    /// Aquesta funció requereix que el flotador especificat sigui finit, per exemple, si és infinit o NaN, aquesta funció serà panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Crea un nou literal de coma flotant amb sufix.
    ///
    /// Aquest constructor crearà un literal com `1.0f32` on el valor especificat és la part anterior del token i `f32` és el sufix del token.
    /// Aquest token sempre es deduirà com un `f32` al compilador.
    /// Els literals creats a partir de nombres negatius poden no sobreviure a les restrips a través de `TokenStream` o cadenes i es poden dividir en dos tokens (`-` i literal positiu).
    ///
    ///
    /// # Panics
    ///
    /// Aquesta funció requereix que el flotador especificat sigui finit, per exemple, si és infinit o NaN, aquesta funció serà panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Crea un nou literal de coma flotant sense sufixar.
    ///
    /// Aquest constructor és similar a aquells com `Literal::i8_unsuffixed`, on el valor del flotador s`emet directament al token però no s`utilitza cap sufix, de manera que es pot deduir que serà un `f64` més endavant al compilador.
    ///
    /// Els literals creats a partir de nombres negatius poden no sobreviure a les restrips a través de `TokenStream` o cadenes i es poden dividir en dos tokens (`-` i literal positiu).
    ///
    /// # Panics
    ///
    /// Aquesta funció requereix que el flotador especificat sigui finit, per exemple, si és infinit o NaN, aquesta funció serà panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Crea un nou literal de coma flotant amb sufix.
    ///
    /// Aquest constructor crearà un literal com `1.0f64` on el valor especificat és la part anterior del token i `f64` és el sufix del token.
    /// Aquest token sempre es deduirà com un `f64` al compilador.
    /// Els literals creats a partir de nombres negatius poden no sobreviure a les restrips a través de `TokenStream` o cadenes i es poden dividir en dos tokens (`-` i literal positiu).
    ///
    ///
    /// # Panics
    ///
    /// Aquesta funció requereix que el flotador especificat sigui finit, per exemple, si és infinit o NaN, aquesta funció serà panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Cadena literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Caràcter literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Literal de cadena de bytes.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Retorna l'espai que engloba aquest literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configura l'espai associat per a aquest literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Retorna un `Span` que és un subconjunt de `self.span()` que conté només els bytes d'origen en l'interval `range`.
    /// Retorna `None` si l'interval retallat és fora dels límits de `self`.
    ///
    // FIXME(SergioBenitez): comproveu que l'interval de bytes comenci i acabi en un límit UTF-8 de la font.
    // en cas contrari, és probable que aparegui un panic en qualsevol altre lloc quan s'imprimeixi el text d'origen.
    // FIXME(SergioBenitez): no hi ha manera que l`usuari sàpiga a què s`assigna realment `self.span()`, de manera que actualment aquest mètode només es pot anomenar a cegues.
    // Per exemple, `to_string()` per al caràcter 'c' retorna "'\u{63}'";no hi ha manera que l'usuari sàpiga si el text d'origen era 'c' o si era '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) alguna cosa semblant a `Option::cloned`, però per a `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, el pont només proporciona `to_string`, implementeu `fmt::Display` basat en ell (el revers de la relació habitual entre tots dos).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Imprimeix el literal com una cadena que hauria de ser convertible sense pèrdues al mateix literal (excepte possibles arrodoniments per als literals de coma flotant).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Accés rastrejat a variables d'entorn.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Recupereu una variable d'entorn i afegiu-la per crear informació de dependència.
    /// El sistema de compilació que executa el compilador sabrà que es va accedir a la variable durant la compilació i podrà tornar a executar la compilació quan canviï el valor d'aquesta variable.
    ///
    /// A més del seguiment de dependències, aquesta funció hauria de ser equivalent a `env::var` de la biblioteca estàndard, tret que l'argument ha de ser UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}