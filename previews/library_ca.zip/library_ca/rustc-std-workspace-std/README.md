# El `rustc-std-workspace-std` crate

Consulteu la documentació del `rustc-std-workspace-core` crate.