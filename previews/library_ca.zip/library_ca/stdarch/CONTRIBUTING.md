# Contribució a stdarch

El `stdarch` crate està més que disposat a acceptar contribucions.En primer lloc, probablement voldreu consultar el dipòsit i assegurar-vos que us passin les proves:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

On `<your-target-arch>` és el triple objectiu utilitzat per `rustup`, per exemple, `x86_x64-unknown-linux-gnu` (sense cap `nightly-` anterior o similar).
Recordeu també que aquest dipòsit requereix el canal nocturn de Rust.
De fet, les proves anteriors requereixen que rust cada nit sigui el valor per defecte del vostre sistema, per establir que utilitzeu `rustup default nightly` (i `rustup default stable` per tornar).

Si algun dels passos anteriors no funciona, [please let us know][new]!

A continuació, podeu ajudar a [find an issue][issues], n'hem seleccionat uns quants amb les etiquetes [`help wanted`][help] i [`impl-period`][impl], que podrien ajudar particularment. 
És possible que us interessi el [#40][vendor], implementant tots els productes intrínsecs del proveïdor a x86.Aquest número té alguns bons consells sobre com començar.

Si teniu preguntes generals, no dubteu en fer preguntes sobre [join us on gitter][gitter].No dubteu a fer ping a@BurntSushi o@alexcrichton amb preguntes.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Com escriure exemples per a intrínsecs stdarch

Hi ha algunes funcions que s`han d`habilitar perquè l`intrínsec donat funcioni correctament i l`exemple només l`ha d`executar `cargo test --doc` quan la funció admet la CPU.

Com a resultat, el `fn main` predeterminat que genera `rustdoc` no funcionarà (en la majoria dels casos).
Penseu a utilitzar el següent com a guia per assegurar-vos que el vostre exemple funcioni tal com s`esperava.

```rust
/// # // Necessitem cfg_target_feature per assegurar-nos que l`exemple només sigui
/// # // executat per `cargo test --doc` quan la CPU admet la funció
/// # #![feature(cfg_target_feature)]
/// # // Necessitem target_feature perquè els intrínsecs funcionin
/// # #![feature(target_feature)]
/// #
/// # // rustdoc per defecte utilitza `extern crate stdarch`, però necessitem el fitxer
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // La funció principal real
/// # fn main() {
/// #     // Executeu-ho només si s'admet `<target feature>`
/// #     si cfg_feature_enabled! ("<target feature>"){
/// #         // Creeu una funció `worker` que només s'executarà si la funció de destinació
/// #         // és compatible i assegureu-vos que `target_feature` estigui habilitat per al vostre treballador
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         fn worker() insegur {
/// // Escriviu aquí el vostre exemple.Les funcions intrínsecs específiques funcionaran aquí.Sigues salvatge!
///
/// #         }
///
/// #         { worker(); } insegur
/// #     }
/// # }
```

Si algunes de les sintaxis anteriors no semblen familiars, la secció [Documentation as tests] del [Rust Book] descriu la sintaxi `rustdoc` força bé.
Com sempre, no dubteu en [join us on gitter][gitter] i pregunteu-nos si teniu cap problema i gràcies per ajudar a millorar la documentació de `stdarch`.

# Instruccions alternatives de proves

En general, es recomana utilitzar `ci/run.sh` per executar les proves.
Tanmateix, pot ser que això no us funcioni, per exemple, si esteu a Windows.

En aquest cas, podeu tornar a executar `cargo +nightly test` i `cargo +nightly test --release -p core_arch` per provar la generació de codi.
Tingueu en compte que requereixen la instal・lació de la cadena d`eines nocturna i que `rustc` conegui el vostre triple objectiu i la seva CPU.
En particular, heu d`establir la variable d`entorn `TARGET` tal com ho faríeu per a `ci/run.sh`.
A més, heu d`establir `RUSTCFLAGS` (necessiteu el `C`) per indicar les funcions objectiu, per exemple `RUSTCFLAGS="-C -target-features=+avx2"`.
També podeu configurar `-C -target-cpu=native` si esteu desenvolupant "just" amb la vostra CPU actual.

Tingueu en compte que quan feu servir aquestes instruccions alternatives, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], per exemple
les proves de generació d'instruccions poden fallar perquè el desmuntador les va anomenar de manera diferent, per exemple
pot generar instruccions `vaesenc` en lloc d`instruccions `aesenc` malgrat que es comportin igual.
A més, aquestes instruccions executen menys proves de les que normalment es farien, així que no us sorprengueu que quan sol・liciteu extracció eventualment apareguin alguns errors per a proves que no es tracten aquí.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






