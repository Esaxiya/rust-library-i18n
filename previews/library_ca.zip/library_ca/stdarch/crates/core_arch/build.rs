use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Solia dir-nos a les nostres anotacions `#[assert_instr]` que tots els intrinsecs simd estan disponibles per provar els seus codegens, ja que alguns estan tancats darrere d`un `-Ctarget-feature=+unimplemented-simd128` addicional que ara mateix no té cap equivalent a `#[target_feature]`.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}