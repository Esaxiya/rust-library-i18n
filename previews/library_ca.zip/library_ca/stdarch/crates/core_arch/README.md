`core::arch` - Intrínsecs específics de l'arquitectura principal de la biblioteca de Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

El mòdul `core::arch` implementa sistemes intrínsecs dependents de l'arquitectura (per exemple, SIMD).

# Usage 

`core::arch` està disponible com a part de `libcore` i és reexportat per `libstd`.Preferiu utilitzar-lo mitjançant `core::arch` o `std::arch` que mitjançant aquest crate.
Les funcions inestables solen estar disponibles a la Rust nocturna a través del `feature(stdsimd)`.

L`ús de `core::arch` mitjançant aquest crate requereix Rust cada nit, i pot (i sí) trencar sovint.Els únics casos en què hauríeu de plantejar-vos d`utilitzar-lo mitjançant aquest crate són:

* si heu de tornar a compilar `core::arch` vosaltres mateixos, per exemple, amb funcions específiques de destinació habilitades que no estan habilitades per a `libcore`/`libstd`.
Note: si heu de tornar a compilar-lo per a un objectiu no estàndard, preferiu fer servir `xargo` i tornar a compilar `libcore`/`libstd` segons correspongui en lloc d'utilitzar aquest crate.
  
* utilitzant algunes funcions que poden no estar disponibles, fins i tot darrere de les funcions Rust inestables.Intentem reduir-los al mínim.
Si heu d`utilitzar algunes d`aquestes funcions, obriu un problema perquè puguem exposar-les a la Rust nocturna i les pugueu utilitzar des d`aquí.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` es distribueix principalment sota els termes de la llicència MIT i de la llicència Apache (versió 2.0), amb porcions cobertes per diverses llicències semblants a BSD.

Vegeu LICENSE-APACHE i LICENSE-MIT per obtenir més informació.

# Contribution

Tret que expliqueu explícitament el contrari, qualsevol contribució que hàgiu enviat intencionadament per incloure-la a `core_arch`, tal com es defineix a la llicència Apache-2.0, tindrà una llicència dual tal com s'ha indicat anteriorment, sense termes o condicions addicionals.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












