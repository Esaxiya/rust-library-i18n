//! Està desenrotllant l'objectiu *emscripten*.
//!
//! Mentre que la implementació habitual de desenrotllament de Rust per a plataformes Unix fa una crida directament a les API libunwind, a Emscripten en canvi fem una crida a les API de desenrotllament C++ .
//! Això és només una experiència, ja que el temps d'execució d'Emscripten sempre implementa aquestes API i no implementa libunwind.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Això coincideix amb el disseny de std::type_info en C++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // El byte principal `\x01` aquí és en realitat un senyal màgic a LLVM per no aplicar cap altra manipulació, com ara la prefixació amb un caràcter `_`.
    //
    //
    // Aquest símbol és la taula vt que utilitza el `std::type_info` de C++ .
    // Els objectes de tipus `std::type_info`, descriptors de tipus, tenen un punter cap a aquesta taula.
    // Els descriptors de tipus estan referenciats per les estructures C++ EH definides anteriorment i que construïm a continuació.
    //
    // Tingueu en compte que la mida real és superior a 3 usades, però només necessitem la nostra taula virtual per assenyalar el tercer element.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info per a una classe rust_panic
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Normalment utilitzaríem .as_ptr().add(2), però això no funciona en un context const.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Això intencionadament no utilitza l`esquema normal de manipulació de noms perquè no volem que C++ pugui produir o captar Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // Això és necessari perquè el codi C++ pot capturar la nostra execption amb std::exception_ptr i tornar-lo a provar diverses vegades, possiblement fins i tot en un altre fil.
    //
    //
    caught: AtomicBool,

    // Això ha de ser una opció perquè la durada de l'objecte segueix la semàntica C++ : quan catch_unwind mou el quadre fora de l'excepció, ha de deixar l'objecte d'excepció en un estat vàlid perquè el seu destructor encara serà anomenat per __cxa_end_catch.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try en realitat ens dóna un punter cap a aquesta estructura.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Com que cleanup() no està autoritzat a panic, simplement avortem.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}