//! Implementació de panics mitjançant desenrotllament de pila
//!
//! Aquest crate és una implementació de panics a Rust mitjançant el mecanisme de desenrotllament de pila "most native" de la plataforma per a la qual es compila.
//! Actualment, bàsicament, es classifica en tres cubs:
//!
//! 1. Els objectius MSVC utilitzen SEH al fitxer `seh.rs`.
//! 2. Emscripten utilitza excepcions C++ al fitxer `emcc.rs`.
//! 3. La resta de destinacions utilitzen libunwind/libgcc al fitxer `gcc.rs`.
//!
//! Podeu trobar més documentació sobre cada implementació al mòdul respectiu.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` no s`utilitza amb Miri, així que silencieu les advertències.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Els objectes d'inici del temps d'execució de Rust depenen d'aquests símbols, per tant, feu-los públics.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Objectius que no admeten el desenrotllament.
        // - arch=wasm32
        // - os=none (objectius "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Utilitzeu el temps d'execució de Miri.
        // Encara hem de carregar el temps d`execució normal anterior, ja que rustc espera que es defineixin certs elements de llenguatge.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Utilitzeu el temps d`execució real.
        use real_imp as imp;
    }
}

extern "C" {
    /// Es diu el controlador a libstd quan es deixa caure un objecte panic fora de `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Es diu el controlador a libstd quan es detecta una excepció estrangera.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Punt d`entrada per generar una excepció, només delegueu a la implementació específica de la plataforma.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}