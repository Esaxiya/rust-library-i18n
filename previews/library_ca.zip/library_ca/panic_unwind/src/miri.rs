//! Desenvolupament de panics per a Miri.
use alloc::boxed::Box;
use core::any::Any;

// El tipus de càrrega útil que el motor Miri propaga a través del desenrotllament per a nosaltres.
// Ha de tenir la mida d'un punter.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Funció externa proporcionada per Miri per començar a desconnectar.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // La càrrega útil que passem a `miri_start_panic` serà exactament l`argument que obtindrem a `cleanup` a continuació.
    // Així doncs, només l`emmagatzemem una vegada per obtenir una mida del punter.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Recupereu el `Box` subjacent.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}