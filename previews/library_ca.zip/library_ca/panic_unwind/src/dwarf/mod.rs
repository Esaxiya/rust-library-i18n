//! Utilitats per analitzar fluxos de dades codificats amb DWARF.
//! Vegeu <http://www.dwarfstd.org>, DWARF-4 estàndard, Secció 7, "Data Representation"
//!

// Aquest mòdul només el fa servir x86_64-pc-windows-gnu per ara, però el recopilem a tot arreu per evitar regressions.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // Els fluxos DWARF estan empaquetats, de manera que, per exemple, un u32 no necessàriament estaria alineat en un límit de 4 bytes.
    // Això pot causar problemes a les plataformes amb requisits d`alineació estrictes.
    // En ajustar les dades en una estructura "packed", estem indicant al backend que generi codi "misalignment-safe".
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // Les codificacions ULEB128 i SLEB128 es defineixen a la secció 7.6, "Variable Length Data".
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}