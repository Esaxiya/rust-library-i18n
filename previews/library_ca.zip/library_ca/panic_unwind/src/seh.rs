//! Windows SEH
//!
//! A Windows (actualment només a MSVC), el mecanisme per defecte de gestió d`excepcions és Structured Exception Handling (SEH).
//! Això és bastant diferent del tractament de les excepcions basat en Dwarf (per exemple, el que fan servir altres plataformes unix) pel que fa a les funcions internes del compilador, de manera que es requereix que LLVM tingui una gran quantitat de suport addicional per a SEH.
//!
//! En poques paraules, el que passa aquí és:
//!
//! 1. La funció `panic` crida a la funció Windows estàndard `_CxxThrowException` per llançar una excepció semblant a C++ , desencadenant el procés de desenrotllament.
//! 2.
//! Totes les plataformes d'aterratge generades pel compilador utilitzen la funció de personalitat `__CxxFrameHandler3`, una funció del CRT, i el codi de desenrotllament de Windows utilitzarà aquesta funció de personalitat per executar tot el codi de neteja de la pila.
//!
//! 3. Totes les trucades generades pel compilador a `invoke` tenen una pista d'aterratge configurada com a instrucció `cleanuppad` LLVM, que indica l'inici de la rutina de neteja.
//! La personalitat (al pas 2, definida al CRT) s`encarrega d`executar les rutines de neteja.
//! 4. Finalment, s`executa el codi "catch" a l`intrínsec `try` (generat pel compilador) i indica que el control hauria de tornar a Rust.
//! Això es fa mitjançant una instrucció `catchswitch` més una `catchpad` en termes LLVM IR, retornant finalment el control normal al programa amb una instrucció `catchret`.
//!
//! Algunes diferències específiques del tractament d`excepcions basat en gcc són:
//!
//! * Rust no té cap funció de personalització personalitzada, sinó que és *sempre*`__CxxFrameHandler3`.A més, no es realitza cap filtre addicional, de manera que acabem captant qualsevol excepció C++ que sembli semblant a la que estem llançant.
//! Tingueu en compte que llançar una excepció a Rust és un comportament indefinit de totes maneres, de manera que hauria d`estar bé.
//! * Tenim algunes dades per transmetre a través del límit de desenrotllament, concretament un `Box<dyn Any + Send>`.Igual que amb les excepcions de Dwarf, aquests dos indicadors s`emmagatzemen com a càrrega útil a la pròpia excepció.
//! Tanmateix, a MSVC no hi ha cap assignació de pila addicional perquè la pila de trucades es conserva mentre s`executen les funcions de filtre.
//! Això vol dir que els punteres es passen directament a `_CxxThrowException`, que després es recuperen a la funció de filtre per escriure-los al quadre de pila de l `try` intrínsec.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Aquesta ha de ser una opció perquè capturem l'excepció per referència i el seu destructor s'executa en temps d'execució C++ .
    // Quan traiem el quadre de l`excepció, hem de deixar l`excepció en un estat vàlid perquè el destructor s`executi sense deixar caure el doble.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// En primer lloc, un munt de definicions de tipus.Aquí hi ha algunes peculiaritats específiques de la plataforma i moltes que s`han copiat descaradament de LLVM.El propòsit de tot això és implementar la funció `panic` següent mitjançant una trucada a `_CxxThrowException`.
//
// Aquesta funció té dos arguments.El primer és un punter a les dades que passem, que en aquest cas és el nostre objecte trait.Molt fàcil de trobar.El següent, però, és més complicat.
// Aquest és un punter cap a una estructura `_ThrowInfo` i, en general, només pretén descriure l'excepció que s'està llançant.
//
// Actualment, la definició d`aquest tipus [1] és una mica peluda i la curiositat principal (i la diferència de l`article en línia) és que a 32 bits els punteres són punteres, però a 64 bits els punteres s`expressen com a compensacions de 32 bits Símbol `__ImageBase`.
//
// Per expressar-ho s`utilitzen les macros `ptr_t` i `ptr!` dels mòduls següents.
//
// El laberint de definicions de tipus també segueix de prop el que emet LLVM per a aquest tipus d`operacions.Per exemple, si compileu aquest codi C++ a MSVC i emetreu el LLVM IR:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      buit foo() { rust_panic a = {0, 1};
//          llançar un;}
//
// Això és essencialment el que intentem imitar.La majoria dels valors constants següents s`acaben de copiar de LLVM,
//
// En qualsevol cas, totes aquestes estructures es construeixen de manera similar i, per a nosaltres, són una mica detallades.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Tingueu en compte que aquí ignorem intencionadament les regles de manipulació de noms: no volem que C++ pugui atrapar Rust panics simplement declarant un `struct rust_panic`.
//
//
// Quan modifiqueu, assegureu-vos que la cadena de nom del tipus coincideixi exactament amb la que s`utilitza a `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // El byte principal `\x01` aquí és en realitat un senyal màgic a LLVM per no aplicar cap altra manipulació, com ara la prefixació amb un caràcter `_`.
    //
    //
    // Aquest símbol és la taula vt que utilitza el `std::type_info` de C++ .
    // Els objectes de tipus `std::type_info`, descriptors de tipus, tenen un punter cap a aquesta taula.
    // Els descriptors de tipus estan referenciats per les estructures C++ EH definides anteriorment i que construïm a continuació.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Aquest descriptor de tipus només s`utilitza quan es produeix una excepció.
// La part de captura és gestionada per la prova intrínseca, que genera el seu propi TypeDescriptor.
//
// Està bé, ja que el temps d'execució de MSVC utilitza la comparació de cadenes al nom del tipus per fer coincidir TypeDescriptors en lloc de la igualtat de punter.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor utilitzat si el codi C++ decideix capturar l'excepció i deixar-la sense propagar.
// La part de captura de la prova intrínseca establirà la primera paraula de l'objecte d'excepció a 0 perquè el destructor la salti.
//
// Tingueu en compte que x86 Windows utilitza la convenció de trucades "thiscall" per a funcions de membres de C++ en lloc de la convenció de trucades "C" per defecte.
//
// La funció exception_copy és una mica especial aquí: és invocada pel temps d'execució MSVC sota un bloc try/catch i el panic que generem aquí s'utilitzarà com a resultat de la còpia d'excepció.
//
// El temps d`execució de C++ l`utilitza per admetre excepcions de captura amb std::exception_ptr, cosa que no podem admetre perquè Box<dyn Any>no és clonable.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException s`executa completament en aquest marc de pila, de manera que no cal transferir `data` al munt.
    // Simplement passem un punter de pila a aquesta funció.
    //
    // El ManuallyDrop és necessari aquí, ja que no volem que l'excepció es deixi caure quan es desenrotlla.
    // En lloc d'això, es deixarà caure per exception_cleanup, que és invocat pel temps d'execució C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Això ... pot semblar sorprenent i, de manera justificada.En MSVC de 32 bits, els indicadors entre aquestes estructures són només això, els indicadors.
    // Tanmateix, a MSVC de 64 bits, els indicadors entre estructures s`expressen més aviat com desplaçaments de 32 bits de `__ImageBase`.
    //
    // En conseqüència, a MSVC de 32 bits podem declarar tots aquests indicadors a la secció 'estàtica' anterior.
    // En MSVC de 64 bits, hauríem d`expressar la resta de punteres en estàtiques, cosa que Rust no permet actualment, de manera que no podem fer-ho realment.
    //
    // El següent millor és omplir aquestes estructures en temps d'execució (el pànic ja és l "slow path").
    // Així doncs, aquí reinterpretem tots aquests camps de punter com a enters de 32 bits i després hi emmagatzemem el valor rellevant (atòmicament, ja que pot estar passant panics concurrent).
    //
    // Tècnicament, el temps d'execució probablement farà una lectura no atòmica d'aquests camps, però en teoria mai no llegeixen el valor * incorrecte, de manera que no hauria de ser tan dolent ...
    //
    // En qualsevol cas, bàsicament hem de fer alguna cosa així fins que puguem expressar més operacions en estàtica (i potser mai no serem capaços de fer-ho).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Una càrrega útil NULL aquí significa que hem arribat aquí des de la captura (...) de __rust_try.
    // Això passa quan es detecta una excepció estrangera que no és Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// El compilador requereix que existeixi (per exemple, és un element lang), però el compilador mai no el crida perquè __C_specific_handler o_except_handler3 és la funció de personalitat que sempre s'utilitza.
//
// Per tant, això és només un tronc que avorta.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}