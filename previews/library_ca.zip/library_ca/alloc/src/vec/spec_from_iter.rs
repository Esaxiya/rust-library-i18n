use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Especialització trait que s`utilitza per a Vec::from_iter
///
/// ## El gràfic de delegació:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Un cas comú és passar un vector a una funció que es recol・lecta immediatament a un vector.
        // Podem fer un curtcircuit si l`IntoIter no s`ha avançat gens.
        // Quan s'hagi avançat, també podem reutilitzar la memòria i moure les dades cap a la part frontal.
        // Però només ho fem quan el Vec resultant no tindria més capacitat inutilitzada que la que es crea mitjançant la implementació genèrica de FromIterator.
        //
        // Aquesta limitació no és estrictament necessària, ja que el comportament d`assignació de Vec no s`especifica intencionadament.
        // Però és una opció conservadora.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // ha de delegar a spec_extend() ja que el propi extend() delega a spec_from per a Vecs buits
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// S`utilitza `iterator.as_slice().to_vec()` ja que spec_extend ha de fer més passos per raonar sobre la capacitat final + longitud i, per tant, fer més feina.
// `to_vec()` assigna directament l`import correcte i l`omple exactament.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): amb cfg(test), el mètode inherent `[T]::to_vec`, que es requereix per a aquesta definició de mètode, no està disponible.
    // En lloc d'això, utilitzeu la funció `slice::to_vec`, que només està disponible amb cfg(test) NB. Consulteu el mòdul slice::hack a slice.rs per obtenir més informació.
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}