use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Un iterador que utilitza un tancament per determinar si s`ha d`eliminar un element.
///
/// Aquesta estructura és creada per [`Vec::drain_filter`].
/// Consulteu-ne la documentació per obtenir més informació.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// L'índex de l'element que serà inspeccionat per la propera trucada a `next`.
    pub(super) idx: usize,
    /// El nombre d`elements que s`han esgotat fins ara (removed).
    pub(super) del: usize,
    /// La longitud original del `vec` abans del drenatge.
    pub(super) old_len: usize,
    /// El predicat de prova del filtre.
    pub(super) pred: F,
    /// Un indicador que indica que s'ha produït un panic al predicat de prova del filtre.
    /// S'utilitza com a suggeriment en la implementació de la caiguda per evitar el consum de la resta del `DrainFilter`.
    /// Qualsevol element no processat es retrocedirà a la `vec`, però el predicat del filtre no deixarà ni provarà cap altre element.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Retorna una referència a l'assignador subjacent.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Actualitzeu l`índex *després que* es cridi el predicat.
                // Si l'índex s'actualitza prèviament i el predicat panics, l'element d'aquest índex es filtraria.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Aquest és un estat força desordenat i, realment, no hi ha res correcte a fer.
                        // No volem continuar intentant executar `pred`, de manera que només canviem tots els elements sense processar i li diem al vec que encara existeixen.
                        //
                        // Es requereix el retrocés per evitar una doble caiguda de l'últim element drenat amb èxit abans d'un panic al predicat.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Intenteu consumir qualsevol element restant si el predicat del filtre encara no ha entrat en pànic.
        // Tornarem a canviar els elements restants, ja sigui que ja tinguem pànic o si el consum aquí és panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}