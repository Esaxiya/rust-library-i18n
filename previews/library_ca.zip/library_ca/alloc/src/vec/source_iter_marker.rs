use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Marc d'especialització per recollir una canonada d'iterador en un Vec mentre es reutilitza l'assignació d'origen, és a dir
/// executant la canonada al seu lloc.
///
/// El pare SourceIter trait és necessari perquè la funció especialitzadora accedeixi a l'assignació que es vol reutilitzar.
/// Però no és suficient perquè l`especialització sigui vàlida.
/// Vegeu límits addicionals a la impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// Les std-internes SourceIter/InPlaceIterable traits només són implementades per cadenes d'adaptador <Adapter<Adapter<IntoIter>>> (tots propietat de core/std).
// Els límits addicionals de les implementacions de l'adaptador (més enllà de `impl<I: Trait> Trait for Adapter<I>`) només depenen d'altres traits ja marcats com a especialització traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. el marcador no depèn de la vida útil dels tipus subministrats per l'usuari.Moduleu el forat de còpia, del qual ja depenen diverses altres especialitzacions.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Requisits addicionals que no es poden expressar mitjançant trait bounds.En canvi, ens basem en const eval:
        // a) sense ZST, ja que no hi hauria assignació per reutilitzar i l'aritmètica del punter coincidiria amb panic b) coincidiria amb la mida que exigeix el contracte Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // alternativa a implementacions més genèriques
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // utilitzeu try-fold des de
        // - es vectoritza millor per a alguns adaptadors iteradors
        // - a diferència de la majoria dels mètodes d'iteració interns, només es necessita un self &mut
        // - ens permet passar el punter d'escriptura a través de les seves entranyes i recuperar-lo al final
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // la iteració ha tingut èxit, no deixeu anar el cap
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // comproveu si el contracte de SourceIter es va confirmar: si no ho fos, potser ni tan sols arribem a aquest punt
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // comproveu el contracte InPlaceIterable.Això només és possible si l'iterador ha avançat el punter d'origen.
        // Si utilitza un accés no marcat mitjançant TrustedRandomAccess, el punter d'origen es mantindrà a la seva posició inicial i no el podem utilitzar com a referència
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // deixeu caure els valors restants a la cua de la font, però eviteu la caiguda de l'assignació si IntoIter surt fora de l'abast si la caiguda panics llavors també filtrem qualsevol element recollit a dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // el contracte InPlaceIterable no es pot verificar amb precisió aquí, ja que try_fold té una referència exclusiva al punter d'origen tot el que podem fer és comprovar si encara està a l'interval
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}