#![stable(feature = "rust1", since = "1.0.0")]

//! Punters de recompte de referències segurs per a fils.
//!
//! Consulteu la documentació [`Arc<T>`][Arc] per obtenir més detalls.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Un límit suau de la quantitat de referències que es poden fer a un `Arc`.
///
/// Si supereu aquest límit, avortareu el programa (encara que no necessàriament) amb les referències _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer no admet tanques de memòria.
// Per evitar informes falsos positius en la implementació Arc/Weak, utilitzeu càrregues atòmiques per a la sincronització.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Un punter de recompte de referències segur de fils.'Arc' significa "Atomically Reference Counted".
///
/// El tipus `Arc<T>` proporciona la propietat compartida d'un valor del tipus `T`, assignat a l'emmagatzematge dinàmic.La invocació de [`clone`][clone] a `Arc` produeix una nova instància `Arc`, que apunta a la mateixa assignació a l'emmagatzematge dinàmic que la font `Arc`, alhora que augmenta el recompte de referència.
/// Quan es destrueix l'últim punter `Arc` a una assignació determinada, també es baixa el valor emmagatzemat en aquesta assignació (sovint anomenat "inner value").
///
/// Les referències compartides a Rust no permeten la mutació per defecte i `Arc` no és una excepció: generalment no es pot obtenir una referència mutable a alguna cosa dins d`un `Arc`.Si heu de mutar mitjançant un `Arc`, utilitzeu [`Mutex`][mutex], [`RwLock`][rwlock] o un dels tipus [`Atomic`][atomic].
///
/// ## Seguretat del fil
///
/// A diferència de [`Rc<T>`], `Arc<T>` utilitza operacions atòmiques per al seu recompte de referència.Això significa que és apte per a fils.L`inconvenient és que les operacions atòmiques són més costoses que els accessos de memòria habituals.Si no compartiu assignacions comptades amb referències entre fils, penseu a utilitzar [`Rc<T>`] per a despeses generals més baixes.
/// [`Rc<T>`] és un valor per defecte segur, perquè el compilador detectarà qualsevol intent d`enviar un [`Rc<T>`] entre fils.
/// Tot i això, una biblioteca pot triar `Arc<T>` per tal de proporcionar als consumidors de biblioteca més flexibilitat.
///
/// `Arc<T>` implementarà [`Send`] i [`Sync`] sempre que `T` implementi [`Send`] i [`Sync`].
/// Per què no podeu posar un tipus `T` que no sigui segur per a fils en un `Arc<T>` per fer-lo segur?Això pot ser una mica anti-intuïtiu al principi: al cap i a la fi, no és el punt de seguretat del fil `Arc<T>`?La clau és aquesta: `Arc<T>` fa que sigui segur de tenir diverses propietats de les mateixes dades, però no afegeix seguretat de fils a les seves dades.
///
/// Considereu `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] no és [`Sync`], i si `Arc<T>` sempre era [`Send`], `Arc <` [`RefCell<T>"]">`també ho seria.
/// Però llavors tindríem un problema:
/// [`RefCell<T>`] no és apte per a fils;fa un seguiment del recompte de préstecs mitjançant operacions no atòmiques.
///
/// Al final, això vol dir que potser haureu d`aparellar `Arc<T>` amb algun tipus de tipus [`std::sync`], normalment [`Mutex<T>`][mutex].
///
/// ## Trencar cicles amb `Weak`
///
/// El mètode [`downgrade`][downgrade] es pot utilitzar per crear un punter [`Weak`] que no sigui propietari.Un punter [`Weak`] es pot [[actualitzar]][actualitzar] d a un `Arc`, però això retornarà [`None`] si el valor emmagatzemat a l'assignació ja s'ha eliminat.
/// En altres paraules, els punters `Weak` no mantenen viu el valor dins de l'assignació;no obstant això,*sí* mantenen viva l'assignació (el magatzem secundari del valor).
///
/// Mai es repartirà un cicle entre els punteros `Arc`.
/// Per aquest motiu, [`Weak`] s'utilitza per trencar cicles.Per exemple, un arbre podria tenir indicadors `Arc` forts des de nodes pares fins a fills, i indicadors [`Weak`] des de nens fins als seus pares.
///
/// # Referències de clonació
///
/// La creació d`una nova referència a partir d`un punter de recompte de referències existent es fa mitjançant el `Clone` trait implementat per a [`Arc<T>`][Arc] i [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Les dues sintaxis següents són equivalents.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b i foo són arcs que apunten a la mateixa ubicació de memòria
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` anul・la automàticament les referències a `T` (mitjançant [`Deref`][deref] trait), de manera que podeu trucar als mètodes de "T" a un valor del tipus `Arc<T>`.Per evitar xocs de noms amb els mètodes de "T", els mètodes de `Arc<T>` en si són funcions associades, anomenades amb [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>Les implementacions de traits com `Clone` també es poden anomenar utilitzant una sintaxi completament qualificada.
/// Algunes persones prefereixen utilitzar una sintaxi completament qualificada, mentre que d'altres prefereixen utilitzar la sintaxi de mètode-trucada.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Sintaxi de mètode-trucada
/// let arc2 = arc.clone();
/// // Sintaxi completament qualificada
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] no fa autoreferència a `T`, ja que és possible que el valor intern ja s'hagi eliminat.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Compartir algunes dades immutables entre fils:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Tingueu en compte que **no** fem aquestes proves aquí.
// Els creadors de windows es mostren molt descontents si un fil sobreviu al fil principal i després surt al mateix temps (alguna cosa està bloquejat), de manera que ho evitem completament no executant aquestes proves.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Compartir un [`AtomicUsize`] mutable:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Consulteu el [`rc` documentation][rc_examples] per obtenir més exemples de recompte de referències en general.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` és una versió de [`Arc`] que conté una referència que no és propietària de l'assignació gestionada.
/// S'accedeix a l'assignació trucant a [`upgrade`] al punter `Weak`, que retorna una [`Opció`]`<`[`Arc`] `<T>>`.
///
/// Com que una referència `Weak` no compta amb la propietat, no evitarà que es caigui el valor emmagatzemat a l'assignació i el propi `Weak` no garanteix que el valor encara estigui present.
///
/// Per tant, pot retornar [`None`] quan ["actualitzar"] d.
/// Tingueu en compte, però, que una referència `Weak`*no* impedeix la distribució de l'assignació mateixa (el magatzem de suport).
///
/// Un punter `Weak` és útil per mantenir una referència temporal a l'assignació gestionada per [`Arc`] sense impedir que es baixi el seu valor intern.
/// També s'utilitza per evitar referències circulars entre els punters [`Arc`], ja que les referències de propietat mútua mai permetrien deixar caure cap dels dos [`Arc`].
/// Per exemple, un arbre pot tenir indicadors [`Arc`] forts des de nodes pares fins a fills, i indicadors `Weak` des de nens fins als seus pares.
///
/// La forma típica d'obtenir un punter `Weak` és trucar a [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Es tracta d`un `NonNull` que permet optimitzar la mida d`aquest tipus a les enumeracions, però no necessàriament és un punter vàlid.
    //
    // `Weak::new` ho defineix a `usize::MAX` perquè no necessiti assignar espai al munt.
    // Aquest no és un valor que tindrà mai un punter real perquè RcBox té alineació com a mínim 2.
    // Això només és possible quan `T: Sized`;`T` sense mida mai no penja.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Es tracta d'una prova de repr(C) a future contra possibles reordenacions de camp, que interfereixen amb [into|from]_raw() d'una altra manera segura de tipus interiors transmutables.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // el valor usize::MAX actua com un sentinella per a "locking" temporalment la possibilitat d'actualitzar els punteres febles o rebaixar els forts;s'utilitza per evitar curses en `make_mut` i `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Construeix un nou `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Inicieu el recompte de punter feble com a 1, que és el punter feble que tenen tots els indicadors forts (kinda); consulteu std/rc.rs per obtenir més informació.
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Construeix un nou `Arc<T>` mitjançant una referència feble a si mateix.
    /// Si intenteu actualitzar la referència feble abans que es retorni aquesta funció, obtindreu un valor `None`.
    /// No obstant això, la referència feble es pot clonar lliurement i emmagatzemar per utilitzar-la posteriorment.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Construïu l'interior en l'estat "uninitialized" amb una única referència feble.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // És important que no renunciem a la propietat del punter feble o, si no, la memòria es pot alliberar en el moment que `data_fn` torni.
        // Si realment volguéssim passar la propietat, podríem crear-nos un punter dèbil addicional, però això donaria lloc a actualitzacions addicionals del recompte de referències dèbils que d`una altra manera potser no serien necessàries.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Ara podem inicialitzar correctament el valor interior i convertir la nostra feble referència en una referència forta.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // L'escriptura anterior al camp de dades ha de ser visible per a tots els fils que observin un recompte fort que no sigui zero.
            // Per tant, necessitem com a mínim ordenar "Release" per sincronitzar amb `compare_exchange_weak` a `Weak::upgrade`.
            //
            // "Acquire" no cal fer cap comanda.
            // Quan considerem els possibles comportaments de `data_fn`, només hem de mirar què podria fer amb una referència a un `Weak` no actualitzable:
            //
            // - Pot *clonar* l `Weak`, augmentant el recompte de referència feble.
            // - Pot deixar caure aquests clons, disminuint el recompte de referència feble (però mai a zero).
            //
            // Aquests efectes secundaris no ens afecten de cap manera i no es poden produir altres efectes secundaris només amb el codi segur.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Les referències fortes haurien de posseir col・lectivament una referència feble compartida, així que no executeu el destructor de la nostra antiga referència feble.
        //
        mem::forget(weak);
        strong
    }

    /// Construeix un nou `Arc` amb contingut no inicialitzat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inicialització diferida:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Construeix un nou `Arc` amb contingut no inicialitzat, amb la memòria plena de bytes `0`.
    ///
    ///
    /// Vegeu [`MaybeUninit::zeroed`][zeroed] per obtenir exemples d`ús correcte i incorrecte d`aquest mètode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Construeix un nou `Pin<Arc<T>>`.
    /// Si `T` no implementa `Unpin`, `data` quedarà fixat a la memòria i no es podrà moure.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Construeix un `Arc<T>` nou, retornant un error si falla l'assignació.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Inicieu el recompte de punter feble com a 1, que és el punter feble que tenen tots els indicadors forts (kinda); consulteu std/rc.rs per obtenir més informació.
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Construeix un nou `Arc` amb contingut no inicialitzat, retornant un error si falla l'assignació.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Inicialització diferida:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Construeix un nou `Arc` amb contingut no inicialitzat, amb la memòria omplerta de bytes `0`, retornant un error si falla l'assignació.
    ///
    ///
    /// Vegeu [`MaybeUninit::zeroed`][zeroed] per obtenir exemples d`ús correcte i incorrecte d`aquest mètode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Retorna el valor intern, si l `Arc` té exactament una referència forta.
    ///
    /// En cas contrari, es retornarà un [`Err`] amb el mateix `Arc` que es va passar.
    ///
    ///
    /// Això tindrà èxit encara que hi hagi referències febles pendents.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Feu un punter feble per netejar la referència implícita forta-feble
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Construeix una nova secció comptada amb referències atòmiques amb continguts no inicialitzats.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inicialització diferida:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Construeix una nova secció comptada amb referències atòmiques amb contingut no inicialitzat, amb la memòria plena de bytes `0`.
    ///
    ///
    /// Vegeu [`MaybeUninit::zeroed`][zeroed] per obtenir exemples d`ús correcte i incorrecte d`aquest mètode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Converteix a `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Igual que amb [`MaybeUninit::assume_init`], correspon a la persona que truca garantir el valor intern realment en un estat inicialitzat.
    ///
    /// Cridar-ho quan el contingut encara no està inicialitzat completament provoca un comportament immediat i indefinit.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inicialització diferida:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Converteix a `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Igual que amb [`MaybeUninit::assume_init`], correspon a la persona que truca garantir el valor intern realment en un estat inicialitzat.
    ///
    /// Cridar-ho quan el contingut encara no està inicialitzat completament provoca un comportament immediat i indefinit.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inicialització diferida:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Consumeix el `Arc`, retornant el punter embolicat.
    ///
    /// Per evitar pèrdues de memòria, el punter s'ha de tornar a convertir a un `Arc` mitjançant [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Proporciona un punter en brut a les dades.
    ///
    /// Els recomptes no es veuen afectats de cap manera i el `Arc` no es consumeix.
    /// El punter és vàlid sempre que hi hagi recompenses fortes al `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SEGURETAT: Això no pot passar per Deref::deref o RcBoxPtr::inner perquè
        // això es requereix per conservar la procedència raw/mut tal que, per exemple,
        // `get_mut` pot escriure a través del punter després de recuperar Rc mitjançant `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Construeix un `Arc<T>` a partir d'un punter en brut.
    ///
    /// El punter en brut ha d'haver estat retornat prèviament per una trucada a [`Arc<U>::into_raw`][into_raw], on `U` ha de tenir la mateixa mida i alineament que `T`.
    /// Això és trivialment cert si `U` és `T`.
    /// Tingueu en compte que si `U` no és `T` però té la mateixa mida i alineació, bàsicament és com transmutar referències de diferents tipus.
    /// Consulteu [`mem::transmute`][transmute] per obtenir més informació sobre les restriccions que s`apliquen en aquest cas.
    ///
    /// L'usuari de `from_raw` s'ha d'assegurar que un valor específic de `T` només es caigui una vegada.
    ///
    /// Aquesta funció no és segura, ja que un ús inadequat pot provocar una inseguretat de la memòria, fins i tot si no s'accedeix mai a l `Arc<T>` retornat.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Converteix de nou en un `Arc` per evitar fuites.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Les trucades posteriors a `Arc::from_raw(x_ptr)` no serien segures per a la memòria.
    /// }
    ///
    /// // La memòria es va alliberar quan `x` va sortir de l'abast anterior, de manera que `x_ptr` ara penja.
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Invertiu el desplaçament per trobar ArcInner original.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Crea un nou punter [`Weak`] per a aquesta assignació.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Relaxed està bé perquè comprovem el valor al CAS següent.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // comproveu si el comptador feble és actualment "locked";si és així, gira.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: actualment aquest codi ignora la possibilitat de desbordament
            // a usize::MAX;en general, tant Rc com Arc s'han d'ajustar per fer front al desbordament.
            //

            // A diferència de l Clone(), necessitem que sigui una lectura Adquirir per sincronitzar amb l'escriptura provinent de `is_unique`, de manera que els esdeveniments anteriors a aquesta escriptura passin abans d'aquesta lectura.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Assegureu-vos que no creem un dèbil penjant
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Obté el nombre de punteres [`Weak`] a aquesta assignació.
    ///
    /// # Safety
    ///
    /// Aquest mètode per si mateix és segur, però utilitzar-lo correctament requereix una cura addicional.
    /// Un altre fil pot canviar el recompte feble en qualsevol moment, inclòs potencialment entre trucar a aquest mètode i actuar sobre el resultat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Aquesta afirmació és determinista perquè no hem compartit el `Arc` o el `Weak` entre fils.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Si el recompte feble està bloquejat actualment, el valor del recompte era 0 just abans de fer el bloqueig.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Obté el nombre de punteres (`Arc`) forts a aquesta assignació.
    ///
    /// # Safety
    ///
    /// Aquest mètode per si mateix és segur, però utilitzar-lo correctament requereix una cura addicional.
    /// Un altre fil pot canviar el recompte fort en qualsevol moment, inclòs potencialment entre trucar a aquest mètode i actuar sobre el resultat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Aquesta afirmació és determinista perquè no hem compartit l `Arc` entre fils.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Incrementa el nombre de referències fortes del `Arc<T>` associat amb el punter proporcionat.
    ///
    /// # Safety
    ///
    /// El punter s`ha d`haver obtingut mitjançant `Arc::into_raw` i la instància `Arc` associada ha de ser vàlida (és a dir
    /// el recompte fort ha de ser com a mínim 1) durant la durada d`aquest mètode.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Aquesta afirmació és determinista perquè no hem compartit l `Arc` entre fils.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Conserveu Arc, però no toqueu el recompte embolicant-lo a ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Ara augmenteu el recompte, però tampoc no deixeu anar el recompte nou
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Disminueix el nombre de referències fortes del `Arc<T>` associat amb el punter proporcionat per un.
    ///
    /// # Safety
    ///
    /// El punter s`ha d`haver obtingut mitjançant `Arc::into_raw` i la instància `Arc` associada ha de ser vàlida (és a dir
    /// el recompte fort ha de ser com a mínim 1) en invocar aquest mètode.
    /// Aquest mètode es pot utilitzar per alliberar l `Arc` final i emmagatzemar la còpia de seguretat, però **no s'hauria de** trucar després que s'hagi llançat l `Arc` final.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Aquestes afirmacions són deterministes perquè no hem compartit l `Arc` entre fils.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Aquesta inseguretat està bé perquè, mentre aquest arc estigui viu, estem garantits que el punter intern és vàlid.
        // A més, sabem que la pròpia estructura `ArcInner` és `Sync` perquè les dades internes també són `Sync`, així que estem bé prestant un punter immutable a aquests continguts.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Part no inclinada de `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Destruïu les dades en aquest moment, tot i que és possible que no alliberem l'assignació de la caixa (és possible que encara hi hagi indicadors febles).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Deixeu caure el feble ref que col・lectivament mantenen totes les referències fortes
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Retorna `true` si els dos `Arc`s apunten a la mateixa assignació (en una línia similar a [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Assigna un `ArcInner<T>` amb espai suficient per a un valor interior que no sigui possible de mida on el valor tingui el disseny proporcionat.
    ///
    /// La funció `mem_to_arcinner` es diu amb el punter de dades i ha de tornar un indicador (potencialment gros) per al `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Calculeu el disseny utilitzant el disseny del valor donat.
        // Anteriorment, el disseny es calculava sobre l'expressió `&*(ptr as* const ArcInner<T>)`, però això va crear una referència desalineada (vegeu #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Assigna un `ArcInner<T>` amb espai suficient per a un valor intern possiblement sense mida on el valor tingui el disseny proporcionat, retornant un error si falla l'assignació.
    ///
    ///
    /// La funció `mem_to_arcinner` es diu amb el punter de dades i ha de tornar un indicador (potencialment gros) per al `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Calculeu el disseny utilitzant el disseny del valor donat.
        // Anteriorment, el disseny es calculava sobre l'expressió `&*(ptr as* const ArcInner<T>)`, però això va crear una referència desalineada (vegeu #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Inicialitzeu ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Assigna un `ArcInner<T>` amb espai suficient per obtenir un valor interior sense mida.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Assigneu el `ArcInner<T>` mitjançant el valor indicat.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Copieu el valor com a bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Allibereu l'assignació sense deixar-ne caure el contingut
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Assigna un `ArcInner<[T]>` amb la longitud indicada.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Copieu els elements de la llesca a l'Arc assignat recentment <\[T\]>
    ///
    /// No és segur perquè la persona que truca ha de ser propietari o vincular `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Construeix un `Arc<[T]>` a partir d'un iterador conegut per tenir una mida determinada.
    ///
    /// El comportament no està definit si la mida no és correcta.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Protecció Panic mentre clona elements T.
        // En cas que es produeixi un panic, s`eliminaran els elements que s`hagin escrit al nou ArcInner i s`alliberarà la memòria.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Punter al primer element
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Tot bé.Oblideu-vos de la guàrdia perquè no alliberi el nou ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Especialització trait que s`utilitza per a `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Fa un clon del punter `Arc`.
    ///
    /// Això crea un altre punter a la mateixa assignació, augmentant el recompte de referència forta.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Utilitzar una ordenació relaxada està bé aquí, ja que el coneixement de la referència original impedeix que altres fils eliminin l`objecte per error.
        //
        // Com s`explica al [Boost documentation][1], augmentar el comptador de referència sempre es pot fer amb memory_order_relaxed: les noves referències a un objecte només es poden formar a partir d`una referència existent i passar una referència existent d`un fil a un altre ja ha de proporcionar la sincronització necessària.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Tanmateix, hem de protegir-nos dels recomptes massius en cas que algú estigui "mem: : oblidat" amb Arcs.
        // Si no ho fem, el recompte es pot desbordar i els usuaris faran servir després.
        // Ens saturem de forma racial fins a `isize::MAX`, suposant que no hi ha ~2 mil milions de fils que incrementin el recompte de referència alhora.
        //
        // Aquest branch mai no es prendrà en cap programa realista.
        //
        // Avortem perquè aquest programa és increïblement degenerat i no ens importa donar-li suport.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Fa una referència mutable al `Arc` donat.
    ///
    /// Si hi ha altres indicadors `Arc` o [`Weak`] a la mateixa assignació, `make_mut` crearà una assignació nova i invocarà [`clone`][clone] al valor intern per garantir la propietat única.
    /// Això també es coneix com a clonatge en escriptura.
    ///
    /// Tingueu en compte que això difereix del comportament de [`Rc::make_mut`], que desvincula els indicadors `Weak` restants.
    ///
    /// Vegeu també [`get_mut`][get_mut], que fallarà en lloc de clonar.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // No clonaré res
    /// let mut other_data = Arc::clone(&data); // No clonarà dades internes
    /// *Arc::make_mut(&mut data) += 1;         // Clona dades internes
    /// *Arc::make_mut(&mut data) += 1;         // No clonaré res
    /// *Arc::make_mut(&mut other_data) *= 2;   // No clonaré res
    ///
    /// // Ara `data` i `other_data` apunten a assignacions diferents.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Tingueu en compte que mantenim una referència forta i una referència feble.
        // Per tant, alliberar la nostra forta referència només no provocarà, per si sol, la distribució de la memòria.
        //
        // Utilitzeu Acquire per assegurar-nos que veiem qualsevol escriptura a `weak` que es produeixi abans de la versió de la versió (és a dir, disminueix) a `strong`.
        // Com que comptem amb un dèbil recompte, no hi ha cap possibilitat que el propi ArcInner es pugui repartir.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Existeix un altre punter fort, per tant, hem de clonar-lo.
            // Pre-assigneu memòria per permetre escriure directament el valor clonat.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Amb la relaxació n`hi ha prou perquè això és fonamentalment una optimització: sempre estem corrent amb la caiguda d`indicadors febles.
            // En el pitjor dels casos, acabem assignant innecessàriament un nou Arc.
            //

            // Vam eliminar l'última referència forta, però encara queden referències dèbils addicionals.
            // Mourem el contingut a un Arc nou i invalidarem la resta de referències febles.
            //

            // Tingueu en compte que no és possible que la lectura de `weak` produeixi usize::MAX (és a dir, bloquejat), ja que el recompte feble només el pot bloquejar un fil amb una referència forta.
            //
            //

            // Materialitzeu el nostre propi punter dèbil implícit, de manera que pugui netejar ArcInner segons sigui necessari.
            //
            let _weak = Weak { ptr: this.ptr };

            // Només puc robar les dades, només queden dèbils
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Érem l`única referència de cap de les dues classes;bump back back el fort recompte de ref.
            //
            this.inner().strong.store(1, Release);
        }

        // Igual que amb `get_mut()`, la inseguretat és correcta perquè la nostra referència era única per començar o es va convertir en una en clonar el contingut.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Retorna una referència mutable al `Arc` donat, si no hi ha cap altre punter `Arc` o [`Weak`] a la mateixa assignació.
    ///
    ///
    /// Retorna [`None`] en cas contrari, perquè no és segur mutar un valor compartit.
    ///
    /// Vegeu també [`make_mut`][make_mut], que permetrà [`clone`][clone] el valor intern quan hi hagi altres indicadors.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Aquesta inseguretat està bé, ja que estem garantits que el punter retornat és l'únic punter que es retornarà a T.
            // Es garanteix que el nostre recompte de referències és 1 en aquest moment i hem exigit que el propi Arc sigui `mut`, de manera que retornem l`única referència possible a les dades internes.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Retorna una referència mutable al `Arc` donat, sense cap comprovació.
    ///
    /// Vegeu també [`get_mut`], que és segur i fa les comprovacions adequades.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Els altres indicadors `Arc` o [`Weak`] de la mateixa assignació no es poden deixar de referenciar durant la durada del préstec retornat.
    ///
    /// Això és trivialment el cas si no existeixen aquests indicadors, per exemple immediatament després de `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Tenim cura de *no* crear una referència que cobreixi els camps "count", ja que això seria un àlies amb accés simultani als recomptes de referència (per exemple,
        // per `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Determineu si aquesta és la referència única (inclosos els referents febles) a les dades subjacents.
    ///
    ///
    /// Tingueu en compte que això requereix bloquejar el recompte feble de ref.
    fn is_unique(&mut self) -> bool {
        // bloquejar el recompte de punter dèbil si sembla que som l'únic titular del punter feble.
        //
        // L`etiqueta d`adquisició aquí garanteix una relació que succeeix abans amb qualsevol escriptura a `strong` (en particular a `Weak::upgrade`) abans de disminuir el recompte `weak` (mitjançant `Weak::drop`, que utilitza la versió).
        // Si la referència feble actualitzada mai no es va retirar, el CAS aquí fallarà, de manera que no ens importa sincronitzar.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Aquest ha de ser un `Acquire` per sincronitzar-lo amb el decrement del comptador `strong` a `drop`, l'únic accés que es produeix quan se suprimeix una referència excepte la darrera.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // L'escriptura de llançament aquí se sincronitza amb una lectura en `downgrade`, evitant efectivament que la lectura anterior de `strong` es produeixi després de l'escriptura.
            //
            //
            self.inner().weak.store(1, Release); // deixeu anar el pany
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Deixa caure el `Arc`.
    ///
    /// Això disminuirà el recompte de referència forta.
    /// Si el recompte de referències fortes arriba a zero, les altres referències (si n`hi ha) són [`Weak`], de manera que `drop` el valor intern.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // No imprimeix res
    /// drop(foo2);   // Imprimeix "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Com que `fetch_sub` ja és atòmic, no cal que ens sincronitzem amb altres fils, tret que eliminem l'objecte.
        // Aquesta mateixa lògica s'aplica a la `fetch_sub` següent per al recompte `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Aquesta tanca és necessària per evitar la reordenació de l`ús de les dades i la supressió de les dades.
        // Com que està marcat com `Release`, la disminució del recompte de referència se sincronitza amb aquesta tanca `Acquire`.
        // Això significa que l'ús de les dades es produeix abans de disminuir el recompte de referència, que passa abans d'aquesta tanca, que passa abans de la supressió de les dades.
        //
        // Com s`explica al [Boost documentation][1],
        //
        // > És important fer complir qualsevol possible accés a l'objecte en un
        // > fil (a través d'una referència existent) per *passar abans que* se suprimeixi
        // > l'objecte en un fil diferent.Això s`aconsegueix amb un "release"
        // > operació després de deixar caure una referència (qualsevol accés a l'objecte
        // > a través d'aquesta referència, òbviament, ha de passar abans), i un
        // > "acquire" operació abans de suprimir l'objecte.
        //
        // En particular, tot i que el contingut d'un Arc sol ser immutable, és possible que les escriptures interiors es facin a Mutex<T>.
        // Com que no s`adquireix un Mutex quan s`esborra, no podem confiar en la seva lògica de sincronització per fer visibles les escriptures del fil A per a un destructor que s`executa al fil B.
        //
        //
        // Tingueu en compte també que la tanca Acquire aquí probablement es podria substituir per una càrrega Acquire, que podria millorar el rendiment en situacions molt disputades.Vegeu [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Intenteu reduir el `Arc<dyn Any + Send + Sync>` a un tipus concret.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Construeix un nou `Weak<T>`, sense assignar cap memòria.
    /// Trucar a [`upgrade`] pel valor de retorn sempre proporciona [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Tipus d'ajuda per permetre l'accés als recomptes de referència sense fer cap afirmació sobre el camp de dades.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Retorna un punter en brut a l'objecte `T` que apunta aquest `Weak<T>`.
    ///
    /// El punter només és vàlid si hi ha algunes referències fortes.
    /// El punter pot estar penjat, sense alinear o fins i tot [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Tots dos apunten al mateix objecte
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // El fort aquí el manté viu, de manera que encara podem accedir a l`objecte.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Però ja no.
    /// // Podem fer weak.as_ptr(), però accedir al punter comportaria un comportament indefinit.
    /// // assert_eq! ("hola", insegur {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Si el punter penja, retornem la sentinella directament.
            // No pot ser una adreça de càrrega útil vàlida, ja que la càrrega útil està almenys tan alineada com ArcInner (usize).
            ptr as *const T
        } else {
            // SEGURETAT: si is_dangling retorna false, el punter no es pot referenciar.
            // És possible que la càrrega útil es redueixi en aquest moment i hem de mantenir la procedència, de manera que utilitzeu la manipulació del punter en brut.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Consumeix el `Weak<T>` i el converteix en un punter en brut.
    ///
    /// Això converteix el punter feble en un punter cru, tot i que es conserva la propietat d'una referència feble (el recompte feble no es modifica amb aquesta operació).
    /// Es pot tornar a convertir en el `Weak<T>` amb [`from_raw`].
    ///
    /// S'apliquen les mateixes restriccions d'accés a l'objectiu del punter que amb [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Converteix un punter en brut creat prèviament per [`into_raw`] en `Weak<T>`.
    ///
    /// Es pot utilitzar per obtenir una referència segura (trucant més tard a [`upgrade`]) o per localitzar el recompte feble deixant caure el `Weak<T>`.
    ///
    /// Adopta la propietat d`una referència feble (a excepció dels indicadors creats per [`new`], ja que aquests no posseeixen res; el mètode encara funciona).
    ///
    /// # Safety
    ///
    /// El punter deu haver estat originari del [`into_raw`] i encara ha de posseir la seva possible referència feble.
    ///
    /// Es permet que el recompte fort sigui 0 en el moment de trucar a això.
    /// Tot i això, es fa propietari d'una referència feble representada actualment com a punter en brut (el recompte feble no es modifica amb aquesta operació) i, per tant, s'ha de combinar amb una trucada anterior a [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Disminuir l`últim recompte feble.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Vegeu Weak::as_ptr per veure el context de com es deriva el punter d'entrada.

        let ptr = if is_dangling(ptr as *mut T) {
            // Això és un dèbil penjant.
            ptr as *mut ArcInner<T>
        } else {
            // En cas contrari, estem garantits que el punter provenia d`un punt feble que no té res.
            // SEGURETAT: data_offset és segur de trucar, ja que ptr fa referència a un T. real (potencialment caigut).
            let offset = unsafe { data_offset(ptr) };
            // Per tant, invertim el desplaçament per obtenir tot el RcBox.
            // SEGURETAT: el punter es va originar en un punt feble, de manera que aquest desplaçament és segur.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SEGURETAT: ara hem recuperat el punter feble original, de manera que podem crear el punt feble.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Intenta actualitzar el punter `Weak` a un [`Arc`], retardant la caiguda del valor intern si té èxit.
    ///
    ///
    /// Retorna [`None`] si des de llavors s'ha perdut el valor intern.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Destrueix tots els indicadors forts.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Utilitzem un bucle CAS per incrementar el recompte fort en lloc d`un fetch_add, ja que aquesta funció mai hauria de prendre el recompte de referència de zero a un.
        //
        //
        let inner = self.inner()?;

        // Càrrega relaxada perquè qualsevol escriptura de 0 que podem observar deixa el camp en un estat permanentment zero (per tant, una lectura "stale" de 0 està bé) i qualsevol altre valor es confirma a través del CAS a continuació.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Vegeu els comentaris a `Arc::clone` per saber per què ho fem (per a `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaxed està bé per al cas del fracàs perquè no tenim cap expectativa sobre el nou estat.
            // L`adquisició és necessària perquè el cas d`èxit es sincronitzi amb `Arc::new_cyclic`, quan el valor intern es pot inicialitzar després de crear ja les referències `Weak`.
            // En aquest cas, esperem observar el valor totalment inicialitzat.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // nul marcat anteriorment
                Err(old) => n = old,
            }
        }
    }

    /// Obté el nombre de punteres (`Arc`) forts que apunten a aquesta assignació.
    ///
    /// Si `self` es va crear amb [`Weak::new`], tornarà 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Obté una aproximació del nombre de punteres `Weak` que apunten a aquesta assignació.
    ///
    /// Si `self` es va crear amb [`Weak::new`] o si no queden indicadors forts, tornarà 0.
    ///
    /// # Accuracy
    ///
    /// A causa dels detalls de la implementació, el valor retornat es pot desactivar en 1 en qualsevol direcció quan altres fils manipulin qualsevol `Arc` o`Debil` que apuntin a la mateixa assignació.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Com que vam observar que hi havia almenys un punter fort després de llegir el recompte feble, sabem que la referència dèbil implícita (present sempre que hi ha alguna referència forta) encara existia quan observàvem el recompte feble i, per tant, podem restar-lo amb seguretat.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Retorna `None` quan el punter està penjat i no hi ha `ArcInner` assignat, (és a dir, quan aquest `Weak` va ser creat per `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Tenim cura de *no* crear una referència que cobreixi el camp "data", ja que es pot mutar simultàniament (per exemple, si es deixa caure l'últim `Arc`, el camp de dades es deixarà caure al seu lloc)
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Retorna `true` si els dos `Debils` apunten a la mateixa assignació (similar a [`ptr::eq`]), o si tots dos no assenyalen cap assignació (perquè es van crear amb `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Com que això compara els indicadors, significa que `Weak::new()` serà igual, encara que no assenyali cap assignació.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Comparant `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Fa un clon del punter `Weak` que apunta a la mateixa assignació.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Vegeu els comentaris a Arc::clone() per saber per què es relaxa.
        // Això pot fer servir un fetch_add (ignorant el bloqueig) perquè el recompte feble només es bloqueja on no hi ha *altres* indicadors febles.
        //
        // (Per tant, no podem executar aquest codi en aquest cas).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Vegeu els comentaris a Arc::clone() per saber per què ho fem (per a mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Construeix un nou `Weak<T>`, sense assignar memòria.
    /// Trucar a [`upgrade`] pel valor de retorn sempre proporciona [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Deixa caure el punter `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // No imprimeix res
    /// drop(foo);        // Imprimeix "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Si ens assabentem que érem l`últim punter feble, aleshores és hora de distribuir completament les dades.Vegeu el debat a Arc::drop() sobre els ordres de memòria
        //
        // No és necessari comprovar l`estat de bloqueig aquí, perquè el recompte feble només es pot bloquejar si hi hagués precisament un ref feble, és a dir, que la caiguda només podria executar-se activat el ref feble restant, que només pot ocórrer després d`alliberar el bloqueig.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Estem fent aquesta especialització aquí, i no com una optimització més general a `&T`, perquè d'una altra manera afegiria un cost a totes les comprovacions d'igualtat de les referències.
/// Suposem que `Arc`s s'utilitza per emmagatzemar valors grans, que són lents a clonar, però també pesats per comprovar si hi ha igualtat, cosa que fa que aquest cost es pagui més fàcilment.
///
/// També és més probable que tingueu dos clons `Arc`, que apunten al mateix valor, que dos `&T`.
///
/// Només ho podem fer quan `T: Eq` com a `PartialEq` pot ser deliberadament irreflexiu.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Igualtat per a dos `Arc`s.
    ///
    /// Dos `Arc` són iguals si els seus valors interns són iguals, fins i tot si s`emmagatzemen en una assignació diferent.
    ///
    /// Si `T` també implementa `Eq` (que implica reflexivitat d'igualtat), dos `Arc`s que apunten a la mateixa assignació són sempre iguals.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Desigualtat per a dos `Arc`s.
    ///
    /// Dos `Arc`s són desiguals si els seus valors interiors són desiguals.
    ///
    /// Si `T` també implementa `Eq` (que implica reflexivitat d'igualtat), dos `Arc`s que apunten al mateix valor mai són desiguals.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Comparació parcial per a dos `Arc`s.
    ///
    /// Els dos es comparen trucant a `partial_cmp()` sobre els seus valors interns.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Comparació inferior a dos `Arc`s.
    ///
    /// Els dos es comparen trucant a `<` sobre els seus valors interns.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Comparació "inferior o igual a" per a dos "Arc".
    ///
    /// Els dos es comparen trucant a `<=` sobre els seus valors interns.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Comparació superior a la de dos `Arc`s.
    ///
    /// Els dos es comparen trucant a `>` sobre els seus valors interns.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Comparació "superior o igual a" per a dos "Arc".
    ///
    /// Els dos es comparen trucant a `>=` sobre els seus valors interns.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Comparació de dos `Arc`s.
    ///
    /// Els dos es comparen trucant a `cmp()` sobre els seus valors interns.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Crea un `Arc<T>` nou, amb el valor `Default` per a `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Assigneu una llesca comptada amb referències i empleneu-la clonant els elements de "v".
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Assigneu un `str` comptable amb referències i copieu-hi `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Assigneu un `str` comptable amb referències i copieu-hi `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Moveu un objecte encaixat a una assignació nova, comptada amb referències.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Assigneu una llesca comptada amb referències i moveu-hi els elements de `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Permet que el Vec alliberi la seva memòria, però no en destrueixi el contingut
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Agafa cada element del `Iterator` i el recull en un `Arc<[T]>`.
    ///
    /// # Característiques de rendiment
    ///
    /// ## El cas general
    ///
    /// En el cas general, la recopilació a `Arc<[T]>` es realitza recopilant primer a un `Vec<T>`.És a dir, quan escriviu el següent:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// això es comporta com si escrivíssim:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // El primer conjunt d'assignacions passa aquí.
    ///     .into(); // Aquí es fa una segona assignació per a `Arc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Això s'assignarà tantes vegades com calgui per construir el `Vec<T>` i, a continuació, s'assignarà una vegada per convertir el `Vec<T>` en el `Arc<[T]>`.
    ///
    ///
    /// ## Iteradors de longitud coneguda
    ///
    /// Quan el vostre `Iterator` implementi `TrustedLen` i tingui una mida exacta, es farà una única assignació per al `Arc<[T]>`.Per exemple:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Aquí només hi ha una assignació única.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Especialització trait que s`utilitza per recollir a `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // És el cas d`un iterador `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SEGURETAT: hem de garantir que l'iterador tingui una longitud exacta i que tinguem.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Torneu a la implementació normal.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Obteniu el desplaçament dins d'un `ArcInner` per a la càrrega útil darrere d'un punter.
///
/// # Safety
///
/// El punter ha d'assenyalar (i tenir metadades vàlides per a) una instància vàlida de T prèviament, però es pot deixar caure la T.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Alineeu el valor sense mida al final de l'ArcInner.
    // Com que RcBox és repr(C), sempre serà l'últim camp de la memòria.
    // SEGURETAT: atès que els únics tipus no dimensionats possibles són les llesques, objectes trait,
    // i tipus externs, el requisit de seguretat d`entrada és actualment suficient per satisfer els requisits d`alineament_de_val_raw;es tracta d`un detall d`implementació del llenguatge que pot no confiar-se fora de std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}