//! Una vista de mida dinàmica en una seqüència contigua, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Les llesques són una vista d'un bloc de memòria representat com a punter i longitud.
//!
//! ```
//! // tallant un Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // coaccionar una matriu a una llesca
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Les parts poden ser mutables o compartides.
//! El tipus de segment compartit és `&[T]`, mentre que el tipus de segment modificable és `&mut [T]`, on `T` representa el tipus d`element.
//! Per exemple, podeu mutar el bloc de memòria al qual apunta un segment mutable:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! A continuació, es detallen algunes de les coses que conté aquest mòdul:
//!
//! ## Structs
//!
//! Hi ha diverses estructures útils per a talls, com ara [`Iter`], que representa la iteració sobre una talla.
//!
//! ## Implementacions de Trait
//!
//! Hi ha diverses implementacions de traits comú per a talls.Alguns exemples inclouen:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], per a talls el tipus d'element dels quals són [`Eq`] o [`Ord`].
//! * [`Hash`] - per a les llesques el tipus d'element de les quals és [`Hash`].
//!
//! ## Iteration
//!
//! Les llesques implementen `IntoIterator`.L'iterador proporciona referències als elements de la porció.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! La part mutable proporciona referències mutables als elements:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Aquest iterador proporciona referències mutables als elements de la llesca, de manera que mentre el tipus d`element de la llesca és `i32`, el tipus d`element de l`iterador és `&mut i32`.
//!
//!
//! * [`.iter`] i [`.iter_mut`] són els mètodes explícits per retornar els iteradors per defecte.
//! * Altres mètodes que retornen els iteradors són [`.split`], [`.splitn`], [`.chunks`], [`.windows`] i molt més.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Molts dels usos d`aquest mòdul només s`utilitzen a la configuració de la prova.
// És més net només desactivar l'advertiment unused_imports que solucionar-los.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Mètodes bàsics d`extensió de llesques
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) necessari per a la implementació de la macro `vec!` durant les proves NB, consulteu el mòdul `hack` d`aquest fitxer per obtenir més detalls.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) necessari per a la implementació de `Vec::clone` durant les proves NB, consulteu el mòdul `hack` d`aquest fitxer per obtenir més detalls.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Amb cfg(test) `impl [T]` no està disponible, aquestes tres funcions són en realitat mètodes que estan a `impl [T]` però no a `core::slice::SliceExt`, hem de subministrar aquestes funcions per a la prova `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // No hi hauríem d'afegir atributs inline, ja que s'utilitza principalment a la macro `vec!` i provoca una regressió perfecta.
    // Vegeu #71204 per obtenir resultats sobre debats i perfeccionament.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // els elements es van marcar inicialitzats al bucle següent
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) és necessari perquè LLVM elimini les comprovacions de límits i té un codi millor que zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // el vec es va assignar i inicialitzar a almenys aquesta longitud.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // assignat més amunt amb la capacitat de `s` i inicialitzeu-lo a `s.len()` a ptr::copy_to_non_overlapping a continuació.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Ordena la llesca.
    ///
    /// Aquest tipus és estable (és a dir, no reordena elements iguals) i *O*(*n*\*log(* n*)) en el pitjor dels casos.
    ///
    /// Si escau, es prefereix l'ordenació inestable perquè generalment és més ràpida que l'ordenació estable i no assigna memòria auxiliar.
    /// Vegeu [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Implementació actual
    ///
    /// L`algorisme actual és un tipus de combinació iterativa i adaptativa inspirat en [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Està dissenyat per ser molt ràpid en els casos en què la llesca estigui gairebé ordenada o estigui formada per dues o més seqüències ordenades concatenades una darrere l`altra.
    ///
    ///
    /// A més, assigna emmagatzematge temporal a la meitat de la mida de `self`, però per a talls curts s`utilitza un tipus d`inserció que no s`assigna.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Ordena el segment amb una funció de comparació.
    ///
    /// Aquest tipus és estable (és a dir, no reordena elements iguals) i *O*(*n*\*log(* n*)) en el pitjor dels casos.
    ///
    /// La funció de comparador ha de definir una ordenació total dels elements de la part.Si l`ordenació no és total, l`ordre dels elements no s`especifica.
    /// Un ordre és un ordre total si és així (per a tots els `a`, `b` i `c`):
    ///
    /// * total i antisimètric: exactament un de `a < b`, `a == b` o `a > b` és cert, i
    /// * transitiva, `a < b` i `b < c` implica `a < c`.El mateix s`ha de mantenir tant per a `==` com per a `>`.
    ///
    /// Per exemple, mentre que [`f64`] no implementa [`Ord`] perquè `NaN != NaN`, podem utilitzar `partial_cmp` com a funció d'ordenació quan sabem que el segment no conté cap `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Si escau, es prefereix l'ordenació inestable perquè generalment és més ràpida que l'ordenació estable i no assigna memòria auxiliar.
    /// Vegeu [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Implementació actual
    ///
    /// L`algorisme actual és un tipus de combinació iterativa i adaptativa inspirat en [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Està dissenyat per ser molt ràpid en els casos en què la llesca estigui gairebé ordenada o estigui formada per dues o més seqüències ordenades concatenades una darrere l`altra.
    ///
    /// A més, assigna emmagatzematge temporal a la meitat de la mida de `self`, però per a talls curts s`utilitza un tipus d`inserció que no s`assigna.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ordenació inversa
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Ordena el segment amb una funció d`extracció de tecles.
    ///
    /// Aquest tipus és estable (és a dir, no reordena elements iguals) i *O*(*m*\* * n *\* log(*n*)) en el pitjor dels casos, on la funció de tecla és *O*(*m*).
    ///
    /// Per a funcions de tecles costoses (per exemple,
    /// funcions que no són simples accessos a propietats ni operacions bàsiques), és probable que [`sort_by_cached_key`](slice::sort_by_cached_key) sigui significativament més ràpid, ja que no recomputa les claus dels elements.
    ///
    ///
    /// Si escau, es prefereix l'ordenació inestable perquè generalment és més ràpida que l'ordenació estable i no assigna memòria auxiliar.
    /// Vegeu [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Implementació actual
    ///
    /// L`algorisme actual és un tipus de combinació iterativa i adaptativa inspirat en [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Està dissenyat per ser molt ràpid en els casos en què la llesca estigui gairebé ordenada o estigui formada per dues o més seqüències ordenades concatenades una darrere l`altra.
    ///
    /// A més, assigna emmagatzematge temporal a la meitat de la mida de `self`, però per a talls curts s`utilitza un tipus d`inserció que no s`assigna.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Ordena el segment amb una funció d`extracció de tecles.
    ///
    /// Durant l`ordenació, la funció de tecla només es diu una vegada per element.
    ///
    /// Aquest tipus és estable (és a dir, no reordena elements iguals) i *O*(*m*\* * n *+* n *\* log(*n*)) en el pitjor dels casos, on la funció de tecla és *O*(*m*) .
    ///
    /// Per a funcions de tecles simples (per exemple, funcions que són accessos a propietats o operacions bàsiques), és probable que [`sort_by_key`](slice::sort_by_key) sigui més ràpid.
    ///
    /// # Implementació actual
    ///
    /// L`algoritme actual es basa en [pattern-defeating quicksort][pdqsort] d`Orson Peters, que combina el cas mitjà ràpid d`escala ràpida aleatòria amb el pitjor cas ràpid d`escala forta, alhora que s`aconsegueix un temps lineal en talls amb determinats patrons.
    /// Utilitza certa aleatorització per evitar casos degenerats, però amb un seed fix per proporcionar sempre un comportament determinista.
    ///
    /// En el pitjor dels casos, l'algorisme assigna emmagatzematge temporal en un `Vec<(K, usize)>` de la longitud del tall.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Macro auxiliar per indexar el nostre vector pel tipus més petit possible, per reduir l`assignació.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Els elements de `indices` són únics, ja que estan indexats, de manera que qualsevol tipus serà estable respecte al segment original.
                // Aquí fem servir `sort_unstable` perquè requereix menys assignació de memòria.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Copia `self` en un nou `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Aquí, `s` i `x` es poden modificar independentment.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Copia `self` en un nou `Vec` amb un assignador.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Aquí, `s` i `x` es poden modificar independentment.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, consulteu el mòdul `hack` d`aquest fitxer per obtenir més informació.
        hack::to_vec(self, alloc)
    }

    /// Converteix `self` en un vector sense clons ni assignació.
    ///
    /// El vector resultant es pot tornar a convertir en una caixa mitjançant `Vec<T>Mètode `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` ja no es pot utilitzar perquè s'ha convertit en `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, consulteu el mòdul `hack` d`aquest fitxer per obtenir més informació.
        hack::into_vec(self)
    }

    /// Crea un vector repetint un segment `n` vegades.
    ///
    /// # Panics
    ///
    /// Aquesta funció serà panic si la capacitat es desbordaria.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// Un panic en cas de desbordament:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Si `n` és més gran que zero, es pot dividir com a `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` és el nombre representat pel bit '1' més esquerre de `n` i `rem` és la part restant de `n`.
        //
        //

        // Utilitzant `Vec` per accedir a `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` la repetició es fa duplicant els temps "expn" de `buf`.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Si és `m > 0`, queden bits fins al '1' més a l'esquerra.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` té una capacitat de `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) la repetició es fa copiant les primeres repeticions `rem` del propi `buf`.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Això no es solapa des de `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` és igual a `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Aplana una llesca de `T` en un valor únic `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Aplana una llesca de `T` en un valor únic `Self::Output`, col・locant un separador determinat entre cadascun.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Aplana una llesca de `T` en un valor únic `Self::Output`, col・locant un separador determinat entre cadascun.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Retorna un vector que conté una còpia d'aquest segment on cada byte està assignat al seu equivalent en majúscules ASCII.
    ///
    ///
    /// Les lletres ASCII 'a' a 'z' s`assignen a 'A' a 'Z', però les lletres que no són ASCII no canvien.
    ///
    /// Per posar en majúscules el valor al seu lloc, utilitzeu [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Retorna un vector que conté una còpia d'aquest segment on cada byte està assignat al seu equivalent en minúscules ASCII.
    ///
    ///
    /// Les lletres ASCII 'A' a 'Z' s`assignen a 'a' a 'z', però les lletres que no són ASCII no canvien.
    ///
    /// Per reduir el valor al seu lloc, utilitzeu [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Extensió traits per a segmentacions sobre tipus específics de dades
////////////////////////////////////////////////////////////////////////////////

/// Helper trait per a [`[T]: : concat`](slice::concat).
///
/// Note: el paràmetre tipus `Item` no s'utilitza en aquest trait, però permet que els impls siguin més genèrics.
/// Sense ell, obtenim aquest error:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Això es deu al fet que podrien existir tipus `V` amb múltiples implements `Borrow<[_]>`, de manera que s`aplicarien diversos tipus `T`:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// El tipus resultant després de la concatenació
    type Output;

    /// Implementació de [`[T]: : concat`](slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Ajudant trait per a [`[T]: : join`](llesca::join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// El tipus resultant després de la concatenació
    type Output;

    /// Implementació de [`[T]: : join`](slice::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Implementacions estàndard trait per a talls
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // deixeu anar qualsevol objectiu que no se sobreescrigui
        target.truncate(self.len());

        // target.len <= self.len a causa del truncat anterior, de manera que les llesques aquí sempre estan dins dels límits.
        //
        let (init, tail) = self.split_at(target.len());

        // torneu a utilitzar els valors continguts allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Insereix `v[0]` a la seqüència `v[1..]` prèviament ordenada de manera que `v[..]` sencer s'ordeni.
///
/// Aquesta és la subrutina integral de la classificació per inserció.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Aquí hi ha tres maneres d'implementar la inserció:
            //
            // 1. Canvieu els elements adjacents fins que el primer arribi al seu destí final.
            //    Tanmateix, d`aquesta manera copiem les dades més del necessari.
            //    Si els elements són estructures grans (costoses de copiar), aquest mètode serà lent.
            //
            // 2. Iterar fins que es trobi el lloc adequat per al primer element.
            // A continuació, canvieu els elements que la succeeixen per deixar lloc i, finalment, col・loqueu-lo al forat restant.
            // Aquest és un bon mètode.
            //
            // 3. Copieu el primer element en una variable temporal.Iterar fins que es trobi el lloc adequat.
            // Mentre avancem, copieu tots els elements recorreguts a la ranura anterior.
            // Finalment, copieu les dades de la variable temporal al forat restant.
            // Aquest mètode és molt bo.
            // Els punts de referència van demostrar un rendiment lleugerament millor que amb el segon mètode.
            //
            // Tots els mètodes es van comparar i el tercer va mostrar els millors resultats.Així que l`hem triat.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // `hole` fa un seguiment de l`estat intermedi del procés d`inserció, que té dos propòsits:
            // 1. Protegeix la integritat de `v` de panics a `is_less`.
            // 2. Omple el forat restant de `v` al final.
            //
            // Seguretat Panic:
            //
            // Si `is_less` panics en algun moment del procés, `hole` caurà i omplirà el forat de `v` amb `tmp`, garantint així que `v` encara conté tots els objectes que tenia inicialment exactament una vegada.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` es deixa caure i, per tant, copia `tmp` al forat restant de `v`.
        }
    }

    // Quan es deixa caure, còpies de `src` a `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Combina les sèries `v[..mid]` i `v[mid..]` no decreixents utilitzant `buf` com a emmagatzematge temporal i emmagatzema el resultat a `v[..]`.
///
/// # Safety
///
/// Les dues parts no han de ser buides i `mid` ha de tenir límits.
/// El buffer `buf` ha de tenir el temps suficient per contenir una còpia de la part més curta.
/// A més, `T` no ha de ser de tipus zero.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // El procés de combinació primer copia la versió més curta a `buf`.
    // A continuació, fa un seguiment de l'execució recentment copiada i de l'execució més llarga cap endavant (o cap enrere), comparant els següents elements no consumits i copiant el menor (o superior) a `v`.
    //
    // Tan bon punt es consumeixi completament el període més curt, el procés es realitzarà.Si es consumeix primer la tirada més llarga, hem de copiar tot el que queda de la tirada més curta al forat restant de `v`.
    //
    // `hole` sempre fa un seguiment de l`estat intermedi del procés, que té dos propòsits:
    // 1. Protegeix la integritat de `v` de panics a `is_less`.
    // 2. Omple el forat restant a `v` si es consumeix primer el llarg termini.
    //
    // Seguretat Panic:
    //
    // Si `is_less` panics en algun moment del procés, `hole` caurà i omplirà el forat de `v` amb el rang no consumit de `buf`, garantint així que `v` encara manté tots els objectes que inicialment tenia exactament una vegada.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // La carrera a l'esquerra és més curta.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Inicialment, aquests indicadors apunten als inicis de les seves matrius.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Consumeix el costat menor.
            // Si és igual, preferiu la cursa esquerra per mantenir l'estabilitat.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // La tirada correcta és més curta.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Inicialment, aquests indicadors apunten més enllà dels extrems de les seves matrius.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Consumeix el costat més gran.
            // Si és igual, preferiu la carrera adequada per mantenir l`estabilitat.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Finalment, `hole` es deixa caure.
    // Si la cursa més curta no es va consumir completament, tot el que en quedi quedarà copiat al forat de `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Quan es deixa caure, copia l`interval `start..end` a `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` no és de tipus zero, per tant, està bé dividir per la seva mida.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Aquest tipus de combinació manlleva algunes (però no totes) idees de TimSort, que es descriu detalladament [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// L`algorisme identifica subseqüències estrictament descendents i no descendents, que s`anomenen curses naturals.Hi ha una pila d`execucions pendents encara per fusionar.
/// Cadascuna de les proves que es troben recentment s`enfonsa a la pila i, a continuació, es combinen alguns parells de proves adjacents fins que es compleixen aquests dos invariants:
///
/// 1. per a cada `i` de `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. per a cada `i` de `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Els invariants asseguren que el temps d'execució total sigui *O*(*n*\*log(* n*)) en el pitjor dels casos.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Les llesques de fins a aquesta longitud s`ordenen mitjançant la classificació per inserció.
    const MAX_INSERTION: usize = 20;
    // Les tirades molt curtes s`amplien mitjançant la classificació per inserció per abastar almenys tants elements.
    const MIN_RUN: usize = 10;

    // L`ordenació no té un comportament significatiu en els tipus de mida zero.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Les matrius curtes s`ordenen al lloc mitjançant la classificació per inserció per evitar assignacions.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Assigneu un buffer per utilitzar-lo com a memòria de zero.Mantenim la longitud 0 perquè puguem conservar-hi còpies superficials del contingut de `v` sense arriscar-nos a que els dtors funcionin amb còpies si `is_less` panics.
    //
    // En combinar dues tirades ordenades, aquest buffer conté una còpia de la tirada més curta, que sempre tindrà una longitud màxima de `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Per tal d`identificar carreres naturals a `v`, la recorrem cap enrere.
    // Podria semblar una decisió estranya, però tingueu en compte el fet que les fusions més sovint van en la direcció oposada (forwards).
    // Segons els punts de referència, la fusió cap endavant és lleugerament més ràpida que la de cap enrere.
    // Per concloure, identificar carreres recorrent cap enrere millora el rendiment.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Cerqueu la següent cursa natural i invertiu-la si és estrictament descendent.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Inseriu alguns elements més a la carrera si és massa curt.
        // La classificació per inserció és més ràpida que la classificació per combinació en seqüències curtes, de manera que això millora significativament el rendiment.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Premeu aquesta carrera a la pila.
        runs.push(Run { start, len: end - start });
        end = start;

        // Combineu alguns parells de carreres adjacents per satisfer els invariants.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Finalment, ha de romandre exactament una carrera a la pila.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Examina la pila de carreres i identifica el següent parell de carreres a combinar.
    // Més concretament, si es retorna `Some(r)`, això vol dir que `runs[r]` i `runs[r + 1]` s'han de combinar a continuació.
    // Si l'algoritme ha de continuar creant una nova execució, es retorna `None`.
    //
    // TimSort és famós per les seves implementacions de buggy, tal com es descriu aquí:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // L'essència de la història és: hem d'aplicar els invariants a les quatre primeres tirades de la pila.
    // Aplicar-los a les tres primeres parts no és suficient per assegurar-se que els invariants continuaran mantenint-se durant *totes* les execucions de la pila.
    //
    // Aquesta funció comprova correctament els invariants de les quatre primeres proves.
    // A més, si la tirada superior comença a l`índex 0, sempre exigirà una operació de combinació fins que la pila quedi totalment col・lapsada, per tal de completar l`ordenació.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}