//! Una cadena cultivable codificada per UTF-8.
//!
//! Aquest mòdul conté el tipus [`String`], el [`ToString`] trait per convertir a cadenes i diversos tipus d'errors que poden resultar de treballar amb ["Cadena"].
//!
//!
//! # Examples
//!
//! Hi ha diverses maneres de crear un [`String`] nou a partir d'una cadena literal:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Podeu crear un [`String`] nou a partir d`un existent concatenant-lo amb
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Si teniu un vector de bytes UTF-8 vàlids, podeu fer-ne un [`String`].També podeu fer el contrari.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Sabem que aquests bytes són vàlids, de manera que farem servir `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Una cadena cultivable codificada per UTF-8.
///
/// El tipus `String` és el tipus de cadena més comú que té la propietat sobre el contingut de la cadena.Té una estreta relació amb el seu homòleg prestat, el primitiu [`str`].
///
/// # Examples
///
/// Podeu crear un `String` a partir de [a literal string][`str`] amb [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Podeu afegir un [`char`] a un `String` amb el mètode [`push`] i afegir un [`&str`] amb el mètode [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Si teniu un vector de bytes UTF-8, podeu crear-ne un amb el mètode [`from_utf8`]:
///
/// ```
/// // alguns bytes, en un vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Sabem que aquests bytes són vàlids, de manera que farem servir `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// Les "cadenes" sempre són vàlides UTF-8.Això té algunes implicacions, la primera de les quals és que si necessiteu una cadena que no sigui UTF-8, tingueu en compte [`OsString`].És similar, però sense la restricció UTF-8.La segona implicació és que no es pot indexar en un `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Es pretén que la indexació sigui una operació en temps constant, però la codificació UTF-8 no ens permet fer-ho.A més, no està clar quin tipus de coses hauria de retornar l`índex: un byte, un punt de codi o un clúster de grafemes.
/// Els mètodes [`bytes`] i [`chars`] retornen iteradors durant els dos primers, respectivament.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// Implementació de `String`s [`Deref`] `<Target=str>', i hereta tots els mètodes de [`str`].A més, això vol dir que podeu passar un `String` a una funció que prengui un [`&str`] utilitzant un signe i (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Això crearà un [`&str`] a partir de l `String` i el passarà. Aquesta conversió és molt barata i, per tant, en general, les funcions acceptaran [`&str`] s com a arguments tret que necessitin un `String` per alguna raó específica.
///
/// En certs casos, Rust no té prou informació per fer aquesta conversió, coneguda com a coerció [`Deref`].A l'exemple següent, una secció de cadena [`&'a str`][`&str`] implementa el trait `TraitExample` i la funció `example_func` pren qualsevol cosa que implementi el trait.
/// En aquest cas, Rust hauria de fer dues conversions implícites, cosa que Rust no té els mitjans per fer.
/// Per aquest motiu, l'exemple següent no es compilarà.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Hi ha dues opcions que funcionarien.El primer seria canviar la línia `example_func(&example_string);` per `example_func(example_string.as_str());`, utilitzant el mètode [`as_str()`] per extreure explícitament el segment de cadena que conté la cadena.
/// La segona forma canvia `example_func(&example_string);` a `example_func(&*example_string);`.
/// En aquest cas, estem desferenciant un `String` a un [`str`][`&str`] i, a continuació, referenciem el [`str`][`&str`] a [`&str`].
/// La segona forma és més idiomàtica, però tots dos treballen per fer la conversió explícitament en lloc de confiar en la conversió implícita.
///
/// # Representation
///
/// Un `String` està format per tres components: un punter a alguns bytes, una longitud i una capacitat.El punter apunta a un buffer intern que `String` utilitza per emmagatzemar les seves dades.La longitud és el nombre de bytes emmagatzemats actualment al buffer i la capacitat és la mida del buffer en bytes.
///
/// Com a tal, la longitud sempre serà inferior o igual a la capacitat.
///
/// Aquest buffer sempre s`emmagatzema a l`emmagatzematge dinàmic.
///
/// Podeu veure-les amb els mètodes [`as_ptr`], [`len`] i [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Actualitzeu-ho quan vec_into_raw_parts s'estabilitzi.
/// // Eviteu deixar caure automàticament les dades de la cadena
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // la història té dinou bytes
/// assert_eq!(19, len);
///
/// // Podem reconstruir una cadena a partir de ptr, len i capacitat.
/// // Tot això no és segur, ja que som responsables de garantir que els components siguin vàlids:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Si un `String` té prou capacitat, no s'hi assignarà cap element afegit.Per exemple, tingueu en compte aquest programa:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Això produirà el següent:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Al principi, no tenim cap memòria assignada, però a mesura que anem afegint-la a la cadena, augmenta la seva capacitat adequadament.Si utilitzem el mètode [`with_capacity`] per assignar la capacitat correcta inicialment:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Acabem amb una sortida diferent:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Aquí no cal assignar més memòria dins del bucle.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Un possible valor d'error en convertir un `String` d'un byte UTF-8 vector.
///
/// Aquest tipus és el tipus d'error del mètode [`from_utf8`] a [`String`].
/// Està dissenyat de manera que eviti acuradament reassignacions: el mètode [`into_bytes`] retornarà el byte vector que es va utilitzar en l'intent de conversió.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// El tipus [`Utf8Error`] proporcionat per [`std::str`] representa un error que es pot produir en convertir un segment de [`u8`] s a un [`&str`].
/// En aquest sentit, és un analògic a `FromUtf8Error`, i podeu obtenir-ne un `FromUtf8Error` mitjançant el mètode [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// // alguns bytes no vàlids, en un vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Un possible valor d'error en convertir un `String` des d'un segment de bytes UTF-16.
///
/// Aquest tipus és el tipus d'error del mètode [`from_utf16`] a [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Crea un nou `String` buit.
    ///
    /// Tenint en compte que el `String` està buit, això no assignarà cap búfer inicial.Tot i que això significa que aquesta operació inicial és molt econòmica, pot causar una assignació excessiva més endavant quan afegiu dades.
    ///
    /// Si teniu una idea de quantes dades tindrà el `String`, tingueu en compte el mètode [`with_capacity`] per evitar una reassignació excessiva.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Crea un nou `String` buit amb una capacitat particular.
    ///
    /// Les cadenes tenen una memòria intermèdia interna per contenir les seves dades.
    /// La capacitat és la longitud d'aquest buffer i es pot consultar amb el mètode [`capacity`].
    /// Aquest mètode crea un `String` buit, però un amb un buffer inicial que pot contenir bytes `capacity`.
    /// Això és útil quan podeu afegir un munt de dades al `String`, reduint el nombre de reassignacions que ha de fer.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Si la capacitat donada és `0`, no es produirà cap assignació i aquest mètode és idèntic al mètode [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // La cadena no conté caràcters, tot i que té capacitat per a més
    /// assert_eq!(s.len(), 0);
    ///
    /// // Tots es fan sense reassignar ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... però això pot fer reassignar la cadena
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): amb cfg(test), el mètode inherent `[T]::to_vec`, que es requereix per a aquesta definició de mètode, no està disponible.
    // Com que no necessitem aquest mètode per provar-los, només el faré un cop. Vegeu el mòdul slice::hack a slice.rs per obtenir més informació.
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Converteix un vector de bytes en un `String`.
    ///
    /// Una cadena ([`String`]) està formada per bytes ([`u8`]) i un vector de bytes ([`Vec<u8>`]) està format per bytes, de manera que aquesta funció converteix els dos.
    /// No tots els talls de bytes són vàlids, però: `String` requereix que sigui UTF-8 vàlid.
    /// `from_utf8()` comprova que els bytes són UTF-8 vàlids i, a continuació, fa la conversió.
    ///
    /// Si esteu segur que la secció de bytes és vàlida UTF-8 i no voleu incórrer en la sobrecàrrega de la comprovació de validesa, hi ha una versió no segura d'aquesta funció, [`from_utf8_unchecked`], que té el mateix comportament, però omet la comprovació.
    ///
    ///
    /// Aquest mètode tindrà cura de no copiar el vector, per motius d`eficiència.
    ///
    /// Si necessiteu un [`&str`] en lloc d`un `String`, tingueu en compte el [`str::from_utf8`].
    ///
    /// La inversa d`aquest mètode és [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Retorna [`Err`] si el segment no és UTF-8 amb una descripció de per què els bytes proporcionats no són UTF-8.També s`inclou el vector que us heu instal・lat.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// // alguns bytes, en un vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Sabem que aquests bytes són vàlids, de manera que farem servir `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Bytes incorrectes:
    ///
    /// ```
    /// // alguns bytes no vàlids, en un vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Consulteu els documents de [`FromUtf8Error`] per obtenir més informació sobre què podeu fer amb aquest error.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Converteix un segment de bytes a una cadena, inclosos els caràcters no vàlids.
    ///
    /// Les cadenes estan formades per bytes ([`u8`]) i una porció de bytes ([`&[u8]`][byteslice]) està formada per bytes, de manera que aquesta funció converteix els dos.No obstant això, no tots els talls de bytes són cadenes vàlides: cal que les cadenes siguin UTF-8 vàlides.
    /// Durant aquesta conversió, `from_utf8_lossy()` substituirà qualsevol seqüència UTF-8 no vàlida per [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], que té aquest aspecte:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Si esteu segur que el segment de bytes és vàlid UTF-8 i no voleu incórrer en la sobrecàrrega de la conversió, hi ha una versió no segura d'aquesta funció, [`from_utf8_unchecked`], que té el mateix comportament, però omet les comprovacions.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Aquesta funció retorna un [`Cow<'a, str>`].Si la nostra secció de bytes no és vàlida UTF-8, hem d'inserir els caràcters de substitució, que canviaran la mida de la cadena i, per tant, necessitaran un `String`.
    /// Però si ja és vàlid UTF-8, no necessitem una assignació nova.
    /// Aquest tipus de retorn ens permet gestionar els dos casos.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// // alguns bytes, en un vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Bytes incorrectes:
    ///
    /// ```
    /// // alguns bytes no vàlids
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Descodifiqueu un vector `v` codificat per UTF-16 en un `String`, retornant [`Err`] si `v` conté dades no vàlides.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Això no es fa mitjançant collect: <Result<_, _>> () per motius de rendiment.
        // FIXME: la funció es pot simplificar de nou quan es tanca #48994.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Descodifiqueu un segment `v` codificat amb UTF-16 en un `String`, substituint les dades no vàlides per [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// A diferència de [`from_utf8_lossy`] que retorna un [`Cow<'a, str>`], `from_utf16_lossy` retorna un `String` ja que la conversió UTF-16 a UTF-8 requereix una assignació de memòria.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Descompon un `String` en els seus components en brut.
    ///
    /// Retorna el punter en brut a les dades subjacents, la longitud de la cadena (en bytes) i la capacitat assignada de les dades (en bytes).
    /// Aquests són els mateixos arguments en el mateix ordre que els arguments de [`from_raw_parts`].
    ///
    /// Després de trucar a aquesta funció, la persona que truca és responsable de la memòria gestionada prèviament per l `String`.
    /// L'única manera de fer-ho és convertir el punter, la longitud i la capacitat en brut en un `String` amb la funció [`from_raw_parts`], cosa que permet al destructor realitzar la neteja.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Crea un nou `String` a partir d'una longitud, capacitat i punter.
    ///
    /// # Safety
    ///
    /// Això és molt insegur, a causa del nombre d'invariants que no es comproven:
    ///
    /// * La memòria a `buf` ha d`haver estat assignada prèviament pel mateix assignador que utilitza la biblioteca estàndard, amb un alineamiento obligatori d`exactament 1.
    /// * `length` ha de ser inferior o igual a `capacity`.
    /// * `capacity` ha de ser el valor correcte.
    /// * Els primers bytes `length` de `buf` han de ser UTF-8 vàlids.
    ///
    /// Incomplir-los pot causar problemes com ara corrompre les estructures de dades internes de l`assignador.
    ///
    /// La propietat de `buf` es transfereix efectivament al `String`, que després pot reassignar, reassignar o canviar el contingut de la memòria que assenyala el punter a voluntat.
    /// Assegureu-vos que res més utilitza el punter després de trucar a aquesta funció.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Actualitzeu-ho quan vec_into_raw_parts s'estabilitzi.
    ///     // Eviteu deixar caure automàticament les dades de la cadena
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Converteix un vector de bytes en un `String` sense comprovar que la cadena conté UTF-8 vàlid.
    ///
    /// Consulteu la versió segura, [`from_utf8`], per obtenir més informació.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Aquesta funció no és segura perquè no comprova que els bytes que se li passen siguin vàlids UTF-8.
    /// Si es infringeix aquesta restricció, pot causar problemes de seguretat de memòria amb els usuaris de future de l `String`, ja que la resta de la biblioteca estàndard assumeix que les "cadenes" són UTF-8 vàlides.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// // alguns bytes, en un vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Converteix un `String` en un byte vector.
    ///
    /// Això consumeix l `String`, de manera que no necessitem copiar-ne el contingut.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Extreu un segment de cadena que conté tot el `String`.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Converteix un `String` en un segment de cadena mutable.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Afegeix una secció de cadena donada al final d'aquest `String`.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Retorna la capacitat d'aquesta "Cadena", en bytes.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Assegura que la capacitat d'aquesta "cadena" sigui com a mínim `additional` bytes més gran que la seva longitud.
    ///
    /// La capacitat pot augmentar-se en més de `additional` bytes si ho prefereix, per evitar reassignacions freqüents.
    ///
    ///
    /// Si no voleu aquest comportament "at least", consulteu el mètode [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics si la nova capacitat desborda [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Això pot no augmentar la capacitat:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // ara té una longitud de 2 i una capacitat de 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Com que ja tenim una capacitat addicional de 8, anomenem això ...
    /// s.reserve(8);
    ///
    /// // ... en realitat no augmenta.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Assegura que la capacitat d'aquesta "cadena" és `additional` bytes més gran que la seva longitud.
    ///
    /// Penseu en la possibilitat d`utilitzar el mètode [`reserve`] tret que sàpiga millor que l`assignador.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics si la nova capacitat desborda `usize`.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Això pot no augmentar la capacitat:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // ara té una longitud de 2 i una capacitat de 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Com que ja tenim una capacitat addicional de 8, anomenem això ...
    /// s.reserve_exact(8);
    ///
    /// // ... en realitat no augmenta.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Intenta reservar capacitat per a almenys `additional` elements més que s'inseriran al `String` donat.
    /// La col・lecció pot reservar més espai per evitar reassignacions freqüents.
    /// Després de trucar a `reserve`, la capacitat serà superior o igual a `self.len() + additional`.
    /// No fa res si la capacitat ja és suficient.
    ///
    /// # Errors
    ///
    /// Si la capacitat es desborda o l`assignador informa d`un error, es retornarà un error.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Reserveu prèviament la memòria, sortint si no podem
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Ara sabem que això no pot OOM enmig del nostre complex treball
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Intenta reservar la capacitat mínima per inserir exactament `additional` més elements a la `String` donada.
    ///
    /// Després de trucar a `reserve_exact`, la capacitat serà superior o igual a `self.len() + additional`.
    /// No fa res si la capacitat ja és suficient.
    ///
    /// Tingueu en compte que l`assignador pot donar a la col・lecció més espai del que demana.
    /// Per tant, no es pot confiar en la capacitat per ser precisament mínima.
    /// Preferiu `reserve` si s`esperen insercions future.
    ///
    /// # Errors
    ///
    /// Si la capacitat es desborda o l`assignador informa d`un error, es retornarà un error.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Reserveu prèviament la memòria, sortint si no podem
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Ara sabem que això no pot OOM enmig del nostre complex treball
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Redueix la capacitat d`aquest `String` perquè coincideixi amb la seva longitud.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Redueix la capacitat d`aquest `String` amb un límit inferior.
    ///
    /// La capacitat es mantindrà com a mínim tan gran com la longitud i el valor subministrat.
    ///
    ///
    /// Si la capacitat actual és inferior al límit inferior, es tracta d'un no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Afegeix el [`char`] donat al final d'aquest `String`.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Retorna un segment de bytes del contingut d'aquesta "Cadena".
    ///
    /// La inversa d`aquest mètode és [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Escurça aquest `String` a la longitud especificada.
    ///
    /// Si `new_len` és superior a la longitud actual de la cadena, això no tindrà efecte.
    ///
    ///
    /// Tingueu en compte que aquest mètode no té cap efecte sobre la capacitat assignada de la cadena
    ///
    /// # Panics
    ///
    /// Panics si `new_len` no es troba en un límit [`char`].
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Elimina l'últim caràcter del buffer de cadenes i el retorna.
    ///
    /// Retorna [`None`] si aquest `String` està buit.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Elimina un [`char`] d'aquest `String` en una posició de byte i el retorna.
    ///
    /// Es tracta d`una operació *O*(*n*), ja que requereix copiar tots els elements del buffer.
    ///
    /// # Panics
    ///
    /// Panics si `idx` és més gran o igual a la longitud de la "Cadena" o si no es troba en un límit [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Elimineu totes les coincidències del patró `pat` del `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Les coincidències es detectaran i se suprimiran iterativament, de manera que en els casos en què els patrons es superposin, només se suprimirà el primer patró:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // SEGURETAT: el començament i el final seran als límits de bytes utf8 per
        // els documents del Cercador
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Conserva només els caràcters especificats pel predicat.
    ///
    /// En altres paraules, elimineu tots els caràcters `c` de manera que `f(c)` retorni `false`.
    /// Aquest mètode funciona al seu lloc, visitant cada personatge exactament una vegada en l'ordre original i conserva l'ordre dels caràcters conservats.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// L'ordre exacte pot ser útil per fer un seguiment de l'estat extern, com ara un índex.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Apunteu idx al següent caràcter
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Insereix un caràcter en aquest `String` en una posició de byte.
    ///
    /// Es tracta d`una operació *O*(*n*) ja que requereix copiar tots els elements del buffer.
    ///
    /// # Panics
    ///
    /// Panics si `idx` és més gran que la longitud de la "String" o si no es troba en un límit [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Insereix una llesca de cadena en aquest `String` en una posició de byte.
    ///
    /// Es tracta d`una operació *O*(*n*) ja que requereix copiar tots els elements del buffer.
    ///
    /// # Panics
    ///
    /// Panics si `idx` és més gran que la longitud de la "String" o si no es troba en un límit [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Retorna una referència mutable al contingut d'aquest `String`.
    ///
    /// # Safety
    ///
    /// Aquesta funció no és segura perquè no comprova que els bytes que se li passen siguin vàlids UTF-8.
    /// Si es infringeix aquesta restricció, pot causar problemes de seguretat de memòria amb els usuaris de future de l `String`, ja que la resta de la biblioteca estàndard assumeix que les "cadenes" són UTF-8 vàlides.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Retorna la longitud d'aquest `String`, en bytes, no en [`char`] ni en grafemes.
    /// Dit d`una altra manera, potser no és el que un humà considera la longitud de la corda.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Retorna `true` si aquest `String` té una longitud de zero i `false` en cas contrari.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Divideix la cadena en dos a l'índex de bytes donat.
    ///
    /// Retorna un `String` recentment assignat.
    /// `self` conté bytes `[0, at)` i el `String` retornat conté bytes `[at, len)`.
    /// `at` ha d'estar al límit d'un punt de codi UTF-8.
    ///
    /// Tingueu en compte que la capacitat de `self` no canvia.
    ///
    /// # Panics
    ///
    /// Panics si `at` no es troba en un límit de punt de codi `UTF-8` o si està més enllà de l'últim punt de codi de la cadena.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Trunca aquest `String` i elimina tot el contingut.
    ///
    /// Tot i que això significa que el `String` tindrà una longitud de zero, no toca la seva capacitat.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Crea un iterador de drenatge que elimina l'interval especificat al `String` i produeix el `chars` eliminat.
    ///
    ///
    /// Note: L'interval d'elements s'elimina fins i tot si l'iterador no es consumeix fins al final.
    ///
    /// # Panics
    ///
    /// Panics si el punt inicial o final no es troba en un límit [`char`] o si està fora de límit.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Traieu l'interval fins a la β de la cadena
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Un rang complet neteja la cadena
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Seguretat de la memòria
        //
        // La versió String de Drain no té problemes de seguretat de memòria de la versió vector.
        // Les dades són només bytes simples.
        // Com que l`eliminació de l`interval es fa a Drop, si es perd l`iterador Drain, l`eliminació no es produirà.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Traieu dos préstecs simultanis.
        // No s`accedirà a la cadena &mut fins que no acabi la iteració, a Drop.
        let self_ptr = self as *mut _;
        // SEGURETAT: `slice::range` i `is_char_boundary` fan les comprovacions de límits adequades.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Elimina l'interval especificat a la cadena i el substitueix per la cadena donada.
    /// La cadena donada no ha de tenir la mateixa longitud que l'interval.
    ///
    /// # Panics
    ///
    /// Panics si el punt inicial o final no es troba en un límit [`char`] o si està fora de límit.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Substituïu l'interval fins a la β de la cadena
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Seguretat de la memòria
        //
        // Replace_range no té problemes de seguretat de memòria d'un vector Splice.
        // de la versió vector.Les dades són només bytes simples.

        // ADVERTÈNCIA: Incloure aquesta variable no seria correcte (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // ADVERTÈNCIA: Incloure aquesta variable no seria correcte (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Tornar a utilitzar `range` no seria correcte (#81138) Suposem que els límits reportats per `range` continuen sent els mateixos, però una implementació contrària podria canviar entre trucades
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Converteix aquest `String` en un [`Box`]`<`[`str`] `>`.
    ///
    /// Això reduirà l'excés de capacitat.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Retorna un segment de [`u8`] s bytes que s'ha intentat convertir a un `String`.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// // alguns bytes no vàlids, en un vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Retorna els bytes que s'han intentat convertir a un `String`.
    ///
    /// Aquest mètode està construït amb cura per evitar l'assignació.
    /// Consumirà l'error, desplaçant els bytes, de manera que no cal fer una còpia dels bytes.
    ///
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// // alguns bytes no vàlids, en un vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Obteniu un `Utf8Error` per obtenir més detalls sobre l`error de la conversió.
    ///
    /// El tipus [`Utf8Error`] proporcionat per [`std::str`] representa un error que es pot produir en convertir un segment de [`u8`] s a un [`&str`].
    /// En aquest sentit, és un anàleg a `FromUtf8Error`.
    /// Consulteu la seva documentació per obtenir més detalls sobre l`ús.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// // alguns bytes no vàlids, en un vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // el primer byte no és vàlid aquí
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Com que estem iterant sobre "Cadena", podem evitar almenys una assignació obtenint la primera cadena de l'iterador i afegint-hi totes les cadenes posteriors.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Com que estem iterant sobre CoWs, podem evitar (potentially) com a mínim una assignació obtenint el primer element i afegint-hi tots els elements posteriors.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Una aplicació de conveniència que delega a la implementació per a `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Crea un `String` buit.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Implementa l'operador `+` per concatenar dues cadenes.
///
/// Això consumeix el `String` a la part esquerra i torna a utilitzar el seu buffer (fent-lo créixer si cal).
/// Això es fa per evitar assignar un nou `String` i copiar tot el contingut de cada operació, cosa que comportaria un temps d'execució *O*(*n*^ 2) en construir una cadena de *n*-byte mitjançant una concatenació repetida.
///
///
/// La corda del costat dret només es pot manllevar;el seu contingut es copia a l `String` retornat.
///
/// # Examples
///
/// La concatenació de dos `String`s pren la primera per valor i pren la segona:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` es mou i ja no es pot utilitzar aquí.
/// ```
///
/// Si voleu continuar utilitzant el primer `String`, podeu clonar-lo i afegir-lo al clon:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` encara és vàlid aquí.
/// ```
///
/// La concatenació de les llesques `&str` es pot fer convertint la primera en un `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Implementa l'operador `+=` per afegir-lo a un `String`.
///
/// Té el mateix comportament que el mètode [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Un àlies de tipus per a [`Infallible`].
///
/// Aquest àlies existeix per compatibilitat amb versions anteriors i, finalment, pot quedar obsolet.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// Un trait per convertir un valor en un `String`.
///
/// Aquest trait s'implementa automàticament per a qualsevol tipus que implementi el [`Display`] trait.
/// Com a tal, `ToString` no s'ha d'implementar directament:
/// [`Display`] s'hauria d'implementar, i obtindreu la implementació `ToString` de forma gratuïta.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Converteix el valor donat en un `String`.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// En aquesta implementació, el mètode `to_string` panics si la implementació `Display` retorna un error.
/// Això indica una implementació incorrecta de `Display` ja que `fmt::Write for String` mai no retorna un error per si mateix.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Una pauta comuna és no incloure funcions genèriques.
    // Tot i això, eliminar `#[inline]` d`aquest mètode provoca regressions no menyspreables.
    // Vegeu <https://github.com/rust-lang/rust/pull/74852>, l`últim intent per eliminar-lo.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Converteix un `&mut str` en un `String`.
    ///
    /// El resultat s`assigna al munt.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: test pulls in libstd, que provoca errors aquí
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Converteix el segment `str` en caixa donat a un `String`.
    /// És destacable que el segment `str` és propietat.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Converteix el `String` donat en un segment `str` encaixat que és propietat.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Converteix una secció de cadena en una variant prestada.
    /// No es realitza cap assignació de pila i la cadena no es copia.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Converteix una cadena en una variant de propietat.
    /// No es realitza cap assignació de pila i la cadena no es copia.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Converteix una referència de cadena en una variant prestada.
    /// No es realitza cap assignació de pila i la cadena no es copia.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Converteix el `String` donat en un vector `Vec` que conté valors del tipus `u8`.
    ///
    /// # Examples
    ///
    /// Ús bàsic:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Un iterador de drenatge per a `String`.
///
/// Aquesta estructura es crea mitjançant el mètode [`drain`] a [`String`].
/// Consulteu-ne la documentació per obtenir més informació.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// S'utilitzarà com a "Cadena mut" al destructor
    string: *mut String,
    /// Inici de la peça per eliminar
    start: usize,
    /// Final de la peça per eliminar
    end: usize,
    /// Interval restant actual per eliminar
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Utilitzeu Vec::drain.
            // "Reaffirm" els límits comproven per evitar que es torni a inserir el codi panic.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Retorna la (sub) cadena restant d'aquest iterador com una llesca.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: un comentari que implica AsRef a continuació quan s'estabilitza.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// No comenteu en estabilitzar `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>per a Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> per a Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}