#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// El contingut de la nova memòria no s`inicialitza.
    Uninitialized,
    /// Es garanteix que la nova memòria es posarà a zero.
    Zeroed,
}

/// Una utilitat de baix nivell per assignar, reassignar i reassignar de manera ergonòmica una memòria intermèdia a l'emmagatzematge dinàmic sense haver de preocupar-se de tots els casos de coin.
///
/// Aquest tipus és excel・lent per crear estructures de dades pròpies com Vec i VecDeque.
/// En particular:
///
/// * Produeix `Unique::dangling()` en tipus de mida zero.
/// * Produeix `Unique::dangling()` en assignacions de longitud zero.
/// * Evita alliberar `Unique::dangling()`.
/// * Capta tots els desbordaments en càlculs de capacitat (els promou a "capacity overflow" panics).
/// * Protegeix els sistemes de 32 bits que assignen més de isize::MAX bytes.
/// * Protecció contra el desbordament de la seva longitud.
/// * Truca a `handle_alloc_error` per obtenir assignacions fal・libles.
/// * Conté un `ptr::Unique` i, per tant, proporciona a l'usuari tots els avantatges relacionats.
/// * Utilitza l`excés retornat de l`assignador per utilitzar la capacitat més gran disponible.
///
/// Aquest tipus no inspecciona de cap manera la memòria que gestiona.Quan es deixa caure,*alliberarà* la seva memòria, però *no* intentarà * deixar-ne el contingut.
/// Correspon a l'usuari de `RawVec` gestionar les coses reals *emmagatzemades* dins d'un `RawVec`.
///
/// Tingueu en compte que l'excés d'un tipus de mida zero sempre és infinit, de manera que `capacity()` sempre retorna `usize::MAX`.
/// Això vol dir que heu de tenir precaució quan feu aquest tipus de voltes amb un `Box<[T]>`, ja que `capacity()` no donarà la longitud.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Això existeix perquè `#[unstable]` `const fn`s no ha de ser conforme a `min_const_fn` i, per tant, tampoc no es poden cridar a`min_const_fn`s.
    ///
    /// Si canvieu `RawVec<T>::new` o dependències, tingueu cura de no introduir res que infringeixi realment `min_const_fn`.
    ///
    /// NOTE: Podríem evitar aquest pirateig i comprovar la conformitat amb algun atribut `#[rustc_force_min_const_fn]` que requereix conformitat amb `min_const_fn`, però no permet necessàriament trucar-lo a `stable(...) const fn`/el codi d`usuari que no habilita `foo` quan hi ha `#[rustc_const_unstable(feature = "foo", issue = "01234")]`.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Crea el `RawVec` més gran possible (a la pila del sistema) sense assignar-lo.
    /// Si `T` té una mida positiva, es converteix en un `RawVec` amb capacitat `0`.
    /// Si `T` té una mida zero, es fa un `RawVec` amb capacitat `usize::MAX`.
    /// Útil per implementar una assignació retardada.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Crea un `RawVec` (a l`emmagatzematge dinàmic del sistema) amb els requisits d`alineació i capacitat exactes per a un `[T; capacity]`.
    /// Això equival a trucar a `RawVec::new` quan `capacity` és `0` o `T` té una mida zero.
    /// Tingueu en compte que si `T` té una mida zero, això vol dir que *no* obtindreu un `RawVec` amb la capacitat sol・licitada.
    ///
    /// # Panics
    ///
    /// Panics si la capacitat sol・licitada supera els `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// S'anul・la a l'OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Igual que `with_capacity`, però garanteix que el buffer es posa a zero.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Substitueix un `RawVec` a partir d'un punter i de la capacitat.
    ///
    /// # Safety
    ///
    /// Cal assignar el `ptr` (a l`emmagatzematge dinàmic del sistema) i amb el `capacity` donat.
    /// El `capacity` no pot superar `isize::MAX` per a tipus de mida.(només preocupa els sistemes de 32 bits).
    /// ZST vectors pot tenir una capacitat de fins a `usize::MAX`.
    /// Si el `ptr` i el `capacity` provenen d`un `RawVec`, això està garantit.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Els petits Vecs són ximples.Vés a:
    // - 8 si la mida de l'element és 1, perquè és probable que qualsevol assignador de pila arrodoneixi una sol・licitud de menys de 8 bytes a almenys 8 bytes.
    //
    // - 4 si els elements són de mida moderada (<=1 KiB).
    // - 1 en cas contrari, per evitar malgastar massa espai per a Vecs molt curts.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Igual que `new`, però parametritzat sobre l`elecció de l`assignador per al `RawVec` retornat.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` significa "unallocated".s'ignoren els tipus de mida zero.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Igual que `with_capacity`, però parametritzat sobre l`elecció de l`assignador per al `RawVec` retornat.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Igual que `with_capacity_zeroed`, però parametritzat sobre l`elecció de l`assignador per al `RawVec` retornat.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Converteix un `Box<[T]>` en un `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Converteix tot el buffer a `Box<[MaybeUninit<T>]>` amb el `len` especificat.
    ///
    /// Tingueu en compte que això reconstituirà correctament els canvis `cap` que s'hagin pogut realitzar.(Vegeu la descripció del tipus per obtenir més informació.)
    ///
    /// # Safety
    ///
    /// * `len` ha de ser superior o igual a la capacitat sol・licitada més recentment i
    /// * `len` ha de ser inferior o igual a `self.capacity()`.
    ///
    /// Tingueu en compte que la capacitat sol・licitada i l `self.capacity()` poden diferir, ja que un assignador podria globalment localitzar i retornar un bloc de memòria superior al sol・licitat.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Comproveu la sanitat comprovar la meitat dels requisits de seguretat (no podem comprovar l`altra meitat).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Aquí evitem `unwrap_or_else` perquè inflà la quantitat de LLVM IR generada.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Substitueix un `RawVec` des d'un punter, capacitat i assignador.
    ///
    /// # Safety
    ///
    /// Cal assignar el `ptr` (mitjançant l`assignador `alloc` donat) i amb el `capacity` donat.
    /// El `capacity` no pot superar `isize::MAX` per a tipus de mida.
    /// (només preocupa els sistemes de 32 bits).
    /// ZST vectors pot tenir una capacitat de fins a `usize::MAX`.
    /// Si l `ptr` i l `capacity` provenen d'un `RawVec` creat mitjançant `alloc`, això està garantit.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Obté un punter en brut al començament de l'assignació.
    /// Tingueu en compte que es tracta de `Unique::dangling()` si `capacity == 0` o `T` té una mida zero.
    /// En el primer cas, cal anar amb compte.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Obté la capacitat de l'assignació.
    ///
    /// Això sempre serà `usize::MAX` si `T` té una mida zero.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Retorna una referència compartida a l`assignador que dóna suport a aquest `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Tenim un tros de memòria assignat, de manera que podem evitar les comprovacions en temps d'execució per obtenir el nostre disseny actual.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Assegura que la memòria intermèdia conté almenys prou espai per contenir elements `len + additional`.
    /// Si encara no té prou capacitat, reassignarà prou espai i espai còmode per obtenir un comportament amortitzat *O*(1).
    ///
    /// Limitarà aquest comportament si causaria innecessàriament a panic.
    ///
    /// Si `len` supera `self.capacity()`, és possible que no s'assigni l'espai sol・licitat.
    /// Això no és realment insegur, però el codi insegur *que* escriviu que es basa en el comportament d'aquesta funció es pot trencar.
    ///
    /// Això és ideal per implementar una operació push-bulk com `extend`.
    ///
    /// # Panics
    ///
    /// Panics si la nova capacitat supera els `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// S'anul・la a l'OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // La reserva s'hauria avortat o entraria en pànic si el len excedís `isize::MAX`, de manera que ara es pot fer sense marcar.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// El mateix que el `reserve`, però torna amb errors en lloc de prendre pànic o avortar.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Assegura que la memòria intermèdia conté almenys prou espai per contenir elements `len + additional`.
    /// Si encara no ho fa, reassignarà la quantitat mínima possible de memòria necessària.
    /// En general, aquesta serà exactament la quantitat de memòria necessària, però, en principi, l'assignador és lliure de retornar més del que demanàvem.
    ///
    ///
    /// Si `len` supera `self.capacity()`, és possible que no s'assigni l'espai sol・licitat.
    /// Això no és realment insegur, però el codi insegur *que* escriviu que es basa en el comportament d'aquesta funció es pot trencar.
    ///
    /// # Panics
    ///
    /// Panics si la nova capacitat supera els `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// S'anul・la a l'OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// El mateix que el `reserve_exact`, però torna amb errors en lloc de prendre pànic o avortar.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Redueix l'assignació fins a la quantitat especificada.
    /// Si l`import indicat és 0, realment es desassigna completament.
    ///
    /// # Panics
    ///
    /// Panics si l'import donat és *més gran* que la capacitat actual.
    ///
    /// # Aborts
    ///
    /// S'anul・la a l'OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Torna si el buffer necessita créixer per complir la capacitat addicional necessària.
    /// S'utilitza principalment per fer possibles trucades de reserva en línia sense `grow` en línia.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Normalment, aquest mètode s`instancia en moltes ocasions.Per tant, volem que sigui el més petit possible, per millorar els temps de compilació.
    // Però també volem que la major part del seu contingut sigui computable estàticament com sigui possible, per fer que el codi generat funcioni més ràpidament.
    // Per tant, aquest mètode s`escriu acuradament de manera que tot el codi que depèn de `T` estigui dins d`ell, mentre la major part del codi que no depèn de `T` es troba en funcions no genèriques sobre `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Això ho asseguren els contextos de trucades.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Ja que retornem una capacitat de `usize::MAX` quan `elem_size` és
            // 0, arribar fins aquí significa necessàriament que el `RawVec` és ple.
            return Err(CapacityOverflow);
        }

        // Malauradament, no podem fer res amb aquests controls.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Això garanteix un creixement exponencial.
        // La duplicació no es pot desbordar perquè `cap <= isize::MAX` i el tipus de `cap` són `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` no és genèric sobre `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Les restriccions d`aquest mètode són molt les mateixes que les de l `grow_amortized`, però aquest mètode normalment s`instancia amb menys freqüència, de manera que és menys crític.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Ja que retornem una capacitat de `usize::MAX` quan la mida del tipus és
            // 0, arribar fins aquí significa necessàriament que el `RawVec` és ple.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` no és genèric sobre `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Aquesta funció està fora de `RawVec` per minimitzar els temps de compilació.Consulteu el comentari anterior de `RawVec::grow_amortized` per obtenir més informació.
// (El paràmetre `A` no és significatiu, perquè el nombre de tipus `A` diferents vistos a la pràctica és molt menor que el nombre de tipus `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Comproveu aquí l'error per minimitzar la mida de `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // L'assignador comprova si hi ha igualtat d'alineació
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Allibera la memòria propietat del `RawVec`*sense* intentar deixar caure el seu contingut.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Funció central per al maneig d'errors de reserva.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Hem de garantir el següent:
// * Mai no assignem objectes de mida de byte `> isize::MAX`.
// * No desbordem `usize::MAX` i en realitat assignem massa poc.
//
// A 64 bits només hem de comprovar si hi ha desbordament, ja que segur que fallarà intentar assignar bytes `> isize::MAX`.
// A 32 i 16 bits, hem d'afegir una protecció addicional per a això en cas que estiguem executant-nos en una plataforma que pugui utilitzar tots els 4 GB a l'espai de l'usuari, per exemple, PAE o x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Una funció central responsable del desbordament de capacitat d'informes.
// Això garantirà que la generació de codi relacionada amb aquests panics sigui mínima, ja que només hi ha una ubicació que panics en lloc d`un munt al llarg del mòdul.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}