//! Punters de recompte de referències d`un sol fil.'Rc' significa 'Referència
//! Counted'.
//!
//! El tipus [`Rc<T>`][`Rc`] proporciona la propietat compartida d'un valor del tipus `T`, assignat a l'emmagatzematge dinàmic.
//! La invocació de [`clone`][clone] a [`Rc`] produeix un nou punter a la mateixa assignació al munt.
//! Quan es destrueix l'últim punter [`Rc`] a una assignació determinada, també es baixa el valor emmagatzemat en aquesta assignació (sovint anomenat "inner value").
//!
//! Les referències compartides a Rust no permeten la mutació per defecte i [`Rc`] no és una excepció: generalment no es pot obtenir una referència mutable a alguna cosa dins d`un [`Rc`].
//! Si necessiteu mutabilitat, poseu un [`Cell`] o [`RefCell`] dins del [`Rc`];vegeu [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] utilitza el recompte de referències no atòmiques.
//! Això significa que la sobrecàrrega és molt baixa, però no es pot enviar un [`Rc`] entre fils i, per tant, [`Rc`] no implementa [`Send`][send].
//! Com a resultat, el compilador Rust comprovarà *en el moment de la compilació* que no envieu [`Rc`] s entre fils.
//! Si necessiteu un recompte de referències atòmiques de diversos fils, utilitzeu [`sync::Arc`][arc].
//!
//! El mètode [`downgrade`][downgrade] es pot utilitzar per crear un punter [`Weak`] que no sigui propietari.
//! Un punter [`Weak`] es pot [[actualitzar]][actualitzar] d a un [`Rc`], però això retornarà [`None`] si el valor emmagatzemat a l'assignació ja s'ha eliminat.
//! En altres paraules, els punters `Weak` no mantenen viu el valor dins de l'assignació;no obstant això,*sí* mantenen viva l'assignació (el magatzem secundari del valor intern).
//!
//! Mai es repartirà un cicle entre els punteros [`Rc`].
//! Per aquest motiu, [`Weak`] s'utilitza per trencar cicles.
//! Per exemple, un arbre pot tenir indicadors [`Rc`] forts des de nodes pares fins a fills, i indicadors [`Weak`] des de nens fins als seus pares.
//!
//! `Rc<T>` cancel・la automàticament les referències a `T` (mitjançant [`Deref`] trait), de manera que podeu trucar als mètodes de "T" a un valor del tipus [`Rc<T>`][`Rc`].
//! Per evitar xocs de noms amb els mètodes de "T", els mètodes de [`Rc<T>`][`Rc`] en si són funcions associades, anomenades amb [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Les implementacions de traits com `Clone` també es poden anomenar utilitzant una sintaxi completament qualificada.
//! Algunes persones prefereixen utilitzar una sintaxi completament qualificada, mentre que d'altres prefereixen utilitzar la sintaxi de mètode-trucada.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Sintaxi de mètode-trucada
//! let rc2 = rc.clone();
//! // Sintaxi completament qualificada
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] no fa autoreferència a `T`, ja que és possible que el valor intern ja s'hagi eliminat.
//!
//! # Referències de clonació
//!
//! La creació d`una nova referència a la mateixa assignació que un punter comptador de referència existent es fa mitjançant el `Clone` trait implementat per a [`Rc<T>`][`Rc`] i [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Les dues sintaxis següents són equivalents.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a i b apunten a la mateixa ubicació de memòria que foo.
//! ```
//!
//! La sintaxi `Rc::clone(&from)` és la més idiomàtica perquè transmet de manera més explícita el significat del codi.
//! A l'exemple anterior, aquesta sintaxi facilita la comprovació que aquest codi crea una nova referència en lloc de copiar tot el contingut de foo.
//!
//! # Examples
//!
//! Penseu en un escenari en què un conjunt de "gadgets" sigui propietat d'un determinat `Owner`.
//! Volem que el nostre "gadget" apunti al seu `Owner`.No ho podem fer amb una propietat única, perquè és possible que més d'un gadget pertanyi al mateix `Owner`.
//! [`Rc`] ens permet compartir un `Owner` entre diversos `Gadget` i fer que el `Owner` romangui assignat sempre que hi hagi `Gadget` que hi apunti.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... altres camps
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... altres camps
//! }
//!
//! fn main() {
//!     // Creeu un `Owner` comptable de referències.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Creeu `Gadget` que pertanyi a `gadget_owner`.
//!     // La clonació del `Rc<Owner>` ens proporciona un nou punter a la mateixa assignació `Owner`, incrementant el recompte de referència en el procés.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Eliminar la nostra variable local `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Tot i deixar de banda el `gadget_owner`, encara podem imprimir el nom del `Owner` del `Gadget`.
//!     // Això es deu al fet que només hem deixat caure un sol `Rc<Owner>`, no el `Owner` al qual apunta.
//!     // Mentre hi hagi altres `Rc<Owner>` que apuntin a la mateixa assignació `Owner`, es mantindrà activa.
//!     // La projecció de camp `gadget1.owner.name` funciona perquè `Rc<Owner>` anul・la automàticament les referències a `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Al final de la funció, `gadget1` i `gadget2` es destrueixen i, amb elles, es compten les darreres referències al nostre `Owner`.
//!     // Ara Gadget Man també es destrueix.
//!     //
//! }
//! ```
//!
//! Si els nostres requisits canvien i també hem de poder passar de `Owner` a `Gadget`, ens trobarem amb problemes.
//! Un punter [`Rc`] de `Owner` a `Gadget` introdueix un cicle.
//! Això vol dir que els seus recomptes de referència no poden arribar mai a 0 i que l'assignació mai es destruirà:
//! una fuita de memòria.Per evitar-ho, podem utilitzar punteres [`Weak`].
//!
//! Rust fa que sigui una mica difícil produir aquest bucle en primer lloc.Per acabar amb dos valors que s`assenyalen, un d`ells ha de ser mutable.
//! Això és difícil perquè [`Rc`] imposa la seguretat de la memòria només proporcionant referències compartides al valor que embolcalla i aquestes no permeten la mutació directa.
//! Hem d`ajustar la part del valor que volem mutar en un [`RefCell`], que proporciona *mutabilitat interior*: un mètode per aconseguir la mutabilitat mitjançant una referència compartida.
//! [`RefCell`] fa complir les normes de préstec de Rust en temps d'execució.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... altres camps
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... altres camps
//! }
//!
//! fn main() {
//!     // Creeu un `Owner` comptable de referències.
//!     // Tingueu en compte que hem posat el vector del "Propietari" de "Gadget" dins d'un `RefCell` perquè puguem mutar-lo mitjançant una referència compartida.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Creeu `Gadget` que pertanyi a `gadget_owner`, com abans.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Afegiu el gadget al dispositiu `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` el préstec dinàmic acaba aquí.
//!     }
//!
//!     // Repeteix els nostres "gadgets" i imprimeix les seves dades.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` és un `Weak<Gadget>`.
//!         // Com que els punters `Weak` no poden garantir que encara existeixi l'assignació, hem de trucar a `upgrade`, que retorna un `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // En aquest cas, sabem que l'assignació encara existeix, de manera que simplement `unwrap` l `Option`.
//!         // En un programa més complicat, és possible que necessiteu una manipulació d'errors elegant per obtenir un resultat `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Al final de la funció, `gadget_owner`, `gadget1` i `gadget2` es destrueixen.
//!     // Ara no hi ha indicadors (`Rc`) forts als aparells, de manera que són destruïts.
//!     // Això posa a zero el recompte de referència en Gadget Man, de manera que també es destrueix.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Es tracta d'una prova de repr(C) a future contra possibles reordenacions de camp, que interfereixen amb [into|from]_raw() d'una altra manera segura de tipus interiors transmutables.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Un punter de comptatge de referències d`un sol fil.'Rc' significa 'Referència
/// Counted'.
///
/// Consulteu el [module-level documentation](./index.html) per obtenir més detalls.
///
/// Els mètodes inherents a `Rc` són funcions associades, cosa que significa que cal anomenar-los com, per exemple, [`Rc::get_mut(&mut value)`][get_mut] en lloc de `value.get_mut()`.
/// Això evita conflictes amb mètodes del tipus interior `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Aquesta inseguretat està bé perquè mentre aquest Rc estigui viu estem garantits que el punter intern és vàlid.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Construeix un nou `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Hi ha un punter dèbil implícit propietat de tots els indicadors forts, que garanteix que el destructor feble mai no allibera l'assignació mentre el destructor fort està en execució, fins i tot si el punter feble s'emmagatzema dins del fort.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Construeix un nou `Rc<T>` mitjançant una referència feble a si mateix.
    /// Si intenteu actualitzar la referència feble abans que es retorni aquesta funció, obtindreu un valor `None`.
    ///
    /// No obstant això, la referència feble es pot clonar lliurement i emmagatzemar per utilitzar-la posteriorment.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... més camps
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Construïu l'interior en l'estat "uninitialized" amb una única referència feble.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // És important que no renunciem a la propietat del punter feble o, si no, la memòria es pot alliberar en el moment que `data_fn` torni.
        // Si realment volguéssim passar la propietat, podríem crear-nos un punter dèbil addicional, però això donaria lloc a actualitzacions addicionals del recompte de referències dèbils que d`una altra manera potser no serien necessàries.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Les referències fortes haurien de posseir col・lectivament una referència feble compartida, així que no executeu el destructor de la nostra antiga referència feble.
        //
        mem::forget(weak);
        strong
    }

    /// Construeix un nou `Rc` amb contingut no inicialitzat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inicialització diferida:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Construeix un nou `Rc` amb contingut no inicialitzat, amb la memòria plena de bytes `0`.
    ///
    ///
    /// Vegeu [`MaybeUninit::zeroed`][zeroed] per obtenir exemples d`ús correcte i incorrecte d`aquest mètode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Construeix un nou `Rc<T>`, retornant un error si falla l'assignació
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Hi ha un punter dèbil implícit propietat de tots els indicadors forts, que garanteix que el destructor feble mai no allibera l'assignació mentre el destructor fort està en execució, fins i tot si el punter feble s'emmagatzema dins del fort.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Construeix un nou `Rc` amb contingut no inicialitzat, retornant un error si falla l'assignació
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Inicialització diferida:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Construeix un nou `Rc` amb contingut no inicialitzat, amb la memòria omplerta de bytes `0`, retornant un error si falla l'assignació
    ///
    ///
    /// Vegeu [`MaybeUninit::zeroed`][zeroed] per obtenir exemples d`ús correcte i incorrecte d`aquest mètode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Construeix un nou `Pin<Rc<T>>`.
    /// Si `T` no implementa `Unpin`, `value` quedarà fixat a la memòria i no es podrà moure.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Retorna el valor intern, si l `Rc` té exactament una referència forta.
    ///
    /// En cas contrari, es retornarà un [`Err`] amb el mateix `Rc` que es va passar.
    ///
    ///
    /// Això tindrà èxit encara que hi hagi referències febles pendents.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // copieu l'objecte contingut

                // Indiqueu a Weaks que no es poden promoure disminuint el recompte fort i, a continuació, elimineu el punter "strong weak" implícit alhora que gestioneu la lògica de caiguda creant només un fals Weak.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Construeix una nova secció comptada amb referències amb contingut no inicialitzat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inicialització diferida:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Construeix una nova secció comptada amb referències amb contingut no inicialitzat, amb la memòria omplerta de bytes `0`.
    ///
    ///
    /// Vegeu [`MaybeUninit::zeroed`][zeroed] per obtenir exemples d`ús correcte i incorrecte d`aquest mètode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Converteix a `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Igual que amb [`MaybeUninit::assume_init`], correspon a la persona que truca garantir el valor intern realment en un estat inicialitzat.
    ///
    /// Cridar-ho quan el contingut encara no està inicialitzat completament provoca un comportament immediat i indefinit.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inicialització diferida:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Converteix a `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Igual que amb [`MaybeUninit::assume_init`], correspon a la persona que truca garantir el valor intern realment en un estat inicialitzat.
    ///
    /// Cridar-ho quan el contingut encara no està inicialitzat completament provoca un comportament immediat i indefinit.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inicialització diferida:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Consumeix el `Rc`, retornant el punter embolicat.
    ///
    /// Per evitar pèrdues de memòria, el punter s'ha de tornar a convertir a un `Rc` mitjançant [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Proporciona un punter en brut a les dades.
    ///
    /// Els recomptes no es veuen afectats de cap manera i el `Rc` no es consumeix.
    /// El punter és vàlid mentre hi hagi un recompte fort al `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SEGURETAT: Això no pot passar per Deref::deref o Rc::inner perquè
        // això es requereix per conservar la procedència raw/mut tal que, per exemple,
        // `get_mut` pot escriure a través del punter després de recuperar Rc mitjançant `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Construeix un `Rc<T>` a partir d'un punter en brut.
    ///
    /// El punter en brut ha d'haver estat retornat prèviament per una trucada a [`Rc<U>::into_raw`][into_raw], on `U` ha de tenir la mateixa mida i alineament que `T`.
    /// Això és trivialment cert si `U` és `T`.
    /// Tingueu en compte que si `U` no és `T` però té la mateixa mida i alineació, bàsicament és com transmutar referències de diferents tipus.
    /// Consulteu [`mem::transmute`][transmute] per obtenir més informació sobre les restriccions que s`apliquen en aquest cas.
    ///
    /// L'usuari de `from_raw` s'ha d'assegurar que un valor específic de `T` només es caigui una vegada.
    ///
    /// Aquesta funció no és segura, ja que un ús inadequat pot provocar una inseguretat de la memòria, fins i tot si no s'accedeix mai a l `Rc<T>` retornat.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Converteix de nou en un `Rc` per evitar fuites.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Les trucades posteriors a `Rc::from_raw(x_ptr)` no serien segures per a la memòria.
    /// }
    ///
    /// // La memòria es va alliberar quan `x` va sortir de l'abast anterior, de manera que `x_ptr` ara penja.
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Invertiu el desplaçament per trobar el RcBox original.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Crea un nou punter [`Weak`] per a aquesta assignació.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Assegureu-vos que no creem un dèbil penjant
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Obté el nombre de punteres [`Weak`] a aquesta assignació.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Obté el nombre de punteres (`Rc`) forts a aquesta assignació.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Retorna `true` si no hi ha cap altre indicador `Rc` o [`Weak`] en aquesta assignació.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Retorna una referència mutable al `Rc` donat, si no hi ha cap altre punter `Rc` o [`Weak`] a la mateixa assignació.
    ///
    ///
    /// Retorna [`None`] en cas contrari, perquè no és segur mutar un valor compartit.
    ///
    /// Vegeu també [`make_mut`][make_mut], que permetrà [`clone`][clone] el valor intern quan hi hagi altres indicadors.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Retorna una referència mutable al `Rc` donat, sense cap comprovació.
    ///
    /// Vegeu també [`get_mut`], que és segur i fa les comprovacions adequades.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Els altres indicadors `Rc` o [`Weak`] de la mateixa assignació no es poden deixar de referenciar durant la durada del préstec retornat.
    ///
    /// Això és trivialment el cas si no existeixen aquests indicadors, per exemple immediatament després de `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Tenim cura de *no* crear una referència que cobreixi els camps "count", ja que això entraria en conflicte amb els accessos als recomptes de referència (per exemple,
        // per `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Retorna `true` si els dos `Rc` apunten a la mateixa assignació (en una línia similar a [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Fa una referència mutable al `Rc` donat.
    ///
    /// Si hi ha altres indicadors `Rc` a la mateixa assignació, `make_mut` farà que [`clone`] el valor intern d'una nova assignació per garantir la propietat única.
    /// Això també es coneix com a clonatge en escriptura.
    ///
    /// Si no hi ha altres indicadors `Rc` en aquesta assignació, els indicadors [`Weak`] en aquesta assignació es desvincularan.
    ///
    /// Vegeu també [`get_mut`], que fallarà en lloc de clonar.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // No clonaré res
    /// let mut other_data = Rc::clone(&data);    // No clonarà dades internes
    /// *Rc::make_mut(&mut data) += 1;        // Clona dades internes
    /// *Rc::make_mut(&mut data) += 1;        // No clonaré res
    /// *Rc::make_mut(&mut other_data) *= 2;  // No clonaré res
    ///
    /// // Ara `data` i `other_data` apunten a assignacions diferents.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] els indicadors es desvincularan:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // He de clonar les dades, hi ha altres Rcs.
            // Pre-assigneu memòria per permetre escriure directament el valor clonat.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Només puc robar les dades, només queden dèbils
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Elimineu la referència implícita fort-feble (no cal que creeu un fals feble aquí, ja que sabem que altres debilitats poden netejar-nos)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Aquesta inseguretat està bé, ja que estem garantits que el punter retornat és l'únic punter que es retornarà a T.
        // Es garanteix que el nostre recompte de referències serà 1 en aquest moment i hem exigit que el propi `Rc<T>` sigui `mut`, de manera que retornem l`única referència possible a l`assignació.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Intenteu reduir el `Rc<dyn Any>` a un tipus concret.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Assigna un `RcBox<T>` amb espai suficient per a un valor interior que no sigui possible de mida on el valor tingui el disseny proporcionat.
    ///
    /// La funció `mem_to_rcbox` es diu amb el punter de dades i ha de tornar un indicador (potencialment gros) per al `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Calculeu el disseny utilitzant el disseny del valor donat.
        // Anteriorment, el disseny es calculava sobre l'expressió `&*(ptr as* const RcBox<T>)`, però això va crear una referència desalineada (vegeu #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Assigna un `RcBox<T>` amb espai suficient per a un valor intern possiblement sense mida on el valor tingui el disseny proporcionat, retornant un error si falla l'assignació.
    ///
    ///
    /// La funció `mem_to_rcbox` es diu amb el punter de dades i ha de tornar un indicador (potencialment gros) per al `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Calculeu el disseny utilitzant el disseny del valor donat.
        // Anteriorment, el disseny es calculava sobre l'expressió `&*(ptr as* const RcBox<T>)`, però això va crear una referència desalineada (vegeu #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Assignar el disseny.
        let ptr = allocate(layout)?;

        // Inicialitzeu el RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Assigna un `RcBox<T>` amb espai suficient per obtenir un valor interior sense mida
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Assigneu el `RcBox<T>` mitjançant el valor indicat.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Copieu el valor com a bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Allibereu l'assignació sense deixar-ne caure el contingut
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Assigna un `RcBox<[T]>` amb la longitud indicada.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Copieu els elements de la llesca a Rc <\[T\]> assignat recentment
    ///
    /// No és segur perquè la persona que truca ha de ser propietari o vincular `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Construeix un `Rc<[T]>` a partir d'un iterador conegut per tenir una mida determinada.
    ///
    /// El comportament no està definit si la mida no és correcta.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Protecció Panic mentre clona elements T.
        // En cas que es produeixi un panic, es deixaran els elements que s'hagin escrit al nou RcBox i després s'alliberarà la memòria.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Punter al primer element
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Tot bé.Oblideu-vos de la guàrdia perquè no alliberi el nou RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Especialització trait que s`utilitza per a `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Deixa caure el `Rc`.
    ///
    /// Això disminuirà el recompte de referència forta.
    /// Si el recompte de referències fortes arriba a zero, les altres referències (si n`hi ha) són [`Weak`], de manera que `drop` el valor intern.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // No imprimeix res
    /// drop(foo2);   // Imprimeix "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // destruir l'objecte contingut
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // elimineu el punter "strong weak" implícit ara que hem destruït el contingut.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Fa un clon del punter `Rc`.
    ///
    /// Això crea un altre punter a la mateixa assignació, augmentant el recompte de referència forta.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Crea un `Rc<T>` nou, amb el valor `Default` per a `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack per permetre l'especialització en `Eq` tot i que `Eq` té un mètode.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Estem fent aquesta especialització aquí, i no com una optimització més general a `&T`, perquè d'una altra manera afegiria un cost a totes les comprovacions d'igualtat de les referències.
/// Suposem que els `Rc` s`utilitzen per emmagatzemar valors grans, que són lents a clonar, però també pesats per comprovar la igualtat, cosa que fa que aquest cost es pagui més fàcilment.
///
/// També és més probable que tingueu dos clons `Rc`, que apunten al mateix valor, que dos `&T`.
///
/// Només ho podem fer quan `T: Eq` com a `PartialEq` pot ser deliberadament irreflexiu.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Igualtat per a dos `Rc`s.
    ///
    /// Dos "Rc" són iguals si els seus valors interns són iguals, fins i tot si s'emmagatzemen en una assignació diferent.
    ///
    /// Si `T` també implementa `Eq` (que implica reflexivitat d'igualtat), dos `Rc` que apunten a la mateixa assignació són sempre iguals.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Desigualtat per a dos `Rc`.
    ///
    /// Dos "Rc" són desiguals si els seus valors interns són desiguals.
    ///
    /// Si `T` també implementa `Eq` (que implica reflexivitat d'igualtat), dos `Rc` que apunten a la mateixa assignació mai són desiguals.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Comparació parcial per a dos `Rc`.
    ///
    /// Els dos es comparen trucant a `partial_cmp()` sobre els seus valors interns.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Comparació inferior a dos "Rc".
    ///
    /// Els dos es comparen trucant a `<` sobre els seus valors interns.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Comparació "inferior o igual a" per a dos "Rc".
    ///
    /// Els dos es comparen trucant a `<=` sobre els seus valors interns.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Comparació superior a la de dos "Rc".
    ///
    /// Els dos es comparen trucant a `>` sobre els seus valors interns.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Comparació "superior o igual a" per a dos "Rc".
    ///
    /// Els dos es comparen trucant a `>=` sobre els seus valors interns.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Comparació de dos `Rc`s.
    ///
    /// Els dos es comparen trucant a `cmp()` sobre els seus valors interns.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Assigneu una llesca comptada amb referències i empleneu-la clonant els elements de "v".
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Assigneu una llesca de cadena comptada amb referències i copieu-hi `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Assigneu una llesca de cadena comptada amb referències i copieu-hi `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Moveu un objecte amb caixa a una assignació nova, comptada amb referències.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Assigneu una llesca comptada amb referències i moveu-hi els elements de `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Permet que el Vec alliberi la seva memòria, però no en destrueixi el contingut
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Agafa cada element del `Iterator` i el recull en un `Rc<[T]>`.
    ///
    /// # Característiques de rendiment
    ///
    /// ## El cas general
    ///
    /// En el cas general, la recopilació a `Rc<[T]>` es realitza recopilant primer a un `Vec<T>`.És a dir, quan escriviu el següent:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// això es comporta com si escrivíssim:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // El primer conjunt d'assignacions passa aquí.
    ///     .into(); // Aquí es fa una segona assignació per a `Rc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Això s'assignarà tantes vegades com calgui per construir el `Vec<T>` i, a continuació, s'assignarà una vegada per convertir el `Vec<T>` en el `Rc<[T]>`.
    ///
    ///
    /// ## Iteradors de longitud coneguda
    ///
    /// Quan el vostre `Iterator` implementi `TrustedLen` i tingui una mida exacta, es farà una única assignació per al `Rc<[T]>`.Per exemple:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Aquí només hi ha una assignació única.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Especialització trait que s`utilitza per recollir a `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // És el cas d`un iterador `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SEGURETAT: hem de garantir que l'iterador tingui una longitud exacta i que tinguem.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Torneu a la implementació normal.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` és una versió de [`Rc`] que conté una referència que no és propietària de l'assignació gestionada.S'accedeix a l'assignació trucant a [`upgrade`] al punter `Weak`, que retorna una [`Opció`]`<`[`Rc`] `<T>>`.
///
/// Com que una referència `Weak` no compta amb la propietat, no evitarà que es caigui el valor emmagatzemat a l'assignació i el propi `Weak` no garanteix que el valor encara estigui present.
/// Per tant, pot retornar [`None`] quan ["actualitzar"] d.
/// Tingueu en compte, però, que una referència `Weak`*no* impedeix la distribució de l'assignació mateixa (el magatzem de suport).
///
/// Un punter `Weak` és útil per mantenir una referència temporal a l'assignació gestionada per [`Rc`] sense impedir que es baixi el seu valor intern.
/// També s'utilitza per evitar referències circulars entre els punters [`Rc`], ja que les referències de propietat mútua mai permetrien deixar caure cap dels dos [`Rc`].
/// Per exemple, un arbre pot tenir indicadors [`Rc`] forts des de nodes pares fins a fills, i indicadors `Weak` des de nens fins als seus pares.
///
/// La forma típica d'obtenir un punter `Weak` és trucar a [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Es tracta d`un `NonNull` que permet optimitzar la mida d`aquest tipus a les enumeracions, però no necessàriament és un punter vàlid.
    //
    // `Weak::new` ho defineix a `usize::MAX` perquè no necessiti assignar espai al munt.
    // Aquest no és un valor que tindrà mai un punter real perquè RcBox té alineació com a mínim 2.
    // Això només és possible quan `T: Sized`;`T` sense mida mai no penja.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Construeix un nou `Weak<T>`, sense assignar cap memòria.
    /// Trucar a [`upgrade`] pel valor de retorn sempre proporciona [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Tipus d'ajuda per permetre l'accés als recomptes de referència sense fer cap afirmació sobre el camp de dades.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Retorna un punter en brut a l'objecte `T` que apunta aquest `Weak<T>`.
    ///
    /// El punter només és vàlid si hi ha algunes referències fortes.
    /// El punter pot estar penjat, sense alinear o fins i tot [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Tots dos apunten al mateix objecte
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // El fort aquí el manté viu, de manera que encara podem accedir a l`objecte.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Però ja no.
    /// // Podem fer weak.as_ptr(), però accedir al punter comportaria un comportament indefinit.
    /// // assert_eq! ("hola", insegur {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Si el punter penja, retornem la sentinella directament.
            // Aquesta no pot ser una adreça de càrrega útil vàlida, ja que la càrrega útil està almenys tan alineada com RcBox (usize).
            ptr as *const T
        } else {
            // SEGURETAT: si is_dangling retorna false, el punter no es pot referenciar.
            // És possible que la càrrega útil es redueixi en aquest moment i hem de mantenir la procedència, de manera que utilitzeu la manipulació del punter en brut.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Consumeix el `Weak<T>` i el converteix en un punter en brut.
    ///
    /// Això converteix el punter feble en un punter cru, tot i que es conserva la propietat d'una referència feble (el recompte feble no es modifica amb aquesta operació).
    /// Es pot tornar a convertir en el `Weak<T>` amb [`from_raw`].
    ///
    /// S'apliquen les mateixes restriccions d'accés a l'objectiu del punter que amb [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Converteix un punter en brut creat prèviament per [`into_raw`] en `Weak<T>`.
    ///
    /// Es pot utilitzar per obtenir una referència segura (trucant més tard a [`upgrade`]) o per localitzar el recompte feble deixant caure el `Weak<T>`.
    ///
    /// Adopta la propietat d`una referència feble (a excepció dels indicadors creats per [`new`], ja que aquests no posseeixen res; el mètode encara funciona).
    ///
    /// # Safety
    ///
    /// El punter deu haver estat originari del [`into_raw`] i encara ha de posseir la seva possible referència feble.
    ///
    /// Es permet que el recompte fort sigui 0 en el moment de trucar a això.
    /// Tot i això, es fa propietari d'una referència feble representada actualment com a punter en brut (el recompte feble no es modifica amb aquesta operació) i, per tant, s'ha de combinar amb una trucada anterior a [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Disminuir l`últim recompte feble.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Vegeu Weak::as_ptr per veure el context de com es deriva el punter d'entrada.

        let ptr = if is_dangling(ptr as *mut T) {
            // Això és un dèbil penjant.
            ptr as *mut RcBox<T>
        } else {
            // En cas contrari, estem garantits que el punter provenia d`un punt feble que no té res.
            // SEGURETAT: data_offset és segur de trucar, ja que ptr fa referència a un T. real (potencialment caigut).
            let offset = unsafe { data_offset(ptr) };
            // Per tant, invertim el desplaçament per obtenir tot el RcBox.
            // SEGURETAT: el punter es va originar en un punt feble, de manera que aquest desplaçament és segur.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SEGURETAT: ara hem recuperat el punter feble original, de manera que podem crear el punt feble.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Intenta actualitzar el punter `Weak` a un [`Rc`], retardant la caiguda del valor intern si té èxit.
    ///
    ///
    /// Retorna [`None`] si des de llavors s'ha perdut el valor intern.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Destrueix tots els indicadors forts.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Obté el nombre de punteres (`Rc`) forts que apunten a aquesta assignació.
    ///
    /// Si `self` es va crear amb [`Weak::new`], tornarà 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Obté el nombre de punteres `Weak` que apunten a aquesta assignació.
    ///
    /// Si no queden indicadors forts, tornarà a zero.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // restar el ptr feble implícit
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Retorna `None` quan el punter està penjat i no hi ha `RcBox` assignat, (és a dir, quan aquest `Weak` va ser creat per `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Tenim cura de *no* crear una referència que cobreixi el camp "data", ja que es pot mutar simultàniament (per exemple, si es deixa caure l'últim `Rc`, el camp de dades es deixarà caure al seu lloc).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Retorna `true` si els dos `Debils` apunten a la mateixa assignació (similar a [`ptr::eq`]), o si tots dos no assenyalen cap assignació (perquè es van crear amb `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Com que això compara els indicadors, significa que `Weak::new()` serà igual, encara que no assenyali cap assignació.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Comparant `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Deixa caure el punter `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // No imprimeix res
    /// drop(foo);        // Imprimeix "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // el recompte feble comença a 1 i només anirà a zero si han desaparegut tots els indicadors forts.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Fa un clon del punter `Weak` que apunta a la mateixa assignació.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Construeix un nou `Weak<T>`, assignant memòria per a `T` sense inicialitzar-lo.
    /// Trucar a [`upgrade`] pel valor de retorn sempre proporciona [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Hem comprovat_afegit aquí per tractar amb mem::forget amb seguretat.En particular
// si feu servir mem::forget Rcs (o Weaks), el recompte es pot desbordar i llavors podeu alliberar l'assignació mentre existeixin Rcs (o Weaks) pendents.
//
// Avortem perquè aquest és un escenari tan degenerat que no ens importa el que passi; cap programa real no hauria d`experimentar-ho mai.
//
// Això hauria de tenir despeses generals insignificants, ja que en realitat no cal clonar-les a Rust gràcies a la propietat i la semàntica de moviment.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Volem avortar en cas de desbordament en lloc de deixar caure el valor.
        // El recompte de referència mai serà nul quan es crida aquesta;
        // tanmateix, inserim un avortament aquí per donar a entendre a LLVM una optimització que no es pot trobar.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Volem avortar en cas de desbordament en lloc de deixar caure el valor.
        // El recompte de referència mai serà nul quan es crida aquesta;
        // tanmateix, inserim un avortament aquí per donar a entendre a LLVM una optimització que no es pot trobar.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Obteniu el desplaçament dins d'un `RcBox` per a la càrrega útil darrere d'un punter.
///
/// # Safety
///
/// El punter ha d'assenyalar (i tenir metadades vàlides per a) una instància vàlida de T prèviament, però es pot deixar caure la T.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Alineeu el valor sense mida al final del RcBox.
    // Com que RcBox és repr(C), sempre serà l'últim camp de la memòria.
    // SEGURETAT: atès que els únics tipus no dimensionats possibles són les llesques, objectes trait,
    // i tipus externs, el requisit de seguretat d`entrada és actualment suficient per satisfer els requisits d`alineament_de_val_raw;es tracta d`un detall d`implementació del llenguatge que pot no confiar-se fora de std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}