//! API d'assignació de memòria

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Aquests són els símbols màgics per anomenar l`assignador global.rustc els genera per trucar a `__rg_alloc`, etc.
    // si hi ha un atribut `#[global_allocator]` (el codi que amplia aquesta macro d'atribut genera aquestes funcions), o per trucar a les implementacions per defecte a libstd (`__rdl_alloc`, etc.)
    //
    // en `library/std/src/alloc.rs`) en cas contrari.
    // El rustc fork de LLVM també posa en casos especials aquests noms de funcions per poder optimitzar-los com `malloc`, `realloc` i `free`, respectivament.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// L'assignador de memòria global.
///
/// Aquest tipus implementa el [`Allocator`] trait reenviant trucades a l`assignador registrat amb l`atribut `#[global_allocator]` si n`hi ha un o el `std` crate per defecte.
///
///
/// Note: mentre aquest tipus és inestable, es pot accedir a la funcionalitat que proporciona a través del [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Assigneu memòria amb l`assignador global.
///
/// Aquesta funció reenvia les trucades al mètode [`GlobalAlloc::alloc`] de l`assignador registrat amb l`atribut `#[global_allocator]` si n`hi ha un o el valor per defecte del `std` crate.
///
///
/// S'espera que aquesta funció quedi obsoleta en favor del mètode `alloc` del tipus [`Global`] quan aquest i el [`Allocator`] trait es tornin estables.
///
/// # Safety
///
/// Vegeu [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Repartiu la memòria amb l'assignador global.
///
/// Aquesta funció reenvia les trucades al mètode [`GlobalAlloc::dealloc`] de l`assignador registrat amb l`atribut `#[global_allocator]` si n`hi ha un o el valor per defecte del `std` crate.
///
///
/// S'espera que aquesta funció quedi obsoleta en favor del mètode `dealloc` del tipus [`Global`] quan aquest i el [`Allocator`] trait es tornin estables.
///
/// # Safety
///
/// Vegeu [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Reassigneu la memòria amb l`assignador global.
///
/// Aquesta funció reenvia les trucades al mètode [`GlobalAlloc::realloc`] de l`assignador registrat amb l`atribut `#[global_allocator]` si n`hi ha un o el valor per defecte del `std` crate.
///
///
/// S'espera que aquesta funció quedi obsoleta en favor del mètode `realloc` del tipus [`Global`] quan aquest i el [`Allocator`] trait es tornin estables.
///
/// # Safety
///
/// Vegeu [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Assigneu memòria inicialitzada zero amb l`assignador global.
///
/// Aquesta funció reenvia les trucades al mètode [`GlobalAlloc::alloc_zeroed`] de l`assignador registrat amb l`atribut `#[global_allocator]` si n`hi ha un o el valor per defecte del `std` crate.
///
///
/// S'espera que aquesta funció quedi obsoleta en favor del mètode `alloc_zeroed` del tipus [`Global`] quan aquest i el [`Allocator`] trait es tornin estables.
///
/// # Safety
///
/// Vegeu [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // SEGURETAT: la mida `layout` no és nul・la,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // SEGURETAT: Igual que `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // SEGURETAT: `new_size` no és nul, ja que `old_size` és superior o igual a `new_size`
            // segons les condicions de seguretat.La persona que truca ha de complir altres condicions
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` probablement comproveu si hi ha `new_size >= old_layout.size()` o alguna cosa similar.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SEGURETAT: perquè `new_layout.size()` ha de ser superior o igual a `old_size`,
            // tant l'assignació de memòria antiga com la nova són vàlides per a lectures i escriptures per a bytes `old_size`.
            // A més, com que l`assignació antiga encara no estava repartida, no es pot superposar a `new_ptr`.
            // Per tant, la trucada a `copy_nonoverlapping` és segura.
            // La persona que truca ha de confirmar el contracte de seguretat del `dealloc`.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // SEGURETAT: la mida `layout` no és nul・la,
            // la persona que truca ha de complir altres condicions
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURETAT: totes les condicions han de ser respectades per la persona que truca
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SEGURETAT: totes les condicions han de ser respectades per la persona que truca
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // SEGURETAT: les condicions han de ser confirmades per la persona que truca
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // SEGURETAT: `new_size` no és nul.La persona que truca ha de complir altres condicions
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` probablement comproveu si hi ha `new_size <= old_layout.size()` o alguna cosa similar.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SEGURETAT: perquè `new_size` ha de ser menor o igual a `old_layout.size()`,
            // tant l'assignació de memòria antiga com la nova són vàlides per a lectures i escriptures per a bytes `new_size`.
            // A més, com que l`assignació antiga encara no estava repartida, no es pot superposar a `new_ptr`.
            // Per tant, la trucada a `copy_nonoverlapping` és segura.
            // La persona que truca ha de confirmar el contracte de seguretat del `dealloc`.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// L`assignador de punteres únics.
// Aquesta funció no s'ha de desconnectar.Si ho fa, el codegen MIR fallarà.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Aquesta signatura ha de ser la mateixa que `Box`, en cas contrari es produirà un ICE.
// Quan s'afegeix un paràmetre addicional a `Box` (com `A: Allocator`), també s'ha d'afegir aquí.
// Per exemple, si `Box` es canvia a `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, aquesta funció també s'ha de canviar a `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Gestor d'errors d'assignació

extern "Rust" {
    // Aquest és el símbol màgic per trucar al gestor d'errors assignació global.
    // rustc el genera per trucar a `__rg_oom` si hi ha un `#[alloc_error_handler]`, o trucar a les implementacions per defecte per sota de (`__rdl_oom`) en cas contrari.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Interrompre l'error o error d'assignació de memòria.
///
/// Es recomana a les trucades de les API d'assignació de memòria que vulguin avortar el càlcul en resposta a un error d'assignació a trucar a aquesta funció, en lloc d'invocar directament `panic!` o similar.
///
///
/// El comportament per defecte d`aquesta funció és imprimir un missatge a un error estàndard i avortar el procés.
/// Es pot substituir per [`set_alloc_error_hook`] i [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Per a la prova d'assignació es pot utilitzar directament `std::alloc::handle_alloc_error`.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // anomenat mitjançant `__rust_alloc_error_handler` generat

    // si no hi ha `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // si hi ha un `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Especialitzeu els clons en memòria no assignada prèviament assignada.
/// Utilitzat per `Box::clone` i `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Haver assignat *primer* pot permetre a l`optimitzador crear el valor clonat al lloc, saltant-se el local i moure`s.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Sempre podem copiar al lloc, sense implicar mai cap valor local.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}