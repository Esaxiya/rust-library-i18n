//! Utilitats per formatar i imprimir `String`s.
//!
//! Aquest mòdul conté el suport en temps d'execució de l'extensió de sintaxi [`format!`].
//! Aquesta macro s'implementa al compilador per emetre trucades a aquest mòdul per tal de formatar arguments en temps d'execució en cadenes.
//!
//! # Usage
//!
//! La macro [`format!`] està pensada per ser familiar per a aquells que provenen de les funcions `printf`/`fprintf` de C o de la funció `str.format` de Python.
//!
//! Alguns exemples de l'extensió [`format!`] són:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" amb zeros inicials
//! ```
//!
//! A partir d`aquestes, podeu veure que el primer argument és una cadena de format.El compilador requereix que això sigui una cadena literal;no pot ser una variable passada (per tal de realitzar la comprovació de validesa).
//! El compilador analitzarà la cadena de format i determinarà si la llista d'arguments proporcionats és adequada per passar a aquesta cadena de format.
//!
//! Per convertir un valor únic en una cadena, utilitzeu el mètode [`to_string`].S`utilitzarà el format [`Display`] trait.
//!
//! ## Paràmetres posicionals
//!
//! Cada argument de format permet especificar quin argument de valor fa referència i, si s'omet, es suposa que és "the next argument".
//! Per exemple, la cadena de format `{} {} {}` prendria tres paràmetres i es formatarien en el mateix ordre que es dóna.
//! Tanmateix, la cadena de format `{2} {1} {0}` formataria els arguments en ordre invers.
//!
//! Les coses es poden posar una mica complicades quan comenceu a barrejar els dos tipus d'especificadors de posició.Es pot considerar que l'especificador "next argument" és un iterador de l'argument.
//! Cada vegada que es veu un especificador "next argument", l'iterador avança.Això condueix a un comportament com aquest:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! L'iterador intern de l'argument no s'ha avançat quan es veu el primer `{}`, de manera que imprimeix el primer argument.Després d'arribar al segon `{}`, l'iterador ha avançat al segon argument.
//! Bàsicament, els paràmetres que nomenen explícitament el seu argument no afecten els paràmetres que no nomenen un argument en termes d'especificadors de posició.
//!
//! Es requereix una cadena de format per utilitzar tots els seus arguments, en cas contrari és un error en temps de compilació.Podeu fer referència al mateix argument més d'una vegada a la cadena de format.
//!
//! ## Paràmetres anomenats
//!
//! Rust en si no té un equivalent similar a Python de paràmetres nomenats a una funció, però la macro [`format!`] és una extensió de sintaxi que li permet aprofitar paràmetres nomenats.
//! Els paràmetres anomenats s`enumeren al final de la llista d`arguments i tenen la sintaxi:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Per exemple, les expressions [`format!`] següents utilitzen tots els arguments anomenats:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! No és vàlid posar paràmetres posicionals (aquells sense noms) després d'arguments que tinguin noms.Igual que amb els paràmetres de posició, no és vàlid proporcionar paràmetres anomenats que la cadena de format no utilitza.
//!
//! # Paràmetres de format
//!
//! Cada argument que s'està formatant es pot transformar mitjançant diversos paràmetres de format (corresponents a `format_spec` a [the syntax](#syntax)). Aquests paràmetres afecten la representació de cadenes del que s'està formatant.
//!
//! ## Width
//!
//! ```
//! // Tot això imprimeix "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Aquest és un paràmetre per al "minimum width" que hauria de tenir el format.
//! Si la cadena del valor no omple tants caràcters, el farciment especificat per fill/alignment s'utilitzarà per ocupar l'espai requerit (vegeu més avall).
//!
//! El valor de l'amplada també es pot proporcionar com a [`usize`] a la llista de paràmetres afegint un postfix `$`, que indica que el segon argument és un [`usize`] que especifica l'amplada.
//!
//! Referir-se a un argument amb la sintaxi del dòlar no afecta el comptador "next argument", per la qual cosa sol ser una bona idea referir-se a arguments per posició o utilitzar arguments amb nom.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! El caràcter de farciment i l'alineació opcionals es proporcionen normalment juntament amb el paràmetre [`width`](#width).S'ha de definir abans de l `width`, just després de l `:`.
//! Això indica que si el valor que s`està formatant és inferior a `width`, s`imprimiran uns caràcters addicionals al seu voltant.
//! El farciment inclou les variants següents per a diferents alineacions:
//!
//! * `[fill]<` - l'argument està alineat a l'esquerra a les columnes `width`
//! * `[fill]^` - l'argument està alineat al centre en columnes `width`
//! * `[fill]>` - l'argument està alineat a la dreta a les columnes `width`
//!
//! El valor [fill/alignment](#fillalignment) per defecte per als no numèrics és un espai i alineat a l'esquerra.El valor per defecte dels formators numèrics també és un caràcter espacial però amb alineació a la dreta.
//! Si s`especifica el senyalador `0` (vegeu més avall) per a la numèrica, el caràcter de farciment implícit és `0`.
//!
//! Tingueu en compte que és possible que alguns tipus no implementin l'alineació.En particular, generalment no s`implementa per al `Debug` trait.
//! Una bona manera d`assegurar-se que s`aplica el farciment és formatar la vostra entrada i, a continuació, enganxar aquesta cadena resultant per obtenir la vostra sortida:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Hola Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Totes aquestes bandes alteren el comportament del formatador.
//!
//! * `+` - Està pensat per a tipus numèrics i indica que el signe sempre s'ha d'imprimir.Els signes positius mai s`imprimeixen de manera predeterminada i el signe negatiu només s`imprimeix per defecte per a l `Signed` trait.
//! Aquest indicador indica que sempre s`ha d`imprimir el signe correcte (`+` o `-`).
//! * `-` - Actualment no s'utilitza
//! * `#` - Aquest indicador indica que s`ha d`utilitzar la forma d`impressió "alternate".Les formes alternatives són:
//!     * `#?` - imprimeix força el format [`Debug`]
//!     * `#x` - precedeix l'argument amb un `0x`
//!     * `#X` - precedeix l'argument amb un `0x`
//!     * `#b` - precedeix l'argument amb un `0b`
//!     * `#o` - precedeix l'argument amb un `0o`
//! * `0` - S`utilitza per indicar per a formats enters que el farcit a `width` s`ha de fer amb un caràcter `0`, així com tenir en compte els signes.
//! Un format com `{:08}` donaria `00000001` per a l`enter `1`, mentre que el mateix format donaria `-0000001` per a l`enter `-1`.
//! Fixeu-vos que la versió negativa té un zero menys que la versió positiva.
//!         Tingueu en compte que els zeros de farciment sempre es col・loquen després del signe (si n'hi ha) i abans dels dígits.Quan s`utilitza juntament amb el senyalador `#`, s`aplica una regla similar: els zeros de farciment s`insereixen després del prefix, però abans dels dígits.
//!         El prefix s'inclou a l'amplada total.
//!
//! ## Precision
//!
//! Per als tipus no numèrics, es pot considerar un "maximum width".
//! Si la cadena resultant és més gran que aquesta amplada, es trunca fins a comptar amb molts caràcters i aquest valor truncat s'emet amb els `fill`, `alignment` i `width` adequats si s'estableixen aquests paràmetres.
//!
//! Per als tipus integrals, això s'ignora.
//!
//! Per als tipus de coma flotant, indica quants dígits després del punt decimal s'han d'imprimir.
//!
//! Hi ha tres maneres possibles d'especificar el `precision` desitjat:
//!
//! 1. Un enter `.N`:
//!
//!    el nombre enter `N` és la precisió.
//!
//! 2. Un nombre enter o nom seguit del signe de dòlar `.N$`:
//!
//!    utilitzeu el format *argument*`N` (que ha de ser un `usize`) com a precisió.
//!
//! 3. Un asterisc `.*`:
//!
//!    `.*` significa que aquest `{...}` està associat amb entrades de format *dos* en lloc d'una: la primera entrada té la precisió `usize` i la segona té el valor per imprimir.
//!    Tingueu en compte que, en aquest cas, si s'utilitza la cadena de format `{<arg>:<spec>.*}`, la part `<arg>` fa referència al valor* per imprimir i el `precision` ha d'entrar a l'entrada anterior a `<arg>`.
//!
//! Per exemple, totes les trucades següents imprimeixen el mateix `Hello x is 0.01000`:
//!
//! ```
//! // Hola {arg 0 ("x")} és {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Hola {arg 1 ("x")} és {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Hola {arg 0 ("x")} és {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Hola {next arg ("x")} és {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Hola {next arg ("x")} és {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Hola {next arg ("x")} és {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Tot i que aquests:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! imprimeix tres coses significativament diferents:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! En alguns llenguatges de programació, el comportament de les funcions de format de cadena depèn de la configuració regional del sistema operatiu.
//! Les funcions de format proporcionades per la biblioteca estàndard de Rust no tenen cap concepte de configuració regional i produiran els mateixos resultats en tots els sistemes independentment de la configuració de l'usuari.
//!
//! Per exemple, el següent codi sempre imprimirà `1.5` fins i tot si la configuració regional del sistema utilitza un separador decimal que no sigui un punt.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Els caràcters literals `{` i `}` es poden incloure en una cadena precedint-los del mateix caràcter.Per exemple, el caràcter `{` s'escapa amb `{{` i el caràcter `}` s'escapa amb `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Per resumir, aquí podeu trobar la gramàtica completa de les cadenes de format.
//! La sintaxi del llenguatge de format utilitzat prové d'altres idiomes, de manera que no hauria de ser massa estranya.Els arguments estan formatats amb una sintaxi similar a Python, el que significa que els arguments estan envoltats per `{}` en lloc de la `%` com C.
//! La gramàtica real de la sintaxi de format és:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! A la gramàtica anterior, `text` no pot contenir cap caràcter `'{'` o `'}'`.
//!
//! # Format de traits
//!
//! Quan sol・liciteu el format d'un argument amb un tipus concret, realment sol・liciteu que un argument s'atribueixi a un trait concret.
//! Això permet formatar diversos tipus reals mitjançant `{:x}` (com [`i8`] i [`isize`]).El mapatge actual de tipus a traits és:
//!
//! * *res* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] amb nombres enters hexadecimals en minúscules
//! * `X?` ⇒ [`Debug`] amb nombres enters hexadecimals en majúscules
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Això vol dir que qualsevol tipus d'argument que implementi [`fmt::Binary`][`Binary`] trait es pugui formatar amb `{:b}`.La biblioteca estàndard també proporciona implementacions per a aquests traits per a diversos tipus primitius.
//!
//! Si no s'especifica cap format (com a `{}` o `{:6}`), el format trait utilitzat és el [`Display`] trait.
//!
//! En implementar un format trait per al vostre propi tipus, haureu d'implementar un mètode de signatura:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // el nostre tipus personalitzat
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! El vostre tipus es passarà com a referència secundària `self` i, a continuació, la funció hauria d'emetre sortida al flux `f.buf`.Depèn de cada implementació de format trait complir correctament els paràmetres de format sol・licitats.
//! Els valors d'aquests paràmetres es mostraran als camps de l'estructura [`Formatter`].Per ajudar-hi, l`estructura [`Formatter`] també proporciona alguns mètodes d`ajuda.
//!
//! A més, el valor de retorn d`aquesta funció és [`fmt::Result`], que és un àlies de tipus de [`Resultat`]` <(), `[` std: : fmt::Error`]`>`.
//! Les implementacions de format han de garantir que propaguen els errors des del [`Formatter`] (per exemple, quan es truca al [`write!`]).
//! Tanmateix, mai no haurien de retornar erròniament els errors.
//! És a dir, una implementació de format només pot retornar un error si el [`Formatter`] rebut retorna un error.
//! Això es deu al fet que, al contrari del que podria suggerir la signatura de la funció, el format de cadena és una operació infal・lible.
//! Aquesta funció només retorna un resultat perquè l'escriptura al flux subjacent pot fallar i ha de proporcionar una manera de propagar el fet que s'ha produït un error en fer una còpia de seguretat de la pila.
//!
//! Un exemple d'implementació del format traits seria el següent:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // El valor `f` implementa el `Write` trait, que és el que escriu!s'espera una macro.
//!         // Tingueu en compte que aquest format ignora els diversos indicadors proporcionats per formatar cadenes.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Diferents traits permeten diferents formes de sortida d'un tipus.
//! // El significat d`aquest format és imprimir la magnitud d`un vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Respecteu els senyaladors de format mitjançant el mètode auxiliar `pad_integral` a l'objecte Formatter.
//!         // Consulteu la documentació del mètode per obtenir més informació i la funció `pad` es pot utilitzar per encoixinar les cadenes.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` contra `fmt::Debug`
//!
//! Aquests dos formats de traits tenen finalitats diferents:
//!
//! - [`fmt::Display`][`Display`] les implementacions afirmen que el tipus es pot representar fidelment com una cadena UTF-8 en tot moment.**No** s'espera que tots els tipus implementin el [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] les implementacions s'han d'implementar per a **tots els** tipus públics.
//!   La sortida normalment representarà l`estat intern de la forma més fidel possible.
//!   L'objectiu del [`Debug`] trait és facilitar la depuració del codi Rust.En la majoria dels casos, és suficient i es recomana utilitzar `#[derive(Debug)]`.
//!
//! Alguns exemples de la sortida de tots dos traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Macros relacionades
//!
//! Hi ha una sèrie de macros relacionades a la família [`format!`].Els que s`implementen actualment són:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! This i [`writeln!`] són dues macros que s`utilitzen per emetre la cadena de format a un flux especificat.S'utilitza per evitar assignacions intermèdies de cadenes de format i, en canvi, escriure directament la sortida.
//! Sota el capó, aquesta funció realment invoca la funció [`write_fmt`] definida al [`std::io::Write`] trait.
//! L`exemple d`ús és:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Això i [`println!`] emeten la seva sortida a stdout.De manera similar a la macro [`write!`], l'objectiu d'aquestes macros és evitar assignacions intermèdies en imprimir la sortida.L`exemple d`ús és:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Les macros [`eprint!`] i [`eprintln!`] són idèntiques a [`print!`] i [`println!`], respectivament, tret que emeten la seva sortida a stderr.
//!
//! ### `format_args!`
//!
//! Es tracta d`una curiosa macro que s`utilitza per passar amb seguretat un objecte opac que descriu la cadena de format.Aquest objecte no requereix cap assignació de pila per crear i només fa referència a la informació de la pila.
//! Sota el capó, totes les macros relacionades s`implementen en funció d`això.
//! En primer lloc, alguns exemples d`ús són:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! El resultat de la macro [`format_args!`] és un valor del tipus [`fmt::Arguments`].
//! Aquesta estructura es pot passar a les funcions [`write`] i [`format`] dins d`aquest mòdul per processar la cadena de format.
//! L`objectiu d`aquesta macro és evitar encara més les assignacions intermèdies quan es tracta de formatar cadenes.
//!
//! Per exemple, una biblioteca de registre podria utilitzar la sintaxi de format estàndard, però passaria per aquesta estructura internament fins que s'hagi determinat cap a on hauria d'anar la sortida.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// La funció `format` pren una estructura [`Arguments`] i retorna la cadena formatada resultant.
///
///
/// La instància [`Arguments`] es pot crear amb la macro [`format_args!`].
///
/// # Examples
///
/// Ús bàsic:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Tingueu en compte que pot ser preferible utilitzar [`format!`].
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}