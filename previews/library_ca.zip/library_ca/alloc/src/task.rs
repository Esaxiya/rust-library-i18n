#![stable(feature = "wake_trait", since = "1.51.0")]
//! Tipus i Traits per treballar amb tasques asíncrones.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// La implementació de despertar una tasca en un executor.
///
/// Aquest trait es pot utilitzar per crear un [`Waker`].
/// Un executor pot definir una implementació d`aquest trait i utilitzar-lo per construir un Waker per passar a les tasques que s`executen en aquest executor.
///
/// Aquest trait és una alternativa ergonòmica i segura per a la memòria per construir un [`RawWaker`].
/// Admet el disseny d`executor comú en què les dades utilitzades per activar una tasca s`emmagatzemen en un [`Arc`].
/// Alguns executors (especialment els de sistemes incrustats) no poden utilitzar aquesta API, motiu pel qual [`RawWaker`] existeix com a alternativa per a aquests sistemes.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Una funció bàsica `block_on` que pren un future i l'executa fins al final del fil actual.
///
/// **Note:** Aquest exemple canvia la correcció per simplicitat.
/// Per evitar bloquejos, les implementacions de nivell de producció també hauran de gestionar les trucades intermèdies a `thread::unpark`, així com les invocacions imbricades.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Un waker que desperta el fil actual quan es crida.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Executeu un future fins al final del fil actual.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Fixeu el future perquè es pugui interrogar.
///     let mut fut = Box::pin(fut);
///
///     // Creeu un context nou per passar al future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Executeu el future fins a la seva finalització.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Desperta aquesta tasca.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Despertar aquesta tasca sense consumir el waker.
    ///
    /// Si un executor admet una forma més barata de despertar sense consumir el waker, hauria de substituir aquest mètode.
    /// Per defecte, clona el [`Arc`] i crida a [`wake`] al clon.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SEGURETAT: això és segur perquè raw_waker construeix de manera segura
        // un RawWaker d'Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Aquesta funció privada per construir un RawWaker s'utilitza en lloc de
// incorporant-ho a l'impl `From<Arc<W>> for RawWaker`, per assegurar-vos que la seguretat de `From<Arc<W>> for Waker` no depèn de l'enviament trait correcte, en canvi, tots dos impls criden aquesta funció directa i explícitament.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Incrementeu el recompte de referència de l'arc per clonar-lo.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Despert per valor, movent l'Arc a la funció Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Despertar per referència, embolicar el waker a ManuallyDrop per evitar deixar-lo caure
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Disminuir el recompte de referència de l'Arc a la caiguda
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}