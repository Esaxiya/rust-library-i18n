use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Un pla per a instàncies fictícies de prova de fallades que controlen esdeveniments concrets.
/// Algunes instàncies es poden configurar a panic en algun moment.
/// Els esdeveniments són `clone`, `drop` o alguns `query` anònims.
///
/// Els dummies de prova de bloqueig s`identifiquen i s`ordenen mitjançant un identificador, de manera que es poden utilitzar com a claus en un BTreeMap.
/// La implementació que s`utilitza intencionadament no depèn de res definit a la crate, a part de la `Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Crea un disseny fictici de prova de fallades.El `id` determina l'ordre i la igualtat d'instàncies.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Crea una instància d'un simulador de prova de fallades que registra els esdeveniments que experimenta i, opcionalment, panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Retorna el nombre de vegades que s'han clonat casos de maniquí.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Retorna el nombre de vegades que s'han eliminat les instàncies del maniquí.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Retorna el nombre de vegades que s'ha invocat el membre `query` a les instàncies del maniquí.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Alguna consulta anònima, el resultat de la qual ja es dóna.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}