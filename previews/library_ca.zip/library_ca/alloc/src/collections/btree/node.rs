// Es tracta d`un intent d`implementació que segueix l`ideal
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Com que Rust en realitat no té tipus dependents i recursivitat polimòrfica, ens conformem amb molta inseguretat.
//

// Un dels objectius principals d`aquest mòdul és evitar la complexitat tractant l`arbre com un contenidor genèric (si té una forma estranya) i evitant tractar amb la majoria dels invariants de l`arbre B.
//
// Com a tal, a aquest mòdul no li importa si s`ordenen les entrades, quins nodes poden estar incomplets o, fins i tot, el que significa subfull.Tot i això, ens basem en uns quants invariants:
//
// - Els arbres han de tenir un uniforme depth/height.Això vol dir que cada trajecte fins a una fulla d'un determinat node té exactament la mateixa longitud.
// - Un node de longitud `n` té claus `n`, valors `n` i arestes `n + 1`.
//   Això implica que fins i tot un node buit té almenys un edge.
//   Per a un node de fulla, "having an edge" només significa que podem identificar una posició al node, ja que les vores de les fulles estan buides i no necessiten representació de dades.
// En un node intern, un edge identifica una posició i conté un punter cap a un node fill.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// La representació subjacent dels nodes fulls i part de la representació dels nodes interns.
struct LeafNode<K, V> {
    /// Volem ser covariants a `K` i `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// L'índex d'aquest node a la matriu `edges` del node pare.
    /// `*node.parent.edges[node.parent_idx]` hauria de ser el mateix que `node`.
    /// Això només es garanteix que s'inicialitzarà quan `parent` no sigui nul.
    parent_idx: MaybeUninit<u16>,

    /// El nombre de claus i valors que emmagatzema aquest node.
    len: u16,

    /// Les matrius que emmagatzemen les dades reals del node.
    /// Només s`inicialitzen i són vàlids els primers elements `len` de cada matriu.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Inicialitza un nou `LeafNode` al lloc.
    unsafe fn init(this: *mut Self) {
        // Com a política general, deixem els camps sense inicialitzar si poden ser, ja que hauria de ser lleugerament més ràpid i fàcil de rastrejar a Valgrind.
        //
        unsafe {
            // parent_idx, claus i vals són PotserUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Crea un nou `LeafNode` amb caixa.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// La representació subjacent dels nodes interns.Igual que amb `LeafNode`s, aquests haurien d'estar amagats darrere de`BoxedNode`s per evitar deixar caure valors i claus no inicialitzats.
/// Qualsevol punter a un `InternalNode` es pot llançar directament a un punter a la porció `LeafNode` subjacent del node, permetent que el codi actuï genèricament sobre els nodes fulls i interns sense haver de comprovar fins i tot a quin dels dos apunta un punter.
///
/// Aquesta propietat està habilitada mitjançant l'ús de `repr(C)`.
///
#[repr(C)]
// gdb_providers.py utilitza aquest nom de tipus per a la introspecció.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Els indicadors dels fills d`aquest node.
    /// `len + 1` d'aquests es consideren inicialitzats i vàlids, excepte que a prop del final, mentre l'arbre es manté mitjançant un préstec tipus `Dying`, alguns d'aquests indicadors estan penjats.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Crea un nou `InternalNode` amb caixa.
    ///
    /// # Safety
    /// Una invariant de nodes interns és que tenen almenys un edge inicialitzat i vàlid.
    /// Aquesta funció no configura aquest edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Només cal inicialitzar les dades;les vores són MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Un punter gestionat i no nul a un node.Es tracta d'un punter de propietat a `LeafNode<K, V>` o d'un punter de propietat a `InternalNode<K, V>`.
///
/// Tanmateix, `BoxedNode` no conté informació sobre quin dels dos tipus de nodes conté realment i, parcialment a causa d'aquesta manca d'informació, no és un tipus separat i no té cap destructor.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// El node arrel d'un arbre propietat.
///
/// Tingueu en compte que no té cap destructor i s`ha de netejar manualment.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Retorna un nou arbre de propietat, amb el seu propi node arrel que inicialment està buit.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` no ha de ser zero.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Manlleu mutament el node arrel propietari.
    /// A diferència de `reborrow_mut`, això és segur perquè el valor de retorn no es pot utilitzar per destruir l'arrel i no hi pot haver altres referències a l'arbre.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// En préstec lleugerament mutable del node arrel propietari.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Transita de manera irreversible a una referència que permet el recorregut i ofereix mètodes destructius i poca cosa més.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Afegeix un nou node intern amb un sol edge que apunta al node arrel anterior, converteix aquest node nou en el node arrel i el retorna.
    /// Això augmenta 1 l`alçada i és el contrari que el `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, tret que només hem oblidat que ara som interns:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Elimina el node arrel intern, fent servir el seu primer fill com a nou node arrel.
    /// Com que només es pretén cridar-lo quan el node arrel només té un fill, no es fa cap neteja de cap de les claus, valors i altres fills.
    ///
    /// Això disminueix l`alçada en 1 i és el contrari que el `push_internal_level`.
    ///
    /// Requereix accés exclusiu a l'objecte `Root` però no al node arrel;
    /// no invalidarà altres identificadors ni referències al node arrel.
    ///
    /// Panics si no hi ha nivell intern, és a dir, si el node arrel és un full.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SEGURETAT: afirmem que som interns.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SEGURETAT: hem prestat exclusivament `self` i el seu tipus de préstec és exclusiu.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SEGURETAT: sempre s`inicialitza el primer edge.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` sempre és covariant a `K` i `V`, fins i tot quan el `BorrowType` és `Mut`.
// Això és tècnicament incorrecte, però no pot provocar cap seguretat a causa de l`ús intern de `NodeRef` perquè ens mantenim completament genèrics respecte a `K` i `V`.
//
// Tanmateix, sempre que un tipus públic emboliqui `NodeRef`, assegureu-vos que tingui la variància correcta.
//
/// Una referència a un node.
///
/// Aquest tipus té una sèrie de paràmetres que controlen el seu funcionament:
/// - `BorrowType`: Un tipus fictici que descriu el tipus de préstec i té una vida útil.
///    - Quan es tracta de `Immut<'a>`, el `NodeRef` actua aproximadament com `&'a Node`.
///    - Quan es tracta de `ValMut<'a>`, l `NodeRef` actua aproximadament com `&'a Node` pel que fa a les claus i l'estructura de l'arbre, però també permet que coexisteixen moltes referències mutables a valors de tot l'arbre.
///    - Quan es tracta de `Mut<'a>`, el `NodeRef` actua aproximadament com `&'a mut Node`, tot i que els mètodes d'inserció permeten coexistir un punter mutable a un valor.
///    - Quan es tracta de `Owned`, l `NodeRef` actua aproximadament com `Box<Node>`, però no té cap destructor i s'ha de netejar manualment.
///    - Quan es tracta de `Dying`, el `NodeRef` encara actua aproximadament com `Box<Node>`, però té mètodes per destruir l'arbre a poc a poc i els mètodes normals, tot i que no es marquen com a insegurs per trucar, poden invocar UB si es crida incorrectament.
///
///   Com que qualsevol `NodeRef` permet navegar per l'arbre, `BorrowType` s'aplica efectivament a tot l'arbre, no només al node en si.
/// - `K` i `V`: són els tipus de claus i valors emmagatzemats als nodes.
/// - `Type`: Pot ser `Leaf`, `Internal` o `LeafOrInternal`.
/// Quan aquest és `Leaf`, el `NodeRef` apunta a un node fulla, quan aquest és `Internal`, el `NodeRef` apunta a un node intern i, quan aquest és `LeafOrInternal`, el `NodeRef` pot apuntar cap a qualsevol tipus de node.
///   `Type` s`anomena `NodeType` quan s`utilitza fora de `NodeRef`.
///
/// Tant `BorrowType` com `NodeType` restringeixen els mètodes que implementem per aprofitar la seguretat del tipus estàtic.Hi ha limitacions en la manera com podem aplicar aquestes restriccions:
/// - Per a cada paràmetre de tipus, només podem definir un mètode de manera genèrica o per a un tipus concret.
/// Per exemple, no podem definir un mètode com `into_kv` genèricament per a tots els `BorrowType`, o una vegada per a tots els tipus que tinguin tota la vida, perquè volem que torni referències `&'a`.
///   Per tant, el definim només per al tipus `Immut<'a>` menys potent.
/// - No podem obtenir la coacció implícita de `Mut<'a>` a `Immut<'a>`.
///   Per tant, hem de trucar explícitament a `reborrow` en un `NodeRef` més potent per arribar a un mètode com `into_kv`.
///
/// Tots els mètodes de `NodeRef` que retornen algun tipus de referència:
/// - Agafeu `self` per valor i torneu la vida útil de `BorrowType`.
///   De vegades, per invocar aquest mètode, hem de trucar al `reborrow_mut`.
/// - Preneu `self` com a referència i (implicitly) retornarà la vida útil d'aquesta referència, en lloc de la vida útil de `BorrowType`.
/// D`aquesta manera, el comprovador de préstecs garanteix que el `NodeRef` es manté prestat sempre que s`utilitzi la referència retornada.
///   Els mètodes que donen suport a la inserció doblen aquesta regla retornant un punter en brut, és a dir, una referència sense vida.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// El nombre de nivells que el node i el nivell de fulles estan separats, una constant del node que no pot ser descrita del tot per `Type` i que el mateix node no emmagatzema.
    /// Només ens cal emmagatzemar l`alçada del node arrel i derivar-ne l`altura de tots els altres nodes.
    /// Ha de ser zero si `Type` és `Leaf` i no és zero si `Type` és `Internal`.
    ///
    ///
    height: usize,
    /// El punter cap a la fulla o el node intern.
    /// La definició de `InternalNode` garanteix que el punter sigui vàlid de qualsevol manera.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Desempaqueteu una referència de node empaquetada com a `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Exposa les dades d`un node intern.
    ///
    /// Retorna un ptr en brut per evitar invalidar altres referències a aquest node.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SEGURETAT: el tipus de node estàtic és `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Presta accés exclusiu a les dades d`un node intern.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Troba la longitud del node.Aquest és el nombre de claus o valors.
    /// El nombre d`arestes és `len() + 1`.
    /// Tingueu en compte que, tot i ser segur, trucar a aquesta funció pot tenir l`efecte secundari d`invalidar les referències mutables que ha creat un codi no segur.
    ///
    pub fn len(&self) -> usize {
        // De manera crucial, només accedim al camp `len` aquí.
        // Si BorrowType és marker::ValMut, pot haver-hi referències mutables pendents de valors que no hem d`invalidar.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Retorna el nombre de nivells separats entre el node i el full.
    /// Alçada zero significa que el node és una fulla mateixa.
    /// Si imagineu arbres amb l`arrel a sobre, el número diu a quina elevació apareix el node.
    /// Si us imagineu arbres amb fulles a la part superior, el número indica quina altura s`estén per sobre del node.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Temporalment treu una altra referència immutable al mateix node.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Exposa la porció de fulla de qualsevol fulla o node intern.
    ///
    /// Retorna un ptr en brut per evitar invalidar altres referències a aquest node.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // El node ha de ser vàlid com a mínim per a la part LeafNode.
        // Aquesta no és una referència al tipus NodeRef perquè no sabem si ha de ser única o compartida.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Cerca el pare del node actual.
    /// Retorna `Ok(handle)` si el node actual realment té un pare, on `handle` apunta a la edge del pare que apunta al node actual.
    ///
    /// Retorna `Err(self)` si el node actual no té cap pare, retornant el `NodeRef` original.
    ///
    /// El nom del mètode suposa que us imagineu arbres amb el node arrel a la part superior.
    ///
    /// `edge.descend().ascend().unwrap()` i `node.ascend().unwrap().descend()` no haurien de fer res, amb èxit.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Hem d`utilitzar punters en brut per als nodes perquè, si BorrowType és marker::ValMut, pot haver-hi referències mutables pendents de valors que no hem d`invalidar.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Tingueu en compte que l `self` no ha de ser buit.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Tingueu en compte que l `self` no ha de ser buit.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Exposa la porció de fulla de qualsevol fulla o node intern en un arbre immutable.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SEGURETAT: no hi pot haver referències mutables en aquest arbre manllevat com a `Immut`.
        unsafe { &*ptr }
    }

    /// Presta una vista a les claus emmagatzemades al node.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// De manera similar a `ascend`, obté una referència al node pare d'un node, però també reparteix el node actual en el procés.
    /// Això no és segur perquè el node actual continuarà sent accessible tot i estar deslocalitzat.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Afirma amb seguretat al compilador la informació estàtica que aquest node és un `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Afirma amb seguretat al compilador la informació estàtica que aquest node és un `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Treu temporalment una altra referència mutable al mateix node.Compte, ja que aquest mètode és molt perillós, doblement, ja que pot no semblar immediatament perillós.
    ///
    /// Com que els punteres mutables poden recórrer qualsevol lloc de l`arbre, el punter retornat es pot utilitzar fàcilment per fer penjar el punter original, fora dels límits o no vàlid segons les regles de préstec apilades.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) penseu a afegir un altre paràmetre de tipus a `NodeRef` que restringeixi l'ús de mètodes de navegació als punters reborrowed, evitant aquesta inseguretat.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Presta accés exclusiu a la part de fulla de qualsevol fulla o node intern.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SEGURETAT: tenim accés exclusiu a tot el node.
        unsafe { &mut *ptr }
    }

    /// Ofereix accés exclusiu a la part de fulla de qualsevol fulla o node intern.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SEGURETAT: tenim accés exclusiu a tot el node.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Presta accés exclusiu a un element de l`àrea d`emmagatzematge de claus.
    ///
    /// # Safety
    /// `index` està dins dels límits de 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SEGURETAT: la persona que truca no podrà trucar a altres mètodes per si mateix
        // fins que es retiri la referència de la secció de claus, ja que tenim accés únic durant tota la vida del préstec.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Presta accés exclusiu a un element o una porció de l'àrea d'emmagatzematge de valor del node.
    ///
    /// # Safety
    /// `index` està dins dels límits de 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SEGURETAT: la persona que truca no podrà trucar a altres mètodes per si mateix
        // fins que es retiri la referència del segment de valor, ja que tenim accés únic durant tota la vida del préstec.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Presta accés exclusiu a un element o a una porció de l'àrea d'emmagatzematge del node per al contingut edge.
    ///
    /// # Safety
    /// `index` està dins dels límits de 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SEGURETAT: la persona que truca no podrà trucar a altres mètodes per si mateix
        // fins que es retiri la referència de la secció edge, ja que tenim accés únic durant tota la vida del préstec.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - El node té més d`elements inicialitzats `idx`.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Només creem una referència a l`únic element que ens interessa, per evitar l`aliasing amb referències destacades a altres elements, en particular, aquells retornats a la persona que truca en iteracions anteriors.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Hem de coaccionar a indicadors de matriu sense mida a causa del problema Rust #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Presta accés exclusiu a la longitud del node.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Estableix l'enllaç del node al seu pare edge, sense invalidar altres referències al node.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Esborra l'enllaç de l'arrel al seu pare edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Afegeix un parell clau-valor al final del node.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Tots els elements retornats per `range` són un índex edge vàlid per al node.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Afegeix un parell clau-valor i un edge per anar a la dreta d'aquest parell, al final del node.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Comprova si un node és un node `Internal` o un node `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Una referència a un parell clau-valor específic o edge dins d`un node.
/// El paràmetre `Node` ha de ser un `NodeRef`, mentre que el `Type` pot ser `KV` (que significa un identificador en un parell clau-valor) o `Edge` (que significa un identificador en un edge).
///
/// Tingueu en compte que fins i tot els nodes `Leaf` poden tenir nanses `Edge`.
/// En lloc de representar un punter a un node fill, aquests representen els espais on els punteres infantils anirien entre els parells clau-valor.
/// Per exemple, en un node de longitud 2, hi hauria 3 ubicacions possibles de edge, una a l'esquerra del node, una entre els dos parells i una a la dreta del node.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// No necessitem la generalitat completa de `#[derive(Clone)]`, ja que l'única vegada que `Node` serà "Clonable" és quan és una referència immutable i, per tant, `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Recupera el node que conté el parell clau-valor edge a què apunta aquest identificador.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Retorna la posició d'aquest identificador al node.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Crea un nou identificador per a un parell clau-valor a `node`.
    /// No és segur perquè la persona que truca ha de garantir que `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Podria ser una implementació pública de PartialEq, però només s'utilitza en aquest mòdul.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Treu temporalment un altre mànec immutable a la mateixa ubicació.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // No podem utilitzar Handle::new_kv o Handle::new_edge perquè desconeixem el nostre tipus
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Afirma amb seguretat al compilador la informació estàtica que el node del mànec és un `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Treu temporalment un altre identificador mutable a la mateixa ubicació.
    /// Compte, ja que aquest mètode és molt perillós, doblement, ja que pot no semblar immediatament perillós.
    ///
    ///
    /// Per obtenir més informació, consulteu `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // No podem utilitzar Handle::new_kv o Handle::new_edge perquè desconeixem el nostre tipus
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Crea un nou identificador per a un edge a `node`.
    /// No és segur perquè la persona que truca ha de garantir que `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Donat un índex edge on volem inserir en un node ple de capacitat, calcula un índex KV assenyat d'un punt dividit i on realitzar la inserció.
///
/// L`objectiu del punt de divisió és que la seva clau i el seu valor acabin en un node pare;
/// les tecles, els valors i les vores a l'esquerra del punt de divisió es converteixen en el fill esquerre;
/// les tecles, els valors i les vores a la dreta del punt de divisió es converteixen en el fill adequat.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // El problema Rust #74834 intenta explicar aquestes regles simètriques.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Insereix un nou parell clau-valor entre els parells clau-valor a la dreta i a l'esquerra d'aquest edge.
    /// Aquest mètode suposa que hi ha prou espai al node perquè encaixi el nou parell.
    ///
    /// El punter retornat apunta al valor inserit.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Insereix un nou parell clau-valor entre els parells clau-valor a la dreta i a l'esquerra d'aquest edge.
    /// Aquest mètode divideix el node si no hi ha prou espai.
    ///
    /// El punter retornat apunta al valor inserit.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Corregeix el punter i l`índex pare al node fill al qual enllaça aquest edge.
    /// Això és útil quan s`ha canviat l`ordenació de les vores,
    fn correct_parent_link(self) {
        // Creeu un backpointer sense invalidar altres referències al node.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Insereix un nou parell clau-valor i un edge que anirà a la dreta del nou parell entre aquest edge i el parell clau-valor a la dreta d`aquest edge.
    /// Aquest mètode suposa que hi ha prou espai al node perquè encaixi el nou parell.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Insereix un nou parell clau-valor i un edge que anirà a la dreta del nou parell entre aquest edge i el parell clau-valor a la dreta d`aquest edge.
    /// Aquest mètode divideix el node si no hi ha prou espai.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Insereix un nou parell clau-valor entre els parells clau-valor a la dreta i a l'esquerra d'aquest edge.
    /// Aquest mètode divideix el node si no hi ha prou espai i intenta inserir la part separada al node pare de manera recursiva, fins que s'arriba a l'arrel.
    ///
    ///
    /// Si el resultat retornat és un `Fit`, el node del controlador pot ser aquest node de edge o un avantpassat.
    /// Si el resultat retornat és un `Split`, el camp `left` serà el node arrel.
    /// El punter retornat apunta al valor inserit.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Cerca el node que assenyala aquest edge.
    ///
    /// El nom del mètode suposa que us imagineu arbres amb el node arrel a la part superior.
    ///
    /// `edge.descend().ascend().unwrap()` i `node.ascend().unwrap().descend()` no haurien de fer res, amb èxit.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Hem d`utilitzar punters en brut per als nodes perquè, si BorrowType és marker::ValMut, pot haver-hi referències mutables pendents de valors que no hem d`invalidar.
        // No hi ha cap preocupació per accedir al camp d'alçada perquè es copia aquest valor.
        // Tingueu en compte que, una vegada que es desferencia el punter del node, accedim a la matriu de vores amb una referència (Rust número #73987) i invalidem qualsevol altra referència a la matriu o dins de la matriu, en cas que hi hagi al voltant.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // No podem trucar a mètodes de clau i valor separats, perquè trucar al segon invalida la referència retornada pel primer.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Substituïu la clau i el valor a què fa referència el controlador KV.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Ajuda a la implementació de `split` per a un `NodeType` concret, tenint cura de les dades de fulls.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Divideix el node subjacent en tres parts:
    ///
    /// - El node es trunca per contenir només els parells clau-valor a l'esquerra d'aquest identificador.
    /// - S'extreu la clau i el valor que assenyala aquest identificador.
    /// - Tots els parells clau-valor a la dreta d'aquest identificador es col・loquen en un node recentment assignat.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Elimina el parell clau-valor que assenyala aquest identificador i el retorna, juntament amb el edge en què es va col・lapsar el parell clau-valor.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Divideix el node subjacent en tres parts:
    ///
    /// - El node es trunca per contenir només les vores i els parells clau-valor a l'esquerra d'aquest identificador.
    /// - S'extreu la clau i el valor que assenyala aquest identificador.
    /// - Totes les vores i els parells clau-valor a la dreta d'aquest identificador es col・loquen en un node recentment assignat.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Representa una sessió per avaluar i realitzar una operació d'equilibri al voltant d'un parell clau-valor intern.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Tria un context d'equilibri que implica el node com a fill, per tant, entre el KV immediatament a l'esquerra o a la dreta al node pare.
    /// Retorna un `Err` si no hi ha cap pare.
    /// Panics si el pare és buit.
    ///
    /// Prefereix el costat esquerre, per ser òptim si el node donat és d'alguna manera poc ple, és a dir, aquí només té menys elements que el seu germà esquerre i que el seu germà dret, si existeixen.
    /// En aquest cas, la fusió amb el germà esquerre és més ràpida, ja que només necessitem moure els N elements del node, en lloc de desplaçar-los a la dreta i moure més de N elements al davant.
    /// El robatori del germà esquerre també sol ser més ràpid, ja que només hem de desplaçar els N elements del node cap a la dreta, en lloc de desplaçar almenys N dels elements del germà cap a l`esquerra.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Retorna si és possible la fusió, és a dir, si hi ha prou espai en un node per combinar el KV central amb els dos nodes secundaris adjacents.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Realitza una combinació i permet que un tancament decideixi què s'ha de retornar.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SEGURETAT: l'alçada dels nodes que es fusionen és inferior a l'altura
                // del node d`aquest edge, per tant per sobre de zero, per tant són interns.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Combina el parell clau-valor del pare i els dos nodes fills adjacents al node fill esquerre i retorna el node pare reduït.
    ///
    ///
    /// Panics tret que ho fem `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Combina el parell clau-valor del pare i els dos nodes fills adjacents al node fill esquerre i retorna aquest node fill.
    ///
    ///
    /// Panics tret que ho fem `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Combina el parell clau-valor del pare i els dos nodes secundaris adjacents al node fill esquerre i retorna el controlador edge en aquest node fill on ha acabat el fill seguit edge,
    ///
    ///
    /// Panics tret que ho fem `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Elimina un parell clau-valor del fill esquerre i el col・loca a l'emmagatzematge de valor-clau del pare, mentre s'empeny el parell clau-valor pare antic al fill dret.
    ///
    /// Retorna un identificador a edge al fill secundari corresponent al lloc on va acabar el edge original especificat per `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Elimina un parell clau-valor del fill adequat i el col・loca a l`emmagatzematge de valor-clau del pare, mentre es prem el parell clau-valor pare antic al fill esquerre.
    ///
    /// Retorna un identificador al edge del fill esquerre especificat per `track_left_edge_idx`, que no es va moure.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Això fa robar de manera similar a `steal_left`, però roba diversos elements alhora.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Assegureu-vos que puguem robar amb seguretat.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Mou les dades del full.
            {
                // Deixeu lloc als elements robats en el fill adequat.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Moveu els elements del nen esquerre a la dreta.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Moveu el parell més robat a l'esquerra al pare.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Mou el parell clau-valor dels pares al fill adequat.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Deixeu lloc a les vores robades.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Robar vores.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// El clon simètric de `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Assegureu-vos que puguem robar amb seguretat.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Mou les dades del full.
            {
                // Moveu el parell més robat a la dreta al pare.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Moveu el parell clau-valor dels pares al fill esquerre.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Moveu els elements del nen dret a l`esquerra.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Ompliu el buit on abans hi havia els elements robats.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Robar vores.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Ompliu el buit on abans hi havia les vores robades.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Elimina tota informació estàtica que afirma que aquest node és un node `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Elimina tota informació estàtica que afirma que aquest node és un node `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Comprova si el node subjacent és un node `Internal` o un node `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Moveu el sufix després de `self` d`un node a un altre.`right` ha d'estar buit.
    /// El primer edge de `right` es manté sense canvis.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Resultat de la inserció, quan un node necessitava expandir-se més enllà de la seva capacitat.
pub struct SplitResult<'a, K, V, NodeType> {
    // Node alterat a l'arbre existent amb elements i vores que pertanyen a l'esquerra de `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Algunes claus i valors es divideixen per inserir-se en un altre lloc.
    pub kv: (K, V),
    // Node nou de propietat, sense adjuntar, amb elements i arestes que pertanyen a la dreta de `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Si les referències de node d`aquest tipus de préstec permeten passar a altres nodes de l`arbre.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // La travessia no és necessària, passa amb el resultat de `borrow_mut`.
        // Desactivant el recorregut i només creant noves referències a arrels, sabem que totes les referències del tipus `Owned` són a un node arrel.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Insereix un valor en un segment d'elements inicialitzats seguit d'un element no inicialitzat.
///
/// # Safety
/// La part té més d`elements `idx`.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Elimina i retorna un valor d'un segment de tots els elements inicialitzats, deixant enrere un element final no inicialitzat.
///
///
/// # Safety
/// La part té més d`elements `idx`.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Desplaça els elements en un segment `distance` a l'esquerra.
///
/// # Safety
/// La part té almenys elements `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Desplaça els elements en un segment de posicions `distance` cap a la dreta.
///
/// # Safety
/// La part té almenys elements `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Moveu tots els valors des d'un segment d'elements inicialitzats a un segment d'elements no inicialitzats, deixant enrere `src` com a tots no inicialitzats.
///
/// Funciona com `dst.copy_from_slice(src)`, però no requereix que `T` sigui `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;