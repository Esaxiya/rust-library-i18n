use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Treu temporalment un altre immutable equivalent del mateix rang.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Cerca les diferents vores de les fulles que delimiten un rang especificat en un arbre.
    /// Retorna un parell de nanses diferents al mateix arbre o un parell d'opcions buides.
    ///
    /// # Safety
    ///
    /// Tret que `BorrowType` sigui `Immut`, no utilitzeu els mànecs duplicats per visitar el mateix KV dues vegades.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Equival a `(root1.first_leaf_edge(), root2.last_leaf_edge())` però més eficient.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Cerca el parell de vores de fulles que delimiten un rang específic en un arbre.
    ///
    /// El resultat és significatiu només si l`arbre està ordenat per clau, com ho és l`arbre d`un `BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // SEGURETAT: el nostre tipus de préstec és immutable.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Troba el parell de vores de fulles que delimiten un arbre sencer.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Divideix una referència única en un parell de vores de fulles que delimiten un interval especificat.
    /// El resultat són referències no úniques que permeten la mutació (some), que s`han d`utilitzar amb cura.
    ///
    /// El resultat és significatiu només si l`arbre està ordenat per clau, com ho és l`arbre d`un `BTreeMap`.
    ///
    ///
    /// # Safety
    /// No utilitzeu les nanses duplicades per visitar el mateix KV dues vegades.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Divideix una referència única en un parell de vores de fulles que delimiten tota la gamma de l'arbre.
    /// Els resultats són referències no úniques que permeten la mutació (només de valors), de manera que s`han d`utilitzar amb cura.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Aquí dupliquem l'arrel NodeRef: mai no visitarem el mateix KV dues vegades i mai acabarem amb referències de valor superposades.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Divideix una referència única en un parell de vores de fulles que delimiten tota la gamma de l'arbre.
    /// Els resultats són referències no úniques que permeten una mutació massiva destructiva, de manera que s`han d`utilitzar amb la màxima cura.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Aquí dupliquem l'arrel NodeRef: mai no hi accedirem de manera que se superposin a les referències obtingudes de l'arrel.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Donat un identificador de fulla edge, retorna [`Result::Ok`] amb un identificador al KV veí al costat dret, que es troba al mateix node de fulla o en un node ancestral.
    ///
    /// Si el full edge és l'últim de l'arbre, retorna [`Result::Err`] amb el node arrel.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Donat un identificador de fulla edge, retorna [`Result::Ok`] amb un identificador al KV veí al costat esquerre, que es troba al mateix node de fulla o en un node ancestral.
    ///
    /// Si el full edge és el primer de l'arbre, retorna [`Result::Err`] amb el node arrel.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Donat un controlador edge intern, retorna [`Result::Ok`] amb un controlador al KV veí al costat dret, que es troba al mateix node intern o en un node ancestral.
    ///
    /// Si el edge intern és l'últim de l'arbre, retorna [`Result::Err`] amb el node arrel.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Donat un mànec de fulla edge en un arbre que es mor, retorna la següent fulla edge al costat dret i el parell clau-valor entremig, que es troba al mateix node de fulla, en un node ancestral o inexistent.
    ///
    ///
    /// Aquest mètode també reparteix qualsevol node(s) que arribi al final.
    /// Això implica que si no existeix cap parell clau-valor, s'haurà repartit tota la resta de l'arbre i no queda res per tornar.
    ///
    /// # Safety
    /// El edge donat no ha d'haver estat retornat prèviament per la contrapart `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Donat un mànec de fulla edge en un arbre moribund, retorna la següent fulla edge al costat esquerre i el parell clau-valor entremig, que es troba al mateix node de fulla, en un node avantpassat, o inexistent.
    ///
    ///
    /// Aquest mètode també reparteix qualsevol node(s) que arribi al final.
    /// Això implica que si no existeix cap parell clau-valor, s'haurà repartit tota la resta de l'arbre i no queda res per tornar.
    ///
    /// # Safety
    /// El edge donat no ha d'haver estat retornat prèviament per la contrapart `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Desassigna una pila de nodes des de la fulla fins a l'arrel.
    /// Aquesta és l'única manera de repartir la resta d'un arbre després que `deallocating_next` i `deallocating_next_back` hagin rosegat els dos costats de l'arbre i hagin colpejat el mateix edge.
    /// Com que només es vol cridar quan s'han retornat totes les claus i valors, no es fa cap neteja de cap de les claus o valors.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Mou el mànec de fulla edge a la següent fulla edge i retorna referències a la clau i al valor intermedi.
    ///
    ///
    /// # Safety
    /// Hi ha d`haver un altre KV en la direcció recorreguda.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Mou el mànec de fulla edge a la fulla edge anterior i retorna referències a la clau i al valor intermedi.
    ///
    ///
    /// # Safety
    /// Hi ha d`haver un altre KV en la direcció recorreguda.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Mou el mànec de fulla edge a la següent fulla edge i retorna referències a la clau i al valor intermedi.
    ///
    ///
    /// # Safety
    /// Hi ha d`haver un altre KV en la direcció recorreguda.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Fer això últim és més ràpid, segons els paràmetres.
        kv.into_kv_valmut()
    }

    /// Mou la fulla edge a la fulla anterior i retorna referències a la clau i al valor intermedi.
    ///
    ///
    /// # Safety
    /// Hi ha d`haver un altre KV en la direcció recorreguda.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Fer això últim és més ràpid, segons els paràmetres.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Mou el mànec de fulla edge a la següent fulla edge i retorna la clau i el valor entremig, repartint qualsevol node deixat mentre es deixa penjat el edge corresponent al seu node pare.
    ///
    /// # Safety
    /// - Hi ha d`haver un altre KV en la direcció recorreguda.
    /// - Aquesta contrapartida `next_back_unchecked` no va retornar prèviament aquest KV en cap còpia de les nanses que s`utilitzaven per travessar l`arbre.
    ///
    /// L'única manera segura de procedir amb el controlador actualitzat és comparar-lo, deixar-lo caure, tornar a trucar a aquest mètode segons les seves condicions de seguretat o trucar al seu homòleg `next_back_unchecked` segons les seves condicions de seguretat.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Mou el mànec de fulla edge a la fulla edge anterior i retorna la clau i el valor entremig, repartint qualsevol node deixat mentre es deixa penjat el edge corresponent al seu node pare.
    ///
    /// # Safety
    /// - Hi ha d`haver un altre KV en la direcció recorreguda.
    /// - Aquesta fulla edge no la va retornar prèviament la contraparte `next_unchecked` en cap còpia de les nanses que s`utilitzaven per travessar l`arbre.
    ///
    /// L'única manera segura de procedir amb el controlador actualitzat és comparar-lo, deixar-lo caure, tornar a trucar a aquest mètode segons les seves condicions de seguretat o trucar al seu homòleg `next_unchecked` segons les seves condicions de seguretat.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Retorna la fulla més esquerra edge dins o per sota d'un node, és a dir, la edge que necessiteu primer per navegar cap endavant (o per últim quan navegueu cap enrere).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Retorna la fulla edge situada més a la dreta dins o per sota d'un node, és a dir, la edge que necessiteu per últim quan navegueu cap endavant (o primer quan aneu cap enrere).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Visita els nodes fulls i els KV interns per ordre de tecles ascendents, i també visita els nodes interns en conjunt en un primer ordre de profunditat, és a dir, que els nodes interns precedeixen els seus KV individuals i els seus nodes fills.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Calcula el nombre d`elements d`un (sub) arbre.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Retorna la fulla edge més propera a un KV per a la navegació cap endavant.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Retorna la fulla edge més propera a un KV per a la navegació cap enrere.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}