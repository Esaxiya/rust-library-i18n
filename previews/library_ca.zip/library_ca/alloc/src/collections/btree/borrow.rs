use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modela un reborrow d'alguna referència única, quan sabeu que el reborrow i tots els seus descendents (és a dir, tots els indicadors i referències que se'n deriven) ja no s'utilitzaran en cap moment, després del qual voleu tornar a utilitzar la referència única original .
///
///
/// El comprovador de préstecs sol gestionar aquest apilament de préstecs, però alguns fluxos de control que aconsegueixen aquest apilament són massa complicats per al compilador.
/// Un `DormantMutRef` us permet comprovar els préstecs, tot expressant la seva naturalesa apilada, i encapsulant el codi de punter en brut necessari per fer-ho sense un comportament indefinit.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Captureu un préstec únic i torneu-lo a demanar immediatament.
    /// Per al compilador, la vida útil de la nova referència és la mateixa que la vida original de la referència original, però heu de fer-la servir per un període més curt.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SEGURETAT: mantenim el préstec durant tota 'a via `_marker` i exposem
        // només aquesta referència, per tant, és única.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Torneu al préstec únic capturat inicialment.
    ///
    /// # Safety
    ///
    /// El reborrow ha d'haver finalitzat, és a dir, la referència retornada per `new` i tots els punters i referències que se'n deriven ja no s'han d'utilitzar.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SEGURETAT: les nostres pròpies condicions de seguretat impliquen que aquesta referència torna a ser única.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;