use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Afegeix tots els parells clau-valor de la unió de dos iteradors ascendents, incrementant una variable `length` al llarg del camí.Això últim facilita que la persona que truca pugui evitar fuites quan un controlador de caigudes té pànic.
    ///
    /// Si els dos iteradors produeixen la mateixa clau, aquest mètode elimina el parell de l'iterador esquerre i afegeix el parell de l'iterador dret.
    ///
    /// Si voleu que l`arbre acabi en un ordre estrictament ascendent, com per un `BTreeMap`, els dos iteradors haurien de produir claus en ordre estrictament ascendent, cadascuna superior a totes les tecles de l`arbre, incloses les tecles que ja es troben a l`arbre en entrar.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Ens preparem per combinar `left` i `right` en una seqüència ordenada en temps lineal.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Mentrestant, construïm un arbre a partir de la seqüència ordenada en temps lineal.
        self.bulk_push(iter, length)
    }

    /// Emet tots els parells clau-valor fins al final de l'arbre, incrementant una variable `length` al llarg del camí.
    /// Això últim facilita a la persona que truca evitar fuites quan l`iterador té pànic.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Repeteix tots els parells clau-valor empenyent-los als nodes del nivell adequat.
        for (key, value) in iter {
            // Intenteu introduir el parell clau-valor al node full actual.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // No queda cap espai, puja i empeny cap allà.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // S'ha trobat un node amb espai esquerre, premeu aquí.
                                open_node = parent;
                                break;
                            } else {
                                // Torneu a pujar.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Som a la part superior, creem un nou node arrel i hi empenyem.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Premeu el parell clau-valor i el nou subarbre dret.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Baixeu de nou a la fulla més dreta.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Incrementeu la longitud de cada iteració per assegurar-vos que el mapa elimina els elements adjunts, fins i tot si avança l'iterador.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Un iterador per combinar dues seqüències ordenades en una sola
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Si dues claus són iguals, retorna el parell clau-valor de la font correcta.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}