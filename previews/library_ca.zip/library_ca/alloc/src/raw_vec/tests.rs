use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Escriure una prova d`integració entre assignadors de tercers i `RawVec` és una mica complicat perquè l`API `RawVec` no exposa mètodes d`assignació fal・libles, de manera que no podem comprovar què passa quan s`esgoti l`assignador (més enllà de detectar un panic).
    //
    //
    // En lloc d'això, només es comprova que els mètodes `RawVec` passen almenys per l'API Allocator quan reserva emmagatzematge.
    //
    //
    //
    //
    //

    // Un assignador ximple que consumeix una quantitat fixa de combustible abans que els intents d'assignació comencin a fallar.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (provoca una reassignació, utilitzant així 50 + 150=200 unitats de combustible)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // En primer lloc, `reserve` s`assigna com `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 supera el doble de 7, de manera que `reserve` hauria de funcionar com `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 és menys de la meitat de 12, de manera que `reserve` ha de créixer exponencialment.
        // En el moment d`escriure aquesta prova, el factor de creixement és 2, de manera que la nova capacitat és de 24, però el factor de creixement de 1.5 també està bé.
        //
        // Per tant, `>= 18` en afirmació.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}