//! Knihovna podpory pro autory maker při definování nových maker.
//!
//! Tato knihovna, poskytovaná standardní distribucí, poskytuje typy spotřebované v rozhraních procedurálně definovaných definic maker, jako jsou makra podobná funkcím `#[proc_macro]`, atributy maker `#[proc_macro_attribute]` a vlastní odvozené atributy`#[proc_macro_derive]`.
//!
//!
//! Další informace viz [the book].
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Určuje, zda byl proc_macro zpřístupněn aktuálně spuštěnému programu.
///
/// Proc_macro crate je určen pouze pro použití uvnitř implementace procedurálních maker.Všechny funkce v tomto crate panic, pokud jsou vyvolány zvenčí procedurálního makra, například z testovacího skriptu nebo testu jednotky nebo běžného binárního souboru Rust.
///
/// S ohledem na knihovny Rust, které jsou navrženy tak, aby podporovaly případy použití maker i jiných maker, poskytuje `proc_macro::is_available()` nepanikující způsob, jak zjistit, zda je v současné době k dispozici infrastruktura potřebná k použití API proc_macro.
/// Vrátí true, pokud je vyvolána zevnitř procedurálního makra, false, pokud je vyvolána z jiného binárního souboru.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Hlavní typ poskytovaný tímto crate, představující abstraktní proud tokens, nebo konkrétněji sekvenci stromů token.
/// Typ poskytuje rozhraní pro iteraci nad těmito stromy token a naopak shromažďování několika stromů token do jednoho proudu.
///
///
/// Toto je vstup i výstup definic `#[proc_macro]`, `#[proc_macro_attribute]` a `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Chyba vrácená z `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Vrátí prázdný `TokenStream`, který neobsahuje žádné stromy token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Zkontroluje, zda je `TokenStream` prázdný.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Pokusy rozdělit řetězec na tokens a analyzovat tyto tokens na stream token.
/// Může selhat z mnoha důvodů, například pokud řetězec obsahuje nevyvážené oddělovače nebo znaky, které v jazyce neexistují.
///
/// Všechny tokens v analyzovaném streamu získají rozpětí `Span::call_site()`.
///
/// NOTE: některé chyby mohou místo vrácení `LexError` způsobit panics.Vyhrazujeme si právo tyto chyby později změnit na `LexError`.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, most poskytuje pouze `to_string`, implementujte `fmt::Display` na jeho základě (opak obvyklého vztahu mezi těmito dvěma).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Vytiskne stream token jako řetězec, který má být bezztrátově převoditelný zpět do stejného proudu token (modulo rozpětí), s výjimkou případných tokenů `TokenTree: : Group` s oddělovači `Delimiter::None` a zápornými číselnými literály.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Vytiskne token ve formě vhodné pro ladění.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Vytvoří stream token obsahující jeden strom token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Sbírá řadu stromů token do jednoho proudu.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Operace "flattening" na streamech token, shromažďuje stromy token z více streamů token do jednoho proudu.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Je možné použít optimalizovanou implementaci if/when.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Veřejné podrobnosti implementace pro typ `TokenStream`, například iterátory.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Iterátor nad tokenstree `TokenStream`.
    /// Iterace je "shallow", např. Iterátor se neopakuje do oddělených skupin a vrací celé skupiny jako stromy token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` přijímá libovolné tokens a expanduje do `TokenStream` popisujícího vstup.
/// Například `quote!(a + b)` vytvoří výraz, který po vyhodnocení vytvoří `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Unquoting is done with `$`, and works by taking the single next ident as the unquoted term.
/// Chcete-li citovat samotný `$`, použijte `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Oblast zdrojového kódu spolu s informacemi o expanzi maker.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Vytvoří nový `Diagnostic` s daným `message` v rozpětí `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Rozpětí, které se vyřeší na webu definice makra.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Rozsah vyvolání aktuálního procedurálního makra.
    /// Identifikátory vytvořené s tímto rozsahem budou vyřešeny, jako kdyby byly zapsány přímo v místě volání makra (hygiena volání na místě) a další kód na místě volání makra bude na ně také moci odkazovat.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Rozpětí, které představuje hygienu `macro_rules`, a někdy se vyřeší na místě definice makra (místní proměnné, štítky, `$crate`) a někdy na místě volání makra (vše ostatní).
    ///
    /// Poloha rozpětí je převzata z call-site.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Původní zdrojový soubor, do kterého toto rozpětí směřuje.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` pro tokens v předchozím rozšíření makra, ze kterého byl generován `self`, pokud existuje.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Rozpětí zdrojového kódu původu, ze kterého byl generován `self`.
    /// Pokud tento `Span` nebyl vygenerován z jiných makro expanzí, pak je návratová hodnota stejná jako `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Získá počáteční line/column ve zdrojovém souboru pro toto rozpětí.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Získá koncový line/column ve zdrojovém souboru pro toto rozpětí.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Vytvoří nový rozsah zahrnující `self` a `other`.
    ///
    /// Vrátí `None`, pokud `self` a `other` jsou z různých souborů.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Vytvoří nový rozsah se stejnými informacemi line/column jako `self`, ale který vyřeší symboly, jako by tomu bylo v `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Vytvoří nový rozsah se stejným chováním rozlišení názvu jako `self`, ale s informacemi line/column `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Ve srovnání s rozpětím zjistíte, zda jsou si rovni.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Vrátí zdrojový text za rozpětí.
    /// Tím se zachová původní zdrojový kód, včetně mezer a komentářů.
    /// Vrátí výsledek pouze v případě, že rozpětí odpovídá skutečnému zdrojovému kódu.
    ///
    /// Note: Pozorovatelný výsledek makra by se měl spoléhat pouze na tokens a ne na tento zdrojový text.
    ///
    /// Výsledkem této funkce je maximální úsilí, které lze použít pouze pro diagnostiku.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Vytiskne rozpětí ve formě vhodné pro ladění.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Pár řádek-sloupec představující začátek nebo konec `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Řádek s 1 indexem ve zdrojovém souboru, u kterého rozpětí začíná nebo končí (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Sloupec s indexací 0 (ve znacích UTF-8) ve zdrojovém souboru, ve kterém rozpětí začíná nebo končí (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Zdrojový soubor daného `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Získá cestu k tomuto zdrojovému souboru.
    ///
    /// ### Note
    /// Pokud byl rozsah kódu přidružený k tomuto `SourceFile` vygenerován externím makrem, tímto makrem, nemusí to být skutečná cesta k souborovému systému.
    /// Ke kontrole použijte [`is_real`].
    ///
    /// Všimněte si také, že i když `is_real` vrací `true`, pokud byl `--remap-path-prefix` předán na příkazovém řádku, nemusí být zadaná cesta ve skutečnosti platná.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Vrátí `true`, pokud je tento zdrojový soubor skutečným zdrojovým souborem a není generován expanzí externího makra.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Jedná se o hack, dokud nebudou implementována mezikroková rozpětí a my nebudeme mít skutečné zdrojové soubory pro rozpětí generovaná v externích makrech.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Jeden token nebo ohraničená sekvence stromů token (např. `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Stream token obklopený oddělovači závorek.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Identifikátor.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Jeden interpunkční znak (`+`, `,`, `$` atd.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Doslovný znak (`'a'`), řetězec (`"hello"`), číslo (`2.3`) atd.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Vrátí rozpětí tohoto stromu, delegování na metodu `span` obsaženého token nebo oddělený proud.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Konfiguruje rozpětí pro *pouze tento token*.
    ///
    /// Všimněte si, že pokud je tento token `Group`, pak tato metoda nenakonfiguruje rozpětí každé z interních tokens, bude to jednoduše delegovat na metodu `set_span` každé varianty.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Vytiskne strom token ve formě vhodné pro ladění.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Každý z nich má název v typu struktury v odvozeném ladění, takže se neobtěžujte s další vrstvou nepřímo
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, most poskytuje pouze `to_string`, implementujte `fmt::Display` na jeho základě (opak obvyklého vztahu mezi těmito dvěma).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Vytiskne strom token jako řetězec, který má být bezztrátově konvertovatelný zpět do stejného stromu token (modulo rozpětí), s výjimkou případných souborů `TokenTree: : Group` s oddělovači `Delimiter::None` a zápornými číselnými literály.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Oddělený stream token.
///
/// `Group` interně obsahuje `TokenStream`, který je obklopen `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Popisuje, jak je ohraničena sekvence stromů token.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Implicitní oddělovač, který se může například objevit kolem tokens pocházejícího z "macro variable" `$var`.
    /// Je důležité zachovat priority operátora v případech, jako je `$var * 3`, kde `$var` je `1 + 2`.
    /// Implicitní oddělovače nemusí přežít zpáteční let proudu token prostřednictvím řetězce.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Vytvoří nový `Group` s daným oddělovačem a streamem token.
    ///
    /// Tento konstruktor nastaví rozpětí pro tuto skupinu na `Span::call_site()`.
    /// Chcete-li změnit rozpětí, můžete použít níže uvedenou metodu `set_span`.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Vrátí oddělovač tohoto `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Vrátí `TokenStream` tokens, které jsou v tomto `Group` odděleny.
    ///
    /// Všimněte si, že vrácený stream token nezahrnuje oddělovač vrácený výše.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Vrátí rozpětí pro oddělovače tohoto proudu token, zahrnující celou `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Vrátí rozpětí ukazující na počáteční oddělovač této skupiny.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Vrátí rozpětí směřující k uzavíracímu oddělovači této skupiny.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Nakonfiguruje rozpětí pro oddělovače této skupiny, ale ne pro jeho interní tokens.
    ///
    /// Tato metoda **nenastaví** rozpětí všech interních tokens překlenutých touto skupinou, ale spíše nastaví pouze rozpětí oddělovače tokens na úrovni `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, most poskytuje pouze `to_string`, implementujte `fmt::Display` na jeho základě (opak obvyklého vztahu mezi těmito dvěma).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Vytiskne skupinu jako řetězec, který by měl být bezztrátově převoditelný zpět do stejné skupiny (modulo rozpětí), s výjimkou případných souborů `TokenTree: : Group` s oddělovači `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` je jediný interpunkční znak jako `+`, `-` nebo `#`.
///
/// Víceznakové operátory jako `+=` jsou reprezentovány jako dvě instance `Punct` s různými formami `Spacing` vrácených.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Zda `Punct` následuje okamžitě další `Punct` nebo následuje další token nebo mezery.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// např. `+` je `Alone` v `+ =`, `+ident` nebo `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// např. `+` je `Joint` v `+=` nebo `'#`.
    /// Kromě toho se `'` s jednoduchou citací může spojit s identifikátory a vytvořit tak život `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Vytvoří nový `Punct` z daného znaku a mezer.
    /// Argument `ch` musí být platný interpunkční znak povolený jazykem, jinak bude funkce panic.
    ///
    /// Vrácená `Punct` bude mít výchozí rozpětí `Span::call_site()`, které lze dále konfigurovat pomocí metody `set_span` níže.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Vrátí hodnotu tohoto interpunkčního znaku jako `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Vrátí mezery tohoto interpunkčního znaku, což označuje, zda za ním v proudu token okamžitě následuje další `Punct`, takže je lze potenciálně kombinovat do víceznakového operátora (`Joint`), nebo za ním následuje nějaký jiný token nebo mezery (`Alone`), takže operátor určitě má skončila.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Vrátí rozpětí pro tento interpunkční znak.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Nakonfigurujte rozpětí pro tento interpunkční znak.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, most poskytuje pouze `to_string`, implementujte `fmt::Display` na jeho základě (opak obvyklého vztahu mezi těmito dvěma).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Vytiskne interpunkční znak jako řetězec, který by měl být bezztrátově převoditelný zpět na stejný znak.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Identifikátor (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Vytvoří nový `Ident` s daným `string` i se zadaným `span`.
    /// Argument `string` musí být platný identifikátor povolený jazykem (včetně klíčových slov, např. `self` nebo `fn`).Jinak bude funkce panic.
    ///
    /// Všimněte si, že `span`, aktuálně v rustc, konfiguruje hygienické informace pro tento identifikátor.
    ///
    /// Od této doby se `Span::call_site()` výslovně přihlásí k hygieně "call-site", což znamená, že identifikátory vytvořené s tímto rozpětím budou vyřešeny, jako kdyby byly zapsány přímo v místě volání makra, a další kód na webu volání makra bude moci odkazovat na také je.
    ///
    ///
    /// Pozdější rozsahy jako `Span::def_site()` umožní přihlásit se k hygieně "definition-site", což znamená, že identifikátory vytvořené s tímto rozpětím budou vyřešeny v místě definice makra a další kód na webu volání makra na ně nebude moci odkazovat.
    ///
    /// Vzhledem k aktuálnímu významu hygieny vyžaduje tento konstruktér, na rozdíl od jiných tokens, při konstrukci specifikaci `Span`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Stejné jako `Ident::new`, ale vytvoří nezpracovaný identifikátor (`r#ident`).
    /// Argument `string` je platný identifikátor povolený jazykem (včetně klíčových slov, např. `fn`).
    /// Klíčová slova, která jsou použitelná v segmentech cest (např
    /// `self`, `super`) nejsou podporovány a způsobí panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Vrátí rozpětí tohoto `Ident`, zahrnující celý řetězec vrácený [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Nakonfiguruje rozpětí tohoto `Ident`, což může změnit jeho hygienický kontext.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, most poskytuje pouze `to_string`, implementujte `fmt::Display` na jeho základě (opak obvyklého vztahu mezi těmito dvěma).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Vytiskne identifikátor jako řetězec, který by měl být bezztrátově převoditelný zpět na stejný identifikátor.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Doslovný řetězec (`"hello"`), bajtový řetězec (`b"hello"`), znak (`'a'`), bajtový znak (`b'a'`), celé číslo nebo číslo s plovoucí desetinnou čárkou s příponou nebo bez ní (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Booleovské literály jako `true` a `false` sem nepatří, jsou to `Ident.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Vytvoří nový příponový celočíselný literál se zadanou hodnotou.
        ///
        /// Tato funkce vytvoří celé číslo jako `1u32`, kde zadaná celočíselná hodnota je první částí token a integrál je také přípona na konci.
        /// Literály vytvořené ze záporných čísel nemusí přežít zpáteční lety přes `TokenStream` nebo řetězce a mohou být rozděleny do dvou tokens (`-` a pozitivní literál).
        ///
        ///
        /// Literály vytvořené pomocí této metody mají ve výchozím nastavení rozpětí `Span::call_site()`, které lze konfigurovat níže uvedenou metodou `set_span`.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Vytvoří nový nefixovaný celočíselný literál se zadanou hodnotou.
        ///
        /// Tato funkce vytvoří celé číslo jako `1`, kde zadaná celočíselná hodnota je první částí token.
        /// Na tomto token není zadána žádná přípona, což znamená, že vyvolání jako `Literal::i8_unsuffixed(1)` jsou ekvivalentní `Literal::u32_unsuffixed(1)`.
        /// Literály vytvořené ze záporných čísel nemusí přežít rountrips prostřednictvím `TokenStream` nebo řetězců a mohou být rozděleny do dvou tokens (`-` a pozitivní literál).
        ///
        ///
        /// Literály vytvořené pomocí této metody mají ve výchozím nastavení rozpětí `Span::call_site()`, které lze konfigurovat níže uvedenou metodou `set_span`.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Vytvoří nový literál s nefixovanou plovoucí desetinnou čárkou.
    ///
    /// Tento konstruktor je podobný těm, jako je `Literal::i8_unsuffixed`, kde je hodnota floatu emitována přímo do token, ale nepoužívá se žádná přípona, takže lze později v kompilátoru odvodit, že jde o `f64`.
    ///
    /// Literály vytvořené ze záporných čísel nemusí přežít rountrips prostřednictvím `TokenStream` nebo řetězců a mohou být rozděleny do dvou tokens (`-` a pozitivní literál).
    ///
    /// # Panics
    ///
    /// Tato funkce vyžaduje, aby zadaný float byl konečný, například pokud je nekonečno nebo NaN, tato funkce bude panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Vytvoří nový příponový literál s plovoucí desetinnou čárkou.
    ///
    /// Tento konstruktor vytvoří literál jako `1.0f32`, kde zadaná hodnota je předchozí částí token a `f32` je přípona token.
    /// Tento token bude v kompilátoru vždy odvozen jako `f32`.
    /// Literály vytvořené ze záporných čísel nemusí přežít rountrips prostřednictvím `TokenStream` nebo řetězců a mohou být rozděleny do dvou tokens (`-` a pozitivní literál).
    ///
    ///
    /// # Panics
    ///
    /// Tato funkce vyžaduje, aby zadaný float byl konečný, například pokud je nekonečno nebo NaN, tato funkce bude panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Vytvoří nový literál s nefixovanou plovoucí desetinnou čárkou.
    ///
    /// Tento konstruktor je podobný těm, jako je `Literal::i8_unsuffixed`, kde je hodnota floatu emitována přímo do token, ale nepoužívá se žádná přípona, takže lze později v kompilátoru odvodit, že jde o `f64`.
    ///
    /// Literály vytvořené ze záporných čísel nemusí přežít rountrips prostřednictvím `TokenStream` nebo řetězců a mohou být rozděleny do dvou tokens (`-` a pozitivní literál).
    ///
    /// # Panics
    ///
    /// Tato funkce vyžaduje, aby zadaný float byl konečný, například pokud je nekonečno nebo NaN, tato funkce bude panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Vytvoří nový příponový literál s plovoucí desetinnou čárkou.
    ///
    /// Tento konstruktor vytvoří literál jako `1.0f64`, kde zadaná hodnota je předchozí částí token a `f64` je přípona token.
    /// Tento token bude v kompilátoru vždy odvozen jako `f64`.
    /// Literály vytvořené ze záporných čísel nemusí přežít rountrips prostřednictvím `TokenStream` nebo řetězců a mohou být rozděleny do dvou tokens (`-` a pozitivní literál).
    ///
    ///
    /// # Panics
    ///
    /// Tato funkce vyžaduje, aby zadaný float byl konečný, například pokud je nekonečno nebo NaN, tato funkce bude panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Řetězec doslovný.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Znak doslovný.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Bajtový řetězec doslovný.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Vrátí rozpětí zahrnující tento literál.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfiguruje rozsah přidružený k tomuto literálu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Vrátí `Span`, což je podmnožina `self.span()` obsahující pouze zdrojové bajty v rozsahu `range`.
    /// Vrátí `None`, pokud je očekávané oříznuté rozpětí mimo hranice `self`.
    ///
    // FIXME(SergioBenitez): zkontrolujte, zda rozsah bajtů začíná a končí na hranici UTF-8 zdroje.
    // jinak je pravděpodobné, že se při tisku zdrojového textu objeví panic jinde.
    // FIXME(SergioBenitez): neexistuje žádný způsob, jak by uživatel věděl, na co se `self.span()` ve skutečnosti mapuje, takže tuto metodu lze v současné době volat pouze naslepo.
    // Například `to_string()` pro znak 'c' vrátí "'\u{63}'";uživatel nemůže nijak zjistit, zda byl zdrojový text 'c' nebo zda to byl '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) něco podobného `Option::cloned`, ale pro `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, most poskytuje pouze `to_string`, implementujte `fmt::Display` na jeho základě (opak obvyklého vztahu mezi těmito dvěma).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Vytiskne literál jako řetězec, který by měl být bezztrátově převoditelný zpět do stejného literálu (s výjimkou možného zaokrouhlování literálů s plovoucí desetinnou čárkou).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Sledovaný přístup k proměnným prostředí.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Načtěte proměnnou prostředí a přidejte ji k vytvoření informací o závislosti.
    /// Systém sestavení provádějící kompilátor bude vědět, že k proměnné bylo přistupováno během kompilace, a bude moci znovu spustit sestavení, když se změní hodnota této proměnné.
    ///
    /// Kromě sledování závislostí by tato funkce měla být ekvivalentní `env::var` ze standardní knihovny, kromě toho, že argument musí být UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}