//! Toto je interní modul používaný ifmt!runtime.Tyto struktury jsou emitovány do statických polí do předkompilace řetězců formátu předem.
//!
//! Tyto definice jsou podobné jejich ekvivalentům `ct`, ale liší se tím, že je lze staticky přidělit a jsou mírně optimalizovány pro běh
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Možné zarovnání, které lze požadovat jako součást směrnice o formátování.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Označení, že obsah by měl být zarovnán doleva.
    Left,
    /// Označení, že obsah by měl být zarovnán doprava.
    Right,
    /// Označení, že obsah by měl být zarovnán na střed.
    Center,
    /// Nebylo požadováno žádné zarovnání.
    Unknown,
}

/// Používá se specifikátory [width](https://doc.rust-lang.org/std/fmt/#width) a [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Určeno doslovným číslem, uloží hodnotu
    Is(usize),
    /// Určeno pomocí syntaxí `$` a `*`, uloží index do `args`
    Param(usize),
    /// Nespecifikováno
    Implied,
}