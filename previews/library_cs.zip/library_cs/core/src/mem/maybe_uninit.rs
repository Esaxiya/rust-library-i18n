use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Typ obálky pro konstrukci neinicializovaných instancí `T`.
///
/// # Inicializace invariantní
///
/// Kompilátor obecně předpokládá, že proměnná je správně inicializována podle požadavků typu proměnné.Například proměnná referenčního typu musí být zarovnaná a nemá NULL.
/// Jedná se o invariant, který musí být *vždy* potvrzen, a to i v nebezpečném kódu.
/// V důsledku toho nulová inicializace proměnné referenčního typu způsobí okamžité [undefined behavior][ub], bez ohledu na to, zda se tato reference někdy zvykne na přístup k paměti:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // nedefinované chování!⚠️
/// // Ekvivalentní kód s `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // nedefinované chování!⚠️
/// ```
///
/// To kompilátor využívá pro různé optimalizace, jako je například kontrola běhu a optimalizace rozložení `enum`.
///
/// Podobně může mít zcela neinicializovaná paměť jakýkoli obsah, zatímco `bool` musí být vždy `true` nebo `false`.Vytvoření neinicializovaného `bool` je tedy nedefinované chování:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // nedefinované chování!⚠️
/// // Ekvivalentní kód s `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // nedefinované chování!⚠️
/// ```
///
/// Neinicializovaná paměť je navíc speciální v tom, že nemá pevnou hodnotu ("fixed" znamená "it won't change without being written to").Čtení stejného neinicializovaného bajtu vícekrát může poskytnout různé výsledky.
/// Díky tomu je nedefinované chování mít neinicializovaná data v proměnné, i když má tato proměnná celočíselný typ, který jinak může obsahovat jakýkoli *fixní* bitový vzor:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // nedefinované chování!⚠️
/// // Ekvivalentní kód s `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // nedefinované chování!⚠️
/// ```
/// (Všimněte si, že pravidla kolem neinicializovaných celých čísel ještě nejsou dokončena, ale dokud nebudou, je vhodné se jim vyhnout.)
///
/// Kromě toho si pamatujte, že většina typů má další invarianty, kromě toho, že jsou považovány za inicializované na úrovni typů.
/// Například [`Vec<T>`] inicializovaný na 1 je považován za inicializovaný (v rámci aktuální implementace; to nepředstavuje stabilní záruku), protože kompilátor o tom ví jen tím, že datový ukazatel musí mít nenulovou hodnotu.
/// Vytvoření takového `Vec<T>` nezpůsobí *okamžité* nedefinované chování, ale způsobí nedefinované chování u většiny bezpečných operací (včetně jeho zrušení).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` slouží k povolení nebezpečného kódu pro zpracování neinicializovaných dat.
/// Je to signál do kompilátoru označující, že data zde nemusí *být* inicializována:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Vytvořte výslovně neinicializovaný odkaz.
/// // Kompilátor ví, že data uvnitř `MaybeUninit<T>` mohou být neplatná, a proto to není UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Nastavte ji na platnou hodnotu.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Extrahujte inicializovaná data-to je povoleno *pouze po* správné inicializaci `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Kompilátor pak ví, že v tomto kódu neprovede žádné nesprávné předpoklady nebo optimalizace.
///
/// Můžete si myslet, že `MaybeUninit<T>` je trochu jako `Option<T>`, ale bez sledování běhu a bez jakékoli bezpečnostní kontroly.
///
/// ## out-pointers
///
/// K implementaci "out-pointers" můžete použít `MaybeUninit<T>`: místo vracení dat z funkce předejte ukazatel na nějakou paměť (uninitialized), do které chcete výsledek vložit.
/// To může být užitečné, když je pro volajícího důležité řídit, jak se paměť, ve které je výsledek uložen, přidělí, a chcete se vyhnout zbytečným tahům.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` nevypustí starý obsah, což je důležité.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Nyní víme, že `v` je inicializován!Tím se také zajistí, že se vector správně spadne.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Inicializace pole prvek po prvku
///
/// `MaybeUninit<T>` lze použít k inicializaci velkého pole prvek po prvku:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Vytvořte neinicializované pole `MaybeUninit`.
///     // `assume_init` je bezpečný, protože typ, o kterém zde prohlašujeme, že je inicializován, je spousta `MožnáUninit`, které nevyžadují inicializaci.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Upuštění `MaybeUninit` nedělá nic.
///     // Takže použití surového přiřazení ukazatele místo `ptr::write` nezpůsobí zrušení staré neinicializované hodnoty.
/////
///     // Také pokud během této smyčky existuje panic, došlo k úniku paměti, ale není zde žádný problém s bezpečností paměti.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Vše je inicializováno.
///     // Převeďte pole na inicializovaný typ.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Můžete také pracovat s částečně inicializovanými poli, která lze najít v nízkoúrovňových datových strukturách.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Vytvořte neinicializované pole `MaybeUninit`.
/// // `assume_init` je bezpečný, protože typ, o kterém zde prohlašujeme, že je inicializován, je spousta `MožnáUninit`, které nevyžadují inicializaci.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Spočítejte počet prvků, které jsme přiřadili.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // U každé položky v poli zrušte, pokud jsme ji přidělili.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Inicializace struktury pole po poli
///
/// K inicializaci struktur po jednotlivých polích můžete použít `MaybeUninit<T>` a makro [`std::ptr::addr_of_mut`]:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Inicializace pole `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Inicializace pole `list` Pokud je zde panic, pak `String` v poli `name` uniká.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Všechna pole jsou inicializována, proto voláme `assume_init`, abychom získali inicializovaný Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` je zaručeno, že bude mít stejnou velikost, zarovnání a ABI jako `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Nezapomeňte však, že typ *obsahující* a `MaybeUninit<T>` nemusí být nutně stejné rozložení;Rust obecně nezaručuje, že pole `Foo<T>` mají stejné pořadí jako `Foo<U>`, i když `T` a `U` mají stejnou velikost a zarovnání.
///
/// Dále proto, že jakákoli bitová hodnota je platná pro `MaybeUninit<T>`, kompilátor nemůže použít optimalizace non-zero/niche-filling, což může mít za následek větší velikost:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Pokud je `T` bezpečný na FFI, pak je také `MaybeUninit<T>`.
///
/// Zatímco `MaybeUninit` je `#[repr(transparent)]` (což znamená, že zaručuje stejnou velikost, zarovnání a ABI jako `T`), to *nezmění* žádné z předchozích upozornění.
/// `Option<T>` a `Option<MaybeUninit<T>>` mohou mít stále různé velikosti a typy obsahující pole typu `T` mohou být rozloženy (a velikosti) odlišně, než kdyby toto pole bylo `MaybeUninit<T>`.
/// `MaybeUninit` je typ spojení a `#[repr(transparent)]` na svazcích je nestabilní (viz [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Přesné záruky `#[repr(transparent)]` na odbory se mohou časem vyvíjet a `MaybeUninit` může nebo nemusí zůstat `#[repr(transparent)]`.
/// To znamená, že `MaybeUninit<T>`*vždy* zaručí, že má stejnou velikost, zarovnání a ABI jako `T`;je to tak, že způsob, jakým `MaybeUninit` implementuje tuto záruku, se může vyvíjet.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Položka Lang, abychom do ní mohli zabalit další typy.To je užitečné pro generátory.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Když nevoláme `T::clone()`, nemůžeme vědět, jestli jsme na to dostatečně inicializováni.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Vytvoří nový `MaybeUninit<T>` inicializovaný s danou hodnotou.
    /// Je bezpečné volat [`assume_init`] na návratovou hodnotu této funkce.
    ///
    /// Pamatujte, že upuštění `MaybeUninit<T>` nikdy nezavolá drop kód `T`.
    /// Je vaší odpovědností zajistit, aby `T` byl vynechán, pokud byl inicializován.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Vytvoří nový `MaybeUninit<T>` v neinicializovaném stavu.
    ///
    /// Pamatujte, že upuštění `MaybeUninit<T>` nikdy nezavolá drop kód `T`.
    /// Je vaší odpovědností zajistit, aby `T` byl vynechán, pokud byl inicializován.
    ///
    /// Několik příkladů najdete v [type-level documentation][MaybeUninit].
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Vytvořte nové pole položek `MaybeUninit<T>` v neinicializovaném stavu.
    ///
    /// Note: ve verzi future Rust se tato metoda může stát zbytečnou, pokud syntaxe pole doslovný umožňuje [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Následující příklad by pak mohl použít `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Vrátí (možná menší) část dat, která byla skutečně načtena
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // BEZPEČNOST: Neinicializovaná `[MaybeUninit<_>; LEN]` je platná.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Vytvoří nový `MaybeUninit<T>` v neinicializovaném stavu, přičemž paměť bude naplněna bajty `0`.Záleží na `T`, zda to již zajišťuje správnou inicializaci.
    ///
    /// Například `MaybeUninit<usize>::zeroed()` je inicializován, ale `MaybeUninit<&'static i32>::zeroed()` není, protože odkazy nesmí mít hodnotu null.
    ///
    /// Pamatujte, že upuštění `MaybeUninit<T>` nikdy nezavolá drop kód `T`.
    /// Je vaší odpovědností zajistit, aby `T` byl vynechán, pokud byl inicializován.
    ///
    /// # Example
    ///
    /// Správné použití této funkce: inicializace struktury s nulou, kde všechna pole struktury mohou obsahovat bitový vzor 0 jako platnou hodnotu.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Nesprávné* použití této funkce: volání `x.zeroed().assume_init()`, když `0` není platný bitový vzor pro typ:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Uvnitř dvojice vytvoříme `NotZero`, který nemá platný diskriminátor.
    /// // Toto je nedefinované chování.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // BEZPEČNOST: `u.as_mut_ptr()` bodů do přidělené paměti.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Nastaví hodnotu `MaybeUninit<T>`.
    /// Tím se přepíše jakákoli předchozí hodnota, aniž byste ji zrušili, takže buďte opatrní, abyste ji nepoužívali dvakrát, pokud nechcete přeskočit spuštění destruktoru.
    ///
    /// Pro vaše pohodlí to také vrátí proměnlivý odkaz na (nyní bezpečně inicializovaný) obsah `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // BEZPEČNOST: Právě jsme inicializovali tuto hodnotu.
        unsafe { self.assume_init_mut() }
    }

    /// Získá ukazatel na obsaženou hodnotu.
    /// Čtení z tohoto ukazatele nebo jeho přeměna na odkaz je nedefinované chování, pokud není `MaybeUninit<T>` inicializován.
    /// Zápis do paměti, na kterou tento ukazatel (non-transitively) ukazuje, je nedefinované chování (kromě uvnitř `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Správné použití této metody:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Vytvořte odkaz do `MaybeUninit<T>`.To je v pořádku, protože jsme to inicializovali.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Nesprávné* použití této metody:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Vytvořili jsme odkaz na neinicializovaný vector!Toto je nedefinované chování.⚠️
    /// ```
    ///
    /// (Všimněte si, že pravidla týkající se odkazů na neinicializované údaje ještě nejsou dokončena, ale dokud nebudou, je vhodné se jim vyhnout.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` a `ManuallyDrop` jsou oba `repr(transparent)`, takže můžeme hodit ukazatel.
        self as *const _ as *const T
    }

    /// Získá proměnlivý ukazatel na obsaženou hodnotu.
    /// Čtení z tohoto ukazatele nebo jeho přeměna na odkaz je nedefinované chování, pokud není `MaybeUninit<T>` inicializován.
    ///
    /// # Examples
    ///
    /// Správné použití této metody:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Vytvořte odkaz do `MaybeUninit<Vec<u32>>`.
    /// // To je v pořádku, protože jsme to inicializovali.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Nesprávné* použití této metody:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Vytvořili jsme odkaz na neinicializovaný vector!Toto je nedefinované chování.⚠️
    /// ```
    ///
    /// (Všimněte si, že pravidla týkající se odkazů na neinicializované údaje ještě nejsou dokončena, ale dokud nebudou, je vhodné se jim vyhnout.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` a `ManuallyDrop` jsou oba `repr(transparent)`, takže můžeme hodit ukazatel.
        self as *mut _ as *mut T
    }

    /// Extrahuje hodnotu z kontejneru `MaybeUninit<T>`.To je skvělý způsob, jak zajistit, že budou data zahozena, protože výsledný `T` podléhá obvyklému zpracování dropů.
    ///
    /// # Safety
    ///
    /// Je na volajícím, aby zaručil, že `MaybeUninit<T>` je skutečně v inicializovaném stavu.Volání, když obsah ještě není plně inicializován, způsobí okamžité nedefinované chování.
    /// [type-level documentation][inv] obsahuje více informací o tomto inicializačním invariantu.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Kromě toho si pamatujte, že většina typů má další invarianty, kromě toho, že jsou považovány za inicializované na úrovni typů.
    /// Například [`Vec<T>`] inicializovaný na 1 je považován za inicializovaný (v rámci aktuální implementace; to nepředstavuje stabilní záruku), protože kompilátor o tom ví jen tím, že datový ukazatel musí mít nenulovou hodnotu.
    ///
    /// Vytvoření takového `Vec<T>` nezpůsobí *okamžité* nedefinované chování, ale způsobí nedefinované chování u většiny bezpečných operací (včetně jeho zrušení).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Správné použití této metody:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Nesprávné* použití této metody:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ještě nebyl inicializován, takže tento poslední řádek způsobil nedefinované chování.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // BEZPEČNOST: volající musí zaručit inicializaci `self`.
        // To také znamená, že `self` musí být variantou `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Přečte hodnotu z kontejneru `MaybeUninit<T>`.Výsledný `T` podléhá obvyklému zpracování kapek.
    ///
    /// Kdykoli je to možné, je lepší použít místo toho [`assume_init`], což zabrání duplikování obsahu `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Je na volajícím, aby zaručil, že `MaybeUninit<T>` je skutečně v inicializovaném stavu.Volání, když obsah ještě není plně inicializován, způsobí nedefinované chování.
    /// [type-level documentation][inv] obsahuje více informací o tomto inicializačním invariantu.
    ///
    /// Navíc to v `MaybeUninit<T>` zanechává kopii stejných dat.
    /// Při použití více kopií dat (opakovaným voláním `assume_init_read` nebo prvním voláním `assume_init_read` a poté [`assume_init`]) je vaší odpovědností zajistit, aby tato data mohla být skutečně duplikována.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Správné použití této metody:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` je `Copy`, takže můžeme číst vícekrát.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Duplikování hodnoty `None` je v pořádku, takže můžeme číst vícekrát.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Nesprávné* použití této metody:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Nyní jsme vytvořili dvě kopie stejného vector, což vedlo k dvojímu uvolnění when️, když oba vypadnou!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // BEZPEČNOST: volající musí zaručit inicializaci `self`.
        // Čtení z `self.as_ptr()` je bezpečné, protože `self` by měl být inicializován.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Spadne obsaženou hodnotu na místo.
    ///
    /// Pokud vlastníte `MaybeUninit`, můžete místo toho použít [`assume_init`].
    ///
    /// # Safety
    ///
    /// Je na volajícím, aby zaručil, že `MaybeUninit<T>` je skutečně v inicializovaném stavu.Volání, když obsah ještě není plně inicializován, způsobí nedefinované chování.
    ///
    /// Kromě toho musí být splněny všechny další invarianty typu `T`, protože implementace `Drop` `T` (nebo jejích členů) se na to může spolehnout.
    /// Například [`Vec<T>`] inicializovaný na 1 je považován za inicializovaný (v rámci aktuální implementace; to nepředstavuje stabilní záruku), protože kompilátor o tom ví jen tím, že datový ukazatel musí mít nenulovou hodnotu.
    ///
    /// Puštění takové `Vec<T>` však způsobí nedefinované chování.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // BEZPEČNOST: volající musí zaručit, že `self` je inicializován a
        // uspokojuje všechny invarianty `T`.
        // Pokud je tomu tak, je bezpečné místo na místě bezpečně uložit.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Získá sdílený odkaz na obsaženou hodnotu.
    ///
    /// To může být užitečné, když chceme získat přístup k `MaybeUninit`, který byl inicializován, ale nemáme vlastnictví `MaybeUninit` (brání použití `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Volání, když obsah ještě není plně inicializován, způsobí nedefinované chování: je na volajícím, aby zaručil, že `MaybeUninit<T>` je skutečně v inicializovaném stavu.
    ///
    ///
    /// # Examples
    ///
    /// ### Správné použití této metody:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Inicializovat `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Nyní, když je známo, že je naše `MaybeUninit<_>` inicializována, je v pořádku vytvořit na ni sdílený odkaz:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // BEZPEČNOST: `x` byl inicializován.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Nesprávné* použití této metody:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Vytvořili jsme odkaz na neinicializovaný vector!Toto je nedefinované chování.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Inicializujte `MaybeUninit` pomocí `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Odkaz na neinicializovaný `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // BEZPEČNOST: volající musí zaručit inicializaci `self`.
        // To také znamená, že `self` musí být variantou `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Získá proměnlivý odkaz (unique) na obsaženou hodnotu.
    ///
    /// To může být užitečné, když chceme získat přístup k `MaybeUninit`, který byl inicializován, ale nemáme vlastnictví `MaybeUninit` (brání použití `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Volání, když obsah ještě není plně inicializován, způsobí nedefinované chování: je na volajícím, aby zaručil, že `MaybeUninit<T>` je skutečně v inicializovaném stavu.
    /// Například `.assume_init_mut()` nelze použít k inicializaci `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Správné použití této metody:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Inicializuje *všechny* bajty vstupní vyrovnávací paměti.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Inicializovat `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Nyní víme, že `buf` byl inicializován, takže jsme ho mohli `.assume_init()`.
    /// // Použití `.assume_init()` však může spustit `memcpy` z 2048 bajtů.
    /// // Abychom tvrdili, že náš buffer byl inicializován bez jeho kopírování, upgradujeme `&mut MaybeUninit<[u8; 2048]>` na `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // BEZPEČNOST: `buf` byl inicializován.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Nyní můžeme použít `buf` jako normální řez:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Nesprávné* použití této metody:
    ///
    /// K inicializaci hodnoty nemůžete použít `.assume_init_mut()`:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Vytvořili jsme odkaz (mutable) na neinicializovaný `bool`!
    ///     // Toto je nedefinované chování.⚠️
    /// }
    /// ```
    ///
    /// Například nemůžete [`Read`] do neinicializované vyrovnávací paměti:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) odkaz na neinicializovanou paměť!
    ///                             // Toto je nedefinované chování.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Rovněž nemůžete použít přímý přístup k poli k postupné inicializaci pole po poli:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) odkaz na neinicializovanou paměť!
    ///                  // Toto je nedefinované chování.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) odkaz na neinicializovanou paměť!
    ///                  // Toto je nedefinované chování.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): V současné době se spoléháme na to, že výše uvedené je nesprávné, tj. Máme odkazy na neinicializovaná data (např. V `libcore/fmt/float.rs`).
    // Před stabilizací bychom měli učinit konečné rozhodnutí o pravidlech.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // BEZPEČNOST: volající musí zaručit inicializaci `self`.
        // To také znamená, že `self` musí být variantou `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Extrahuje hodnoty z pole kontejnerů `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Je na volajícím, aby zaručil, že všechny prvky pole jsou v inicializovaném stavu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // BEZPEČNOST: Nyní jsme v bezpečí, protože jsme inicializovali všechny prvky
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Volající zaručuje, že jsou inicializovány všechny prvky pole
        // * `MaybeUninit<T>` a T zaručeně mají stejné rozložení
        // * Je možné, že Ununint neklesne, takže nedochází k žádným dvojitým osvobozením, a proto je převod bezpečný
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Za předpokladu, že jsou všechny prvky inicializovány, získejte k nim řez.
    ///
    /// # Safety
    ///
    /// Je na volajícím, aby zaručil, že prvky `MaybeUninit<T>` jsou skutečně v inicializovaném stavu.
    ///
    /// Volání, když obsah ještě není plně inicializován, způsobí nedefinované chování.
    ///
    /// Další podrobnosti a příklady viz [`assume_init_ref`].
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // BEZPEČNOST: odlévání plátek do `*const [T]` je bezpečné, protože to volající zaručuje
        // `slice` je inicializován a je zaručeno, že`MaybeUninit` bude mít stejné rozložení jako `T`.
        // Získaný ukazatel je platný, protože odkazuje na paměť vlastněnou `slice`, což je reference, a proto je zaručeno, že bude platná pro čtení.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Za předpokladu, že jsou všechny prvky inicializovány, získejte k nim proměnlivý řez.
    ///
    /// # Safety
    ///
    /// Je na volajícím, aby zaručil, že prvky `MaybeUninit<T>` jsou skutečně v inicializovaném stavu.
    ///
    /// Volání, když obsah ještě není plně inicializován, způsobí nedefinované chování.
    ///
    /// Další podrobnosti a příklady viz [`assume_init_mut`].
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // BEZPEČNOST: podobné bezpečnostním poznámkám pro `slice_get_ref`, ale máme a
        // měnitelný odkaz, který je také zaručeně platný pro zápisy.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Získá ukazatel na první prvek pole.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Získá proměnlivý ukazatel na první prvek pole.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Zkopíruje prvky z `src` do `this` a vrátí proměnlivý odkaz na nyní initalizovaný obsah `this`.
    ///
    /// Pokud `T` neimplementuje `Copy`, použijte [`write_slice_cloned`]
    ///
    /// Je to podobné jako u [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Tato funkce bude panic, pokud mají dva řezy různé délky.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // BEZPEČNOST: právě jsme zkopírovali všechny prvky len do volné kapacity
    /// // první src.len() prvky věc jsou nyní platné.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // BEZPEČNOST: &[T] a&[MožnáUninit<T>] mají stejné rozložení
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // BEZPEČNOST: Platné prvky byly právě zkopírovány do `this`, takže je inicializováno
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Klonuje prvky z `src` do `this` a vrací proměnlivý odkaz na nyní initalizovaný obsah `this`.
    /// Žádné již inicializované prvky nebudou zrušeny.
    ///
    /// Pokud `T` implementuje `Copy`, použijte [`write_slice`]
    ///
    /// Toto je podobné jako u [`slice::clone_from_slice`], ale nezruší existující prvky.
    ///
    /// # Panics
    ///
    /// Tato funkce bude panic, pokud mají dva řezy různé délky, nebo pokud je implementace `Clone` panics.
    ///
    /// Pokud existuje panic, budou již klonované prvky zrušeny.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // BEZPEČNOST: právě jsme naklonovali všechny prvky len do volné kapacity
    /// // první src.len() prvky věc jsou nyní platné.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // na rozdíl od copy_from_slice to nevolá clone_from_slice na řezu, protože `MaybeUninit<T: Clone>` neimplementuje Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // BEZPEČNOST: tento surový řez bude obsahovat pouze inicializované objekty
                // proto je povoleno upustit.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Musíme je výslovně rozdělit na stejnou délku
        // pro vyloučení kontroly hranic a optimalizátor vygeneruje memcpy pro jednoduché případy (například T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // je potřeba stráž b/c panic se může stát během klonu
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // BEZPEČNOST: Do `this` byly právě zapsány platné prvky, takže je inicializován
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}