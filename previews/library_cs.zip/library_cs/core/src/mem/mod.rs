//! Základní funkce pro práci s pamětí.
//!
//! Tento modul obsahuje funkce pro dotazování na velikost a zarovnání typů, inicializaci a manipulaci s pamětí.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Převezme vlastnictví a "forgets" o hodnotě **, aniž by spustil svůj destruktor**.
///
/// Jakékoli prostředky, které hodnota spravuje, jako je halda paměti nebo popisovač souboru, zůstanou navždy v nedosažitelném stavu.Nezaručuje však, že odkazy na tuto paměť zůstanou platné.
///
/// * Pokud chcete uvolnit paměť, podívejte se na [`Box::leak`].
/// * Pokud chcete získat surový ukazatel do paměti, podívejte se na [`Box::into_raw`].
/// * Chcete-li správně zlikvidovat hodnotu, spusťte její destruktor, viz [`mem::drop`].
///
/// # Safety
///
/// `forget` není označen jako `unsafe`, protože bezpečnostní záruky Rust nezahrnují záruku, že destruktory budou vždy fungovat.
/// Například program může vytvořit referenční cyklus pomocí [`Rc`][rc] nebo zavolat [`process::exit`][exit] a ukončit bez spuštění destruktorů.
/// Povolení `mem::forget` z bezpečného kódu tedy zásadně nemění bezpečnostní záruky Rust.
///
/// To znamená, že únik zdrojů, jako je paměť nebo objekty I/O, je obvykle nežádoucí.
/// Potřeba přichází v některých specializovaných případech použití pro FFI nebo nebezpečný kód, ale i tak se obvykle dává přednost [`ManuallyDrop`].
///
/// Protože zapomenutí na hodnotu je povoleno, musí jakýkoli kód `unsafe`, který napíšete, tuto možnost umožňovat.Nemůžete vrátit hodnotu a očekávat, že volající bude nutně spouštět destruktor hodnoty.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Kanonicky bezpečné použití `mem::forget` je obejít destruktor hodnoty implementovaný `Drop` trait.Například dojde k úniku `File`, tj
/// získat zpět prostor zabraný proměnnou, ale nikdy nezavřít podkladový systémový prostředek:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// To je užitečné, když bylo vlastnictví podkladového zdroje dříve přeneseno do kódu mimo Rust, například přenosem surového deskriptoru souboru do kódu C.
///
/// # Vztah s `ManuallyDrop`
///
/// Zatímco `mem::forget` lze také použít k přenosu vlastnictví *paměti*, je to náchylné k chybám.
/// [`ManuallyDrop`] místo toho by měl být použit.Zvažte například tento kód:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Postavte `String` pomocí obsahu `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // únik `v`, protože jeho paměť je nyní spravována `s`
/// mem::forget(v);  // ERROR, v je neplatný a nesmí být předán funkci
/// assert_eq!(s, "Az");
/// // `s` je implicitně zrušeno a jeho paměť uvolněna.
/// ```
///
/// U výše uvedeného příkladu existují dva problémy:
///
/// * Pokud by byl mezi konstrukci `String` a vyvolání `mem::forget()` přidán další kód, panic v něm by způsobil dvojí volnost, protože `v` i `s` zpracovávají stejnou paměť.
/// * Po volání `v.as_mut_ptr()` a přenesení vlastnictví dat do `s` je hodnota `v` neplatná.
/// I když je hodnota právě přesunuta do `mem::forget` (která ji nebude kontrolovat), některé typy mají přísné požadavky na své hodnoty, díky nimž jsou neplatné, když jsou visící nebo již nejsou vlastněny.
/// Použití neplatných hodnot jakýmkoli způsobem, včetně jejich předávání nebo vracení z funkcí, představuje nedefinované chování a může porušit předpoklady vytvořené kompilátorem.
///
/// Přepnutím na `ManuallyDrop` se vyhnete oběma problémům:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Než rozebráme `v` na jeho surové části, ujistěte se, že nedojde k jeho pádu!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Nyní rozeberte `v`.Tyto operace nemohou panic, takže nemůže dojít k úniku.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Nakonec postavte `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` je implicitně zrušeno a jeho paměť uvolněna.
/// ```
///
/// `ManuallyDrop` robustně zamezuje zdvojnásobení, protože před jakýmkoli jiným deaktivujeme destruktor `v`.
/// `mem::forget()` neumožňuje to, protože spotřebovává svůj argument a nutí nás volat jej až po extrahování všeho, co potřebujeme, z `v`.
/// I kdyby byl mezi konstrukcí `ManuallyDrop` a vytvořením řetězce zaveden panic (což se v kódu nemůže stát, jak je znázorněno), mělo by to za následek únik a ne dvojité uvolnění.
/// Jinými slovy, `ManuallyDrop` chybuje na straně úniku místo toho, aby chyboval na straně (dvojitého) pádu.
///
/// `ManuallyDrop` nám také brání v tom, abychom po převodu vlastnictví na `s` museli mít "touch" `v`-poslednímu kroku interakce s `v` a jeho likvidaci bez spuštění jeho destruktoru je zcela zabráněno.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Stejně jako [`forget`], ale také přijímá hodnoty bez velikosti.
///
/// Tato funkce je pouze vložka určená k odstranění, když se funkce `unsized_locals` stabilizuje.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Vrátí velikost typu v bajtech.
///
/// Konkrétněji se jedná o posun v bajtech mezi po sobě jdoucími prvky v poli s daným typem položky včetně zarovnávací výplně.
///
/// Proto pro jakýkoli typ `T` a délku `n` má `[T; n]` velikost `n * size_of::<T>()`.
///
/// Obecně není velikost typu stabilní napříč kompilacemi, ale konkrétní typy, například primitivní, jsou.
///
/// Následující tabulka uvádí velikost primitiv.
///
/// Typ |velikost: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 znaků |4
///
/// Kromě toho mají `usize` a `isize` stejnou velikost.
///
/// Všechny typy `*const T`, `&T`, `Box<T>`, `Option<&T>` a `Option<Box<T>>` mají stejnou velikost.
/// Pokud je velikost `T`, všechny tyto typy mají stejnou velikost jako `usize`.
///
/// Změnitelnost ukazatele nemění jeho velikost.`&T` a `&mut T` mají stejnou velikost.
/// Podobně pro `*const T` a `* mut T`.
///
/// # Velikost položek `#[repr(C)]`
///
/// Reprezentace `C` pro položky má definované rozložení.
/// S tímto rozložením je velikost položek také stabilní, pokud mají všechna pole stabilní velikost.
///
/// ## Velikost struktur
///
/// U `structs` je velikost určena následujícím algoritmem.
///
/// Pro každé pole ve struktuře seřazené podle pořadí prohlášení:
///
/// 1. Přidejte velikost pole.
/// 2. Zaokrouhlete aktuální velikost na nejbližší násobek [alignment] dalšího pole.
///
/// Nakonec zaokrouhlete velikost struktury na nejbližší násobek její [alignment].
/// Zarovnání struktury je obvykle největší zarovnání všech jejích polí;to lze změnit pomocí `repr(align(N))`.
///
/// Na rozdíl od `C` nejsou struktury nulové velikosti zaokrouhleny nahoru na jeden bajt.
///
/// ## Velikost výčtu
///
/// Výčty, které nesou žádná jiná data než diskriminační, mají stejnou velikost jako výčty C na platformě, pro kterou jsou kompilovány.
///
/// ## Velikost unií
///
/// Velikost unie je velikost jejího největšího pole.
///
/// Na rozdíl od `C` nejsou odbory nulové velikosti zaokrouhleny nahoru na jeden bajt.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Někteří primitivové
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Některá pole
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Rovnost velikosti ukazatele
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Pomocí `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Velikost prvního pole je 1, takže k velikosti přidejte 1.Velikost je 1.
/// // Zarovnání druhého pole je 2, takže přidejte 1 k velikosti pro odsazení.Velikost je 2.
/// // Velikost druhého pole je 2, takže k velikosti přidejte 2.Velikost je 4.
/// // Zarovnání třetího pole je 1, takže k velikosti pro odsazení přidejte 0.Velikost je 4.
/// // Velikost třetího pole je 1, takže k velikosti přidejte 1.Velikost je 5.
/// // Nakonec je zarovnání struktury 2 (protože největší zarovnání mezi jeho poli je 2), takže přidejte 1 k velikosti pro výplň.
/// // Velikost je 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple structs se řídí stejnými pravidly.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Pamatujte, že změna pořadí polí může zmenšit velikost.
/// // Oba padding bajty můžeme odstranit vložením `third` před `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Velikost Unie je velikost největšího pole.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Vrátí velikost poukázané hodnoty v bajtech.
///
/// To je obvykle stejné jako u `size_of::<T>()`.
/// Pokud však `T`*nemá* žádnou staticky známou velikost, např. Řez [`[T]`][slice] nebo [trait object], lze k získání dynamicky známé velikosti použít `size_of_val`.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // BEZPEČNOST: `val` je reference, takže je to platný surový ukazatel
    unsafe { intrinsics::size_of_val(val) }
}

/// Vrátí velikost poukázané hodnoty v bajtech.
///
/// To je obvykle stejné jako u `size_of::<T>()`.Pokud však `T`*nemá* žádnou staticky známou velikost, např. Řez [`[T]`][slice] nebo [trait object], lze k získání dynamicky známé velikosti použít `size_of_val_raw`.
///
/// # Safety
///
/// Tuto funkci lze bezpečně volat, pouze pokud jsou splněny následující podmínky:
///
/// - Pokud `T` je `Sized`, tato funkce je vždy bezpečná pro volání.
/// - Pokud je ocas `T` bez velikosti:
///     - [slice], pak délka ocasu řezu musí být inicializované celé číslo a velikost *celé hodnoty*(délka dynamického ocasu + předpona staticky velikosti) musí odpovídat `isize`.
///     - a [trait object], pak musí vtable část ukazatele ukazovat na platnou vtable získanou donucením bez dimenze a velikost *celé hodnoty*(dynamická délka ocasu + předpona statické velikosti) se musí vejít do `isize`.
///
///     - (unstable) [extern type], pak je tato funkce vždy bezpečná, ale může panic nebo jinak vrátit nesprávnou hodnotu, protože není známo rozložení externího typu.
///     Toto je stejné chování jako [`size_of_val`] u odkazu na typ s ocasem externího typu.
///     - jinak není konzervativně povoleno volat tuto funkci.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // BEZPEČNOST: volající musí poskytnout platný surový ukazatel
    unsafe { intrinsics::size_of_val(val) }
}

/// Vrátí minimální [ABI] požadované zarovnání typu.
///
/// Každý odkaz na hodnotu typu `T` musí být násobkem tohoto čísla.
///
/// Toto je zarovnání použité pro strukturní pole.Může být menší než upřednostňované zarovnání.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Vrátí minimální [ABI] požadované zarovnání typu hodnoty, na kterou `val` ukazuje.
///
/// Každý odkaz na hodnotu typu `T` musí být násobkem tohoto čísla.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // BEZPEČNOST: val je odkaz, takže je to platný surový ukazatel
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Vrátí minimální [ABI] požadované zarovnání typu.
///
/// Každý odkaz na hodnotu typu `T` musí být násobkem tohoto čísla.
///
/// Toto je zarovnání použité pro strukturní pole.Může být menší než upřednostňované zarovnání.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Vrátí minimální [ABI] požadované zarovnání typu hodnoty, na kterou `val` ukazuje.
///
/// Každý odkaz na hodnotu typu `T` musí být násobkem tohoto čísla.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // BEZPEČNOST: val je odkaz, takže je to platný surový ukazatel
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Vrátí minimální [ABI] požadované zarovnání typu hodnoty, na kterou `val` ukazuje.
///
/// Každý odkaz na hodnotu typu `T` musí být násobkem tohoto čísla.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Tuto funkci lze bezpečně volat, pouze pokud jsou splněny následující podmínky:
///
/// - Pokud `T` je `Sized`, tato funkce je vždy bezpečná pro volání.
/// - Pokud je ocas `T` bez velikosti:
///     - [slice], pak délka ocasu řezu musí být inicializované celé číslo a velikost *celé hodnoty*(délka dynamického ocasu + předpona staticky velikosti) musí odpovídat `isize`.
///     - a [trait object], pak musí vtable část ukazatele ukazovat na platnou vtable získanou donucením bez dimenze a velikost *celé hodnoty*(dynamická délka ocasu + předpona statické velikosti) se musí vejít do `isize`.
///
///     - (unstable) [extern type], pak je tato funkce vždy bezpečná, ale může panic nebo jinak vrátit nesprávnou hodnotu, protože není známo rozložení externího typu.
///     Toto je stejné chování jako [`align_of_val`] u odkazu na typ s ocasem externího typu.
///     - jinak není konzervativně povoleno volat tuto funkci.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // BEZPEČNOST: volající musí poskytnout platný surový ukazatel
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Vrátí `true`, pokud záleží na klesajících hodnotách typu `T`.
///
/// Jedná se čistě o optimalizační nápovědu a lze ji implementovat konzervativně:
/// může vrátit `true` pro typy, které ve skutečnosti nemusí být zrušeny.
/// Jako takový by vždy vracející se `true` byla platnou implementací této funkce.Pokud však tato funkce ve skutečnosti vrátí `false`, pak si můžete být jisti, že upuštění od `T` nemá žádný vedlejší účinek.
///
/// Nízkoúrovňové implementace věcí, jako jsou sbírky, které potřebují ručně zrušit svá data, by měly tuto funkci používat, aby se zbytečně nepokoušely vyhodit veškerý jejich obsah, když jsou zničeny.
///
/// To nemusí dělat rozdíl v sestaveních vydání (kde je smyčka, která nemá žádné vedlejší účinky, snadno detekována a eliminována), ale je často velkou výhodou pro sestavení ladění.
///
/// Všimněte si, že [`drop_in_place`] tuto kontrolu již provádí, takže pokud vaše pracovní zátěž může být snížena na malý počet hovorů [`drop_in_place`], není to nutné.
/// Zejména si všimněte, že můžete [`drop_in_place`] řez, a to provede jedinou kontrolu need_drop všech hodnot.
///
/// Typy jako Vec proto pouze `drop_in_place(&mut self[..])` bez výslovného použití `needs_drop`.
/// Na druhou stranu typy jako [`HashMap`] musí klesat hodnoty po jednom a měly by používat toto API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Zde je příklad toho, jak může kolekce využívat `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // zahodit data
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Vrátí hodnotu typu `T` představovanou vzorem bajtů s nulovou hodnotou.
///
/// To znamená, že například padding byte v `(u8, u16)` nemusí být nutně vynulován.
///
/// Neexistuje žádná záruka, že vzor nula bajtů představuje platnou hodnotu nějakého typu `T`.
/// Například vzor nulového bajtu není platná hodnota pro referenční typy (`&T`, `&mut T`) a ukazatele funkcí.
/// Použití `zeroed` na takové typy způsobí okamžitý [undefined behavior][ub], protože [the Rust compiler assumes][inv], že v proměnné, kterou považuje za inicializovanou, vždy existuje platná hodnota.
///
///
/// To má stejný účinek jako [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Je to někdy užitečné pro FFI, ale obecně by se mu mělo vyhnout.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Správné použití této funkce: inicializace celého čísla s nulou.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Nesprávné* použití této funkce: inicializace reference s nulou.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Nedefinované chování!
/// let _y: fn() = unsafe { mem::zeroed() }; // A znovu!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // BEZPEČNOST: volající musí zaručit, že pro `T` je platná nulová hodnota.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Obchází normální kontroly inicializace paměti Rust předstíráním, že produkuje hodnotu typu `T`, přičemž nedělá vůbec nic.
///
/// **Tato funkce je zastaralá.** Místo toho použijte [`MaybeUninit<T>`].
///
/// Důvodem pro ukončení podpory je, že funkci nelze v zásadě správně použít: má stejný účinek jako [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Jak vysvětluje [`assume_init` documentation][assume_init], [the Rust compiler assumes][inv], že hodnoty jsou správně inicializovány.
/// V důsledku toho volání např
/// `mem::uninitialized::<bool>()` způsobí okamžité nedefinované chování pro vrácení `bool`, který rozhodně není `true` nebo `false`.
/// Horší je, že skutečně neinicializovaná paměť, jako je to, co se zde vrátí, je speciální v tom, že kompilátor ví, že nemá pevnou hodnotu.
/// Díky tomu je nedefinované chování mít neinicializovaná data v proměnné, i když má tato proměnná celočíselný typ.
/// (Všimněte si, že pravidla kolem neinicializovaných celých čísel ještě nejsou dokončena, ale dokud nebudou, je vhodné se jim vyhnout.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // BEZPEČNOST: volající musí zaručit, že pro `T` je platná jednotková hodnota.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Zamění hodnoty na dvou proměnlivých místech, aniž by jedna z nich byla deinicializována.
///
/// * Chcete-li zaměnit výchozí nebo fiktivní hodnotu, přečtěte si [`take`].
/// * Pokud chcete vyměnit za předanou hodnotu, vracíte starou hodnotu, viz [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // BEZPEČNOST: surové ukazatele byly vytvořeny z bezpečných proměnlivých odkazů splňujících všechny
    // omezení na `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Nahradí `dest` výchozí hodnotou `T` a vrátí předchozí hodnotu `dest`.
///
/// * Pokud chcete nahradit hodnoty dvou proměnných, podívejte se na [`swap`].
/// * Pokud chcete místo výchozí hodnoty nahradit předanou hodnotu, přečtěte si [`replace`].
///
/// # Examples
///
/// Jednoduchý příklad:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` umožňuje převzetí vlastnictví pole struktury jeho nahrazením hodnotou "empty".
/// Bez `take` můžete narazit na problémy, jako jsou tyto:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Všimněte si, že `T` nemusí nutně implementovat [`Clone`], takže nemůže ani klonovat a resetovat `self.buf`.
/// Ale `take` lze použít k oddělení původní hodnoty `self.buf` od `self`, což umožňuje její vrácení:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Přesune `src` do odkazované `dest` a vrátí předchozí hodnotu `dest`.
///
/// Žádná z hodnot není vynechána.
///
/// * Pokud chcete nahradit hodnoty dvou proměnných, podívejte se na [`swap`].
/// * Pokud chcete nahradit výchozí hodnotu, podívejte se na [`take`].
///
/// # Examples
///
/// Jednoduchý příklad:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` umožňuje spotřebu pole struktury nahrazením jinou hodnotou.
/// Bez `replace` můžete narazit na problémy, jako jsou tyto:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Všimněte si, že `T` nemusí nutně implementovat [`Clone`], takže nemůžeme ani klonovat `self.buf[i]`, abychom se tomuto pohybu vyhnuli.
/// Ale `replace` lze použít k oddělení původní hodnoty v tomto indexu od `self`, což umožňuje její vrácení:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // BEZPEČNOST: Četli jsme z `dest`, ale poté do něj přímo zapisujeme `src`,
    // tak, aby nebyla duplikována stará hodnota.
    // Nic není zrušeno a nic zde nemůže panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Disponuje hodnotou.
///
/// Činí tak voláním implementace argumentu [`Drop`][drop].
///
/// To efektivně nedělá nic pro typy, které implementují `Copy`, např
/// integers.
/// Takové hodnoty jsou zkopírovány a _then_ přesunuty do funkce, takže hodnota přetrvává i po tomto volání funkce.
///
///
/// Tato funkce není magická;je doslova definován jako
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Protože `_x` je přesunut do funkce, je automaticky zrušen před návratem funkce.
///
/// [drop]: Drop
///
/// # Examples
///
/// Základní použití:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // výslovně zrušte vector
/// ```
///
/// Protože [`RefCell`] vynucuje pravidla výpůjčky za běhu, `drop` může uvolnit výpůjčku [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // vzdát se proměnlivé půjčky v tomto slotu
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Celá čísla a další typy implementující [`Copy`] nejsou `drop` ovlivněny.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // kopie `x` je přesunuta a zrušena
/// drop(y); // kopie `y` je přesunuta a zrušena
///
/// println!("x: {}, y: {}", x, y.0); // stále dostupný
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Interpretuje `src` jako typ `&U` a poté přečte `src` bez přesunutí obsažené hodnoty.
///
/// Tato funkce bude nebezpečně předpokládat, že ukazatel `src` je platný pro bajty [`size_of::<U>`][size_of] transmutací `&T` na `&U` a následným čtením `&U` (kromě toho, že je to provedeno správným způsobem, i když `&U` vyžaduje přísnější požadavky na zarovnání než `&T`).
/// Nebezpečně také vytvoří kopii obsažené hodnoty namísto přesunutí z `src`.
///
/// Nejedná se o chybu v době kompilace, pokud mají `T` a `U` různé velikosti, ale je velmi doporučeno vyvolat tuto funkci pouze tam, kde `T` a `U` mají stejnou velikost.Tato funkce spouští [undefined behavior][ub], pokud je `U` větší než `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Zkopírujte data z 'foo_array' a považujte je za 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Upravte zkopírovaná data
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Obsah 'foo_array' se neměl měnit
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Pokud má U vyšší požadavek na zarovnání, nemusí být src vhodně zarovnán.
    if align_of::<U>() > align_of::<T>() {
        // BEZPEČNOST: `src` je reference, která je zaručeně platná pro čtení.
        // Volající musí zaručit, že skutečná transmutace je bezpečná.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // BEZPEČNOST: `src` je reference, která je zaručeně platná pro čtení.
        // Právě jsme zkontrolovali, že `src as *const U` byl správně zarovnán.
        // Volající musí zaručit, že skutečná transmutace je bezpečná.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Neprůhledný typ představující diskriminátora výčtu.
///
/// Další informace najdete v části Funkce [`discriminant`] v tomto modulu.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Tyto implementace trait nelze odvodit, protože na T. nechceme žádné hranice.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Vrátí hodnotu jednoznačně identifikující variantu výčtu v `v`.
///
/// Pokud `T` není enum, volání této funkce nebude mít za následek nedefinované chování, ale návratová hodnota je nespecifikovaná.
///
///
/// # Stability
///
/// Diskriminační varianta výčtu se může změnit, pokud se změní definice výčtu.
/// Diskriminant některé varianty se mezi kompilacemi se stejným překladačem nezmění.
///
/// # Examples
///
/// To lze použít k porovnání výčtů, které přenášejí data, bez ohledu na skutečná data:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Vrátí počet variant ve výčtu typu `T`.
///
/// Pokud `T` není enum, volání této funkce nebude mít za následek nedefinované chování, ale návratová hodnota je nespecifikovaná.
/// Stejně tak, pokud `T` je výčet s více variantami než `usize::MAX`, návratová hodnota není uvedena.
/// Neobývané varianty budou započítány.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}