use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Obálka, která brání kompilátoru v automatickém volání destruktoru `T`.
/// Tento obal je bez nákladů.
///
/// `ManuallyDrop<T>` podléhá stejným optimalizacím rozvržení jako `T`.
/// V důsledku toho nemá *žádný vliv* na předpoklady, které kompilátor dělá o svém obsahu.
/// Například inicializace `ManuallyDrop<&mut T>` pomocí [`mem::zeroed`] je nedefinované chování.
/// Pokud potřebujete zpracovat neinicializovaná data, použijte místo toho [`MaybeUninit<T>`].
///
/// Všimněte si, že přístup k hodnotě uvnitř `ManuallyDrop<T>` je bezpečný.
/// To znamená, že `ManuallyDrop<T>`, jehož obsah byl zrušen, nesmí být vystaven prostřednictvím veřejného bezpečného rozhraní API.
/// Odpovídajícím způsobem je `ManuallyDrop::drop` nebezpečný.
///
/// # `ManuallyDrop` a zrušte objednávku.
///
/// Rust má dobře definovaných [drop order] hodnot.
/// Chcete-li se ujistit, že pole nebo místní obyvatelé jsou zrušeni v určitém pořadí, změňte pořadí deklarací tak, aby implicitní pořadí přetažení bylo správné.
///
/// Je možné použít `ManuallyDrop` k ovládání pořadí přetažení, ale to vyžaduje nebezpečný kód a je těžké to udělat správně za přítomnosti odvíjení.
///
///
/// Například pokud se chcete ujistit, že určité pole je vynecháno za ostatními, udělejte z něj poslední pole struktury:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` bude zrušeno po `children`.
///     // Rust zaručuje, že pole budou zrušena v pořadí deklarace.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Zabalte hodnotu, která má být ručně zrušena.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Na hodnotě můžete stále bezpečně pracovat
    /// assert_eq!(*x, "Hello");
    /// // Ale `Drop` zde nebude spuštěn
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Extrahuje hodnotu z kontejneru `ManuallyDrop`.
    ///
    /// To umožňuje opětovné upuštění hodnoty.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Tím klesne `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Vezme hodnotu z kontejneru `ManuallyDrop<T>` ven.
    ///
    /// Tato metoda je primárně určena pro přesunutí hodnot v poklesu.
    /// Místo toho, abyste ručně použili hodnotu [`ManuallyDrop::drop`], můžete tuto metodu použít k převzetí hodnoty a použít ji, jak je požadováno.
    ///
    /// Kdykoli je to možné, je lepší použít místo toho [`into_inner`][`ManuallyDrop::into_inner`], což zabrání duplikování obsahu `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Tato funkce sémanticky přesune obsaženou hodnotu bez zabránění dalšímu použití a ponechá stav tohoto kontejneru beze změny.
    /// Je vaší odpovědností zajistit, aby tento `ManuallyDrop` nebyl znovu používán.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // BEZPEČNOST: čteme z reference, která je zaručena
        // být platný pro čtení.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Ručně zruší obsaženou hodnotu.To je přesně ekvivalent volání [`ptr::drop_in_place`] s ukazatelem na obsaženou hodnotu.
    /// Pokud tedy obsažená hodnota není zabalená struktura, destruktor bude volán na místě bez přesunutí hodnoty, a lze jej tedy použít k bezpečnému odložení dat [pinned].
    ///
    /// Pokud vlastníte hodnotu, můžete místo toho použít [`ManuallyDrop::into_inner`].
    ///
    /// # Safety
    ///
    /// Tato funkce spustí destruktor obsažené hodnoty.
    /// Kromě změn provedených samotným destruktorem zůstává paměť beze změny, takže pokud jde o kompilátor, stále obsahuje bitový vzor, který je platný pro typ `T`.
    ///
    ///
    /// Tato hodnota "zombie" by však neměla být vystavena bezpečnému kódu a tato funkce by neměla být volána více než jednou.
    /// Chcete-li použít hodnotu poté, co byla zrušena, nebo ji několikrát vypustit, může to způsobit nedefinované chování (v závislosti na tom, co `drop` dělá).
    /// Normálně tomu systém typů brání, ale uživatelé `ManuallyDrop` musí tyto záruky dodržet bez pomoci kompilátoru.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // BEZPEČNOST: snižujeme hodnotu, na kterou ukazuje proměnlivá reference
        // který je zaručeně platný pro zápisy.
        // Je na volajícím, aby se ujistil, že `slot` není znovu zrušen.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}