use crate::fmt;

/// Vytvoří nový iterátor, kde každá iterace volá zadaný uzávěr `F: FnMut() -> Option<T>`.
///
/// To umožňuje vytvořit vlastní iterátor s jakýmkoli chováním bez použití podrobnější syntaxe vytváření vyhrazeného typu a implementace [`Iterator`] trait pro něj.
///
/// Všimněte si, že iterátor `FromFn` nevytváří předpoklady o chování uzávěru, a proto konzervativně neimplementuje [`FusedIterator`] nebo nepřepíše [`Iterator::size_hint()`] ze svého výchozího `(0, None)`.
///
///
/// Uzávěr může pomocí zachycení a jeho prostředí sledovat stav napříč iteracemi.V závislosti na tom, jak se iterátor používá, to může vyžadovat zadání klíčového slova [`move`] na uzávěru.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Pojďme znovu implementovat iterátor čítače z [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Zvyšte náš počet.Proto jsme začali na nule.
///     count += 1;
///
///     // Zkontrolujte, zda jsme počítání dokončili nebo ne.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Iterátor, kde každá iterace volá zadanou uzávěrku `F: FnMut() -> Option<T>`.
///
/// Tento `struct` je vytvořen funkcí [`iter::from_fn()`].
/// Další informace najdete v jeho dokumentaci.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}