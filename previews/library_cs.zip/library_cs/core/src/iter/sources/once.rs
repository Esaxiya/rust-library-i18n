use crate::iter::{FusedIterator, TrustedLen};

/// Vytvoří iterátor, který získá prvek přesně jednou.
///
/// To se běžně používá k přizpůsobení jedné hodnoty do [`chain()`] jiných druhů iterace.
/// Možná máte iterátor, který pokrývá téměř vše, ale potřebujete zvláštní případ.
/// Možná máte funkci, která pracuje na iterátorech, ale potřebujete zpracovat pouze jednu hodnotu.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Základní použití:
///
/// ```
/// use std::iter;
///
/// // jeden je nejosamělejší číslo
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // jen jeden, to je vše, co dostaneme
/// assert_eq!(None, one.next());
/// ```
///
/// Řetězení spolu s dalším iterátorem.
/// Řekněme, že chceme iterovat každý soubor adresáře `.foo`, ale také konfigurační soubor,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // musíme převést z iterátoru DirEntry-s na iterátor PathBufs, takže používáme mapu
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // nyní náš iterátor pouze pro náš konfigurační soubor
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // spojte dva iterátory dohromady do jednoho velkého iterátoru
/// let files = dirs.chain(config);
///
/// // to nám dá všechny soubory v .foo i .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Iterátor, který získá prvek přesně jednou.
///
/// Tento `struct` je vytvořen funkcí [`once()`].Další informace najdete v jeho dokumentaci.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}