use crate::iter::{FusedIterator, TrustedLen};

/// Vytvoří nový iterátor, který nekonečně opakuje jeden prvek.
///
/// Funkce `repeat()` opakuje jednu hodnotu znovu a znovu.
///
/// Nekonečné iterátory jako `repeat()` se často používají s adaptéry jako [`Iterator::take()`], aby byly konečné.
///
/// Pokud typ prvku iterátoru, který potřebujete, neimplementuje `Clone`, nebo pokud nechcete zachovat opakovaný prvek v paměti, můžete místo toho použít funkci [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Základní použití:
///
/// ```
/// use std::iter;
///
/// // číslo čtyři 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // jo, pořád čtyři
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Do konce s [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // ten poslední příklad byl příliš mnoho čtyř.Pojďme mít jen čtyři čtyři.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... a teď máme hotovo
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Iterátor, který nekonečně opakuje prvek.
///
/// Tento `struct` je vytvořen funkcí [`repeat()`].Další informace najdete v jeho dokumentaci.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}