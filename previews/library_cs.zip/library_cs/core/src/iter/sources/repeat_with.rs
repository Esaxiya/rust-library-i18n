use crate::iter::{FusedIterator, TrustedLen};

/// Vytvoří nový iterátor, který donekonečna opakuje prvky typu `A` použitím zadaného uzávěru, opakovače, `F: FnMut() -> A`.
///
/// Funkce `repeat_with()` volá opakovač znovu a znovu.
///
/// Nekonečné iterátory jako `repeat_with()` se často používají s adaptéry jako [`Iterator::take()`], aby byly konečné.
///
/// Pokud typ prvku iterátoru, který potřebujete, implementuje [`Clone`] a je v pořádku zachovat zdrojový prvek v paměti, měli byste místo toho použít funkci [`repeat()`].
///
///
/// Iterátor produkovaný `repeat_with()` není [`DoubleEndedIterator`].
/// Pokud potřebujete `repeat_with()` k vrácení [`DoubleEndedIterator`], otevřete prosím problém s GitHub vysvětlující váš případ použití.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Základní použití:
///
/// ```
/// use std::iter;
///
/// // Předpokládejme, že máme nějakou hodnotu typu, který není `Clone` nebo který ještě nechcete mít v paměti, protože je drahý:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // konkrétní hodnota navždy:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Použití mutace a přechod na konečnou:
///
/// ```rust
/// use std::iter;
///
/// // Od nuly do třetí síly dvou:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... a teď máme hotovo
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Iterátor, který donekonečna opakuje prvky typu `A` použitím zadaného uzávěru `F: FnMut() -> A`.
///
///
/// Tento `struct` je vytvořen funkcí [`repeat_with()`].
/// Další informace najdete v jeho dokumentaci.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}