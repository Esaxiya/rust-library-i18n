//! Složitelná externí iterace.
//!
//! Pokud jste našli nějakou sbírku a potřebujete provést operaci s prvky uvedené kolekce, rychle narazíte na 'iterators'.
//! Iterátory jsou často používány v idiomatickém kódu Rust, takže stojí za to se s nimi seznámit.
//!
//! Než vysvětlíme více, promluvme si o tom, jak je tento modul strukturován:
//!
//! # Organization
//!
//! Tento modul je z velké části organizován podle typu:
//!
//! * [Traits] jsou hlavní částí: tyto traits definují, jaké iterátory existují a co s nimi můžete dělat.Metody těchto traits stojí za to věnovat nějaký čas navíc studiu.
//! * [Functions] poskytnout několik užitečných způsobů, jak vytvořit několik základních iterátorů.
//! * [Structs] jsou často typy návratů různých metod na traits tohoto modulu.Obvykle se budete chtít podívat na metodu, která vytváří `struct`, spíše než na samotný `struct`.
//! Další podrobnosti o tom, proč, najdete v části " [Implementující iterátor](#implementation-iterator)`.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! A je to!Pojďme kopat do iterátorů.
//!
//! # Iterator
//!
//! Srdcem a duší tohoto modulu je [`Iterator`] trait.Jádro [`Iterator`] vypadá takto:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Iterátor má metodu [`next`], která při volání vrátí [" Možnost`]`<Item>`.
//! [`next`] vrátí [`Some(Item)`], pokud existují prvky, a jakmile budou všechny vyčerpány, vrátí `None`, což znamená, že iterace je dokončena.
//! Jednotlivé iterátory se mohou rozhodnout obnovit iteraci, a tak opětovné volání [`next`] může nebo nemusí nakonec v určitém okamžiku začít znovu vracet [`Some(Item)`] (například viz [`TryIter`]).
//!
//!
//! Plná definice aplikace [`Iterator`] zahrnuje také řadu dalších metod, ale jsou to výchozí metody postavené na [`next`], takže je máte zdarma.
//!
//! Iterátory jsou také skládatelné a je běžné je spojovat dohromady, aby bylo možné provádět složitější formy zpracování.Další podrobnosti najdete níže v části [Adapters](#adapters).
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Tři formy iterace
//!
//! Existují tři běžné metody, které mohou vytvářet iterátory ze sbírky:
//!
//! * `iter()`, který iteruje přes `&T`.
//! * `iter_mut()`, který iteruje přes `&mut T`.
//! * `into_iter()`, který iteruje přes `T`.
//!
//! Různé věci ve standardní knihovně mohou implementovat jednu nebo více ze tří, pokud je to vhodné.
//!
//! # Implementace Iterátoru
//!
//! Vytvoření vlastního iterátoru zahrnuje dva kroky: vytvoření `struct` pro uchování stavu iterátoru a implementace [`Iterator`] pro tento `struct`.
//! To je důvod, proč v tomto modulu existuje tolik `struktur`: pro každý iterátor a adaptér iterátoru je jeden.
//!
//! Vytvořme iterátor s názvem `Counter`, který počítá od `1` do `5`:
//!
//! ```
//! // Nejprve struktura:
//!
//! /// Iterátor, který počítá od jedné do pěti
//! struct Counter {
//!     count: usize,
//! }
//!
//! // chceme, aby náš počet začínal na jedné, přidejme tedy na pomoc metodu new().
//! // To není nezbytně nutné, ale je to pohodlné.
//! // Všimněte si, že začínáme `count` na nule, uvidíme proč v implementaci `next()`'s níže.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Potom implementujeme `Iterator` pro náš `Counter`:
//!
//! impl Iterator for Counter {
//!     // budeme počítat s usize
//!     type Item = usize;
//!
//!     // next() je jedinou požadovanou metodou
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Zvyšte náš počet.Proto jsme začali na nule.
//!         self.count += 1;
//!
//!         // Zkontrolujte, zda jsme počítání dokončili nebo ne.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // A teď to můžeme použít!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Volání [`next`] tímto způsobem se opakuje.Rust má konstrukci, která může volat [`next`] na vašem iterátoru, dokud nedosáhne `None`.Pojďme to projít dále.
//!
//! Všimněte si také, že `Iterator` poskytuje výchozí implementaci metod, jako jsou `nth` a `fold`, které interně volají `next`.
//! Je však také možné napsat vlastní implementaci metod jako `nth` a `fold`, pokud je může iterátor vypočítat efektivněji bez volání `next`.
//!
//! # `for` smyčky a `IntoIterator`
//!
//! Syntaxe smyčky `for` v Rust je ve skutečnosti iterátorem cukru.Zde je základní příklad `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Tím se vytisknou čísla jedna až pět, každé na svém vlastním řádku.Ale tady si něco všimnete: na našem vector jsme nikdy nic nevolali, abychom vytvořili iterátor.Co dává?
//!
//! Ve standardní knihovně je trait pro převod něčeho na iterátor: [`IntoIterator`].
//! Tento trait má jednu metodu, [`into_iter`], která převádí věc implementující [`IntoIterator`] na iterátor.
//! Podívejme se na tuto smyčku `for` znovu a na to, na co ji kompilátor převede:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust toto zbavuje cukru na:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Nejprve voláme `into_iter()` na hodnotě.Poté se shodujeme s iterátorem, který se vrací, znovu a znovu voláme [`next`], dokud neuvidíme `None`.
//! V tomto okamžiku jsme `break` ze smyčky a skončili jsme s iterací.
//!
//! Je tu ještě jeden jemný kousek: standardní knihovna obsahuje zajímavou implementaci [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Jinými slovy, všichni [" Iterátoři`] implementují [`IntoIterator`] pouhým návratem.To znamená dvě věci:
//!
//! 1. Pokud píšete [`Iterator`], můžete jej použít se smyčkou `for`.
//! 2. Pokud vytváříte kolekci, implementace [`IntoIterator`] pro ni umožní použití vaší kolekce ve smyčce `for`.
//!
//! # Iterace podle odkazu
//!
//! Protože [`into_iter()`] bere `self` podle hodnoty, použití smyčky `for` k iteraci přes kolekci tuto kolekci spotřebuje.Často můžete chtít iterovat kolekci, aniž byste ji konzumovali.
//! Mnoho kolekcí nabízí metody, které poskytují iterátory nad referencemi, běžně nazývanými `iter()` a `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` je stále ve vlastnictví této funkce.
//! ```
//!
//! Pokud typ kolekce `C` poskytuje `iter()`, obvykle také implementuje `IntoIterator` pro `&C`, s implementací, která právě volá `iter()`.
//! Podobně kolekce `C`, která poskytuje `iter_mut()`, obecně implementuje `IntoIterator` pro `&mut C` delegováním na `iter_mut()`.To umožňuje pohodlnou zkratku:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // stejné jako `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // stejné jako `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Zatímco mnoho sbírek nabízí `iter()`, ne všechny nabízejí `iter_mut()`.
//! Například mutace klíčů [`HashSet<T>`] nebo [`HashMap<K, V>`] by mohla dát kolekci do nekonzistentního stavu, pokud se změní hash klíče, takže tyto kolekce nabízejí pouze `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Funkce, které přebírají [`Iterator`] a vracejí další [`Iterator`], se často nazývají " iterátorové adaptéry`, protože jsou formou " adaptéru`
//! pattern'.
//!
//! Mezi běžné iterátorové adaptéry patří [`map`], [`take`] a [`filter`].
//! Další informace najdete v jejich dokumentaci.
//!
//! Pokud je iterátorový adaptér panics, bude iterátor ve nespecifikovaném (ale bezpečné paměti) stavu.
//! Tento stav také nezaručuje, že zůstane stejný napříč verzemi Rust, takže byste se neměli spoléhat na přesné hodnoty vrácené iterátorem, který zpanikařil.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterátory (a iterátor [adapters](#adapters)) jsou *líní*. To znamená, že pouze vytvoření iterátoru není _do_ příliš mnoho. Ve skutečnosti se nic nestane, dokud nezavoláte [`next`].
//! To je někdy zdroj záměny při vytváření iterátoru pouze pro jeho vedlejší účinky.
//! Například metoda [`map`] volá uzávěr u každého prvku, který iteruje:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! To nevytiskne žádné hodnoty, protože jsme vytvořili pouze iterátor, místo abychom jej používali.Kompilátor nás na tento druh chování upozorní:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Idiomatickým způsobem, jak napsat [`map`] pro jeho vedlejší účinky, je použít smyčku `for` nebo zavolat metodu [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Dalším běžným způsobem, jak vyhodnotit iterátor, je použití metody [`collect`] k vytvoření nové kolekce.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iterátory nemusí být konečné.Jako příklad je otevřeným rozsahem nekonečný iterátor:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Je běžné používat adaptér iterátoru [`take`] k přeměně nekonečného iterátoru na konečný:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Tím se vytisknou čísla `0` až `4`, každé na svém vlastním řádku.
//!
//! Mějte na paměti, že metody na nekonečných iterátorech, dokonce i těch, u nichž lze matematicky určit výsledek v konečném čase, nemusí být ukončeny.
//! Konkrétně metody jako [`min`], které obecně vyžadují procházení všech prvků v iterátoru, se pravděpodobně nevrátí úspěšně pro žádné nekonečné iterátory.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Ach ne!Nekonečná smyčka!
//! // `ones.min()` způsobí nekonečnou smyčku, takže tohoto bodu nedosáhneme!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;