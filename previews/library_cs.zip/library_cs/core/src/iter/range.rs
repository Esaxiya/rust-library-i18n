use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Objekty, které mají představu o operacích *nástupce* a *předchůdce*.
///
/// Operace *nástupce* se posune k hodnotám, které se porovnávají větší.
/// Operace *předchůdce* se posune k hodnotám, které se porovnávají méně.
///
/// # Safety
///
/// Tento trait je `unsafe`, protože jeho implementace musí být správná z důvodu bezpečnosti implementací `unsafe trait TrustedLen`, a výsledky použití tohoto trait lze jinak důvěřovat kódem `unsafe`, aby byly správné a splňovaly uvedené povinnosti.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Vrátí počet *následných* kroků potřebných k přechodu z `start` na `end`.
    ///
    /// Vrátí `None`, pokud by počet kroků přetekl `usize` (nebo je nekonečný, nebo pokud by nikdy nebylo dosaženo `end`).
    ///
    ///
    /// # Invariants
    ///
    /// Pro všechny modely `a`, `b` a `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` právě když `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` právě když `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` pouze pokud `a <= b`
    ///   * Dodatek: `steps_between(&a, &b) == Some(0)` právě tehdy, pokud `a == b`
    ///   * Všimněte si, že `a <= b` znamená _not_, což znamená `steps_between(&a, &b) != None`;
    ///     to je případ, kdy by k získání `b` bylo zapotřebí více než `usize::MAX` kroků
    /// * `steps_between(&a, &b) == None` pokud `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Vrátí hodnotu, která by byla získána převzetím *nástupce* z `self` `count` krát.
    ///
    /// Pokud by došlo k přetečení rozsahu hodnot podporovaných `Self`, vrátí `None`.
    ///
    /// # Invariants
    ///
    /// Pro všechny modely `a`, `n` a `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Pro všechny `a`, `n` a `m`, kde `n + m` nepřetéká:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Pro všechny modely `a` a `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Vrátí hodnotu, která by byla získána převzetím *nástupce* z `self` `count` krát.
    ///
    /// Pokud by došlo k přetečení rozsahu hodnot podporovaných `Self`, je tato funkce povolena na panic, wrap nebo saturate.
    ///
    /// Navrhované chování je panic, když jsou povolena tvrzení ladění, a jinak zabalit nebo saturovat.
    ///
    /// Nebezpečný kód by se neměl spoléhat na správnost chování po přetečení.
    ///
    /// # Invariants
    ///
    /// U všech modelů `a`, `n` a `m`, u kterých nedochází k přetečení:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// U všech `a` a `n`, kde nedochází k přetečení:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Vrátí hodnotu, která by byla získána převzetím *nástupce* z `self` `count` krát.
    ///
    /// # Safety
    ///
    /// Je nedefinované chování této operace k přetečení rozsahu hodnot podporovaných `Self`.
    /// Pokud nemůžete zaručit, že nedojde k přetečení, použijte místo toho `forward` nebo `forward_checked`.
    ///
    /// # Invariants
    ///
    /// Pro jakoukoli `a`:
    ///
    /// * pokud existuje `b` takový, že `b > a`, je bezpečné volat `Step::forward_unchecked(a, 1)`
    /// * pokud existuje `b`, `n` takový, že `steps_between(&a, &b) == Some(n)`, je bezpečné volat `Step::forward_unchecked(a, m)` pro jakýkoli `m <= n`.
    ///
    ///
    /// U všech `a` a `n`, kde nedochází k přetečení:
    ///
    /// * `Step::forward_unchecked(a, n)` odpovídá `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Vrátí hodnotu, která by byla získána převzetím *předchůdce* z `self` `count` krát.
    ///
    /// Pokud by došlo k přetečení rozsahu hodnot podporovaných `Self`, vrátí `None`.
    ///
    /// # Invariants
    ///
    /// Pro všechny modely `a`, `n` a `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Pro všechny modely `a` a `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Vrátí hodnotu, která by byla získána převzetím *předchůdce* z `self` `count` krát.
    ///
    /// Pokud by došlo k přetečení rozsahu hodnot podporovaných `Self`, je tato funkce povolena na panic, wrap nebo saturate.
    ///
    /// Navrhované chování je panic, když jsou povolena tvrzení ladění, a jinak zabalit nebo saturovat.
    ///
    /// Nebezpečný kód by se neměl spoléhat na správnost chování po přetečení.
    ///
    /// # Invariants
    ///
    /// U všech modelů `a`, `n` a `m`, u kterých nedochází k přetečení:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// U všech `a` a `n`, kde nedochází k přetečení:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Vrátí hodnotu, která by byla získána převzetím *předchůdce* z `self` `count` krát.
    ///
    /// # Safety
    ///
    /// Je nedefinované chování této operace k přetečení rozsahu hodnot podporovaných `Self`.
    /// Pokud nemůžete zaručit, že nedojde k přetečení, použijte místo toho `backward` nebo `backward_checked`.
    ///
    /// # Invariants
    ///
    /// Pro jakoukoli `a`:
    ///
    /// * pokud existuje `b` takový, že `b < a`, je bezpečné volat `Step::backward_unchecked(a, 1)`
    /// * pokud existuje `b`, `n` takový, že `steps_between(&b, &a) == Some(n)`, je bezpečné volat `Step::backward_unchecked(a, m)` pro jakýkoli `m <= n`.
    ///
    ///
    /// U všech `a` a `n`, kde nedochází k přetečení:
    ///
    /// * `Step::backward_unchecked(a, n)` odpovídá `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Stále se generují makra, protože celočíselné literály se rozlišují na různé typy.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // BEZPEČNOST: volající musí zaručit, že `start + n` nebude přetékat.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // BEZPEČNOST: volající musí zaručit, že `start - n` nebude přetékat.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // V sestavení ladění spusťte panic při přetečení.
            // To by se mělo v sestaveních vydání úplně optimalizovat.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Zabalte matematiku, abyste umožnili např `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // V sestavení ladění spusťte panic při přetečení.
            // To by se mělo v sestaveních vydání úplně optimalizovat.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Zabalte matematiku, abyste umožnili např `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // To závisí na $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // pokud n je mimo rozsah, `unsigned_start + n` je také
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // pokud n je mimo rozsah, `unsigned_start - n` je také
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // To závisí na $i_narrower <=usize
                        //
                        // Casting to isize rozšiřuje šířku, ale zachovává znak.
                        // Použijte wrapping_sub v isize space a cast to usize pro výpočet rozdílu, který se nemusí hodit do rozsahu isize.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Balení zpracovává případy jako `Step::forward(-120_i8, 200) == Some(80_i8)`, i když 200 je pro i8 mimo rozsah.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Přidání přeteklo
                            }
                        }
                        // Pokud n je mimo rozsah např
                        // u8, pak je větší než celý rozsah pro i8 je široký, takže `any_i8 + n` nutně přetéká i8.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Balení zpracovává případy jako `Step::forward(-120_i8, 200) == Some(80_i8)`, i když 200 je pro i8 mimo rozsah.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Odčítání přeteklo
                            }
                        }
                        // Pokud n je mimo rozsah např
                        // u8, pak je větší než celý rozsah pro i8 je široký, takže `any_i8 - n` nutně přetéká i8.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Pokud je rozdíl příliš velký např
                            // i128, bude to také příliš velké pro použití s menším počtem bitů.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // BEZPEČNOST: res je platný skalární kód Unicode
            // (pod 0x110000 a ne v 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // BEZPEČNOST: res je platný skalární kód Unicode
        // (pod 0x110000 a ne v 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // BEZPEČNOST: volající musí zaručit, že to nepřeteče
        // rozsah hodnot pro znak.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // BEZPEČNOST: volající musí zaručit, že to nepřeteče
            // rozsah hodnot pro znak.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // BEZPEČNOST: z důvodu předchozí smlouvy je to zaručeno
        // volajícím za platný znak.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // BEZPEČNOST: volající musí zaručit, že to nepřeteče
        // rozsah hodnot pro znak.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // BEZPEČNOST: volající musí zaručit, že to nepřeteče
            // rozsah hodnot pro znak.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // BEZPEČNOST: z důvodu předchozí smlouvy je to zaručeno
        // volajícím za platný znak.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // BEZPEČNOST: pouze zkontrolována předpoklad
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // BEZPEČNOST: pouze zkontrolována předpoklad
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Tato makra generují implikace `ExactSizeIterator` pro různé typy rozsahů.
//
// * `ExactSizeIterator::len` je nutné vždy vrátit přesnou `usize`, takže žádný dosah nesmí být delší než `usize::MAX`.
//
// * U celočíselných typů v `Range<_>` to platí pro typy užší než nebo tak široké jako `usize`.
//   U celočíselných typů v `RangeInclusive<_>` to platí pro typy *striktně užší* než `usize`, protože např
//   `(0..=u64::MAX).len()` bude `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Podle výše uvedené úvahy se jedná o incore, ale jejich odstranění by bylo zlomovou změnou, protože byly stabilizovány v Rust 1.0.0.
    // Takže např
    // `(0..66_000_u32).len()` například bude kompilován bez chyby nebo varování na 16bitových platformách, ale bude i nadále poskytovat špatný výsledek.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Podle výše uvedené úvahy se jedná o incore, ale jejich odstranění by bylo zlomovou změnou, protože byly stabilizovány v Rust 1.26.0.
    // Takže např
    // `(0..=u16::MAX).len()` například bude kompilován bez chyby nebo varování na 16bitových platformách, ale bude i nadále poskytovat špatný výsledek.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // BEZPEČNOST: pouze zkontrolována předpoklad
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // BEZPEČNOST: pouze zkontrolována předpoklad
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // BEZPEČNOST: pouze zkontrolována předpoklad
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // BEZPEČNOST: pouze zkontrolována předpoklad
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // BEZPEČNOST: pouze zkontrolována předpoklad
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // BEZPEČNOST: pouze zkontrolována předpoklad
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}