/// Konverze z [`Iterator`].
///
/// Implementací `FromIterator` pro typ definujete, jak bude vytvořen z iterátoru.
/// To je běžné pro typy, které popisují kolekci nějakého druhu.
///
/// [`FromIterator::from_iter()`] je zřídka volán explicitně a místo toho je používán metodou [`Iterator::collect()`].
///
/// Další příklady najdete v dokumentaci [`Iterator::collect()`]'s.
///
/// Viz také: [`IntoIterator`].
///
/// # Examples
///
/// Základní použití:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Použití [`Iterator::collect()`] k implicitnímu použití `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Implementace `FromIterator` pro váš typ:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Sbírka vzorků, to je jen obal přes Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Pojďme mu dát několik metod, abychom mohli jednu vytvořit a přidat k ní věci.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // a implementujeme FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Nyní můžeme vytvořit nový iterátor ...
/// let iter = (0..5).into_iter();
///
/// // ... a vytvořte z toho MyCollection
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // sbírejte také díla!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Vytvoří hodnotu z iterátoru.
    ///
    /// Další informace najdete v [module-level documentation].
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Přeměna na [`Iterator`].
///
/// Implementací `IntoIterator` pro typ definujete, jak bude převeden na iterátor.
/// To je běžné pro typy, které popisují kolekci nějakého druhu.
///
/// Jednou z výhod implementace `IntoIterator` je, že váš typ bude [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Viz také: [`FromIterator`].
///
/// # Examples
///
/// Základní použití:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Implementace `IntoIterator` pro váš typ:
///
/// ```
/// // Sbírka vzorků, to je jen obal přes Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Pojďme mu dát několik metod, abychom mohli jednu vytvořit a přidat k ní věci.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // a implementujeme IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Nyní můžeme vytvořit novou kolekci ...
/// let mut c = MyCollection::new();
///
/// // ... přidejte k tomu nějaké věci ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... a pak z něj udělejte Iterátora:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Je běžné používat `IntoIterator` jako trait bound.To umožňuje změnit typ kolekce vstupu, pokud je stále iterátor.
/// Další hranice lze určit omezením na
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Typ prvků, které jsou iterovány.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Na jaký druh iterátoru to děláme?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Vytvoří iterátor z hodnoty.
    ///
    /// Další informace najdete v [module-level documentation].
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Rozšířit kolekci o obsah iterátoru.
///
/// Iterátory vytvářejí řadu hodnot a sbírky lze také považovat za řadu hodnot.
/// `Extend` trait překlenuje tuto mezeru a umožňuje vám rozšířit kolekci zahrnutím obsahu tohoto iterátoru.
/// Při rozšiřování kolekce o již existující klíč se tato položka aktualizuje, nebo v případě kolekcí, které umožňují více položek se stejnými klíči, se tato položka vloží.
///
///
/// # Examples
///
/// Základní použití:
///
/// ```
/// // Řetězec můžete rozšířit několika znaky:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Implementace `Extend`:
///
/// ```
/// // Sbírka vzorků, to je jen obal přes Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Pojďme mu dát několik metod, abychom mohli jednu vytvořit a přidat k ní věci.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // protože MyCollection má seznam i32, implementujeme Extend pro i32
/// impl Extend<i32> for MyCollection {
///
///     // To je s podpisem konkrétního typu o něco jednodušší: můžeme zavolat extend na cokoli, z čeho lze udělat Iterátor, který nám dává i32s.
///     // Protože potřebujeme i32s dát do MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Implementace je velmi přímočará: procházejte iterátorem a každý prvek add() pro sebe.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // pojďme rozšířit naši sbírku o další tři čísla
/// c.extend(vec![1, 2, 3]);
///
/// // přidali jsme tyto prvky na konec
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Rozšiřuje kolekci o obsah iterátoru.
    ///
    /// Protože se jedná o jedinou požadovanou metodu pro tuto trait, dokumenty [trait-level] obsahují další podrobnosti.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// // Řetězec můžete rozšířit několika znaky:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Rozšiřuje kolekci přesně o jeden prvek.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Rezervuje kapacitu v kolekci pro daný počet dalších prvků.
    ///
    /// Výchozí implementace nedělá nic.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}