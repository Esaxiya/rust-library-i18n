/// Iterátor, který po vyčerpání vždy pokračuje ve výnosech `None`.
///
/// Volání next na fúzovaném iterátoru, který jednou vrátil `None`, zaručuje návrat [`None`] znovu.
/// Tento trait by měl být implementován všemi iterátory, které se chovají tímto způsobem, protože umožňují optimalizovat [`Iterator::fuse()`].
///
///
/// Note: Obecně byste neměli používat `FusedIterator` v obecných mezích, pokud potřebujete fúzovaný iterátor.
/// Místo toho byste měli zavolat [`Iterator::fuse()`] na iterátoru.
/// Pokud je iterátor již fúzovaný, další obal [`Fuse`] bude no-op bez penalizace výkonu.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Iterátor, který hlásí přesnou délku pomocí size_hint.
///
/// Iterátor hlásí nápovědu k velikosti, kde je buď přesná (dolní hranice se rovná horní hranici), nebo horní hranice je [`None`].
///
/// Horní mez musí být pouze [`None`], pokud je skutečná délka iterátoru větší než [`usize::MAX`].
/// V takovém případě musí být dolní mez [`usize::MAX`], což má za následek [`Iterator::size_hint()`] `(usize::MAX, None)`.
///
/// Iterátor musí před dosažením konce vyprodukovat přesně ten počet prvků, které nahlásil nebo se rozcházel.
///
/// # Safety
///
/// Tento trait musí být implementován, pouze když je smlouva potvrzena.
/// Spotřebitelé tohoto trait musí zkontrolovat horní hranici [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Iterátor, který při získání položky vezme alespoň jeden prvek ze svého podkladového [`SourceIter`].
///
/// Volání jakékoli metody, která posune iterátor, např
/// [`next()`] nebo [`try_fold()`], zaručuje, že pro každý krok byla přesunuta alespoň jedna hodnota podkladového zdroje iterátoru a na jeho místo může být vložen výsledek řetězce iterátoru, za předpokladu, že strukturální omezení zdroje umožňují takové vložení.
///
/// Jinými slovy tento trait naznačuje, že lze na místě shromáždit iterační kanál.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}