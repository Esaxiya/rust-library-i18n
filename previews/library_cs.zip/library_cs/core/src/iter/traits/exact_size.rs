/// Iterátor, který zná přesnou délku.
///
/// Mnoho [" Iterátorů`] neví, kolikrát budou iterovat, ale někteří ano.
/// Pokud iterátor ví, kolikrát může iterovat, může být užitečné poskytnout přístup k těmto informacím.
/// Například pokud chcete iterovat zpět, dobrým začátkem je vědět, kde je konec.
///
/// Při implementaci `ExactSizeIterator` musíte také implementovat [`Iterator`].
/// Přitom implementace [`Iterator::size_hint`]*musí* vrátit přesnou velikost iterátoru.
///
/// Metoda [`len`] má výchozí implementaci, takže byste ji obvykle neměli implementovat.
/// Možná však budete moci poskytnout výkonnější implementaci než výchozí, takže její přepsání v tomto případě dává smysl.
///
///
/// Všimněte si, že tento trait je bezpečný trait a jako takový *ne* a *nemůže* zaručit, že vrácená délka je správná.
/// To znamená, že kód `unsafe`**nesmí** spoléhat na správnost [`Iterator::size_hint`].
/// Nestabilní a nebezpečný [`TrustedLen`](super::marker::TrustedLen) trait poskytuje tuto další záruku.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Základní použití:
///
/// ```
/// // konečný rozsah přesně ví, kolikrát bude iterovat
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// V [module-level docs] jsme implementovali [`Iterator`], `Counter`.
/// Implementujme pro ni také `ExactSizeIterator`:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Můžeme snadno vypočítat zbývající počet iterací.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // A teď to můžeme použít!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Vrátí přesnou délku iterátoru.
    ///
    /// Implementace zajišťuje, že iterátor vrátí přesně `len()` vícekrát hodnotu [`Some(T)`], než vrátí [`None`].
    ///
    /// Tato metoda má výchozí implementaci, takže byste ji obvykle neměli implementovat přímo.
    /// Pokud však můžete poskytnout efektivnější implementaci, můžete tak učinit.
    /// Příklad najdete v dokumentech [trait-level].
    ///
    /// Tato funkce má stejné bezpečnostní záruky jako funkce [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// // konečný rozsah přesně ví, kolikrát bude iterovat
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Toto tvrzení je příliš defenzivní, ale kontroluje invariant
        // zaručeno trait.
        // Pokud by tento trait byl rust-internal, mohli bychom použít debug_assert !;assert_eq!zkontroluje také všechny implementace uživatele Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Vrátí `true`, pokud je iterátor prázdný.
    ///
    /// Tato metoda má výchozí implementaci pomocí [`ExactSizeIterator::len()`], takže ji nemusíte implementovat sami.
    ///
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}