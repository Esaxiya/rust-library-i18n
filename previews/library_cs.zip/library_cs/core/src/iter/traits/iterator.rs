// ignore-tidy-filelength Tento soubor téměř výhradně sestává z definice `Iterator`.
// To nemůžeme rozdělit do více souborů.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Rozhraní pro práci s iterátory.
///
/// Toto je hlavní iterátor trait.
/// Další informace o konceptu iterátorů obecně najdete v [module-level documentation].
/// Zejména možná budete chtít vědět, jak na [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Typ prvků, které jsou iterovány.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Posune iterátor a vrátí další hodnotu.
    ///
    /// Vrátí [`None`] po dokončení iterace.
    /// Jednotlivé implementace iterátoru se mohou rozhodnout obnovit iteraci, a tak opětovné volání `next()` může nebo nemusí nakonec v určitém okamžiku začít znovu vracet [`Some(Item)`].
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Volání next() vrátí další hodnotu ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... a pak Žádný, jakmile to skončí.
    /// assert_eq!(None, iter.next());
    ///
    /// // Více hovorů může nebo nemusí vrátit `None`.Tady vždy budou.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Vrátí hranice zbývající délky iterátoru.
    ///
    /// Konkrétně `size_hint()` vrací n-tici, kde první prvek je dolní mez a druhý prvek je horní mez.
    ///
    /// Druhá polovina n-tice, která je vrácena, je [`Option`]`<`[`usize`] `>`.
    /// [`None`] zde znamená, že buď není známa horní mez, nebo je horní mez větší než [`usize`].
    ///
    /// # Poznámky k implementaci
    ///
    /// Není vynuceno, aby implementace iterátoru přinesla deklarovaný počet prvků.Buginy iterátor může přinést méně než dolní mez nebo více než horní mez prvků.
    ///
    /// `size_hint()` je primárně určen k použití pro optimalizace, jako je rezervace prostoru pro prvky iterátoru, ale nesmí být důvěryhodný např. pro vynechání hraničních kontrol v nebezpečném kódu.
    /// Nesprávná implementace `size_hint()` by neměla vést k narušení bezpečnosti paměti.
    ///
    /// To znamená, že implementace by měla poskytovat správný odhad, protože jinak by to bylo porušení protokolu trait.
    ///
    /// Výchozí implementace vrací `(0,` [`None`]`)`, což je správné pro jakýkoli iterátor.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Složitější příklad:
    ///
    /// ```
    /// // Sudá čísla od nuly do deseti.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Mohli bychom iterovat od nuly do desetkrát.
    /// // Vědomí, že je to přesně pět, by nebylo možné bez provedení filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Přidejme dalších pět čísel s chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // nyní jsou obě hranice zvýšeny o pět
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Vrácení `None` pro horní mez:
    ///
    /// ```
    /// // nekonečný iterátor nemá horní hranici a maximální možnou dolní hranici
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Spotřebuje iterátor, spočítá počet iterací a vrátí jej.
    ///
    /// Tato metoda bude volat [`next`] opakovaně, dokud nenarazí na [`None`], čímž vrátí počet, kolikrát viděl [`Some`].
    /// Všimněte si, že [`next`] musí být vyvolán alespoň jednou, i když iterátor nemá žádné prvky.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Chování při přetečení
    ///
    /// Metoda neprobíhá žádnou ochranu proti přetečení, takže počítání prvků iterátoru s více než [`usize::MAX`] prvky produkuje nesprávný výsledek nebo panics.
    ///
    /// Pokud jsou povolena tvrzení ladění, je zaručen panic.
    ///
    /// # Panics
    ///
    /// Tato funkce může panic, pokud má iterátor více než [`usize::MAX`] prvků.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Spotřebuje iterátor a vrátí poslední prvek.
    ///
    /// Tato metoda vyhodnotí iterátor, dokud nevrátí [`None`].
    /// Přitom sleduje aktuální prvek.
    /// Po vrácení [`None`] vrátí `last()` poslední prvek, který viděl.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Posune iterátor o prvky `n`.
    ///
    /// Tato metoda bude dychtivě přeskakovat prvky `n` voláním [`next`] až `n` krát, dokud nenastane [`None`].
    ///
    /// `advance_by(n)` vrátí [`Ok(())`][Ok], pokud iterátor úspěšně postoupí o prvky `n`, nebo [`Err(k)`][Err], pokud dojde k [`None`], kde `k` je počet prvků, o které je iterátor posunut před vyčerpáním prvků (tj.
    /// délka iterátoru).
    /// Všimněte si, že `k` je vždy menší než `n`.
    ///
    /// Volání `advance_by(0)` nespotřebovává žádné prvky a vždy vrátí [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // pouze `&4` byl přeskočen
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Vrátí `n`-tý prvek iterátoru.
    ///
    /// Stejně jako většina operací indexování začíná počet od nuly, takže `nth(0)` vrátí první hodnotu, `nth(1)` druhou atd.
    ///
    /// Všimněte si, že všechny předchozí prvky, stejně jako vrácený prvek, budou spotřebovány z iterátoru.
    /// To znamená, že předchozí prvky budou zahozeny a také to, že volání `nth(0)` vícekrát na stejném iterátoru vrátí různé prvky.
    ///
    ///
    /// `nth()` vrátí [`None`], pokud je `n` větší nebo rovna délce iterátoru.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Volání `nth()` vícekrát iterátor nepřetočí zpět:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Vrácení `None`, pokud existuje méně než `n + 1` prvků:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Vytvoří iterátor začínající ve stejném bodě, ale krokující o danou částku při každé iteraci.
    ///
    /// Poznámka 1: První prvek iterátoru bude vždy vrácen, bez ohledu na daný krok.
    ///
    /// Poznámka 2: Čas, kdy jsou ignorované prvky vytaženy, není pevně stanoven.
    /// `StepBy` chová se jako sekvence `next(), nth(step-1), nth(step-1),…`, ale také se může chovat jako sekvence
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Který způsob se používá, se může u některých iterátorů z důvodu výkonu změnit.
    /// Druhý způsob posune iterátor dříve a může spotřebovat více položek.
    ///
    /// `advance_n_and_return_first` je ekvivalentem:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Metoda bude panic, pokud je daný krok `0`.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Vezme dva iterátory a vytvoří nový iterátor nad oběma v pořadí.
    ///
    /// `chain()` vrátí nový iterátor, který nejprve iteruje nad hodnotami z prvního iterátoru a poté nad hodnotami z druhého iterátoru.
    ///
    /// Jinými slovy, spojuje dva iterátory dohromady v řetězci.🔗
    ///
    /// [`once`] se běžně používá k přizpůsobení jedné hodnoty do řetězce jiných druhů iterací.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Protože argument pro `chain()` používá [`IntoIterator`], můžeme předat cokoli, co lze převést na [`Iterator`], nejen na samotný [`Iterator`].
    /// Například řezy (`&[T]`) implementují [`IntoIterator`], takže je lze předat přímo `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Pokud pracujete s Windows API, možná budete chtít převést [`OsStr`] na `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// " Zipuje` dva iterátory do jednoho iterátoru párů.
    ///
    /// `zip()` vrací nový iterátor, který bude iterovat přes dva další iterátory, vrací n-tici, kde první prvek pochází z prvního iterátoru, a druhý prvek pochází z druhého iterátoru.
    ///
    ///
    /// Jinými slovy, zipuje dva iterátory dohromady do jednoho.
    ///
    /// Pokud některý iterátor vrátí [`None`], [`next`] ze zipového iterátoru vrátí [`None`].
    /// Pokud první iterátor vrátí [`None`], `zip` dojde ke zkratu a `next` nebude volán na druhém iterátoru.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Protože argument pro `zip()` používá [`IntoIterator`], můžeme předat cokoli, co lze převést na [`Iterator`], nejen na samotný [`Iterator`].
    /// Například řezy (`&[T]`) implementují [`IntoIterator`], takže je lze předat přímo `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` se často používá ke zipování nekonečného iterátoru na konečný.
    /// Funguje to, protože konečný iterátor nakonec vrátí [`None`] a zakončí zip.Zipování pomocí `(0..)` může vypadat hodně jako [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Vytvoří nový iterátor, který umístí kopii `separator` mezi sousední položky původního iterátoru.
    ///
    /// V případě, že `separator` neimplementuje [`Clone`] nebo je třeba jej pokaždé vypočítat, použijte [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // První prvek z `a`.
    /// assert_eq!(a.next(), Some(&100)); // Oddělovač.
    /// assert_eq!(a.next(), Some(&1));   // Další prvek z `a`.
    /// assert_eq!(a.next(), Some(&100)); // Oddělovač.
    /// assert_eq!(a.next(), Some(&2));   // Poslední prvek z `a`.
    /// assert_eq!(a.next(), None);       // Iterátor je dokončen.
    /// ```
    ///
    /// `intersperse` může být velmi užitečné spojit položky iterátoru pomocí společného prvku:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Vytvoří nový iterátor, který umístí položku vygenerovanou `separator` mezi sousední položky původního iterátoru.
    ///
    /// Uzávěr bude volán přesně jednou pokaždé, když je položka umístěna mezi dvě sousední položky ze základního iterátoru;
    /// konkrétně uzávěrka není volána, pokud podkladový iterátor přináší méně než dvě položky a po získání poslední položky.
    ///
    ///
    /// Pokud položka iterátoru implementuje [`Clone`], může být jednodušší použít [`intersperse`].
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // První prvek z `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Oddělovač.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Další prvek z `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Oddělovač.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Poslední prvek z `v`.
    /// assert_eq!(it.next(), None);               // Iterátor je dokončen.
    /// ```
    ///
    /// `intersperse_with` lze použít v situacích, kdy je třeba vypočítat oddělovač:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Uzávěr si proměnlivě vypůjčí svůj kontext a vygeneruje položku.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Přijme uzavření a vytvoří iterátor, který volá toto uzavření u každého prvku.
    ///
    /// `map()` transformuje jeden iterátor na jiný pomocí svého argumentu:
    /// něco, co implementuje [`FnMut`].Produkuje nový iterátor, který volá toto uzavření na každém prvku původního iterátoru.
    ///
    /// Pokud umíte dobře myslet na typy, můžete na `map()` myslet takto:
    /// Pokud máte iterátor, který vám dává prvky nějakého typu `A`, a chcete iterátor nějakého jiného typu `B`, můžete použít `map()` a předat uzávěr, který vezme `A` a vrátí `B`.
    ///
    ///
    /// `map()` je koncepčně podobný smyčce [`for`].Jelikož je `map()` líný, je nejlepší jej použít, když už pracujete s jinými iterátory.
    /// Pokud provádíte nějaké smyčky pro vedlejší efekt, je považováno za idiomatičtější použít [`for`] než `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Pokud provádíte nějaký vedlejší účinek, upřednostňujte [`for`] až `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // nedělej to:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // nebude ani vykonán, protože je líný.Rust vás na to upozorní.
    ///
    /// // Místo toho použijte pro:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Volá uzavření u každého prvku iterátoru.
    ///
    /// To je ekvivalentní použití smyčky [`for`] na iterátoru, ačkoli `break` a `continue` nejsou možné z uzavření.
    /// Obecně je více idiomatické použít smyčku `for`, ale `for_each` může být čitelnější při zpracování položek na konci delších řetězců iterátorů.
    ///
    /// V některých případech může být `for_each` také rychlejší než smyčka, protože na adaptérech jako `Chain` bude používat interní iteraci.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// V tak malém příkladu může být smyčka `for` čistší, ale `for_each` může být vhodnější zachovat funkční styl s delšími iterátory:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Vytvoří iterátor, který pomocí uzávěru určí, zda má být prvek získán.
    ///
    /// Vzhledem k prvku musí uzávěr vrátit `true` nebo `false`.Vrácený iterátor přinese pouze prvky, pro které uzávěrka vrátí hodnotu true.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Protože uzávěr předaný `filter()` přebírá odkaz a mnoho iterátorů iteruje přes odkazy, vede to k možná matoucí situaci, kdy je typ uzávěru dvojitým odkazem:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // potřebujete dva * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Je běžné místo toho použít destrukci argumentu k odstranění jednoho:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // oba&a *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// nebo oboje:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // dva &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// těchto vrstev.
    ///
    /// Všimněte si, že `iter.filter(f).next()` je ekvivalentní `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Vytvoří iterátor, který filtruje i mapuje.
    ///
    /// Vrácený iterátor poskytuje pouze hodnoty, pro které dodaná uzávěrka vrací `Some(value)`.
    ///
    /// `filter_map` lze použít ke zkrácení řetězů [`filter`] a [`map`].
    /// Níže uvedený příklad ukazuje, jak lze `map().filter().map()` zkrátit na jedno volání `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tady je stejný příklad, ale s [`filter`] a [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Vytvoří iterátor, který dává aktuální počet iterací i další hodnotu.
    ///
    /// Iterátor vrátil výnosy párů `(i, val)`, kde `i` je aktuální index iterace a `val` je hodnota vrácená iterátorem.
    ///
    ///
    /// `enumerate()` udržuje svůj počet jako [`usize`].
    /// Pokud chcete počítat podle jiného velkého čísla, funkce [`zip`] poskytuje podobné funkce.
    ///
    /// # Chování při přetečení
    ///
    /// Metoda neprobíhá žádnou ochranu před přetečením, takže výčet více než [`usize::MAX`] prvků způsobí nesprávný výsledek nebo panics.
    /// Pokud jsou povolena tvrzení ladění, je zaručen panic.
    ///
    /// # Panics
    ///
    /// Vrácený iterátor by mohl panic, pokud by index, který se má vrátit, přetekl [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Vytvoří iterátor, který může pomocí [`peek`] sledovat další prvek iterátoru bez jeho konzumace.
    ///
    /// Přidá metodu [`peek`] do iterátoru.Další informace najdete v jeho dokumentaci.
    ///
    /// Všimněte si, že podkladový iterátor je stále pokročilý, když se [`peek`] volá poprvé: Za účelem načtení dalšího prvku se [`next`] volá na podkladovém iterátoru, tedy jakékoli vedlejší účinky (tj.
    ///
    /// dojde k něčemu jinému než načtení další hodnoty) metody [`next`].
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() umožňuje nám nahlédnout do future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // můžeme peek() několikrát, iterátor nepostoupí
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // po dokončení iterátoru také peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Vytvoří iterátor, který [" přeskočí`] s prvky na základě predikátu.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` bere uzavření jako argument.Zavolá toto uzavření na každém prvku iterátoru a prvky bude ignorovat, dokud nevrátí `false`.
    ///
    /// Po vrácení `false` je úloha `skip_while()`'s ukončena a zbytek prvků je získán.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Protože uzávěr předaný `skip_while()` přebírá odkaz a mnoho iterátorů iteruje přes odkazy, vede to k možná matoucí situaci, kdy je typ uzávěrového argumentu dvojitý odkaz:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // potřebujete dva * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Zastavení po počátečním `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // i když by to bylo falešné, protože už jsme dostali faleš, skip_while() se již nepoužívá
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Vytvoří iterátor, který získá prvky na základě predikátu.
    ///
    /// `take_while()` bere uzavření jako argument.Zavolá toto uzavření na každém prvku iterátoru a získá prvky, zatímco vrátí `true`.
    ///
    /// Po vrácení `false` je úloha `take_while()`'s ukončena a ostatní prvky jsou ignorovány.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Protože uzávěr předaný `take_while()` přebírá odkaz a mnoho iterátorů iteruje přes odkazy, vede to k možná matoucí situaci, kdy je typ uzávěru dvojitým odkazem:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // potřebujete dva * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Zastavení po počátečním `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Máme více prvků, které jsou menší než nula, ale protože jsme již dostali false, take_while() se už nepoužívá
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Protože `take_while()` se musí podívat na hodnotu, aby zjistil, zda by měla být zahrnuta nebo ne, náročné iterátory uvidí, že je odstraněna:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` tam už není, protože byl spotřebován, aby se zjistilo, zda by se iterace měla zastavit, ale nebyl umístěn zpět do iterátoru.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Vytvoří iterátor, který poskytuje prvky na základě predikátu a map.
    ///
    /// `map_while()` bere uzavření jako argument.
    /// Zavolá toto uzavření na každém prvku iterátoru a získá prvky, zatímco vrátí [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tady je stejný příklad, ale s [`take_while`] a [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Zastavení po počátečním [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Máme více prvků, které se vešly do u32 (4, 5), ale `map_while` vrátil `None` pro `-3` (protože `predicate` vrátil `None`) a `collect` se zastaví při prvním setkání s `None`.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Protože `map_while()` se musí podívat na hodnotu, aby zjistil, zda by měla být zahrnuta nebo ne, náročné iterátory uvidí, že je odstraněna:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` tam už není, protože byl spotřebován, aby se zjistilo, zda by se iterace měla zastavit, ale nebyl umístěn zpět do iterátoru.
    ///
    /// Všimněte si, že na rozdíl od [`take_while`] není tento iterátor **fúzován**.
    /// Rovněž není zadáno, co tento iterátor vrátí po vrácení prvního [`None`].
    /// Pokud potřebujete fúzovaný iterátor, použijte [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Vytvoří iterátor, který přeskočí první prvky `n`.
    ///
    /// Poté, co byly spotřebovány, jsou získány ostatní prvky.
    /// Spíše než přímo přepsat tuto metodu, místo toho přepsat metodu `nth`.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Vytvoří iterátor, který získá své první prvky `n`.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` se často používá s nekonečným iterátorem, aby byl konečný:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Pokud je k dispozici méně než `n` prvků, `take` se omezí na velikost podkladového iterátoru:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Adaptér iterátoru podobný [`fold`], který obsahuje vnitřní stav a vytváří nový iterátor.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` bere dva argumenty: počáteční hodnotu, která osazuje vnitřní stav, a uzavření se dvěma argumenty, z nichž první je proměnlivý odkaz na vnitřní stav a druhý iterátorový prvek.
    ///
    /// Uzávěr lze přiřadit k internímu stavu a sdílet stav mezi iteracemi.
    ///
    /// Při iteraci se uzavření použije na každý prvek iterátoru a iterátor získá návratovou hodnotu z uzavření, [`Option`].
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // každou iteraci vynásobíme stav prvkem
    ///     *state = *state * x;
    ///
    ///     // pak získáme negaci státu
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Vytvoří iterátor, který funguje jako mapa, ale zploští vnořenou strukturu.
    ///
    /// Adaptér [`map`] je velmi užitečný, ale pouze v případě, že argument uzavření vytváří hodnoty.
    /// Pokud místo toho vytvoří iterátor, existuje další vrstva nepřímo.
    /// `flat_map()` odstraní tuto další vrstvu samostatně.
    ///
    /// Můžete si představit `flat_map(f)` jako sémantický ekvivalent [[map`]] pingu a poté [" zploštit`] jako v `map(f).flatten()`.
    ///
    /// Další způsob uvažování o `flat_map()`: Uzávěr [`map`]] vrací jednu položku pro každý prvek a uzávěr `flat_map()`'s vrací iterátor pro každý prvek.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() vrací iterátor
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Vytvoří iterátor, který zploští vnořenou strukturu.
    ///
    /// To je užitečné, pokud máte iterátor iterátorů nebo iterátor věcí, které lze přeměnit na iterátory, a chcete odstranit jednu úroveň indirection.
    ///
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Mapování a následné zploštění:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() vrací iterátor
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Můžete to také přepsat z hlediska [`flat_map()`], což je v tomto případě výhodnější, protože jasněji vyjadřuje záměr:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() vrací iterátor
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Sloučení odstraní pouze jednu úroveň vnoření najednou:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Zde vidíme, že `flatten()` neprovádí "deep" zploštění.
    /// Místo toho je odstraněna pouze jedna úroveň vnoření.To znamená, že pokud `flatten()` vytvoříte trojrozměrné pole, bude výsledek dvojrozměrný a nikoli jednorozměrný.
    /// Chcete-li získat jednorozměrnou strukturu, musíte znovu provést `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Vytvoří iterátor, který končí po prvním [`None`].
    ///
    /// Poté, co iterátor vrátí [`None`], volání future mohou nebo nemusí [`Some(T)`] znovu přinést.
    /// `fuse()` upraví iterátor a zajistí, že po zadání [`None`] bude vždy navracet [`None`] navždy.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// // iterátor, který střídá Some a None
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // pokud je sudý, Some(i32), jinak Žádný
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // můžeme vidět náš iterátor chodit tam a zpět
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // jakmile to však spojíme ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // vždy vrátí `None` po prvním spuštění.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Udělá něco s každým prvkem iterátoru a předá hodnotu dál.
    ///
    /// Při použití iterátorů často několik z nich spojíte dohromady.
    /// Při práci na takovém kódu možná budete chtít zkontrolovat, co se děje v různých částech kanálu.Chcete-li to provést, vložte volání `inspect()`.
    ///
    /// Je běžnější, aby se `inspect()` používalo jako nástroj pro ladění, než aby existoval ve vašem konečném kódu, ale aplikace mohou považovat za užitečné v určitých situacích, kdy je třeba protokolovat chyby před vyřazením.
    ///
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // tato sekvence iterátoru je složitá.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // přidejme několik volání inspect(), abychom zjistili, co se děje
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Vytiskne se:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Chyby protokolování před jejich vyřazením:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Vytiskne se:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Vypůjčí si iterátor, místo aby ho konzumoval.
    ///
    /// To je užitečné pro povolení použití adaptérů iterátoru při zachování vlastnictví původního iterátoru.
    ///
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // pokud se pokusíme iter použít znovu, nebude to fungovat.
    /// // Následující řádek udává " chybu: použití přesunuté hodnoty: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // zkusme to znovu
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // místo toho přidáme .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // teď je to v pořádku:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Transformuje iterátor na kolekci.
    ///
    /// `collect()` může vzít cokoli iterovatelného a proměnit to v relevantní kolekci.
    /// Jedná se o jednu z výkonnějších metod ve standardní knihovně, která se používá v různých kontextech.
    ///
    /// Nejzákladnějším vzorem, ve kterém se `collect()` používá, je přeměna jedné kolekce na druhou.
    /// Vezmete sbírku, zavoláte na ni [`iter`], provedete spoustu transformací a na konci `collect()`.
    ///
    /// `collect()` může také vytvářet instance typů, které nejsou typickými kolekcemi.
    /// Například [`String`] lze sestavit z [`char`] s a iterátor [`Result<T, E>`][`Result`] položek lze shromáždit do `Result<Collection<T>, E>`.
    ///
    /// Další příklady najdete níže.
    ///
    /// Protože `collect()` je tak obecný, může způsobit problémy s odvozením typu.
    /// Jako takový je `collect()` jedním z mála okamžiků, kdy uvidíte syntaxi láskyplně známou jako 'turbofish': `::<>`.
    /// To pomáhá inferenčnímu algoritmu přesně pochopit, do které kolekce se pokoušíte shromažďovat.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Všimněte si, že jsme potřebovali `: Vec<i32>` na levé straně.Je to proto, že bychom místo toho mohli shromažďovat například do [`VecDeque<T>`]:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Použití 'turbofish' místo anotování `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Vzhledem k tomu, že `collect()` se stará pouze o to, do čeho sbíráte, můžete s turbofishem stále používat částečnou nápovědu typu `_`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Použití `collect()` k vytvoření [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Pokud máte seznam [`Výsledek<T, E>`][`Výsledek`] s, můžete pomocí `collect()` zjistit, zda některý z nich selhal:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // dává nám první chybu
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // dává nám seznam odpovědí
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Spotřebuje iterátor a vytvoří z něj dvě kolekce.
    ///
    /// Predikát předaný `partition()` může vrátit `true` nebo `false`.
    /// `partition()` vrátí pár, všechny prvky, pro které vrátil `true`, a všechny prvky, pro které vrátil `false`.
    ///
    ///
    /// Viz také [`is_partitioned()`] a [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Změní pořadí prvků tohoto iterátoru *na místě* podle daného predikátu, takže všechny ty, které vracejí `true`, předcházejí všechny ty, které vracejí `false`.
    ///
    /// Vrátí počet nalezených prvků `true`.
    ///
    /// Relativní pořadí rozdělených položek není udržováno.
    ///
    /// Viz také [`is_partitioned()`] a [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Rozdělte na místo mezi rovnostmi a pravděpodobností
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: měli bychom si dělat starosti s přetékáním počtu?Jediný způsob, jak mít více než
        // `usize::MAX` proměnlivé odkazy jsou u ZST, které nejsou užitečné pro rozdělení ...

        // Tyto uzavírací funkce "factory" existují, aby se zabránilo obecnosti v `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Opakovaně najděte první `false` a vyměňte jej za poslední `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Zkontroluje, zda jsou prvky tohoto iterátoru rozděleny podle daného predikátu, takže všechny ty, které vracejí `true`, předcházejí všechny ty, které vracejí `false`.
    ///
    ///
    /// Viz také [`partition()`] a [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Buď všechny položky otestují `true`, nebo se první klauzule zastaví na `false` a my zkontrolujeme, že po tom už nebudou žádné další položky `true`.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Metoda iterátoru, která aplikuje funkci, pokud se vrací úspěšně, čímž vytvoří jednu konečnou hodnotu.
    ///
    /// `try_fold()` trvá dva argumenty: počáteční hodnotu a uzavření se dvěma argumenty: 'accumulator' a element.
    /// Uzávěr se buď vrací úspěšně, s hodnotou, kterou by měl akumulátor mít pro další iteraci, nebo vrací selhání, s chybovou hodnotou, která se šíří zpět volajícímu okamžitě (short-circuiting).
    ///
    ///
    /// Počáteční hodnota je hodnota, kterou bude mít akumulátor při prvním volání.Pokud použití uzavření proběhlo úspěšně proti každému prvku iterátoru, vrátí `try_fold()` konečný akumulátor jako úspěch.
    ///
    /// Skládání je užitečné, kdykoli máte sbírku něčeho a chcete z ní vyprodukovat jedinou hodnotu.
    ///
    /// # Poznámka pro implementátory
    ///
    /// Několik dalších metod (forward) má výchozí implementace, pokud jde o tuto, takže se pokuste implementovat to explicitně, pokud to může udělat něco lepšího než výchozí implementace smyčky `for`.
    ///
    /// Zejména se pokuste mít toto volání `try_fold()` na vnitřních částech, ze kterých je tento iterátor složen.
    /// Pokud je potřeba více hovorů, může být operátor `?` vhodný pro zřetězení hodnoty akumulátoru, ale pozor na všechny invarianty, které je třeba před těmito časnými návraty potvrdit.
    /// Toto je metoda `&mut self`, takže iterace musí být obnovitelná po zasažení chyby zde.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // zkontrolovaný součet všech prvků pole
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Tento součet přetéká při přidání prvku 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Protože je zkratován, zbývající prvky jsou stále k dispozici prostřednictvím iterátoru.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Metoda iterátoru, která aplikuje omylnou funkci na každou položku v iterátoru, zastaví se při první chybě a vrátí tuto chybu.
    ///
    ///
    /// Lze to také považovat za omylnou formu [`for_each()`] nebo za bezstavovou verzi [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Zkratoval, takže zbývající položky jsou stále v iterátoru:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Složí každý prvek do akumulátoru pomocí operace a vrátí konečný výsledek.
    ///
    /// `fold()` trvá dva argumenty: počáteční hodnotu a uzavření se dvěma argumenty: 'accumulator' a element.
    /// Uzávěr vrací hodnotu, kterou by měl mít akumulátor pro další iteraci.
    ///
    /// Počáteční hodnota je hodnota, kterou bude mít akumulátor při prvním volání.
    ///
    /// Po použití tohoto uzávěru na každý prvek iterátoru vrátí `fold()` akumulátor.
    ///
    /// Tato operace se někdy nazývá 'reduce' nebo 'inject'.
    ///
    /// Skládání je užitečné, kdykoli máte sbírku něčeho a chcete z ní vyprodukovat jedinou hodnotu.
    ///
    /// Note: `fold()` a podobné metody, které procházejí celým iterátorem, nemusí být ukončeny pro nekonečné iterátory, dokonce ani pro traits, pro které je výsledek stanovitelný v konečném čase.
    ///
    /// Note: [`reduce()`] lze použít k použití prvního prvku jako počáteční hodnoty, pokud je typ akumulátoru a typ položky stejný.
    ///
    /// # Poznámka pro implementátory
    ///
    /// Několik dalších metod (forward) má výchozí implementace, pokud jde o tuto, takže se pokuste implementovat to explicitně, pokud to může udělat něco lepšího než výchozí implementace smyčky `for`.
    ///
    ///
    /// Zejména se pokuste mít toto volání `fold()` na vnitřních částech, ze kterých je tento iterátor složen.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // součet všech prvků pole
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Projdeme si zde každý krok iterace:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// A tak náš konečný výsledek, `6`.
    ///
    /// Je běžné, že lidé, kteří iterátory příliš nepoužívali, používají k vytvoření výsledku smyčku `for` se seznamem věcí.Ty lze přeměnit na `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // pro smyčku:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // jsou stejné
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Redukuje prvky na jeden opakovaným použitím redukční operace.
    ///
    /// Pokud je iterátor prázdný, vrátí [`None`];v opačném případě vrátí výsledek redukce.
    ///
    /// U iterátorů s alespoň jedním prvkem je to stejné jako u [`fold()`] s prvním prvkem iterátoru jako počáteční hodnotou, skládáním do ní každý následující prvek.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Najděte maximální hodnotu:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Testuje, zda každý prvek iterátoru odpovídá predikátu.
    ///
    /// `all()` provede uzávěrku, která vrací `true` nebo `false`.Aplikuje toto uzavření na každý prvek iterátoru, a pokud všechny vrátí `true`, pak také `all()`.
    /// Pokud některý z nich vrátí `false`, vrátí `false`.
    ///
    /// `all()` je zkratovaný;jinými slovy, zastaví zpracování, jakmile najde `false`, protože bez ohledu na to, co se ještě stane, bude výsledkem také `false`.
    ///
    ///
    /// Prázdný iterátor vrátí `true`.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Zastavení na první `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // stále můžeme použít `iter`, protože prvků je více.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Testuje, zda některý prvek iterátoru odpovídá predikátu.
    ///
    /// `any()` provede uzávěrku, která vrací `true` nebo `false`.Aplikuje toto uzavření na každý prvek iterátoru, a pokud některý z nich vrátí `true`, pak také `any()`.
    /// Pokud všichni vrátí `false`, vrátí `false`.
    ///
    /// `any()` je zkratovaný;jinými slovy, zastaví zpracování, jakmile najde `true`, protože bez ohledu na to, co se ještě stane, bude výsledkem také `true`.
    ///
    ///
    /// Prázdný iterátor vrátí `false`.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Zastavení na první `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // stále můžeme použít `iter`, protože prvků je více.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Vyhledá prvek iterátoru, který splňuje predikát.
    ///
    /// `find()` provede uzávěrku, která vrací `true` nebo `false`.
    /// Aplikuje toto uzavření na každý prvek iterátoru, a pokud některý z nich vrátí `true`, pak `find()` vrátí [`Some(element)`].
    /// Pokud všichni vrátí `false`, vrátí [`None`].
    ///
    /// `find()` je zkratovaný;jinými slovy, zastaví zpracování, jakmile uzávěrka vrátí `true`.
    ///
    /// Protože `find()` přebírá odkaz a mnoho iterátorů iteruje přes odkazy, vede to k možná matoucí situaci, kdy je argument dvojitým odkazem.
    ///
    /// Tento efekt můžete vidět v příkladech níže s `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Zastavení na první `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // stále můžeme použít `iter`, protože prvků je více.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Všimněte si, že `iter.find(f)` je ekvivalentní `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Aplikuje funkci na prvky iterátoru a vrací první non-none výsledek.
    ///
    ///
    /// `iter.find_map(f)` odpovídá `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Aplikuje funkci na prvky iterátoru a vrátí první skutečný výsledek nebo první chybu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Vyhledá prvek v iterátoru a vrátí jeho index.
    ///
    /// `position()` provede uzávěrku, která vrací `true` nebo `false`.
    /// Aplikuje toto uzavření na každý prvek iterátoru, a pokud jeden z nich vrátí `true`, pak `position()` vrátí [`Some(index)`].
    /// Pokud všechny vrátí `false`, vrátí [`None`].
    ///
    /// `position()` je zkratovaný;jinými slovy, přestane zpracovávat, jakmile najde `true`.
    ///
    /// # Chování při přetečení
    ///
    /// Metoda neprovádí žádnou ochranu před přetečením, takže pokud existuje více než [`usize::MAX`] neodpovídajících prvků, vytvoří buď nesprávný výsledek, nebo panics.
    ///
    /// Pokud jsou povolena tvrzení ladění, je zaručen panic.
    ///
    /// # Panics
    ///
    /// Tato funkce může panic, pokud má iterátor více než `usize::MAX` neodpovídajících prvků.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Zastavení na první `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // stále můžeme použít `iter`, protože prvků je více.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Vrácený index závisí na stavu iterátoru
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Vyhledá prvek v iterátoru zprava a vrátí jeho index.
    ///
    /// `rposition()` provede uzávěrku, která vrací `true` nebo `false`.
    /// Aplikuje toto uzavření na každý prvek iterátoru, počínaje od konce, a pokud jeden z nich vrátí `true`, pak `rposition()` vrátí [`Some(index)`].
    ///
    /// Pokud všechny vrátí `false`, vrátí [`None`].
    ///
    /// `rposition()` je zkratovaný;jinými slovy, přestane zpracovávat, jakmile najde `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Zastavení na první `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // stále můžeme použít `iter`, protože prvků je více.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Zde není potřeba kontrola přetečení, protože `ExactSizeIterator` znamená, že počet prvků zapadá do `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Vrátí maximální prvek iterátoru.
    ///
    /// Pokud je několik prvků stejně maximálních, vrátí se poslední prvek.
    /// Pokud je iterátor prázdný, vrátí se [`None`].
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Vrátí minimální prvek iterátoru.
    ///
    /// Pokud je několik prvků stejně minimální, vrátí se první prvek.
    /// Pokud je iterátor prázdný, vrátí se [`None`].
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Vrátí prvek, který dává maximální hodnotu ze zadané funkce.
    ///
    ///
    /// Pokud je několik prvků stejně maximálních, vrátí se poslední prvek.
    /// Pokud je iterátor prázdný, vrátí se [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Vrátí prvek, který dává maximální hodnotu vzhledem k zadané srovnávací funkci.
    ///
    ///
    /// Pokud je několik prvků stejně maximálních, vrátí se poslední prvek.
    /// Pokud je iterátor prázdný, vrátí se [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Vrátí prvek, který dává minimální hodnotu ze zadané funkce.
    ///
    ///
    /// Pokud je několik prvků stejně minimální, vrátí se první prvek.
    /// Pokud je iterátor prázdný, vrátí se [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Vrátí prvek, který dává minimální hodnotu vzhledem k zadané srovnávací funkci.
    ///
    ///
    /// Pokud je několik prvků stejně minimální, vrátí se první prvek.
    /// Pokud je iterátor prázdný, vrátí se [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Obrátí směr iterátoru.
    ///
    /// Iterátory obvykle iterují zleva doprava.
    /// Po použití `rev()` bude iterátor místo toho iterovat zprava doleva.
    ///
    /// To je možné pouze v případě, že iterátor má konec, takže `rev()` funguje pouze na [" DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Převede iterátor párů na pár kontejnerů.
    ///
    /// `unzip()` spotřebuje celý iterátor párů a vytvoří dvě kolekce: jednu z levých prvků dvojic a jednu z pravých prvků.
    ///
    ///
    /// Tato funkce je v určitém smyslu opakem [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Vytvoří iterátor, který kopíruje všechny jeho prvky.
    ///
    /// To je užitečné, pokud máte iterátor přes `&T`, ale potřebujete iterátor přes `T`.
    ///
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // zkopírováno je stejné jako .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Vytvoří iterátor, který [klonuje] všechny jeho prvky.
    ///
    /// To je užitečné, pokud máte iterátor přes `&T`, ale potřebujete iterátor přes `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // klonovaný je stejný jako .map(|&x| x), pro celá čísla
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Opakuje iterátor do nekonečna.
    ///
    /// Místo zastavení na [`None`] se iterátor místo toho začne znovu, od začátku.Po opětovném iteraci začne znovu na začátku.A znovu.
    /// A znovu.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Shrnuje prvky iterátoru.
    ///
    /// Vezme každý prvek, sečte je a vrátí výsledek.
    ///
    /// Prázdný iterátor vrací nulovou hodnotu typu.
    ///
    /// # Panics
    ///
    /// Při volání `sum()` a je vrácen primitivní celočíselný typ, tato metoda bude panic, pokud dojde k přetečení výpočtu a jsou povolena tvrzení ladění.
    ///
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iteruje po celém iterátoru a vynásobí všechny prvky
    ///
    /// Prázdný iterátor vrátí jednu hodnotu typu.
    ///
    /// # Panics
    ///
    /// Při volání `product()` a je vrácen primitivní celočíselný typ, metoda bude panic, pokud dojde k přetečení výpočtu a jsou povolena tvrzení ladění.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) porovnává prvky tohoto [`Iterator`] s prvky jiného.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) porovnává prvky tohoto [`Iterator`] s prvky jiného s ohledem na zadanou srovnávací funkci.
    ///
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) porovnává prvky tohoto [`Iterator`] s prvky jiného.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) porovnává prvky tohoto [`Iterator`] s prvky jiného s ohledem na zadanou srovnávací funkci.
    ///
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Určuje, zda jsou prvky tohoto [`Iterator`] stejné jako prvky jiného.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Určuje, zda jsou prvky tohoto [`Iterator`] stejné jako prvky jiného s ohledem na zadanou funkci rovnosti.
    ///
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Určuje, zda jsou prvky tohoto [`Iterator`] nerovné s prvky jiného.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Určuje, zda jsou prvky tohoto [`Iterator`] o [lexicographically](Ord#lexicographical-comparison) menší než prvky jiného.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Určuje, zda prvky tohoto [`Iterator`] jsou [lexicographically](Ord#lexicographical-comparison) menší nebo stejné jako prvky jiného.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Určuje, zda jsou prvky tohoto [`Iterator`] o [lexicographically](Ord#lexicographical-comparison) větší než prvky jiného.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Určuje, zda prvky tohoto [`Iterator`] jsou [lexicographically](Ord#lexicographical-comparison) větší nebo stejné jako prvky jiného.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Zkontroluje, zda jsou tříděny prvky tohoto iterátoru.
    ///
    /// To znamená, že pro každý prvek `a` a jeho následující prvek `b` musí `a <= b` platit.Pokud iterátor získá přesně nulu nebo jeden prvek, vrátí se `true`.
    ///
    /// Všimněte si, že pokud `Self::Item` je pouze `PartialOrd`, ale ne `Ord`, výše uvedená definice znamená, že tato funkce vrací `false`, pokud nejsou dvě po sobě jdoucí položky srovnatelné.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Zkontroluje, zda jsou prvky tohoto iterátoru tříděny pomocí dané funkce komparátoru.
    ///
    /// Namísto použití `PartialOrd::partial_cmp` tato funkce používá danou funkci `compare` k určení pořadí dvou prvků.
    /// Kromě toho je to ekvivalent [`is_sorted`];další informace najdete v jeho dokumentaci.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Zkontroluje, zda jsou prvky tohoto iterátoru tříděny pomocí dané funkce extrakce klíčů.
    ///
    /// Namísto přímého porovnání prvků iterátoru tato funkce porovnává klíče prvků, jak je určeno `f`.
    /// Kromě toho je to ekvivalent [`is_sorted`];další informace najdete v jeho dokumentaci.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Viz [TrustedRandomAccess]
    // Nezvyklý název je vyhnout se kolizím jmen v rozlišení metody, viz #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}