use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Tento trait poskytuje tranzitivní přístup do zdrojové fáze v potrubí interator-adaptér za podmínek, které
/// * zdroj iterátoru `S` sám implementuje `SourceIter<Source = S>`
/// * existuje delegující implementace tohoto trait pro každý adaptér v potrubí mezi zdrojem a spotřebitelem kanálu.
///
/// Pokud je zdrojem vlastní iterátorová struktura (běžně se nazývá `IntoIter`), může to být užitečné pro specializaci implementací [`FromIterator`] nebo pro obnovení zbývajících prvků po částečném vyčerpání iterátoru.
///
///
/// Všimněte si, že implementace nemusí nutně poskytovat přístup k nejvnitřnějšímu zdroji kanálu.Stavový mezilehlý adaptér může dychtivě vyhodnotit část kanálu a vystavit své vnitřní úložiště jako zdroj.
///
/// trait není bezpečný, protože implementátoři musí dodržovat další bezpečnostní vlastnosti.
/// Podrobnosti viz [`as_inner`].
///
/// # Examples
///
/// Načítání částečně spotřebovaného zdroje:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Fáze zdroje v potrubí iterátoru.
    type Source: Iterator;

    /// Načíst zdroj kanálu iterátoru.
    ///
    /// # Safety
    ///
    /// Implementace musí po celou dobu jejich životnosti vrátit stejný proměnlivý odkaz, pokud není nahrazen volajícím.
    /// Volající mohou smět nahradit odkaz pouze v případě, že zastavili iteraci a po extrahování zdroje zruší iterátorový kanál.
    ///
    /// To znamená, že adaptéry iterátoru se mohou spoléhat na to, že se zdroj během iterace nezmění, ale nemohou se na něj spolehnout ve svých implementacích Drop.
    ///
    /// Implementace této metody znamená, že se adaptéry vzdají pouze soukromého přístupu ke svému zdroji a mohou se spolehnout pouze na záruky poskytnuté na základě typů přijímačů metod.
    /// Nedostatek omezeného přístupu také vyžaduje, aby adaptéry musely udržovat veřejné API zdroje, i když mají přístup k jeho interním funkcím.
    ///
    /// Volající zase musí očekávat, že zdroj bude v jakémkoli stavu, který je v souladu s jeho veřejným API, protože adaptéry sedící mezi ním a zdrojem mají stejný přístup.
    /// Zejména adaptér může spotřebovat více prvků, než je nezbytně nutné.
    ///
    /// Celkovým cílem těchto požadavků je umožnit spotřebiteli potrubí používat
    /// * cokoli zůstane ve zdroji po zastavení iterace
    /// * paměť, která se stala nevyužitou postupováním náročného iterátoru
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Adaptér iterátoru, který produkuje výstup, pokud podkladový iterátor produkuje hodnoty `Result::Ok`.
///
///
/// Pokud dojde k chybě, iterátor se zastaví a chyba se uloží.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Zpracujte daný iterátor, jako by místo `Result<T, _>` získal `T`.
/// Jakékoli chyby zastaví vnitřní iterátor a celkovým výsledkem bude chyba.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}