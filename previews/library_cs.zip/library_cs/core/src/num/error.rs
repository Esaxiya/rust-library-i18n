//! Typy chyb pro převod na integrální typy.

use crate::convert::Infallible;
use crate::fmt;

/// Typ chyby se vrátil, když se nepovede převod kontrolovaného integrálního typu.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Spárujte se spíše než vynucujte, abyste se ujistili, že kód jako `From<Infallible> for TryFromIntError` výše bude fungovat, i když se `Infallible` stane aliasem pro `!`.
        //
        //
        match never {}
    }
}

/// Chyba, kterou lze vrátit při analýze celého čísla.
///
/// Tato chyba se používá jako typ chyby pro funkce `from_str_radix()` na primitivních celočíselných typech, jako je [`i8::from_str_radix`].
///
/// # Možné příčiny
///
/// Mezi další příčiny může být `ParseIntError` vyvolána z důvodu vedení nebo koncové mezery v řetězci, např. Když je získána ze standardního vstupu.
///
/// Použití metody [`str::trim()`] zajistí, že před analýzou nezůstanou žádné mezery.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Výčet pro uložení různých typů chyb, které mohou způsobit selhání analýzy celého čísla.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Analyzovaná hodnota je prázdná.
    ///
    /// Mimo jiné bude tato varianta vytvořena při analýze prázdného řetězce.
    Empty,
    /// Obsahuje neplatnou číslici v jejím kontextu.
    ///
    /// Mezi další příčiny bude tato varianta vytvořena při analýze řetězce, který obsahuje znak jiný než ASCII.
    ///
    /// Tato varianta je také konstruována, když je `+` nebo `-` ztraceno v řetězci buď samostatně, nebo uprostřed čísla.
    ///
    ///
    InvalidDigit,
    /// Celé číslo je příliš velké na uložení v cílovém typu celého čísla.
    PosOverflow,
    /// Celé číslo je příliš malé na uložení v cílovém typu celého čísla.
    NegOverflow,
    /// Hodnota byla nula
    ///
    /// Tato varianta bude vydána, když má syntaktický řetězec hodnotu nula, což by bylo pro nenulové typy nelegální.
    ///
    Zero,
}

impl ParseIntError {
    /// Vypíše podrobnou příčinu analýzy celého čísla, které selhalo.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}