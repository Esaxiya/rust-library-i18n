//! Bitová bitva na kladných plovácích IEEE 754.Záporná čísla nejsou a nemusí být zpracována.
//! Normální čísla s plovoucí desetinnou čárkou mají kanonickou reprezentaci jako (frac, exp), takže hodnota je 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)), kde N je počet bitů.
//!
//! Subnormály jsou mírně odlišné a divné, ale platí stejný princip.
//!
//! Zde je však reprezentujeme jako (sig, k) s f kladem, takže hodnota je f *
//! 2 <sup>e</sup> .Kromě toho, že je "hidden bit" explicitní, mění se exponent takzvaným posunem mantisy.
//!
//! Jinými slovy, normálně jsou plováky zapsány jako (1), ale zde jsou zapsány jako (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Nazýváme (1)**zlomkovou reprezentaci** a (2)**integrální reprezentaci**.
//!
//! Mnoho funkcí v tomto modulu zpracovává pouze normální čísla.Rutiny dec2flt konzervativně využívají univerzálně správnou pomalou cestu (Algoritmus M) pro velmi malá a velmi velká čísla.
//! Tento algoritmus potřebuje pouze next_float(), který zpracovává podnormály a nuly.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Pomocný nástroj trait, aby se zabránilo duplikování v podstatě všech konverzních kódů pro `f32` a `f64`.
///
/// Proč je to nutné, přečtěte si komentář k nadřazenému modulu.
///
/// Mělo by být **nikdy** implementováno pro jiné typy nebo použito mimo modul dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Typ používaný `to_bits` a `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Provede surovou transmutaci na celé číslo.
    fn to_bits(self) -> Self::Bits;

    /// Provede surovou transmutaci z celého čísla.
    fn from_bits(v: Self::Bits) -> Self;

    /// Vrátí kategorii, do které toto číslo spadá.
    fn classify(self) -> FpCategory;

    /// Vrátí mantisu, exponent a znaménko jako celá čísla.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Dekóduje plovák.
    fn unpack(self) -> Unpacked;

    /// Vrhá z malého celého čísla, které lze přesně reprezentovat.
    /// Panic pokud celé číslo nelze reprezentovat, další kód v tomto modulu zajistí, že se to nikdy nestane.
    fn from_int(x: u64) -> Self;

    /// Získá hodnotu 10 <sup>e</sup> z předem vypočítané tabulky.
    /// Panics pro `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Co říká název.
    /// Je snazší tvrdě kódovat, než žonglovat s vnitřní podstatou a doufat, že to konstanta LLVM složí.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Konzervativní vazba na desítkové číslice vstupů, které nemohou způsobit přetečení nebo nulu nebo
    /// podnormality.Pravděpodobně desetinný exponent maximální normální hodnoty, odtud název.
    const MAX_NORMAL_DIGITS: usize;

    /// Když má nejvýznamnější desetinná číslice hodnotu místa větší než toto, je číslo jistě zaokrouhleno na nekonečno.
    ///
    const INF_CUTOFF: i64;

    /// Pokud má nejvýznamnější desetinná číslice hodnotu místa menší než toto, je číslo jistě zaokrouhleno na nulu.
    ///
    const ZERO_CUTOFF: i64;

    /// Počet bitů v exponentu.
    const EXP_BITS: u8;

    /// Počet bitů v mantinele,*včetně* skrytého bitu.
    const SIG_BITS: u8;

    /// Počet bitů v znaménku,*kromě* skrytého bitu.
    const EXPLICIT_SIG_BITS: u8;

    /// Maximální právní exponent ve zlomkovém vyjádření.
    const MAX_EXP: i16;

    /// Minimální legální exponent ve zlomkovém vyjádření, s výjimkou podnormálních hodnot.
    const MIN_EXP: i16;

    /// `MAX_EXP` pro integrální reprezentaci, tj. s použitým posunem.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` kódovaný (tj. s odchylkou posunutí)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` pro integrální reprezentaci, tj. s použitým posunem.
    const MIN_EXP_INT: i16;

    /// Maximální normalizovaný význam v integrálním vyjádření.
    const MAX_SIG: u64;

    /// Minimální normalizovaný význam v integrálním vyjádření.
    const MIN_SIG: u64;
}

// Většinou řešení pro #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Vrátí mantisu, exponent a znaménko jako celá čísla.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Posun exponentu + posun mantisy
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe si není jistý, zda `as` správně zaokrouhluje na všech platformách.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Vrátí mantisu, exponent a znaménko jako celá čísla.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Posun exponentu + posun mantisy
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe si není jistý, zda `as` správně zaokrouhluje na všech platformách.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Převede `Fp` na nejbližší plovoucí typ stroje.
/// Nezpracovává podnormální výsledky.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f je 64 bitů, takže xe má posun mantisy 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Zaokrouhlete 64bitový význam na bity T::SIG_BITS s polovičním vyrovnáním.
/// Nezpracovává přetečení exponentů.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Upravte posun mantisy
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Inverzní hodnota `RawFloat::unpack()` pro normalizovaná čísla.
/// Panics, pokud význam nebo exponent nejsou platné pro normalizovaná čísla.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Odstraňte skrytý bit
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Upravte exponent pro zkreslení exponentu a posun mantisy
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Ponechte znaménkový bit na 0 ("+"), naše čísla jsou kladná
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Vytvořte podnormální.Mantisa 0 je povolena a konstruuje nulu.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Zakódovaný exponent je 0, znaménkový bit je 0, takže musíme jen reinterpretovat bity.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Přibližně bignum s Fp.Zaokrouhlí se na 0.5 ULP s polovičním vyrovnáním.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Ořezali jsme všechny bity před indexem `start`, tj. Efektivně jsme posunuli doprava o částku `start`, takže toto je také exponent, který potřebujeme.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Kolo (half-to-even) v závislosti na zkrácených bitech.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Najde největší číslo s plovoucí desetinnou čárkou striktně menší než argument.
/// Nezpracovává podnormality, nulu nebo podtečení exponentu.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Najděte nejmenší číslo s plovoucí desetinnou čárkou, které je striktně větší než argument.
// Tato operace je saturující, tj. next_float(inf) ==inf.
// Na rozdíl od většiny kódů v tomto modulu tato funkce zpracovává nulu, podnormality a nekonečna.
// Stejně jako všechny ostatní kódy zde však nepracuje s NaN a zápornými čísly.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // To se zdá být příliš dobré na to, aby to byla pravda, ale funguje to.
        // 0.0 je zakódováno jako slovo s nulovou hodnotou.Subnormály jsou 0x000m ... m, kde m je mantisa.
        // Zejména nejmenší subnormální je 0x0 ... 01 a největší je 0x000F ... F.
        // Nejmenší normální číslo je 0x0010 ... 0, takže funguje i tento rohový případ.
        // Pokud přírůstek přeteče mantisou, bit bitu zvýší exponent tak, jak chceme, a bity mantisy se stanou nulou.
        // Kvůli konvenci skrytých bitů je to také přesně to, co chceme!
        // Nakonec f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}