//! Obslužné funkce pro bignumy, které nedávají příliš smysl, aby se změnily v metody.

// FIXME Název tohoto modulu je trochu nešťastný, protože ostatní moduly také importují `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Vyzkoušejte, zda zkrácení všech bitů méně významných než `ones_place` zavádí relativní chybu menší, rovnou nebo větší než 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Pokud jsou všechny zbývající bity nulové, je to= 0.5 ULP, jinak> 0.5 Pokud už žádné bity nejsou (half_bit==0), vrátí se níže správně také Equal.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Převede řetězec ASCII obsahující pouze desetinná místa na `u64`.
///
/// Neprovádí kontroly přetečení nebo neplatných znaků, takže pokud si volající nedává pozor, je výsledek falešný a může panic (i když to nebude `unsafe`).
/// S prázdnými řetězci se navíc zachází jako s nulou.
/// Tato funkce existuje, protože
///
/// 1. použití `FromStr` na `&[u8]` vyžaduje `from_utf8_unchecked`, což je špatné, a
/// 2. Sestavování výsledků `integral.parse()` a `fractional.parse()` je složitější než celá tato funkce.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Převede řetězec ASCII číslic na bignum.
///
/// Stejně jako `from_str_unchecked` se tato funkce spoléhá na to, že analyzátor vymaže jiné číslice.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Rozbalí bignum na 64bitové celé číslo.Panics, pokud je číslo příliš velké.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Extrahuje řadu bitů.

/// Index 0 je nejméně významný bit a rozsah je jako obvykle napůl otevřený.
/// Panics, pokud je požádán o extrahování více bitů, než se vejde do návratového typu.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}