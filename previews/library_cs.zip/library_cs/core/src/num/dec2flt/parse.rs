//! Ověření a rozložení desetinného řetězce formuláře:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Jinými slovy, standardní syntaxe s plovoucí desetinnou čárkou, se dvěma výjimkami: Bez znaménka a bez manipulace s "inf" a "NaN".Řídí je funkce ovladače (super::dec2flt).
//!
//! I když je rozpoznávání platných vstupů relativně snadné, musí tento modul také odmítnout nespočet neplatných variant, nikdy panic, a provádět četné kontroly, na které ostatní moduly spoléhají, aby ne panic (nebo přetečení).
//!
//! Aby toho nebylo málo, vše, co se děje v jediném průchodu vstupem.
//! Při úpravách tedy buďte opatrní a zkontrolujte to u ostatních modulů.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Zajímavé části desetinného řetězce.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Desetinný exponent, který má zaručeně méně než 18 desetinných číslic.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Zkontroluje, zda je vstupním řetězcem platné číslo s plovoucí desetinnou čárkou, a pokud ano, vyhledejte integrální část, zlomkovou část a exponent v ní.
/// Nezpracovává značky.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Žádné číslice před 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Požadujeme alespoň jednu číslici před nebo za bodem.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Trailing haraburdí po zlomkové části
            }
        }
        _ => Invalid, // Trailing junk after first digit string
    }
}

/// Oddělí desetinná místa až po první neciferný znak.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Extrakce komponent a kontrola chyb.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Trailing junk after exponent
    }
    if number.is_empty() {
        return Invalid; // Prázdný exponent
    }
    // V tomto okamžiku určitě máme platný řetězec číslic.Může to být příliš dlouhé na to, aby se dal do `i64`, ale pokud je to tak obrovské, vstup je určitě nula nebo nekonečno.
    // Jelikož každá nula v desetinných číslicích upravuje exponent pouze o +/-1, při exp=10 ^ 18 by vstup musel být 17 exabyte (!) nul, aby se ještě vzdáleně přiblížil konečnému.
    //
    // Toto není přesně případ použití, kterému se musíme věnovat.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}