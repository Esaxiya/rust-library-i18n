//! Dekóduje hodnotu s plovoucí desetinnou čárkou na jednotlivé části a rozsahy chyb.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Dekódovaná konečná hodnota bez znaménka, takže:
///
/// - Původní hodnota se rovná `mant * 2^exp`.
///
/// - Jakékoli číslo od `(mant - minus)*2^exp` do `(mant + plus)* 2^exp` se zaokrouhlí na původní hodnotu.
/// Rozsah je zahrnut pouze v případě, že `inclusive` je `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Škálovaná mantisa.
    pub mant: u64,
    /// Dolní rozsah chyb.
    pub minus: u64,
    /// Horní rozsah chyb.
    pub plus: u64,
    /// Sdílený exponent v základně 2.
    pub exp: i16,
    /// Je pravda, když je rozsah chyb včetně.
    ///
    /// V IEEE 754 to platí, když byla původní mantisa sudá.
    pub inclusive: bool,
}

/// Dekódovaná nepodepsaná hodnota.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinity, ať už pozitivní nebo negativní.
    Infinite,
    /// Nula, pozitivní nebo negativní.
    Zero,
    /// Konečná čísla s dalšími dekódovanými poli.
    Finite(Decoded),
}

/// Typ s plovoucí desetinnou čárkou, který lze `dekódovat`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Minimální kladná normalizovaná hodnota.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Vrátí znaménko (true, když je záporné) a hodnotu `FullDecoded` z daného čísla s plovoucí desetinnou čárkou.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // sousedé: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode vždy zachovává exponent, takže mantisa je upravena pro subnormály.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // sousedé: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant, 1, exp)
                // kde maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // sousedé: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}