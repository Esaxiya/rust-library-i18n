//! Vlastní implementace čísla (bignum) s libovolnou přesností.
//!
//! Toto je navrženo tak, aby se zabránilo přidělení haldy na úkor paměti zásobníku.
//! Nejpoužívanější typ bignum, `Big32x40`, je omezen na 32 × 40=1280 bitů a bude trvat maximálně 160 bajtů paměti zásobníku.
//! To je víc než dost pro zpáteční všechny možné konečné hodnoty `f64`.
//!
//! V zásadě je možné mít více typů bignum pro různé vstupy, ale neděláme to, abychom se vyhnuli nafouknutí kódu.
//!
//! Každé bignum je stále sledováno pro skutečné využití, takže na tom normálně nezáleží.
//!

// Tento modul je pouze pro dec2flt a flt2dec a pouze veřejný kvůli koretestům.
// Není zamýšleno, aby byla kdykoli stabilizována.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// Aritmetické operace vyžadované bignumy.
pub trait FullOps: Sized {
    /// Vrátí `(carry', v')` tak, že `carry' * 2^W + v' = self + other + carry`, kde `W` je počet bitů v `Self`.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// Vrátí `(carry', v')` tak, že `carry'*2^W + v' = self* other + carry`, kde `W` je počet bitů v `Self`.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// Vrátí `(carry', v')` tak, že `carry'*2^W + v' = self* other + other2 + carry`, kde `W` je počet bitů v `Self`.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// Vrátí `(quo, rem)`, takže `borrow *2^W + self = quo* other + rem` a `0 <= rem < other`, kde `W` je počet bitů v `Self`.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // To nemůže přetéct;výstup je mezi `0` a `2 * 2^nbits - 1`.
                    // FIXME: optimalizuje to LLVM na ADC nebo podobně?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // To nemůže přetéct;
                    // výstup je mezi `0` a `2^nbits * (2^nbits - 1)`.
                    // FIXME: optimalizuje to LLVM na ADC nebo podobně?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // To nemůže přetéct;
                    // výstup je mezi `0` a `2^nbits * (2^nbits - 1)`.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // To nemůže přetéct;výstup je mezi `0` a `other * (2^nbits - 1)`.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // Povolení viz RFC #521.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// Tabulka mocnin 5 reprezentovatelných v číslicích.Konkrétně největší hodnota {u8, u16, u32}, která je silou pěti, plus odpovídající exponent.
/// Používá se v `mul_pow5`.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// Stack-associated arbitrary-precision (up to certain limit) integer.
        ///
        /// To je podpořeno polem s pevnou velikostí daného typu ("digit").
        /// I když pole není příliš velké (obvykle několik set bajtů), jeho bezohledné kopírování může mít za následek výkonnostní zásah.
        ///
        /// Záměrně to tedy není `Copy`.
        ///
        /// Všechny operace dostupné bignumům panic v případě přetečení.
        /// Volající je odpovědný za použití dostatečně velkých typů bignum.
        pub struct $name {
            /// Jeden plus posun k maximálnímu použitému "digit".
            /// To se nesnižuje, takže mějte na paměti výpočetní pořadí.
            /// `base[size..]` by měla být nula.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` představuje `a + b *2^W + c* 2^(2W) + ...`, kde `W` je počet bitů v typu číslice.
            base: [$ty; $n],
        }

        impl $name {
            /// Vytvoří bignum z jedné číslice.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// Vytvoří bignum z hodnoty `u64`.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// Vrátí interní číslice jako řez `[a, b, c, ...]`, takže číselná hodnota je `a + b *2^W + c* 2^(2W) + ...`, kde `W` je počet bitů v typu číslice.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// Vrátí `i`-tý bit, kde bit 0 je nejméně významný.
            /// Jinými slovy, bit o hmotnosti `2^i`.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// Vrátí `true`, pokud je bignum nula.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// Vrátí počet bitů potřebný k vyjádření této hodnoty.
            /// Všimněte si, že nula je považována za potřebnou 0 bitů.
            pub fn bit_length(&self) -> usize {
                // Přeskočte nejvýznamnější číslice, které jsou nulové.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // Neexistují nenulové číslice, tj. Číslo je nula.
                    return 0;
                }
                // To by mohlo být optimalizováno pomocí leading_zeros() a bitových posunů, ale to pravděpodobně nestojí za potíže.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// Přidá `other` k sobě a vrátí jeho vlastní proměnlivý odkaz.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// Odečte `other` od sebe a vrátí jeho vlastní proměnlivou referenci.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// Násobí se číslicí `other` a vrací svou vlastní proměnlivou referenci.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// Násobí se `2^bits` a vrátí svou vlastní proměnlivou referenci.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // posun o `digits * digitbits` bitů
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // posun o `bits` bitů
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. číslice] je nula, není třeba měnit
                }

                self.size = sz;
                self
            }

            /// Násobí se `5^e` a vrátí svou vlastní proměnlivou referenci.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // Na 2 ^ n je přesně n koncových nul a jedinou relevantní velikostí číslic jsou po sobě jdoucí mocniny dvou, takže je to vhodný index pro tabulku.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // Znásobte se s největším jednociferným výkonem co nejdéle ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... a zbytek dokončete.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// Vynásobí se číslem popsaným `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (kde `W` je počet bitů v typu číslice) a vrátí jeho vlastní proměnlivou referenci.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // vnitřní rutina.funguje nejlépe, když aa.len() <= bb.len().
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// Dělí se na `other` o velikosti číslic a vrací svou vlastní proměnlivou referenci *a* zbytek.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// Rozdělte sebe jiným bignumem, přepište `q` kvocientem a `r` zbytkem.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // Hloupé pomalé base-2 dlouhé dělení převzato z
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME používá větší základnu ($ty) pro dlouhé dělení.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // Nastavte bit `i` q na 1.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// Typ číslice pro `Big32x40`.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// tento se používá pouze pro testování.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}