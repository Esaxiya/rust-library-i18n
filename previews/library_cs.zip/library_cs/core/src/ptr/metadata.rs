#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Poskytuje typ metadat ukazatele jakéhokoli špičatého typu.
///
/// # Ukazatel metadata
///
/// Surové typy ukazatelů a referenční typy v Rust lze považovat za vytvořené ze dvou částí:
/// datový ukazatel, který obsahuje adresu paměti hodnoty a některá metadata.
///
/// U staticky velkých typů (které implementují `Sized` traits) i u typů `extern` se o ukazatelích říká, že jsou " tenké`: metadata mají nulovou velikost a jejich typ je `()`.
///
///
/// Ukazatele na [dynamically-sized types][dst] jsou považovány za " široké`nebo " tlusté`, mají nenulová metadata:
///
/// * U struktur, jejichž posledním polem je DST, jsou metadata metadata posledního pole
/// * U typu `str` jsou metadata délka v bajtech jako `usize`
/// * U typů řezů, jako je `[T]`, jsou metadata délkou v položkách jako `usize`
/// * U objektů trait jako `dyn SomeTrait` jsou metadata [`DynMetadata<Self>`][DynMetadata] (např. `DynMetadata<dyn SomeTrait>`)
///
/// V future může jazyk Rust získat nové druhy typů, které mají různá metadata ukazatele.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Smyslem tohoto trait je jeho asociovaný typ `Metadata`, kterým je `()` nebo `usize` nebo `DynMetadata<_>`, jak je popsáno výše.
/// Automaticky se implementuje pro každý typ.
/// Lze předpokládat, že je implementován v obecném kontextu, a to i bez odpovídající vazby.
///
/// # Usage
///
/// Nezpracované ukazatele lze pomocí metody [`to_raw_parts`] rozložit na komponenty datové adresy a metadata.
///
/// Alternativně lze pomocí funkce [`metadata`] extrahovat pouze metadata.
/// Odkaz lze předat [`metadata`] a implicitně vynutit.
///
/// Ukazatel (possibly-wide) lze dát dohromady z jeho adresy a metadat pomocí [`from_raw_parts`] nebo [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Typ metadat v ukazatelích a odkazech na `Self`.
    #[lang = "metadata_type"]
    // NOTE: Ponechat trait bounds v `static_assert_expected_bounds_for_metadata`
    //
    // v `library/core/src/ptr/metadata.rs` v synchronizaci s těmi zde:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Ukazatele na typy implementující tento alias trait jsou " tenké`.
///
/// To zahrnuje staticky typy ``Size`` a typy `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: nestabilizujte to dříve, než jsou aliasy trait v jazyce stabilní?
pub trait Thin = Pointee<Metadata = ()>;

/// Extrahujte komponentu metadat ukazatele.
///
/// Hodnoty typu `*mut T`, `&T` nebo `&mut T` lze předat přímo této funkci, protože implicitně vynucují `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // BEZPEČNOST: Přístup k hodnotě z unie `PtrRepr` je bezpečný, protože * const T
    // a PtrComponents<T>mají stejné rozložení paměti.
    // Tuto záruku může poskytnout pouze std.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Vytvoří surový ukazatel (possibly-wide) z datové adresy a metadat.
///
/// Tato funkce je bezpečná, ale vrácený ukazatel nemusí být nutně bezpečný pro dereference.
/// Pláty viz bezpečnostní požadavky v dokumentaci [`slice::from_raw_parts`].
/// U objektů trait musí metadata pocházet z ukazatele na stejný podkladový typ.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // BEZPEČNOST: Přístup k hodnotě z unie `PtrRepr` je bezpečný, protože * const T
    // a PtrComponents<T>mají stejné rozložení paměti.
    // Tuto záruku může poskytnout pouze std.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Provede stejnou funkcionalitu jako [`from_raw_parts`], kromě toho, že je vrácen surový ukazatel `*mut`, na rozdíl od surového ukazatele `* const`.
///
///
/// Další podrobnosti najdete v dokumentaci [`from_raw_parts`].
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // BEZPEČNOST: Přístup k hodnotě z unie `PtrRepr` je bezpečný, protože * const T
    // a PtrComponents<T>mají stejné rozložení paměti.
    // Tuto záruku může poskytnout pouze std.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Aby se zabránilo vázání `T: Copy`, je zapotřebí ruční nářadí.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Aby se zabránilo vázání `T: Clone`, je zapotřebí ruční nářadí.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Metadata pro typ objektu `Dyn = dyn SomeTrait` trait.
///
/// Jedná se o ukazatel na vtable (tabulka virtuálních volání), která představuje všechny potřebné informace k manipulaci s konkrétním typem uloženým uvnitř objektu trait.
/// Vtable zejména obsahuje:
///
/// * velikost písma
/// * zarovnání typu
/// * ukazatel na typ `drop_in_place` impl (může být no-op pro prostá stará data)
/// * ukazatele na všechny metody implementace typu trait typu
///
/// Všimněte si, že první tři jsou speciální, protože je nutné alokovat, zrušit a zrušit přidělení libovolného objektu trait.
///
/// Je možné pojmenovat tuto strukturu pomocí parametru typu, který není objektem `dyn` trait (například `DynMetadata<u64>`), ale nelze získat smysluplnou hodnotu této struktury.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Společná předpona všech vtables.Za ním následují ukazatele funkcí pro metody trait.
///
/// Soukromá implementace detail `DynMetadata::size_of` atd.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Vrátí velikost typu přidruženého k této vtable.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Vrátí zarovnání typu přidruženého k této vtable.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Vrátí velikost a zarovnání společně jako `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // BEZPEČNOST: kompilátor emitoval tento vtable pro konkrétní typ Rust který
        // je známo, že má platné rozložení.Stejné odůvodnění jako v `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Abyste se vyhnuli hranicím `Dyn: $Trait`, je zapotřebí manuální implementace.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}