//! Ručně spravujte paměť pomocí surových ukazatelů.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Mnoho funkcí v tomto modulu bere surové ukazatele jako argumenty a čte je nebo na ně zapisuje.Aby to bylo bezpečné, musí být tyto ukazatele *platné*.
//! Zda je ukazatel platný, závisí na operaci, pro kterou se používá (čtení nebo zápis), a na rozsahu paměti, ke které se přistupuje (tj. Kolik bajtů je read/written).
//! Většina funkcí používá `*mut T` a `* const T` pro přístup pouze k jedné hodnotě, v takovém případě dokumentace vynechá velikost a implicitně předpokládá, že jde o `size_of::<T>()` bajtů.
//!
//! Přesná pravidla platnosti ještě nejsou stanovena.Záruky poskytované v tomto okamžiku jsou velmi minimální:
//!
//! * Ukazatel [null] je *nikdy* neplatný, a to ani pro přístupy [size zero][zst].
//! * Aby byl ukazatel platný, je nutné, ale ne vždy dostatečné, aby byl ukazatel *dereferenceable*: rozsah paměti dané velikosti začínající na ukazateli musí být v mezích jediného přiděleného objektu.
//!
//! Všimněte si, že v Rust je každá proměnná (stack-allocated) považována za samostatný přidělený objekt.
//! * Dokonce i pro operace [size zero][zst] nesmí ukazatel ukazovat na uvolněnou paměť, tj. Při přidělení jsou ukazatele neplatné i pro operace nulové velikosti.
//! Vrhání jakéhokoli nenulového celého čísla *literálu* na ukazatel je však platné pro přístupy s nulovou velikostí, i když na této adrese náhodou existuje nějaká paměť a dojde k jejímu uvolnění.
//! To odpovídá psaní vlastního alokátoru: alokace objektů nulové velikosti není příliš tvrdá.
//! Kanonickým způsobem, jak získat ukazatel, který je platný pro přístupy s nulovou velikostí, je [`NonNull::dangling`].
//! * Všechny přístupy prováděné funkcemi v tomto modulu jsou *ne-atomové* ve smyslu [atomic operations] používaného k synchronizaci mezi vlákny.
//! To znamená, že je nedefinované chování provádět dva souběžné přístupy ke stejnému umístění z různých vláken, pokud oba přístupy nečtou pouze z paměti.
//! Všimněte si, že to výslovně zahrnuje [`read_volatile`] a [`write_volatile`]: Těkavé přístupy nelze použít pro synchronizaci mezi vlákny.
//! * Výsledek přetypování odkazu na ukazatel je platný tak dlouho, dokud je podkladový objekt aktivní a pro přístup do stejné paměti se nepoužívá žádný odkaz (pouze surové ukazatele).
//!
//! Tyto axiomy, spolu s pečlivým používáním [`offset`] pro aritmetiku ukazatele, jsou dostatečné pro správnou implementaci mnoha užitečných věcí v nebezpečném kódu.
//! Až budou stanovena pravidla [aliasing], budou nakonec poskytnuty přísnější záruky.
//! Další informace najdete v [book] a také v sekci v odkazu věnovaném [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Platné surové ukazatele, jak jsou definovány výše, nemusí být nutně správně zarovnány (kde je zarovnání "proper" definováno typem pointee, tj. `*const T` musí být zarovnáno s `mem::align_of::<T>()`).
//! Většina funkcí však vyžaduje, aby jejich argumenty byly správně zarovnány, a výslovně uvedou tento požadavek ve své dokumentaci.
//! Pozoruhodné výjimky jsou [`read_unaligned`] a [`write_unaligned`].
//!
//! Když funkce vyžaduje správné zarovnání, udělá to, i když má přístup velikost 0, tj. I když se ve skutečnosti nedotkne paměti.V takových případech zvažte použití [`NonNull::dangling`].
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Spustí destruktor (pokud existuje) namířené hodnoty.
///
/// To je sémanticky ekvivalentní volání [`ptr::read`] a vyřazení výsledku, ale má následující výhody:
///
/// * Je *povinné* použít `drop_in_place` k zahození nezměněných typů, jako jsou objekty trait, protože je nelze přečíst do zásobníku a normálně zahodit.
///
/// * Optimalizátor je přívětivější udělat to přes [`ptr::read`] při rušení ručně přidělené paměti (např. V implementacích `Box`/`Rc`/`Vec`), protože kompilátor nemusí prokazovat, že je dobrý, aby elidoval kopii.
///
///
/// * Lze jej použít k přetažení dat [pinned], když `T` není `repr(packed)` (připnutá data se před přesunem nesmí přesouvat).
///
/// Nezarovnané hodnoty nelze na místo zahodit, je třeba je nejprve zkopírovat do zarovnaného umístění pomocí [`ptr::read_unaligned`].U zabalených struktur se tento tah provádí automaticky kompilátorem.
/// To znamená, že pole zabalených struktur nebudou umístěna na místo.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Chování není definováno, pokud dojde k porušení některé z následujících podmínek:
///
/// * `to_drop` musí být [valid] pro čtení i zápis.
///
/// * `to_drop` musí být správně zarovnány.
///
/// * Hodnota `to_drop` bodů, která musí být platná pro upuštění, což může znamenat, že musí udržovat další invarianty, to je závislé na typu.
///
/// Navíc pokud `T` není [`Copy`], může použití hodnoty ukazující na po volání `drop_in_place` způsobit nedefinované chování.Všimněte si, že `*to_drop = foo` se počítá jako použití, protože to způsobí opětovné snížení hodnoty.
/// [`write()`] lze použít k přepsání dat, aniž by došlo k jejich zrušení.
///
/// Všimněte si, že i když má `T` velikost `0`, ukazatel musí mít jinou hodnotu než NULL a musí být správně zarovnaný.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ručně odebrat poslední položku ze vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Získejte surový ukazatel na poslední prvek v `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Zkraťte `v`, abyste zabránili pádu poslední položky.
///     // Nejprve to uděláme, abychom zabránili problémům, pokud `drop_in_place` pod panics.
///     v.set_len(1);
///     // Bez volání `drop_in_place` by poslední položka nikdy nebyla zrušena a došlo by k úniku paměti, kterou spravuje.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Zajistěte, aby byla poslední položka zrušena.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Všimněte si, že kompilátor provede tuto kopii automaticky při odhození zabalených struktur, tj. Pokud se neobjevíte ručně `drop_in_place`, obvykle si nemusíte dělat starosti s takovými problémy.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Na kódu zde nezáleží, toto je nahrazeno skutečným lepidlem pro kapky kompilátorem.
    //

    // BEZPEČNOST: viz výše uvedený komentář
    unsafe { drop_in_place(to_drop) }
}

/// Vytvoří nulový surový ukazatel.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Vytvoří nulový proměnlivý surový ukazatel.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Aby se zabránilo vázání `T: Clone`, je zapotřebí ruční nářadí.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Aby se zabránilo vázání `T: Copy`, je zapotřebí ruční nářadí.
impl<T> Copy for FatPtr<T> {}

/// Vytvoří surový řez z ukazatele a délky.
///
/// Argument `len` je počet **prvků**, nikoli počet bajtů.
///
/// Tato funkce je bezpečná, ale ve skutečnosti je použití návratové hodnoty nebezpečné.
/// Požadavky na bezpečnost řezů najdete v dokumentaci [`slice::from_raw_parts`].
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // vytvořte ukazatel řezu, když začínáte s ukazatelem na první prvek
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // BEZPEČNOST: Přístup k hodnotě z unie `Repr` je bezpečný od * const [T]
        //
        // a FatPtr mají stejné rozložení paměti.Tuto záruku může poskytnout pouze std.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Provede stejnou funkcionalitu jako [`slice_from_raw_parts`], kromě toho, že se vrátí nezměnitelný nezměnitelný řez, na rozdíl od nezměněného nezměnitelného řezu.
///
///
/// Další podrobnosti najdete v dokumentaci [`slice_from_raw_parts`].
///
/// Tato funkce je bezpečná, ale ve skutečnosti je použití návratové hodnoty nebezpečné.
/// Požadavky na bezpečnost řezů najdete v dokumentaci [`slice::from_raw_parts_mut`].
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // přiřadit hodnotu indexu v řezu
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // BEZPEČNOST: Přístup k hodnotě z unie `Repr` je bezpečný od * mut [T]
        // a FatPtr mají stejné rozložení paměti
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Zamění hodnoty na dvou proměnlivých místech stejného typu, aniž by došlo k deinicializaci.
///
/// Ale pro následující dvě výjimky je tato funkce sémanticky ekvivalentní [`mem::swap`]:
///
///
/// * Funguje na surových ukazatelích místo odkazů.
/// Pokud jsou k dispozici odkazy, měla by se upřednostňovat [`mem::swap`].
///
/// * Dvě ukazované hodnoty se mohou překrývat.
/// Pokud se hodnoty překrývají, použije se překrývající se oblast paměti z `x`.
/// To je ukázáno v druhém příkladu níže.
///
/// # Safety
///
/// Chování není definováno, pokud dojde k porušení některé z následujících podmínek:
///
/// * `x` i `y` musí být [valid] pro čtení i zápis.
///
/// * `x` i `y` musí být správně zarovnány.
///
/// Všimněte si, že i když má `T` velikost `0`, ukazatele musí mít jinou hodnotu než NULL a musí být správně zarovnány.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Zaměňte dvě nepřekrývající se oblasti:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // toto je `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // toto je `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Zaměňte dvě překrývající se oblasti:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // toto je `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // toto je `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Indexy `1..3` řezu se překrývají mezi `x` a `y`.
///     // Přiměřené výsledky by pro ně byly `[2, 3]`, takže indexy `0..3` jsou `[1, 2, 3]` (odpovídající `y` před `swap`);nebo aby byly `[0, 1]`, takže indexy `1..4` jsou `[0, 1, 2]` (odpovídající `x` před `swap`).
/////
///     // Tato implementace je definována tak, aby byla provedena druhá možnost.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Dejte nám trochu volného místa pro práci.
    // S kapkami se nemusíme bát: `MaybeUninit` při pádu nedělá nic.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Proveďte výměnu BEZPEČNOST: volající musí zaručit, že `x` a `y` jsou platné pro zápis a správně zarovnané.
    // `tmp` nemůže překrývat `x` ani `y`, protože `tmp` byl právě přidělen na zásobníku jako samostatný přidělený objekt.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` a `y` se mohou překrývat
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Zamění bajty `count * size_of::<T>()` mezi dvěma oblastmi paměti počínaje `x` a `y`.
/// Tyto dvě oblasti se nesmí *překrývat*.
///
/// # Safety
///
/// Chování není definováno, pokud dojde k porušení některé z následujících podmínek:
///
/// * Jak `x`, tak `y` musí být [valid] pro čtení i zápis počtu *
///   velikost: :<T>() `` bajtů.
///
/// * `x` i `y` musí být správně zarovnány.
///
/// * Oblast paměti začínající na `x` s velikostí `count *
///   velikost: :<T>() `bajty se *nesmí* překrývat s oblastí paměti začínající na `y` se stejnou velikostí.
///
/// Všimněte si, že i když je skutečně zkopírována velikost (`count * size_of: :<T>()`) je `0`, ukazatele musí mít jinou hodnotu než NULL a musí být správně zarovnány.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Základní použití:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // BEZPEČNOST: volající musí zaručit, že `x` a `y` jsou
    // platí pro zápisy a správně zarovnáno.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // U typů menších, než je optimalizace bloku níže, stačí zaměnit přímo, abyste se vyhnuli pesimizaci kódu.
    //
    if mem::size_of::<T>() < 32 {
        // BEZPEČNOST: volající musí zaručit platnost `x` a `y`
        // pro zápisy, správně zarovnané a nepřekrývající se.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Přístupem je využití simd k efektivní výměně x&y.
    // Testování odhalilo, že výměna buď 32 bajtů nebo 64 bajtů najednou je pro procesory Intel Haswell E nejúčinnější.
    // LLVM je schopen optimalizovat, pokud dáme struktuře #[repr(simd)], i když tuto strukturu ve skutečnosti nepoužíváme přímo.
    //
    //
    // FIXME repr(simd) nefunkční na emscripten a redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Procházejte x&y, kopírujte je `Block` najednou Optimalizátor by měl u většiny typů NB smyčku plně odmotat
    // Nemůžeme použít smyčku for, protože `range` impl volá rekurzivně `mem::swap`
    //
    let mut i = 0;
    while i + block_size <= len {
        // Vytvořte neinicializovanou paměť jako stírací prostor Deklarováním `t` se zde vyhnete zarovnání zásobníku, když je tato smyčka nepoužívaná
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // BEZPEČNOST: Jako `i < len` a jako volající musí zaručit platnost `x` a `y`
        // pro `len` bajty musí být `x + i` a `y + i` platné adresy, které splňují bezpečnostní smlouvu pro `add`.
        //
        // Volající musí také zaručit, že `x` a `y` jsou platné pro zápisy, správně zarovnané a nepřekrývající se, což splňuje bezpečnostní smlouvu pro `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Zaměňte blok bajtů x&y pomocí t jako dočasné vyrovnávací paměti To by mělo být optimalizováno do efektivních operací SIMD, pokud je k dispozici
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Vyměňte všechny zbývající bajty
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // BEZPEČNOST: viz předchozí bezpečnostní komentář.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Přesune `src` do špičatého `dst` a vrátí předchozí hodnotu `dst`.
///
/// Žádná z hodnot není vynechána.
///
/// Tato funkce je sémanticky ekvivalentní [`mem::replace`], kromě toho, že pracuje na surových ukazatelích místo odkazů.
/// Pokud jsou k dispozici odkazy, měla by se upřednostňovat [`mem::replace`].
///
/// # Safety
///
/// Chování není definováno, pokud dojde k porušení některé z následujících podmínek:
///
/// * `dst` musí být [valid] pro čtení i zápis.
///
/// * `dst` musí být správně zarovnány.
///
/// * `dst` musí ukazovat na správně inicializovanou hodnotu typu `T`.
///
/// Všimněte si, že i když má `T` velikost `0`, ukazatel musí mít jinou hodnotu než NULL a musí být správně zarovnaný.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` by měl stejný účinek, aniž by vyžadoval nebezpečný blok.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // BEZPEČNOST: volající musí zaručit, že `dst` je platný
    // přetypovat na proměnlivý odkaz (platí pro zápisy, zarovnáno, inicializováno) a nemůže překrývat `src`, protože `dst` musí ukazovat na odlišný přidělený objekt.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // nemůže překrývat
    }
    src
}

/// Přečte hodnotu z `src` bez jejího přesunutí.To ponechá paměť v `src` beze změny.
///
/// # Safety
///
/// Chování není definováno, pokud dojde k porušení některé z následujících podmínek:
///
/// * `src` pro čtení musí být [valid].
///
/// * `src` musí být správně zarovnány.Pokud tomu tak není, použijte [`read_unaligned`].
///
/// * `src` musí ukazovat na správně inicializovanou hodnotu typu `T`.
///
/// Všimněte si, že i když má `T` velikost `0`, ukazatel musí mít jinou hodnotu než NULL a musí být správně zarovnaný.
///
/// # Examples
///
/// Základní použití:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Ručně implementovat [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Vytvořte bitovou kopii hodnoty na `a` v `tmp`.
///         let tmp = ptr::read(a);
///
///         // Ukončení v tomto okamžiku (buď explicitním vrácením nebo voláním funkce, která panics) způsobí, že hodnota v `tmp` bude zrušena, zatímco na stejnou hodnotu bude `a` stále odkazovat.
///         // To by mohlo spustit nedefinované chování, pokud `T` není `Copy`.
/////
/////
///
///         // Vytvořte bitovou kopii hodnoty na `b` v `a`.
///         // To je bezpečné, protože proměnlivé odkazy nelze aliasovat.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Jak je uvedeno výše, ukončení zde by mohlo spustit nedefinované chování, protože `a` a `b` odkazuje na stejnou hodnotu.
/////
///
///         // Přesuňte `tmp` do `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` byl přesunut (`write` přebírá vlastnictví svého druhého argumentu), takže zde nic implicitně nepustí.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Vlastnictví vrácené hodnoty
///
/// `read` vytvoří bitovou kopii `T`, bez ohledu na to, zda `T` je [`Copy`].
/// Pokud `T` není [`Copy`], použití vrácené hodnoty a hodnoty na `*src` může narušit bezpečnost paměti.
/// Všimněte si, že přiřazení k `*src` se počítá jako použití, protože se pokusí o pokles hodnoty na `* src`.
///
/// [`write()`] lze použít k přepsání dat, aniž by došlo k jejich zrušení.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` nyní ukazuje na stejnou základní paměť jako `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Přiřazení k `s2` způsobí pokles jeho původní hodnoty.
///     // Za tímto bodem již `s` nesmí být používán, protože podkladová paměť byla uvolněna.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Přiřazení k `s` by způsobilo opětovné upuštění od staré hodnoty, což by mělo za následek nedefinované chování.
/////
///     // s= String::from("bar");//CHYBA
///
///     // `ptr::write` lze použít k přepsání hodnoty bez jejího zrušení.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // BEZPEČNOST: volající musí zaručit, že `src` je platný pro čtení.
    // `src` nemůže překrývat `tmp`, protože `tmp` byl právě přidělen na zásobníku jako samostatný přidělený objekt.
    //
    //
    // Protože jsme právě zapsali platnou hodnotu do `tmp`, je zaručeno, že bude správně inicializována.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Přečte hodnotu z `src` bez jejího přesunutí.To ponechá paměť v `src` beze změny.
///
/// Na rozdíl od [`read`] pracuje `read_unaligned` s nezarovnanými ukazateli.
///
/// # Safety
///
/// Chování není definováno, pokud dojde k porušení některé z následujících podmínek:
///
/// * `src` pro čtení musí být [valid].
///
/// * `src` musí ukazovat na správně inicializovanou hodnotu typu `T`.
///
/// Stejně jako [`read`], i `read_unaligned` vytváří bitovou kopii `T`, bez ohledu na to, zda `T` je [`Copy`].
/// Pokud `T` není [`Copy`], použití vrácené hodnoty a hodnoty na `*src` může [violate memory safety][read-ownership].
///
/// Všimněte si, že i když má `T` velikost `0`, ukazatel musí mít jinou hodnotu než NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Na strukturách `packed`
///
/// V současné době je nemožné vytvořit surové ukazatele na nevyrovnaná pole zabalené struktury.
///
/// Pokus o vytvoření nezpracovaného ukazatele na pole struktury `unaligned` s výrazem, jako je `&packed.unaligned as *const FieldType`, vytvoří před převedením na nezpracovaný ukazatel mezilehlou nevyrovnanou referenci.
///
/// Že tento odkaz je dočasný a okamžité přetypování je bezvýznamné, protože kompilátor vždy očekává, že odkazy budou správně zarovnány.
/// Výsledkem je, že použití `&packed.unaligned as *const FieldType` způsobí okamžité* nedefinované chování * ve vašem programu.
///
/// Příklad toho, co nedělat a jak to souvisí s `read_unaligned`, je:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Zde se pokusíme vzít adresu 32bitového celého čísla, které není zarovnáno.
///     let unaligned =
///         // Zde se vytvoří dočasný nezarovnaný odkaz, který má za následek nedefinované chování bez ohledu na to, zda je odkaz použit nebo ne.
/////
///         &packed.unaligned
///         // Casting na surový ukazatel nepomůže;chyba se již stala.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Přístup k nevyrovnaným polím přímo např. S `packed.unaligned` je však bezpečný.
///
///
///
///
///
///
// FIXME: Aktualizujte dokumenty na základě výsledku RFC #2582 a přátel.
/// # Examples
///
/// Přečíst hodnotu usize z vyrovnávací paměti bajtů:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // BEZPEČNOST: volající musí zaručit, že `src` je platný pro čtení.
    // `src` nemůže překrývat `tmp`, protože `tmp` byl právě přidělen na zásobníku jako samostatný přidělený objekt.
    //
    //
    // Protože jsme právě zapsali platnou hodnotu do `tmp`, je zaručeno, že bude správně inicializována.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Přepíše místo v paměti zadanou hodnotou bez načtení nebo zrušení staré hodnoty.
///
/// `write` nevypustí obsah `dst`.
/// To je bezpečné, ale mohlo by dojít k úniku alokací nebo prostředků, proto je třeba dbát na to, aby nedošlo k přepsání objektu, který by měl být zrušen.
///
///
/// Navíc neklesá `src`.Sémanticky se `src` přesune do umístění, na které ukazuje `dst`.
///
/// To je vhodné pro inicializaci neinicializované paměti nebo přepsání paměti, ze které byl dříve [`read`].
///
/// # Safety
///
/// Chování není definováno, pokud dojde k porušení některé z následujících podmínek:
///
/// * `dst` pro zápis musí být [valid].
///
/// * `dst` musí být správně zarovnány.Pokud tomu tak není, použijte [`write_unaligned`].
///
/// Všimněte si, že i když má `T` velikost `0`, ukazatel musí mít jinou hodnotu než NULL a musí být správně zarovnaný.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Základní použití:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Ručně implementovat [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Vytvořte bitovou kopii hodnoty na `a` v `tmp`.
///         let tmp = ptr::read(a);
///
///         // Ukončení v tomto okamžiku (buď explicitním vrácením nebo voláním funkce, která panics) způsobí, že hodnota v `tmp` bude zrušena, zatímco na stejnou hodnotu bude `a` stále odkazovat.
///         // To by mohlo spustit nedefinované chování, pokud `T` není `Copy`.
/////
/////
///
///         // Vytvořte bitovou kopii hodnoty na `b` v `a`.
///         // To je bezpečné, protože proměnlivé odkazy nelze aliasovat.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Jak je uvedeno výše, ukončení zde by mohlo spustit nedefinované chování, protože `a` a `b` odkazuje na stejnou hodnotu.
/////
///
///         // Přesuňte `tmp` do `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` byl přesunut (`write` přebírá vlastnictví svého druhého argumentu), takže zde nic implicitně nepustí.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Voláme vnitřní přímo, abychom se vyhnuli volání funkcí v generovaném kódu, protože `intrinsics::copy_nonoverlapping` je obálková funkce.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // BEZPEČNOST: volající musí zaručit, že `dst` je platný pro zápis.
    // `dst` nemůže překrývat `src`, protože volající má proměnlivý přístup k `dst`, zatímco `src` je vlastněn touto funkcí.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Přepíše místo v paměti zadanou hodnotou bez načtení nebo zrušení staré hodnoty.
///
/// Na rozdíl od [`write()`] může být ukazatel nezarovnaný.
///
/// `write_unaligned` nevypustí obsah `dst`.To je bezpečné, ale mohlo by dojít k úniku alokací nebo prostředků, proto je třeba dbát na to, aby nedošlo k přepsání objektu, který by měl být zrušen.
///
/// Navíc neklesá `src`.Sémanticky se `src` přesune do umístění, na které ukazuje `dst`.
///
/// To je vhodné pro inicializaci neinicializované paměti nebo přepsání paměti, která byla dříve načtena pomocí [`read_unaligned`].
///
/// # Safety
///
/// Chování není definováno, pokud dojde k porušení některé z následujících podmínek:
///
/// * `dst` pro zápis musí být [valid].
///
/// Všimněte si, že i když má `T` velikost `0`, ukazatel musí mít jinou hodnotu než NULL.
///
/// [valid]: self#safety
///
/// ## Na strukturách `packed`
///
/// V současné době je nemožné vytvořit surové ukazatele na nevyrovnaná pole zabalené struktury.
///
/// Pokus o vytvoření nezpracovaného ukazatele na pole struktury `unaligned` s výrazem, jako je `&packed.unaligned as *const FieldType`, vytvoří před převedením na nezpracovaný ukazatel mezilehlou nevyrovnanou referenci.
///
/// Že tento odkaz je dočasný a okamžité přetypování je bezvýznamné, protože kompilátor vždy očekává, že odkazy budou správně zarovnány.
/// Výsledkem je, že použití `&packed.unaligned as *const FieldType` způsobí okamžité* nedefinované chování * ve vašem programu.
///
/// Příklad toho, co nedělat a jak to souvisí s `write_unaligned`, je:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Zde se pokusíme vzít adresu 32bitového celého čísla, které není zarovnáno.
///     let unaligned =
///         // Zde se vytvoří dočasný nezarovnaný odkaz, který má za následek nedefinované chování bez ohledu na to, zda je odkaz použit nebo ne.
/////
///         &mut packed.unaligned
///         // Casting na surový ukazatel nepomůže;chyba se již stala.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Přístup k nevyrovnaným polím přímo např. S `packed.unaligned` je však bezpečný.
///
///
///
///
///
///
///
///
///
// FIXME: Aktualizujte dokumenty na základě výsledku RFC #2582 a přátel.
/// # Examples
///
/// Napište hodnotu použití do bajtové vyrovnávací paměti:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // BEZPEČNOST: volající musí zaručit, že `dst` je platný pro zápis.
    // `dst` nemůže překrývat `src`, protože volající má proměnlivý přístup k `dst`, zatímco `src` je vlastněn touto funkcí.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Voláme vnitřní přímo, abychom se vyhnuli volání funkcí v generovaném kódu.
        intrinsics::forget(src);
    }
}

/// Provede volatilní čtení hodnoty z `src` bez jejího přesunutí.To ponechá paměť v `src` beze změny.
///
/// Volatile operations are intended to act on I/O memory, and are guaranteed to not be elited or reordered by the compiler across other volatile operations.
///
/// # Notes
///
/// Rust v současné době nemá přísně a formálně definovaný paměťový model, takže přesná sémantika toho, co zde "volatile" znamená, se může časem změnit.
/// Jak již bylo řečeno, sémantika téměř vždy skončí docela podobně jako [C11's definition of volatile][c11].
///
/// Kompilátor by neměl měnit relativní pořadí nebo počet operací volatilní paměti.
/// Avšak operace těkavé paměti u typů s nulovou velikostí (např. Pokud je typ s nulovou velikostí předán `read_volatile`) jsou noops a mohou být ignorovány.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Chování není definováno, pokud dojde k porušení některé z následujících podmínek:
///
/// * `src` pro čtení musí být [valid].
///
/// * `src` musí být správně zarovnány.
///
/// * `src` musí ukazovat na správně inicializovanou hodnotu typu `T`.
///
/// Stejně jako [`read`], i `read_volatile` vytváří bitovou kopii `T`, bez ohledu na to, zda `T` je [`Copy`].
/// Pokud `T` není [`Copy`], použití vrácené hodnoty a hodnoty na `*src` může [violate memory safety][read-ownership].
/// Ukládání typů, které nejsou v kopii, je však téměř jistě nesprávné.
///
/// Všimněte si, že i když má `T` velikost `0`, ukazatel musí mít jinou hodnotu než NULL a musí být správně zarovnaný.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Stejně jako v C, zda je operace volatilní, nemá vůbec žádný vliv na otázky týkající se souběžného přístupu z více vláken.Těkavé přístupy se v tomto ohledu chovají přesně jako jiné než atomové přístupy.
///
/// Zejména závod mezi `read_volatile` a jakoukoli operací zápisu do stejného umístění je nedefinované chování.
///
/// # Examples
///
/// Základní použití:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Nepanikaří, aby byl dopad kodegenu menší.
        abort();
    }
    // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Provede volatilní zápis paměťového místa s danou hodnotou bez čtení nebo zrušení staré hodnoty.
///
/// Volatile operations are intended to act on I/O memory, and are guaranteed to not be elited or reordered by the compiler across other volatile operations.
///
/// `write_volatile` nevypustí obsah `dst`.To je bezpečné, ale mohlo by dojít k úniku alokací nebo prostředků, proto je třeba dbát na to, aby nedošlo k přepsání objektu, který by měl být zrušen.
///
/// Navíc neklesá `src`.Sémanticky se `src` přesune do umístění, na které ukazuje `dst`.
///
/// # Notes
///
/// Rust v současné době nemá přísně a formálně definovaný paměťový model, takže přesná sémantika toho, co zde "volatile" znamená, se může časem změnit.
/// Jak již bylo řečeno, sémantika téměř vždy skončí docela podobně jako [C11's definition of volatile][c11].
///
/// Kompilátor by neměl měnit relativní pořadí nebo počet operací volatilní paměti.
/// Avšak operace těkavé paměti u typů s nulovou velikostí (např. Pokud je typ s nulovou velikostí předán `write_volatile`) jsou noops a mohou být ignorovány.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Chování není definováno, pokud dojde k porušení některé z následujících podmínek:
///
/// * `dst` pro zápis musí být [valid].
///
/// * `dst` musí být správně zarovnány.
///
/// Všimněte si, že i když má `T` velikost `0`, ukazatel musí mít jinou hodnotu než NULL a musí být správně zarovnaný.
///
/// [valid]: self#safety
///
/// Stejně jako v C, zda je operace volatilní, nemá vůbec žádný vliv na otázky týkající se souběžného přístupu z více vláken.Těkavé přístupy se v tomto ohledu chovají přesně jako jiné než atomové přístupy.
///
/// Zejména závod mezi `write_volatile` a jakoukoli jinou operací (čtení nebo zápis) na stejném místě je nedefinované chování.
///
/// # Examples
///
/// Základní použití:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Nepanikaří, aby byl dopad kodegenu menší.
        abort();
    }
    // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Zarovnejte ukazatel `p`.
///
/// Vypočítejte offset (z hlediska prvků kroku `stride`), který je třeba použít na ukazatel `p`, aby se ukazatel `p` zarovnal na `a`.
///
/// Note: Tato implementace byla pečlivě přizpůsobena tomu, aby nebyla panic.Je to UB pro to panic.
/// Jedinou skutečnou změnou, kterou lze zde provést, je změna `INV_TABLE_MOD_16` a souvisejících konstant.
///
/// Pokud se někdy rozhodneme umožnit nazvat vnitřní s `a`, která není dvojí silou, bude pravděpodobně rozumnější prostě přejít na naivní implementaci, než se snažit přizpůsobit této změně.
///
///
/// Jakékoli dotazy přejděte na@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Přímé použití těchto vnitřních řešení významně vylepšuje kodegen na opt-úrovni <=
    // 1, kde verze metody těchto operací nejsou vložené.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Vypočítejte multiplikativní modulární inverzi `x` modulo `m`.
    ///
    /// Tato implementace je přizpůsobena pro `align_offset` a má následující předpoklady:
    ///
    /// * `m` je síla dvou;
    /// * `x < m`; (pokud `x ≥ m`, místo toho předejte `x % m`)
    ///
    /// Implementace této funkce nesmí panic.Vůbec.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Multiplikativní modulární inverzní stůl modulo 2⁴=16.
        ///
        /// Všimněte si, že tato tabulka neobsahuje hodnoty, kde inverzní neexistuje (tj. Pro `0⁻¹ mod 16`, `2⁻¹ mod 16` atd.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo, pro které je `INV_TABLE_MOD_16` určen.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // BEZPEČNOST: `m` musí mít sílu dvou, tedy nenulovou.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Opakujeme "up" pomocí následujícího vzorce:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // do 2²ⁿ ≥ m.Pak můžeme snížit na požadovaný `m` tím, že vezmeme výsledek `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Všimněte si, že zde používáme operace zalamování záměrně-původní vzorec používá např. Odčítání `mod n`.
                // Je naprosto v pořádku udělat je místo toho `mod usize::MAX`, protože výsledek `mod n` bereme stejně.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // BEZPEČNOST: `a` je síla dvou, tedy nenulová.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` případ lze vypočítat jednodušeji pomocí `-p (mod a)`, ale tím se potlačí schopnost LLVM vybírat instrukce jako `lea`.Místo toho počítáme
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // který distribuuje operace kolem nosnosti, ale dostatečně pesimizuje `and`, aby LLVM mohl využívat různé optimalizace, o kterých ví.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Již zarovnáno.Jo!
        return 0;
    } else if stride == 0 {
        // Pokud ukazatel není zarovnaný a prvek má nulovou velikost, pak žádné množství prvků nikdy ukazatel nezarovná.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // BEZPEČNOST: a je síla dvou, tedy nenulová.stride==0 případ je zpracován výše.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // BEZPEČNOST: gcdpow má horní hranici, což je maximálně počet bitů v usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // BEZPEČNOST: gcd je vždy větší nebo rovno 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Tato branch řeší následující rovnici lineární kongruence:
        //
        // ` p + so = 0 mod a `
        //
        // `p` Zde je hodnota ukazatele, `s`, krok `T`, `o` offset v `T`s a `a`, požadované zarovnání.
        //
        // S `g = gcd(a, s)` a výše uvedenou podmínkou, která tvrdí, že `p` je také dělitelný `g`, můžeme označit `a' = a/g`, `s' = s/g`, `p' = p/g`, pak se to stane ekvivalentem:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // První člen je "the relative alignment of `p` to `a`" (děleno `g`), druhý člen je "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (opět dělen `g`).
        //
        // Dělení `g` je nutné, aby se inverzní dobře formoval, pokud `a` a `s` nejsou co-prime.
        //
        // Výsledek vytvořený tímto řešením není "minimal", takže je nutné vzít výsledek `o mod lcm(s, a)`.Můžeme nahradit `lcm(s, a)` pouze `a'`.
        //
        //
        //
        //
        //

        // BEZPEČNOST: `gcdpow` má horní mez, která není větší než počet koncových 0 bitů v `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // BEZPEČNOST: `a2` je nenulová.Řazení `a` o `gcdpow` nemůže posunout žádný z nastavených bitů
        // v `a` (z nichž má přesně jednu).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // BEZPEČNOST: `gcdpow` má horní mez, která není větší než počet koncových 0 bitů v `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // BEZPEČNOST: `gcdpow` má horní mez, která není větší než počet koncových 0 bitů
        // `a`.
        // Kromě toho odečtení nemůže přetéct, protože `a2 = a >> gcdpow` bude vždy přísně větší než `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // BEZPEČNOST: `a2` je síla dvou, jak bylo prokázáno výše.`s2` je přísně menší než `a2`
        // protože `(s % a) >> gcdpow` je přísně menší než `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Nelze vůbec zarovnat.
    usize::MAX
}

/// Porovná surové ukazatele pro rovnost.
///
/// Je to stejné jako použití operátoru `==`, ale méně obecné:
/// argumenty musí být `*const T` raw ukazatele, ne nic, co implementuje `PartialEq`.
///
/// To lze použít k porovnání referencí `&T` (které se implicitně nutí k `*const T`) podle jejich adresy, spíše než k porovnání hodnot, na které ukazují (což je implementace `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Plátky jsou také porovnány podle jejich délky (tučné ukazatele):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits jsou také srovnávány podle jejich implementace:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Ukazatele mají stejné adresy.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Objekty mají stejné adresy, ale `Trait` má různé implementace.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Převod odkazu na `*const u8` se porovnává podle adresy.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash surový ukazatel.
///
/// To lze použít k hašování odkazu `&T` (který se implicitně přenese na `*const T`) podle jeho adresy, nikoli podle hodnoty, na kterou ukazuje (což je implementace `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls pro ukazatele funkcí
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Pro AVR je vyžadován zprostředkovaný cast jako použití
                // takže adresní prostor ukazatele zdrojové funkce je zachován v konečném ukazateli funkce.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Pro AVR je vyžadován zprostředkovaný cast jako použití
                // takže adresní prostor ukazatele zdrojové funkce je zachován v konečném ukazateli funkce.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Žádné variadické funkce s 0 parametry
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Vytvořte surový ukazatel `const` na místo, aniž byste vytvořili mezilehlou referenci.
///
/// Vytvoření reference pomocí `&`/`&mut` je povoleno, pouze pokud je ukazatel správně zarovnán a ukazuje na inicializovaná data.
/// V případech, kdy tyto požadavky neplatí, by místo toho měly být použity surové ukazatele.
/// `&expr as *const _` však vytvoří odkaz před tím, než jej přenese na surový ukazatel, a tento odkaz podléhá stejným pravidlům jako všechny ostatní odkazy.
///
/// Toto makro může vytvořit surový ukazatel *, aniž by* nejprve vytvořil odkaz.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` by vytvořilo nezarovnanou referenci, a tak by bylo nedefinované chování!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Vytvořte surový ukazatel `mut` na místo, aniž byste vytvořili mezilehlou referenci.
///
/// Vytvoření reference pomocí `&`/`&mut` je povoleno, pouze pokud je ukazatel správně zarovnán a ukazuje na inicializovaná data.
/// V případech, kdy tyto požadavky neplatí, by místo toho měly být použity surové ukazatele.
/// `&mut expr as *mut _` však vytvoří odkaz před tím, než jej přenese na surový ukazatel, a tento odkaz podléhá stejným pravidlům jako všechny ostatní odkazy.
///
/// Toto makro může vytvořit surový ukazatel *, aniž by* nejprve vytvořil odkaz.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` by vytvořilo nezarovnanou referenci, a tak by bylo nedefinované chování!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` vynutí kopírování pole namísto vytvoření reference.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}