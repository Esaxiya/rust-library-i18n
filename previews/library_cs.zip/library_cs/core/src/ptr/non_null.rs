use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` ale nenulové a kovariantní.
///
/// Toto je často správná věc, kterou lze použít při vytváření datových struktur pomocí surových ukazatelů, ale je nakonec nebezpečnější použít kvůli jeho dalším vlastnostem.Pokud si nejste jisti, zda byste měli používat `NonNull<T>`, stačí použít `*mut T`!
///
/// Na rozdíl od `*mut T` musí být ukazatel vždy nenulový, i když ukazatel nikdy není dereferencován.To proto, aby výčty mohly použít tuto zakázanou hodnotu jako diskriminační-`Option<NonNull<T>>` má stejnou velikost jako `* mut T`.
/// Ukazatel se však může stále houpat, pokud není dereferencován.
///
/// Na rozdíl od `*mut T` byl `NonNull<T>` vybrán jako kovariantní přes `T`.Díky tomu je možné při vytváření kovariantních typů použít `NonNull<T>`, ale pokud se použije v typu, který by ve skutečnosti neměl být kovariantní, představuje riziko nezdraví.
/// (U `*mut T` byla provedena opačná volba, i když technicky mohla být nezdravost způsobena pouze voláním nebezpečných funkcí.)
///
/// Covariance je správná pro většinu bezpečných abstrakcí, jako jsou `Box`, `Rc`, `Arc`, `Vec` a `LinkedList`.Je tomu tak proto, že poskytují veřejné API, které se řídí běžnými sdílenými proměnnými pravidly XOR Rust.
///
/// Pokud váš typ nemůže být bezpečně kovariantní, musíte zajistit, aby obsahoval nějaké další pole pro zajištění invariance.Toto pole bude často typu [`PhantomData`], jako je `PhantomData<Cell<T>>` nebo `PhantomData<&'a mut T>`.
///
/// Všimněte si, že `NonNull<T>` má instanci `From` pro `&T`.To však nemění skutečnost, že mutace prostřednictvím (ukazatele odvozeného z a) sdíleného odkazu je nedefinované chování, pokud k mutaci nedojde uvnitř [`UnsafeCell<T>`].Totéž platí pro vytvoření proměnlivého odkazu ze sdíleného odkazu.
///
/// Pokud používáte tuto instanci `From` bez `UnsafeCell<T>`, je vaší odpovědností zajistit, aby `as_mut` nikdy nebyl volán a `as_ptr` nebyl nikdy použit pro mutaci.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` ukazatele nejsou `Send`, protože data, na která odkazují, mohou být aliasy.
// Pozn., Tento impl je zbytečný, ale měl by poskytovat lepší chybové zprávy.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` ukazatele nejsou `Sync`, protože data, na která odkazují, mohou být aliasy.
// Pozn., Tento impl je zbytečný, ale měl by poskytovat lepší chybové zprávy.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Vytvoří nový `NonNull`, který je visící, ale dobře zarovnaný.
    ///
    /// To je užitečné pro inicializaci typů, které líně alokují, jako to dělá `Vec::new`.
    ///
    /// Všimněte si, že hodnota ukazatele může potenciálně představovat platný ukazatel na `T`, což znamená, že to nesmí být použito jako sentinelová hodnota "not yet initialized".
    /// Typy, které líně přidělují, musí sledovat inicializaci nějakými jinými prostředky.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // BEZPEČNOST: mem::align_of() vrací nenulové použití, které se poté vrhá
        // na * mut T.
        // Proto `ptr` nemá hodnotu null a jsou dodrženy podmínky pro volání new_unchecked().
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Vrátí sdílené odkazy na hodnotu.Na rozdíl od [`as_ref`] to nevyžaduje inicializaci hodnoty.
    ///
    /// Pro proměnlivý protějšek viz [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Při volání této metody musíte zajistit, aby byly splněny všechny následující podmínky:
    ///
    /// * Ukazatel musí být správně zarovnán.
    ///
    /// * Musí to být "dereferencable" ve smyslu definovaném v [the module documentation].
    ///
    /// * Musíte vynutit pravidla aliasingu Rust, protože vrácená životnost `'a` je zvolena libovolně a nemusí nutně odrážet skutečnou životnost dat.
    ///
    ///   Zejména po dobu tohoto života nesmí dojít k mutaci paměti, na kterou ukazatel ukazuje, (kromě uvnitř `UnsafeCell`).
    ///
    /// To platí, i když je výsledek této metody nepoužitý!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // BEZPEČNOST: volající musí zaručit, že `self` splňuje všechny požadavky
        // požadavky na referenci.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Vrátí jedinečné odkazy na hodnotu.Na rozdíl od [`as_mut`] to nevyžaduje inicializaci hodnoty.
    ///
    /// Sdílené protějšky viz [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Při volání této metody musíte zajistit, aby byly splněny všechny následující podmínky:
    ///
    /// * Ukazatel musí být správně zarovnán.
    ///
    /// * Musí to být "dereferencable" ve smyslu definovaném v [the module documentation].
    ///
    /// * Musíte vynutit pravidla aliasingu Rust, protože vrácená životnost `'a` je zvolena libovolně a nemusí nutně odrážet skutečnou životnost dat.
    ///
    ///   Zejména po dobu tohoto života nesmí do paměti, na kterou ukazatel směřuje, získat přístup (čtení ani zápis) prostřednictvím jiného ukazatele.
    ///
    /// To platí, i když je výsledek této metody nepoužitý!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // BEZPEČNOST: volající musí zaručit, že `self` splňuje všechny požadavky
        // požadavky na referenci.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Vytvoří nový `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` musí mít nenulovou hodnotu.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // BEZPEČNOST: volající musí zaručit, že `ptr` nebude mít hodnotu null.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Vytvoří nový `NonNull`, pokud `ptr` nemá hodnotu null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // BEZPEČNOST: Ukazatel je již zkontrolován a nemá hodnotu null
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Provádí stejné funkce jako [`std::ptr::from_raw_parts`], kromě toho, že je vrácen ukazatel `NonNull`, na rozdíl od surového ukazatele `*const`.
    ///
    ///
    /// Další podrobnosti najdete v dokumentaci [`std::ptr::from_raw_parts`].
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // BEZPEČNOST: Výsledek `ptr::from::raw_parts_mut` je nenulový, protože `data_address` ano.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Rozložte (případně široký) ukazatel na adresu a komponenty metadat.
    ///
    /// Ukazatel lze později rekonstruovat pomocí [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Získá podkladový ukazatel `*mut`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Vrátí sdílený odkaz na hodnotu.Pokud může být hodnota neinicializována, musí se místo toho použít [`as_uninit_ref`].
    ///
    /// Pro proměnlivý protějšek viz [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Při volání této metody musíte zajistit, aby byly splněny všechny následující podmínky:
    ///
    /// * Ukazatel musí být správně zarovnán.
    ///
    /// * Musí to být "dereferencable" ve smyslu definovaném v [the module documentation].
    ///
    /// * Ukazatel musí ukazovat na inicializovanou instanci `T`.
    ///
    /// * Musíte vynutit pravidla aliasingu Rust, protože vrácená životnost `'a` je zvolena libovolně a nemusí nutně odrážet skutečnou životnost dat.
    ///
    ///   Zejména po dobu tohoto života nesmí dojít k mutaci paměti, na kterou ukazatel ukazuje, (kromě uvnitř `UnsafeCell`).
    ///
    /// To platí, i když je výsledek této metody nepoužitý!
    /// (Část o inicializaci ještě není zcela rozhodnuta, ale dokud nebude, jediný bezpečný přístup je zajistit, aby byly skutečně inicializovány.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // BEZPEČNOST: volající musí zaručit, že `self` splňuje všechny požadavky
        // požadavky na referenci.
        unsafe { &*self.as_ptr() }
    }

    /// Vrátí jedinečný odkaz na hodnotu.Pokud může být hodnota neinicializována, musí se místo toho použít [`as_uninit_mut`].
    ///
    /// Sdílené protějšky viz [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Při volání této metody musíte zajistit, aby byly splněny všechny následující podmínky:
    ///
    /// * Ukazatel musí být správně zarovnán.
    ///
    /// * Musí to být "dereferencable" ve smyslu definovaném v [the module documentation].
    ///
    /// * Ukazatel musí ukazovat na inicializovanou instanci `T`.
    ///
    /// * Musíte vynutit pravidla aliasingu Rust, protože vrácená životnost `'a` je zvolena libovolně a nemusí nutně odrážet skutečnou životnost dat.
    ///
    ///   Zejména po dobu tohoto života nesmí do paměti, na kterou ukazatel směřuje, získat přístup (čtení ani zápis) prostřednictvím jiného ukazatele.
    ///
    /// To platí, i když je výsledek této metody nepoužitý!
    /// (Část o inicializaci ještě není zcela rozhodnuta, ale dokud nebude, jediný bezpečný přístup je zajistit, aby byly skutečně inicializovány.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // BEZPEČNOST: volající musí zaručit, že `self` splňuje všechny požadavky
        // požadavky na proměnlivý odkaz.
        unsafe { &mut *self.as_ptr() }
    }

    /// Přetypuje na ukazatel jiného typu.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // BEZPEČNOST: `self` je ukazatel `NonNull`, který je nutně nenulový
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Vytvoří nenulový surový řez z tenkého ukazatele a délky.
    ///
    /// Argument `len` je počet **prvků**, nikoli počet bajtů.
    ///
    /// Tato funkce je bezpečná, ale dereferencování návratové hodnoty je nebezpečné.
    /// Požadavky na bezpečnost řezů najdete v dokumentaci [`slice::from_raw_parts`].
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // vytvořte ukazatel řezu, když začínáte s ukazatelem na první prvek
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Všimněte si, že tento příklad uměle demonstruje použití této metody, ale `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // BEZPEČNOST: `data` je ukazatel `NonNull`, který je nutně nenulový
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Vrátí délku nenulového surového řezu.
    ///
    /// Vrácená hodnota je počet **prvků**, nikoli počet bajtů.
    ///
    /// Tato funkce je bezpečná, i když nelze nerelový surový řez dereferencovat na řez, protože ukazatel nemá platnou adresu.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Vrátí nenulový ukazatel do vyrovnávací paměti řezu.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // BEZPEČNOST: Víme, že `self` není null.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Vrátí surový ukazatel do vyrovnávací paměti řezu.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Vrátí sdílený odkaz na výseč možných neinicializovaných hodnot.Na rozdíl od [`as_ref`] to nevyžaduje inicializaci hodnoty.
    ///
    /// Pro proměnlivý protějšek viz [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Při volání této metody musíte zajistit, aby byly splněny všechny následující podmínky:
    ///
    /// * Ukazatel musí být [valid] pro čtení pro `ptr.len() * mem::size_of::<T>()` mnoho bajtů a musí být správně zarovnán.To znamená zejména:
    ///
    ///     * Celý rozsah paměti tohoto řezu musí být obsažen v jednom přiděleném objektu!
    ///       Řezy se nikdy nemohou rozprostřít přes více přidělených objektů.
    ///
    ///     * Ukazatel musí být zarovnán i pro řezy nulové délky.
    ///     Jedním z důvodů je to, že optimalizace výčtu výčtu se může spoléhat na to, že odkazy (včetně řezů libovolné délky) jsou zarovnány a nenulové, aby se odlišily od ostatních dat.
    ///
    ///     Ukazatel, který je použitelný jako `data` pro řezy nulové délky, můžete získat pomocí [`NonNull::dangling()`].
    ///
    /// * Celková velikost řezu `ptr.len() * mem::size_of::<T>()` nesmí být větší než `isize::MAX`.
    ///   Viz bezpečnostní dokumentace [`pointer::offset`].
    ///
    /// * Musíte vynutit pravidla aliasingu Rust, protože vrácená životnost `'a` je zvolena libovolně a nemusí nutně odrážet skutečnou životnost dat.
    ///   Zejména po dobu tohoto života nesmí dojít k mutaci paměti, na kterou ukazatel ukazuje, (kromě uvnitř `UnsafeCell`).
    ///
    /// To platí, i když je výsledek této metody nepoužitý!
    ///
    /// Viz také [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Vrátí jedinečný odkaz na výseč možných neinicializovaných hodnot.Na rozdíl od [`as_mut`] to nevyžaduje inicializaci hodnoty.
    ///
    /// Sdílené protějšky viz [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Při volání této metody musíte zajistit, aby byly splněny všechny následující podmínky:
    ///
    /// * Ukazatel musí být [valid] pro čtení a zápis pro `ptr.len() * mem::size_of::<T>()` mnoho bajtů a musí být správně zarovnán.To znamená zejména:
    ///
    ///     * Celý rozsah paměti tohoto řezu musí být obsažen v jednom přiděleném objektu!
    ///       Řezy se nikdy nemohou rozprostřít přes více přidělených objektů.
    ///
    ///     * Ukazatel musí být zarovnán i pro řezy nulové délky.
    ///     Jedním z důvodů je to, že optimalizace výčtu výčtu se může spoléhat na to, že odkazy (včetně řezů libovolné délky) jsou zarovnány a nenulové, aby se odlišily od ostatních dat.
    ///
    ///     Ukazatel, který je použitelný jako `data` pro řezy nulové délky, můžete získat pomocí [`NonNull::dangling()`].
    ///
    /// * Celková velikost řezu `ptr.len() * mem::size_of::<T>()` nesmí být větší než `isize::MAX`.
    ///   Viz bezpečnostní dokumentace [`pointer::offset`].
    ///
    /// * Musíte vynutit pravidla aliasingu Rust, protože vrácená životnost `'a` je zvolena libovolně a nemusí nutně odrážet skutečnou životnost dat.
    ///   Zejména po dobu tohoto života nesmí do paměti, na kterou ukazatel směřuje, získat přístup (čtení ani zápis) prostřednictvím jiného ukazatele.
    ///
    /// To platí, i když je výsledek této metody nepoužitý!
    ///
    /// Viz také [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // To je bezpečné, protože `memory` je platný pro čtení a zápis pro `memory.len()` mnoho bajtů.
    /// // Upozorňujeme, že volání `memory.as_mut()` zde není povoleno, protože obsah může být neinicializován.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Vrátí nezpracovaný ukazatel na prvek nebo podřízený řez, aniž by bylo nutné kontrolovat hranice.
    ///
    /// Volání této metody s indexem out-of-bounds nebo když `self` není dereferencable je *[nedefinované chování]*, i když výsledný ukazatel není použit.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // BEZPEČNOST: volající zajišťuje, že `self` je dereferencable a `index` v mezích.
        // V důsledku toho nemůže být výsledný ukazatel NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // BEZPEČNOST: Unikátní ukazatel nemůže mít hodnotu null, takže podmínky pro
        // new_unchecked() jsou respektovány.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // BEZPEČNOST: Změnitelný odkaz nemůže mít hodnotu null.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // BEZPEČNOST: Odkaz nemůže mít hodnotu null, takže podmínky pro
        // new_unchecked() jsou respektovány.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}