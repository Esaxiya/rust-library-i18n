use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Obálka kolem nezpracované nenulové hodnoty `*mut T`, která označuje, že vlastník této obálky vlastní referenta.
/// Užitečné pro vytváření abstrakcí jako `Box<T>`, `Vec<T>`, `String` a `HashMap<K, V>`.
///
/// Na rozdíl od `*mut T` se `Unique<T>` chová "as if", šlo o instanci `T`.
/// Implementuje `Send`/`Sync`, pokud `T` je `Send`/`Sync`.
/// To také naznačuje druh silných aliasingových záruk, které může instance `T` očekávat:
/// referent ukazatele by neměl být upraven bez jedinečné cesty k jeho vlastnímu Unique.
///
/// Pokud si nejste jisti, zda je správné používat `Unique` pro vaše účely, zvažte použití `NonNull`, který má slabší sémantiku.
///
///
/// Na rozdíl od `*mut T` musí být ukazatel vždy nenulový, i když ukazatel nikdy není dereferencován.
/// To proto, aby výčty mohly použít tuto zakázanou hodnotu jako diskriminační-`Option<Unique<T>>` má stejnou velikost jako `Unique<T>`.
/// Ukazatel se však může stále houpat, pokud není dereferencován.
///
/// Na rozdíl od `*mut T` je `Unique<T>` kovariantní nad `T`.
/// To by mělo být vždy správné pro jakýkoli typ, který dodržuje požadavky Unique na aliasing.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: tato značka nemá žádné důsledky pro rozptyl, ale je nutná
    // aby Dropck pochopil, že logicky vlastníme `T`.
    //
    // Podrobnosti viz:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` ukazatele jsou `Send`, pokud `T` je `Send`, protože data, na která odkazují, jsou neaktivní.
/// Všimněte si, že tento invariant aliasingu není vynucen typovým systémem;abstrakce používající `Unique` ji musí vynutit.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` ukazatele jsou `Sync`, pokud `T` je `Sync`, protože data, na která odkazují, jsou neaktivní.
/// Všimněte si, že tento invariant aliasingu není vynucen typovým systémem;abstrakce používající `Unique` ji musí vynutit.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Vytvoří nový `Unique`, který je visící, ale dobře zarovnaný.
    ///
    /// To je užitečné pro inicializaci typů, které líně alokují, jako to dělá `Vec::new`.
    ///
    /// Všimněte si, že hodnota ukazatele může potenciálně představovat platný ukazatel na `T`, což znamená, že to nesmí být použito jako sentinelová hodnota "not yet initialized".
    /// Typy, které líně přidělují, musí sledovat inicializaci nějakými jinými prostředky.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // BEZPEČNOST: mem::align_of() vrací platný ukazatel, který nemá hodnotu null.The
        // podmínky pro volání new_unchecked() jsou tedy respektovány.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Vytvoří nový `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` musí mít nenulovou hodnotu.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // BEZPEČNOST: volající musí zaručit, že `ptr` nebude mít hodnotu null.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Vytvoří nový `Unique`, pokud `ptr` nemá hodnotu null.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // BEZPEČNOST: Ukazatel již byl zkontrolován a není nulový.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Získá podkladový ukazatel `*mut`.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Oddělí obsah.
    ///
    /// Výsledná životnost je vázána na sebe, takže se to chová "as if", ve skutečnosti to byla instance T, která si vypůjčuje.
    /// Pokud je potřeba delší životnost (unbound), použijte `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // BEZPEČNOST: volající musí zaručit, že `self` splňuje všechny požadavky
        // požadavky na referenci.
        unsafe { &*self.as_ptr() }
    }

    /// Odlišně dereferenční obsah.
    ///
    /// Výsledná životnost je vázána na sebe, takže se to chová "as if", ve skutečnosti to byla instance T, která si vypůjčuje.
    /// Pokud je potřeba delší životnost (unbound), použijte `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // BEZPEČNOST: volající musí zaručit, že `self` splňuje všechny požadavky
        // požadavky na proměnlivý odkaz.
        unsafe { &mut *self.as_ptr() }
    }

    /// Přetypuje na ukazatel jiného typu.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // BEZPEČNOST: Unique::new_unchecked() vytváří nový unikát a potřeby
        // daný ukazatel nesmí být null.
        // Protože míjíme sebe jako ukazatel, nemůže to být null.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // BEZPEČNOST: Změnitelný odkaz nemůže mít hodnotu null
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}