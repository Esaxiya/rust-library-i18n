use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Vrátí `true`, pokud má ukazatel hodnotu null.
    ///
    /// Všimněte si, že typy bez velikosti mají mnoho možných nulových ukazatelů, protože je považován pouze ukazatel surových dat, nikoli jejich délka, vtable atd.
    /// Proto dva ukazatele, které mají hodnotu null, se stále nemusí navzájem srovnávat.
    ///
    /// ## Chování během vyhodnocení konstanty
    ///
    /// Pokud se tato funkce používá během vyhodnocení const, může vrátit `false` pro ukazatele, které se za běhu ukáží jako null.
    /// Konkrétně, když je ukazatel na nějakou paměť odsazen za své hranice takovým způsobem, že výsledný ukazatel je null, funkce stále vrátí `false`.
    ///
    /// Neexistuje žádný způsob, jak CTFE zná absolutní polohu této paměti, takže nemůžeme zjistit, zda je ukazatel nulový nebo ne.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Porovnejte pomocí obsazení s tenkým ukazatelem, takže tlustí ukazatelé uvažují o své části "data" pouze pro nulovou hodnotu.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Přetypuje na ukazatel jiného typu.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Rozložte (případně široký) ukazatel na adresu a komponenty metadat.
    ///
    /// Ukazatel lze později rekonstruovat pomocí [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Vrátí `None`, pokud má ukazatel hodnotu null, jinak vrátí sdílený odkaz na hodnotu zabalenou v `Some`.Pokud může být hodnota neinicializována, musí se místo toho použít [`as_uninit_ref`].
    ///
    /// Pro proměnlivý protějšek viz [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Při volání této metody musíte zajistit, aby *buď* ukazatel měl hodnotu NULL *nebo* všechny následující hodnoty:
    ///
    /// * Ukazatel musí být správně zarovnán.
    ///
    /// * Musí to být "dereferencable" ve smyslu definovaném v [the module documentation].
    ///
    /// * Ukazatel musí ukazovat na inicializovanou instanci `T`.
    ///
    /// * Musíte vynutit pravidla aliasingu Rust, protože vrácená životnost `'a` je zvolena libovolně a nemusí nutně odrážet skutečnou životnost dat.
    ///   Zejména po dobu tohoto života nesmí dojít k mutaci paměti, na kterou ukazatel ukazuje, (kromě uvnitř `UnsafeCell`).
    ///
    /// To platí, i když je výsledek této metody nepoužitý!
    /// (Část o inicializaci ještě není zcela rozhodnuta, ale dokud nebude, jediný bezpečný přístup je zajistit, aby byly skutečně inicializovány.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Verze bez zaškrtnutí
    ///
    /// Pokud jste si jisti, že ukazatel nikdy nemůže mít hodnotu null a hledáte nějaký druh `as_ref_unchecked`, který vrátí `&T` místo `Option<&T>`, víte, že můžete dereferenci ukazatele přímo.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // BEZPEČNOST: volající musí zaručit, že `self` je platný pro a
        // odkaz, pokud není null.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Vrátí `None`, pokud má ukazatel hodnotu null, jinak vrátí sdílený odkaz na hodnotu zabalenou v `Some`.
    /// Na rozdíl od [`as_ref`] to nevyžaduje inicializaci hodnoty.
    ///
    /// Pro proměnlivý protějšek viz [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Při volání této metody musíte zajistit, aby *buď* ukazatel měl hodnotu NULL *nebo* všechny následující hodnoty:
    ///
    /// * Ukazatel musí být správně zarovnán.
    ///
    /// * Musí to být "dereferencable" ve smyslu definovaném v [the module documentation].
    ///
    /// * Musíte vynutit pravidla aliasingu Rust, protože vrácená životnost `'a` je zvolena libovolně a nemusí nutně odrážet skutečnou životnost dat.
    ///
    ///   Zejména po dobu tohoto života nesmí dojít k mutaci paměti, na kterou ukazatel ukazuje, (kromě uvnitř `UnsafeCell`).
    ///
    /// To platí, i když je výsledek této metody nepoužitý!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // BEZPEČNOST: volající musí zaručit, že `self` splňuje všechny požadavky
        // požadavky na referenci.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Vypočítá posunutí od ukazatele.
    ///
    /// `count` je v jednotkách T;např. `count` 3 představuje posun ukazatele `3 * size_of::<T>()` bajtů.
    ///
    /// # Safety
    ///
    /// Pokud dojde k porušení některé z následujících podmínek, výsledkem bude nedefinované chování:
    ///
    /// * Počáteční i výsledný ukazatel musí být buď v mezích, nebo o jeden bajt za koncem stejného přiděleného objektu.
    /// Všimněte si, že v Rust je každá proměnná (stack-allocated) považována za samostatný přidělený objekt.
    ///
    /// * Vypočítaný posun,**v bajtech**, nemůže přetéct `isize`.
    ///
    /// * Ofset je v mezích nemůže spoléhat na "wrapping around" adresního prostoru.To znamená, že součet nekonečné přesnosti,**v bajtech**, se musí vejít do usize.
    ///
    /// Kompilátor a standardní knihovna se obecně snaží zajistit, aby přidělení nikdy nedosáhla velikosti, kde je problémem offset.
    /// Například `Vec` a `Box` zajišťují, že nikdy nepřidělí více než `isize::MAX` bajtů, takže `vec.as_ptr().add(vec.len())` je vždy v bezpečí.
    ///
    /// Většina platforem zásadně nemůže takové přidělení ani postavit.
    /// Například žádná známá 64bitová platforma nemůže nikdy vyhovět požadavku na 2 <sup>63</sup> bajtů kvůli omezením tabulky stránek nebo rozdělení prostoru adres.
    /// Některé 32bitové a 16bitové platformy však mohou úspěšně obsloužit požadavek na více než `isize::MAX` bajtů s věcmi, jako je rozšíření fyzické adresy.
    ///
    /// Paměť získaná přímo z alokátorů nebo souborů mapovaných do paměti *může být* příliš velká na to, aby s touto funkcí mohla pracovat.
    ///
    /// Pokud je obtížné splnit tato omezení, zvažte místo toho použití [`wrapping_offset`].
    /// Jedinou výhodou této metody je, že umožňuje agresivnější optimalizace kompilátoru.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `offset`.
        // Získaný ukazatel je platný pro zápis, protože volající musí zaručit, že ukazuje na stejný přidělený objekt jako `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Vypočítá posunutí od ukazatele pomocí aritmetiky obtékání.
    /// `count` je v jednotkách T;např. `count` 3 představuje posun ukazatele `3 * size_of::<T>()` bajtů.
    ///
    /// # Safety
    ///
    /// Samotná tato operace je vždy bezpečná, ale použití výsledného ukazatele není.
    ///
    /// Výsledný ukazatel zůstane připojen ke stejnému přidělenému objektu, na který `self` ukazuje.
    /// Může *nelze* použít pro přístup k jinému přidělenému objektu.Všimněte si, že v Rust je každá proměnná (stack-allocated) považována za samostatný přidělený objekt.
    ///
    /// Jinými slovy, `let z = x.wrapping_offset((y as isize) - (x as isize))`*ne* dělá `z` stejně jako `y`, i když předpokládáme, že `T` má velikost `1` a nedochází k žádnému přetečení: `z` je stále připojen k objektu, ke kterému je `x` připojen, a dereferencováním je nedefinované chování, pokud `x` a `y` bod do stejného přiděleného objektu.
    ///
    /// Ve srovnání s [`offset`] tato metoda v zásadě zpožďuje požadavek pobytu ve stejném přiděleném objektu: [`offset`] je okamžité nedefinované chování při překračování hranic objektu;`wrapping_offset` produkuje ukazatel, ale přesto vede k nedefinovanému chování, pokud je ukazatel dereferencován, když je mimo hranice objektu, ke kterému je připojen.
    /// [`offset`] lze optimalizovat lépe a je tedy výhodnější v kódu citlivém na výkon.
    ///
    /// Zpožděná kontrola bere v úvahu pouze hodnotu ukazatele, která byla dereferencována, nikoli mezilehlé hodnoty použité během výpočtu konečného výsledku.
    /// Například `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` je vždy stejný jako `x`.Jinými slovy je povoleno opustit přidělený objekt a poté jej znovu zadat později.
    ///
    /// Pokud potřebujete překročit hranice objektu, přetypujte ukazatel na celé číslo a proveďte tam aritmetiku.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// // Iterujte pomocí surového ukazatele v krocích po dvou prvcích
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // BEZPEČNOST: vnitřní `arith_offset` nemá žádné předpoklady pro volání.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Vrátí `None`, pokud má ukazatel hodnotu null, jinak vrátí jedinečný odkaz na hodnotu zabalenou v `Some`.Pokud může být hodnota neinicializována, musí se místo toho použít [`as_uninit_mut`].
    ///
    /// Sdílené protějšky viz [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Při volání této metody musíte zajistit, aby *buď* ukazatel měl hodnotu NULL *nebo* všechny následující hodnoty:
    ///
    /// * Ukazatel musí být správně zarovnán.
    ///
    /// * Musí to být "dereferencable" ve smyslu definovaném v [the module documentation].
    ///
    /// * Ukazatel musí ukazovat na inicializovanou instanci `T`.
    ///
    /// * Musíte vynutit pravidla aliasingu Rust, protože vrácená životnost `'a` je zvolena libovolně a nemusí nutně odrážet skutečnou životnost dat.
    ///   Zejména po dobu tohoto života nesmí do paměti, na kterou ukazatel směřuje, získat přístup (čtení ani zápis) prostřednictvím jiného ukazatele.
    ///
    /// To platí, i když je výsledek této metody nepoužitý!
    /// (Část o inicializaci ještě není zcela rozhodnuta, ale dokud nebude, jediný bezpečný přístup je zajistit, aby byly skutečně inicializovány.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Vytiskne se: "[4, 2, 3]".
    /// ```
    ///
    /// # Verze bez zaškrtnutí
    ///
    /// Pokud jste si jisti, že ukazatel nikdy nemůže mít hodnotu null a hledáte nějaký druh `as_mut_unchecked`, který vrátí `&mut T` místo `Option<&mut T>`, víte, že můžete dereferenci ukazatele přímo.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Vytiskne se: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // BEZPEČNOST: volající musí zaručit, že `self` je platný pro
        // proměnlivý odkaz, pokud není null.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Vrátí `None`, pokud má ukazatel hodnotu null, jinak vrátí jedinečný odkaz na hodnotu zabalenou v `Some`.
    /// Na rozdíl od [`as_mut`] to nevyžaduje inicializaci hodnoty.
    ///
    /// Sdílené protějšky viz [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Při volání této metody musíte zajistit, aby *buď* ukazatel měl hodnotu NULL *nebo* všechny následující hodnoty:
    ///
    /// * Ukazatel musí být správně zarovnán.
    ///
    /// * Musí to být "dereferencable" ve smyslu definovaném v [the module documentation].
    ///
    /// * Musíte vynutit pravidla aliasingu Rust, protože vrácená životnost `'a` je zvolena libovolně a nemusí nutně odrážet skutečnou životnost dat.
    ///
    ///   Zejména po dobu tohoto života nesmí do paměti, na kterou ukazatel směřuje, získat přístup (čtení ani zápis) prostřednictvím jiného ukazatele.
    ///
    /// To platí, i když je výsledek této metody nepoužitý!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // BEZPEČNOST: volající musí zaručit, že `self` splňuje všechny požadavky
        // požadavky na referenci.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Vrátí, zda jsou dva ukazatele zaručeně stejné.
    ///
    /// Za běhu se tato funkce chová jako `self == other`.
    /// V některých kontextech (např. Vyhodnocení při kompilaci) však není vždy možné určit rovnost dvou ukazatelů, takže tato funkce může rušivě vrátit `false` pro ukazatele, které se později skutečně ukáží jako stejné.
    ///
    /// Ale když vrátí `true`, jsou ukazatele zaručeně stejné.
    ///
    /// Tato funkce je zrcadlem [`guaranteed_ne`], ale nikoli jeho inverzí.Existují srovnání ukazatelů, u nichž obě funkce vracejí `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Návratová hodnota se může změnit v závislosti na verzi kompilátoru a nebezpečný kód se nemusí spolehnout na výsledek této funkce pro spolehlivost.
    /// Doporučuje se používat tuto funkci pouze pro optimalizaci výkonu, kde falešné návratové hodnoty `false` touto funkcí nemají vliv na výsledek, ale pouze na výkon.
    /// Důsledky použití této metody k tomu, aby se běhový a kompilační kód choval odlišně, nebyly prozkoumány.
    /// Tato metoda by neměla být použita k zavedení takových rozdílů a neměla by být ani stabilizována, dokud nebudeme lépe rozumět této problematice.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Vrátí, zda jsou dva ukazatele zaručeně nerovné.
    ///
    /// Za běhu se tato funkce chová jako `self != other`.
    /// V některých kontextech (např. Vyhodnocení při kompilaci) však není vždy možné určit nerovnost dvou ukazatelů, takže tato funkce může falešně vrátit `false` pro ukazatele, které se později skutečně ukáží jako nerovné.
    ///
    /// Ale když vrátí `true`, ukazatele jsou zaručeně nerovné.
    ///
    /// Tato funkce je zrcadlem [`guaranteed_eq`], ale nikoli jeho inverzí.Existují srovnání ukazatelů, u nichž obě funkce vracejí `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Návratová hodnota se může změnit v závislosti na verzi kompilátoru a nebezpečný kód se nemusí spolehnout na výsledek této funkce pro spolehlivost.
    /// Doporučuje se používat tuto funkci pouze pro optimalizaci výkonu, kde falešné návratové hodnoty `false` touto funkcí nemají vliv na výsledek, ale pouze na výkon.
    /// Důsledky použití této metody k tomu, aby se běhový a kompilační kód choval odlišně, nebyly prozkoumány.
    /// Tato metoda by neměla být použita k zavedení takových rozdílů a neměla by být ani stabilizována, dokud nebudeme lépe rozumět této problematice.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Vypočítá vzdálenost mezi dvěma ukazateli.Vrácená hodnota je v jednotkách T: vzdálenost v bajtech se vydělí `mem::size_of::<T>()`.
    ///
    /// Tato funkce je inverzní k [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Pokud dojde k porušení některé z následujících podmínek, výsledkem bude nedefinované chování:
    ///
    /// * Počáteční i další ukazatel musí být buď v mezích, nebo o jeden bajt za koncem stejného přiděleného objektu.
    /// Všimněte si, že v Rust je každá proměnná (stack-allocated) považována za samostatný přidělený objekt.
    ///
    /// * Oba ukazatele musí být *odvozeny z* ukazatele na stejný objekt.
    ///   (Příklad viz níže.)
    ///
    /// * Vzdálenost mezi ukazateli, v bajtech, musí být přesným násobkem velikosti `T`.
    ///
    /// * Vzdálenost mezi ukazateli,**v bajtech**, nemůže přetéct `isize`.
    ///
    /// * Vzdálenost v mezích se nemůže spolehnout na "wrapping around" v adresním prostoru.
    ///
    /// Typy Rust nejsou nikdy větší než `isize::MAX` a přidělení Rust se nikdy neobjevují kolem adresního prostoru, takže dva ukazatele v rámci nějaké hodnoty jakéhokoli typu Rust typu `T` vždy splní poslední dvě podmínky.
    ///
    /// Standardní knihovna také obecně zajišťuje, že přidělení nikdy nedosáhne velikosti, kde je problémem offset.
    /// Například `Vec` a `Box` zajišťují, že nikdy nepřidělují více než `isize::MAX` bajtů, takže `ptr_into_vec.offset_from(vec.as_ptr())` vždy splňuje poslední dvě podmínky.
    ///
    /// Většina platforem v zásadě nedokáže postavit ani tak velkou alokaci.
    /// Například žádná známá 64bitová platforma nemůže nikdy vyhovět požadavku na 2 <sup>63</sup> bajtů kvůli omezením tabulky stránek nebo rozdělení prostoru adres.
    /// Některé 32bitové a 16bitové platformy však mohou úspěšně obsloužit požadavek na více než `isize::MAX` bajtů s věcmi, jako je rozšíření fyzické adresy.
    /// Paměť získaná přímo z alokátorů nebo souborů mapovaných do paměti *může být* příliš velká na to, aby s touto funkcí mohla pracovat.
    /// (Všimněte si, že [`offset`] a [`add`] mají také podobné omezení, a proto je nelze použít ani u tak velkých alokací.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Tato funkce panics, pokud `T` je typ ("ZST") s nulovou velikostí.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Nesprávné* použití:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Udělejte z ptr2_other "alias" z ptr2, ale odvozeného z ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Vzhledem k tomu, že ptr2_other a ptr2 jsou odvozeny z ukazatelů na různé objekty, výpočet jejich offsetu je nedefinované chování, i když ukazují na stejnou adresu!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Nedefinované chování
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Vypočítá posunutí od ukazatele (výhoda pro `.offset(count as isize)`).
    ///
    /// `count` je v jednotkách T;např. `count` 3 představuje posun ukazatele `3 * size_of::<T>()` bajtů.
    ///
    /// # Safety
    ///
    /// Pokud dojde k porušení některé z následujících podmínek, výsledkem bude nedefinované chování:
    ///
    /// * Počáteční i výsledný ukazatel musí být buď v mezích, nebo o jeden bajt za koncem stejného přiděleného objektu.
    /// Všimněte si, že v Rust je každá proměnná (stack-allocated) považována za samostatný přidělený objekt.
    ///
    /// * Vypočítaný posun,**v bajtech**, nemůže přetéct `isize`.
    ///
    /// * Ofset, který je v mezích, se nemůže spolehnout na "wrapping around" v adresním prostoru.To znamená, že součet nekonečné přesnosti musí zapadat do `usize`.
    ///
    /// Kompilátor a standardní knihovna se obecně snaží zajistit, aby přidělení nikdy nedosáhla velikosti, kde je problémem offset.
    /// Například `Vec` a `Box` zajišťují, že nikdy nepřidělí více než `isize::MAX` bajtů, takže `vec.as_ptr().add(vec.len())` je vždy v bezpečí.
    ///
    /// Většina platforem zásadně nemůže takové přidělení ani postavit.
    /// Například žádná známá 64bitová platforma nemůže nikdy vyhovět požadavku na 2 <sup>63</sup> bajtů kvůli omezením tabulky stránek nebo rozdělení prostoru adres.
    /// Některé 32bitové a 16bitové platformy však mohou úspěšně obsloužit požadavek na více než `isize::MAX` bajtů s věcmi, jako je rozšíření fyzické adresy.
    ///
    /// Paměť získaná přímo z alokátorů nebo souborů mapovaných do paměti *může být* příliš velká na to, aby s touto funkcí mohla pracovat.
    ///
    /// Pokud je obtížné splnit tato omezení, zvažte místo toho použití [`wrapping_add`].
    /// Jedinou výhodou této metody je, že umožňuje agresivnější optimalizace kompilátoru.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Vypočítá posunutí od ukazatele (výhoda pro `.offset ((počítat jako isize).wrapping_neg())`).
    ///
    /// `count` je v jednotkách T;např. `count` 3 představuje posun ukazatele `3 * size_of::<T>()` bajtů.
    ///
    /// # Safety
    ///
    /// Pokud dojde k porušení některé z následujících podmínek, výsledkem bude nedefinované chování:
    ///
    /// * Počáteční i výsledný ukazatel musí být buď v mezích, nebo o jeden bajt za koncem stejného přiděleného objektu.
    /// Všimněte si, že v Rust je každá proměnná (stack-allocated) považována za samostatný přidělený objekt.
    ///
    /// * Vypočítaný posun nesmí překročit `isize::MAX`**bajtů**.
    ///
    /// * Ofset je v mezích nemůže spoléhat na "wrapping around" adresního prostoru.To znamená, že součet nekonečné přesnosti musí zapadnout do usize.
    ///
    /// Kompilátor a standardní knihovna se obecně snaží zajistit, aby přidělení nikdy nedosáhla velikosti, kde je problémem offset.
    /// Například `Vec` a `Box` zajišťují, že nikdy nepřidělí více než `isize::MAX` bajtů, takže `vec.as_ptr().add(vec.len()).sub(vec.len())` je vždy v bezpečí.
    ///
    /// Většina platforem zásadně nemůže takové přidělení ani postavit.
    /// Například žádná známá 64bitová platforma nemůže nikdy vyhovět požadavku na 2 <sup>63</sup> bajtů kvůli omezením tabulky stránek nebo rozdělení prostoru adres.
    /// Některé 32bitové a 16bitové platformy však mohou úspěšně obsloužit požadavek na více než `isize::MAX` bajtů s věcmi, jako je rozšíření fyzické adresy.
    ///
    /// Paměť získaná přímo z alokátorů nebo souborů mapovaných do paměti *může být* příliš velká na to, aby s touto funkcí mohla pracovat.
    ///
    /// Pokud je obtížné splnit tato omezení, zvažte místo toho použití [`wrapping_sub`].
    /// Jedinou výhodou této metody je, že umožňuje agresivnější optimalizace kompilátoru.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Vypočítá posunutí od ukazatele pomocí aritmetiky obtékání.
    /// (pohodlí pro `.wrapping_offset(count as isize)`)
    ///
    /// `count` je v jednotkách T;např. `count` 3 představuje posun ukazatele `3 * size_of::<T>()` bajtů.
    ///
    /// # Safety
    ///
    /// Samotná tato operace je vždy bezpečná, ale použití výsledného ukazatele není.
    ///
    /// Výsledný ukazatel zůstane připojen ke stejnému přidělenému objektu, na který `self` ukazuje.
    /// Může *nelze* použít pro přístup k jinému přidělenému objektu.Všimněte si, že v Rust je každá proměnná (stack-allocated) považována za samostatný přidělený objekt.
    ///
    /// Jinými slovy, `let z = x.wrapping_add((y as usize) - (x as usize))`*ne* dělá `z` stejně jako `y`, i když předpokládáme, že `T` má velikost `1` a nedochází k žádnému přetečení: `z` je stále připojen k objektu, ke kterému je `x` připojen, a dereferencováním je nedefinované chování, pokud `x` a `y` bod do stejného přiděleného objektu.
    ///
    /// Ve srovnání s [`add`] tato metoda v zásadě zpožďuje požadavek pobytu ve stejném přiděleném objektu: [`add`] je okamžité nedefinované chování při překračování hranic objektu;`wrapping_add` vytváří ukazatel, ale stále vede k nedefinovanému chování, pokud je ukazatel dereferencován, když je mimo hranice objektu, ke kterému je připojen.
    /// [`add`] lze optimalizovat lépe a je tedy výhodnější v kódu citlivém na výkon.
    ///
    /// Zpožděná kontrola bere v úvahu pouze hodnotu ukazatele, která byla dereferencována, nikoli mezilehlé hodnoty použité během výpočtu konečného výsledku.
    /// Například `x.wrapping_add(o).wrapping_sub(o)` je vždy stejný jako `x`.Jinými slovy je povoleno opustit přidělený objekt a poté jej znovu zadat později.
    ///
    /// Pokud potřebujete překročit hranice objektu, přetypujte ukazatel na celé číslo a proveďte tam aritmetiku.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// // Iterujte pomocí surového ukazatele v krocích po dvou prvcích
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Tato smyčka vytiskne "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Vypočítá posunutí od ukazatele pomocí aritmetiky obtékání.
    /// (výhoda pro `.wrapping_offset ((počítat jako isize).wrapping_neg())`)
    ///
    /// `count` je v jednotkách T;např. `count` 3 představuje posun ukazatele `3 * size_of::<T>()` bajtů.
    ///
    /// # Safety
    ///
    /// Samotná tato operace je vždy bezpečná, ale použití výsledného ukazatele není.
    ///
    /// Výsledný ukazatel zůstane připojen ke stejnému přidělenému objektu, na který `self` ukazuje.
    /// Může *nelze* použít pro přístup k jinému přidělenému objektu.Všimněte si, že v Rust je každá proměnná (stack-allocated) považována za samostatný přidělený objekt.
    ///
    /// Jinými slovy, `let z = x.wrapping_sub((x as usize) - (y as usize))`*ne* dělá `z` stejně jako `y`, i když předpokládáme, že `T` má velikost `1` a nedochází k žádnému přetečení: `z` je stále připojen k objektu, ke kterému je `x` připojen, a dereferencováním je nedefinované chování, pokud `x` a `y` bod do stejného přiděleného objektu.
    ///
    /// Ve srovnání s [`sub`] tato metoda v zásadě zpožďuje požadavek pobytu ve stejném přiděleném objektu: [`sub`] je okamžité nedefinované chování při překračování hranic objektu;`wrapping_sub` produkuje ukazatel, ale přesto vede k nedefinovanému chování, pokud je ukazatel dereferencován, když je mimo hranice objektu, ke kterému je připojen.
    /// [`sub`] lze optimalizovat lépe a je tedy výhodnější v kódu citlivém na výkon.
    ///
    /// Zpožděná kontrola bere v úvahu pouze hodnotu ukazatele, která byla dereferencována, nikoli mezilehlé hodnoty použité během výpočtu konečného výsledku.
    /// Například `x.wrapping_add(o).wrapping_sub(o)` je vždy stejný jako `x`.Jinými slovy je povoleno opustit přidělený objekt a poté jej znovu zadat později.
    ///
    /// Pokud potřebujete překročit hranice objektu, přetypujte ukazatel na celé číslo a proveďte tam aritmetiku.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// // Iterujte pomocí surového ukazatele v krocích po dvou prvcích (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Tato smyčka vytiskne "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Nastaví hodnotu ukazatele na `ptr`.
    ///
    /// V případě, že `self` je ukazatel (fat) na nezměněný typ, tato operace ovlivní pouze část ukazatele, zatímco u ukazatelů (thin) na velké typy to má stejný účinek jako jednoduché přiřazení.
    ///
    /// Výsledný ukazatel bude mít původ `val`, tj. U tučného ukazatele je tato operace sémanticky stejná jako vytváření nového tučného ukazatele s hodnotou datového ukazatele `val`, ale s metadaty `self`.
    ///
    ///
    /// # Examples
    ///
    /// Tato funkce je primárně užitečná pro povolení aritmetiky ukazatelů po bajtech na potenciálně tlustých ukazatelích:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // vytiskne "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // BEZPEČNOST: V případě tenkého ukazatele je tato operace identická
        // k jednoduchému úkolu.
        // V případě tlustého ukazatele je s aktuální implementací rozložení tlustého ukazatele prvním polem takového ukazatele vždy datový ukazatel, který je rovněž přiřazen.
        //
        unsafe { *thin = val };
        self
    }

    /// Přečte hodnotu z `self` bez jejího přesunutí.
    /// To ponechá paměť v `self` beze změny.
    ///
    /// Bezpečnostní problémy a příklady viz [`ptr::read`].
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro ``.
        unsafe { read(self) }
    }

    /// Provede volatilní čtení hodnoty z `self` bez jejího přesunutí.To ponechá paměť v `self` beze změny.
    ///
    /// Volatile operations are intended to act on I/O memory, and are guaranteed to not be elited or reordered by the compiler across other volatile operations.
    ///
    ///
    /// Bezpečnostní problémy a příklady viz [`ptr::read_volatile`].
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Přečte hodnotu z `self` bez jejího přesunutí.
    /// To ponechá paměť v `self` beze změny.
    ///
    /// Na rozdíl od `read` může být ukazatel nezarovnaný.
    ///
    /// Bezpečnostní problémy a příklady viz [`ptr::read_unaligned`].
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Kopíruje bajty `count * size_of<T>` z `self` do `dest`.
    /// Zdroj a cíl se mohou překrývat.
    ///
    /// NOTE: toto má *stejné* pořadí argumentů jako [`ptr::copy`].
    ///
    /// Bezpečnostní problémy a příklady viz [`ptr::copy`].
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Kopíruje bajty `count * size_of<T>` z `self` do `dest`.
    /// Zdroj a cíl se nemusí *překrývat*.
    ///
    /// NOTE: toto má *stejné* pořadí argumentů jako [`ptr::copy_nonoverlapping`].
    ///
    /// Bezpečnostní problémy a příklady viz [`ptr::copy_nonoverlapping`].
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Kopíruje bajty `count * size_of<T>` z `src` do `self`.
    /// Zdroj a cíl se mohou překrývat.
    ///
    /// NOTE: toto má *opačné* pořadí argumentů [`ptr::copy`].
    ///
    /// Bezpečnostní problémy a příklady viz [`ptr::copy`].
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Kopíruje bajty `count * size_of<T>` z `src` do `self`.
    /// Zdroj a cíl se nemusí *překrývat*.
    ///
    /// NOTE: toto má *opačné* pořadí argumentů [`ptr::copy_nonoverlapping`].
    ///
    /// Bezpečnostní problémy a příklady viz [`ptr::copy_nonoverlapping`].
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Spustí destruktor (pokud existuje) namířené hodnoty.
    ///
    /// Bezpečnostní problémy a příklady viz [`ptr::drop_in_place`].
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Přepíše místo v paměti zadanou hodnotou bez načtení nebo zrušení staré hodnoty.
    ///
    ///
    /// Bezpečnostní problémy a příklady viz [`ptr::write`].
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `write`.
        unsafe { write(self, val) }
    }

    /// Vyvolá memset na zadaném ukazateli a nastaví `count * size_of::<T>()` bajtů paměti od `self` do `val`.
    ///
    ///
    /// Bezpečnostní problémy a příklady viz [`ptr::write_bytes`].
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Provede volatilní zápis paměťového místa s danou hodnotou bez čtení nebo zrušení staré hodnoty.
    ///
    /// Volatile operations are intended to act on I/O memory, and are guaranteed to not be elited or reordered by the compiler across other volatile operations.
    ///
    ///
    /// Bezpečnostní problémy a příklady viz [`ptr::write_volatile`].
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Přepíše místo v paměti zadanou hodnotou bez načtení nebo zrušení staré hodnoty.
    ///
    ///
    /// Na rozdíl od `write` může být ukazatel nezarovnaný.
    ///
    /// Bezpečnostní problémy a příklady viz [`ptr::write_unaligned`].
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Nahradí hodnotu `self` `src`, vrátí starou hodnotu, aniž by došlo k jejímu zrušení.
    ///
    ///
    /// Bezpečnostní problémy a příklady viz [`ptr::replace`].
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `replace`.
        unsafe { replace(self, src) }
    }

    /// Zamění hodnoty na dvou proměnlivých místech stejného typu, aniž by došlo k deinicializaci.
    /// Mohou se překrývat, na rozdíl od `mem::swap`, který je jinak ekvivalentní.
    ///
    /// Bezpečnostní problémy a příklady viz [`ptr::swap`].
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `swap`.
        unsafe { swap(self, with) }
    }

    /// Vypočítá posun, který je třeba použít na ukazatel, aby byl zarovnaný s `align`.
    ///
    /// Pokud není možné zarovnat ukazatel, implementace vrátí `usize::MAX`.
    /// Je povoleno, aby implementace *vždy* vrátila `usize::MAX`.
    /// Pouze výkon vašeho algoritmu může záviset na získání použitelného offsetu zde, ne na jeho správnosti.
    ///
    /// Posun je vyjádřen v počtu prvků `T`, nikoli v bajtech.Vrácenou hodnotu lze použít s metodou `wrapping_add`.
    ///
    /// Neexistují vůbec žádné záruky, že kompenzace ukazatele nepřeteče nebo nepřesáhne alokaci, na kterou ukazatel ukazuje.
    ///
    /// Je na volajícím, aby zajistil, že vrácené posunutí je správné ve všech podmínkách jiných než zarovnání.
    ///
    /// # Panics
    ///
    /// Funkce panics, pokud `align` není mocninou dvou.
    ///
    /// # Examples
    ///
    /// Přístup k sousedním `u8` jako `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // zatímco ukazatel lze zarovnat pomocí `offset`, směřoval by mimo alokaci
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // BEZPEČNOST: `align` byl zkontrolován jako výkon 2 výše
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Vrátí délku surového řezu.
    ///
    /// Vrácená hodnota je počet **prvků**, nikoli počet bajtů.
    ///
    /// Tato funkce je bezpečná, i když surový řez nelze přenést na odkaz řezu, protože ukazatel je null nebo nezarovnaný.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // BEZPEČNOST: je to bezpečné, protože `*const [T]` a `FatPtr<T>` mají stejné rozložení.
            // Tuto záruku může poskytnout pouze `std`.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Vrátí surový ukazatel do vyrovnávací paměti řezu.
    ///
    /// To je ekvivalent k odlévání `self` do `*mut T`, ale bezpečnější pro typ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Vrátí nezpracovaný ukazatel na prvek nebo podřízený řez, aniž by bylo nutné kontrolovat hranice.
    ///
    /// Volání této metody s indexem out-of-bounds nebo když `self` není dereferencable je *[nedefinované chování]*, i když výsledný ukazatel není použit.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // BEZPEČNOST: volající zajišťuje, že `self` je dereferencable a `index` v mezích.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Vrátí `None`, pokud má ukazatel hodnotu null, jinak vrátí sdílený řez na hodnotu zabalenou v `Some`.
    /// Na rozdíl od [`as_ref`] to nevyžaduje inicializaci hodnoty.
    ///
    /// Pro proměnlivý protějšek viz [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Při volání této metody musíte zajistit, aby *buď* ukazatel měl hodnotu NULL *nebo* všechny následující hodnoty:
    ///
    /// * Ukazatel musí být [valid] pro čtení pro `ptr.len() * mem::size_of::<T>()` mnoho bajtů a musí být správně zarovnán.To znamená zejména:
    ///
    ///     * Celý rozsah paměti tohoto řezu musí být obsažen v jednom přiděleném objektu!
    ///       Řezy se nikdy nemohou rozprostřít přes více přidělených objektů.
    ///
    ///     * Ukazatel musí být zarovnán i pro řezy nulové délky.
    ///     Jedním z důvodů je to, že optimalizace výčtu výčtu se může spoléhat na to, že odkazy (včetně řezů libovolné délky) jsou zarovnány a nenulové, aby se odlišily od ostatních dat.
    ///
    ///     Ukazatel, který je použitelný jako `data` pro řezy nulové délky, můžete získat pomocí [`NonNull::dangling()`].
    ///
    /// * Celková velikost řezu `ptr.len() * mem::size_of::<T>()` nesmí být větší než `isize::MAX`.
    ///   Viz bezpečnostní dokumentace [`pointer::offset`].
    ///
    /// * Musíte vynutit pravidla aliasingu Rust, protože vrácená životnost `'a` je zvolena libovolně a nemusí nutně odrážet skutečnou životnost dat.
    ///   Zejména po dobu tohoto života nesmí dojít k mutaci paměti, na kterou ukazatel ukazuje, (kromě uvnitř `UnsafeCell`).
    ///
    /// To platí, i když je výsledek této metody nepoužitý!
    ///
    /// Viz také [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Vrátí `None`, pokud má ukazatel hodnotu null, jinak vrátí jedinečný řez na hodnotu zabalenou v `Some`.
    /// Na rozdíl od [`as_mut`] to nevyžaduje inicializaci hodnoty.
    ///
    /// Sdílené protějšky viz [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Při volání této metody musíte zajistit, aby *buď* ukazatel měl hodnotu NULL *nebo* všechny následující hodnoty:
    ///
    /// * Ukazatel musí být [valid] pro čtení a zápis pro `ptr.len() * mem::size_of::<T>()` mnoho bajtů a musí být správně zarovnán.To znamená zejména:
    ///
    ///     * Celý rozsah paměti tohoto řezu musí být obsažen v jednom přiděleném objektu!
    ///       Řezy se nikdy nemohou rozprostřít přes více přidělených objektů.
    ///
    ///     * Ukazatel musí být zarovnán i pro řezy nulové délky.
    ///     Jedním z důvodů je to, že optimalizace výčtu výčtu se může spoléhat na to, že odkazy (včetně řezů libovolné délky) jsou zarovnány a nenulové, aby se odlišily od ostatních dat.
    ///
    ///     Ukazatel, který je použitelný jako `data` pro řezy nulové délky, můžete získat pomocí [`NonNull::dangling()`].
    ///
    /// * Celková velikost řezu `ptr.len() * mem::size_of::<T>()` nesmí být větší než `isize::MAX`.
    ///   Viz bezpečnostní dokumentace [`pointer::offset`].
    ///
    /// * Musíte vynutit pravidla aliasingu Rust, protože vrácená životnost `'a` je zvolena libovolně a nemusí nutně odrážet skutečnou životnost dat.
    ///   Zejména po dobu tohoto života nesmí do paměti, na kterou ukazatel směřuje, získat přístup (čtení ani zápis) prostřednictvím jiného ukazatele.
    ///
    /// To platí, i když je výsledek této metody nepoužitý!
    ///
    /// Viz také [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Rovnost pro ukazatele
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}