#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` umožňuje implementátoru prováděcího úkolu vytvořit [`Waker`], který poskytuje přizpůsobené chování při probuzení.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Skládá se z datového ukazatele a [virtual function pointer table (vtable)][vtable], který přizpůsobuje chování `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Ukazatel dat, který lze použít k uložení libovolných dat podle požadavků exekutora.
    /// Může to být např
    /// ukazatel vymazaného typu na `Arc`, který je přidružen k úkolu.
    /// Hodnota tohoto pole se předá všem funkcím, které jsou součástí vtable jako první parametr.
    ///
    data: *const (),
    /// Tabulka ukazatelů virtuální funkce, která upravuje chování tohoto probuzení.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Vytvoří nový `RawWaker` z poskytnutého ukazatele `data` a `vtable`.
    ///
    /// Ukazatel `data` lze použít k uložení libovolných dat podle požadavků exekutora.Může to být např
    /// ukazatel vymazaného typu na `Arc`, který je přidružen k úkolu.
    /// Hodnota tohoto ukazatele bude předána všem funkcím, které jsou součástí `vtable` jako první parametr.
    ///
    /// `vtable` upravuje chování `Waker`, který je vytvořen z `RawWaker`.
    /// Pro každou operaci na `Waker` bude vyvolána přidružená funkce v `vtable` podkladového `RawWaker`.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Tabulka ukazatelů virtuální funkce (vtable), která určuje chování [`RawWaker`].
///
/// Ukazatel předaný všem funkcím uvnitř vtable je ukazatel `data` z obklopujícího objektu [`RawWaker`].
///
/// Funkce uvnitř této struktury jsou určeny pouze k volání na ukazatel `data` správně vytvořeného objektu [`RawWaker`] zevnitř implementace [`RawWaker`].
/// Volání jedné z obsažených funkcí pomocí jiného ukazatele `data` způsobí nedefinované chování.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Tato funkce bude vyvolána při klonování [`RawWaker`], např. Při klonování [`Waker`], ve kterém je [`RawWaker`] uložen.
    ///
    /// Implementace této funkce musí zachovat všechny prostředky, které jsou vyžadovány pro tuto další instanci [`RawWaker`] a přidruženou úlohu.
    /// Volání `wake` na výsledném [`RawWaker`] by mělo vést k probuzení stejného úkolu, který by probudil původní [`RawWaker`].
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Tato funkce bude vyvolána, když je na [`Waker`] volána `wake`.
    /// Musí probudit úkol spojený s tímto [`RawWaker`].
    ///
    /// Implementace této funkce musí zajistit uvolnění veškerých prostředků, které jsou přidruženy k této instanci [`RawWaker`] a přidružené úlohy.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Tato funkce bude vyvolána, když je na [`Waker`] volána `wake_by_ref`.
    /// Musí probudit úkol spojený s tímto [`RawWaker`].
    ///
    /// Tato funkce je podobná `wake`, ale nesmí využívat uvedený datový ukazatel.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Tato funkce se zavolá, když dojde k pádu [`RawWaker`].
    ///
    /// Implementace této funkce musí zajistit uvolnění veškerých prostředků, které jsou přidruženy k této instanci [`RawWaker`] a přidružené úlohy.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Vytvoří nový `RawWakerVTable` z poskytovaných funkcí `clone`, `wake`, `wake_by_ref` a `drop`.
    ///
    /// # `clone`
    ///
    /// Tato funkce bude vyvolána při klonování [`RawWaker`], např. Při klonování [`Waker`], ve kterém je [`RawWaker`] uložen.
    ///
    /// Implementace této funkce musí zachovat všechny prostředky, které jsou vyžadovány pro tuto další instanci [`RawWaker`] a přidruženou úlohu.
    /// Volání `wake` na výsledném [`RawWaker`] by mělo vést k probuzení stejného úkolu, který by probudil původní [`RawWaker`].
    ///
    /// # `wake`
    ///
    /// Tato funkce bude vyvolána, když je na [`Waker`] volána `wake`.
    /// Musí probudit úkol spojený s tímto [`RawWaker`].
    ///
    /// Implementace této funkce musí zajistit uvolnění veškerých prostředků, které jsou přidruženy k této instanci [`RawWaker`] a přidružené úlohy.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Tato funkce bude vyvolána, když je na [`Waker`] volána `wake_by_ref`.
    /// Musí probudit úkol spojený s tímto [`RawWaker`].
    ///
    /// Tato funkce je podobná `wake`, ale nesmí využívat uvedený datový ukazatel.
    ///
    /// # `drop`
    ///
    /// Tato funkce se zavolá, když dojde k pádu [`RawWaker`].
    ///
    /// Implementace této funkce musí zajistit uvolnění veškerých prostředků, které jsou přidruženy k této instanci [`RawWaker`] a přidružené úlohy.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` asynchronního úkolu.
///
/// V současné době `Context` slouží pouze k poskytnutí přístupu k `&Waker`, který lze použít k probuzení aktuální úlohy.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Ujistěte se, že jsme future-důkaz proti změnám rozptylu tím, že vynutíte, aby životnost byla neměnná (doby životnosti pozice argumentu jsou v rozporu, zatímco doby života návratové polohy jsou kovariantní).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Vytvořte nový `Context` z `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Vrátí odkaz na `Waker` pro aktuální úkol.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` je popisovač pro probuzení úkolu oznámením jeho vykonavateli, že je připraven ke spuštění.
///
/// Tento popisovač zapouzdřuje instanci [`RawWaker`], která definuje chování při probuzení specifické pro exekutora.
///
///
/// Implementuje [`Clone`], [`Send`] a [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Probuďte úkol spojený s tímto `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Skutečné probuzení je delegováno prostřednictvím volání virtuální funkce na implementaci, která je definována exekutorem.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Nevolejte `drop`-buditel bude spotřebován `wake`.
        crate::mem::forget(self);

        // BEZPEČNOST: Je to bezpečné, protože `Waker::from_raw` je jediný způsob
        // inicializovat `wake` a `data` vyžadující, aby uživatel potvrdil, že je smlouva `RawWaker` potvrzena.
        //
        unsafe { (wake)(data) };
    }

    /// Probuďte úkol spojený s tímto `Waker`, aniž byste spotřebovali `Waker`.
    ///
    /// Je to podobné jako u `wake`, ale může to být o něco méně efektivní v případě, že je k dispozici vlastněná `Waker`.
    /// Tato metoda by měla být upřednostňována před voláním `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Skutečné probuzení je delegováno prostřednictvím volání virtuální funkce na implementaci, která je definována exekutorem.
        //

        // BEZPEČNOST: viz `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Vrátí `true`, pokud tento `Waker` a další `Waker` probudili stejný úkol.
    ///
    /// Tato funkce funguje na základě nejlepšího úsilí a může se vrátit nepravdivě, i když by `Waker`s probudil stejný úkol.
    /// Pokud však tato funkce vrátí `true`, je zaručeno, že program `Waker`s probudí stejný úkol.
    ///
    /// Tato funkce se primárně používá pro účely optimalizace.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Vytvoří nový `Waker` z [`RawWaker`].
    ///
    /// Chování vrácené `Waker` není definováno, pokud smlouva definovaná v dokumentaci [" RawWaker`] a [" RawWakerVTable`] `není potvrzena.
    ///
    /// Proto je tato metoda nebezpečná.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // BEZPEČNOST: Je to bezpečné, protože `Waker::from_raw` je jediný způsob
            // inicializovat `clone` a `data` vyžadující, aby uživatel potvrdil, že je smlouva [`RawWaker`] potvrzena.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // BEZPEČNOST: Je to bezpečné, protože `Waker::from_raw` je jediný způsob
        // inicializovat `drop` a `data` vyžadující, aby uživatel potvrdil, že je smlouva `RawWaker` potvrzena.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}