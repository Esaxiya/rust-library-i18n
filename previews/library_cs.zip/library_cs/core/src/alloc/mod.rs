//! Rozhraní API pro přidělování paměti

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Chyba `AllocError` označuje selhání přidělení, které může být způsobeno vyčerpáním prostředků nebo něčím špatným při kombinaci zadaných vstupních argumentů s tímto alokátorem.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (potřebujeme to pro následný impl chyby trait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Implementace `Allocator` může přidělit, růst, zmenšit a uvolnit libovolné bloky dat popsaných prostřednictvím [`Layout`][].
///
/// `Allocator` je navržen tak, aby byl implementován na ZST, referencích nebo inteligentních ukazatelích, protože nelze přidělit alokátor jako `MyAlloc([u8; N])` přesunout bez aktualizace ukazatelů do přidělené paměti.
///
/// Na rozdíl od [`GlobalAlloc`][] jsou v `Allocator` povolena alokace nulové velikosti.
/// Pokud podkladový alokátor toto nepodporuje (například jemalloc) nebo vrací nulový ukazatel (například `libc::malloc`), musí to implementace zachytit.
///
/// ### Aktuálně přidělená paměť
///
/// Některé z metod vyžadují, aby byl blok paměti *aktuálně přidělen* prostřednictvím alokátoru.Tohle znamená tamto:
///
/// * počáteční adresa daného paměťového bloku byla dříve vrácena [`allocate`], [`grow`] nebo [`shrink`] a
///
/// * blok paměti nebyl následně uvolněn, kde bloky jsou uvolněny přímo předáním [`deallocate`] nebo byly změněny předáním [`grow`] nebo [`shrink`], které vrací `Ok`.
///
/// Pokud `grow` nebo `shrink` vrátili `Err`, předaný ukazatel zůstane platný.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Přizpůsobení paměti
///
/// Některé z metod vyžadují, aby rozložení *vyhovovalo* paměťovému bloku.
/// To znamená, že pro rozvržení do "fit" znamená paměťový blok (nebo ekvivalentně pro paměťový blok do "fit" rozvržení), že musí platit následující podmínky:
///
/// * Blok musí být přiřazen se stejným zarovnáním jako [`layout.align()`] a
///
/// * Poskytnutý [`layout.size()`] musí spadat do rozsahu `min ..= max`, kde:
///   - `min` je velikost rozložení, které bylo naposledy použito k přidělení bloku, a
///   - `max` je nejnovější skutečná velikost vrácená z [`allocate`], [`grow`] nebo [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Bloky paměti vrácené z alokátoru musí ukazovat na platnou paměť a zachovat si jejich platnost, dokud instance a všechny její klony nebudou zrušeny,
///
/// * klonování nebo přesunutí alokátoru nesmí zneplatnit paměťové bloky vrácené z tohoto alokátoru.Klonovaný alokátor se musí chovat jako stejný alokátor a
///
/// * jakýkoli ukazatel na blok paměti, který je [*currently allocated*], může být předán jakékoli jiné metodě alokátoru.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Pokusy o přidělení bloku paměti.
    ///
    /// Při úspěchu vrátí [`NonNull<[u8]>`][NonNull] splňující záruky velikosti a zarovnání `layout`.
    ///
    /// Vrácený blok může mít větší velikost, než je specifikováno `layout.size()`, a může nebo nemusí mít inicializovaný jeho obsah.
    ///
    /// # Errors
    ///
    /// Vrácení `Err` znamená, že buď je paměť vyčerpaná, nebo `layout` nesplňuje omezení velikosti a zarovnání alokátoru.
    ///
    /// Implementacím se doporučuje vrátit `Err` na vyčerpání paměti, nikoli na paniku nebo přerušení, ale nejde o přísný požadavek.
    /// (Konkrétně: je *legální* implementovat tento trait na vrcholu podkladové nativní alokační knihovny, která se přeruší při vyčerpání paměti.)
    ///
    /// Klientům, kteří chtějí přerušit výpočet v reakci na chybu přidělení, se doporučuje volat funkci [`handle_alloc_error`], místo aby přímo vyvolali `panic!` nebo podobné.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Chová se jako `allocate`, ale také zajišťuje, že se vrácená paměť nula inicializuje.
    ///
    /// # Errors
    ///
    /// Vrácení `Err` znamená, že buď je paměť vyčerpaná, nebo `layout` nesplňuje omezení velikosti a zarovnání alokátoru.
    ///
    /// Implementacím se doporučuje vrátit `Err` na vyčerpání paměti, nikoli na paniku nebo přerušení, ale nejde o přísný požadavek.
    /// (Konkrétně: je *legální* implementovat tento trait na vrcholu podkladové nativní alokační knihovny, která se přeruší při vyčerpání paměti.)
    ///
    /// Klientům, kteří chtějí přerušit výpočet v reakci na chybu přidělení, se doporučuje volat funkci [`handle_alloc_error`], místo aby přímo vyvolali `panic!` nebo podobné.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // BEZPEČNOST: `alloc` vrací platný blok paměti
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Dealokuje paměť, na kterou odkazuje `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` musí označovat blok paměti [*currently allocated*] prostřednictvím tohoto alokátoru a
    /// * `layout` musí [*fit*] ten blok paměti.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Pokusy o rozšíření bloku paměti.
    ///
    /// Vrátí nový [`NonNull<[u8]>`][NonNull] obsahující ukazatel a skutečnou velikost přidělené paměti.Ukazatel je vhodný pro uchovávání dat popsaných `new_layout`.
    /// Za tímto účelem může alokátor rozšířit alokaci odkazovanou `ptr` tak, aby odpovídala novému rozložení.
    ///
    /// Pokud toto vrátí `Ok`, pak vlastnictví paměťového bloku odkazovaného `ptr` bylo přeneseno do tohoto alokátoru.
    /// Paměť může nebo nemusí být uvolněna a měla by být považována za nepoužitelnou, pokud nebyla znovu přenesena zpět na volajícího prostřednictvím návratové hodnoty této metody.
    ///
    /// Pokud tato metoda vrátí `Err`, pak vlastnictví bloku paměti nebylo přeneseno do tohoto alokátoru a obsah bloku paměti bude nezměněn.
    ///
    /// # Safety
    ///
    /// * `ptr` musí označovat blok paměti [*currently allocated*] prostřednictvím tohoto alokátoru.
    /// * `old_layout` musí [*fit*] ten blok paměti (Argument `new_layout` to nemusí odpovídat.).
    /// * `new_layout.size()` musí být větší nebo rovno `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Vrátí `Err`, pokud nové rozložení nesplňuje omezení alokačního omezení alokátoru alokátoru, nebo pokud růst selže jinak.
    ///
    /// Implementacím se doporučuje vrátit `Err` na vyčerpání paměti, nikoli na paniku nebo přerušení, ale nejde o přísný požadavek.
    /// (Konkrétně: je *legální* implementovat tento trait na vrcholu podkladové nativní alokační knihovny, která se přeruší při vyčerpání paměti.)
    ///
    /// Klientům, kteří chtějí přerušit výpočet v reakci na chybu přidělení, se doporučuje volat funkci [`handle_alloc_error`], místo aby přímo vyvolali `panic!` nebo podobné.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // BEZPEČNOST: protože `new_layout.size()` musí být větší nebo roven
        // `old_layout.size()`, stará i nová alokace paměti jsou platné pro čtení a zápis pro `old_layout.size()` bajtů.
        // Také proto, že stará alokace ještě nebyla uvolněna, nemůže překrývat `new_ptr`.
        // Volání na `copy_nonoverlapping` je tedy bezpečné.
        // Bezpečnostní smlouva pro `dealloc` musí být potvrzena volajícím.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Chová se jako `grow`, ale také zajišťuje, že nový obsah je před vrácením nastaven na nulu.
    ///
    /// Blok paměti bude obsahovat následující obsah po úspěšném volání
    /// `grow_zeroed`:
    ///   * Bajty `0..old_layout.size()` jsou zachovány z původního přidělení.
    ///   * Bajty `old_layout.size()..old_size` budou buď zachovány, nebo vynulovány, v závislosti na implementaci alokátoru.
    ///   `old_size` odkazuje na velikost bloku paměti před voláním `grow_zeroed`, která může být větší než velikost, která byla původně požadována, když byla přidělena.
    ///   * Bajty `old_size..new_size` jsou vynulovány.`new_size` odkazuje na velikost bloku paměti vráceného voláním `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` musí označovat blok paměti [*currently allocated*] prostřednictvím tohoto alokátoru.
    /// * `old_layout` musí [*fit*] ten blok paměti (Argument `new_layout` to nemusí odpovídat.).
    /// * `new_layout.size()` musí být větší nebo rovno `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Vrátí `Err`, pokud nové rozložení nesplňuje omezení alokačního omezení alokátoru alokátoru, nebo pokud růst selže jinak.
    ///
    /// Implementacím se doporučuje vrátit `Err` na vyčerpání paměti, nikoli na paniku nebo přerušení, ale nejde o přísný požadavek.
    /// (Konkrétně: je *legální* implementovat tento trait na vrcholu podkladové nativní alokační knihovny, která se přeruší při vyčerpání paměti.)
    ///
    /// Klientům, kteří chtějí přerušit výpočet v reakci na chybu přidělení, se doporučuje volat funkci [`handle_alloc_error`], místo aby přímo vyvolali `panic!` nebo podobné.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // BEZPEČNOST: protože `new_layout.size()` musí být větší nebo roven
        // `old_layout.size()`, stará i nová alokace paměti jsou platné pro čtení a zápis pro `old_layout.size()` bajtů.
        // Také proto, že stará alokace ještě nebyla uvolněna, nemůže překrývat `new_ptr`.
        // Volání na `copy_nonoverlapping` je tedy bezpečné.
        // Bezpečnostní smlouva pro `dealloc` musí být potvrzena volajícím.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Pokusy o zmenšení bloku paměti.
    ///
    /// Vrátí nový [`NonNull<[u8]>`][NonNull] obsahující ukazatel a skutečnou velikost přidělené paměti.Ukazatel je vhodný pro uchovávání dat popsaných `new_layout`.
    /// Za tímto účelem může alokátor zmenšit alokaci, na kterou odkazuje `ptr`, aby se vešla do nového rozložení.
    ///
    /// Pokud toto vrátí `Ok`, pak vlastnictví paměťového bloku odkazovaného `ptr` bylo přeneseno do tohoto alokátoru.
    /// Paměť může nebo nemusí být uvolněna a měla by být považována za nepoužitelnou, pokud nebyla znovu přenesena zpět na volajícího prostřednictvím návratové hodnoty této metody.
    ///
    /// Pokud tato metoda vrátí `Err`, pak vlastnictví bloku paměti nebylo přeneseno do tohoto alokátoru a obsah bloku paměti bude nezměněn.
    ///
    /// # Safety
    ///
    /// * `ptr` musí označovat blok paměti [*currently allocated*] prostřednictvím tohoto alokátoru.
    /// * `old_layout` musí [*fit*] ten blok paměti (Argument `new_layout` to nemusí odpovídat.).
    /// * `new_layout.size()` musí být menší nebo rovno `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Vrátí `Err`, pokud nové rozložení nesplňuje omezení alokačního omezení alokátoru alokátoru, nebo pokud zmenšení jinak selže.
    ///
    /// Implementacím se doporučuje vrátit `Err` na vyčerpání paměti, nikoli na paniku nebo přerušení, ale nejde o přísný požadavek.
    /// (Konkrétně: je *legální* implementovat tento trait na vrcholu podkladové nativní alokační knihovny, která se přeruší při vyčerpání paměti.)
    ///
    /// Klientům, kteří chtějí přerušit výpočet v reakci na chybu přidělení, se doporučuje volat funkci [`handle_alloc_error`], místo aby přímo vyvolali `panic!` nebo podobné.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // BEZPEČNOST: protože `new_layout.size()` musí být nižší nebo roven
        // `old_layout.size()`, stará i nová alokace paměti jsou platné pro čtení a zápis pro `new_layout.size()` bajtů.
        // Také proto, že stará alokace ještě nebyla uvolněna, nemůže překrývat `new_ptr`.
        // Volání na `copy_nonoverlapping` je tedy bezpečné.
        // Bezpečnostní smlouva pro `dealloc` musí být potvrzena volajícím.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Vytvoří adaptér "by reference" pro tuto instanci `Allocator`.
    ///
    /// Vrácený adaptér také implementuje `Allocator` a jednoduše si ho vypůjčí.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}