use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// I když je tato funkce používána na jednom místě a její implementace by mohla být inline, předchozí pokusy o to rustc pomaleji:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Rozložení bloku paměti.
///
/// Instance `Layout` popisuje konkrétní rozložení paměti.
/// Vytvoříte `Layout` jako vstup, který přidělíte alokátoru.
///
/// Všechna rozvržení mají přidruženou velikost a vyrovnání síly dvou.
///
/// (Všimněte si, že rozložení *nemusí* mít nenulovou velikost, i když `GlobalAlloc` vyžaduje, aby všechny požadavky na paměť byly nenulové.
/// Volající musí buď zajistit splnění takových podmínek, použít konkrétní alokátory s volnějšími požadavky, nebo použít mírnější rozhraní `Allocator`.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // velikost požadovaného bloku paměti, měřeno v bajtech.
    size_: usize,

    // zarovnání požadovaného bloku paměti, měřeno v bajtech.
    // zajistíme, aby se vždy jednalo o mocninu dvou, protože API jako `posix_memalign` to vyžadují a je to rozumné omezení, které je třeba uložit konstruktorům Layout.
    //
    //
    // (Analogicky však nevyžadujeme `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Vytvoří `Layout` z daného `size` a `align`, nebo vrátí `LayoutError`, pokud není splněna některá z následujících podmínek:
    ///
    /// * `align` nesmí být nula,
    ///
    /// * `align` musí být síla dvou,
    ///
    /// * `size`, při zaokrouhlování nahoru na nejbližší násobek `align` nesmí přetékat (tj. zaokrouhlená hodnota musí být menší nebo rovna `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (mocnina dvou znamená zarovnání!=0.)

        // Zaokrouhlená velikost je:
        //   size_rounded_up=(size + align, 1)&! (align, 1);
        //
        // Z výše uvedeného víme, že zarovnání!=0.
        // Pokud přidání (zarovnání, 1) nepřetéká, bude zaokrouhlování nahoru v pořádku.
        //
        // Naopak&-masking s! (Zarovnání, 1) odečte pouze bity nižšího řádu.
        // Pokud tedy k součtu dojde k přetečení,&-mask nemůže dostatečně odečíst, aby toto přetečení zrušilo.
        //
        //
        // Výše uvedené znamená, že kontrola přetečení součtu je nezbytná i dostatečná.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // BEZPEČNOST: podmínky pro `from_size_align_unchecked` byly
        // zkontrolováno výše.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Vytvoří rozložení, obejde všechny kontroly.
    ///
    /// # Safety
    ///
    /// Tato funkce je nebezpečná, protože neověřuje předpoklady z [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // BEZPEČNOST: volající musí zajistit, aby hodnota `align` byla větší než nula.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Minimální velikost v bajtech pro blok paměti tohoto rozložení.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Minimální zarovnání bajtů pro blok paměti tohoto rozložení.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Vytvoří `Layout` vhodný pro uchování hodnoty typu `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // BEZPEČNOST: Zarovnání je zaručeno Rust jako síla dvou a
        // kombinace combo size + align je zaručeno, že se vejde do našeho adresního prostoru.
        // Ve výsledku použijte nekontrolovaný konstruktor, abyste se vyhnuli vložení kódu panics, pokud není dostatečně optimalizován.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produkuje rozložení popisující záznam, který lze použít k alokaci podpůrné struktury pro `T` (což může být trait nebo jiný typ bez velikosti, například řez).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // BEZPEČNOST: proč to používá nebezpečnou variantu, viz odůvodnění v `new`
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produkuje rozložení popisující záznam, který lze použít k alokaci podpůrné struktury pro `T` (což může být trait nebo jiný typ bez velikosti, například řez).
    ///
    /// # Safety
    ///
    /// Tuto funkci lze bezpečně volat, pouze pokud jsou splněny následující podmínky:
    ///
    /// - Pokud `T` je `Sized`, tato funkce je vždy bezpečná pro volání.
    /// - Pokud je ocas `T` bez velikosti:
    ///     - a [slice], pak délka ocasu řezu musí být intializované celé číslo a velikost *celé hodnoty*(délka dynamického ocasu + předpona staticky velikosti) musí odpovídat `isize`.
    ///     - a [trait object], pak musí vtable část ukazatele ukazovat na platnou vtable pro typ `T` získaný nesměrovou koerzí a velikost *celé hodnoty*(dynamická délka ocasu + předpona staticky velikosti) se musí vejít do `isize`.
    ///
    ///     - (unstable) [extern type], pak je tato funkce vždy bezpečná, ale může panic nebo jinak vrátit nesprávnou hodnotu, protože není známo rozložení externího typu.
    ///     Toto je stejné chování jako [`Layout::for_value`] u odkazu na ocas externího typu.
    ///     - jinak není konzervativně povoleno volat tuto funkci.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // BEZPEČNOST: předáváme předpoklady těchto funkcí volajícímu
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // BEZPEČNOST: proč to používá nebezpečnou variantu, viz odůvodnění v `new`
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Vytvoří houpající se `NonNull`, ale pro toto rozložení dobře zarovnané.
    ///
    /// Všimněte si, že hodnota ukazatele může potenciálně představovat platný ukazatel, což znamená, že se nesmí používat jako hodnota sentinelu "not yet initialized".
    /// Typy, které líně přidělují, musí sledovat inicializaci nějakými jinými prostředky.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // BEZPEČNOST: Zarovnání je zaručeno nenulové
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Vytvoří rozložení popisující záznam, které může obsahovat hodnotu stejného rozložení jako `self`, ale které je také zarovnáno k zarovnání `align` (měřeno v bajtech).
    ///
    ///
    /// Pokud `self` již splňuje předepsané zarovnání, vrátí `self`.
    ///
    /// Všimněte si, že tato metoda nepřidá žádné vycpávky k celkové velikosti, bez ohledu na to, zda má vrácené rozložení jiné zarovnání.
    /// Jinými slovy, pokud má `K` velikost 16, `K.align_to(32)` bude *stále* mít velikost 16.
    ///
    /// Vrátí chybu, pokud kombinace `self.size()` a daného `align` porušuje podmínky uvedené v [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Vrátí množství odsazení, které musíme vložit za `self`, abychom zajistili, že následující adresa uspokojí `align` (měřeno v bajtech).
    ///
    /// např. pokud `self.size()` je 9, pak `self.padding_needed_for(4)` vrátí 3, protože to je minimální počet bajtů výplně požadovaný pro získání adresy 4 zarovnané (za předpokladu, že odpovídající blok paměti začíná na adrese 4 zarovnané).
    ///
    ///
    /// Návratová hodnota této funkce nemá žádný význam, pokud `align` není mocninou dvou.
    ///
    /// Všimněte si, že obslužnost vrácené hodnoty vyžaduje, aby `align` byla menší nebo rovna zarovnání počáteční adresy pro celý přidělený blok paměti.Jedním ze způsobů, jak uspokojit toto omezení, je zajistit `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Zaokrouhlená hodnota je:
        //   len_rounded_up=(len + zarovnat, 1)&! (zarovnat, 1);
        // a pak vrátíme výplňový rozdíl: `len_rounded_up - len`.
        //
        // Modulární aritmetiku používáme v celém rozsahu:
        //
        // 1. Zarovnání je zaručeně> 0, takže Zarovnání, 1 je vždy platné.
        //
        // 2.
        // `len + align - 1` může přetékat maximálně `align - 1`, takže&-mask s `!(align - 1)` zajistí, že v případě přetečení bude `len_rounded_up` sám o sobě 0.
        //
        //    Když je tedy vrácená výplň přidána k `len`, dává 0, což triviálně splňuje zarovnání `align`.
        //
        // (Samozřejmě, pokusy o alokaci bloků paměti, jejichž velikost a výplň přetečou výše uvedeným způsobem, by stejně způsobily, že alokátor způsobí chybu.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Vytvoří rozložení zaokrouhlením velikosti tohoto rozložení na násobek zarovnání rozložení.
    ///
    ///
    /// To je ekvivalentní přidání výsledku `padding_needed_for` k aktuální velikosti rozložení.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // To nemůže přetéct.Citace z invariantu Layout:
        // > `size`, po zaokrouhlení nahoru na nejbližší násobek `align`,
        // > nesmí přetékat (tj. zaokrouhlená hodnota musí být menší než
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Vytvoří rozložení popisující záznam pro instance `n` z `self`, s vhodným množstvím odsazení mezi každou, aby bylo zajištěno, že každé instanci bude dána požadovaná velikost a zarovnání.
    /// Při úspěchu vrátí `(k, offs)`, kde `k` je rozložení pole a `offs` je vzdálenost mezi začátkem každého prvku v poli.
    ///
    /// Při aritmetickém přetečení vrátí `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // To nemůže přetéct.Citace z invariantu Layout:
        // > `size`, po zaokrouhlení nahoru na nejbližší násobek `align`,
        // > nesmí přetékat (tj. zaokrouhlená hodnota musí být menší než
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // BEZPEČNOST: O self.align je již známo, že je platný, a alloc_size již byl
        // již polstrované.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Vytvoří rozložení popisující záznam pro `self` následovaný `next`, včetně všech nezbytných výplní, aby bylo zajištěno, že `next` bude správně zarovnán, ale *žádné koncové výplně*.
    ///
    /// Chcete-li odpovídat rozložení reprezentace C `repr(C)`, měli byste po rozšíření rozložení o všechna pole zavolat `pad_to_align`.
    /// (Neexistuje způsob, jak se shodovat s výchozím rozložením reprezentace Rust `repr(Rust)`, as it is unspecified.)
    ///
    /// Všimněte si, že zarovnání výsledného rozvržení bude maximální jako u `self` a `next`, aby bylo zajištěno zarovnání obou částí.
    ///
    /// Vrátí `Ok((k, offset))`, kde `k` je rozložení zřetězeného záznamu a `offset` je relativní umístění v bajtech začátku `next` vloženého do zřetězeného záznamu (za předpokladu, že samotný záznam začíná na offsetu 0).
    ///
    ///
    /// Při aritmetickém přetečení vrátí `LayoutError`.
    ///
    /// # Examples
    ///
    /// Výpočet rozložení struktury `#[repr(C)]` a offsetů polí z rozložení polí:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Nezapomeňte finalizovat s `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // vyzkoušejte, že to funguje
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Vytvoří rozložení popisující záznam pro instance `n` z `self`, bez výplně mezi každou instancí.
    ///
    /// Všimněte si, že na rozdíl od `repeat`, `repeat_packed` nezaručuje, že opakované instance `self` budou správně zarovnány, i když je daná instance `self` správně zarovnána.
    /// Jinými slovy, pokud se k přidělení pole použije rozložení vrácené `repeat_packed`, není zaručeno, že všechny prvky v poli budou správně zarovnány.
    ///
    /// Při aritmetickém přetečení vrátí `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Vytvoří rozložení popisující záznam pro `self` následovaný `next` bez dalšího polstrování mezi těmito dvěma.
    /// Vzhledem k tomu, že není vložena žádná výplň, je zarovnání `next` irelevantní a není do výsledného rozložení zahrnuto *vůbec*.
    ///
    ///
    /// Při aritmetickém přetečení vrátí `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Vytvoří rozložení popisující záznam pro `[T; n]`.
    ///
    /// Při aritmetickém přetečení vrátí `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Parametry dané `Layout::from_size_align` nebo nějakému jinému konstruktoru `Layout` nesplňují jeho dokumentovaná omezení.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (potřebujeme to pro následný impl chyby trait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}