//! Traits pro převody mezi typy.
//!
//! traits v tomto modulu poskytují způsob převodu z jednoho typu na jiný.
//! Každá trait slouží jinému účelu:
//!
//! - Implementujte [`AsRef`] trait pro levné převody typu reference-to-reference
//! - Implementujte [`AsMut`] trait pro levné konverze mezi proměnnými
//! - Implementujte [`From`] trait pro náročné převody mezi hodnotami
//! - Implementujte [`Into`] trait pro náročné převody hodnoty na hodnotu pro typy mimo aktuální crate
//! - [`TryFrom`] a [`TryInto`] traits se chovají jako [`From`] a [`Into`], ale měly by být implementovány, když převod může selhat.
//!
//! traits v tomto modulu se často používají jako trait bounds pro obecné funkce, takže jsou podporovány argumenty více typů.Příklady najdete v dokumentaci ke každému trait.
//!
//! Jako autor knihovny byste měli vždy upřednostňovat implementaci [`From<T>`][`From`] nebo [`TryFrom<T>`][`TryFrom`] před [`Into<U>`][`Into`] nebo [`TryInto<U>`][`TryInto`], protože [`From`] a [`TryFrom`] poskytují větší flexibilitu a nabízejí ekvivalentní implementace [`Into`] nebo [`TryInto`] zdarma, díky plošné implementaci ve standardní knihovně.
//! Při cílení na verzi před Rust 1.41 může být nutné převést [`Into`] nebo [`TryInto`] přímo při převodu na typ mimo aktuální crate.
//!
//! # Obecné implementace
//!
//! - [`AsRef`] a [`AsMut`] auto-dereference, pokud je vnitřní typ referencí
//! - [" Od`] " <U>pro T` znamená [" Do`]`</u><T><U>pro U`</u>
//! - [`TryFrom`]`<U>pro T` znamená [`TryInto`]`</u><T><U>pro U`</u>
//! - [`From`] a [`Into`] jsou reflexní, což znamená, že všechny typy mohou `into` samy a `from` samy
//!
//! Podívejte se na každý trait pro příklady použití.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Funkce identity.
///
/// O této funkci je důležité si uvědomit dvě věci:
///
/// - Není to vždy ekvivalent uzávěru jako `|x| x`, protože uzávěr může `x` donutit k jinému typu.
///
/// - Přesune vstup `x` předaný funkci.
///
/// I když by se mohlo zdát divné mít funkci, která pouze vrátí zpět vstup, existuje několik zajímavých použití.
///
///
/// # Examples
///
/// Pomocí `identity` neděláte nic v řadě dalších zajímavých funkcí:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Předstírejme, že přidání jednoho je zajímavá funkce.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Použití `identity` jako základního případu "do nothing" v podmíněném:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Dělejte zajímavější věci ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Použití `identity` k udržení variant `Some` iterátoru `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Používá se k levnému převodu z odkazu na referenci.
///
/// Tento trait je podobný [`AsMut`], který se používá pro převod mezi proměnlivými odkazy.
/// Pokud potřebujete provést nákladnou konverzi, je lepší implementovat [`From`] s typem `&T` nebo napsat vlastní funkci.
///
/// `AsRef` má stejný podpis jako [`Borrow`], ale [`Borrow`] se liší v několika aspektech:
///
/// - Na rozdíl od `AsRef` má [`Borrow`] plošný impl pro jakýkoli `T` a lze jej použít k přijetí buď reference, nebo hodnoty.
/// - [`Borrow`] také vyžaduje, aby [`Hash`], [`Eq`] a [`Ord`] pro vypůjčenou hodnotu byly ekvivalentní hodnotě vlastněné hodnoty.
/// Z tohoto důvodu, pokud si chcete vypůjčit pouze jedno pole struktury, můžete implementovat `AsRef`, ale ne [`Borrow`].
///
/// **Note: Tento trait nesmí selhat **.Pokud převod může selhat, použijte vyhrazenou metodu, která vrací [`Option<T>`] nebo [`Result<T, E>`].
///
/// # Obecné implementace
///
/// - `AsRef` automatické dereference, pokud je vnitřním typem odkaz nebo proměnlivý odkaz (např .: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Použitím trait bounds můžeme přijímat argumenty různých typů, pokud je lze převést na zadaný typ `T`.
///
/// Například: Vytvořením obecné funkce, která přebírá `AsRef<str>`, vyjadřujeme, že chceme přijmout všechny odkazy, které lze převést na [`&str`] jako argument.
/// Protože [`String`] i [`&str`] implementují `AsRef<str>`, můžeme oba přijmout jako vstupní argument.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Provede převod.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Slouží k provedení levné konverze referencí s proměnlivou proměnnou.
///
/// Tento trait je podobný [`AsRef`], ale používá se pro převod mezi proměnlivými odkazy.
/// Pokud potřebujete provést nákladnou konverzi, je lepší implementovat [`From`] s typem `&mut T` nebo napsat vlastní funkci.
///
/// **Note: Tento trait nesmí selhat **.Pokud převod může selhat, použijte vyhrazenou metodu, která vrací [`Option<T>`] nebo [`Result<T, E>`].
///
/// # Obecné implementace
///
/// - `AsMut` automatické dereference, pokud je vnitřní typ proměnlivý odkaz (např .: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Používáme-li `AsMut` jako trait bound pro obecnou funkci, můžeme přijmout všechny proměnlivé odkazy, které lze převést na typ `&mut T`.
/// Protože [`Box<T>`] implementuje `AsMut<T>`, můžeme napsat funkci `add_one`, která přebírá všechny argumenty, které lze převést na `&mut u64`.
/// Protože [`Box<T>`] implementuje `AsMut<T>`, `add_one` přijímá také argumenty typu `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Provede převod.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Převod hodnoty na hodnotu, který spotřebovává vstupní hodnotu.Opak [`From`].
///
/// Jeden by se měl vyvarovat implementace [`Into`] a místo toho implementovat [`From`].
/// Implementace [`From`] automaticky poskytuje implementaci [`Into`] díky plošné implementaci ve standardní knihovně.
///
/// Při zadávání trait bounds na obecné funkci upřednostňujete použití [`Into`] před [`From`], abyste zajistili, že lze použít také typy, které implementují pouze [`Into`].
///
/// **Note: Tento trait nesmí selhat **.Pokud převod může selhat, použijte [`TryInto`].
///
/// # Obecné implementace
///
/// - [" Od`]`<T>pro U` znamená `Into<U> for T`
/// - [`Into`] je reflexivní, což znamená, že je implementován `Into<T> for T`
///
/// # Implementace [`Into`] pro převody na externí typy ve starých verzích Rust
///
/// Před Rust 1.41, pokud cílový typ nebyl součástí aktuálního crate, pak jste nemohli přímo implementovat [`From`].
/// Vezměte například tento kód:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// To se nepodaří zkompilovat ve starších verzích jazyka, protože pravidla osamocení Rust bývají trochu přísnější.
/// Chcete-li to obejít, můžete implementovat [`Into`] přímo:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Je důležité si uvědomit, že [`Into`] neposkytuje implementaci [`From`] (jako [`From`] s [`Into`]).
/// Proto byste se měli vždy pokusit implementovat [`From`] a poté přejít zpět na [`Into`], pokud [`From`] nelze implementovat.
///
/// # Examples
///
/// [`String`] implementuje [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Abychom vyjádřili, že chceme, aby obecná funkce převzala všechny argumenty, které lze převést na zadaný typ `T`, můžeme použít trait bound z [`Into`]`<T>`.
///
/// Například: Funkce `is_hello` přebírá všechny argumenty, které lze převést na [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Provede převod.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Používá se k provádění převodů mezi hodnotami při náročné vstupní hodnotě.Je to převrácená hodnota [`Into`].
///
/// Jeden by měl vždy upřednostňovat implementaci `From` před [`Into`], protože implementace `From` automaticky poskytuje implementaci [`Into`] díky plošné implementaci ve standardní knihovně.
///
///
/// [`Into`] implementujte pouze při cílení na verzi před Rust 1.41 a při převodu na typ mimo aktuální crate.
/// `From` nebyl schopen provést tyto typy převodu v dřívějších verzích kvůli pravidlům osiřelého sledování Rust.
/// Další podrobnosti viz [`Into`].
///
/// Při zadávání trait bounds na obecné funkci upřednostňujete použití [`Into`] před použitím `From`.
/// Tímto způsobem lze jako argumenty použít také typy, které přímo implementují [`Into`].
///
/// `From` je také velmi užitečný při zpracování chyb.Při konstrukci funkce, která je schopná selhání, bude návratový typ obecně ve tvaru `Result<T, E>`.
/// `From` trait zjednodušuje zpracování chyb tím, že umožňuje funkci vrátit jeden typ chyby, který zapouzdřuje více typů chyb.Další podrobnosti najdete v části "Examples" a [the book][book].
///
/// **Note: Tento trait nesmí selhat **.Pokud převod může selhat, použijte [`TryFrom`].
///
/// # Obecné implementace
///
/// - `From<T> for U` znamená [" do`]` <U>pro T`</u>
/// - `From` je reflexivní, což znamená, že je implementován `From<T> for T`
///
/// # Examples
///
/// [`String`] nářadí `From<&str>`:
///
/// Explicitní převod z `&str` na řetězec se provádí následovně:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Při provádění zpracování chyb je často užitečné implementovat `From` pro svůj vlastní typ chyby.
/// Převáděním základních typů chyb na náš vlastní typ chyby, který zapouzdřuje základní typ chyby, můžeme vrátit jeden typ chyby, aniž bychom ztratili informace o základní příčině.
/// Operátor '?' automaticky převede základní typ chyby na náš vlastní typ chyby voláním `Into<CliError>::into`, který je automaticky poskytnut při implementaci `From`.
/// Kompilátor poté odvodí, která implementace `Into` by měla být použita.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Provede převod.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Pokus o převod, který spotřebovává `self`, což může, ale nemusí být drahé.
///
/// Autoři knihovny by obvykle neměli přímo implementovat tento trait, ale měli by upřednostňovat implementaci [`TryFrom`] trait, která nabízí větší flexibilitu a poskytuje ekvivalentní implementaci `TryInto` zdarma, díky plošné implementaci ve standardní knihovně.
/// Další informace najdete v dokumentaci k [`Into`].
///
/// # Implementace `TryInto`
///
/// To trpí stejnými omezeními a úvahami jako implementace [`Into`], podrobnosti najdete zde.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Typ vrácený v případě chyby převodu.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Provede převod.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Jednoduché a bezpečné převody typu, které za určitých okolností mohou kontrolovaným způsobem selhat.Je to převrácená hodnota [`TryInto`].
///
/// To je užitečné, když provádíte převod typu, který může triviálně uspět, ale může také vyžadovat speciální zpracování.
/// Například neexistuje způsob, jak převést [`i64`] na [`i32`] pomocí [`From`] trait, protože [`i64`] může obsahovat hodnotu, kterou [`i32`] nemůže představovat, a tak by převod ztratil data.
///
/// To lze vyřešit zkrácením [`i64`] na [`i32`] (což v podstatě dává hodnotu ["i64`]" modulo [`i32::MAX`]) nebo jednoduše vrácením [`i32::MAX`] nebo jinou metodou.
/// [`From`] trait je určen pro dokonalé převody, takže `TryFrom` trait informuje programátora, když se převod typu může pokazit, a nechá je rozhodnout, jak s ním zacházet.
///
/// # Obecné implementace
///
/// - `TryFrom<T> for U` implikuje [`TryInto`]`<U>pro T`</u>
/// - [`try_from`] je reflexivní, což znamená, že `TryFrom<T> for T` je implementován a nemůže selhat-přidružený typ `Error` pro volání `T::try_from()` na hodnotě typu `T` je [`Infallible`].
/// Když je typ [`!`] stabilizován, [`Infallible`] a [`!`] budou ekvivalentní.
///
/// `TryFrom<T>` lze implementovat takto:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Jak je popsáno, [`i32`] implementuje `TryFrom <` [i64`]`>:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Potichu zkrátí `big_number`, vyžaduje detekci a zpracování zkrácení po faktu.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Vrátí chybu, protože `big_number` je příliš velký na to, aby se vešel do `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Vrátí `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Typ vrácený v případě chyby převodu.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Provede převod.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// GENERICKÉ DOPADY
////////////////////////////////////////////////////////////////////////////////

// Jak se zvedá a
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Jako výtahy přes &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): nahraďte výše uvedené impls pro&/&mut za následující obecnější:
// // Jako výtahy nad Derefem
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>for D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut zvedne přes &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): nahraďte výše uvedený impl pro &mut následujícím obecnějším:
// // AsMut se zvedá nad DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>for D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Z implikuje do
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Od (a tedy do) je reflexivní
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Poznámka ke stabilitě:** Tento impl zatím neexistuje, ale jsme "reserving space", abychom jej přidali do future.
/// Podrobnosti viz [rust-lang/rust#64715][#64715].
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): místo toho proveďte zásadní opravu.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom znamená TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Infallible conversions are semantically equivalent to fallible conversions with an unhabited error type.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// BETONOVÉ IMPLY
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// TYP CHYBY BEZ CHYBY
////////////////////////////////////////////////////////////////////////////////

/// Typ chyby pro chyby, ke kterým nikdy nemůže dojít.
///
/// Protože tento výčet nemá žádnou variantu, hodnota tohoto typu ve skutečnosti nikdy nemůže existovat.
/// To může být užitečné pro obecná rozhraní API, která používají [`Result`] a parametrizují typ chyby, což znamená, že výsledkem je vždy [`Ok`].
///
/// Například [`TryFrom`] trait (převod, který vrací [`Result`]) má plošnou implementaci pro všechny typy, kde existuje reverzní implementace [`Into`].
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Kompatibilita Future
///
/// Tento výčet má stejnou roli jako [the `!`“never”type][never], což je v této verzi Rust nestabilní.
/// Když je `!` stabilizovaný, plánujeme z `Infallible` udělat alias typu:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …A nakonec zastarat `Infallible`.
///
/// Existuje však jeden případ, kdy lze použít syntaxi `!` před stabilizací `!` jako plnohodnotného typu: v poloze návratového typu funkce.
/// Konkrétně je možné implementace pro dva různé typy ukazatelů funkcí:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Protože `Infallible` je enum, je tento kód platný.
/// Když se však `Infallible` stane aliasem pro never type, dvě `impl`s se začnou překrývat, a proto budou zakázána pravidly koherence jazyka trait.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}