//! Podpora Panic pro libcore
//!
//! Základní knihovna nemůže definovat paniku, ale *deklaruje* paniku.
//! To znamená, že funkce uvnitř libcore jsou povoleny pro panic, ale aby to bylo užitečné, musí upstream crate definovat paniku, kterou bude libcore používat.
//! Aktuální rozhraní pro paniku je:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Tato definice umožňuje paniku s jakoukoli obecnou zprávou, ale neumožňuje selhání s hodnotou `Box<Any>`.
//! (`PanicInfo` právě obsahuje `&(dyn Any + Send)`, pro který vyplníme fiktivní hodnotu v `PanicInfo: : internal_constructor`.) Důvodem je to, že není povoleno přidělovat libcore.
//!
//!
//! Tento modul obsahuje několik dalších panických funkcí, ale to jsou jen nezbytné položky lang pro kompilátor.Všechny panics jsou financovány prostřednictvím této jedné funkce.
//! Skutečný symbol je deklarován prostřednictvím atributu `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Základní implementace makra lib00 `panic!`, když není použito žádné formátování.
#[cold]
// nikdy inline, pokud panic_immediate_abort, abyste co nejvíce zabránili nafouknutí kódu na místech volání
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // potřebné pro codegen pro panic na přetečení a další `Assert` MIR terminátory
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Použijte Arguments::new_v1 místo format_args! ("{}", Expr), abyste potenciálně snížili režijní náklady.
    // Formát_args!makro používá str's Display trait k zápisu expr, který volá Formatter::pad, který musí vyhovovat zkrácení řetězce a odsazení (i když zde není žádný použit).
    //
    // Použití Arguments::new_v1 může umožnit kompilátoru vynechat Formatter::pad z výstupního binárního souboru, což ušetří až několik kilobajtů.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // potřebné pro konstantní panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // potřebné pro codegen pro panic při přístupu OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Při formátování je použita základní implementace makra lib00 `panic!`.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // POZNÁMKA Tato funkce nikdy nepřekročí hranici FFI;je to volání Rust-to-Rust, které je vyřešeno na funkci `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // BEZPEČNOST: `panic_impl` je definován v bezpečném kódu Rust a je tedy bezpečné volat.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Interní funkce pro makra `assert_eq!` a `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}