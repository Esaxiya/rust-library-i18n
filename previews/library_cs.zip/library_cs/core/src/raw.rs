#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Obsahuje definice struktur pro rozložení vestavěných typů kompilátoru.
//!
//! Mohou být použity jako cíle transmutací v nebezpečném kódu pro přímou manipulaci s nezpracovanými reprezentacemi.
//!
//!
//! Jejich definice by měla vždy odpovídat ABI definovanému v `rustc_middle::ty::layout`.
//!

/// Reprezentace objektu trait jako `&dyn SomeTrait`.
///
/// Tato struktura má stejné rozložení jako typy jako `&dyn SomeTrait` a `Box<dyn AnotherTrait>`.
///
/// `TraitObject` je zaručeno, že odpovídá rozložení, ale nejedná se o typ objektů trait (např. pole nejsou přímo přístupná na `&dyn SomeTrait`) ani toto rozvržení neovládá (změna definice nezmění rozložení `&dyn SomeTrait`).
///
/// Je navržen pouze pro použití nebezpečným kódem, který potřebuje manipulovat s podrobnostmi na nízké úrovni.
///
/// Neexistuje žádný způsob, jak obecně odkazovat na všechny objekty trait, takže jediný způsob, jak vytvořit hodnoty tohoto typu, je pomocí funkcí, jako je [`std::mem::transmute`][transmute].
/// Podobně jediný způsob, jak vytvořit skutečný objekt trait z hodnoty `TraitObject`, je `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Syntéza objektu trait s neodpovídajícími typy-ten, kde vtable neodpovídá typu hodnoty, na kterou ukazuje datový ukazatel-s vysokou pravděpodobností povede k nedefinovanému chování.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // příklad trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // nechte kompilátor vytvořit objekt trait
/// let object: &dyn Foo = &value;
///
/// // podívejte se na surovou reprezentaci
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // datový ukazatel je adresa `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // postavit nový objekt, ukazující na jiný `i32`, dávejte pozor, abyste použili `i32` vtable z `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // mělo by to fungovat stejně, jako kdybychom postavili objekt trait z `other_value` přímo
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}