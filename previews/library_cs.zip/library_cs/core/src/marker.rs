//! Primitivní traits a typy představující základní vlastnosti typů.
//!
//! Typy Rust lze klasifikovat různými užitečnými způsoby podle jejich vnitřních vlastností.
//! Tyto klasifikace jsou reprezentovány jako traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Typy, které lze přenést přes hranice podprocesů.
///
/// Tento trait se automaticky implementuje, když kompilátor určí, že je to vhodné.
///
/// Příkladem typu, který není " Odeslat`, je ukazatel počítání referencí [`rc::Rc`][`Rc`].
/// Pokud se dvě vlákna pokusí naklonovat [`Rc`], které odkazují na stejnou hodnotu počítanou odkazem, mohou se pokusit aktualizovat počet odkazů současně, což je [undefined behavior][ub], protože [`Rc`] nepoužívá atomové operace.
///
/// Jeho bratranec [`sync::Arc`][arc] skutečně využívá atomové operace (s určitou režií), a proto je `Send`.
///
/// Další podrobnosti viz [the Nomicon](../../nomicon/send-and-sync.html).
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Typy s konstantní velikostí známé v době kompilace.
///
/// Všechny parametry typu mají implicitní vazbu `Sized`.Pokud to není vhodné, lze k odstranění této vazby použít speciální syntaxi `?Sized`.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//error: Sized is not implemented for [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Jedinou výjimkou je implicitní typ `Self` trait.
/// trait nemá implicitní vazbu `Sized`, protože je nekompatibilní s [objektem trait], kde trait podle definice musí pracovat se všemi možnými implementátory, a může tedy mít libovolnou velikost.
///
///
/// Ačkoli vám Rust umožní svázat `Sized` se trait, nebudete jej moci použít k vytvoření objektu trait později:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // nechť y: &dyn Bar= &Impl;//chyba: z objektu trait `Bar` nelze udělat objekt
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // například Default, který vyžaduje, aby `[T]: !Default` bylo možné vyhodnotit
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Typy, které mohou být "unsized" na dynamicky velký typ.
///
/// Například velké pole typu `[i8; 2]` implementuje `Unsize<[i8]>` a `Unsize<dyn fmt::Debug>`.
///
/// Všechny implementace `Unsize` poskytuje kompilátor automaticky.
///
/// `Unsize` je implementováno pro:
///
/// - `[T; N]` je `Unsize<[T]>`
/// - `T` je `Unsize<dyn Trait>`, když `T: Trait`
/// - `Foo<..., T, ...>` je `Unsize<Foo<..., U, ...>>`, pokud:
///   - `T: Unsize<U>`
///   - Foo je struktura
///   - Pouze poslední pole `Foo` má typ zahrnující `T`
///   - `T` není součástí typu žádného jiného pole
///   - `Bar<T>: Unsize<Bar<U>>`, pokud má poslední pole `Foo` typ `Bar<T>`
///
/// `Unsize` se spolu s [`ops::CoerceUnsized`] používá k tomu, aby kontejnery "user-defined", jako je [`Rc`], obsahovaly dynamicky velké typy.
/// Další podrobnosti viz [DST coercion RFC][RFC982] a [the nomicon entry on coercion][nomicon-coerce].
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Požadovaný trait pro konstanty použité ve shodách vzorů.
///
/// Jakýkoli typ, který odvozuje `PartialEq`, automaticky implementuje tento trait,*bez ohledu na to*, zda jeho parametry typu implementují `Eq`.
///
/// Pokud položka `const` obsahuje nějaký typ, který tento trait neimplementuje, pak tento typ buď (1.) neimplementuje `PartialEq` (což znamená, že konstanta neposkytne tuto srovnávací metodu, která předpokládá, že je k dispozici generování kódu), nebo (2.) implementuje *vlastní* verze `PartialEq` (předpokládáme, že neodpovídá srovnávání strukturální rovnosti).
///
///
/// V jednom ze dvou výše uvedených scénářů odmítáme použití takové konstanty ve shodě vzorů.
///
/// Podívejte se také na [structural match RFC][RFC1445] a [issue 63438], které motivovaly k migraci z designu založeného na atributech na tento trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Požadovaný trait pro konstanty použité ve shodách vzorů.
///
/// Jakýkoli typ, který odvozuje `Eq`, automaticky implementuje tento trait,*bez ohledu na* to, zda jeho parametry typu implementují `Eq`.
///
/// Jedná se o hack, který obchází omezení v našem typovém systému.
///
/// # Background
///
/// Chceme požadovat, aby typy konstant použitých ve shodách vzorů měly atribut `#[derive(PartialEq, Eq)]`.
///
/// V ideálnějším světě bychom tento požadavek mohli zkontrolovat pouhou kontrolou, že daný typ implementuje jak `StructuralPartialEq` trait *, tak*`Eq` trait.
/// Můžete však mít ADT, které *do*`derive(PartialEq, Eq)`, a být případ, který chceme, aby kompilátor přijal, a přesto typ konstanty nedokáže implementovat `Eq`.
///
/// Jmenovitě takový případ:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Problém ve výše uvedeném kódu spočívá v tom, že `Wrap<fn(&())>` neimplementuje `PartialEq` ani `Eq`, protože `for <'a> fn(&'a _)` does not implement those traits.)
///
/// Proto se nemůžeme spolehnout na naivní kontrolu pro `StructuralPartialEq` a pouhou `Eq`.
///
/// Jako hack k řešení tohoto problému používáme dva samostatné traits injektované každým ze dvou odvozených (`#[derive(PartialEq)]` a `#[derive(Eq)]`) a kontrolujeme, zda jsou oba přítomny jako součást kontroly strukturální shody.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Typy, jejichž hodnoty lze duplikovat jednoduše kopírováním bitů.
///
/// Ve výchozím nastavení mají vazby proměnných " sémantiku přesunu`.Jinými slovy:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` se přesunul do `y`, a proto jej nelze použít
///
/// // println! ("{: ?}", x);//chyba: použití přesunuté hodnoty
/// ```
///
/// Pokud však typ implementuje `Copy`, má místo toho 'sémantiku kopírování':
///
/// ```
/// // Můžeme odvodit implementaci `Copy`.
/// // `Clone` je také vyžadován, protože se jedná o nadprůměr `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` je kopie `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Je důležité si uvědomit, že v těchto dvou příkladech je jediný rozdíl v tom, zda máte po přiřazení povolen přístup k `x`.
/// Kopie i pohyb pod kapotou mohou mít za následek kopírování bitů do paměti, i když je to někdy optimalizováno.
///
/// ## Jak mohu implementovat `Copy`?
///
/// Existují dva způsoby, jak implementovat `Copy` na váš typ.Nejjednodušší je použít `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// `Copy` a `Clone` můžete také implementovat ručně:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Mezi těmito dvěma je malý rozdíl: strategie `derive` také umístí `Copy` vázaný na parametry typu, což není vždy žádoucí.
///
/// ## Jaký je rozdíl mezi `Copy` a `Clone`?
///
/// Ke kopírování dochází implicitně, například jako součást přiřazení `y = x`.Chování `Copy` nelze přetížit;vždy je to jednoduchá bitová kopie.
///
/// Klonování je explicitní akce, `x.clone()`.Implementace [`Clone`] může poskytnout jakékoli typově specifické chování nezbytné pro bezpečnou duplikaci hodnot.
/// Například implementace [`Clone`] pro [`String`] musí kopírovat vyrovnávací paměť poukázaného řetězce v haldě.
/// Jednoduchá bitová kopie hodnot [`String`] by pouze zkopírovala ukazatel, což by vedlo k dvojitému uvolnění po řádku.
/// Z tohoto důvodu je [`String`] [`Clone`], ale ne `Copy`.
///
/// [`Clone`] je supertrénou `Copy`, takže vše, co je `Copy`, musí také implementovat [`Clone`].
/// Pokud je typ `Copy`, pak jeho implementace [`Clone`] potřebuje vrátit pouze `*self` (viz výše uvedený příklad).
///
/// ## Kdy může být můj typ `Copy`?
///
/// Typ může implementovat `Copy`, pokud všechny jeho komponenty implementují `Copy`.Například tato struktura může být `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Struktura může být `Copy` a [`i32`] je `Copy`, proto `Point` může být `Copy`.
/// Naproti tomu zvažte
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Struktura `PointList` nemůže implementovat `Copy`, protože [`Vec<T>`] není `Copy`.Pokud se pokusíme odvodit implementaci `Copy`, zobrazí se chyba:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Sdílené odkazy (`&T`) jsou také `Copy`, takže typ může být `Copy`, i když obsahuje sdílené odkazy typů `T`, které *nejsou*`Copy`.
/// Zvažte následující strukturu, která může implementovat `Copy`, protože obsahuje pouze *sdílený odkaz* na náš typ `PointList` jiného typu než " Copy`:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Kdy *nemůže* být můj typ `Copy`?
///
/// Některé typy nelze bezpečně kopírovat.Například kopírování `&mut T` by vytvořilo aliasovaný proměnlivý odkaz.
/// Kopírování [`String`] by duplikovalo odpovědnost za správu vyrovnávací paměti [" String`]`, což by vedlo k dvojnásobnému uvolnění.
///
/// Zobecnění druhého případu, jakýkoli typ implementující [`Drop`] nemůže být `Copy`, protože spravuje nějaký prostředek kromě svých vlastních bajtů [`size_of::<T>`].
///
/// Pokud se pokusíte implementovat `Copy` na strukturu nebo výčet obsahující data, která nejsou " Kopie`, zobrazí se chyba [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Kdy *by měl* být můj typ `Copy`?
///
/// Obecně řečeno, pokud váš typ _can_ implementuje `Copy`, měl by.
/// Mějte však na paměti, že implementace `Copy` je součástí veřejného API vašeho typu.
/// Pokud by se typ mohl v future stát " non-copy`, mohlo by být rozumné nyní vynechat implementaci `Copy`, aby se zabránilo zlomení změny API.
///
/// ## Další implementátoři
///
/// Kromě [implementors listed below][impls] implementují následující typy také `Copy`:
///
/// * Typy funkčních položek (tj. Odlišné typy definované pro každou funkci)
/// * Typy ukazatelů funkcí (např. `fn() -> i32`)
/// * Typy polí pro všechny velikosti, pokud typ položky implementuje také `Copy` (např. `[i32; 123456]`)
/// * Typy n-tic, pokud každá komponenta také implementuje `Copy` (např. `()`, `(i32, bool)`)
/// * Uzávěrové typy, pokud nezachycují žádnou hodnotu z prostředí nebo pokud všechny takové zachycené hodnoty implementují `Copy` samy.
///   Všimněte si, že proměnné zachycené sdílenou referencí vždy implementují `Copy` (i když referent ne), zatímco proměnné zachycené proměnlivou referencí nikdy neimplementují `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) To umožňuje kopírování typu, který neimplementuje `Copy` kvůli neuspokojeným hranicím životnosti (kopírování `A<'_>`, když jsou pouze `A<'static>: Copy` a `A<'_>: Clone`).
// Tento atribut zde prozatím máme jen proto, že v `Copy` existuje poměrně málo existujících specializací, které již existují ve standardní knihovně, a nyní neexistuje způsob, jak toto chování bezpečně mít.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Odvozte makro generující impl z trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Typy, pro které je bezpečné sdílet odkazy mezi vlákny.
///
/// Tento trait se automaticky implementuje, když kompilátor určí, že je to vhodné.
///
/// Přesná definice je: typ `T` je [`Sync`] právě tehdy, když `&T` je [`Send`].
/// Jinými slovy, pokud neexistuje možnost [undefined behavior][ub] (včetně datových závodů) při předávání odkazů `&T` mezi vlákny.
///
/// Jak by se dalo očekávat, primitivní typy jako [`u8`] a [`f64`] jsou všechny [`Sync`], a tedy i jednoduché agregační typy, které je obsahují, jako n-tice, struktury a výčty.
/// Další příklady základních typů [`Sync`] zahrnují typy "immutable", jako je `&T`, a ty s jednoduchou zděděnou proměnlivostí, jako jsou [`Box<T>`][box], [`Vec<T>`][vec] a většina dalších typů kolekcí.
///
/// (Obecné parametry musí být [`Sync`], aby jejich kontejner byl [" Sync`].)
///
/// Trochu překvapivým důsledkem definice je, že `&mut T` je `Sync` (pokud `T` je `Sync`), i když se zdá, že by to mohlo poskytnout nesynchronizovanou mutaci.
/// Trik spočívá v tom, že proměnlivá reference za sdílenou referencí (tj. `& &mut T`) se stane pouze pro čtení, jako by to byla `& &T`.
/// Neexistuje tedy riziko datové rasy.
///
/// Typy, které nejsou `Sync`, jsou ty, které mají "interior mutability" ve formě, která není bezpečná pro vlákna, například [`Cell`][cell] a [`RefCell`][refcell].
/// Tyto typy umožňují mutaci jejich obsahu i prostřednictvím neměnné sdílené reference.
/// Například metoda `set` na [`Cell<T>`][cell] trvá `&self`, takže vyžaduje pouze sdílenou referenci [`&Cell<T>`][cell].
/// Metoda neprovádí žádnou synchronizaci, takže [`Cell`][cell] nemůže být `Sync`.
///
/// Dalším příkladem typu, který není typu " Sync`, je ukazatel počítání referencí [`Rc`][rc].
/// Vzhledem k jakémukoli referenčnímu [`&Rc<T>`][rc] můžete klonovat nový [`Rc<T>`][rc] a upravit počty odkazů jiným než atomovým způsobem.
///
/// V případech, kdy je potřeba měnit vnitřní prostředí bezpečné pro vlákna, poskytuje Rust [atomic data types], stejně jako explicitní uzamčení prostřednictvím [`sync::Mutex`][mutex] a [`sync::RwLock`][rwlock].
/// Tyto typy zajišťují, že žádná mutace nemůže způsobit datové rasy, proto jsou typy `Sync`.
/// Podobně [`sync::Arc`][arc] poskytuje analogový [`Rc`][rc] bezpečný pro vlákna.
///
/// Všechny typy s vnitřní měnitelností musí také používat obálku [`cell::UnsafeCell`][unsafecell] kolem value(s), kterou lze mutovat prostřednictvím sdílené reference.
/// Pokud tak neučiníte, je [undefined behavior][ub].
/// Například [" transmute`][transmute]-ing z `&T` na `&mut T` je neplatný.
///
/// Další podrobnosti o `Sync` najdete na [the Nomicon][nomicon-send-and-sync].
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): jakmile podpora pro přidání poznámek v `rustc_on_unimplemented` přistane v beta verzi a byla rozšířena o kontrolu, zda je uzávěrka kdekoli v řetězci požadavků, rozšířte ji jako takovou (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Typ nulové velikosti používaný k označení věcí, které "act like" vlastní `T`.
///
/// Přidání pole `PhantomData<T>` do vašeho typu řekne kompilátoru, že váš typ funguje, jako by ukládal hodnotu typu `T`, i když to ve skutečnosti není.
/// Tyto informace se používají při výpočtu určitých bezpečnostních vlastností.
///
/// Podrobnější vysvětlení, jak používat `PhantomData<T>`, najdete v [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Příšerná poznámka 👻👻👻
///
/// Ačkoli mají oba strašidelná jména, `PhantomData` a " fantomové typy` jsou příbuzné, ale ne identické.Parametr typu fantom je jednoduše parametr typu, který se nikdy nepoužívá.
/// V Rust to často způsobí, že si kompilátor stěžuje, a řešením je přidání použití "dummy" prostřednictvím `PhantomData`.
///
/// # Examples
///
/// ## Nepoužívané parametry životnosti
///
/// Snad nejběžnějším případem použití pro `PhantomData` je struktura, která má nepoužívaný parametr životnosti, obvykle jako součást nějakého nebezpečného kódu.
/// Například zde je struktura `Slice`, která má dva ukazatele typu `*const T`, pravděpodobně směřující někam do pole:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Záměrem je, aby podkladová data byla platná pouze po dobu životnosti `'a`, takže `Slice` by neměl přežít `'a`.
/// Tento záměr však není v kódu vyjádřen, protože neexistuje celoživotní použití `'a`, a proto není jasné, na která data se vztahuje.
/// Můžeme to napravit tím, že řekneme kompilátoru, aby jednal *, jako by* struktura `Slice` obsahovala odkaz `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// To také vyžaduje anotaci `T: 'a`, což znamená, že všechny odkazy v `T` jsou platné po celou dobu životnosti `'a`.
///
/// Při inicializaci `Slice` jednoduše zadáte hodnotu `PhantomData` pro pole `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Nepoužité parametry typu
///
/// Někdy se stane, že máte nepoužité parametry typu, které označují, jaký typ dat je struktura "tied", i když tato data nejsou ve samotné struktuře skutečně nalezena.
/// Zde je příklad, kde k tomu dochází u [FFI].
/// Cizí rozhraní používá úchyty typu `*mut ()` k označení hodnot Rust různých typů.
/// Sledujeme typ Rust pomocí parametru typu fantomu ve struktuře `ExternalResource`, který obtéká popisovač.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Vlastnictví a kontrola pádu
///
/// Přidání pole typu `PhantomData<T>` znamená, že váš typ vlastní data typu `T`.To zase znamená, že když je váš typ zrušen, může zrušit jednu nebo více instancí typu `T`.
/// To má vliv na analýzu [drop check] kompilátoru Rust.
///
/// Pokud vaše struktura ve skutečnosti *nevlastní* data typu `T`, je lepší použít referenční typ, jako je `PhantomData<&'a T>` (ideally) nebo `PhantomData<*const T>` (pokud neplatí žádná doba životnosti), aby nedošlo k označení vlastnictví.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Interní kompilátor trait používaný k označení typu diskriminátorů výčtu.
///
/// Tento trait je automaticky implementován pro každý typ a nepřidává žádné záruky [`mem::Discriminant`].
/// Přeměna mezi `DiscriminantKind::Discriminant` a `mem::Discriminant` je **nedefinované chování**.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Typ diskriminátoru, který musí splňovat trait bounds požadovaný `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Interní kompilátor trait, který se používá k určení, zda typ obsahuje interně `UnsafeCell`, ale ne prostřednictvím indirection.
///
/// To ovlivňuje například to, zda je `static` tohoto typu umístěn ve statické paměti jen pro čtení nebo ve statické paměti pro zápis.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Typy, které lze po připnutí bezpečně přesunout.
///
/// Samotný Rust nemá ponětí o nepohyblivých typech a považuje tahy (např. Přiřazením nebo [`mem::replace`]) za vždy bezpečné.
///
/// Místo toho se používá typ [`Pin`][Pin], aby se zabránilo pohybům typovým systémem.Ukazatele `P<T>` zabalené v obálce [`Pin<P<T>>`][Pin] nelze přesunout ven.
/// Další informace o připnutí naleznete v dokumentaci [`pin` module].
///
/// Implementace `Unpin` trait pro `T` zruší omezení odepnutí typu, což pak umožňuje přesunutí `T` z [`Pin<P<T>>`][Pin] pomocí funkcí, jako je [`mem::replace`].
///
///
/// `Unpin` nemá žádný důsledek pro nepřipnutá data.
/// Zejména [`mem::replace`] šťastně přesouvá data `!Unpin` (funguje pro jakýkoli `&mut T`, nejen když `T: Unpin`).
/// Nelze však použít [`mem::replace`] na data zabalená uvnitř [`Pin<P<T>>`][Pin], protože nemůžete získat `&mut T`, který k tomu potřebujete, a *to* je to, co dělá tento systém funkční.
///
/// Například toto lze provést pouze u typů implementujících `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Abychom mohli volat `mem::replace`, potřebujeme měnitelný odkaz.
/// // Můžeme získat takový odkaz (implicitly) vyvoláním `Pin::deref_mut`, ale to je možné jen proto, že `String` implementuje `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Tento trait je automaticky implementován téměř pro každý typ.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Typ značky, který neimplementuje `Unpin`.
///
/// Pokud typ obsahuje `PhantomPinned`, nebude implicitně implementovat `Unpin`.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementace `Copy` pro primitivní typy.
///
/// Implementace, které nelze popsat v Rust, jsou implementovány v `traits::SelectionContext::copy_clone_conditions()` v `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Sdílené odkazy lze kopírovat, ale proměnlivé odkazy *nemohou*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}