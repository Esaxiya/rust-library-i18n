use crate::iter::FromIterator;

/// Sbalí všechny jednotky z iterátoru do jednoho.
///
/// To je užitečnější v kombinaci s abstrakcemi vyšší úrovně, jako je shromažďování do `Result<(), E>`, kde vám záleží jen na chybách:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}