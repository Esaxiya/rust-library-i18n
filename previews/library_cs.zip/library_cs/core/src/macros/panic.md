Panics aktuální vlákno.

To umožňuje programu okamžitě ukončit a poskytnout zpětnou vazbu volajícímu programu.
`panic!` by se mělo použít, když program dosáhne neobnovitelného stavu.

Toto makro je dokonalým způsobem, jak prosadit podmínky v ukázkovém kódu a v testech.
`panic!` je úzce svázán s metodou `unwrap` výčtů [`Option`][ounwrap] i [`Result`][runwrap].
Obě implementace volají `panic!`, když jsou nastaveny na varianty [`None`] nebo [`Err`].

Při použití `panic!()` můžete určit užitečné zatížení řetězce, které je vytvořeno pomocí syntaxe [`format!`].
Toto užitečné zatížení se používá při vstřikování panic do volajícího vlákna Rust, což způsobí, že se vlákno úplně panic.

Chování výchozího `std` hook, tj
kód, který běží přímo po vyvolání panic, je vytisknout užitečné zatížení zprávy na `stderr` spolu s informacemi file/line/column volání `panic!()`.

panic hook můžete přepsat pomocí [`std::panic::set_hook()`].
Uvnitř hook lze k panic přistupovat jako `&dyn Any + Send`, který obsahuje `&str` nebo `String` pro běžné `panic!()` vyvolání.
Pro panic s hodnotou jiného jiného typu lze použít [`panic_any`].

[`Result`] enum je často lepším řešením pro zotavení z chyb než použití makra `panic!`.
Toto makro by mělo být použito, aby se zabránilo použití nesprávných hodnot, například z externích zdrojů.
Podrobné informace o zpracování chyb najdete v [book].

Viz také makro [`compile_error!`], kde najdete chyby při kompilaci.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Aktuální implementace

Pokud je hlavní vlákno panics, ukončí všechna vaše vlákna a ukončí váš program kódem `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





