#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Rozšiřuje se na `$crate::panic::panic_2015` nebo `$crate::panic::panic_2021` v závislosti na vydání volajícího.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Tvrdí, že dva výrazy jsou si navzájem rovné (pomocí [`PartialEq`]).
///
/// Na panic toto makro vytiskne hodnoty výrazů s jejich ladicími reprezentacemi.
///
///
/// Stejně jako [`assert!`] má toto makro druhý formulář, kde lze poskytnout vlastní zprávu panic.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Znovuzískané níže jsou úmyslné.
                    // Bez nich se zásobník zásobníku pro výpůjčku inicializuje ještě před porovnáním hodnot, což vede k znatelnému zpomalení.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Znovuzískané níže jsou úmyslné.
                    // Bez nich se zásobník zásobníku pro výpůjčku inicializuje ještě před porovnáním hodnot, což vede k znatelnému zpomalení.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Tvrdí, že dva výrazy se navzájem nerovnají (pomocí [`PartialEq`]).
///
/// Na panic toto makro vytiskne hodnoty výrazů s jejich ladicími reprezentacemi.
///
///
/// Stejně jako [`assert!`] má toto makro druhý formulář, kde lze poskytnout vlastní zprávu panic.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Znovuzískané níže jsou úmyslné.
                    // Bez nich se zásobník zásobníku pro výpůjčku inicializuje ještě před porovnáním hodnot, což vede k znatelnému zpomalení.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Znovuzískané níže jsou úmyslné.
                    // Bez nich se zásobník zásobníku pro výpůjčku inicializuje ještě před porovnáním hodnot, což vede k znatelnému zpomalení.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Tvrdí, že logický výraz je `true` za běhu.
///
/// Toto vyvolá makro [`panic!`], pokud zadaný výraz nelze za běhu vyhodnotit na `true`.
///
/// Stejně jako [`assert!`] má toto makro také druhou verzi, kde lze poskytnout vlastní zprávu panic.
///
/// # Uses
///
/// Na rozdíl od [`assert!`] jsou příkazy `debug_assert!` ve výchozím nastavení povoleny pouze v neoptimalizovaných sestaveních.
/// Optimalizované sestavení neprovede příkazy `debug_assert!`, pokud `-C debug-assertions` není předán kompilátoru.
/// Díky tomu je `debug_assert!` užitečný pro kontroly, které jsou příliš drahé na to, aby byly přítomny v sestavení verze, ale mohou být užitečné během vývoje.
/// Výsledek rozšiřování `debug_assert!` je vždy typově kontrolován.
///
/// Nekontrolované tvrzení umožňuje programu v nekonzistentním stavu pokračovat v běhu, což může mít neočekávané důsledky, ale nezavádí bezpečnost, pokud k tomu dojde pouze v bezpečném kódu.
///
/// Náklady na výkon tvrzení však nelze měřit obecně.
/// Výměna [`assert!`] za `debug_assert!` je tedy podporována až po důkladném profilování, a co je důležitější, pouze v bezpečném kódu!
///
/// # Examples
///
/// ```
/// // zpráva panic pro tato tvrzení je přísná hodnota daného výrazu.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // velmi jednoduchá funkce
/// debug_assert!(some_expensive_computation());
///
/// // prosadit vlastní zprávou
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Tvrdí, že dva výrazy jsou si navzájem rovnocenné.
///
/// Na panic toto makro vytiskne hodnoty výrazů s jejich ladicími reprezentacemi.
///
/// Na rozdíl od [`assert_eq!`] jsou příkazy `debug_assert_eq!` ve výchozím nastavení povoleny pouze v neoptimalizovaných sestaveních.
/// Optimalizované sestavení neprovede příkazy `debug_assert_eq!`, pokud `-C debug-assertions` není předán kompilátoru.
/// Díky tomu je `debug_assert_eq!` užitečný pro kontroly, které jsou příliš drahé na to, aby byly přítomny v sestavení verze, ale mohou být užitečné během vývoje.
///
/// Výsledek rozšiřování `debug_assert_eq!` je vždy typově kontrolován.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Tvrdí, že dva výrazy se navzájem nerovnají.
///
/// Na panic toto makro vytiskne hodnoty výrazů s jejich ladicími reprezentacemi.
///
/// Na rozdíl od [`assert_ne!`] jsou příkazy `debug_assert_ne!` ve výchozím nastavení povoleny pouze v neoptimalizovaných sestaveních.
/// Optimalizované sestavení neprovede příkazy `debug_assert_ne!`, pokud `-C debug-assertions` není předán kompilátoru.
/// Díky tomu je `debug_assert_ne!` užitečný pro kontroly, které jsou příliš drahé na to, aby byly přítomny v sestavení verze, ale mohou být užitečné během vývoje.
///
/// Výsledek rozšiřování `debug_assert_ne!` je vždy typově kontrolován.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Vrátí, zda daný výraz odpovídá některému z daných vzorů.
///
/// Stejně jako ve výrazu `match` může za vzorem volitelně následovat `if` a strážný výraz, který má přístup k názvům vázaným vzorem.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Rozbalí výsledek nebo rozšíří jeho chybu.
///
/// K nahrazení `try!` byl přidán operátor `?` a místo toho by měl být použit.
/// Kromě toho je `try` v Rust 2018 vyhrazeným slovem, takže pokud jej musíte použít, budete muset použít [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` odpovídá dané [`Result`].V případě varianty `Ok` má výraz hodnotu zalomené hodnoty.
///
/// V případě varianty `Err` načte vnitřní chybu.`try!` poté provede převod pomocí `From`.
/// To poskytuje automatický převod mezi specializovanými chybami a obecnějšími chybami.
/// Výsledná chyba se poté okamžitě vrátí.
///
/// Z důvodu předčasného návratu lze `try!` použít pouze ve funkcích, které vracejí [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Preferovaná metoda rychlého vrácení chyb
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Předchozí metoda rychlého vrácení chyb
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // To odpovídá:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Zapíše formátovaná data do vyrovnávací paměti.
///
/// Toto makro přijímá 'writer', formátovací řetězec a seznam argumentů.
/// Argumenty budou formátovány podle zadaného formátovacího řetězce a výsledek bude předán zapisovači.
/// Zapisovačem může být jakákoli hodnota s metodou `write_fmt`;obecně to pochází z implementace buď [`fmt::Write`] nebo [`io::Write`] trait.
/// Makro vrátí vše, co vrátí metoda `write_fmt`;běžně [`fmt::Result`] nebo [`io::Result`].
///
/// Další informace o syntaxi formátovacího řetězce viz [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Modul může importovat `std::fmt::Write` i `std::io::Write` a volat `write!` na objekty implementující buď, protože objekty obvykle neimplementují obojí.
///
/// Modul však musí importovat kvalifikované traits, aby jejich jména nebyla v konfliktu:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // používá fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // používá io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Toto makro lze použít také v nastavení `no_std`.
/// V nastavení `no_std` zodpovídáte za podrobnosti implementace komponent.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Zapisujte naformátovaná data do vyrovnávací paměti s připojeným novým řádkem.
///
/// Na všech platformách je nová řada samotným znakem LINE FEED (`\n`/`U+000A`) (žádné další CARRIAGE RETURN (`\r`/`U+000D`).
///
/// Další informace viz [`write!`].Informace o syntaxi formátovacího řetězce najdete v [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Modul může importovat `std::fmt::Write` i `std::io::Write` a volat `write!` na objekty implementující buď, protože objekty obvykle neimplementují obojí.
/// Modul však musí importovat kvalifikované traits, aby jejich jména nebyla v konfliktu:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // používá fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // používá io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Označuje nedosažitelný kód.
///
/// To je užitečné kdykoli, když kompilátor nemůže určit, že je nějaký kód nedosažitelný.Například:
///
/// * Spojte zbraně s ochrannými podmínkami.
/// * Smyčky, které se dynamicky ukončují.
/// * Iterátory, které se dynamicky ukončují.
///
/// Pokud se zjištění, že je kód nedostupný, ukáže jako nesprávné, program okamžitě skončí [`panic!`].
///
/// Nebezpečným protějškem tohoto makra je funkce [`unreachable_unchecked`], která při dosažení kódu způsobí nedefinované chování.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// To bude vždy [`panic!`].
///
/// # Examples
///
/// Zápas zbraně:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // chyba kompilace, pokud je komentář
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // jedna z nejchudších implementací x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Označuje neimplementovaný kód panikou se zprávou "not implemented".
///
/// To umožňuje vašemu kódu zkontrolovat typ, což je užitečné, pokud vytváříte prototypy nebo implementujete trait, který vyžaduje více metod, které neplánujete použít všechny.
///
/// Rozdíl mezi `unimplemented!` a [`todo!`] spočívá v tom, že zatímco `todo!` vyjadřuje záměr implementovat funkce později a zpráva je "not yet implemented", `unimplemented!` žádné takové nároky nečiní.
/// Jeho zpráva je "not implemented".
/// Některá IDE také označí `todo! 'S.
///
/// # Panics
///
/// To bude vždy [`panic!`], protože `unimplemented!` je jen zkratka pro `panic!` s pevnou konkrétní zprávou.
///
/// Stejně jako `panic!` má toto makro druhý formulář pro zobrazení vlastních hodnot.
///
/// # Examples
///
/// Řekněme, že máme trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Chceme implementovat `Foo` pro 'MyStruct', ale z nějakého důvodu má smysl implementovat pouze funkci `bar()`.
/// `baz()` a `qux()` bude stále nutné definovat v naší implementaci `Foo`, ale můžeme použít `unimplemented!` v jejich definicích, abychom umožnili kompilaci našeho kódu.
///
/// Stále chceme, aby náš program přestal běžet, pokud bude dosaženo neimplementovaných metod.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Pro `baz` a `MyStruct` to nedává smysl, takže zde nemáme vůbec žádnou logiku.
/////
///         // Zobrazí se "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Máme tu nějakou logiku, můžeme přidat zprávu neimplementovaným!zobrazit naše opomenutí.
///         // Zobrazí se: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Označuje nedokončený kód.
///
/// To může být užitečné, pokud vytváříte prototypy a hledáte typecku kódu.
///
/// Rozdíl mezi [`unimplemented!`] a `todo!` spočívá v tom, že zatímco `todo!` vyjadřuje záměr implementovat funkce později a zpráva je "not yet implemented", `unimplemented!` žádné takové nároky nečiní.
/// Jeho zpráva je "not implemented".
/// Některá IDE také označí `todo! 'S.
///
/// # Panics
///
/// To bude vždy [`panic!`].
///
/// # Examples
///
/// Zde je příklad nějakého probíhajícího kódu.Máme trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Chceme implementovat `Foo` na jednom z našich typů, ale také nejprve chceme pracovat pouze na `bar()`.Aby se náš kód mohl kompilovat, musíme implementovat `baz()`, abychom mohli použít `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // implementace jde sem
///     }
///
///     fn baz(&self) {
///         // Nebojme se zatím implementovat baz()
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // nepoužíváme ani baz(), takže je to v pořádku.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definice integrovaných maker.
///
/// Většina vlastností makra (stabilita, viditelnost atd.) Je zde převzata ze zdrojového kódu, s výjimkou rozšiřujících funkcí transformujících vstupy makra na výstupy, tyto funkce poskytuje kompilátor.
///
///
pub(crate) mod builtin {

    /// Způsobí selhání kompilace s danou chybovou zprávou při zjištění.
    ///
    /// Toto makro by mělo být použito, když crate používá strategii podmíněného kompilace k poskytnutí lepších chybových zpráv pro chybné podmínky.
    ///
    /// Je to forma [`panic!`] na úrovni kompilátoru, ale vydává chybu během *kompilace* spíše než za *runtime*.
    ///
    /// # Examples
    ///
    /// Dva takové příklady jsou makra a prostředí `#[cfg]`.
    ///
    /// Vyslat lepší chybu kompilátoru, pokud je makru předáno neplatné hodnoty.
    /// Bez konečné branch by kompilátor stále vydával chybu, ale chybová zpráva by nezmínila dvě platné hodnoty.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Vyslat chybu kompilátoru, pokud některá z mnoha funkcí není k dispozici.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Vytvoří parametry pro ostatní makra pro formátování řetězců.
    ///
    /// Toto makro funguje převzetím formátovacího řetězcového literálu obsahujícího `{}` pro každý další předaný argument.
    /// `format_args!` připraví další parametry, aby bylo možné výstup interpretovat jako řetězec, a kanonizuje argumenty do jednoho typu.
    /// Jakoukoli hodnotu, která implementuje [`Display`] trait, lze předat `format_args!`, stejně jako jakoukoli implementaci [`Debug`] předat `{:?}` v rámci formátovacího řetězce.
    ///
    ///
    /// Toto makro vytváří hodnotu typu [`fmt::Arguments`].Tuto hodnotu lze předat makrům v rámci [`std::fmt`] pro provádění užitečného přesměrování.
    /// Všechna ostatní formátovací makra ([" formát!`], [`write!`], [`println!`] atd.) Jsou prostřednictvím tohoto serveru proxy.
    /// `format_args!`, na rozdíl od odvozených maker se vyhne přidělení haldy.
    ///
    /// Můžete použít hodnotu [`fmt::Arguments`], kterou `format_args!` vrací v kontextech `Debug` a `Display`, jak je vidět níže.
    /// Příklad také ukazuje, že `Debug` a `Display` formátují stejnou věc: interpolovaný formátovací řetězec v `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Další informace najdete v dokumentaci [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Stejné jako `format_args`, ale nakonec přidá nový řádek.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Zkontroluje proměnnou prostředí v době kompilace.
    ///
    /// Toto makro se v době kompilace rozbalí na hodnotu pojmenované proměnné prostředí, čímž se získá výraz typu `&'static str`.
    ///
    ///
    /// Pokud proměnná prostředí není definována, bude vydána chyba kompilace.
    /// Chcete-li nevydat chybu kompilace, použijte místo toho makro [`option_env!`].
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Chybovou zprávu můžete přizpůsobit předáním řetězce jako druhého parametru:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Pokud proměnná prostředí `documentation` není definována, zobrazí se následující chyba:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Volitelně zkontroluje proměnnou prostředí v době kompilace.
    ///
    /// Pokud je pojmenovaná proměnná prostředí k dispozici v době kompilace, rozbalí se to do výrazu typu `Option<&'static str>`, jehož hodnota je `Some` hodnoty proměnné prostředí.
    /// Pokud proměnná prostředí není k dispozici, rozbalí se to na `None`.
    /// Další informace o tomto typu najdete v [`Option<T>`][Option].
    ///
    /// Při použití tohoto makra se nikdy nevydá chyba času kompilace bez ohledu na to, zda je proměnná prostředí přítomna nebo ne.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Zřetězí identifikátory do jednoho identifikátoru.
    ///
    /// Toto makro přebírá libovolný počet identifikátorů oddělených čárkami a všechny je spojuje do jednoho, čímž poskytuje výraz, který je novým identifikátorem.
    /// Všimněte si, že hygiena umožňuje, aby toto makro nemohlo zachytit místní proměnné.
    /// Obecně platí, že makra jsou povolena pouze na pozici položky, příkazu nebo výrazu.
    /// To znamená, že i když toto makro můžete použít k odkazování na existující proměnné, funkce nebo moduly atd., Nemůžete s ním definovat nové.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (new, fun, name) { }//takto nepoužitelný!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Zřetězí literály do statického řetězcového řezu.
    ///
    /// Toto makro přebírá libovolný počet literálů oddělených čárkami a poskytuje výraz typu `&'static str`, který představuje všechny literály zřetězené zleva doprava.
    ///
    ///
    /// Celočíselné a plovoucí desetinné čárky jsou zřetězeny, aby mohly být zřetězeny.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Rozbalí se na číslo řádku, na kterém byl vyvolán.
    ///
    /// U [`column!`] a [`file!`] poskytují tato makra vývojářům informace o ladění o umístění ve zdroji.
    ///
    /// Rozšířený výraz má typ `u32` a je založen na 1, takže první řádek v každém souboru se vyhodnotí na 1, druhý na 2 atd.
    /// To je v souladu s chybovými zprávami běžných překladačů nebo populárních editorů.
    /// Vrácený řádek není *nutně* řádek samotného vyvolání `line!`, ale spíše první vyvolání makra vedoucí k vyvolání makra `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Rozbalí se na číslo sloupce, u kterého byl vyvolán.
    ///
    /// U [`line!`] a [`file!`] tato makra poskytují vývojářům informace o ladění o umístění ve zdroji.
    ///
    /// Rozšířený výraz má typ `u32` a je založen na 1, takže první sloupec v každém řádku se vyhodnotí na 1, druhý na 2 atd.
    /// To je v souladu s chybovými zprávami běžných překladačů nebo populárních editorů.
    /// Vrácený sloupec není *nutně* řádek samotného vyvolání `column!`, ale spíše první vyvolání makra vedoucí k vyvolání makra `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Rozbalí se na název souboru, ve kterém byl vyvolán.
    ///
    /// U [`line!`] a [`column!`] poskytují tato makra vývojářům informace o ladění o umístění ve zdroji.
    ///
    /// Rozšířený výraz má typ `&'static str` a vrácený soubor není vyvoláním samotného makra `file!`, ale spíše prvním vyvoláním makra vedoucím k vyvolání makra `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringifikuje jeho argumenty.
    ///
    /// Toto makro přinese výraz typu `&'static str`, což je stringifikace všech tokens předaných makru.
    /// Na syntaxi samotného vyvolání makra nejsou kladena žádná omezení.
    ///
    /// Všimněte si, že rozšířené výsledky vstupu tokens se mohou v future změnit.Pokud se spoléháte na výstup, měli byste být opatrní.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Zahrnuje soubor kódovaný UTF-8 jako řetězec.
    ///
    /// Soubor je umístěn relativně k aktuálnímu souboru (podobně jako jsou nalezeny moduly).
    /// Zadaná cesta je v době kompilace interpretována způsobem specifickým pro platformu.
    /// Například vyvolání s cestou Windows obsahující zpětná lomítka `\` by se na Unix nezkompilovalo správně.
    ///
    ///
    /// Toto makro přinese výraz typu `&'static str`, který je obsahem souboru.
    ///
    /// # Examples
    ///
    /// Předpokládejme, že ve stejném adresáři jsou dva soubory s následujícím obsahem:
    ///
    /// Soubor 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Soubor 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Kompilací 'main.rs' a spuštěním výsledného binárního souboru se vytiskne "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Zahrnuje soubor jako odkaz na bajtové pole.
    ///
    /// Soubor je umístěn relativně k aktuálnímu souboru (podobně jako jsou nalezeny moduly).
    /// Zadaná cesta je v době kompilace interpretována způsobem specifickým pro platformu.
    /// Například vyvolání s cestou Windows obsahující zpětná lomítka `\` by se na Unix nezkompilovalo správně.
    ///
    ///
    /// Toto makro přinese výraz typu `&'static [u8; N]`, který je obsahem souboru.
    ///
    /// # Examples
    ///
    /// Předpokládejme, že ve stejném adresáři jsou dva soubory s následujícím obsahem:
    ///
    /// Soubor 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Soubor 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Kompilací 'main.rs' a spuštěním výsledného binárního souboru se vytiskne "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Rozbalí se na řetězec, který představuje aktuální cestu k modulu.
    ///
    /// Aktuální cestu k modulu lze považovat za hierarchii modulů vedoucích zpět k crate root.
    /// První složkou vrácené cesty je název aktuálně kompilovaného crate.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Vyhodnocuje booleovské kombinace konfiguračních příznaků v době kompilace.
    ///
    /// Kromě atributu `#[cfg]` je toto makro k dispozici, aby umožnilo vyhodnocení logických výrazů konfiguračních příznaků.
    /// To často vede k méně duplikovanému kódu.
    ///
    /// Syntaxe daná tomuto makru je stejná syntaxe jako atribut [`cfg`].
    ///
    /// `cfg!`, na rozdíl od `#[cfg]` neodstraní žádný kód a vyhodnotí se pouze jako true nebo false.
    /// Například všechny bloky ve výrazu if/else musí být platné, když se pro podmínku použije `cfg!`, bez ohledu na to, co `cfg!` vyhodnocuje.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Analyzuje soubor jako výraz nebo položku podle kontextu.
    ///
    /// Soubor je umístěn relativně k aktuálnímu souboru (podobně jako jsou nalezeny moduly).Zadaná cesta je v době kompilace interpretována způsobem specifickým pro platformu.
    /// Například vyvolání s cestou Windows obsahující zpětná lomítka `\` by se na Unix nezkompilovalo správně.
    ///
    /// Použití tohoto makra je často špatný nápad, protože pokud je soubor analyzován jako výraz, bude nehygienicky umístěn do okolního kódu.
    /// To by mohlo mít za následek, že se proměnné nebo funkce budou lišit od toho, co soubor očekával, pokud v aktuálním souboru existují proměnné nebo funkce, které mají stejný název.
    ///
    ///
    /// # Examples
    ///
    /// Předpokládejme, že ve stejném adresáři jsou dva soubory s následujícím obsahem:
    ///
    /// Soubor 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Soubor 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Kompilací 'main.rs' a spuštěním výsledného binárního souboru se vytiskne "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Tvrdí, že logický výraz je `true` za běhu.
    ///
    /// Toto vyvolá makro [`panic!`], pokud zadaný výraz nelze za běhu vyhodnotit na `true`.
    ///
    /// # Uses
    ///
    /// Tvrzení se vždy kontrolují v sestavení ladění i vydání a nelze je deaktivovat.
    /// Viz [`debug_assert!`] pro tvrzení, která nejsou ve výchozím nastavení povolena v sestaveních vydání.
    ///
    /// Nebezpečný kód se může spolehnout na `assert!`, že bude vynucovat run-time invarianty, které by v případě porušení mohly vést k bezpečnosti.
    ///
    /// Mezi další případy použití `assert!` patří testování a vynucování run-time invarianty v bezpečném kódu (jehož porušení nemůže vést k bezpečnosti).
    ///
    ///
    /// # Vlastní zprávy
    ///
    /// Toto makro má druhý formulář, kde lze vlastní zprávu panic poskytnout s argumenty pro formátování nebo bez nich.
    /// Syntaxi tohoto formuláře viz [`std::fmt`].
    /// Výrazy použité jako argumenty formátu budou vyhodnoceny pouze v případě, že se tvrzení nezdaří.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // zpráva panic pro tato tvrzení je přísná hodnota daného výrazu.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // velmi jednoduchá funkce
    ///
    /// assert!(some_computation());
    ///
    /// // prosadit vlastní zprávou
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Inline montáž.
    ///
    /// Přečtěte si o použití [unstable book].
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Vložené sestavení ve stylu LLVM.
    ///
    /// Přečtěte si o použití [unstable book].
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Inline montáž na úrovni modulu.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Výtisky předány tokens do standardního výstupu.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Povolí nebo zakáže funkci trasování používanou pro ladění jiných maker.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Makro atributu použité k použití odvozených maker.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Makro atributu aplikované na funkci, které ji promění v test jednotky.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Makro atributu použité na funkci, které ji proměnilo v test srovnávacího testu.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Detail implementace maker `#[test]` a `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Makro atributu použité na statickou elektřinu, aby se zaregistrovalo jako globální alokátor.
    ///
    /// Viz také [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Ponechá položku, na kterou se vztahuje, pokud je předaná cesta přístupná, a jinak ji odebere.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Rozbalí všechny atributy `#[cfg]` a `#[cfg_attr]` ve fragmentu kódu, na který je aplikován.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Nestabilní implementační detail kompilátoru `rustc`, nepoužívejte.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Nestabilní implementační detail kompilátoru `rustc`, nepoužívejte.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}