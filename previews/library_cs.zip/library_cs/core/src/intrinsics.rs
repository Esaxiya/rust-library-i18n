//! Vnitřní kompilátor.
//!
//! Odpovídající definice jsou v `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Odpovídající implementace const jsou v `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const vnitřní
//!
//! Note: jakékoli změny konstantní povahy by měly být projednány s jazykovým týmem.
//! To zahrnuje změny stability konstance.
//!
//! Aby bylo možné použít intrinsic použitelný v době kompilace, je třeba zkopírovat implementaci z <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> do `compiler/rustc_mir/src/interpret/intrinsics.rs` a přidat `#[rustc_const_unstable(feature = "foo", issue = "01234")]` do intrinsic.
//!
//!
//! Pokud má být vnitřní použita z `const fn` s atributem `rustc_const_stable`, musí být vnitřní atribut také `rustc_const_stable`.
//! Taková změna by neměla být provedena bez konzultace s jazykem T-lang, protože se v ní peče funkce do jazyka, kterou nelze replikovat v uživatelském kódu bez podpory kompilátoru.
//!
//! # Volatiles
//!
//! Nestálé vnitřní funkce poskytují operace určené k činnosti v paměti I/O, u nichž je zaručeno, že nebudou kompilátorem přeuspořádány napříč jinými nestálými vnitřní.Přečtěte si dokumentaci LLVM na [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Atomové vnitřní funkce poskytují běžné atomové operace na strojových slovech s více možnými paměťovými uspořádáními.Poslouchají stejnou sémantiku jako C++ 11.Přečtěte si dokumentaci LLVM na [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Rychlá osvěžení objednávání paměti:
//!
//! * Získejte bariéru pro získání zámku.Následné čtení a zápisy probíhají za bariérou.
//! * Uvolnění, bariéra pro uvolnění zámku.Před bariérou se odehrávají předchozí čtení a zápisy.
//! * Je zaručeno, že postupně konzistentní, postupně konzistentní operace budou probíhat v pořádku.Toto je standardní režim pro práci s atomovými typy a je ekvivalentní `volatile` Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Tyto importy se používají ke zjednodušení odkazů uvnitř dokumentu
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // BEZPEČNOST: viz `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // Upozornění: tyto vnitřní vlastnosti berou surové ukazatele, protože mutují aliasovanou paměť, která není platná pro `&` ani `&mut`.
    //

    /// Uloží hodnotu, pokud je aktuální hodnota stejná jako hodnota `old`.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `compare_exchange` předáním [`Ordering::SeqCst`] jako parametrů `success` i `failure`.
    ///
    /// Například, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, pokud je aktuální hodnota stejná jako hodnota `old`.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `compare_exchange` předáním [`Ordering::Acquire`] jako parametrů `success` i `failure`.
    ///
    /// Například, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, pokud je aktuální hodnota stejná jako hodnota `old`.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `compare_exchange` předáním [`Ordering::Release`] jako `success` a [`Ordering::Relaxed`] jako parametrů `failure`.
    /// Například, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, pokud je aktuální hodnota stejná jako hodnota `old`.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `compare_exchange` předáním [`Ordering::AcqRel`] jako `success` a [`Ordering::Acquire`] jako parametrů `failure`.
    /// Například, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, pokud je aktuální hodnota stejná jako hodnota `old`.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `compare_exchange` předáním [`Ordering::Relaxed`] jako parametrů `success` i `failure`.
    ///
    /// Například, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, pokud je aktuální hodnota stejná jako hodnota `old`.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `compare_exchange` předáním [`Ordering::SeqCst`] jako `success` a [`Ordering::Relaxed`] jako parametrů `failure`.
    /// Například, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, pokud je aktuální hodnota stejná jako hodnota `old`.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `compare_exchange` předáním [`Ordering::SeqCst`] jako `success` a [`Ordering::Acquire`] jako parametrů `failure`.
    /// Například, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, pokud je aktuální hodnota stejná jako hodnota `old`.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `compare_exchange` předáním [`Ordering::Acquire`] jako `success` a [`Ordering::Relaxed`] jako parametrů `failure`.
    /// Například, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, pokud je aktuální hodnota stejná jako hodnota `old`.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `compare_exchange` předáním [`Ordering::AcqRel`] jako `success` a [`Ordering::Relaxed`] jako parametrů `failure`.
    /// Například, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Uloží hodnotu, pokud je aktuální hodnota stejná jako hodnota `old`.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `compare_exchange_weak` předáním [`Ordering::SeqCst`] jako parametrů `success` i `failure`.
    ///
    /// Například, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, pokud je aktuální hodnota stejná jako hodnota `old`.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `compare_exchange_weak` předáním [`Ordering::Acquire`] jako parametrů `success` i `failure`.
    ///
    /// Například, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, pokud je aktuální hodnota stejná jako hodnota `old`.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `compare_exchange_weak` předáním [`Ordering::Release`] jako `success` a [`Ordering::Relaxed`] jako parametrů `failure`.
    /// Například, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, pokud je aktuální hodnota stejná jako hodnota `old`.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `compare_exchange_weak` předáním [`Ordering::AcqRel`] jako `success` a [`Ordering::Acquire`] jako parametrů `failure`.
    /// Například, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, pokud je aktuální hodnota stejná jako hodnota `old`.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `compare_exchange_weak` předáním [`Ordering::Relaxed`] jako parametrů `success` i `failure`.
    ///
    /// Například, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, pokud je aktuální hodnota stejná jako hodnota `old`.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `compare_exchange_weak` předáním [`Ordering::SeqCst`] jako `success` a [`Ordering::Relaxed`] jako parametrů `failure`.
    /// Například, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, pokud je aktuální hodnota stejná jako hodnota `old`.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `compare_exchange_weak` předáním [`Ordering::SeqCst`] jako `success` a [`Ordering::Acquire`] jako parametrů `failure`.
    /// Například, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, pokud je aktuální hodnota stejná jako hodnota `old`.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `compare_exchange_weak` předáním [`Ordering::Acquire`] jako `success` a [`Ordering::Relaxed`] jako parametrů `failure`.
    /// Například, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, pokud je aktuální hodnota stejná jako hodnota `old`.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `compare_exchange_weak` předáním [`Ordering::AcqRel`] jako `success` a [`Ordering::Relaxed`] jako parametrů `failure`.
    /// Například, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Načte aktuální hodnotu ukazatele.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `load` předáním [`Ordering::SeqCst`] jako `order`.
    /// Například, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Načte aktuální hodnotu ukazatele.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `load` předáním [`Ordering::Acquire`] jako `order`.
    /// Například, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Načte aktuální hodnotu ukazatele.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `load` předáním [`Ordering::Relaxed`] jako `order`.
    /// Například, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Uloží hodnotu na určené místo v paměti.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `store` předáním [`Ordering::SeqCst`] jako `order`.
    /// Například, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Uloží hodnotu na určené místo v paměti.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `store` předáním [`Ordering::Release`] jako `order`.
    /// Například, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Uloží hodnotu na určené místo v paměti.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `store` předáním [`Ordering::Relaxed`] jako `order`.
    /// Například, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Uloží hodnotu na určené místo v paměti a vrátí starou hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `swap` předáním [`Ordering::SeqCst`] jako `order`.
    /// Například, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uloží hodnotu na určené místo v paměti a vrátí starou hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `swap` předáním [`Ordering::Acquire`] jako `order`.
    /// Například, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uloží hodnotu na určené místo v paměti a vrátí starou hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `swap` předáním [`Ordering::Release`] jako `order`.
    /// Například, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uloží hodnotu na určené místo v paměti a vrátí starou hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `swap` předáním [`Ordering::AcqRel`] jako `order`.
    /// Například, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uloží hodnotu na určené místo v paměti a vrátí starou hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `swap` předáním [`Ordering::Relaxed`] jako `order`.
    /// Například, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Přidá k aktuální hodnotě a vrátí předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_add` předáním [`Ordering::SeqCst`] jako `order`.
    /// Například, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Přidá k aktuální hodnotě a vrátí předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_add` předáním [`Ordering::Acquire`] jako `order`.
    /// Například, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Přidá k aktuální hodnotě a vrátí předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_add` předáním [`Ordering::Release`] jako `order`.
    /// Například, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Přidá k aktuální hodnotě a vrátí předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_add` předáním [`Ordering::AcqRel`] jako `order`.
    /// Například, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Přidá k aktuální hodnotě a vrátí předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_add` předáním [`Ordering::Relaxed`] jako `order`.
    /// Například, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Odečtěte od aktuální hodnoty a vraťte předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_sub` předáním [`Ordering::SeqCst`] jako `order`.
    /// Například, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Odečtěte od aktuální hodnoty a vraťte předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_sub` předáním [`Ordering::Acquire`] jako `order`.
    /// Například, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Odečtěte od aktuální hodnoty a vraťte předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_sub` předáním [`Ordering::Release`] jako `order`.
    /// Například, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Odečtěte od aktuální hodnoty a vraťte předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_sub` předáním [`Ordering::AcqRel`] jako `order`.
    /// Například, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Odečtěte od aktuální hodnoty a vraťte předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_sub` předáním [`Ordering::Relaxed`] jako `order`.
    /// Například, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Po bitech as aktuální hodnotou vrací předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_and` předáním [`Ordering::SeqCst`] jako `order`.
    /// Například, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Po bitech as aktuální hodnotou vrací předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_and` předáním [`Ordering::Acquire`] jako `order`.
    /// Například, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Po bitech as aktuální hodnotou vrací předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_and` předáním [`Ordering::Release`] jako `order`.
    /// Například, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Po bitech as aktuální hodnotou vrací předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_and` předáním [`Ordering::AcqRel`] jako `order`.
    /// Například, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Po bitech as aktuální hodnotou vrací předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_and` předáním [`Ordering::Relaxed`] jako `order`.
    /// Například, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitová nand s aktuální hodnotou, vrací předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní verze je k dispozici u typu [`AtomicBool`] prostřednictvím metody `fetch_nand` předáním [`Ordering::SeqCst`] jako `order`.
    /// Například, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitová nand s aktuální hodnotou, vrací předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní verze je k dispozici u typu [`AtomicBool`] prostřednictvím metody `fetch_nand` předáním [`Ordering::Acquire`] jako `order`.
    /// Například, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitová nand s aktuální hodnotou, vrací předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní verze je k dispozici u typu [`AtomicBool`] prostřednictvím metody `fetch_nand` předáním [`Ordering::Release`] jako `order`.
    /// Například, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitová nand s aktuální hodnotou, vrací předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní verze je k dispozici u typu [`AtomicBool`] prostřednictvím metody `fetch_nand` předáním [`Ordering::AcqRel`] jako `order`.
    /// Například, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitová nand s aktuální hodnotou, vrací předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní verze je k dispozici u typu [`AtomicBool`] prostřednictvím metody `fetch_nand` předáním [`Ordering::Relaxed`] jako `order`.
    /// Například, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitové nebo s aktuální hodnotou, vrací předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_or` předáním [`Ordering::SeqCst`] jako `order`.
    /// Například, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitové nebo s aktuální hodnotou, vrací předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_or` předáním [`Ordering::Acquire`] jako `order`.
    /// Například, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitové nebo s aktuální hodnotou, vrací předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_or` předáním [`Ordering::Release`] jako `order`.
    /// Například, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitové nebo s aktuální hodnotou, vrací předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_or` předáním [`Ordering::AcqRel`] jako `order`.
    /// Například, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitové nebo s aktuální hodnotou, vrací předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_or` předáním [`Ordering::Relaxed`] jako `order`.
    /// Například, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitový xor s aktuální hodnotou, vrací předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_xor` předáním [`Ordering::SeqCst`] jako `order`.
    /// Například, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitový xor s aktuální hodnotou, vrací předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_xor` předáním [`Ordering::Acquire`] jako `order`.
    /// Například, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitový xor s aktuální hodnotou, vrací předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_xor` předáním [`Ordering::Release`] jako `order`.
    /// Například, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitový xor s aktuální hodnotou, vrací předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_xor` předáním [`Ordering::AcqRel`] jako `order`.
    /// Například, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitový xor s aktuální hodnotou, vrací předchozí hodnotu.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici u typů [`atomic`] pomocí metody `fetch_xor` předáním [`Ordering::Relaxed`] jako `order`.
    /// Například, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximum s aktuální hodnotou pomocí podepsaného srovnání.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici na celočíselných typech se znaménkem [`atomic`] pomocí metody `fetch_max` předáním [`Ordering::SeqCst`] jako `order`.
    /// Například, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum s aktuální hodnotou pomocí podepsaného srovnání.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici na celočíselných typech se znaménkem [`atomic`] pomocí metody `fetch_max` předáním [`Ordering::Acquire`] jako `order`.
    /// Například, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum s aktuální hodnotou pomocí podepsaného srovnání.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici na celočíselných typech se znaménkem [`atomic`] pomocí metody `fetch_max` předáním [`Ordering::Release`] jako `order`.
    /// Například, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum s aktuální hodnotou pomocí podepsaného srovnání.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici na celočíselných typech se znaménkem [`atomic`] pomocí metody `fetch_max` předáním [`Ordering::AcqRel`] jako `order`.
    /// Například, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum s aktuální hodnotou.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici na celočíselných typech se znaménkem [`atomic`] pomocí metody `fetch_max` předáním [`Ordering::Relaxed`] jako `order`.
    /// Například, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum s aktuální hodnotou pomocí podepsaného srovnání.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici na celočíselných typech se znaménkem [`atomic`] pomocí metody `fetch_min` předáním [`Ordering::SeqCst`] jako `order`.
    /// Například, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum s aktuální hodnotou pomocí podepsaného srovnání.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici na celočíselných typech se znaménkem [`atomic`] pomocí metody `fetch_min` předáním [`Ordering::Acquire`] jako `order`.
    /// Například, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum s aktuální hodnotou pomocí podepsaného srovnání.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici na celočíselných typech se znaménkem [`atomic`] pomocí metody `fetch_min` předáním [`Ordering::Release`] jako `order`.
    /// Například, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum s aktuální hodnotou pomocí podepsaného srovnání.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici na celočíselných typech se znaménkem [`atomic`] pomocí metody `fetch_min` předáním [`Ordering::AcqRel`] jako `order`.
    /// Například, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum s aktuální hodnotou pomocí podepsaného srovnání.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici na celočíselných typech se znaménkem [`atomic`] pomocí metody `fetch_min` předáním [`Ordering::Relaxed`] jako `order`.
    /// Například, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum s aktuální hodnotou pomocí nepodepsaného srovnání.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici na celočíselných typech bez znaménka [`atomic`] pomocí metody `fetch_min` předáním [`Ordering::SeqCst`] jako `order`.
    /// Například, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum s aktuální hodnotou pomocí nepodepsaného srovnání.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici na celočíselných typech bez znaménka [`atomic`] pomocí metody `fetch_min` předáním [`Ordering::Acquire`] jako `order`.
    /// Například, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum s aktuální hodnotou pomocí nepodepsaného srovnání.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici na celočíselných typech bez znaménka [`atomic`] pomocí metody `fetch_min` předáním [`Ordering::Release`] jako `order`.
    /// Například, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum s aktuální hodnotou pomocí nepodepsaného srovnání.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici na celočíselných typech bez znaménka [`atomic`] pomocí metody `fetch_min` předáním [`Ordering::AcqRel`] jako `order`.
    /// Například, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum s aktuální hodnotou pomocí nepodepsaného srovnání.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici na celočíselných typech bez znaménka [`atomic`] pomocí metody `fetch_min` předáním [`Ordering::Relaxed`] jako `order`.
    /// Například, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximum s aktuální hodnotou pomocí nepodepsaného srovnání.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici na celočíselných typech bez znaménka [`atomic`] pomocí metody `fetch_max` předáním [`Ordering::SeqCst`] jako `order`.
    /// Například, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum s aktuální hodnotou pomocí nepodepsaného srovnání.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici na celočíselných typech bez znaménka [`atomic`] pomocí metody `fetch_max` předáním [`Ordering::Acquire`] jako `order`.
    /// Například, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum s aktuální hodnotou pomocí nepodepsaného srovnání.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici na celočíselných typech bez znaménka [`atomic`] pomocí metody `fetch_max` předáním [`Ordering::Release`] jako `order`.
    /// Například, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum s aktuální hodnotou pomocí nepodepsaného srovnání.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici na celočíselných typech bez znaménka [`atomic`] pomocí metody `fetch_max` předáním [`Ordering::AcqRel`] jako `order`.
    /// Například, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum s aktuální hodnotou pomocí nepodepsaného srovnání.
    ///
    /// Stabilizovaná verze této vnitřní funkce je k dispozici na celočíselných typech bez znaménka [`atomic`] pomocí metody `fetch_max` předáním [`Ordering::Relaxed`] jako `order`.
    /// Například, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Vnitřní `prefetch` je nápověda ke generátoru kódu pro vložení instrukce předběžného načtení, pokud je podporována;jinak je to no-op.
    /// Prefetches nemají žádný vliv na chování programu, ale mohou změnit jeho výkonnostní charakteristiky.
    ///
    /// Argument `locality` musí být konstantní celé číslo a je specifikátorem časové lokality v rozsahu od (0), žádná lokalita, po (3), extrémně lokální uchování v mezipaměti.
    ///
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Vnitřní `prefetch` je nápověda ke generátoru kódu pro vložení instrukce předběžného načtení, pokud je podporována;jinak je to no-op.
    /// Prefetches nemají žádný vliv na chování programu, ale mohou změnit jeho výkonnostní charakteristiky.
    ///
    /// Argument `locality` musí být konstantní celé číslo a je specifikátorem časové lokality v rozsahu od (0), žádná lokalita, po (3), extrémně lokální uchování v mezipaměti.
    ///
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Vnitřní `prefetch` je nápověda ke generátoru kódu pro vložení instrukce předběžného načtení, pokud je podporována;jinak je to no-op.
    /// Prefetches nemají žádný vliv na chování programu, ale mohou změnit jeho výkonnostní charakteristiky.
    ///
    /// Argument `locality` musí být konstantní celé číslo a je specifikátorem časové lokality v rozsahu od (0), žádná lokalita, po (3), extrémně lokální uchování v mezipaměti.
    ///
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Vnitřní `prefetch` je nápověda ke generátoru kódu pro vložení instrukce předběžného načtení, pokud je podporována;jinak je to no-op.
    /// Prefetches nemají žádný vliv na chování programu, ale mohou změnit jeho výkonnostní charakteristiky.
    ///
    /// Argument `locality` musí být konstantní celé číslo a je specifikátorem časové lokality v rozsahu od (0), žádná lokalita, po (3), extrémně lokální uchování v mezipaměti.
    ///
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Atomový plot.
    ///
    /// Stabilizovaná verze této vnitřní verze je k dispozici v [`atomic::fence`] předáním [`Ordering::SeqCst`] jako `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Atomový plot.
    ///
    /// Stabilizovaná verze této vnitřní verze je k dispozici v [`atomic::fence`] předáním [`Ordering::Acquire`] jako `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Atomový plot.
    ///
    /// Stabilizovaná verze této vnitřní verze je k dispozici v [`atomic::fence`] předáním [`Ordering::Release`] jako `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Atomový plot.
    ///
    /// Stabilizovaná verze této vnitřní verze je k dispozici v [`atomic::fence`] předáním [`Ordering::AcqRel`] jako `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Bariéra paměti pouze pro kompilátor.
    ///
    /// Přístupy do paměti kompilátor přes tuto bariéru nikdy nezmění, ale nebudou pro něj vydány žádné pokyny.
    /// To je vhodné pro operace na stejném vlákně, které mohou být preempted, například při interakci s obslužnými rutinami signálu.
    ///
    /// Stabilizovaná verze této vnitřní verze je k dispozici v [`atomic::compiler_fence`] předáním [`Ordering::SeqCst`] jako `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Bariéra paměti pouze pro kompilátor.
    ///
    /// Přístupy do paměti kompilátor přes tuto bariéru nikdy nezmění, ale nebudou pro něj vydány žádné pokyny.
    /// To je vhodné pro operace na stejném vlákně, které mohou být preempted, například při interakci s obslužnými rutinami signálu.
    ///
    /// Stabilizovaná verze této vnitřní verze je k dispozici v [`atomic::compiler_fence`] předáním [`Ordering::Acquire`] jako `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Bariéra paměti pouze pro kompilátor.
    ///
    /// Přístupy do paměti kompilátor přes tuto bariéru nikdy nezmění, ale nebudou pro něj vydány žádné pokyny.
    /// To je vhodné pro operace na stejném vlákně, které mohou být preempted, například při interakci s obslužnými rutinami signálu.
    ///
    /// Stabilizovaná verze této vnitřní verze je k dispozici v [`atomic::compiler_fence`] předáním [`Ordering::Release`] jako `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Bariéra paměti pouze pro kompilátor.
    ///
    /// Přístupy do paměti kompilátor přes tuto bariéru nikdy nezmění, ale nebudou pro něj vydány žádné pokyny.
    /// To je vhodné pro operace na stejném vlákně, které mohou být preempted, například při interakci s obslužnými rutinami signálu.
    ///
    /// Stabilizovaná verze této vnitřní verze je k dispozici v [`atomic::compiler_fence`] předáním [`Ordering::AcqRel`] jako `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magické vnitřní, které odvozuje svůj význam od atributů připojených k funkci.
    ///
    /// Například tok dat to používá k vložení statických tvrzení, aby `rustc_peek(potentially_uninitialized)` ve skutečnosti dvakrát zkontroloval, zda tok dat skutečně spočítal, že je neinicializovaný v daném bodě v toku řízení.
    ///
    ///
    /// Tento vnitřní by neměl být používán mimo kompilátor.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Přeruší provádění procesu.
    ///
    /// Uživatelsky přívětivější a stabilnější verze této operace je [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Informuje optimalizátor, že tento bod v kódu není dosažitelný, což umožňuje další optimalizace.
    ///
    /// Pozn., Toto se velmi liší od makra `unreachable!()`: Na rozdíl od makra, které panics při svém spuštění dosáhne kódu označeného touto funkcí, je *nedefinované chování*.
    ///
    ///
    /// Stabilizovaná verze této vnitřní verze je [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Informuje optimalizátor, že podmínka je vždy pravdivá.
    /// Pokud je podmínka nepravdivá, chování není definováno.
    ///
    /// Pro tento inherentní není generován žádný kód, ale optimalizátor se pokusí jej zachovat (a jeho stav) mezi průchody, což může narušit optimalizaci okolního kódu a snížit výkon.
    /// Nemělo by se používat, pokud může invariant sám zjistit optimalizátor nebo pokud neumožňuje žádné významné optimalizace.
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Rady kompilátoru, že podmínka branch bude pravděpodobně pravdivá.
    /// Vrátí předanou hodnotu.
    ///
    /// Jakékoli jiné použití než s příkazy `if` pravděpodobně nebude mít žádný účinek.
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Rady kompilátoru, že podmínka branch bude pravděpodobně nepravdivá.
    /// Vrátí předanou hodnotu.
    ///
    /// Jakékoli jiné použití než s příkazy `if` pravděpodobně nebude mít žádný účinek.
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Spustí past zarážky pro kontrolu debuggerem.
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    pub fn breakpoint();

    /// Velikost typu v bajtech.
    ///
    /// Konkrétněji se jedná o posun v bajtech mezi po sobě jdoucími položkami stejného typu, včetně zarovnávací výplně.
    ///
    ///
    /// Stabilizovaná verze této vnitřní verze je [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Minimální zarovnání typu.
    ///
    /// Stabilizovaná verze této vnitřní verze je [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Preferované zarovnání typu.
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Velikost odkazované hodnoty v bajtech.
    ///
    /// Stabilizovaná verze této vnitřní verze je [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Požadované zarovnání odkazované hodnoty.
    ///
    /// Stabilizovaná verze této vnitřní verze je [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Získá statický řetězcový řez obsahující název typu.
    ///
    /// Stabilizovaná verze této vnitřní verze je [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Získá identifikátor, který je globálně jedinečný pro zadaný typ.
    /// Tato funkce vrátí stejnou hodnotu pro typ bez ohledu na to, v kterém je crate vyvolána.
    ///
    ///
    /// Stabilizovaná verze této vnitřní verze je [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Ochranu pro nebezpečné funkce, které nelze nikdy provést, pokud je `T` neobydlený:
    /// To bude staticky buď panic, nebo nic nedělat.
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Ochranu pro nebezpečné funkce, které nikdy nelze provést, pokud `T` neumožňuje nulovou inicializaci: Staticky to buď panic, nebo neudělat nic.
    ///
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    pub fn assert_zero_valid<T>();

    /// Ochranu pro nebezpečné funkce, které nelze nikdy provést, pokud má `T` neplatné bitové vzory: Toto bude staticky buď panic, nebo nedělat nic.
    ///
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    pub fn assert_uninit_valid<T>();

    /// Získá odkaz na statický `Location` označující, kde byl volán.
    ///
    /// Místo toho zvažte použití [`core::panic::Location::caller`](crate::panic::Location::caller).
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Přesune hodnotu mimo rozsah bez spuštění lepidla.
    ///
    /// Toto existuje pouze pro [`mem::forget_unsized`];normální `forget` místo toho používá `ManuallyDrop`.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Znovu interpretuje bity hodnoty jednoho typu jako jiného typu.
    ///
    /// Oba typy musí mít stejnou velikost.
    /// Originál ani výsledek nemusí být [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` je sémanticky ekvivalentní bitovému přesunu jednoho typu do druhého.Zkopíruje bity ze zdrojové hodnoty do cílové hodnoty a poté zapomene na originál.
    /// Je to ekvivalent C `memcpy` pod kapotou, stejně jako `transmute_copy`.
    ///
    /// Protože `transmute` je operace podle hodnoty, zarovnání samotných *transmutovaných hodnot* není problém.
    /// Stejně jako u jakékoli jiné funkce kompilátor již zajišťuje, že `T` i `U` jsou správně zarovnány.
    /// Při převádění hodnot, které *směřují jinam*(například ukazatele, odkazy, políčka…), musí volající zajistit správné zarovnání namířených hodnot.
    ///
    /// `transmute` je **neuvěřitelně** nebezpečný.Existuje obrovské množství způsobů, jak tuto funkci způsobit [undefined behavior][ub].`transmute` by měl být absolutním posledním řešením.
    ///
    /// [nomicon](../../nomicon/transmutes.html) má další dokumentaci.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Existuje několik věcí, pro které je `transmute` opravdu užitečný.
    ///
    /// Proměna ukazatele na ukazatel funkce.To *není* přenosné do strojů, kde mají ukazatele funkcí a datové ukazatele různé velikosti.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Prodloužení životnosti nebo zkrácení neměnné životnosti.Toto je pokročilý, velmi nebezpečný Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Nezoufejte: mnoha použití `transmute` lze dosáhnout jinými způsoby.
    /// Níže jsou uvedeny běžné aplikace `transmute`, které lze nahradit bezpečnějšími konstrukcemi.
    ///
    /// Otáčení surového bytes(`&[u8]`) na `u32`, `f64` atd .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // místo toho použijte `u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // nebo použijte `u32::from_le_bytes` nebo `u32::from_be_bytes` k určení endianity
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Proměna ukazatele na `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Místo toho použijte obsazení `as`
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Přeměna `*mut T` na `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Místo toho použijte znovuzískání
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Přeměna `&mut T` na `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Nyní sestavte `as` a opětovné vypěstování, všimněte si, že řetězení `as` `as` není přechodné
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Přeměna `&str` na `&[u8]`:
    ///
    /// ```
    /// // to není dobrý způsob, jak to udělat.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Můžete použít `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Nebo použijte pouze bajtový řetězec, pokud máte kontrolu nad řetězcovým literálem
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Přeměna `Vec<&T>` na `Vec<Option<&T>>`.
    ///
    /// Chcete-li přeměnit vnitřní typ obsahu kontejneru, musíte se ujistit, že neporušíte žádný invarianty kontejneru.
    /// U `Vec` to znamená, že se musí shodovat jak velikost *, tak zarovnání* vnitřních typů.
    /// Jiné kontejnery se mohou spoléhat na velikost typu, zarovnání nebo dokonce `TypeId`, v takovém případě by transmuting vůbec nebyl možný, aniž by došlo k porušení invariantů kontejneru.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // naklonujte vector, protože je později znovu použijeme
    /// let v_clone = v_orig.clone();
    ///
    /// // Použití transmute: to se spoléhá na neurčené rozložení dat `Vec`, což je špatný nápad a může způsobit nedefinované chování.
    /////
    /// // Není to však žádná kopie.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Toto je navrhovaný a bezpečný způsob.
    /// // Zkopíruje však celý vector do nového pole.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Toto je správný a bezpečný způsob kopírování "transmuting" a `Vec` bez spoléhání se na rozložení dat.
    /// // Místo doslovného volání `transmute` provádíme obsazení ukazatele, ale pokud jde o převod původního vnitřního typu (`&i32`) na nový (`Option<&i32>`), má to stejné upozornění.
    /////
    /// // Kromě výše uvedených informací nahlédněte také do dokumentace [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Aktualizujte to, když je stabilizována věc_into_raw_parts.
    ///     // Zajistěte, aby původní vector nespadl.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Implementace `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Existuje několik způsobů, jak toho dosáhnout, a s následujícím způsobem (transmute) existuje několik problémů.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // první: transmute není bezpečný typ;vše, co kontroluje, je, že T a
    ///         // U jsou stejné velikosti.
    ///         // Zadruhé, tady máte dva proměnlivé odkazy směřující do stejné paměti.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Tím se zbavíte bezpečnostních problémů typu;`&mut *` vám* pouze *dá `&mut T` z `&mut T` nebo `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // stále však máte dva proměnlivé odkazy odkazující na stejnou paměť.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Takto to dělá standardní knihovna.
    /// // Toto je nejlepší metoda, pokud potřebujete něco takového udělat
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // To má nyní tři proměnlivé odkazy směřující na stejnou paměť.`slice`, rvalue ret.0 a rvalue ret.1.
    ///         // `slice` se nikdy nepoužívá po `let ptr = ...`, a proto s ním lze zacházet jako s "dead", a proto máte pouze dva skutečné proměnlivé řezy.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: I když to dělá vnitřní const stabilní, v const fn máme nějaký vlastní kód
    // kontroly, které brání jeho použití v `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Vrátí `true`, pokud skutečný typ zadaný jako `T` vyžaduje lepidlo;vrátí `false`, pokud skutečný typ poskytnutý pro `T` implementuje `Copy`.
    ///
    ///
    /// Pokud skutečný typ nevyžaduje lepidlo na kapky ani neimplementuje `Copy`, pak je návratová hodnota této funkce nespecifikována.
    ///
    /// Stabilizovaná verze této vnitřní verze je [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Vypočítá posunutí od ukazatele.
    ///
    /// To je implementováno jako vnitřní, aby se zabránilo převodu na celé číslo a od něj, protože převod by vyhodil informace o aliasingu.
    ///
    /// # Safety
    ///
    /// Počáteční i výsledný ukazatel musí být buď v mezích, nebo o jeden bajt za koncem přiděleného objektu.
    /// Pokud je některý ukazatel mimo meze nebo dojde k přetečení aritmetiky, pak jakékoli další použití vrácené hodnoty bude mít za následek nedefinované chování.
    ///
    ///
    /// Stabilizovaná verze této vnitřní verze je [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Vypočítá posunutí od ukazatele, potenciálně zalomení.
    ///
    /// To je implementováno jako vnitřní, aby se zabránilo převodu na a z celého čísla, protože převod inhibuje určité optimalizace.
    ///
    /// # Safety
    ///
    /// Na rozdíl od vnitřní `offset`, tato vnitřní neomezuje výsledný ukazatel tak, aby ukazoval na nebo jeden bajt za konec přiděleného objektu, a obtéká se aritmetikou dvou doplňků.
    /// Výsledná hodnota nemusí být nutně platná, aby mohla být použita ke skutečnému přístupu do paměti.
    ///
    /// Stabilizovaná verze této vnitřní verze je [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Odpovídá příslušnému vnitřnímu `llvm.memcpy.p0i8.0i8.*`, s velikostí `count`*`size_of::<T>()` a zarovnáním na
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parametr těkavých látek je nastaven na `true`, takže nebude optimalizován, pokud se velikost nerovná nule.
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Odpovídá příslušnému vnitřnímu `llvm.memmove.p0i8.0i8.*`, s velikostí `count* size_of::<T>()` a zarovnáním na
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parametr těkavých látek je nastaven na `true`, takže nebude optimalizován, pokud se velikost nerovná nule.
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Odpovídá příslušnému vnitřnímu `llvm.memset.p0i8.*`, s velikostí `count* size_of::<T>()` a zarovnáním `min_align_of::<T>()`.
    ///
    ///
    /// Parametr těkavých látek je nastaven na `true`, takže nebude optimalizován, pokud se velikost nerovná nule.
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Provádí volatilní zatížení z ukazatele `src`.
    ///
    /// Stabilizovaná verze této vnitřní verze je [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Provede volatilní úložiště na ukazatel `dst`.
    ///
    /// Stabilizovaná verze této vnitřní verze je [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Provádí nestálé zatížení z ukazatele `src` Ukazatel nemusí být zarovnán.
    ///
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Provede volatilní úložiště na ukazatel `dst`.
    /// Ukazatel nemusí být zarovnán.
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Vrátí druhou odmocninu `f32`
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Vrátí druhou odmocninu `f64`
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Zvyšuje `f32` na celočíselnou mocninu.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Zvyšuje `f64` na celočíselnou mocninu.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Vrátí sinus `f32`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Vrátí sinus `f64`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Vrátí kosinus `f32`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Vrátí kosinus `f64`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Zvyšuje `f32` na `f32`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Zvyšuje `f64` na `f64`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Vrátí exponenciál `f32`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Vrátí exponenciál `f64`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Vrátí hodnotu 2 zvýšenou na sílu `f32`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Vrátí hodnotu 2 zvýšenou na sílu `f64`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Vrátí přirozený logaritmus `f32`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Vrátí přirozený logaritmus `f64`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Vrátí základní 10 logaritmus `f32`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Vrátí základní 10 logaritmus `f64`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Vrátí základní 2 logaritmus `f32`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Vrátí základní 2 logaritmus `f64`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Vrátí `a * b + c` pro hodnoty `f32`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Vrátí `a * b + c` pro hodnoty `f64`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Vrátí absolutní hodnotu `f32`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Vrátí absolutní hodnotu `f64`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Vrátí minimálně dvě hodnoty `f32`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Vrátí minimálně dvě hodnoty `f64`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Vrátí maximálně dvě hodnoty `f32`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Vrátí maximálně dvě hodnoty `f64`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Zkopíruje znaménko z `y` do `x` pro hodnoty `f32`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Zkopíruje znaménko z `y` do `x` pro hodnoty `f64`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Vrátí největší celé číslo menší nebo rovno `f32`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Vrátí největší celé číslo menší nebo rovno `f64`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Vrátí nejmenší celé číslo větší nebo rovno `f32`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Vrátí nejmenší celé číslo větší nebo rovno `f64`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Vrátí celočíselnou část `f32`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Vrátí celočíselnou část `f64`.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Vrátí nejbližší celé číslo k `f32`.
    /// Může vyvolat nepřesnou výjimku s plovoucí desetinnou čárkou, pokud argument není celé číslo.
    pub fn rintf32(x: f32) -> f32;
    /// Vrátí nejbližší celé číslo k `f64`.
    /// Může vyvolat nepřesnou výjimku s plovoucí desetinnou čárkou, pokud argument není celé číslo.
    pub fn rintf64(x: f64) -> f64;

    /// Vrátí nejbližší celé číslo k `f32`.
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Vrátí nejbližší celé číslo k `f64`.
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Vrátí nejbližší celé číslo k `f32`.Zaokrouhlí případy na půl cesty od nuly.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Vrátí nejbližší celé číslo k `f64`.Zaokrouhlí případy na půl cesty od nuly.
    ///
    /// Stabilizovaná verze této vnitřní verze je
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Plovoucí doplněk, který umožňuje optimalizaci založenou na algebraických pravidlech.
    /// Může předpokládat, že vstupy jsou konečné.
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Plovoucí odčítání, které umožňuje optimalizaci založenou na algebraických pravidlech.
    /// Může předpokládat, že vstupy jsou konečné.
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Plovoucí násobení, které umožňuje optimalizace založené na algebraických pravidlech.
    /// Může předpokládat, že vstupy jsou konečné.
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Plovoucí dělení, které umožňuje optimalizace založené na algebraických pravidlech.
    /// Může předpokládat, že vstupy jsou konečné.
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Plovoucí zbytek, který umožňuje optimalizace založené na algebraických pravidlech.
    /// Může předpokládat, že vstupy jsou konečné.
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Převod pomocí LLVM fptoui/fptosi, který může vrátit undef pro hodnoty mimo rozsah
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabilizováno jako [`f32::to_int_unchecked`] a [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Vrátí počet bitů nastavený na celé číslo typu `T`
    ///
    /// Stabilizované verze této vnitřní jsou k dispozici na celočíselných primitivech pomocí metody `count_ones`.
    /// Například,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Vrátí počet úvodních nezastavených bitů (zeroes) v celočíselném typu `T`.
    ///
    /// Stabilizované verze této vnitřní jsou k dispozici na celočíselných primitivech pomocí metody `leading_zeros`.
    /// Například,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` s hodnotou `0` vrátí bitovou šířku `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Stejně jako `ctlz`, ale mimořádně nebezpečný, protože vrací `undef`, když dostane `x` s hodnotou `0`.
    ///
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Vrátí počet koncových nezastavených bitů (zeroes) v celočíselném typu `T`.
    ///
    /// Stabilizované verze této vnitřní jsou k dispozici na celočíselných primitivech pomocí metody `trailing_zeros`.
    /// Například,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` s hodnotou `0` vrátí bitovou šířku `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Stejně jako `cttz`, ale mimořádně nebezpečný, protože vrací `undef`, když dostane `x` s hodnotou `0`.
    ///
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Obrátí bajty v celočíselném typu `T`.
    ///
    /// Stabilizované verze této vnitřní jsou k dispozici na celočíselných primitivech pomocí metody `swap_bytes`.
    /// Například,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Obrátí bity v celočíselném typu `T`.
    ///
    /// Stabilizované verze této vnitřní jsou k dispozici na celočíselných primitivech pomocí metody `reverse_bits`.
    /// Například,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Provede zaškrtnutí celého čísla.
    ///
    /// Stabilizované verze této vnitřní jsou k dispozici na celočíselných primitivech pomocí metody `overflowing_add`.
    /// Například,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Provede odečtení zkontrolovaného celého čísla
    ///
    /// Stabilizované verze této vnitřní jsou k dispozici na celočíselných primitivech pomocí metody `overflowing_sub`.
    /// Například,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Provádí zaškrtnuté celočíselné násobení
    ///
    /// Stabilizované verze této vnitřní jsou k dispozici na celočíselných primitivech pomocí metody `overflowing_mul`.
    /// Například,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Provede přesné dělení, což má za následek nedefinované chování, kde `x % y != 0` nebo `y == 0` nebo `x == T::MIN && y == -1`
    ///
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Provádí nekontrolované dělení, což má za následek nedefinované chování, kde `y == 0` nebo `x == T::MIN && y == -1`
    ///
    ///
    /// Bezpečné obálky pro tuto vnitřní vlastnost jsou k dispozici na celočíselných primitivech pomocí metody `checked_div`.
    /// Například,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Vrátí zbytek nekontrolovaného dělení, což má za následek nedefinované chování při `y == 0` nebo `x == T::MIN && y == -1`
    ///
    ///
    /// Bezpečné obálky pro tuto vnitřní vlastnost jsou k dispozici na celočíselných primitivech pomocí metody `checked_rem`.
    /// Například,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Provede nezaškrtnutý levý posun, což má za následek nedefinované chování, když `y < 0` nebo `y >= N`, kde N je šířka T v bitech.
    ///
    ///
    /// Bezpečné obálky pro tuto vnitřní vlastnost jsou k dispozici na celočíselných primitivech pomocí metody `checked_shl`.
    /// Například,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Provede nekontrolovaný pravý posun, což má za následek nedefinované chování, když `y < 0` nebo `y >= N`, kde N je šířka T v bitech.
    ///
    ///
    /// Bezpečné obálky pro tuto vnitřní vlastnost jsou k dispozici na celočíselných primitivech pomocí metody `checked_shr`.
    /// Například,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Vrátí výsledek nekontrolovaného přidání, což má za následek nedefinované chování při `x + y > T::MAX` nebo `x + y < T::MIN`.
    ///
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Vrátí výsledek nekontrolovaného odčítání, což má za následek nedefinované chování při `x - y > T::MAX` nebo `x - y < T::MIN`.
    ///
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Vrátí výsledek nekontrolovaného násobení, což má za následek nedefinované chování při `x *y > T::MAX` nebo `x* y < T::MIN`.
    ///
    ///
    /// Tento vnitřní nemá stabilní protějšek.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Provede rotaci doleva.
    ///
    /// Stabilizované verze této vnitřní jsou k dispozici na celočíselných primitivech pomocí metody `rotate_left`.
    /// Například,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Provede rotaci doprava.
    ///
    /// Stabilizované verze této vnitřní jsou k dispozici na celočíselných primitivech pomocí metody `rotate_right`.
    /// Například,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Vrátí (a + b) mod 2 <sup>N</sup>, kde N je šířka T v bitech.
    ///
    /// Stabilizované verze této vnitřní jsou k dispozici na celočíselných primitivech pomocí metody `wrapping_add`.
    /// Například,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Vrátí (a, b) mod 2 <sup>N</sup>, kde N je šířka T v bitech.
    ///
    /// Stabilizované verze této vnitřní jsou k dispozici na celočíselných primitivech pomocí metody `wrapping_sub`.
    /// Například,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Vrátí (a * b) mod 2 <sup>N</sup>, kde N je šířka T v bitech.
    ///
    /// Stabilizované verze této vnitřní jsou k dispozici na celočíselných primitivech pomocí metody `wrapping_mul`.
    /// Například,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Vypočítá `a + b` a saturuje se na číselné hranici.
    ///
    /// Stabilizované verze této vnitřní jsou k dispozici na celočíselných primitivech pomocí metody `saturating_add`.
    /// Například,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Vypočítá `a - b` a saturuje se na číselné hranici.
    ///
    /// Stabilizované verze této vnitřní jsou k dispozici na celočíselných primitivech pomocí metody `saturating_sub`.
    /// Například,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Vrátí hodnotu diskriminátoru pro variantu v 'v';
    /// pokud `T` nemá žádný diskriminační, vrátí `0`.
    ///
    /// Stabilizovaná verze této vnitřní verze je [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Vrátí počet variant obsazení typu `T` na `usize`;
    /// pokud `T` nemá žádné varianty, vrátí `0`.Neobývané varianty budou započítány.
    ///
    /// Stabilizovanou verzí této vnitřní verze je [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Konstrukce "try catch" Rust, která vyvolá funkční ukazatel `try_fn` s datovým ukazatelem `data`.
    ///
    /// Třetím argumentem je funkce volaná, pokud dojde k panic.
    /// Tato funkce přebírá datový ukazatel a ukazatel na objekt výjimky specifický pro cíl, který byl chycen.
    ///
    /// Další informace najdete v zdroji kompilátoru a implementaci úlovku std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Vydává obchod `!nontemporal` podle LLVM (viz jejich dokumenty).
    /// Pravděpodobně se nikdy nestane stabilním.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Podrobnosti najdete v dokumentaci k `<*const T>::offset_from`.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Podrobnosti najdete v dokumentaci k `<*const T>::guaranteed_eq`.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Podrobnosti najdete v dokumentaci k `<*const T>::guaranteed_ne`.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Přidělit v době kompilace.Nemělo by být voláno za běhu.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Zde jsou definovány některé funkce, protože byly omylem zpřístupněny v tomto modulu ve stabilní verzi.
// Viz <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` také spadá do této kategorie, ale nelze jej zabalit kvůli kontrole, že `T` a `U` mají stejnou velikost.)
//

/// Zkontroluje, zda je `ptr` správně zarovnán vzhledem k `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kopíruje bajty `count *size_of::<T>()` z `src` do `dst`.Zdroj a cíl se nesmí* překrývat *.
///
/// Pro oblasti paměti, které se mohou překrývat, použijte místo toho [`copy`].
///
/// `copy_nonoverlapping` je sémanticky ekvivalentní s [`memcpy`] C, ale s vyměněným pořadím argumentů.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Chování není definováno, pokud dojde k porušení některé z následujících podmínek:
///
/// * `src` musí být [valid] pro čtení `count * size_of::<T>()` bajtů.
///
/// * `dst` musí být [valid] pro zápis `count * size_of::<T>()` bajtů.
///
/// * `src` i `dst` musí být správně zarovnány.
///
/// * Oblast paměti začínající na `src` s velikostí `count *
///   velikost: :<T>() `bajty se *nesmí* překrývat s oblastí paměti začínající na `dst` se stejnou velikostí.
///
/// Stejně jako [`read`], i `copy_nonoverlapping` vytváří bitovou kopii `T`, bez ohledu na to, zda `T` je [`Copy`].
/// Pokud `T` není [`Copy`], použití *obou* hodnot v oblasti začínající na `*src` a oblasti začínající na `* dst` může [violate memory safety][read-ownership].
///
///
/// Všimněte si, že i když je skutečně zkopírována velikost (`count * size_of: :<T>()`) je `0`, ukazatele musí mít jinou hodnotu než NULL a musí být správně zarovnány.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Ručně implementovat [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Přesune všechny prvky `src` do `dst`, přičemž `src` zůstane prázdný.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Ujistěte se, že `dst` má dostatečnou kapacitu pro uložení všech `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Volání offsetu je vždy bezpečné, protože `Vec` nikdy nepřidělí více než `isize::MAX` bajtů.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Zkraťte `src` bez upuštění obsahu.
///         // Nejprve to uděláme, abychom se vyhnuli problémům v případě, že bude něco dále od panics.
///         src.set_len(0);
///
///         // Tyto dvě oblasti se nemohou překrývat, protože proměnlivé odkazy nemají alias a dva různé vectors nemohou vlastnit stejnou paměť.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Upozorněte `dst`, že nyní obsahuje obsah `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Tyto kontroly provádějte pouze za běhu
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Nepanikaří, aby byl dopad kodegenu menší.
        abort();
    }*/

    // BEZPEČNOST: bezpečnostní smlouva pro `copy_nonoverlapping` musí být
    // potvrzuje volající.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Kopíruje bajty `count * size_of::<T>()` z `src` do `dst`.Zdroj a cíl se mohou překrývat.
///
/// Pokud se zdroj a cíl *nikdy* nepřekrývají, lze místo nich použít [`copy_nonoverlapping`].
///
/// `copy` je sémanticky ekvivalentní s [`memmove`] C, ale s vyměněným pořadím argumentů.
/// Kopírování probíhá, jako by byly bajty zkopírovány z `src` do dočasného pole a poté zkopírovány z pole do `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Chování není definováno, pokud dojde k porušení některé z následujících podmínek:
///
/// * `src` musí být [valid] pro čtení `count * size_of::<T>()` bajtů.
///
/// * `dst` musí být [valid] pro zápis `count * size_of::<T>()` bajtů.
///
/// * `src` i `dst` musí být správně zarovnány.
///
/// Stejně jako [`read`], i `copy` vytváří bitovou kopii `T`, bez ohledu na to, zda `T` je [`Copy`].
/// Pokud `T` není [`Copy`], lze použít hodnoty jak v oblasti začínající `*src`, tak v oblasti začínající `* dst` [violate memory safety][read-ownership].
///
///
/// Všimněte si, že i když je skutečně zkopírována velikost (`count * size_of: :<T>()`) je `0`, ukazatele musí mít jinou hodnotu než NULL a musí být správně zarovnány.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Efektivně vytvořte Rust vector z nebezpečné paměti:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` musí být správně zarovnán pro svůj typ a nenulový.
/// /// * `ptr` musí být platné pro čtení souvislých prvků `elts` typu `T`.
/// /// * Tyto prvky nesmí být použity po volání této funkce, pokud `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // BEZPEČNOST: Náš předpoklad zajišťuje, že zdroj je zarovnaný a platný,
///     // a `Vec::with_capacity` zajišťuje, že máme využitelný prostor pro jejich zápis.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // BEZPEČNOST: S touto velkou kapacitou jsme to vytvořili dříve,
///     // a předchozí `copy` tyto prvky inicializoval.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Tyto kontroly provádějte pouze za běhu
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Nepanikaří, aby byl dopad kodegenu menší.
        abort();
    }*/

    // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `copy`.
    unsafe { copy(src, dst, count) }
}

/// Nastaví `count * size_of::<T>()` bajtů paměti od `dst` do `val`.
///
/// `write_bytes` je podobný [`memset`] C, ale nastavuje `count * size_of::<T>()` bajtů na `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Chování není definováno, pokud dojde k porušení některé z následujících podmínek:
///
/// * `dst` musí být [valid] pro zápis `count * size_of::<T>()` bajtů.
///
/// * `dst` musí být správně zarovnány.
///
/// Volající navíc musí zajistit, aby zápis bajtů `count * size_of::<T>()` do dané oblasti paměti vedl k platné hodnotě `T`.
/// Použití oblasti paměti zadané jako `T`, která obsahuje neplatnou hodnotu `T`, je nedefinované chování.
///
/// Všimněte si, že i když je skutečně zkopírována velikost (`count * size_of: :<T>()`) je `0`, ukazatel musí mít jinou hodnotu než NULL a musí být správně zarovnán.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Základní použití:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Vytvoření neplatné hodnoty:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Netěsí dříve drženou hodnotu přepsáním `Box<T>` nulovým ukazatelem.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // V tomto okamžiku má použití nebo zrušení `v` za následek nedefinované chování.
/// // drop(v); // ERROR
///
/// // Dokonce i netěsnost `v` "uses", a proto je nedefinované chování.
/// // mem::forget(v); // ERROR
///
/// // Ve skutečnosti je `v` podle invariantů rozložení základního typu neplatný, takže *jakákoli* operace, která se ho dotkne, je nedefinované chování.
/////
/// // nechť v2 =v;//CHYBA
///
/// unsafe {
///     // Pojďme místo toho zadat platnou hodnotu
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Nyní je krabička v pořádku
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `write_bytes`.
    unsafe { write_bytes(dst, val, count) }
}