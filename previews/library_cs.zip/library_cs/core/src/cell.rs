//! Sdílitelné měnitelné kontejnery.
//!
//! Bezpečnost paměti Rust je založena na tomto pravidle: Vzhledem k objektu `T` je možné mít pouze jednu z následujících možností:
//!
//! - Mít několik neměnných odkazů (`&T`) na objekt (také známý jako **aliasing**).
//! - Mající jeden proměnlivý odkaz (&mut T`) na objekt (také známý jako **měnitelnost**).
//!
//! Toto je vynuceno kompilátorem Rust.Existují však situace, kdy toto pravidlo není dostatečně flexibilní.Někdy je nutné mít více odkazů na objekt a přesto jej mutovat.
//!
//! Existují sdílitelné měnitelné kontejnery, které umožňují měnitelnost kontrolovaným způsobem, a to i za přítomnosti aliasingu.Jak [`Cell<T>`], tak [`RefCell<T>`] to umožňují dělat jedním závitem.
//! Ani `Cell<T>`, ani `RefCell<T>` však nejsou bezpečné pro vlákna (neimplementují [`Sync`]).
//! Pokud potřebujete provést aliasing a mutaci mezi více vlákny, je možné použít typy [`Mutex<T>`], [`RwLock<T>`] nebo [`atomic`].
//!
//! Hodnoty typů `Cell<T>` a `RefCell<T>` mohou být mutovány prostřednictvím sdílených odkazů (tj
//! běžný typ `&T`), zatímco většinu typů Rust lze mutovat pouze prostřednictvím jedinečných referencí (&mut T`).
//! Říkáme, že `Cell<T>` a `RefCell<T>` poskytují " vnitřní proměnlivost`, na rozdíl od typických typů Rust, které vykazují " zděděnou proměnlivost`.
//!
//! Typy buněk mají dvě příchutě: `Cell<T>` a `RefCell<T>`.`Cell<T>` implementuje proměnlivost interiéru přesunutím hodnot dovnitř a ven z `Cell<T>`.
//! Chcete-li použít odkazy místo hodnot, musíte použít typ `RefCell<T>` a před mutací získat zámek zápisu.`Cell<T>` poskytuje metody pro načtení a změnu aktuální hodnoty interiéru:
//!
//!  - U typů, které implementují [`Copy`], načte metoda [`get`](Cell::get) aktuální hodnotu interiéru.
//!  - U typů, které implementují [`Default`], metoda [`take`](Cell::take) nahradí aktuální hodnotu interiéru [`Default::default()`] a vrátí nahrazenou hodnotu.
//!  - U všech typů metoda [`replace`](Cell::replace) nahradí aktuální hodnotu interiéru a vrátí nahrazenou hodnotu a metoda [`into_inner`](Cell::into_inner) spotřebuje `Cell<T>` a vrátí hodnotu interiéru.
//!  Metoda [`set`](Cell::set) navíc nahradí vnitřní hodnotu a nahradí nahrazenou hodnotu.
//!
//! `RefCell<T>` využívá životy Rust k implementaci " dynamického vypůjčování`, což je proces, při kterém lze požadovat dočasný, exkluzivní a proměnlivý přístup k vnitřní hodnotě.
//! Půjčuje pro `RefCell<T>`s jsou sledovány 'za běhu', na rozdíl od nativních referenčních typů Rust, které jsou zcela sledovány staticky, v době kompilace.
//! Protože půjčky `RefCell<T>` jsou dynamické, je možné se pokusit vypůjčit si hodnotu, která je již proměnlivě vypůjčena;když k tomu dojde, výsledkem bude vlákno panic.
//!
//! # Kdy zvolit vnitřní proměnlivost
//!
//! Častější zděděná mutabilita, kde je třeba mít jedinečný přístup k mutaci hodnoty, je jedním z klíčových prvků jazyka, který umožňuje Rust silně uvažovat o aliasingu ukazatele, staticky zabraňující chybám při selhání.
//! Z tohoto důvodu je upřednostňována zděděná proměnlivost a vnitřní proměnlivost je poslední možností.
//! Vzhledem k tomu, že typy buněk umožňují mutaci tam, kde by jinak byla zakázána, existují případy, kdy může být vhodná vnitřní proměnlivost, nebo dokonce musí být použit * *, např.
//!
//! * Představujeme proměnlivost 'inside' něčeho neměnného
//! * Podrobnosti implementace logicky neměnných metod.
//! * Mutující implementace [`Clone`].
//!
//! ## Představujeme proměnlivost 'inside' něčeho neměnného
//!
//! Mnoho sdílených typů inteligentních ukazatelů, včetně [`Rc<T>`] a [`Arc<T>`], poskytuje kontejnery, které lze klonovat a sdílet mezi více stranami.
//! Protože obsažené hodnoty mohou být vícenásobně pojmenovány, lze je vypůjčit pouze pomocí `&`, nikoli `&mut`.
//! Bez buněk by bylo nemožné vůbec mutovat data uvnitř těchto inteligentních ukazatelů.
//!
//! Je velmi běžné, že do sdílených typů ukazatelů vložíte `RefCell<T>`, abyste znovu zavedli proměnlivost:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Vytvořte nový blok, abyste omezili rozsah dynamické výpůjčky
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Všimněte si, že pokud bychom nenechali předchozí výpůjčku mezipaměti vypadnout z rozsahu, následná výpůjčka by způsobila dynamické vlákno panic.
//!     //
//!     // To je hlavní riziko používání `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Všimněte si, že tento příklad používá `Rc<T>` a ne `Arc<T>`.`RefCell<T>`jsou pro scénáře s jedním vláknem.Zvažte použití [`RwLock<T>`] nebo [`Mutex<T>`], pokud potřebujete sdílenou proměnlivost v situaci s více vlákny.
//!
//! ## Podrobnosti implementace logicky neměnných metod
//!
//! Občas může být žádoucí nevystavovat v API, že dochází k mutaci "under the hood".
//! Může to být proto, že logicky je operace neměnná, ale např. Ukládání do mezipaměti nutí implementaci provést mutaci;nebo proto, že k implementaci metody trait, která byla původně definována pro `&self`, musíte použít mutaci.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Tady jde drahý výpočet
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Mutující implementace `Clone`
//!
//! Jedná se jednoduše o speciální, ale běžný případ předchozího: skrytí proměnlivosti pro operace, které se zdají být neměnné.
//! Očekává se, že metoda [`clone`](Clone::clone) nezmění zdrojovou hodnotu a je deklarována jako `&self`, nikoli `&mut self`.
//! Proto každá mutace, ke které dojde v metodě `clone`, musí používat typy buněk.
//! Například [`Rc<T>`] udržuje své počty referencí v rámci `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Proměnlivé umístění paměti.
///
/// # Examples
///
/// V tomto příkladu vidíte, že `Cell<T>` umožňuje mutaci uvnitř neměnné struktury.
/// Jinými slovy umožňuje "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // CHYBA: `my_struct` je neměnná
/// // my_struct.regular_field =new_value;
///
/// // PRÁCE: ačkoli `my_struct` je neměnný, `special_field` je `Cell`,
/// // které lze vždy mutovat
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Další informace najdete v [module-level documentation](self).
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Vytvoří `Cell<T>` s hodnotou `Default` pro T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Vytvoří nový `Cell` obsahující danou hodnotu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Nastaví obsaženou hodnotu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Zamění hodnoty dvou buněk.
    /// Rozdíl oproti `std::mem::swap` spočívá v tom, že tato funkce nevyžaduje referenci `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // BEZPEČNOST: To může být riskantní, pokud je voláno ze samostatných vláken, ale `Cell`
        // je `!Sync`, takže se to nestane.
        // To také nezruší platnost žádných ukazatelů, protože `Cell` zajišťuje, že nic jiného nebude směřovat do žádné z těchto `buněk`.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Nahradí obsaženou hodnotu `val` a vrátí starou obsaženou hodnotu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // BEZPEČNOST: To může způsobit závody dat, pokud jsou volány ze samostatného vlákna,
        // ale `Cell` je `!Sync`, takže se to nestane.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Rozbalí hodnotu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Vrátí kopii obsažené hodnoty.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // BEZPEČNOST: To může způsobit závody dat, pokud jsou volány ze samostatného vlákna,
        // ale `Cell` je `!Sync`, takže se to nestane.
        unsafe { *self.value.get() }
    }

    /// Aktualizuje obsaženou hodnotu pomocí funkce a vrátí novou hodnotu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Vrátí nezpracovaný ukazatel na podkladová data v této buňce.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Vrátí proměnlivý odkaz na podkladová data.
    ///
    /// Toto volání si půjčuje `Cell` proměnlivě (v době kompilace), což zaručuje, že máme jedinou referenci.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Vrátí `&Cell<T>` z `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // BEZPEČNOST: `&mut` zajišťuje jedinečný přístup.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Vezme hodnotu buňky a ponechá `Default::default()` na svém místě.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Vrátí `&[Cell<T>]` z `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // BEZPEČNOST: `Cell<T>` má stejné rozložení paměti jako `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Proměnlivé umístění paměti s dynamicky kontrolovanými pravidly výpůjčky
///
/// Další informace najdete v [module-level documentation](self).
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Chyba vrácená [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Chyba vrácená [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Kladné hodnoty představují počet aktivních `Ref`.Záporné hodnoty představují počet aktivních `RefMut`.
// Vícenásobné `RefMut`s mohou být aktivní najednou, pouze pokud odkazují na odlišné nepřekrývající se komponenty `RefCell` (např. Různé rozsahy řezu).
//
// `Ref` a `RefMut` jsou obě dvě slova o velikosti, takže pravděpodobně nikdy nebude existovat dostatek hodnot ``Ref`s nebo `RefMut` k přetečení poloviny rozsahu `usize`.
// `BorrowFlag` tedy pravděpodobně nikdy nepřeteče ani nedopustí.
// To však není záruka, protože patologický program by mohl opakovaně vytvářet a poté mem::forget `Ref`s nebo`RefMut`s.
// Veškerý kód tedy musí explicitně zkontrolovat přetečení a podtečení, aby se zabránilo bezpečnosti, nebo se alespoň choval správně v případě, že dojde k přetečení nebo podtečení (např. Viz BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Vytvoří nový `RefCell` obsahující `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Spotřebuje `RefCell` a vrátí zabalenou hodnotu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Protože tato funkce bere `self` (`RefCell`) podle hodnoty, kompilátor staticky ověří, že není aktuálně vypůjčený.
        //
        self.value.into_inner()
    }

    /// Nahradí zabalenou hodnotu novou, vrátí starou hodnotu, aniž by deinitializoval kteroukoli z nich.
    ///
    ///
    /// Tato funkce odpovídá [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics, pokud je hodnota aktuálně vypůjčena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Nahradí zabalenou hodnotu novou vypočítanou z `f`, vrátí starou hodnotu, aniž by deinitializoval kteroukoli z nich.
    ///
    ///
    /// # Panics
    ///
    /// Panics, pokud je hodnota aktuálně vypůjčena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Zamění zabalenou hodnotu `self` za zabalenou hodnotu `other`, aniž by došlo k deinicializaci jedné z nich.
    ///
    ///
    /// Tato funkce odpovídá [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics, pokud je hodnota v obou `RefCell` aktuálně vypůjčena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Nezaměnitelně si půjčí zabalenou hodnotu.
    ///
    /// Výpůjčka trvá, dokud vrácená `Ref` neopustí rozsah.
    /// Lze vyjmout několik neměnných půjček najednou.
    ///
    /// # Panics
    ///
    /// Panics, pokud je hodnota aktuálně proměnlivě vypůjčena.
    /// U varianty bez paniky použijte [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Příklad panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Nezaměnitelně si vypůjčí zabalenou hodnotu a vrátí chybu, pokud je hodnota aktuálně proměnlivě vypůjčena.
    ///
    ///
    /// Výpůjčka trvá, dokud vrácená `Ref` neopustí rozsah.
    /// Lze vyjmout několik neměnných půjček najednou.
    ///
    /// Toto není varianta paniky [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // BEZPEČNOST: `BorrowRef` zajišťuje, že existuje pouze neměnný přístup
            // na hodnotu při zapůjčení.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Proměnlivě si půjčuje zabalenou hodnotu.
    ///
    /// Výpůjčka trvá, dokud se vrácená `RefMut` nebo všechny `RefMut` odvozené z ní neopustí.
    ///
    /// Hodnotu nelze vypůjčit, pokud je tato výpůjčka aktivní.
    ///
    /// # Panics
    ///
    /// Panics, pokud je hodnota aktuálně vypůjčena.
    /// U varianty bez paniky použijte [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Příklad panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Proměnlivě si vypůjčí zabalenou hodnotu a vrátí chybu, pokud je hodnota aktuálně vypůjčená.
    ///
    ///
    /// Výpůjčka trvá, dokud se vrácená `RefMut` nebo všechny `RefMut` odvozené z ní neopustí.
    /// Hodnotu nelze vypůjčit, pokud je tato výpůjčka aktivní.
    ///
    /// Toto není varianta paniky [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // BEZPEČNOST: `BorrowRef` zaručuje jedinečný přístup.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Vrátí nezpracovaný ukazatel na podkladová data v této buňce.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Vrátí proměnlivý odkaz na podkladová data.
    ///
    /// Toto volání si půjčuje `RefCell` proměnlivě (v době kompilace), takže není potřeba dynamických kontrol.
    ///
    /// Buďte však opatrní: tato metoda očekává, že `self` bude měnitelný, což obecně není případ použití `RefCell`.
    ///
    /// Pokud `self` nelze měnit, podívejte se místo toho na metodu [`borrow_mut`].
    ///
    /// Uvědomte si také, že tato metoda je pouze pro zvláštní okolnosti a obvykle není to, co chcete.
    /// V případě pochybností použijte místo toho [`borrow_mut`].
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Zrušte účinek uniklých ochranných krytů na vypůjčený stav `RefCell`.
    ///
    /// Toto volání je podobné [`get_mut`], ale je více specializované.
    /// Vypůjčuje si `RefCell` proměnlivě, aby zajistil, že žádné půjčky neexistují, a poté resetuje sdílené půjčky sledující stav.
    /// To je relevantní, pokud došlo k úniku některých půjček `Ref` nebo `RefMut`.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Nezaměnitelně si vypůjčí zabalenou hodnotu a vrátí chybu, pokud je hodnota aktuálně proměnlivě vypůjčena.
    ///
    /// # Safety
    ///
    /// Na rozdíl od `RefCell::borrow` je tato metoda nebezpečná, protože nevrací `Ref`, takže ponechává příznak výpůjčky nedotčený.
    /// Mutitable půjčování `RefCell`, zatímco reference vrácená touto metodou je naživu, je nedefinované chování.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // BEZPEČNOST: Zkontrolujeme, že teď nikdo aktivně nepíše, ale je to tak
            // odpovědnost volajícího zajistit, že nikdo nebude psát, dokud se vrácená reference již nebude používat.
            // `self.value.get()` také odkazuje na hodnotu vlastněnou `self` a je tedy zaručeno, že bude platná po celou dobu životnosti `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Vezme zabalenou hodnotu a ponechá `Default::default()` na svém místě.
    ///
    /// # Panics
    ///
    /// Panics, pokud je hodnota aktuálně vypůjčena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics, pokud je hodnota aktuálně proměnlivě vypůjčena.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Vytvoří `RefCell<T>` s hodnotou `Default` pro T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics, pokud je hodnota v obou `RefCell` aktuálně vypůjčena.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics, pokud je hodnota v obou `RefCell` aktuálně vypůjčena.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics, pokud je hodnota v obou `RefCell` aktuálně vypůjčena.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, pokud je hodnota v obou `RefCell` aktuálně vypůjčena.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, pokud je hodnota v obou `RefCell` aktuálně vypůjčena.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, pokud je hodnota v obou `RefCell` aktuálně vypůjčena.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics, pokud je hodnota v obou `RefCell` aktuálně vypůjčena.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Zvyšování výpůjčky může mít za následek nečtení hodnoty (<=0) v těchto případech:
            // 1. Bylo to <0, tj. Existují výpůjčky, takže nemůžeme povolit výpůjčku pro čtení kvůli pravidlům aliasingu pravidel Rust
            // 2.
            // Bylo to isize::MAX (maximální množství zapůjčených na čtení) a přeteklo to do isize::MIN (maximální množství zapůjčených pro zapisování), takže nemůžeme dovolit další výpůjčku na čtení, protože isize nemůže představovat tolik vypůjčených načtení (k tomu může dojít, pouze pokud vám mem::forget více než malé konstantní množství `Ref`s, což není dobrý postup)
            //
            //
            //
            //
            None
        } else {
            // Zvýšení výpůjčky může mít za následek hodnotu čtení (> 0) v těchto případech:
            // 1. Bylo to=0, to znamená, že to nebylo vypůjčené, a bereme si první čtení
            // 2. Bylo to> 0 a <isize::MAX, tzn
            // byly přečtené výpůjčky a isize je dostatečně velký, aby představoval, že má ještě jednu přečtenou výpůjčku
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Protože tento odkaz existuje, víme, že příznak výpůjčky je výpůjčka na čtení.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Zabraňte přetékání počitadla výpůjčky do zapisovací výpůjčky.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Zabalí vypůjčený odkaz na hodnotu do pole `RefCell`.
/// Typ obálky pro neměnně vypůjčenou hodnotu z `RefCell<T>`.
///
/// Další informace najdete v [module-level documentation](self).
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Zkopíruje `Ref`.
    ///
    /// `RefCell` je již neměnně vypůjčený, takže to nemůže selhat.
    ///
    /// Toto je přidružená funkce, kterou je třeba použít jako `Ref::clone(...)`.
    /// Implementace nebo metoda `Clone` by interferovala s rozšířeným používáním `r.borrow().clone()` ke klonování obsahu `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Vytvoří nový `Ref` pro komponentu vypůjčených dat.
    ///
    /// `RefCell` je již neměnně vypůjčený, takže to nemůže selhat.
    ///
    /// Toto je přidružená funkce, kterou je třeba použít jako `Ref::map(...)`.
    /// Metoda by interferovala s metodami stejného jména na obsahu `RefCell` používaného prostřednictvím `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Vyrábí nový `Ref` pro volitelnou součást vypůjčených dat.
    /// Původní stráž se vrátí jako `Err(..)`, pokud uzávěr vrátí `None`.
    ///
    /// `RefCell` je již neměnně vypůjčený, takže to nemůže selhat.
    ///
    /// Toto je přidružená funkce, kterou je třeba použít jako `Ref::filter_map(...)`.
    /// Metoda by interferovala s metodami stejného jména na obsahu `RefCell` používaného prostřednictvím `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Rozdělí `Ref` na více ref. Pro různé komponenty vypůjčených dat.
    ///
    /// `RefCell` je již neměnně vypůjčený, takže to nemůže selhat.
    ///
    /// Toto je přidružená funkce, kterou je třeba použít jako `Ref::map_split(...)`.
    /// Metoda by interferovala s metodami stejného jména na obsahu `RefCell` používaného prostřednictvím `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Převeďte na odkaz na podkladová data.
    ///
    /// Podkladová `RefCell` si už nikdy nelze vypůjčit a bude se vždy jevit jako neměnně vypůjčená.
    ///
    /// Není dobrý nápad unikat více než konstantní počet odkazů.
    /// `RefCell` si lze nezměnitelně vypůjčit, pokud celkem došlo pouze k menšímu počtu úniků.
    ///
    /// Toto je přidružená funkce, kterou je třeba použít jako `Ref::leak(...)`.
    /// Metoda by interferovala s metodami stejného jména na obsahu `RefCell` používaného prostřednictvím `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Zapomenutím tohoto Ref zajistíme, že se počítadlo výpůjček v RefCell nemůže během životnosti `'b` vrátit zpět na UNUSED.
        // Resetování stavu sledování reference by vyžadovalo jedinečný odkaz na vypůjčený RefCell.
        // Z původní buňky nelze vytvořit žádné další proměnlivé odkazy.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Vytvoří nový `RefMut` pro komponentu vypůjčených dat, např. Variantu výčtu.
    ///
    /// `RefCell` je již proměnlivě zapůjčen, takže to nemůže selhat.
    ///
    /// Toto je přidružená funkce, kterou je třeba použít jako `RefMut::map(...)`.
    /// Metoda by interferovala s metodami stejného jména na obsahu `RefCell` používaného prostřednictvím `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): opravit výpůjční šek
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Vyrábí nový `RefMut` pro volitelnou součást vypůjčených dat.
    /// Původní stráž se vrátí jako `Err(..)`, pokud uzávěr vrátí `None`.
    ///
    /// `RefCell` je již proměnlivě zapůjčen, takže to nemůže selhat.
    ///
    /// Toto je přidružená funkce, kterou je třeba použít jako `RefMut::filter_map(...)`.
    /// Metoda by interferovala s metodami stejného jména na obsahu `RefCell` používaného prostřednictvím `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): opravit výpůjční šek
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // BEZPEČNOST: funkce drží po dobu trvání výhradní odkaz
        // jeho volání prostřednictvím `orig` a ukazatel je pouze de-odkazovaný uvnitř volání funkce, který nikdy neumožňuje uniknout exkluzivnímu odkazu.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // BEZPEČNOST: stejné jako výše.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Rozdělí `RefMut` na několik `RefMut` pro různé komponenty vypůjčených dat.
    ///
    /// Podkladová `RefCell` zůstane proměnlivě vypůjčená, dokud obě vrácené položky `RefMut` nespadnou z rozsahu.
    ///
    /// `RefCell` je již proměnlivě zapůjčen, takže to nemůže selhat.
    ///
    /// Toto je přidružená funkce, kterou je třeba použít jako `RefMut::map_split(...)`.
    /// Metoda by interferovala s metodami stejného jména na obsahu `RefCell` používaného prostřednictvím `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Převeďte na proměnlivý odkaz na podkladová data.
    ///
    /// Základní `RefCell` si nelze znovu vypůjčit a vždy se bude jevit jako proměnlivě vypůjčený, takže vrácená reference bude jedinou do interiéru.
    ///
    ///
    /// Toto je přidružená funkce, kterou je třeba použít jako `RefMut::leak(...)`.
    /// Metoda by interferovala s metodami stejného jména na obsahu `RefCell` používaného prostřednictvím `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Zapomenutím tohoto BorrowRefMut zajistíme, že se počítadlo výpůjček v RefCell nemůže během životnosti `'b` vrátit zpět na NEPOUŽITO.
        // Resetování stavu sledování reference by vyžadovalo jedinečný odkaz na vypůjčený RefCell.
        // Z původní buňky během této doby životnosti nelze vytvořit žádné další odkazy, takže aktuální výpůjčka je jedinou referencí pro zbývající dobu životnosti.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Na rozdíl od BorrowRefMut::clone se pro vytvoření iniciály volá new
        // měnitelný odkaz, a tak v současné době nesmí existovat žádné existující odkazy.
        // Zatímco tedy klon zvyšuje proměnlivý refcount, zde výslovně povolujeme pouze přechod z UNUSED na UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Klonuje `BorrowRefMut`.
    //
    // To je platné pouze v případě, že se každý `BorrowRefMut` používá ke sledování proměnlivého odkazu na odlišný nepřekrývající se rozsah původního objektu.
    //
    // To není v klonovém impl, takže to kód implicitně nevolá.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Zabraňte podtečení počítadla půjčky.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Typ obálky s proměnlivě vypůjčenou hodnotou z `RefCell<T>`.
///
/// Další informace najdete v [module-level documentation](self).
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Základní primitivum pro vnitřní proměnlivost v Rust.
///
/// Pokud máte referenční `&T`, pak obvykle v Rust kompilátor provádí optimalizace na základě znalosti, že `&T` ukazuje na neměnná data.Mutování těchto dat, například prostřednictvím aliasu nebo přeměnou `&T` na `&mut T`, se považuje za nedefinované chování.
/// `UnsafeCell<T>` odhlášení ze záruky neměnnosti pro `&T`: sdílená reference `&UnsafeCell<T>` může ukazovat na data, která jsou mutována.Toto se nazývá "interior mutability".
///
/// Všechny ostatní typy, které umožňují interní měnitelnost, například `Cell<T>` a `RefCell<T>`, interně používají `UnsafeCell` k zabalení svých dat.
///
/// Upozorňujeme, že `UnsafeCell` ovlivňuje pouze záruku neměnnosti pro sdílené odkazy.Záruka jedinečnosti pro proměnlivé odkazy není ovlivněna.Neexistuje *žádný* legální způsob, jak získat aliasing `&mut`, a to ani u `UnsafeCell<T>`.
///
/// Samotné API `UnsafeCell` je technicky velmi jednoduché: [`.get()`] vám poskytne surový ukazatel `*mut T` na jeho obsah.Je až _you_ jako návrhář abstrakce, aby správně použil tento surový ukazatel.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Přesná pravidla aliasingu Rust se do jisté míry mění, ale hlavní body nejsou sporné:
///
/// - Pokud vytvoříte bezpečnou referenci s doživotní `'a` (buď `&T` nebo `&mut T` reference), která je přístupná bezpečným kódem (například proto, že jste ji vrátili), nesmíte k datům přistupovat žádným způsobem, který by byl v rozporu se zbytkem této reference z `'a`.
/// Například to znamená, že pokud vezmete `*mut T` z `UnsafeCell<T>` a vrhnete jej na `&T`, pak data v `T` musí zůstat neměnná (samozřejmě modulo jakákoli data `UnsafeCell` nalezená v `T`), dokud nevyprší životnost odkazu.
/// Podobně, pokud vytvoříte odkaz `&mut T`, který je uvolněn do bezpečného kódu, nesmíte přistupovat k datům v rámci `UnsafeCell`, dokud platnost tohoto odkazu nevyprší.
///
/// - Vždy se musíte vyhnout datovým závodům.Pokud má více vláken přístup ke stejné `UnsafeCell`, pak všechny zápisy musí mít správný vztah " before-before` ke všem ostatním přístupům (nebo použít atomiku).
///
/// Pro usnadnění správného návrhu jsou pro scénář s jedním podprocesem výslovně deklarovány následující scénáře:
///
/// 1. Odkaz `&T` lze uvolnit do bezpečného kódu a tam může koexistovat s jinými referencemi `&T`, ale ne s `&mut T`
///
/// 2. Odkaz na `&mut T` může být uvolněn do bezpečného kódu, pokud s ním koexistují i jiné `&mut T` ani `&T`.`&mut T` musí být vždy jedinečný.
///
/// Všimněte si, že zatímco je mutace obsahu `&UnsafeCell<T>` (i když jiné odkazy `&UnsafeCell<T>` alias na buňku) v pořádku (za předpokladu, že vynutíte výše uvedené invarianty jiným způsobem), je stále nedefinované chování mít více aliasů `&mut UnsafeCell<T>`.
/// To znamená, že `UnsafeCell` je obálka navržená pro speciální interakci s _shared_ accesses (_i.e._ prostřednictvím odkazu `&UnsafeCell<_>`);při jednání s _exclusive_ accesses (_e.g._ prostřednictvím `&mut UnsafeCell<_>` není vůbec žádné kouzlo): ani buňka, ani zabalená hodnota nesmí být po dobu trvání této výpůjčky `&mut` aliasována.
///
/// To předvádí přístupový objekt [`.get_mut()`], což je _safe_ getter, který poskytuje `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Zde je příklad představení, jak správně mutovat obsah `UnsafeCell<_>`, přestože existuje více odkazů, které aliasují buňku:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Získejte více/souběžných/sdílených odkazů na stejnou `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // BEZPEČNOST: v tomto rozsahu neexistují žádné další odkazy na obsah `x`,
///     // takže náš je skutečně jedinečný.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- půjčit-+
///     *p1_exclusive += 27; // |
/// } // <---------- nemůže překročit tento bod -------------------+
///
/// unsafe {
///     // BEZPEČNOST: v tomto rozsahu nikdo neočekává, že bude mít výhradní přístup k obsahu `x`,
///     // abychom mohli mít více sdílených přístupů současně.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Následující příklad ukazuje skutečnost, že exkluzivní přístup k `UnsafeCell<T>` implikuje exkluzivní přístup k jeho `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // s exkluzivními přístupy,
///                         // `UnsafeCell` je transparentní no-op obal, takže zde není třeba `unsafe`.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Získejte jedinečný odkaz na `x` při kontrole kompilace.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // S výhradním odkazem můžeme obsah bezplatně mutovat.
/// *p_unique.get_mut() = 0;
/// // Nebo ekvivalentně:
/// x = UnsafeCell::new(0);
///
/// // Když hodnotu vlastníme, můžeme obsah extrahovat zdarma.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Vytvoří novou instanci `UnsafeCell`, která zabalí zadanou hodnotu.
    ///
    ///
    /// Veškerý přístup k vnitřní hodnotě prostřednictvím metod je `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Rozbalí hodnotu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Získá proměnlivý ukazatel na zabalenou hodnotu.
    ///
    /// To lze vrhnout na ukazatel jakéhokoli druhu.
    /// Při odesílání na `&mut T` se ujistěte, že je přístup jedinečný (žádné aktivní reference, měnitelné nebo ne), a zajistěte, aby při odesílání na `&T` nedocházelo k žádným mutacím nebo měnitelným aliasům
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Můžeme jen hodit ukazatel z `UnsafeCell<T>` na `T` kvůli #[repr(transparent)].
        // Toto využívá zvláštního stavu libstd, neexistuje žádná záruka pro uživatelský kód, že to bude fungovat ve verzích kompilátoru future!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Vrátí proměnlivý odkaz na podkladová data.
    ///
    /// Toto volání půjčuje `UnsafeCell` proměnlivě (v době kompilace), což zaručuje, že máme jedinou referenci.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Získá proměnlivý ukazatel na zabalenou hodnotu.
    /// Rozdíl oproti [`get`] spočívá v tom, že tato funkce přijímá surový ukazatel, což je užitečné, aby se zabránilo vytváření dočasných odkazů.
    ///
    /// Výsledek lze vrhnout na ukazatel jakéhokoli druhu.
    /// Při odesílání na `&mut T` se ujistěte, že je přístup jedinečný (žádné aktivní reference, měnitelné nebo ne), a zajistěte, aby při odesílání na `&T` nedocházelo k žádným mutacím nebo měnitelným aliasům.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Postupná inicializace `UnsafeCell` vyžaduje `raw_get`, protože volání `get` by vyžadovalo vytvoření odkazu na neinicializovaná data:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Můžeme jen hodit ukazatel z `UnsafeCell<T>` na `T` kvůli #[repr(transparent)].
        // Toto využívá zvláštního stavu libstd, neexistuje žádná záruka pro uživatelský kód, že to bude fungovat ve verzích kompilátoru future!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Vytvoří `UnsafeCell` s hodnotou `Default` pro T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}