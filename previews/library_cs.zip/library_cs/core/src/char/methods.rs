//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Nejvyšší platný kódový bod, jaký `char` může mít.
    ///
    /// `char` je [Unicode Scalar Value], což znamená, že se jedná o [Code Point], ale pouze v určitém rozsahu.
    /// `MAX` je nejvyšší platný kódový bod, který je platným [Unicode Scalar Value].
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () se v Unicode používá k reprezentaci chyby dekódování.
    ///
    /// Může k tomu dojít například při přidávání nesprávně vytvořených bajtů UTF-8 [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Verze [Unicode](http://www.unicode.org/), na které jsou založeny části Unicode metod `char` a `str`.
    ///
    /// Nové verze Unicode jsou vydávány pravidelně a následně jsou aktualizovány všechny metody ve standardní knihovně v závislosti na Unicode.
    /// Chování některých metod `char` a `str` a hodnota této konstanty se proto v průběhu času mění.
    /// To *není* považováno za zásadní změnu.
    ///
    /// Schéma číslování verzí je vysvětleno v [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Vytvoří iterátor přes kódované body UTF-16 v `iter` a vrátí nepárové náhradní znaky jako `Err`.
    ///
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Ztrátový dekodér lze získat nahrazením výsledků `Err` znakem nahrazení:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Převádí `u32` na `char`.
    ///
    /// Všimněte si, že všechny `znaky jsou platné [` u32`] s a lze je seslat do jednoho s
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Opak však není pravdivý: ne všechny platné [" u32`] s jsou platné" znaky`.
    /// `from_u32()` vrátí `None`, pokud vstup není platná hodnota pro `char`.
    ///
    /// Nebezpečnou verzi této funkce, která tyto kontroly ignoruje, viz [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Vrácení `None`, když vstup není platný `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Převede `u32` na `char`, ignoruje platnost.
    ///
    /// Všimněte si, že všechny `znaky jsou platné [` u32`] s a lze je seslat do jednoho s
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Opak však není pravdivý: ne všechny platné [" u32`] s jsou platné" znaky`.
    /// `from_u32_unchecked()` to bude ignorovat a slepě vrhne na `char`, případně vytvoří neplatný.
    ///
    ///
    /// # Safety
    ///
    /// Tato funkce je nebezpečná, protože může vytvářet neplatné hodnoty `char`.
    ///
    /// Bezpečnou verzi této funkce najdete ve funkci [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Převede číslici v daném radixu na `char`.
    ///
    /// 'radix' se zde někdy také nazývá 'base'.
    /// Radix dvou označuje binární číslo, radix deset, desítkové a radix šestnáct, hexadecimální, aby poskytly některé běžné hodnoty.
    ///
    /// Jsou podporovány libovolné radice.
    ///
    /// `from_digit()` vrátí `None`, pokud vstup není číslice v daném radixu.
    ///
    /// # Panics
    ///
    /// Panics, pokud dostane radix větší než 36.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Desetinné číslo 11 je jedna číslice v základně 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Vrácení `None`, když vstup není číslice:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Předávání velkého radixu, způsobující panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Zkontroluje, zda je `char` číslice v daném radixu.
    ///
    /// 'radix' se zde někdy také nazývá 'base'.
    /// Radix dvou označuje binární číslo, radix deset, desítkové a radix šestnáct, hexadecimální, aby poskytly některé běžné hodnoty.
    ///
    /// Jsou podporovány libovolné radice.
    ///
    /// Ve srovnání s [`is_numeric()`] tato funkce rozpoznává pouze znaky `0-9`, `a-z` a `A-Z`.
    ///
    /// 'Digit' je definován pouze jako následující znaky:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Pro podrobnější porozumění 'digit' viz [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics, pokud dostane radix větší než 36.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Předávání velkého radixu, způsobující panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Převede `char` na číslici v daném radixu.
    ///
    /// 'radix' se zde někdy také nazývá 'base'.
    /// Radix dvou označuje binární číslo, radix deset, desítkové a radix šestnáct, hexadecimální, aby poskytly některé běžné hodnoty.
    ///
    /// Jsou podporovány libovolné radice.
    ///
    /// 'Digit' je definován pouze jako následující znaky:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Vrátí `None`, pokud `char` neodkazuje na číslici v daném rádixu.
    ///
    /// # Panics
    ///
    /// Panics, pokud dostane radix větší než 36.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Předání neciferného čísla má za následek selhání:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Předávání velkého radixu, způsobující panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // kód je zde rozdělen, aby se zlepšila rychlost provádění v případech, kdy je `radix` konstantní a 10 nebo menší
        //
        let val = if likely(radix <= 10) {
            // Pokud není číslice, bude vytvořeno číslo větší než radix.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Vrátí iterátor, který získá hexadecimální znak Unicode znaku jako `char`s.
    ///
    /// To unikne znakům se syntaxí Rust ve tvaru `\u{NNNNNN}`, kde `NNNNNN` je hexadecimální reprezentace.
    ///
    ///
    /// # Examples
    ///
    /// Jako iterátor:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Přímé použití `println!`:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Oba jsou ekvivalentní:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Pomocí `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 zajišťuje, že pro c==0 kód vypočítá, že by měla být vytištěna jedna číslice, a (která je stejná) se vyhne podtečení (31, 32)
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // index nejvýznamnější šestnáctkové číslice
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Rozšířená verze `escape_debug`, která volitelně umožňuje uniknout kódovým bodům Extended Grapheme.
    /// To nám umožňuje lépe formátovat znaky, jako jsou mezery, když jsou na začátku řetězce.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Vrátí iterátor, který získá doslovný řídicí kód znaku jako `char`s.
    ///
    /// Tím uniknou znaky podobné implementacím `Debug` u `str` nebo `char`.
    ///
    ///
    /// # Examples
    ///
    /// Jako iterátor:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Přímé použití `println!`:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Oba jsou ekvivalentní:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Pomocí `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Vrátí iterátor, který získá doslovný řídicí kód znaku jako `char`s.
    ///
    /// Výchozí nastavení je vybráno s předpojatostí k produkci literálů, které jsou legální v různých jazycích, včetně C++ 11 a podobných jazyků rodiny C.
    /// Přesná pravidla jsou:
    ///
    /// * Tabulátor unikl jako `\t`.
    /// * Návrat vozíku je ukončen jako `\r`.
    /// * Posuv řádku je ukončen jako `\n`.
    /// * Jednoduchá nabídka je uvozena jako `\'`.
    /// * Dvojitá nabídka je uvozena jako `\"`.
    /// * Zpětné lomítko uniklo jako `\\`.
    /// * Žádný znak v oblasti " tisknutelných ASCII` `0x20` .. `0x7e` včetně nebude uniknut.
    /// * Všechny ostatní znaky mají hexadecimální znaky Unicode;viz [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Jako iterátor:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Přímé použití `println!`:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Oba jsou ekvivalentní:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Pomocí `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Vrátí počet bajtů, které by `char` potřeboval, pokud by byl kódován v UTF-8.
    ///
    /// Tento počet bajtů je vždy mezi 1 a 4 včetně.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Typ `&str` zaručuje, že jeho obsah je UTF-8, a tak můžeme porovnat délku, kterou by trvalo, kdyby byl každý bod kódu reprezentován jako `char` vs v samotném `&str`:
    ///
    ///
    /// ```
    /// // jako znaky
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // oba mohou být reprezentovány jako tři bajty
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // jako &str jsou tyto dva kódovány v UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // vidíme, že zabírají celkem šest bytů ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... stejně jako &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Vrátí počet 16bitových kódových jednotek, které by `char` potřeboval, pokud by byl kódován v UTF-16.
    ///
    ///
    /// Další vysvětlení tohoto konceptu najdete v dokumentaci k [`len_utf8()`].
    /// Tato funkce je zrcadlem, ale pro UTF-16 místo UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Zakóduje tento znak jako UTF-8 do poskytnuté bajtové vyrovnávací paměti a poté vrátí podřízený díl vyrovnávací paměti, který obsahuje kódovaný znak.
    ///
    ///
    /// # Panics
    ///
    /// Panics, pokud vyrovnávací paměť není dostatečně velká.
    /// Vyrovnávací paměť o délce čtyři je dostatečně velká, aby zakódovala jakoukoli `char`.
    ///
    /// # Examples
    ///
    /// V obou těchto příkladech kódování 'ß' trvá dva bajty.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Vyrovnávací paměť, která je příliš malá:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // BEZPEČNOST: `char` není náhradní, takže toto je platný UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Zakóduje tento znak jako UTF-16 do poskytnuté vyrovnávací paměti `u16` a poté vrátí podřízený řez vyrovnávací paměti, který obsahuje kódovaný znak.
    ///
    ///
    /// # Panics
    ///
    /// Panics, pokud vyrovnávací paměť není dostatečně velká.
    /// Vyrovnávací paměť délky 2 je dostatečně velká, aby zakódovala jakoukoli `char`.
    ///
    /// # Examples
    ///
    /// V obou těchto příkladech kódování '𝕊' trvá dvě `u16`s.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Vyrovnávací paměť, která je příliš malá:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Vrátí `true`, pokud tento `char` má vlastnost `Alphabetic`.
    ///
    /// `Alphabetic` je popsán v kapitole 4 (Vlastnosti znaků) [Unicode Standard] a specifikován v [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // láska je mnoho věcí, ale není abecední
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Vrátí `true`, pokud tento `char` má vlastnost `Lowercase`.
    ///
    /// `Lowercase` je popsán v kapitole 4 (Vlastnosti znaků) [Unicode Standard] a specifikován v [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Různé čínské skripty a interpunkce nemají velikost písmen, a tak:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Vrátí `true`, pokud tento `char` má vlastnost `Uppercase`.
    ///
    /// `Uppercase` je popsán v kapitole 4 (Vlastnosti znaků) [Unicode Standard] a specifikován v [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Různé čínské skripty a interpunkce nemají velikost písmen, a tak:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Vrátí `true`, pokud tento `char` má vlastnost `White_Space`.
    ///
    /// `White_Space` je specifikován v [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // neporušitelný prostor
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Vrátí `true`, pokud tento `char` vyhovuje [`is_alphabetic()`] nebo [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Vrátí `true`, pokud má `char` obecnou kategorii pro řídicí kódy.
    ///
    /// Řídicí kódy (kódové body s obecnou kategorií `Cc`) jsou popsány v kapitole 4 (Vlastnosti znaků) [Unicode Standard] a jsou specifikovány v [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// // U + 009C, STRING TERMINÁTOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Vrátí `true`, pokud tento `char` má vlastnost `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` je popsán v [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] a specifikován v [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Vrátí `true`, pokud má `char` jednu z obecných kategorií čísel.
    ///
    /// Obecné kategorie čísel (`Nd` pro desetinná místa, `Nl` pro písmenné číselné znaky a `No` pro jiné číselné znaky) jsou specifikovány v [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Vrátí iterátor, který poskytuje malá mapování tohoto `char` jako jeden nebo více
    /// `char`s.
    ///
    /// Pokud tento `char` nemá mapování malých písmen, iterátor získá stejný `char`.
    ///
    /// Pokud má tento `char` mapování malých písmen jedna k jedné dané [Unicode Character Database][ucd] [`UnicodeData.txt`], iterátor získá `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Pokud tento `char` vyžaduje speciální úvahy (např. Více `char`s), iterátor získá`char` (s) dané [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Tato operace provádí bezpodmínečné mapování bez přizpůsobení.To znamená, že konverze je nezávislá na kontextu a jazyce.
    ///
    /// V [Unicode Standard] kapitola 4 (Vlastnosti znaků) pojednává o mapování případů obecně a Kapitola 3 (Conformance) pojednává o výchozím algoritmu pro převod případů.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Jako iterátor:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Přímé použití `println!`:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Oba jsou ekvivalentní:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Pomocí `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Výsledkem je někdy více než jeden znak:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Znaky, které nemají velká i malá písmena, se převedou do sebe.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Vrátí iterátor, který získá velké mapování tohoto `char` jako jeden nebo více
    /// `char`s.
    ///
    /// Pokud tento `char` nemá mapování velkých písmen, iterátor poskytuje stejný `char`.
    ///
    /// Pokud má tento `char` mapování velkých písmen jedna k jedné dané [Unicode Character Database][ucd] [`UnicodeData.txt`], iterátor získá `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Pokud tento `char` vyžaduje speciální úvahy (např. Více `char`s), iterátor získá`char` (s) dané [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Tato operace provádí bezpodmínečné mapování bez přizpůsobení.To znamená, že konverze je nezávislá na kontextu a jazyce.
    ///
    /// V [Unicode Standard] kapitola 4 (Vlastnosti znaků) pojednává o mapování případů obecně a Kapitola 3 (Conformance) pojednává o výchozím algoritmu pro převod případů.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Jako iterátor:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Přímé použití `println!`:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Oba jsou ekvivalentní:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Pomocí `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Výsledkem je někdy více než jeden znak:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Znaky, které nemají velká i malá písmena, se převedou do sebe.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Poznámka k národnímu prostředí
    ///
    /// V turečtině má ekvivalent 'i' v latině pět forem místo dvou:
    ///
    /// * 'Dotless': I/ı, někdy psáno ï
    /// * 'Dotted': İ/i
    ///
    /// Všimněte si, že malá tečkovaná 'i' je stejná jako latinka.Proto:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Hodnota `upper_i` zde závisí na jazyce textu: pokud jsme v `en-US`, mělo by to být `"I"`, ale pokud jsme v `tr_TR`, mělo by to být `"İ"`.
    /// `to_uppercase()` to nebere v úvahu, a tak:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// drží napříč jazyky.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Zkontroluje, zda je hodnota v rozsahu ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Vytvoří kopii hodnoty v ekvivalentu velkých písmen ASCII.
    ///
    /// Písmena ASCII 'a' až 'z' jsou mapována na 'A' až 'Z', ale písmena jiných než ASCII se nezmění.
    ///
    /// Chcete-li na místě psát velká písmena, použijte [`make_ascii_uppercase()`].
    ///
    /// K velkým znakům ASCII kromě znaků jiných než ASCII použijte [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Vytvoří kopii hodnoty v ekvivalentu malých písmen ASCII.
    ///
    /// Písmena ASCII 'A' až 'Z' jsou mapována na 'a' až 'z', ale písmena jiných než ASCII se nezmění.
    ///
    /// Chcete-li použít malou hodnotu na místě, použijte [`make_ascii_lowercase()`].
    ///
    /// Chcete-li kromě znaků jiných než ASCII použít malá písmena ASCII, použijte [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Zkontroluje, zda dvě hodnoty odpovídají shodě malých a velkých písmen ASCII.
    ///
    /// Ekvivalent k `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Převede tento typ na místní ekvivalent ASCII velkých písmen.
    ///
    /// Písmena ASCII 'a' až 'z' jsou mapována na 'A' až 'Z', ale písmena jiných než ASCII se nezmění.
    ///
    /// Chcete-li vrátit novou velkou hodnotu bez úpravy stávající, použijte [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Převede tento typ na místní ekvivalent ASCII s malými písmeny.
    ///
    /// Písmena ASCII 'A' až 'Z' jsou mapována na 'a' až 'z', ale písmena jiných než ASCII se nezmění.
    ///
    /// Chcete-li vrátit novou hodnotu s nízkou hodnotou bez úpravy stávající, použijte [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Zkontroluje, zda je hodnota abecedním znakem ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', nebo
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Zkontroluje, zda je hodnota velkým znakem ASCII:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Zkontroluje, zda je hodnota malým znakem ASCII:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Zkontroluje, zda je hodnotou alfanumerický znak ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', nebo
    /// - U + 0061 'a' ..=U + 007A 'z', nebo
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Zkontroluje, zda je hodnota desetinnou číslicí ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Zkontroluje, zda je hodnota hexadecimální číslice ASCII:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', nebo
    /// - U + 0041 'A' ..=U + 0046 'F', nebo
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Zkontroluje, zda je hodnotou interpunkční znak ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, nebo
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, nebo
    /// - U + 005B ..=U + 0060 ``[\] ^ _`` nebo
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Zkontroluje, zda je hodnotou grafický znak ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Zkontroluje, zda je hodnota znakem mezery ASCII:
    /// U + 0020 SPACE, U + 0009 VODOROVNÁ TABULE, U + 000A LINE FEED, U + 000C FORM FEED nebo U + 000D NÁVRATNOST VOZU.
    ///
    /// Rust používá [definition of ASCII whitespace][infra-aw] WhatWG Infra Standard.Existuje několik dalších definic v širokém použití.
    /// Například [the POSIX locale][pct] obsahuje U + 000B VERTICKÝ TAB stejně jako všechny výše uvedené znaky, ale-ze stejné specifikace-[výchozí pravidlo pro "field splitting" v Bourne shell][bfs] zohledňuje *pouze* SPACE, HORIZONTÁLNÍ TAB a LINE FEED jako mezery.
    ///
    ///
    /// Pokud píšete program, který zpracuje existující formát souboru, před použitím této funkce zkontrolujte, jaká je definice mezer v tomto formátu.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Zkontroluje, zda je hodnotou řídicí znak ASCII:
    /// U + 0000 NUL ..=U + 001F SEPARÁTOR JEDNOTKY nebo U + 007F ODSTRANIT.
    /// Všimněte si, že většina prázdných znaků ASCII jsou řídicí znaky, ale MEZERA nikoli.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Zakóduje nezpracovanou hodnotu u32 jako UTF-8 do poskytnuté bajtové vyrovnávací paměti a poté vrátí dílčí část vyrovnávací paměti, která obsahuje kódovaný znak.
///
///
/// Na rozdíl od `char::encode_utf8` tato metoda zpracovává také codepoints v náhradním rozsahu.
/// (Vytvoření `char` v náhradním rozsahu je UB.) Výsledkem je platný [generalized UTF-8], ale neplatný UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics, pokud vyrovnávací paměť není dostatečně velká.
/// Vyrovnávací paměť o délce čtyři je dostatečně velká, aby zakódovala jakoukoli `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Zakóduje nezpracovanou hodnotu u32 jako UTF-16 do poskytnuté vyrovnávací paměti `u16` a poté vrátí dílčí část vyrovnávací paměti, která obsahuje kódovaný znak.
///
///
/// Na rozdíl od `char::encode_utf16` tato metoda zpracovává také codepoints v náhradním rozsahu.
/// (Vytvoření `char` v náhradním rozsahu je UB.)
///
/// # Panics
///
/// Panics, pokud vyrovnávací paměť není dostatečně velká.
/// Vyrovnávací paměť délky 2 je dostatečně velká, aby zakódovala jakoukoli `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // BEZPEČNOST: každé rameno kontroluje, zda je k dispozici dostatek bitů pro zápis
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP propadne
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Doplňková letadla pronikají do náhrad.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}