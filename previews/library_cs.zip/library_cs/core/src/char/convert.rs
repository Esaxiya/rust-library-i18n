//! Konverze znaků.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Převádí `u32` na `char`.
///
/// Všimněte si, že všechny [`char`] s jsou platné [`u32`] s a lze je seslat do jednoho s
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Opak však není pravdivý: ne všechny platné [`u32`] s jsou platné [`char`] s.
/// `from_u32()` vrátí `None`, pokud vstup není platnou hodnotou pro [`char`].
///
/// Nebezpečnou verzi této funkce, která tyto kontroly ignoruje, viz [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Základní použití:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Vrácení `None`, když vstup není platný [`char`]:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Převede `u32` na `char`, ignoruje platnost.
///
/// Všimněte si, že všechny [`char`] s jsou platné [`u32`] s a lze je seslat do jednoho s
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Opak však není pravdivý: ne všechny platné [`u32`] s jsou platné [`char`] s.
/// `from_u32_unchecked()` to bude ignorovat a slepě vrhne na [`char`], případně vytvoří neplatný.
///
///
/// # Safety
///
/// Tato funkce je nebezpečná, protože může vytvářet neplatné hodnoty `char`.
///
/// Bezpečnou verzi této funkce najdete ve funkci [`from_u32`].
///
/// # Examples
///
/// Základní použití:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // BEZPEČNOST: volající musí zaručit, že `i` je platná hodnota char.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Převádí [`char`] na [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Převádí [`char`] na [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Znak je vržen na hodnotu kódového bodu, poté je nula rozšířena na 64 bitů.
        // Viz [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Převádí [`char`] na [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Znak je seslán na hodnotu kódového bodu, poté je nula rozšířena na 128 bitů.
        // Viz [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Mapuje bajt v 0x00 ..=0xFF na `char`, jehož kódový bod má stejnou hodnotu, v U + 0000 ..=U + 00FF.
///
/// Unicode je navržen tak, aby efektivně dekódoval bajty pomocí kódování znaků, které IANA volá ISO-8859-1.
/// Toto kódování je kompatibilní s ASCII.
///
/// Všimněte si, že se to liší od ISO/IEC 8859-1 aka
/// ISO 8859-1 (s jednou pomlčkou), která ponechává některé bajtové hodnoty "blanks", které nejsou přiřazeny žádnému znaku.
/// ISO-8859-1 (IANA) je přiřazuje řídicím kódům C0 a C1.
///
/// Všimněte si, že se *také* liší od Windows-1252 aka
/// kódová stránka 1252, což je nadmnožina ISO/IEC 8859-1, která přiřazuje některé (ne všechny!) mezery interpunkci a různým latinským znakům.
///
/// Abychom ještě něco zmátli, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` a `windows-1252` jsou všechny aliasy pro nadmnožinu Windows-1252, která vyplňuje zbývající mezery odpovídajícími řídicími kódy C0 a C1.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Převádí [`u8`] na [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Chyba, kterou lze vrátit při analýze znaku.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // BEZPEČNOST: zkontrolováno, že se jedná o legální hodnotu unicode
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Typ chyby se vrátil, když selže převod z u32 na char.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Převede číslici v daném radixu na `char`.
///
/// 'radix' se zde někdy také nazývá 'base'.
/// Radix dvou označuje binární číslo, radix deset, desítkové a radix šestnáct, hexadecimální, aby poskytly některé běžné hodnoty.
///
/// Jsou podporovány libovolné radice.
///
/// `from_digit()` vrátí `None`, pokud vstup není číslice v daném radixu.
///
/// # Panics
///
/// Panics, pokud dostane radix větší než 36.
///
/// # Examples
///
/// Základní použití:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Desetinné číslo 11 je jedna číslice v základně 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Vrácení `None`, když vstup není číslice:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Předávání velkého radixu, způsobující panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}