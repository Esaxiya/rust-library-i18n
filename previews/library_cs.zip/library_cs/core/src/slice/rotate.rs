// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Otočí rozsah `[mid-left, mid+right)` tak, aby se prvek v `mid` stal prvním prvkem.Ekvivalentně otočí prvky rozsahu `left` doleva nebo prvky `right` doprava.
///
/// # Safety
///
/// Uvedený rozsah musí být platný pro čtení a zápis.
///
/// # Algorithm
///
/// Algoritmus 1 se používá pro malé hodnoty `left + right` nebo pro velké `T`.
/// Prvky jsou přesunuty do svých konečných pozic jeden po druhém počínaje `mid - left` a postupujícími `right` kroky modulo `left + right`, takže je potřeba pouze jeden dočasný.
/// Nakonec dorazíme zpět na `mid - left`.
/// Pokud však `gcd(left + right, right)` není 1, výše uvedené kroky přeskočily prvky.
/// Například:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Naštěstí je počet přeskočených prvků mezi finalizovanými prvky vždy stejný, takže můžeme jen vyrovnat naši výchozí pozici a udělat více kol (celkový počet kol je `gcd(left + right, right)` value).
///
/// Konečným výsledkem je, že všechny prvky jsou finalizovány jednou a pouze jednou.
///
/// Algoritmus 2 se používá, pokud je `left + right` velký, ale `min(left, right)` je dostatečně malý, aby se vešel do vyrovnávací paměti zásobníku.
/// Prvky `min(left, right)` se zkopírují do vyrovnávací paměti, `memmove` se použije na ostatní a ty ve vyrovnávací paměti se přesunou zpět do díry na opačné straně, odkud pocházejí.
///
/// Algoritmy, které lze vektorizovat, překonají výše uvedené, jakmile se `left + right` dostatečně zvětší.
/// Algoritmus 1 lze vektorizovat blokováním a provedením mnoha kol najednou, ale v průměru je příliš málo kol, dokud není `left + right` enormní, a vždy existuje nejhorší případ jednoho kola.
/// Místo toho algoritmus 3 využívá opakované prohození prvků `min(left, right)`, dokud nezůstane menší problém s rotací.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// při `left < right` se místo toho vymění zleva.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. níže uvedené algoritmy mohou selhat, pokud tyto případy nejsou zkontrolovány
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Mikrobenchmarkové algoritmy 1 naznačují, že průměrný výkon pro náhodné posuny je až do `left + right == 32` lepší, ale výkon v nejhorším případě se zlomí dokonce kolem 16.
            // 24 byl vybrán jako střední cesta.
            // Pokud je velikost `T` větší než 4 `usize`s, tento algoritmus překonává i jiné algoritmy.
            //
            //
            let x = unsafe { mid.sub(left) };
            // začátek prvního kola
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` lze najít před výpočtem `gcd(left + right, right)`, ale je rychlejší udělat jednu smyčku, která vypočítá gcd jako vedlejší efekt, a pak udělat zbytek bloku
            //
            //
            let mut gcd = right;
            // Benchmarky ukazují, že je rychlejší dočasně vyměnit dočasné položky místo toho, abyste si jednou přečetli jednu dočasnou kopii, zkopírovali ji dozadu a pak ji dočasně napsali na samém konci.
            // To je pravděpodobně způsobeno skutečností, že prohození nebo nahrazování dočasných služeb používá ve smyčce pouze jednu adresu paměti, místo aby bylo nutné spravovat dvě.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // místo toho, abychom zvýšili `i` a poté zkontrolovali, zda je mimo hranice, zkontrolujeme, zda `i` při dalším přírůstku překročí hranice.
                // Tím se zabrání jakémukoli zalomení ukazatelů nebo `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // konec prvního kola
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // toto podmíněné musí být zde, pokud `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // dokončete blok s více koly
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` není typ nulové velikosti, takže je v pořádku dělit podle jeho velikosti.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritmus 2 `[T; 0]` zde zajišťuje, že je to pro T řádně zarovnáno
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritmus 3 Existuje alternativní způsob prohození, který zahrnuje zjištění, kde by byl poslední swap tohoto algoritmu, a prohození pomocí posledního chunku místo swapování sousedních chunků, jako je tento algoritmus, ale tento způsob je stále rychlejší.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritmus 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}