//! Bezplatné funkce pro vytváření `&[T]` a `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Vytvoří řez z ukazatele a délky.
///
/// Argument `len` je počet **prvků**, nikoli počet bajtů.
///
/// # Safety
///
/// Chování není definováno, pokud dojde k porušení některé z následujících podmínek:
///
/// * `data` musí být [valid] pro čtení pro `len * mem::size_of::<T>()` mnoho bajtů a musí být správně zarovnán.To znamená zejména:
///
///     * Celý rozsah paměti tohoto řezu musí být obsažen v jednom přiděleném objektu!
///       Řezy se nikdy nemohou rozprostřít přes více přidělených objektů.Viz příklad [below](#incorrect-usage), který to nesprávně nebere v úvahu.
///     * `data` musí být nenulové a zarovnané i pro řezy nulové délky.
///     Jedním z důvodů je to, že optimalizace výčtu výčtu se může spoléhat na to, že odkazy (včetně řezů libovolné délky) jsou zarovnány a nenulové, aby se odlišily od ostatních dat.
///     Ukazatel, který je použitelný jako `data` pro řezy nulové délky, můžete získat pomocí [`NonNull::dangling()`].
///
/// * `data` musí ukazovat na `len` po sobě jdoucích správně inicializovaných hodnot typu `T`.
///
/// * Paměť odkazovaná vráceným řezem nesmí být po dobu životnosti `'a` mutována, s výjimkou uvnitř `UnsafeCell`.
///
/// * Celková velikost řezu `len * mem::size_of::<T>()` nesmí být větší než `isize::MAX`.
///   Viz bezpečnostní dokumentace [`pointer::offset`].
///
/// # Caveat
///
/// Životnost vráceného řezu je odvozena z jeho použití.
/// Aby se zabránilo náhodnému zneužití, doporučuje se svázat životnost s jakoukoli životností zdroje, která je v kontextu bezpečná, například poskytnutím pomocné funkce, která vezme životnost hostitelské hodnoty pro řez, nebo explicitní anotací.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // projevit řez pro jeden prvek
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Nesprávné použití
///
/// Následující funkce `join_slices` je **nezdravá** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Výše uvedené tvrzení zajišťuje, že `fst` a `snd` jsou souvislé, ale stále mohou být obsaženy v _different allocated objects_, v takovém případě je vytvoření tohoto řezu nedefinované chování.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` a `b` jsou různé přidělené objekty ...
///     let a = 42;
///     let b = 27;
///     // ... které však mohou být souvisle uspořádány do paměti: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Provede stejnou funkcionalitu jako [`from_raw_parts`], kromě toho, že je vrácen proměnlivý řez.
///
/// # Safety
///
/// Chování není definováno, pokud dojde k porušení některé z následujících podmínek:
///
/// * `data` musí být [valid] pro čtení i zápis pro `len * mem::size_of::<T>()` mnoho bajtů a musí být správně zarovnán.To znamená zejména:
///
///     * Celý rozsah paměti tohoto řezu musí být obsažen v jednom přiděleném objektu!
///       Řezy se nikdy nemohou rozprostřít přes více přidělených objektů.
///     * `data` musí být nenulové a zarovnané i pro řezy nulové délky.
///     Jedním z důvodů je to, že optimalizace výčtu výčtu se může spoléhat na to, že odkazy (včetně řezů libovolné délky) jsou zarovnány a nenulové, aby se odlišily od ostatních dat.
///
///     Ukazatel, který je použitelný jako `data` pro řezy nulové délky, můžete získat pomocí [`NonNull::dangling()`].
///
/// * `data` musí ukazovat na `len` po sobě jdoucích správně inicializovaných hodnot typu `T`.
///
/// * Paměť odkazovaná vráceným řezem nesmí být po dobu životnosti `'a` přístupná prostřednictvím jiného ukazatele (neodvozeného z návratové hodnoty).
///   Přístup pro čtení i zápis je zakázán.
///
/// * Celková velikost řezu `len * mem::size_of::<T>()` nesmí být větší než `isize::MAX`.
///   Viz bezpečnostní dokumentace [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Převede odkaz na T na řez o délce 1 (bez kopírování).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Převede odkaz na T na řez o délce 1 (bez kopírování).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}