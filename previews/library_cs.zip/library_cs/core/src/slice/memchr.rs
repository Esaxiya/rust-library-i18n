// Původní implementace převzata z rust-memchr.
// Copyright 2015 Andrew Gallant, bluss a Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Použijte zkrácení.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Vrátí `true`, pokud `x` obsahuje nulový bajt.
///
/// Z *Matters Computational*, J. Arndt:
///
/// " Myšlenkou je odečíst jeden z každého z bajtů a poté hledat bajty, kde se výpůjčka šířila až k nejvýznamnějším
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Vrátí první index odpovídající bajtu `x` v `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Rychlá cesta pro malé plátky
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Vyhledejte hodnotu jednoho bajtu čtením dvou slov `usize` najednou.
    //
    // Rozdělte `text` na tři části
    // - nezarovnaná počáteční část, před textem zarovnaná adresa podle prvního slova
    // - tělo, skenovat po 2 slovech najednou
    // - poslední zbývající část, velikost <2 slova

    // hledat až k zarovnané hranici
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // prohledat tělo textu
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // BEZPEČNOST: predikát while zaručuje vzdálenost nejméně 2 * usize_bytes
        // mezi posunem a koncem řezu.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // break, pokud existuje odpovídající bajt
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Najděte bajt za bodem, kdy se smyčka těla zastavila.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Vrátí poslední index odpovídající bajtu `x` v `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Vyhledejte hodnotu jednoho bajtu čtením dvou slov `usize` najednou.
    //
    // Rozdělit `text` na tři části:
    // - nezarovnaný ocas, za textovou adresou zarovnanou podle posledního slova,
    // - tělo, naskenováno 2 slovy najednou,
    // - první zbývající bajty, velikost <2 slova.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Říkáme tomu jen proto, abychom získali délku předpony a přípony.
        // Uprostřed vždy zpracováváme dva bloky najednou.
        // BEZPEČNOST: přeměna `[u8]` na `[usize]` je bezpečná, kromě rozdílů ve velikosti, které zpracovává `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Hledejte v textu, ujistěte se, že nepřekračujeme min_aligned_offset.
    // offset je vždy zarovnaný, takže stačí pouze testování `>` a vyhnete se možnému přetečení.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // BEZPEČNOST: offset začíná na len, suffix.len(), pokud je větší než
        // min_aligned_offset (prefix.len()), zbývající vzdálenost je alespoň 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Přerušte, pokud existuje odpovídající bajt.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Najděte bajt před bodem, kdy se smyčka těla zastavila.
    text[..offset].iter().rposition(|elt| *elt == x)
}