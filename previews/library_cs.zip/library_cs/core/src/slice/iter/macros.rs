//! Makra používaná iterátory řezu.

// Vložení is_empty a len znamená obrovský rozdíl ve výkonu
macro_rules! is_empty {
    // Způsob, jakým kódujeme délku iterátoru ZST, to funguje jak pro ZST, tak pro non-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Abychom se zbavili některých hraničních kontrol (viz `position`), vypočítáme délku poněkud neočekávaným způsobem.
// (Testováno pomocí `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // jsme někdy používáni v nebezpečném bloku

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Tento _cannot_ používá `unchecked_sub`, protože jsme závislí na zabalení, které představuje délku dlouhých iterátorů řezů ZST.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Víme, že `start <= end`, takže může dělat lépe než `offset_from`, který musí řešit podepsané.
            // Nastavením vhodných příznaků zde můžeme LLVM říci, což mu pomáhá odstranit kontroly hranic.
            // BEZPEČNOST: Podle typu invariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Tím, že také řeknete LLVM, že ukazatele jsou od sebe vzdáleny přesným násobkem velikosti typu, může optimalizovat `len() == 0` až na `start == end` místo `(end - start) < size`.
            //
            // BEZPEČNOST: Podle invariantu typu jsou ukazatele zarovnány tak, aby
            //         vzdálenost mezi nimi musí být násobkem velikosti pointee
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Sdílená definice iterátorů `Iter` a `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Vrátí první prvek a posune začátek iterátoru dopředu o 1.
        // Výrazně zvyšuje výkon ve srovnání s vloženou funkcí.
        // Iterátor nesmí být prázdný.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Vrátí poslední prvek a posune konec iterátoru zpět o 1.
        // Výrazně zvyšuje výkon ve srovnání s vloženou funkcí.
        // Iterátor nesmí být prázdný.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Zmenší iterátor, když T je ZST, posunutím konce iterátoru zpět o `n`.
        // `n` nesmí překročit `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Pomocná funkce pro vytvoření řezu z iterátoru.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // BEZPEČNOST: iterátor byl vytvořen z řezu s ukazatelem
                // `self.ptr` a délka `len!(self)`.
                // To zaručuje, že jsou splněny všechny předpoklady pro `from_raw_parts`.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Pomocná funkce pro posunutí začátku iterátoru vpřed pomocí prvků `offset`, návrat starého začátku.
            //
            // Nebezpečný, protože offset nesmí překročit `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // BEZPEČNOST: volající zaručuje, že `offset` nepřekročí `self.len()`,
                    // takže tento nový ukazatel je uvnitř `self` a je tedy zaručeno, že nebude null.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Pomocná funkce pro posunutí konce iterátoru dozadu prvky `offset` a vrácení nového konce.
            //
            // Nebezpečný, protože offset nesmí překročit `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // BEZPEČNOST: volající zaručuje, že `offset` nepřekročí `self.len()`,
                    // což je zaručeno, že nebude přetékat `isize`.
                    // Výsledný ukazatel je také v mezích `slice`, což splňuje další požadavky pro `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // lze implementovat s řezy, ale tím se vyhneme hraničním kontrolám

                // BEZPEČNOST: Hovory `assume` jsou bezpečné od začátku ukazatele řezu
                // musí mít nenulovou hodnotu a řezy nad jinými než ZST musí mít také nenulový koncový ukazatel.
                // Volání `next_unchecked!` je bezpečné, protože nejdříve zkontrolujeme, zda je iterátor prázdný.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Tento iterátor je nyní prázdný.
                    if mem::size_of::<T>() == 0 {
                        // Musíme to udělat tímto způsobem, protože `ptr` nemusí být nikdy 0, ale `end` může být (kvůli zabalení).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // BEZPEČNOST: end nemůže být 0, pokud T není ZST, protože ptr není 0 a end>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // BEZPEČNOST: Jsme v mezích.`post_inc_start` dělá správnou věc i pro ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Přepíšeme výchozí implementaci, která používá `try_fold`, protože tato jednoduchá implementace generuje méně LLVM IR a rychleji se kompiluje.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Přepíšeme výchozí implementaci, která používá `try_fold`, protože tato jednoduchá implementace generuje méně LLVM IR a rychleji se kompiluje.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Přepíšeme výchozí implementaci, která používá `try_fold`, protože tato jednoduchá implementace generuje méně LLVM IR a rychleji se kompiluje.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Přepíšeme výchozí implementaci, která používá `try_fold`, protože tato jednoduchá implementace generuje méně LLVM IR a rychleji se kompiluje.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Přepíšeme výchozí implementaci, která používá `try_fold`, protože tato jednoduchá implementace generuje méně LLVM IR a rychleji se kompiluje.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Přepíšeme výchozí implementaci, která používá `try_fold`, protože tato jednoduchá implementace generuje méně LLVM IR a rychleji se kompiluje.
            // `assume` se také vyhýbá kontrole mezí.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // BEZPEČNOST: je nám zaručeno, že budeme v mezích invariantu smyčky:
                        // když `i >= n`, `self.next()` vrátí `None` a smyčka se přeruší.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Přepíšeme výchozí implementaci, která používá `try_fold`, protože tato jednoduchá implementace generuje méně LLVM IR a rychleji se kompiluje.
            // `assume` se také vyhýbá kontrole mezí.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // BEZPEČNOST: `i` musí být nižší než `n`, protože začíná na `n`
                        // a jen klesá.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // BEZPEČNOST: volající musí zaručit, že `i` je v mezích
                // podkladový řez, takže `i` nemůže přetéct `isize` a vrácené odkazy zaručeně odkazují na prvek řezu, a tudíž zaručeně platné.
                //
                // Všimněte si také, že volající také zaručuje, že už nikdy nebudeme volat se stejným indexem a že se nebudou volat žádné jiné metody, které budou přistupovat k tomuto podřízenému segmentu, takže je platné, aby vrácený odkaz byl proměnlivý v případě
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // lze implementovat s řezy, ale tím se vyhneme hraničním kontrolám

                // BEZPEČNOST: Hovory `assume` jsou bezpečné, protože počáteční ukazatel řezu musí mít nenulovou hodnotu,
                // a řezy nad jinými než ZST musí mít také koncový ukazatel s nulovou hodnotou.
                // Volání `next_back_unchecked!` je bezpečné, protože nejdříve zkontrolujeme, zda je iterátor prázdný.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Tento iterátor je nyní prázdný.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // BEZPEČNOST: Jsme v mezích.`pre_dec_end` dělá správnou věc i pro ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}