//! Provoz na ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Zkontroluje, zda jsou všechny bajty v tomto řezu v rozsahu ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Zkontroluje, zda dva řezy odpovídají shodě malých a velkých písmen ASCII.
    ///
    /// Stejné jako `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, ale bez přidělení a kopírování dočasných položek.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Převede tento řez na místní ekvivalent ASCII velkých písmen.
    ///
    /// Písmena ASCII 'a' až 'z' jsou mapována na 'A' až 'Z', ale písmena jiných než ASCII se nezmění.
    ///
    /// Chcete-li vrátit novou velkou hodnotu bez úpravy stávající, použijte [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Převede tento řez na jeho ekvivalent ASCII malými písmeny na místě.
    ///
    /// Písmena ASCII 'A' až 'Z' jsou mapována na 'a' až 'z', ale písmena jiných než ASCII se nezmění.
    ///
    /// Chcete-li vrátit novou hodnotu s nízkou hodnotou bez úpravy stávající, použijte [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Vrátí `true`, pokud je jakýkoli bajt ve slově `v` nonascii (>=128).
/// Snarfed z `../str/mod.rs`, který dělá něco podobného pro ověření utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Optimalizovaný test ASCII, který bude místo operací typu byte-at-time (je-li to možné) používat operace usize-at-a-time namísto operací byte-at-a-time.
///
/// Algoritmus, který zde používáme, je velmi jednoduchý.Pokud je `s` příliš krátký, jednoduše zkontrolujeme každý bajt a skončíme s ním.V opačném případě:
///
/// - Přečtěte si první slovo s nevyrovnanou zátěží.
/// - Zarovnejte ukazatel, přečtěte si další slova až do konce se zarovnanými zatíženími.
/// - Přečtěte si poslední `usize` z `s` s nevyrovnaným zatížením.
///
/// Pokud některá z těchto zátěží vytvoří něco, pro co `contains_nonascii` (above) vrátí true, pak víme, že odpověď je false.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Pokud bychom z implementace word-at-a-time nic nezískali, vraťte se zpět ke skalární smyčce.
    //
    // Děláme to také pro architektury, kde `size_of::<usize>()` není dostatečné zarovnání pro `usize`, protože je to zvláštní případ edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Vždy čteme první slovo nezarovnané, což znamená, že `align_offset` je
    // 0, načteme stejnou hodnotu znovu pro zarovnané čtení.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // BEZPEČNOST: Ověřujeme `len < USIZE_SIZE` výše.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Zkontrolovali jsme to výše, trochu implicitně.
    // Všimněte si, že `offset_to_aligned` je buď `align_offset` nebo `USIZE_SIZE`, oba jsou výslovně zaškrtnuty výše.
    //
    debug_assert!(offset_to_aligned <= len);

    // BEZPEČNOST: word_ptr je (správně zarovnané) použití ptr, které používáme ke čtení
    // střední část plátku.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` je bajtový index `word_ptr`, používaný pro kontroly konce smyčky.
    let mut byte_pos = offset_to_aligned;

    // Paranoia kontroluje zarovnání, protože se chystáme udělat spoustu nevyrovnaných zátěží.
    // V praxi by to však mělo být nemožné zakázat chybu v `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Čtěte následující slova až do posledního zarovnaného slova, kromě samotného posledního zarovnaného slova, které bude provedeno při kontrole ocasu později, abyste zajistili, že ocas bude vždy maximálně jeden `usize` až extra branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Zdravý rozum zkontrolujte, zda je čtení v mezích
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // A že naše předpoklady o `byte_pos` platí.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // BEZPEČNOST: Víme, že `word_ptr` je správně zarovnán (kvůli
        // `align_offset`) a víme, že máme dostatek bajtů mezi `word_ptr` a koncem
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // BEZPEČNOST: Známe `byte_pos <= len - USIZE_SIZE`, což znamená, že
        // po tomto `add` bude `word_ptr` maximálně jeden konec.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Kontrola zdravého rozumu, aby se zajistilo, že skutečně zbývá jen jeden `usize`.
    // To by mělo být zaručeno naší podmínkou smyčky.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // BEZPEČNOST: To se spoléhá na `len >= USIZE_SIZE`, který kontrolujeme na začátku.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}