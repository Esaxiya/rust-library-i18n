// ignore-tidy-filelength

//! Správa řezů a manipulace.
//!
//! Více podrobností viz [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Čistá implementace rust memchr, převzato z rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Tato funkce je veřejná pouze proto, že neexistuje žádný jiný způsob, jak testovat jednotku heapsort.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Vrátí počet prvků v řezu.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // BEZPEČNOST: zvuk konstantní, protože transmutujeme pole délky jako usize (což musí být)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // BEZPEČNOST: je to bezpečné, protože `&[T]` a `FatPtr<T>` mají stejné rozložení.
            // Tuto záruku může poskytnout pouze `std`.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Pokud je stabilní, nahraďte jej `crate::ptr::metadata(self)`.
            // Od tohoto psaní to způsobí chybu "Const-stable functions can only call other const-stable functions".
            //

            // BEZPEČNOST: Přístup k hodnotě z unie `PtrRepr` je bezpečný, protože * const T
            // a PtrComponents<T>mají stejné rozložení paměti.
            // Tuto záruku může poskytnout pouze std.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Vrátí `true`, pokud má řez délku 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Vrátí první prvek řezu nebo `None`, pokud je prázdný.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Vrátí proměnlivý ukazatel na první prvek řezu nebo `None`, pokud je prázdný.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Vrátí první a všechny ostatní prvky řezu nebo `None`, pokud je prázdný.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Vrátí první a všechny ostatní prvky řezu nebo `None`, pokud je prázdný.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Vrátí poslední a všechny ostatní prvky řezu, nebo `None`, pokud je prázdný.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Vrátí poslední a všechny ostatní prvky řezu, nebo `None`, pokud je prázdný.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Vrátí poslední prvek řezu nebo `None`, pokud je prázdný.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Vrátí proměnlivý ukazatel na poslední položku v řezu.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Vrátí odkaz na prvek nebo podříznutí v závislosti na typu indexu.
    ///
    /// - Pokud je dána pozice, vrátí odkaz na prvek na dané pozici nebo `None`, pokud je mimo hranice.
    ///
    /// - Pokud je zadán rozsah, vrátí podřízený díl odpovídající tomuto rozsahu, nebo `None`, pokud je mimo hranice.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Vrátí proměnlivý odkaz na prvek nebo podřízený řez v závislosti na typu indexu (viz [`get`]) nebo `None`, pokud je index mimo hranice.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Vrátí odkaz na prvek nebo podřez, aniž by provedl kontrolu hranic.
    ///
    /// Pro bezpečnou alternativu viz [`get`].
    ///
    /// # Safety
    ///
    /// Volání této metody s indexem out-of-bounds je *[nedefinované chování]*, i když se výsledný odkaz nepoužívá.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // BEZPEČNOST: volající musí dodržovat většinu bezpečnostních požadavků pro `get_unchecked`;
        // řez je dereferencable, protože `self` je bezpečná reference.
        // Vrácený ukazatel je bezpečný, protože impls `SliceIndex` musí zaručit, že je.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Vrátí proměnlivý odkaz na prvek nebo podřízený řez, aniž by bylo nutné kontrolovat hranice.
    ///
    /// Pro bezpečnou alternativu viz [`get_mut`].
    ///
    /// # Safety
    ///
    /// Volání této metody s indexem out-of-bounds je *[nedefinované chování]*, i když se výsledný odkaz nepoužívá.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní požadavky pro `get_unchecked_mut`;
        // řez je dereferencable, protože `self` je bezpečná reference.
        // Vrácený ukazatel je bezpečný, protože impls `SliceIndex` musí zaručit, že je.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Vrátí surový ukazatel do vyrovnávací paměti řezu.
    ///
    /// Volající musí zajistit, aby výřez přežil ukazatel, který tato funkce vrátí, jinak skončí ukazováním na odpadky.
    ///
    /// Volající musí také zajistit, aby paměť, na kterou ukazuje ukazatel (non-transitively), nebyla nikdy zapsána (kromě uvnitř `UnsafeCell`) pomocí tohoto ukazatele nebo jakéhokoli ukazatele z něj odvozeného.
    /// Pokud potřebujete mutovat obsah řezu, použijte [`as_mut_ptr`].
    ///
    /// Úprava kontejneru, na který odkazuje tento řez, může způsobit přerozdělení jeho vyrovnávací paměti, což by také zneplatnilo všechny ukazatele na něj.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Vrátí nebezpečný proměnlivý ukazatel do vyrovnávací paměti řezu.
    ///
    /// Volající musí zajistit, aby výřez přežil ukazatel, který tato funkce vrátí, jinak skončí ukazováním na odpadky.
    ///
    /// Úprava kontejneru, na který odkazuje tento řez, může způsobit přerozdělení jeho vyrovnávací paměti, což by také zneplatnilo všechny ukazatele na něj.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Vrátí dva surové ukazatele překlenující řez.
    ///
    /// Vrácený rozsah je napůl otevřený, což znamená, že koncový ukazatel ukazuje *jeden za* poslední prvek řezu.
    /// Tímto způsobem je prázdný řez reprezentován dvěma stejnými ukazateli a rozdíl mezi těmito dvěma ukazateli představuje velikost řezu.
    ///
    /// Viz [`as_ptr`] pro upozornění na používání těchto ukazatelů.Koncový ukazatel vyžaduje zvláštní opatrnost, protože neodkazuje na platný prvek v řezu.
    ///
    /// Tato funkce je užitečná pro interakci s cizími rozhraními, která používají dva ukazatele k označení řady prvků v paměti, jak je běžné v C++ .
    ///
    ///
    /// Může být také užitečné zkontrolovat, zda ukazatel na prvek odkazuje na prvek tohoto řezu:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // BEZPEČNOST: `add` je zde bezpečný, protože:
        //
        //   - Oba ukazatele jsou součástí stejného objektu, protože se počítá také míření přímo za objekt.
        //
        //   - Velikost řezu nikdy není větší než isize::MAX bajtů, jak je uvedeno zde:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Není zahrnuto žádné zalamování, protože řezy se nezalomí za konec adresního prostoru.
        //
        // Viz dokumentace k pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Vrátí dva nebezpečné proměnlivé ukazatele překlenující řez.
    ///
    /// Vrácený rozsah je napůl otevřený, což znamená, že koncový ukazatel ukazuje *jeden za* poslední prvek řezu.
    /// Tímto způsobem je prázdný řez reprezentován dvěma stejnými ukazateli a rozdíl mezi těmito dvěma ukazateli představuje velikost řezu.
    ///
    /// Viz [`as_mut_ptr`] pro upozornění na používání těchto ukazatelů.
    /// Koncový ukazatel vyžaduje zvláštní opatrnost, protože neodkazuje na platný prvek v řezu.
    ///
    /// Tato funkce je užitečná pro interakci s cizími rozhraními, která používají dva ukazatele k označení řady prvků v paměti, jak je běžné v C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // BEZPEČNOST: Proč je `add` bezpečný, viz výše as_ptr_range().
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Zamění dva prvky v řezu.
    ///
    /// # Arguments
    ///
    /// * a, Index prvního prvku
    /// * b, Index druhého prvku
    ///
    /// # Panics
    ///
    /// Panics, pokud jsou `a` nebo `b` mimo hranice.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Z jednoho vector si nemůžete vzít dvě proměnlivé půjčky, takže místo toho použijte surové ukazatele.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // BEZPEČNOST: `pa` a `pb` byly vytvořeny z bezpečných proměnlivých referencí a viz
        // na prvky v řezu, a proto je zaručeno, že jsou platné a zarovnané.
        // Všimněte si, že přístup k prvkům za `a` a `b` je zaškrtnut a bude panic, když bude mimo hranice.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Obrátí pořadí prvků v řezu na místě.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // U velmi malých typů fungují všichni jednotlivci na normální cestě špatně.
        // Můžeme to udělat lépe, s ohledem na efektivní nezarovnaný load/store, načtením většího bloku a obrácením registru.
        //

        // V ideálním případě by to LLVM udělal za nás, protože ví lépe než my, zda jsou nevyřízená čtení efektivní (protože se to mění například mezi různými verzemi ARM) a jaká by byla nejlepší velikost bloku.
        // Bohužel od LLVM 4.0 (2017-05) pouze rozbalí smyčku, takže to musíme udělat sami.
        // (Hypotéza: zpětný chod je problematický, protože strany mohou být zarovnány odlišně-budou, když bude délka lichá-takže neexistuje způsob, jak emitovat před a postludy, aby se uprostřed použila plně zarovnaná SIMD.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Použijte vnitřní llvm.bswap k obrácení u8s v usize
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // BEZPEČNOST: Zde je několik věcí, které je třeba zkontrolovat:
                //
                // - Všimněte si, že `chunk` je buď 4 nebo 8 kvůli výše uvedené kontrole cfg.`chunk - 1` je tedy pozitivní.
                // - Indexování s indexem `i` je v pořádku, protože zaručuje kontrola smyčky
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Indexování s indexem `ln - i - chunk = ln - (i + chunk)` je v pořádku:
                //   - `i + chunk > 0` je triviálně pravda.
                //   - Kontrola smyčky zaručuje:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, takže odčítání nepřekročí.
                // - Hovory `read_unaligned` a `write_unaligned` jsou v pořádku:
                //   - `pa` ukazuje na index `i`, kde `i < ln / 2 - (chunk - 1)` (viz výše) a `pb` ukazuje na index `ln - i - chunk`, takže oba jsou alespoň `chunk` mnoho bajtů od konce `self`.
                //
                //   - Jakákoli inicializovaná paměť je platná `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Použijte otočení o 16 k obrácení u16s v u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // BEZPEČNOST: Nezarovnaný u32 lze číst z `i`, pokud `i + 1 < ln`
                // (a samozřejmě `i < ln`), protože každý prvek má 2 bajty a čteme 4.
                //
                // `i + chunk - 1 < ln / 2` # zatímco podmínka
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Jelikož je to menší než délka dělená 2, pak to musí být v mezích.
                //
                // To také znamená, že podmínka `0 < i + chunk <= ln` je vždy respektována, což zajišťuje bezpečné použití ukazatele `pb`.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // BEZPEČNOST: `i` je nižší než polovina délky plátku
            // přístup k `i` a `ln - i - 1` je bezpečný (`i` začíná na 0 a nebude dále než `ln / 2 - 1`).
            // Výsledné ukazatele `pa` a `pb` jsou proto platné a zarovnané a lze je číst a zapisovat do nich.
            //
            //
            unsafe {
                // Nebezpečná výměna, abyste se vyhnuli hranicím, zkontrolujte bezpečnou výměnu.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Vrátí iterátor přes řez.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Vrátí iterátor, který umožňuje upravit každou hodnotu.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Vrátí iterátor přes všechny souvislé windows délky `size`.
    /// windows se překrývají.
    /// Pokud je řez menší než `size`, iterátor nevrátí žádné hodnoty.
    ///
    /// # Panics
    ///
    /// Panics, pokud `size` je 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Pokud je řez menší než `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Vrátí iterátor přes `chunk_size` prvků řezu najednou, počínaje začátkem řezu.
    ///
    /// Kousky jsou plátky a nepřekrývají se.Pokud `chunk_size` nerozdělí délku řezu, pak poslední blok nebude mít délku `chunk_size`.
    ///
    /// Viz [`chunks_exact`] pro variantu tohoto iterátoru, která vrací bloky vždy přesně `chunk_size` prvků, a [`rchunks`] pro stejný iterátor, ale začínající na konci řezu.
    ///
    ///
    /// # Panics
    ///
    /// Panics, pokud `chunk_size` je 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Vrátí iterátor přes `chunk_size` prvků řezu najednou, počínaje začátkem řezu.
    ///
    /// Kousky jsou proměnlivé plátky a nepřekrývají se.Pokud `chunk_size` nerozdělí délku řezu, pak poslední blok nebude mít délku `chunk_size`.
    ///
    /// Viz [`chunks_exact_mut`] pro variantu tohoto iterátoru, která vrací bloky vždy přesně `chunk_size` prvků, a [`rchunks_mut`] pro stejný iterátor, ale začínající na konci řezu.
    ///
    ///
    /// # Panics
    ///
    /// Panics, pokud `chunk_size` je 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Vrátí iterátor přes `chunk_size` prvků řezu najednou, počínaje začátkem řezu.
    ///
    /// Kousky jsou plátky a nepřekrývají se.
    /// Pokud `chunk_size` nerozdělí délku řezu, poslední až `chunk_size-1` prvky budou vynechány a lze je načíst z funkce `remainder` iterátoru.
    ///
    ///
    /// Vzhledem k tomu, že každý blok má přesně `chunk_size` prvky, může kompilátor často optimalizovat výsledný kód lépe než v případě [`chunks`].
    ///
    /// Viz [`chunks`] pro variantu tohoto iterátoru, který také vrací zbytek jako menší blok, a [`rchunks_exact`] pro stejný iterátor, ale začínající na konci řezu.
    ///
    /// # Panics
    ///
    /// Panics, pokud `chunk_size` je 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Vrátí iterátor přes `chunk_size` prvků řezu najednou, počínaje začátkem řezu.
    ///
    /// Kousky jsou proměnlivé plátky a nepřekrývají se.
    /// Pokud `chunk_size` nerozdělí délku řezu, poslední až `chunk_size-1` prvky budou vynechány a lze je načíst z funkce `into_remainder` iterátoru.
    ///
    ///
    /// Vzhledem k tomu, že každý blok má přesně `chunk_size` prvky, může kompilátor často optimalizovat výsledný kód lépe než v případě [`chunks_mut`].
    ///
    /// Viz [`chunks_mut`] pro variantu tohoto iterátoru, který také vrací zbytek jako menší blok, a [`rchunks_exact_mut`] pro stejný iterátor, ale začínající na konci řezu.
    ///
    /// # Panics
    ///
    /// Panics, pokud `chunk_size` je 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Rozdělí plátek na plátek polí s prvky `N` za předpokladu, že nezůstane žádný zbytek.
    ///
    ///
    /// # Safety
    ///
    /// Toto lze volat pouze tehdy, když
    /// - Plátek se rozdělí přesně na kousky s `N` prvky (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // BEZPEČNOST: Kusy 1 prvku nikdy nemají zbytek
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // BEZPEČNOST: Délka řezu (6) je násobkem 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Byly by to nezdravé:
    /// // nechat kousky: &[[_;5]]= slice.as_chunks_unchecked()//Délka řezu není násobkem 5 let chunks:&[[_;0]]= slice.as_chunks_unchecked()//Kusy nulové délky nejsou nikdy povoleny
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // BEZPEČNOST: Náš předpoklad je přesně to, co je potřeba k tomu, abychom to nazvali
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // BEZPEČNOST: Vrháme plátek prvků `new_len * N`
        // plátek `new_len` mnoha kusů prvků `N`.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Rozdělí řez na plátek polí s prvky `N`, počínaje začátkem řezu, a zbývající řez s délkou striktně menší než `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, pokud `N` je 0. Tato kontrola se s největší pravděpodobností změní na chybu kompilace, než se tato metoda stabilizuje.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // BEZPEČNOST: Už jsme zpanikařili na nule a zajistili jsme to konstrukcí
        // že délka dílčího řezu je násobkem N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Rozdělí řez na plátek polí s prvky `N`, počínaje koncem řezu a zbývající řez s délkou striktně menší než `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, pokud `N` je 0. Tato kontrola se s největší pravděpodobností změní na chybu kompilace, než se tato metoda stabilizuje.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // BEZPEČNOST: Už jsme zpanikařili na nule a zajistili jsme to konstrukcí
        // že délka dílčího řezu je násobkem N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Vrátí iterátor přes `N` prvků řezu najednou, počínaje začátkem řezu.
    ///
    /// Kusy jsou odkazy na pole a nepřekrývají se.
    /// Pokud `N` nerozdělí délku řezu, poslední až `N-1` prvky budou vynechány a lze je načíst z funkce `remainder` iterátoru.
    ///
    ///
    /// Tato metoda je obecným ekvivalentem ekvivalentu [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics, pokud `N` je 0. Tato kontrola se s největší pravděpodobností změní na chybu kompilace, než se tato metoda stabilizuje.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Rozdělí plátek na plátek polí s prvky `N` za předpokladu, že nezůstane žádný zbytek.
    ///
    ///
    /// # Safety
    ///
    /// Toto lze volat pouze tehdy, když
    /// - Plátek se rozdělí přesně na kousky s `N` prvky (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // BEZPEČNOST: Kusy 1 prvku nikdy nemají zbytek
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // BEZPEČNOST: Délka řezu (6) je násobkem 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Byly by to nezdravé:
    /// // nechat kousky: &[[_;5]]= slice.as_chunks_unchecked_mut()//Délka řezu není násobkem 5 let chunks:&[[_;0]]= slice.as_chunks_unchecked_mut()//Kusy nulové délky nejsou nikdy povoleny
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // BEZPEČNOST: Náš předpoklad je přesně to, co je potřeba k tomu, abychom to nazvali
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // BEZPEČNOST: Vrháme plátek prvků `new_len * N`
        // plátek `new_len` mnoha kusů prvků `N`.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Rozdělí řez na plátek polí s prvky `N`, počínaje začátkem řezu, a zbývající řez s délkou striktně menší než `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, pokud `N` je 0. Tato kontrola se s největší pravděpodobností změní na chybu kompilace, než se tato metoda stabilizuje.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // BEZPEČNOST: Už jsme zpanikařili na nule a zajistili jsme to konstrukcí
        // že délka dílčího řezu je násobkem N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Rozdělí řez na plátek polí s prvky `N`, počínaje koncem řezu a zbývající řez s délkou striktně menší než `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, pokud `N` je 0. Tato kontrola se s největší pravděpodobností změní na chybu kompilace, než se tato metoda stabilizuje.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // BEZPEČNOST: Už jsme zpanikařili na nule a zajistili jsme to konstrukcí
        // že délka dílčího řezu je násobkem N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Vrátí iterátor přes `N` prvků řezu najednou, počínaje začátkem řezu.
    ///
    /// Kusy jsou proměnlivé odkazy na pole a nepřekrývají se.
    /// Pokud `N` nerozdělí délku řezu, poslední až `N-1` prvky budou vynechány a lze je načíst z funkce `into_remainder` iterátoru.
    ///
    ///
    /// Tato metoda je obecným ekvivalentem ekvivalentu [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics, pokud `N` je 0. Tato kontrola se s největší pravděpodobností změní na chybu kompilace, než se tato metoda stabilizuje.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Vrátí iterátor překrývající windows z `N` prvků řezu, počínaje začátkem řezu.
    ///
    ///
    /// Toto je obecný ekvivalent const [`windows`].
    ///
    /// Pokud je `N` větší než velikost řezu, nevrátí windows.
    ///
    /// # Panics
    ///
    /// Panics, pokud `N` je 0.
    /// Tato kontrola se s největší pravděpodobností změní na časovou chybu kompilace, než se tato metoda stabilizuje.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Vrátí iterátor přes `chunk_size` prvků řezu najednou, počínaje koncem řezu.
    ///
    /// Kousky jsou plátky a nepřekrývají se.Pokud `chunk_size` nerozdělí délku řezu, pak poslední blok nebude mít délku `chunk_size`.
    ///
    /// Viz [`rchunks_exact`] pro variantu tohoto iterátoru, která vrací bloky vždy přesně `chunk_size` prvků, a [`chunks`] pro stejný iterátor, ale začínající na začátku řezu.
    ///
    ///
    /// # Panics
    ///
    /// Panics, pokud `chunk_size` je 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Vrátí iterátor přes `chunk_size` prvků řezu najednou, počínaje koncem řezu.
    ///
    /// Kousky jsou proměnlivé plátky a nepřekrývají se.Pokud `chunk_size` nerozdělí délku řezu, pak poslední blok nebude mít délku `chunk_size`.
    ///
    /// Viz [`rchunks_exact_mut`] pro variantu tohoto iterátoru, která vrací bloky vždy přesně `chunk_size` prvků, a [`chunks_mut`] pro stejný iterátor, ale začínající na začátku řezu.
    ///
    ///
    /// # Panics
    ///
    /// Panics, pokud `chunk_size` je 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Vrátí iterátor přes `chunk_size` prvků řezu najednou, počínaje koncem řezu.
    ///
    /// Kousky jsou plátky a nepřekrývají se.
    /// Pokud `chunk_size` nerozdělí délku řezu, poslední až `chunk_size-1` prvky budou vynechány a lze je načíst z funkce `remainder` iterátoru.
    ///
    /// Vzhledem k tomu, že každý blok má přesně `chunk_size` prvky, může kompilátor často optimalizovat výsledný kód lépe než v případě [`chunks`].
    ///
    /// Viz [`rchunks`] pro variantu tohoto iterátoru, který také vrací zbytek jako menší blok, a [`chunks_exact`] pro stejný iterátor, ale začínající na začátku řezu.
    ///
    ///
    /// # Panics
    ///
    /// Panics, pokud `chunk_size` je 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Vrátí iterátor přes `chunk_size` prvků řezu najednou, počínaje koncem řezu.
    ///
    /// Kousky jsou proměnlivé plátky a nepřekrývají se.
    /// Pokud `chunk_size` nerozdělí délku řezu, poslední až `chunk_size-1` prvky budou vynechány a lze je načíst z funkce `into_remainder` iterátoru.
    ///
    /// Vzhledem k tomu, že každý blok má přesně `chunk_size` prvky, může kompilátor často optimalizovat výsledný kód lépe než v případě [`chunks_mut`].
    ///
    /// Viz [`rchunks_mut`] pro variantu tohoto iterátoru, který také vrací zbytek jako menší blok, a [`chunks_exact_mut`] pro stejný iterátor, ale začínající na začátku řezu.
    ///
    ///
    /// # Panics
    ///
    /// Panics, pokud `chunk_size` je 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Vrátí iterátor nad řezem, který produkuje nepřekrývající se běhy prvků pomocí predikátu k jejich oddělení.
    ///
    /// Predikát je volán na dvou následujících prvcích, to znamená, že predikát je volán na `slice[0]` a `slice[1]`, pak na `slice[1]` a `slice[2]` atd.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tuto metodu lze použít k extrakci seřazených dílčích indexů:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Vrátí iterátor nad řezem, který vytváří nepřekrývající se proměnlivé běhy prvků pomocí predikátu k jejich oddělení.
    ///
    /// Predikát je volán na dvou následujících prvcích, to znamená, že predikát je volán na `slice[0]` a `slice[1]`, pak na `slice[1]` a `slice[2]` atd.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tuto metodu lze použít k extrakci seřazených dílčích indexů:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Rozdělí jeden řez na dva v indexu.
    ///
    /// První bude obsahovat všechny indexy z `[0, mid)` (kromě samotného indexu `mid`) a druhý bude obsahovat všechny indexy z `[mid, len)` (kromě samotného indexu `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics pokud `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // BEZPEČNOST: `[ptr; mid]` a `[mid; len]` jsou uvnitř `self`, což
        // splňuje požadavky `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Rozdělí jeden proměnlivý řez na dva v indexu.
    ///
    /// První bude obsahovat všechny indexy z `[0, mid)` (kromě samotného indexu `mid`) a druhý bude obsahovat všechny indexy z `[mid, len)` (kromě samotného indexu `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics pokud `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // BEZPEČNOST: `[ptr; mid]` a `[mid; len]` jsou uvnitř `self`, což
        // splňuje požadavky `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Rozdělí jeden řez na dva v indexu, aniž by provedl kontrolu hranic.
    ///
    /// První bude obsahovat všechny indexy z `[0, mid)` (kromě samotného indexu `mid`) a druhý bude obsahovat všechny indexy z `[mid, len)` (kromě samotného indexu `len`).
    ///
    ///
    /// Pro bezpečnou alternativu viz [`split_at`].
    ///
    /// # Safety
    ///
    /// Volání této metody s indexem out-of-bounds je *[nedefinované chování]*, i když se výsledný odkaz nepoužívá.Volající musí zajistit, aby `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // BEZPEČNOST: Volající musí zkontrolovat, zda je `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Rozdělí jeden proměnlivý řez na dva v indexu, aniž by provedl kontrolu hranic.
    ///
    /// První bude obsahovat všechny indexy z `[0, mid)` (kromě samotného indexu `mid`) a druhý bude obsahovat všechny indexy z `[mid, len)` (kromě samotného indexu `len`).
    ///
    ///
    /// Pro bezpečnou alternativu viz [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Volání této metody s indexem out-of-bounds je *[nedefinované chování]*, i když se výsledný odkaz nepoužívá.Volající musí zajistit, aby `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // BEZPEČNOST: Volající musí zkontrolovat, zda je `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` a `[mid; len]` se nepřekrývají, takže vrácení proměnlivého odkazu je v pořádku.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Vrátí iterátor přes podřízené oblasti oddělené prvky, které odpovídají `pred`.
    /// Odpovídající prvek není obsažen v podsložkách.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Pokud je první prvek spárován, prázdný řez bude první položkou vrácenou iterátorem.
    /// Podobně, pokud se shoduje poslední prvek v řezu, prázdný řez bude poslední položkou vrácenou iterátorem:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Pokud dva spárované prvky přímo sousedí, bude mezi nimi přítomen prázdný řez:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Vrátí iterátor přes proměnlivé dílčí indexy oddělené prvky, které odpovídají `pred`.
    /// Odpovídající prvek není obsažen v podsložkách.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Vrátí iterátor přes podřízené oblasti oddělené prvky, které odpovídají `pred`.
    /// Odpovídající prvek je obsažen na konci předchozího dílčího řezu jako zakončení.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Pokud je shodný poslední prvek řezu, bude tento prvek považován za zakončení předchozího řezu.
    ///
    /// Tento řez bude poslední položkou vrácenou iterátorem.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Vrátí iterátor přes proměnlivé dílčí indexy oddělené prvky, které odpovídají `pred`.
    /// Odpovídající prvek je obsažen v předchozím dílčím řezu jako zakončení.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Vrátí iterátor přes podřízené řádky oddělené prvky, které odpovídají `pred`, počínaje koncem řezu a fungující vzad.
    /// Odpovídající prvek není obsažen v podsložkách.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stejně jako u `split()`, pokud je shodný první nebo poslední prvek, prázdný řez bude první (nebo poslední) položka vrácená iterátorem.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Vrátí iterátor přes proměnlivé dílčí indexy oddělené prvky, které se shodují s `pred`, počínaje koncem řezu a fungující vzad.
    /// Odpovídající prvek není obsažen v podsložkách.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Vrátí iterátor přes dílčí indexy oddělené prvky, které odpovídají `pred`, omezeno na vrácení maximálně `n` položek.
    /// Odpovídající prvek není obsažen v podsložkách.
    ///
    /// Poslední vrácený prvek, pokud existuje, bude obsahovat zbytek řezu.
    ///
    /// # Examples
    ///
    /// Vytiskněte řez rozdělený jednou čísly dělitelnými 3 (tj. `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Vrátí iterátor přes dílčí indexy oddělené prvky, které odpovídají `pred`, omezeno na vrácení maximálně `n` položek.
    /// Odpovídající prvek není obsažen v podsložkách.
    ///
    /// Poslední vrácený prvek, pokud existuje, bude obsahovat zbytek řezu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Vrátí iterátor přes podřízené oblasti oddělené prvky, které odpovídají `pred` omezenému na vrácení maximálně `n` položek.
    /// Začíná to na konci řezu a funguje to obráceně.
    /// Odpovídající prvek není obsažen v podsložkách.
    ///
    /// Poslední vrácený prvek, pokud existuje, bude obsahovat zbytek řezu.
    ///
    /// # Examples
    ///
    /// Vytiskněte rozdělené řezy jednou, počínaje koncem, čísly dělitelnými 3 (tj. `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Vrátí iterátor přes podřízené oblasti oddělené prvky, které odpovídají `pred` omezenému na vrácení maximálně `n` položek.
    /// Začíná to na konci řezu a funguje to obráceně.
    /// Odpovídající prvek není obsažen v podsložkách.
    ///
    /// Poslední vrácený prvek, pokud existuje, bude obsahovat zbytek řezu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Vrátí `true`, pokud řez obsahuje prvek s danou hodnotou.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Pokud nemáte `&T`, ale jen `&U` takový, že `T: Borrow<U>` (např
    /// `Řetězec: Půjčit si<str>`), můžete použít `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // plátek `String`
    /// assert!(v.iter().any(|e| e == "hello")); // hledat pomocí `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Vrátí `true`, pokud `needle` je předpona řezu.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Vždy vrátí `true`, pokud `needle` je prázdný řez:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Vrátí `true`, pokud `needle` je přípona řezu.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Vždy vrátí `true`, pokud `needle` je prázdný řez:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Vrátí dílčí řez s odstraněnou předponou.
    ///
    /// Pokud řez začíná `prefix`, vrátí podřízený řez za předponou zabalený do `Some`.
    /// Pokud je `prefix` prázdný, jednoduše vrátí původní řez.
    ///
    /// Pokud řez nezačíná `prefix`, vrátí `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Tato funkce bude muset přepsat, pokud a kdy se SlicePattern stane sofistikovanějším.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Vrátí dílčí řez s odstraněnou příponou.
    ///
    /// Pokud řez končí `suffix`, vrátí podřízený díl před příponou zabalený do `Some`.
    /// Pokud je `suffix` prázdný, jednoduše vrátí původní řez.
    ///
    /// Pokud řez nekončí `suffix`, vrátí `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Tato funkce bude muset přepsat, pokud a kdy se SlicePattern stane sofistikovanějším.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binární prohledá tento seřazený řez pro daný prvek.
    ///
    /// Pokud je hodnota nalezena, vrátí se [`Result::Ok`] obsahující index odpovídajícího prvku.
    /// Pokud existuje více shod, mohl by být vrácen kterýkoli ze zápasů.
    /// Pokud hodnota není nalezena, vrátí se [`Result::Err`], obsahující index, do kterého lze při zachování seřazeného pořadí vložit odpovídající prvek.
    ///
    ///
    /// Viz také [`binary_search_by`], [`binary_search_by_key`] a [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Vyhledá řadu čtyř prvků.
    /// První je nalezen s jedinečně určenou pozicí;druhý a třetí nejsou nalezeny;čtvrtý mohl odpovídat jakékoli pozici v `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Pokud chcete vložit položku do seřazeného vector, při zachování pořadí řazení:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binární prohledá tento seřazený řez pomocí funkce komparátoru.
    ///
    /// Funkce komparátoru by měla implementovat pořadí konzistentní s pořadím řazení podkladového řezu a vracet kód objednávky, který označuje, zda je jeho argument `Less`, `Equal` nebo `Greater` požadovaný cíl.
    ///
    ///
    /// Pokud je hodnota nalezena, vrátí se [`Result::Ok`] obsahující index odpovídajícího prvku.Pokud existuje více shod, mohl by být vrácen kterýkoli ze zápasů.
    /// Pokud hodnota není nalezena, vrátí se [`Result::Err`], obsahující index, do kterého lze při zachování seřazeného pořadí vložit odpovídající prvek.
    ///
    /// Viz také [`binary_search`], [`binary_search_by_key`] a [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Vyhledá řadu čtyř prvků.První je nalezen s jedinečně určenou pozicí;druhý a třetí nebyl nalezen;čtvrtý mohl odpovídat jakékoli pozici v `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // BEZPEČNOST: hovor je zabezpečen následujícími invarianty:
            // - `mid >= 0`
            // - `mid < size`: `mid` je omezen vázaným `[left; right)`.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Důvod, proč používáme tok řízení if/else spíše než shodu, je ten, že shoda mění pořadí porovnávacích operací, což je citlivé na perf.
            //
            // Toto je x86 asm pro u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binární prohledá tento seřazený řez pomocí funkce extrakce klíče.
    ///
    /// Předpokládá, že řez je tříděn podle klíče, například s [`sort_by_key`] pomocí stejné funkce extrakce klíče.
    ///
    /// Pokud je hodnota nalezena, vrátí se [`Result::Ok`] obsahující index odpovídajícího prvku.
    /// Pokud existuje více shod, mohl by být vrácen kterýkoli ze zápasů.
    /// Pokud hodnota není nalezena, vrátí se [`Result::Err`], obsahující index, do kterého lze při zachování seřazeného pořadí vložit odpovídající prvek.
    ///
    ///
    /// Viz také [`binary_search`], [`binary_search_by`] a [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Vyhledá řadu čtyř prvků v řezu párů seřazených podle jejich druhých prvků.
    /// První je nalezen s jedinečně určenou pozicí;druhý a třetí nejsou nalezeny;čtvrtý mohl odpovídat jakékoli pozici v `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links je povolen, protože `slice::sort_by_key` je v crate `alloc` a jako takový ještě neexistuje při vytváření `core`.
    //
    // odkazy na navazující crate: #74481.Protože primitiva jsou dokumentována pouze v libstd (#73423), v praxi to nikdy nevede k nefunkčním odkazům.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Seřadí řez, ale nemusí zachovat pořadí stejných prvků.
    ///
    /// Tento druh je nestabilní (tj. Může měnit pořadí stejných prvků), na místě (tj. Nepřiděluje) a *O*(*n*\*log(* n*)) v nejhorším případě).
    ///
    /// # Aktuální implementace
    ///
    /// Současný algoritmus je založen na [pattern-defeating quicksort][pdqsort] od Orsona Petersa, který kombinuje rychlý průměrný případ randomizovaného quicksortu s rychle nejhorším případem heapsortu, přičemž dosahuje lineárního času na řezech s určitými vzory.
    /// Používá určitou randomizaci, aby se zabránilo degenerovaným případům, ale s pevným seed vždy poskytuje deterministické chování.
    ///
    /// Obvykle je rychlejší než stabilní třídění, s výjimkou několika zvláštních případů, např. Když se řez skládá z několika zřetězených seřazených sekvencí.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Seřadí řez podle funkce komparátoru, ale nemusí zachovat pořadí stejných prvků.
    ///
    /// Tento druh je nestabilní (tj. Může měnit pořadí stejných prvků), na místě (tj. Nepřiděluje) a *O*(*n*\*log(* n*)) v nejhorším případě).
    ///
    /// Funkce komparátoru musí definovat celkové uspořádání prvků v řezu.Pokud pořadí není celkové, pořadí prvků je nespecifikováno.Objednávka je celková objednávka, pokud je (pro všechny `a`, `b` a `c`):
    ///
    /// * celkový a antisymetrický: přesně jeden z `a < b`, `a == b` nebo `a > b` je pravdivý a
    /// * tranzitivní, `a < b` a `b < c` znamená `a < c`.Totéž musí platit pro `==` i `>`.
    ///
    /// Například zatímco [`f64`] neimplementuje [`Ord`], protože `NaN != NaN`, můžeme použít `partial_cmp` jako naši funkci řazení, když víme, že řez neobsahuje `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Aktuální implementace
    ///
    /// Současný algoritmus je založen na [pattern-defeating quicksort][pdqsort] od Orsona Petersa, který kombinuje rychlý průměrný případ randomizovaného quicksortu s rychle nejhorším případem heapsortu, přičemž dosahuje lineárního času na řezech s určitými vzory.
    /// Používá určitou randomizaci, aby se zabránilo degenerovaným případům, ale s pevným seed vždy poskytuje deterministické chování.
    ///
    /// Obvykle je rychlejší než stabilní třídění, s výjimkou několika zvláštních případů, např. Když se řez skládá z několika zřetězených seřazených sekvencí.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // zpětné třídění
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Seřadí řez podle funkce extrakce klíčů, ale nemusí zachovat pořadí stejných prvků.
    ///
    /// Tento druh je nestabilní (tj. Může měnit pořadí stejných prvků), na místě (tj. Nepřiděluje) a *O*(m\* * n *\* log(*n*)) nejhorší případ, kde klíčovou funkcí je *O*(*m*).
    ///
    /// # Aktuální implementace
    ///
    /// Současný algoritmus je založen na [pattern-defeating quicksort][pdqsort] od Orsona Petersa, který kombinuje rychlý průměrný případ randomizovaného quicksortu s rychle nejhorším případem heapsortu, přičemž dosahuje lineárního času na řezech s určitými vzory.
    /// Používá určitou randomizaci, aby se zabránilo degenerovaným případům, ale s pevným seed vždy poskytuje deterministické chování.
    ///
    /// Díky své strategii klíčových volání bude [`sort_unstable_by_key`](#method.sort_unstable_by_key) pravděpodobně pomalejší než [`sort_by_cached_key`](#method.sort_by_cached_key) v případech, kdy je klíčová funkce drahá.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Změňte pořadí řezu tak, aby byl prvek v `index` ve své konečné tříděné poloze.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Změňte pořadí řezu pomocí funkce komparátoru tak, aby byl prvek v `index` ve své konečné tříděné poloze.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Změňte pořadí řezu pomocí funkce extrakce klíčů tak, aby byl prvek v `index` ve své konečné tříděné poloze.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Změňte pořadí řezu tak, aby byl prvek v `index` ve své konečné tříděné poloze.
    ///
    /// Toto přeskupení má další vlastnost, že jakákoli hodnota na pozici `i < index` bude menší nebo rovna jakékoli hodnotě na pozici `j > index`.
    /// Toto přeskupení je navíc nestabilní (tj
    /// libovolný počet stejných prvků může skončit na pozici `index`), na místě (tj
    /// nepřiděluje) a *O*(*n*) nejhorší případ.
    /// Tato funkce je v jiných knihovnách také známá jako "kth element".
    /// Vrátí trojici následujících hodnot: všechny prvky menší než ten v daném indexu, hodnota v daném indexu a všechny prvky větší než ten v daném indexu.
    ///
    ///
    /// # Aktuální implementace
    ///
    /// Aktuální algoritmus je založen na části rychlého výběru stejného algoritmu quicksortu použitého pro [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics při `index >= len()`, což znamená, že vždy panics na prázdných řezech.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Najděte medián
    /// v.select_nth_unstable(2);
    ///
    /// // Je nám zaručeno pouze to, že řez bude jedním z následujících, na základě způsobu, jakým řadíme podle zadaného indexu.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Změňte pořadí řezu pomocí funkce komparátoru tak, aby byl prvek v `index` ve své konečné tříděné poloze.
    ///
    /// Toto přeskupení má další vlastnost, že jakákoli hodnota na pozici `i < index` bude menší nebo rovna jakékoli hodnotě na pozici `j > index` pomocí funkce komparátoru.
    /// Toto přeskupení je navíc nestabilní (tj. Libovolný počet stejných prvků může skončit na pozici `index`), na místě (tj. Nepřiděluje) a nejhorší případ *O*(*n*).
    /// Tato funkce je v jiných knihovnách známá také jako "kth element".
    /// Vrátí triplet následujících hodnot: všechny prvky menší než ten v daném indexu, hodnota v daném indexu a všechny prvky větší než ten v daném indexu, pomocí poskytnuté komparátorové funkce.
    ///
    ///
    /// # Aktuální implementace
    ///
    /// Aktuální algoritmus je založen na části rychlého výběru stejného algoritmu quicksortu použitého pro [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics při `index >= len()`, což znamená, že vždy panics na prázdných řezech.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Najděte medián, jako kdyby byl řez seřazen sestupně.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Je nám zaručeno pouze to, že řez bude jedním z následujících, na základě způsobu, jakým řadíme podle zadaného indexu.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Změňte pořadí řezu pomocí funkce extrakce klíčů tak, aby byl prvek v `index` ve své konečné tříděné poloze.
    ///
    /// Toto přeskupení má další vlastnost, že jakákoli hodnota na pozici `i < index` bude menší nebo rovna jakékoli hodnotě na pozici `j > index` pomocí funkce extrakce klíče.
    /// Toto přeskupení je navíc nestabilní (tj. Libovolný počet stejných prvků může skončit na pozici `index`), na místě (tj. Nepřiděluje) a nejhorší případ *O*(*n*).
    /// Tato funkce je v jiných knihovnách známá také jako "kth element".
    /// Vrátí triplet následujících hodnot: všechny prvky menší než ten v daném indexu, hodnota v daném indexu a všechny prvky větší než ten v daném indexu, pomocí poskytnuté funkce extrakce klíče.
    ///
    ///
    /// # Aktuální implementace
    ///
    /// Aktuální algoritmus je založen na části rychlého výběru stejného algoritmu quicksortu použitého pro [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics při `index >= len()`, což znamená, že vždy panics na prázdných řezech.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Vraťte medián, jako by bylo pole seřazeno podle absolutní hodnoty.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Je nám zaručeno pouze to, že řez bude jedním z následujících, na základě způsobu, jakým řadíme podle zadaného indexu.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Přesune všechny po sobě jdoucí opakované prvky na konec řezu podle implementace [`PartialEq`] trait.
    ///
    ///
    /// Vrátí dva plátky.První neobsahuje žádné po sobě jdoucí opakované prvky.
    /// Druhý obsahuje všechny duplikáty v nezadaném pořadí.
    ///
    /// Pokud je řez seřazen, první vrácený řez neobsahuje žádné duplikáty.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Přesune všechny následující prvky kromě prvního na konec řezu, který splňuje daný vztah rovnosti.
    ///
    /// Vrátí dva plátky.První neobsahuje žádné po sobě jdoucí opakované prvky.
    /// Druhý obsahuje všechny duplikáty v nezadaném pořadí.
    ///
    /// Funkce `same_bucket` předává odkazy na dva prvky z řezu a musí určit, zda se prvky porovnávají stejně.
    /// Prvky se předávají v opačném pořadí, než jaké jsou v řezu, takže pokud `same_bucket(a, b)` vrátí `true`, `a` se přesune na konec řezu.
    ///
    ///
    /// Pokud je řez seřazen, první vrácený řez neobsahuje žádné duplikáty.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // I když máme proměnlivý odkaz na `self`, nemůžeme provádět *svévolné* změny.Volání `same_bucket` by mohla panic, takže musíme zajistit, aby byl řez vždy v platném stavu.
        //
        // Způsob, jakým to řešíme, je pomocí swapů;iterujeme přes všechny prvky a vyměňujeme je, takže na konci jsou prvky, které si přejeme ponechat, vpředu a ty, které chceme odmítnout, jsou vzadu.
        // Poté můžeme plátek rozdělit.
        // Tato operace je stále `O(n)`.
        //
        // Příklad: Začneme v tomto stavu, kde `r` představuje " další
        // přečíst "a `w` představuje" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Ve srovnání s self[r] proti sobě [w-1] se nejedná o duplikát, proto vyměníme self[r] a self[w] (žádný účinek jako r==w) a poté zvýšíme r a w, takže nám zůstane:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Ve srovnání s self[r] proti sobě [w-1] je tato hodnota duplikát, takže zvýšíme `r`, ale necháme vše ostatní beze změny:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Ve srovnání s self[r] proti sobě [w-1] nejde o duplikát, proto vyměňte self[r] a self[w] a posuňte r a w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Nejedná se o duplikát, opakujte:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Duplikát, advance r. End řezu.Rozdělit na w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // BEZPEČNOST: podmínka `while` zaručuje `next_read` a `next_write`
        // jsou menší než `len`, tedy jsou uvnitř `self`.
        // `prev_ptr_write` ukazuje na jeden prvek před `ptr_write`, ale `next_write` začíná na 1, takže `prev_ptr_write` nikdy není menší než 0 a je uvnitř řezu.
        // Tím jsou splněny požadavky pro dereferencování `ptr_read`, `prev_ptr_write` a `ptr_write` a pro použití `ptr.add(next_read)`, `ptr.add(next_write - 1)` a `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` is also incremented at most once per loop at most means no element is skipped when it might need to be swapped.
        //
        // `ptr_read` a `prev_ptr_write` nikdy neukazují na stejný prvek.To je nutné, aby `&mut *ptr_read`, `&mut* prev_ptr_write` byly bezpečné.
        // Vysvětlení je prostě to, že `next_read >= next_write` vždy platí, takže `next_read > next_write - 1` také.
        //
        //
        //
        //
        //
        unsafe {
            // Vyhněte se hraničním kontrolám pomocí surových ukazatelů.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Přesune všechny následující prvky kromě prvního na konec řezu, který se vyřeší na stejný klíč.
    ///
    ///
    /// Vrátí dva plátky.První neobsahuje žádné po sobě jdoucí opakované prvky.
    /// Druhý obsahuje všechny duplikáty v nezadaném pořadí.
    ///
    /// Pokud je řez seřazen, první vrácený řez neobsahuje žádné duplikáty.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Otočí řez na místě tak, že se první prvky `mid` řezu přesunou na konec, zatímco poslední prvky `self.len() - mid` se posunou dopředu.
    /// Po volání `rotate_left` se prvek dříve v indexu `mid` stane prvním prvkem ve výřezu.
    ///
    /// # Panics
    ///
    /// Tato funkce bude panic, pokud je `mid` větší než délka řezu.Všimněte si, že `mid == self.len()` dělá _not_ panic a je to no-op rotace.
    ///
    /// # Complexity
    ///
    /// Bere lineární (v čase `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Otočení podřízku:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // BEZPEČNOST: Rozsah `[p.add(mid) - mid, p.add(mid) + k)` je triviální
        // platí pro čtení a zápis, jak vyžaduje `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Otočí řez na místě tak, že se první prvky `self.len() - k` řezu přesunou na konec, zatímco poslední prvky `k` se posunou dopředu.
    /// Po volání `rotate_right` se prvek dříve v indexu `self.len() - k` stane prvním prvkem ve výřezu.
    ///
    /// # Panics
    ///
    /// Tato funkce bude panic, pokud je `k` větší než délka řezu.Všimněte si, že `k == self.len()` dělá _not_ panic a je to no-op rotace.
    ///
    /// # Complexity
    ///
    /// Bere lineární (v čase `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Otočit dílčí řez:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // BEZPEČNOST: Rozsah `[p.add(mid) - mid, p.add(mid) + k)` je triviální
        // platí pro čtení a zápis, jak vyžaduje `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Naplní `self` prvky klonováním `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Vyplní `self` prvky vrácenými opakovaným voláním uzávěru.
    ///
    /// Tato metoda používá uzávěr k vytvoření nových hodnot.Pokud dáváte přednost [`Clone`] dané hodnotě, použijte [`fill`].
    /// Pokud chcete ke generování hodnot použít [`Default`] trait, můžete předat [`Default::default`] jako argument.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Zkopíruje prvky z `src` do `self`.
    ///
    /// Délka `src` musí být stejná jako `self`.
    ///
    /// Pokud `T` implementuje `Copy`, může být efektivnější použít [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Tato funkce bude panic, pokud mají dva řezy různé délky.
    ///
    /// # Examples
    ///
    /// Klonování dvou prvků z řezu do jiného:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Protože řezy musí mít stejnou délku, rozdělíme zdrojový řez ze čtyř prvků na dva.
    /// // Pokud to neděláme, bude to panic.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust vynucuje, že může existovat pouze jeden proměnlivý odkaz bez neměnných odkazů na konkrétní část dat v určitém rozsahu.
    /// Z tohoto důvodu bude mít pokus o použití `clone_from_slice` na jednom řezu za následek selhání kompilace:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Abychom to vyřešili, můžeme pomocí [`split_at_mut`] vytvořit dva odlišné dílčí řezy z řezu:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Zkopíruje všechny prvky z `src` do `self` pomocí memcpy.
    ///
    /// Délka `src` musí být stejná jako `self`.
    ///
    /// Pokud `T` neimplementuje `Copy`, použijte [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Tato funkce bude panic, pokud mají dva řezy různé délky.
    ///
    /// # Examples
    ///
    /// Kopírování dvou prvků z řezu do jiného:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Protože řezy musí mít stejnou délku, rozdělíme zdrojový řez ze čtyř prvků na dva.
    /// // Pokud to neděláme, bude to panic.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust vynucuje, že může existovat pouze jeden proměnlivý odkaz bez neměnných odkazů na konkrétní část dat v určitém rozsahu.
    /// Z tohoto důvodu bude mít pokus o použití `copy_from_slice` na jednom řezu za následek selhání kompilace:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Abychom to vyřešili, můžeme pomocí [`split_at_mut`] vytvořit dva odlišné dílčí řezy z řezu:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Cesta kódu panic byla vložena do studené funkce, aby nebyla nafouknuta stránka volání.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // BEZPEČNOST: `self` je podle definice platný pro prvky `self.len()` a `src` ano
        // zaškrtnuto, aby měly stejnou délku.
        // Řezy se nemohou překrývat, protože proměnlivé odkazy jsou exkluzivní.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Zkopíruje prvky z jedné části řezu do jiné jeho části pomocí funkce memmove.
    ///
    /// `src` je rozsah v rámci `self`, ze kterého se má kopírovat.
    /// `dest` je počáteční index rozsahu v rámci `self`, do kterého se má zkopírovat, který bude mít stejnou délku jako `src`.
    /// Tyto dva rozsahy se mohou překrývat.
    /// Konce těchto dvou rozsahů musí být menší nebo rovné `self.len()`.
    ///
    /// # Panics
    ///
    /// Tato funkce bude panic, pokud buď rozsah přesáhne konec řezu, nebo pokud je konec `src` před začátkem.
    ///
    ///
    /// # Examples
    ///
    /// Kopírování čtyř bajtů v řezu:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // BEZPEČNOST: podmínky pro `ptr::copy` byly zkontrolovány výše,
        // stejně jako ty pro `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Zamění všechny prvky v `self` s těmi v `other`.
    ///
    /// Délka `other` musí být stejná jako `self`.
    ///
    /// # Panics
    ///
    /// Tato funkce bude panic, pokud mají dva řezy různé délky.
    ///
    /// # Example
    ///
    /// Prohození dvou prvků přes plátky:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust vynucuje, že může existovat pouze jeden proměnlivý odkaz na konkrétní část dat v určitém rozsahu.
    ///
    /// Z tohoto důvodu bude mít pokus o použití `swap_with_slice` na jednom řezu za následek selhání kompilace:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Abychom to vyřešili, můžeme použít [`split_at_mut`] k vytvoření dvou odlišných proměnlivých dílčích řezů z řezu:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // BEZPEČNOST: `self` je podle definice platný pro prvky `self.len()` a `src` ano
        // zaškrtnuto, aby měly stejnou délku.
        // Řezy se nemohou překrývat, protože proměnlivé odkazy jsou exkluzivní.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Funkce pro výpočet délek středního a zadního řezu pro `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Co uděláme s `rest`, je přijít na to, kolik násobků " U`můžeme umístit na nejnižší počet " T`.
        //
        // A kolik `T` potřebujeme pro každý takový "multiple".
        //
        // Uvažujme například T=u8 U=u16.Pak můžeme dát 1 U do 2 Ts.Jednoduchý.
        // Zvažte například případ, kdy size_of: :<T>=16, size_of::<U>=24.</u>
        // Můžeme dát 2 Us namísto každé 3 Ts do řezu `rest`.
        // Trochu komplikovanější.
        //
        // Vzorec pro výpočet je:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Rozšířené a zjednodušené:
        //
        // Us=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Naštěstí, protože to vše je neustále hodnoceno ... výkon zde nezáleží!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iterativní Steinův algoritmus Tento `const fn` bychom měli stále dělat (a pokud to uděláme, vrátit se k rekurzivnímu algoritmu), protože spoléhání se na llvm, aby to všechno bylo, je ... no, je mi to nepříjemné.
            //
            //

            // BEZPEČNOST: `a` a `b` jsou označeny jako nenulové hodnoty.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // odstranit všechny faktory 2 z b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // BEZPEČNOST: `b` je zaškrtnuto jako nenulové.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Vyzbrojeni těmito znalostmi, můžeme zjistit, kolik `U` se vejde!
        let us_len = self.len() / ts * us;
        // A kolik `T bude v koncovém řezu!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Převeďte řez na řez jiného typu a zajistěte zachování zarovnání typů.
    ///
    /// Tato metoda rozděluje řez na tři odlišné řezy: předponu, správně zarovnaný střední řez nového typu a příponu řezu.
    /// Metoda může učinit prostřední řez nejdelší možnou délkou pro daný typ a vstupní řez, ale na tom by měl záviset pouze výkon vašeho algoritmu, nikoli jeho správnost.
    ///
    /// Je přípustné, aby byla všechna vstupní data vrácena jako řez předpony nebo přípony.
    ///
    /// Tato metoda nemá žádný účel, když jsou vstupní prvek `T` nebo výstupní prvek `U` nulové velikosti a vrátí původní řez bez rozdělení čehokoli.
    ///
    /// # Safety
    ///
    /// Tato metoda je v podstatě `transmute` s ohledem na prvky ve vráceném středním řezu, takže zde platí i všechny obvyklé výhrady týkající se `transmute::<T, U>`.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Všimněte si, že většina z této funkce bude vyhodnocována konstantně,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // zacházejte se ZST zvlášť, což je-vůbec s nimi nezacházejte.
            return (self, &[], &[]);
        }

        // Nejprve zjistěte, v jakém okamžiku rozdělíme mezi první a druhý řez.
        // Snadné s ptr.align_offset.
        let ptr = self.as_ptr();
        // BEZPEČNOST: Podrobný bezpečnostní komentář viz metoda `align_to_mut`.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // BEZPEČNOST: nyní je `rest` rozhodně zarovnán, takže níže uvedený `from_raw_parts` je v pořádku,
            // protože volající zaručuje, že můžeme bezpečně převést `T` na `U`.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Převeďte řez na řez jiného typu a zajistěte zachování zarovnání typů.
    ///
    /// Tato metoda rozděluje řez na tři odlišné řezy: předponu, správně zarovnaný střední řez nového typu a příponu řezu.
    /// Metoda může učinit prostřední řez nejdelší možnou délkou pro daný typ a vstupní řez, ale na tom by měl záviset pouze výkon vašeho algoritmu, nikoli jeho správnost.
    ///
    /// Je přípustné, aby byla všechna vstupní data vrácena jako řez předpony nebo přípony.
    ///
    /// Tato metoda nemá žádný účel, když jsou vstupní prvek `T` nebo výstupní prvek `U` nulové velikosti a vrátí původní řez bez rozdělení čehokoli.
    ///
    /// # Safety
    ///
    /// Tato metoda je v podstatě `transmute` s ohledem na prvky ve vráceném středním řezu, takže zde platí i všechny obvyklé výhrady týkající se `transmute::<T, U>`.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Všimněte si, že většina z této funkce bude vyhodnocována konstantně,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // zacházejte se ZST zvlášť, což je-vůbec s nimi nezacházejte.
            return (self, &mut [], &mut []);
        }

        // Nejprve zjistěte, v jakém okamžiku rozdělíme mezi první a druhý řez.
        // Snadné s ptr.align_offset.
        let ptr = self.as_ptr();
        // BEZPEČNOST: Zde zajišťujeme, že pro U použijeme zarovnané ukazatele pro U.
        // zbytek metody.To se provádí předáním ukazatele na&[T] se zarovnáním zaměřeným na U.
        // `crate::ptr::align_offset` je volán se správně zarovnaným a platným ukazatelem `ptr` (pochází z odkazu na `self`) as velikostí, která je mocninou dvou (protože pochází z vyrovnání pro U), splňující jeho bezpečnostní omezení.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Poté už nemůžeme `rest` znovu použít, to by zneplatnilo jeho alias `mut_ptr`!BEZPEČNOST: viz komentáře k `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Zkontroluje, zda jsou tříděny prvky tohoto řezu.
    ///
    /// To znamená, že pro každý prvek `a` a jeho následující prvek `b` musí `a <= b` platit.Pokud výřez poskytuje přesně nulu nebo jeden prvek, vrátí se `true`.
    ///
    /// Všimněte si, že pokud `Self::Item` je pouze `PartialOrd`, ale ne `Ord`, výše uvedená definice znamená, že tato funkce vrací `false`, pokud nejsou dvě po sobě jdoucí položky srovnatelné.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Zkontroluje, zda jsou prvky tohoto řezu tříděny pomocí dané funkce komparátoru.
    ///
    /// Namísto použití `PartialOrd::partial_cmp` tato funkce používá danou funkci `compare` k určení pořadí dvou prvků.
    /// Kromě toho je to ekvivalent [`is_sorted`];další informace najdete v jeho dokumentaci.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Zkontroluje, zda jsou prvky tohoto řezu tříděny pomocí dané funkce extrakce klíčů.
    ///
    /// Namísto přímého porovnání prvků řezu tato funkce porovnává klíče prvků, jak je určeno `f`.
    /// Kromě toho je to ekvivalent [`is_sorted`];další informace najdete v jeho dokumentaci.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Vrátí index bodu oddílu podle daného predikátu (index prvního prvku druhého oddílu).
    ///
    /// Předpokládá se, že řez je rozdělen podle daného predikátu.
    /// To znamená, že všechny prvky, pro které predikát vrací true, jsou na začátku řezu a všechny prvky, pro které predikát vrací false, jsou na konci.
    ///
    /// Například [7, 15, 3, 5, 4, 12, 6] je rozdělena pod predikát x% 2!=0 (všechna lichá čísla jsou na začátku, všechna dokonce na konci).
    ///
    /// Pokud tento řez není rozdělen na oddíly, vrácený výsledek je nespecifikovaný a bezvýznamný, protože tato metoda provádí druh binárního vyhledávání.
    ///
    /// Viz také [`binary_search`], [`binary_search_by`] a [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // BEZPEČNOST: Když `left < right`, `left <= mid < right`.
            // Proto se `left` vždy zvyšuje a `right` se vždy snižuje a je vybrán jeden z nich.V obou případech je `left <= right` spokojen.Pokud je tedy `left < right` v kroku, `left <= right` je v dalším kroku spokojen.
            //
            // Pokud je tedy `left != right`, `0 <= left < right <= len` je spokojen, a pokud je tento případ `0 <= mid < len` také spokojen.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Musíme je výslovně rozdělit na stejnou délku
        // aby optimalizátor snáze unikl kontrole hranic.
        // Ale protože se na něj nelze spolehnout, máme také explicitní specializaci na T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Vytvoří prázdný řez.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Vytvoří proměnlivý prázdný řez.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Vzory v řezech, aktuálně používané pouze `strip_prefix` a `strip_suffix`.
/// V bodě future doufáme, že zobecníme `core::str::Pattern` (který je v době psaní omezen na `str`) na řezy a poté bude tento trait nahrazen nebo zrušen.
///
pub trait SlicePattern {
    /// Typ prvku řezu, který se shoduje.
    type Item;

    /// V současné době spotřebitelé `SlicePattern` potřebují plátek.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}