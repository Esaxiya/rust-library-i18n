//! Řazení podle řezů
//!
//! Tento modul obsahuje třídicí algoritmus založený na rychlém řazení Orsona Petersa, který byl publikován na: <https://github.com/orlp/pdqsort>
//!
//!
//! Nestabilní třídění je kompatibilní s libcore, protože na rozdíl od naší implementace stabilního třídění nepřiděluje paměť.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Při upuštění kopie z `src` do `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // BEZPEČNOST: Toto je pomocná třída.
        //          Správnost najdete v jeho použití.
        //          Jmenovitě si musíte být jisti, že `src` a `dst` se nepřekrývají, jak to vyžaduje `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Posune první prvek doprava, dokud nenarazí na větší nebo rovný prvek.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // BEZPEČNOST: Níže uvedené nebezpečné operace zahrnují indexování bez vázané kontroly (`get_unchecked` a `get_unchecked_mut`)
    // a kopírování paměti (`ptr::copy_nonoverlapping`).
    //
    // A.Indexování:
    //  1. Zkontrolovali jsme velikost pole na>=2.
    //  2. Všechno indexování, které uděláme, je vždy maximálně mezi {0 <= index < len}.
    //
    // b.Kopírování paměti
    //  1. Získáváme odkazy na reference, které jsou zaručeně platné.
    //  2. Nemohou se překrývat, protože získáváme ukazatele na rozdílové indexy řezu.
    //     Jmenovitě `i` a `i-1`.
    //  3. Pokud je řez správně zarovnaný, jsou prvky správně zarovnány.
    //     Je odpovědností volajícího zajistit, aby byl řez správně zarovnán.
    //
    // Další podrobnosti viz komentáře níže.
    unsafe {
        // Pokud jsou první dva prvky mimo pořadí ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Přečíst první prvek do proměnné přidělené zásobníku.
            // Pokud následující srovnávací operace panics, `hole` bude zrušena a automaticky zapíše prvek zpět do řezu.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Přesuňte `i`-tý prvek o jedno místo doleva, čímž posunete otvor doprava.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` spadne a tím zkopíruje `tmp` do zbývající díry v `v`.
        }
    }
}

/// Posune poslední prvek doleva, dokud nenarazí na menší nebo stejný prvek.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // BEZPEČNOST: Níže uvedené nebezpečné operace zahrnují indexování bez vázané kontroly (`get_unchecked` a `get_unchecked_mut`)
    // a kopírování paměti (`ptr::copy_nonoverlapping`).
    //
    // A.Indexování:
    //  1. Zkontrolovali jsme velikost pole na>=2.
    //  2. Všechno indexování, které uděláme, je vždy maximálně mezi `0 <= index < len-1`.
    //
    // b.Kopírování paměti
    //  1. Získáváme odkazy na reference, které jsou zaručeně platné.
    //  2. Nemohou se překrývat, protože získáváme ukazatele na rozdílové indexy řezu.
    //     Jmenovitě `i` a `i+1`.
    //  3. Pokud je řez správně zarovnaný, jsou prvky správně zarovnány.
    //     Je odpovědností volajícího zajistit, aby byl řez správně zarovnán.
    //
    // Další podrobnosti viz komentáře níže.
    unsafe {
        // Pokud jsou poslední dva prvky mimo pořadí ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Načtěte poslední prvek do proměnné přidělené zásobníku.
            // Pokud následující srovnávací operace panics, `hole` bude zrušena a automaticky zapíše prvek zpět do řezu.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Přesuňte `i`-tý prvek o jedno místo doprava, čímž posunete otvor doleva.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` spadne a tím zkopíruje `tmp` do zbývající díry v `v`.
        }
    }
}

/// Částečně seřadí výseč posunutím několika prvků mimo pořadí.
///
/// Vrátí `true`, pokud je řez na konci tříděn.Tato funkce je nejhorší případ *O*(*n*).
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Maximální počet sousedních párů mimo pořadí, které se posunou.
    const MAX_STEPS: usize = 5;
    // Pokud je výseč kratší, nepřesouvejte žádné prvky.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // BEZPEČNOST: Svázanou kontrolu jsme již výslovně provedli pomocí `i < len`.
        // Všechny naše následné indexování je pouze v rozsahu `0 <= index < len`
        unsafe {
            // Najděte další pár sousedních prvků mimo pořadí.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Jsme hotovi?
        if i == len {
            return true;
        }

        // Nepřesouvejte prvky na krátkých polích, což má cenu výkonu.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Zaměňte nalezenou dvojici prvků.To je staví do správného pořadí.
        v.swap(i - 1, i);

        // Posuňte menší prvek doleva.
        shift_tail(&mut v[..i], is_less);
        // Posuňte větší prvek doprava.
        shift_head(&mut v[i..], is_less);
    }

    // Nepodařilo se třídit plátek v omezeném počtu kroků.
    false
}

/// Seřadí řez pomocí třídění vložení, což je nejhorší případ *O*(*n*^ 2).
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Seřadí `v` pomocí heapsortu, který zaručuje *O*(*n*\*log(* n*)) v nejhorším případě.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Tato binární halda respektuje invariantní `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Děti `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Vyberte si větší dítě.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Zastavte, pokud invariant drží na `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Zaměňte `node` za větší dítě, posuňte se o krok dolů a pokračujte v prosévání.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Budujte hromadu v lineárním čase.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop maximální prvky z haldy.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Rozdělte oddíly `v` na prvky menší než `pivot`, následované prvky většími nebo rovnými `pivot`.
///
///
/// Vrátí počet prvků menší než `pivot`.
///
/// Rozdělení se provádí blok po bloku, aby se minimalizovaly náklady na operace větvení.
/// Tato myšlenka je prezentována v dokumentu [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Počet prvků v typickém bloku.
    const BLOCK: usize = 128;

    // Algoritmus dělení opakuje následující kroky až do dokončení:
    //
    // 1. Trasujte blok z levé strany, abyste identifikovali prvky větší nebo rovné otočnému čepu.
    // 2. Trace blok z pravé strany k identifikaci prvků menších než pivot.
    // 3. Vyměňte identifikované prvky mezi levou a pravou stranou.
    //
    // Pro blok prvků ponecháme následující proměnné:
    //
    // 1. `block` - Počet prvků v bloku.
    // 2. `start` - Spusťte ukazatel do pole `offsets`.
    // 3. `end` - Ukončete ukazatel do pole `offsets`.
    // 4. `kompenzace, indexy prvků mimo pořadí v bloku.

    // Aktuální blok na levé straně (od `l` do `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Aktuální blok na pravé straně (od `r.sub(block_r)` to `r`).
    // BEZPEČNOST: Dokumentace k .add() výslovně uvádí, že `vec.as_ptr().add(vec.len())` je vždy bezpečný
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Když dostaneme VLA, zkuste vytvořit jedno pole o délce `min(v.len(), 2 * BLOCK) `
    // než dvě pole pevné velikosti o délce `BLOCK`.VLA mohou být efektivnější z hlediska mezipaměti.

    // Vrátí počet prvků mezi ukazateli `l` (inclusive) a `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Když jsme se `l` a `r` přiblížili, skončili jsme s rozdělováním po blocích.
        // Poté provedeme nějakou opravu, abychom rozdělili zbývající prvky mezi ně.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Počet zbývajících prvků (stále není ve srovnání s pivotem).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Upravte velikosti bloků tak, aby se levý a pravý blok nepřekrývaly, ale aby byly dokonale zarovnány, aby pokryly celou zbývající mezeru.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Sledujte prvky `block_l` z levé strany.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // BEZPEČNOST: Níže uvedené nebezpečné operace zahrnují použití `offset`.
                //         Podle podmínek požadovaných funkcí je uspokojujeme, protože:
                //         1. `offsets_l` je alokováno do zásobníku a je tedy považováno za samostatný alokovaný objekt.
                //         2. Funkce `is_less` vrací `bool`.
                //            Casting `bool` nikdy nepřeteče `isize`.
                //         3. Zaručili jsme, že `block_l` bude `<= BLOCK`.
                //            Navíc byl `end_l` původně nastaven na počáteční ukazatel `offsets_`, který byl deklarován na zásobníku.
                //            Víme tedy, že i v nejhorším případě (všechna vyvolání `is_less` vrátí hodnotu false) budeme mít na konci maximálně 1 bajt.
                //        Další bezpečnou operací je dereferencování `elem`.
                //        `elem` byl však zpočátku počátečním ukazatelem na řez, který je vždy platný.
                unsafe {
                    // Bezvětvové srovnání.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Sledujte prvky `block_r` z pravé strany.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // BEZPEČNOST: Níže uvedené nebezpečné operace zahrnují použití `offset`.
                //         Podle podmínek požadovaných funkcí je uspokojujeme, protože:
                //         1. `offsets_r` je alokováno do zásobníku a je tedy považováno za samostatný alokovaný objekt.
                //         2. Funkce `is_less` vrací `bool`.
                //            Casting `bool` nikdy nepřeteče `isize`.
                //         3. Zaručili jsme, že `block_r` bude `<= BLOCK`.
                //            Navíc byl `end_r` původně nastaven na počáteční ukazatel `offsets_`, který byl deklarován na zásobníku.
                //            Víme tedy, že i v nejhorším případě (všechna vyvolání `is_less` vrací hodnotu true) budeme mít na konci maximálně 1 bajt.
                //        Další bezpečnou operací je dereferencování `elem`.
                //        `elem` však byl zpočátku `1 *sizeof(T)` za koncem a my jsme jej před přístupem snížili o `1* sizeof(T)`.
                //        Plus, `block_r` bylo prohlášeno za méně než `BLOCK` a `elem` proto bude nanejvýš ukazovat na začátek řezu.
                unsafe {
                    // Bezvětvové srovnání.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Počet prvků mimo pořadí, které se mají přepínat mezi levou a pravou stranou.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Místo výměny jednoho páru v té době je efektivnější provádět cyklickou permutaci.
            // To není striktně ekvivalentní swapování, ale vytváří podobný výsledek s použitím méně operací paměti.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Všechny prvky mimo pořadí v levém bloku byly přesunuty.Přejít na další blok.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Všechny prvky mimo pořadí v pravém bloku byly přesunuty.Přechod na předchozí blok.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Nyní zbývá maximálně jeden blok (levý nebo pravý) s prvky mimo pořadí, které je třeba přesunout.
    // Tyto zbývající prvky lze v jejich bloku jednoduše posunout na konec.
    //

    if start_l < end_l {
        // Levý blok zůstává.
        // Přesuňte zbývající prvky mimo pořadí zcela vpravo.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Pravý blok zůstává.
        // Přesuňte zbývající prvky mimo pořadí zcela vlevo.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Nic jiného neděláme, skončili jsme.
        width(v.as_mut_ptr(), l)
    }
}

/// Rozdělte oddíly `v` na prvky menší než `v[pivot]`, následované prvky většími nebo rovnými `v[pivot]`.
///
///
/// Vrátí n-tici:
///
/// 1. Počet prvků menší než `v[pivot]`.
/// 2. True, pokud `v` již byl rozdělen na oddíly.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Umístěte čep na začátek řezu.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Přečtěte si pivot do proměnné přidělené zásobníku pro efektivitu.
        // Pokud následující srovnávací operace panics, bude pivot automaticky zapsán zpět do řezu.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Najděte první pár prvků mimo pořadí.
        let mut l = 0;
        let mut r = v.len();

        // BEZPEČNOST: Níže uvedená nebezpečnost zahrnuje indexování pole.
        // Pro první: Hranice zde již kontrolujeme pomocí `l < r`.
        // Za druhé: Zpočátku máme `l == 0` a `r == v.len()` a zkontrolovali jsme, že `l < r` při každé operaci indexování.
        //                     Odtud víme, že `r` musí být alespoň `r == l`, u kterého se ukázalo, že je platný od prvního.
        unsafe {
            // Najděte první prvek větší nebo rovný otočnému čepu.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Najděte poslední prvek menší, než je otočný čep.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` vyjde z rozsahu a zapíše pivot (což je proměnná přidělená zásobníku) zpět do řezu, kde byl původně.
        // Tento krok je zásadní pro zajištění bezpečnosti!
        //
    };

    // Umístěte otočný čep mezi dva oddíly.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Oddíly `v` na prvky rovnající se `v[pivot]` následované prvky většími než `v[pivot]`.
///
/// Vrátí počet prvků rovný pivot.
/// Předpokládá se, že `v` neobsahuje prvky menší než pivot.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Umístěte čep na začátek řezu.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Přečtěte si pivot do proměnné přidělené zásobníku pro efektivitu.
    // Pokud následující srovnávací operace panics, bude pivot automaticky zapsán zpět do řezu.
    // BEZPEČNOST: Ukazatel zde je platný, protože je získán z odkazu na řez.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Nyní rozdělte plátek.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // BEZPEČNOST: Níže uvedená nebezpečnost zahrnuje indexování pole.
        // Pro první: Hranice zde již kontrolujeme pomocí `l < r`.
        // Za druhé: Zpočátku máme `l == 0` a `r == v.len()` a zkontrolovali jsme, že `l < r` při každé operaci indexování.
        //                     Odtud víme, že `r` musí být alespoň `r == l`, u kterého se ukázalo, že je platný od prvního.
        unsafe {
            // Najděte první prvek větší než pivot.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Najděte poslední prvek rovnající se pivot.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Jsme hotovi?
            if l >= r {
                break;
            }

            // Zaměňte nalezenou dvojici prvků mimo pořadí.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Našli jsme prvky `l` rovné otočnému čepu.Přidejte 1 do účtu pro samotný pivot.
    l + 1

    // `_pivot_guard` vyjde z rozsahu a zapíše pivot (což je proměnná přidělená zásobníku) zpět do řezu, kde byl původně.
    // Tento krok je zásadní pro zajištění bezpečnosti!
}

/// Rozptýlí některé prvky kolem ve snaze rozbít vzory, které by mohly způsobit nevyvážené oddíly v rychlém řazení.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Generátor pseudonáhodných čísel z článku "Xorshift RNGs" od George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Vezměte náhodná čísla modulo toto číslo.
        // Číslo zapadá do `usize`, protože `len` není větší než `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Někteří hlavní kandidáti budou v blízkosti tohoto indexu.Pojďme je randomizovat.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Vygenerujte náhodné číslo modulo `len`.
            // Abychom se však vyhnuli nákladným operacím, nejprve jej vezmeme modulo o síle dvou a poté snižujeme o `len`, dokud nezapadne do rozsahu `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` je zaručeno, že bude menší než `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Vybere pivot v `v` a vrátí index a `true`, pokud je řez pravděpodobně již seřazen.
///
/// V tomto procesu mohou být prvky v `v` přeuspořádány.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Minimální délka pro výběr metody mediánu mediánu.
    // Kratší řezy používají jednoduchou metodu střední hodnoty tří.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Maximální počet swapů, které lze v této funkci provést.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Tři indexy, poblíž kterých vybereme pivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Počítá celkový počet swapů, které se chystáme provést při třídění indexů.
    let mut swaps = 0;

    if len >= 8 {
        // Zaměňuje indexy tak, aby `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Zaměňuje indexy tak, aby `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Najde medián `v[a - 1], v[a], v[a + 1]` a uloží index do `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Najděte mediány v sousedstvích `a`, `b` a `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Najděte medián mezi `a`, `b` a `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Byl proveden maximální počet swapů.
        // Je pravděpodobné, že plátek klesá nebo většinou klesá, takže couvání pravděpodobně pomůže rychlejšímu řazení.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Třídí `v` rekurzivně.
///
/// Pokud řez měl předchůdce v původním poli, je zadán jako `pred`.
///
/// `limit` je počet povolených nevyvážených oddílů před přepnutím na `heapsort`.
/// Pokud je nula, tato funkce se okamžitě přepne na heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Řezy až do této délky se třídí pomocí třídění vložením.
    const MAX_INSERTION: usize = 20;

    // Je pravda, pokud bylo poslední rozdělení rozumně vyvážené.
    let mut was_balanced = true;
    // Pravda, pokud poslední rozdělení nerozmíchalo prvky (řez byl již rozdělen).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Velmi krátké řezy se třídí pomocí třídění vložením.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Pokud bylo provedeno příliš mnoho špatných rozhodnutí o otočení, jednoduše přepněte zpět na halps, abyste zajistili nejhorší případ `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Pokud bylo poslední rozdělení nevyvážené, zkuste rozbít vzory v řezu zamícháním některých prvků.
        // Doufejme, že tentokrát zvolíme lepší pivot.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Vyberte pivot a zkuste uhodnout, zda je řez již seřazen.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Pokud bylo poslední rozdělení slušně vyvážené a nebylo zamícháno prvků, a pokud předpovědi kontingenčního výběru předpovídají, že řez je pravděpodobně již seřazen ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Zkuste identifikovat několik prvků mimo pořadí a posunout je do správných pozic.
            // Pokud plátek skončí úplným tříděním, máme hotovo.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Pokud se vybraný pivot rovná předchůdci, pak je to nejmenší prvek v řezu.
        // Rozdělte řez na prvky stejné a prvky větší než pivot.
        // Tento případ je obvykle zasažen, když řez obsahuje mnoho duplicitních prvků.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Pokračujte v třídění prvků větších než pivot.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Rozdělte plátek.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Rozdělte řez na `left`, `pivot` a `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Opakujte pouze na kratší stranu, abyste minimalizovali celkový počet rekurzivních hovorů a spotřebovali méně místa v zásobníku.
        // Pak už jen pokračujte delší stranou (to se podobá rekurzi ocasu).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Seřadí `v` pomocí rychlého řazení, které ničí vzory, což je nejhorší případ *O*(*n*\*log(* n*)).
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // U typů nulové velikosti nemá řazení smysluplné chování.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Omezte počet nevyvážených oddílů na `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // U plátků do této délky je pravděpodobně rychlejší je jednoduše třídit.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Vyberte otočný čep
        let (pivot, _) = choose_pivot(v, is_less);

        // Pokud se vybraný pivot rovná předchůdci, pak je to nejmenší prvek v řezu.
        // Rozdělte řez na prvky stejné a prvky větší než pivot.
        // Tento případ je obvykle zasažen, když řez obsahuje mnoho duplicitních prvků.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Pokud jsme prošli naším indexem, pak jsme dobří.
                if mid > index {
                    return;
                }

                // Jinak pokračujte v třídění prvků větších než pivot.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Rozdělte řez na `left`, `pivot` a `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Pokud mid==index, pak jsme hotovi, protože partition() zaručil, že všechny prvky po polovině jsou větší nebo rovny polovině.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // U typů nulové velikosti nemá řazení smysluplné chování.Nedělat nic.
    } else if index == v.len() - 1 {
        // Najděte maximální prvek a umístěte jej na poslední pozici pole.
        // Zde můžeme zdarma používat `unwrap()`, protože víme, že v nesmí být prázdné.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Najděte prvek min a umístěte jej na první pozici pole.
        // Zde můžeme zdarma používat `unwrap()`, protože víme, že v nesmí být prázdné.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}