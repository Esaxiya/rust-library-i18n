/// Verze operátora volání, který přijímá neměnný přijímač.
///
/// Instance `Fn` lze volat opakovaně bez stavu mutace.
///
/// *Tuto trait (`Fn`) nelze zaměňovat s [function pointers] (`fn`).*
///
/// `Fn` je implementováno automaticky uzávěry, které berou pouze neměnné odkazy na zachycené proměnné nebo nezachycují vůbec nic, stejně jako (safe) [function pointers] (s některými upozorněními, viz jejich dokumentace pro další podrobnosti).
///
/// Navíc pro jakýkoli typ `F`, který implementuje `Fn`, `&F` implementuje také `Fn`.
///
/// Protože jak [`FnMut`], tak [`FnOnce`] jsou supertraity `Fn`, lze jako parametr použít libovolnou instanci `Fn`, kde se očekává [`FnMut`] nebo [`FnOnce`].
///
/// Použijte `Fn` jako vazbu, pokud chcete přijmout parametr funkčního typu a potřebujete jej volat opakovaně a bez mutace stavu (např. Při současném volání).
/// Pokud takové přísné požadavky nepotřebujete, použijte jako mezní hodnoty [`FnMut`] nebo [`FnOnce`].
///
/// Další informace o tomto tématu najdete v [chapter on closures in *The Rust Programming Language*][book].
///
/// Za zmínku stojí také speciální syntaxe pro `Fn` traits (např
/// `Fn(usize, bool) -> použití`).Zájemci o technické podrobnosti mohou odkazovat na [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Volání uzávěrky
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Pomocí parametru `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // aby se regex mohl spolehnout na `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Provede operaci hovoru.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Verze operátora volání, který přijímá proměnlivý přijímač.
///
/// Instance `FnMut` lze volat opakovaně a mohou mutovat stav.
///
/// `FnMut` je implementováno automaticky uzávěry, které berou proměnlivé odkazy na zachycené proměnné, stejně jako všechny typy, které implementují [`Fn`], např. (safe) [function pointers] (protože `FnMut` je supertrait [`Fn`]).
/// Navíc pro jakýkoli typ `F`, který implementuje `FnMut`, `&mut F` implementuje také `FnMut`.
///
/// Protože [`FnOnce`] je supertrénou `FnMut`, lze použít libovolnou instanci `FnMut`, kde se očekává [`FnOnce`], a protože [`Fn`] je subtrait `FnMut`, lze použít libovolnou instanci [`Fn`], kde se očekává `FnMut`.
///
/// Použijte `FnMut` jako vázaný, pokud chcete přijmout parametr funkčního typu a potřebujete jej opakovaně volat a zároveň mu umožnit mutovat stav.
/// Pokud nechcete, aby parametr mutoval stav, použijte [`Fn`] jako vázaný;pokud jej nemusíte opakovaně volat, použijte [`FnOnce`].
///
/// Další informace o tomto tématu najdete v [chapter on closures in *The Rust Programming Language*][book].
///
/// Za zmínku stojí také speciální syntaxe pro `Fn` traits (např
/// `Fn(usize, bool) -> použití`).Zájemci o technické podrobnosti mohou odkazovat na [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Volání proměnlivě zachycujícího uzávěru
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Pomocí parametru `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // aby se regex mohl spolehnout na `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Provede operaci hovoru.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Verze operátora volání, který přijímá přijímač podle hodnoty.
///
/// Instance `FnOnce` lze volat, ale nemusí být možné volat vícekrát.Z tohoto důvodu, pokud je o typu známo pouze to, že implementuje `FnOnce`, lze jej volat pouze jednou.
///
/// `FnOnce` je implementováno automaticky uzávěry, které mohou spotřebovat zachycené proměnné, stejně jako všechny typy, které implementují [`FnMut`], např. (safe) [function pointers] (protože `FnOnce` je supertrait [`FnMut`]).
///
///
/// Protože jak [`Fn`], tak [`FnMut`] jsou subtrity `FnOnce`, lze použít libovolnou instanci [`Fn`] nebo [`FnMut`], kde se očekává `FnOnce`.
///
/// Použijte `FnOnce` jako vazbu, když chcete přijmout parametr funkčního typu a stačí jej zavolat pouze jednou.
/// Pokud potřebujete opakovaně volat parametr, použijte [`FnMut`] jako vázaný;pokud také potřebujete, aby nemutoval stav, použijte [`Fn`].
///
/// Další informace o tomto tématu najdete v [chapter on closures in *The Rust Programming Language*][book].
///
/// Za zmínku stojí také speciální syntaxe pro `Fn` traits (např
/// `Fn(usize, bool) -> použití`).Zájemci o technické podrobnosti mohou odkazovat na [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Pomocí parametru `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` spotřebovává své zachycené proměnné, takže ji nelze spustit více než jednou.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Pokus o opětovné vyvolání `func()` způsobí chybu `use of moved value` pro `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` v tomto okamžiku již nelze vyvolat
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // aby se regex mohl spolehnout na `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Vrácený typ po použití operátoru volání.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Provede operaci hovoru.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}