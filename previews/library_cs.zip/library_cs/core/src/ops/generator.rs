use crate::marker::Unpin;
use crate::pin::Pin;

/// Výsledek obnovení generátoru.
///
/// Tento výčet je vrácen z metody `Generator::resume` a označuje možné návratové hodnoty generátoru.
/// V současné době to odpovídá buď závěsnému bodu (`Yielded`), nebo koncovému bodu (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Generátor pozastaven s hodnotou.
    ///
    /// Tento stav označuje, že generátor byl pozastaven, a obvykle odpovídá příkazu `yield`.
    /// Hodnota poskytovaná v této variantě odpovídá výrazu předanému `yield` a umožňuje generátorům poskytnout hodnotu pokaždé, když se objeví.
    ///
    ///
    Yielded(Y),

    /// Generátor je doplněn návratovou hodnotou.
    ///
    /// Tento stav označuje, že generátor dokončil provádění s poskytnutou hodnotou.
    /// Jakmile generátor vrátil `Complete`, považuje se za chybu programátoru opětovné volání `resume`.
    ///
    Complete(R),
}

/// trait implementovaný vestavěnými typy generátorů.
///
/// Generátory, také běžně označované jako coutiny, jsou v současné době experimentální funkcí jazyka Rust.
/// Přidané do generátorů [RFC 2033] jsou v současné době určeny především k poskytnutí stavebního bloku pro syntaxi async/await, ale pravděpodobně se rozšíří i na poskytnutí ergonomické definice pro iterátory a další primitiva.
///
///
/// Syntaxe a sémantika generátorů je nestabilní a pro stabilizaci bude vyžadovat další RFC.V tuto chvíli je však syntaxe podobná uzavření:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Další dokumentace generátorů najdete v nestabilní knize.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Typ hodnoty, kterou tento generátor poskytuje.
    ///
    /// Tento přidružený typ odpovídá výrazu `yield` a hodnotám, které lze vrátit pokaždé, když generátor získá.
    ///
    /// Například iterátor jako generátor by pravděpodobně měl tento typ jako `T`, přičemž typ je iterován.
    ///
    type Yield;

    /// Typ hodnoty, kterou tento generátor vrací.
    ///
    /// To odpovídá typu vrácenému z generátoru buď s příkazem `return`, nebo implicitně jako poslední výraz literálu generátoru.
    /// Například futures by to použil jako `Result<T, E>`, protože představuje dokončenou future.
    ///
    ///
    type Return;

    /// Obnoví provádění tohoto generátoru.
    ///
    /// Tato funkce obnoví provádění generátoru nebo zahájí provádění, pokud ještě nebylo provedeno.
    /// Toto volání se vrátí zpět do posledního bodu pozastavení generátoru a obnoví provádění od nejnovější `yield`.
    /// Generátor bude pokračovat v provádění, dokud se buď nedostane, nebo se nevrátí, kdy se tato funkce vrátí.
    ///
    /// # Návratová hodnota
    ///
    /// Výčet `GeneratorState` vrácený z této funkce označuje, v jakém stavu je generátor po návratu.
    /// Pokud je vrácena varianta `Yielded`, generátor dosáhl bodu zavěšení a byla získána hodnota.
    /// Generátory v tomto stavu jsou k dispozici pro obnovení později.
    ///
    /// Pokud je `Complete` vrácen, pak generátor zcela skončil s uvedenou hodnotou.Obnovení generátoru je neplatné.
    ///
    /// # Panics
    ///
    /// Tato funkce může panic, pokud je volána poté, co byla dříve vrácena varianta `Complete`.
    /// Zatímco literály generátoru v jazyce jsou při obnovení po `Complete` zaručeny panic, není to zaručeno pro všechny implementace `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}