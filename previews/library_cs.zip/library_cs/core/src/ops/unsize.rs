use crate::marker::Unsize;

/// Trait, který označuje, že se jedná o ukazatel nebo obálku pro jeden, kde lze na pointee provést změnu velikosti.
///
/// Další podrobnosti viz [DST coercion RFC][dst-coerce] a [the nomicon entry on coercion][nomicon-coerce].
///
/// U vestavěných typů ukazatelů budou ukazatele na `T` převedeny na ukazatele na `U`, pokud `T: Unsize<U>` převedením z tenkého ukazatele na tlustý ukazatel.
///
/// U vlastních typů zde funguje donucování vynucením `Foo<T>` na `Foo<U>` za předpokladu, že existuje impl `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Takový impl lze zapsat pouze v případě, že `Foo<T>` má pouze jedno nefantomatické datové pole zahrnující `T`.
/// Pokud je typ tohoto pole `Bar<T>`, musí existovat implementace `CoerceUnsized<Bar<U>> for Bar<T>`.
/// Donucení bude fungovat vynucením pole `Bar<T>` do `Bar<U>` a vyplněním zbývajících polí z `Foo<T>` k vytvoření `Foo<U>`.
/// Tím se efektivně rozbalí na pole ukazatele a vynutí to.
///
/// Obecně platí, že pro inteligentní ukazatele budete implementovat `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` s volitelným `?Sized` vázaným na samotný `T`.
/// U typů obálek, které přímo vkládají `T`, jako `Cell<T>` a `RefCell<T>`, můžete přímo implementovat `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// To umožní, aby donucování typů jako `Cell<Box<T>>` fungovalo.
///
/// [`Unsize`][unsize] se používá k označení typů, které lze vynutit na DST, pokud jsou za ukazateli.Je implementován automaticky kompilátorem.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// To se používá pro bezpečnost objektu, aby se zkontrolovalo, zda lze odeslat typ přijímače metody.
///
/// Příklad implementace trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}