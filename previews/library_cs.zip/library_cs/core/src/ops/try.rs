/// trait pro přizpůsobení chování operátoru `?`.
///
/// Typ implementující `Try` je typ, který má kanonický způsob, jak jej zobrazit z hlediska dichotomie success/failure.
/// Tento trait umožňuje jak extrahovat tyto hodnoty úspěchu nebo selhání z existující instance, tak vytvořit novou instanci z hodnoty úspěchu nebo selhání.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Typ této hodnoty při pohledu na úspěšnou.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Typ této hodnoty při zobrazení jako selhal.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Aplikuje operátor "?".Návrat `Ok(t)` znamená, že provádění by mělo pokračovat normálně a výsledkem `?` je hodnota `t`.
    /// Návrat `Err(e)` znamená, že provedení by mělo branch do nejvnitřnějšího ohraničujícího `catch`, nebo se vrátit z funkce.
    ///
    /// Pokud je vrácen výsledek `Err(e)`, bude hodnota `e` "wrapped" v návratovém typu ohraničujícího oboru (který musí sám implementovat `Try`).
    ///
    /// Konkrétně je vrácena hodnota `X::from_error(From::from(e))`, kde `X` je návratový typ obklopující funkce.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Zabalte chybovou hodnotu, abyste vytvořili složený výsledek.
    /// Například `Result::Err(x)` a `Result::from_error(x)` jsou ekvivalentní.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Zabalením hodnoty OK vytvoříte složený výsledek.
    /// Například `Result::Ok(x)` a `Result::from_ok(x)` jsou ekvivalentní.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}