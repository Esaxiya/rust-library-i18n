//! Přetížitelní operátoři.
//!
//! Implementace těchto traits vám umožňuje přetížit určité operátory.
//!
//! Některé z těchto traits jsou importovány pomocí prelude, takže jsou k dispozici v každém programu Rust.Pouze operátoři podporovaní traits mohou být přetíženi.
//! Například operátor přidání (`+`) může být přetížen prostřednictvím [`Add`] trait, ale protože operátor přiřazení (`=`) nemá žádnou podporu trait, neexistuje žádný způsob přetížení jeho sémantiky.
//! Tento modul navíc neposkytuje žádný mechanismus pro vytváření nových operátorů.
//! Pokud je vyžadováno bezvýsledné přetížení nebo vlastní operátory, měli byste se podívat na makra nebo pluginy kompilátoru, abyste rozšířili syntaxi Rust.
//!
//! Implementace operátoru traits by měla být nepřekvapivá v příslušných kontextech, přičemž je třeba mít na paměti jejich obvyklé významy a [operator precedence].
//! Například při implementaci [`Mul`] by operace měla mít určitou podobnost s násobením (a sdílet očekávané vlastnosti, jako je asociativita).
//!
//! Všimněte si, že operátoři `&&` a `||` zkratují, tj. Hodnotí svůj druhý operand, pouze pokud přispívá k výsledku.Protože toto chování není vymahatelné traits, `&&` a `||` nejsou podporovány jako přetížitelní operátoři.
//!
//! Mnoho operátorů bere své operandy podle hodnoty.V negenerických kontextech zahrnujících vestavěné typy to obvykle není problém.
//! Použití těchto operátorů v obecném kódu však vyžaduje určitou pozornost, pokud je nutné hodnoty znovu použít, na rozdíl od toho, aby je operátoři mohli spotřebovat.Jednou z možností je příležitostně použít [`clone`].
//! Další možností je spoléhat se na příslušné typy, které poskytují další implementace operátorů pro reference.
//! Například pro uživatelem definovaný typ `T`, který má podporovat sčítání, je pravděpodobně dobrý nápad mít `T` i `&T` implementovat traits [`Add<T>`][`Add`] a [`Add<&T>`][`Add`], aby mohl být generický kód psán bez zbytečného klonování.
//!
//!
//! # Examples
//!
//! Tento příklad vytvoří strukturu `Point`, která implementuje [`Add`] a [`Sub`], a poté předvede přidání a odčítání dvou bodů.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Ukázkovou implementaci najdete v dokumentaci ke každému trait.
//!
//! [`Fn`], [`FnMut`] a [`FnOnce`] traits jsou implementovány typy, které lze vyvolat jako funkce.Všimněte si, že [`Fn`] bere `&self`, [`FnMut`] bere `&mut self` a [`FnOnce`] bere `self`.
//! Ty odpovídají třem druhům metod, které lze vyvolat v instanci: call-by-reference, call-by-mutable-reference a call-by-value.
//! Nejběžnějším použitím těchto traits je působit jako hranice funkcí vyšší úrovně, které berou funkce nebo uzávěry jako argumenty.
//!
//! Vezmeme-li [`Fn`] jako parametr:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Vezmeme-li [`FnMut`] jako parametr:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Vezmeme-li [`FnOnce`] jako parametr:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` spotřebovává své zachycené proměnné, takže ji nelze spustit více než jednou
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Pokus o opětovné vyvolání `func()` způsobí chybu `use of moved value` pro `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` v tomto okamžiku již nelze vyvolat
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;