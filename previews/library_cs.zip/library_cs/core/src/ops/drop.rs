/// Vlastní kód v destruktoru.
///
/// Pokud již není potřeba žádná hodnota, spustí Rust "destructor" na tuto hodnotu.
/// Nejběžnějším způsobem, že hodnota již není potřeba, je situace, kdy dojde mimo rozsah.Destruktory mohou stále běžet za jiných okolností, ale zde se zaměříme na rozsah příkladů.
/// Chcete-li se dozvědět některé z těchto dalších případů, přečtěte si část [the reference] o destruktorech.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Tento destruktor se skládá ze dvou komponent:
/// - Volání `Drop::drop` pro tuto hodnotu, pokud je pro tento typ implementován tento speciální `Drop` trait.
/// - Automaticky generovaný "drop glue", který rekurzivně volá destruktory všech polí této hodnoty.
///
/// Protože Rust automaticky volá destruktory všech obsažených polí, nemusíte ve většině případů implementovat `Drop`.
/// Existují ale případy, kdy je to užitečné, například pro typy, které přímo spravují prostředek.
/// Tím prostředkem může být paměť, může to být deskriptor souboru, může to být síťový soket.
/// Jakmile již nebude hodnota tohoto typu použita, měla by "clean up" svůj prostředek uvolnit paměť nebo zavřít soubor nebo soket.
/// Toto je úloha destruktoru, a tedy úloha `Drop::drop`.
///
/// ## Examples
///
/// Chcete-li vidět destruktory v akci, pojďme se podívat na následující program:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust nejprve zavolá `Drop::drop` pro `_x` a poté pro `_x.one` i `_x.two`, což znamená, že jeho spuštěním se vytiskne
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// I když odstraníme implementaci `Drop` pro `HasTwoDrop`, destruktory jeho polí se stále volají.
/// To by mělo za následek
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## `Drop::drop` nemůžete volat sami
///
/// Protože se `Drop::drop` používá k vyčištění hodnoty, může být nebezpečné tuto hodnotu používat po vyvolání metody.
/// Protože `Drop::drop` nepřijímá vlastnictví svého vstupu, Rust zabraňuje zneužití tím, že vám neumožňuje přímo volat `Drop::drop`.
///
/// Jinými slovy, pokud jste se pokusili explicitně zavolat `Drop::drop` ve výše uvedeném příkladu, zobrazí se chyba kompilátoru.
///
/// Pokud byste chtěli explicitně volat destruktor hodnoty, můžete místo toho použít [`mem::drop`].
///
/// [`mem::drop`]: drop
///
/// ## Zrušit objednávku
///
/// Který z našich dvou `HasDrop` však klesá jako první?U struktur je to stejné pořadí, v jakém jsou deklarovány: nejprve `one`, pak `two`.
/// Pokud si to chcete sami vyzkoušet, můžete upravit `HasDrop` výše tak, aby obsahoval některá data, například celé číslo, a poté je použít v `println!` uvnitř `Drop`.
/// Toto chování zaručuje jazyk.
///
/// Na rozdíl od struktur jsou lokální proměnné zrušeny v opačném pořadí:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Tím se vytiskne
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Úplná pravidla najdete v [the reference].
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` a `Drop` jsou exkluzivní
///
/// Nelze implementovat [`Copy`] i `Drop` na stejný typ.Typy, které jsou `Copy`, jsou kompilátorem implicitně duplikovány, takže je velmi těžké předpovědět, kdy a jak často budou destruktory provedeny.
///
/// Tyto typy tedy nemohou mít destruktory.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Spustí destruktor pro tento typ.
    ///
    /// Tato metoda se volá implicitně, když hodnota přejde z rozsahu, a nelze ji volat explicitně (jedná se o chybu kompilátoru [E0040]).
    /// Funkci [`mem::drop`] v prelude však lze použít k volání implementace argumentu `Drop`.
    ///
    /// Když byla tato metoda volána, `self` ještě nebyl uvolněn.
    /// K tomu dojde až po skončení metody.
    /// Pokud tomu tak nebylo, byla by `self` houpající se referencí.
    ///
    /// # Panics
    ///
    /// Vzhledem k tomu, že [`panic!`] bude při odvíjení volat `drop`, jakýkoli [`panic!`] v implementaci `drop` se pravděpodobně přeruší.
    ///
    /// Všimněte si, že i když je tato panics, hodnota je považována za upuštěnou;
    /// nesmíte způsobit opětovné volání `drop`.
    /// Toto je obvykle automaticky zpracováno kompilátorem, ale při použití nebezpečného kódu může někdy nastat neúmyslně, zejména při použití [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}