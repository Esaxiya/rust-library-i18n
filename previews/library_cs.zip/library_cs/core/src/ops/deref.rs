/// Používá se pro neměnné dereferenční operace, jako je `*v`.
///
/// Kromě toho, že je `Deref` používán pro explicitní dereferenční operace s operátorem (unary) `*` v neměnných kontextech, je za mnoha okolností implicitně používán také kompilátorem.
/// Tento mechanismus se nazývá ['`Deref` coercion'][more].
/// V proměnlivých kontextech se používá [`DerefMut`].
///
/// Implementace `Deref` pro inteligentní ukazatele usnadňuje přístup k datům za nimi, a proto implementují `Deref`.
/// Na druhou stranu pravidla týkající se `Deref` a [`DerefMut`] byla navržena speciálně pro přizpůsobení inteligentním ukazatelům.
/// Z tohoto důvodu by měl být **`Deref` implementován pouze pro inteligentní ukazatele**, aby nedošlo k záměně.
///
/// Z podobných důvodů by **tento trait neměl nikdy selhat**.Selhání během dereferencování může být extrémně matoucí, když je implicitně vyvolána `Deref`.
///
/// # Více o nátlaku `Deref`
///
/// Pokud `T` implementuje `Deref<Target = U>` a `x` je hodnota typu `T`, pak:
///
/// * V neměnných kontextech je `*x` (kde `T` není ani odkaz, ani surový ukazatel) ekvivalentní `* Deref::deref(&x)`.
/// * Hodnoty typu `&T` jsou převedeny na hodnoty typu `&U`
/// * `T` implicitně implementuje všechny metody (immutable) typu `U`.
///
/// Další informace najdete v [the chapter in *The Rust Programming Language*][book] a v referenčních částech [the dereference operator][ref-deref-op], [method resolution] a [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Struktura s jediným polem, které je přístupné dereferencí struktury.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Výsledný typ po dereferencování.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Oddělí hodnotu.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Používá se pro proměnlivé dereferenční operace, jako v `*v = 1;`.
///
/// Kromě toho, že je `DerefMut` používán pro explicitní dereferenční operace s operátorem (unary) `*` v proměnlivých kontextech, je za mnoha okolností implicitně používán také kompilátorem.
/// Tento mechanismus se nazývá ['`Deref` coercion'][more].
/// V neměnných kontextech se používá [`Deref`].
///
/// Implementace `DerefMut` pro inteligentní ukazatele usnadňuje mutaci dat za nimi, a proto implementují `DerefMut`.
/// Na druhou stranu pravidla týkající se [`Deref`] a `DerefMut` byla navržena speciálně pro přizpůsobení inteligentním ukazatelům.
/// Z tohoto důvodu by měl být **`DerefMut` implementován pouze pro inteligentní ukazatele**, aby nedošlo k záměně.
///
/// Z podobných důvodů by **tento trait neměl nikdy selhat**.Selhání během dereferencování může být extrémně matoucí, když je implicitně vyvolána `DerefMut`.
///
/// # Více o nátlaku `Deref`
///
/// Pokud `T` implementuje `DerefMut<Target = U>` a `x` je hodnota typu `T`, pak:
///
/// * V proměnlivých kontextech je `*x` (kde `T` není ani odkaz, ani surový ukazatel) ekvivalentní `* DerefMut::deref_mut(&mut x)`.
/// * Hodnoty typu `&mut T` jsou převedeny na hodnoty typu `&mut U`
/// * `T` implicitně implementuje všechny metody (mutable) typu `U`.
///
/// Další informace najdete v [the chapter in *The Rust Programming Language*][book] a v referenčních částech [the dereference operator][ref-deref-op], [method resolution] a [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Struktura s jediným polem, které je modifikovatelné dereferencí struktury.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Hodnota se dereferencuje.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Označuje, že strukturu lze použít jako přijímač metody bez funkce `arbitrary_self_types`.
///
/// To je implementováno stdlib typy ukazatelů jako `Box<T>`, `Rc<T>`, `&T` a `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}