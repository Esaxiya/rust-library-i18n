//! Definuje iterátor vlastněný `IntoIter` pro pole.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Vedlejší hodnota [array] iterátor.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Toto je pole, které iterujeme.
    ///
    /// Prvky s indexem `i`, kde `alive.start <= i < alive.end` ještě nebyly získány a jsou platnými položkami pole.
    /// Prvky s indexy `i < alive.start` nebo `i >= alive.end` již byly získány a již k nim nelze přistupovat!Tyto mrtvé prvky mohou být dokonce ve zcela neinicializovaném stavu!
    ///
    ///
    /// Takže invarianty jsou:
    /// - `data[alive]` je naživu (tj. obsahuje platné prvky)
    /// - `data[..alive.start]` a `data[alive.end..]` jsou mrtvé (tj. prvky již byly přečteny a již se jich nesmí dotknout!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Prvky v `data`, které dosud nebyly získány.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Vytvoří nový iterátor nad daným `array`.
    ///
    /// *Poznámka*: tato metoda může být v future po [`IntoIterator` is implemented for arrays][array-into-iter] zastaralá.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Typ `value` je zde `i32`, místo `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // BEZPEČNOST: Přeměna zde je ve skutečnosti bezpečná.Dokumenty `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` je zaručeno, že budou mít stejnou velikost a zarovnání
        // > jako `T`.
        //
        // Dokumenty dokonce ukazují transmutaci z pole `MaybeUninit<T>` do pole `T`.
        //
        //
        // S tím tato inicializace uspokojí invarianty.

        // FIXME(LukasKalbertodt): ve skutečnosti zde použijte `mem::transmute`, jakmile to bude fungovat s generikami const:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Do té doby můžeme pomocí `mem::transmute_copy` vytvořit bitovou kopii jako jiný typ, pak zapomenout na `array`, aby nebyl zrušen.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Vrátí neměnný řez všech prvků, které ještě nebyly získány.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // BEZPEČNOST: Víme, že všechny prvky v `alive` jsou správně inicializovány.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Vrátí proměnlivý výřez všech prvků, které ještě nebyly získány.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // BEZPEČNOST: Víme, že všechny prvky v `alive` jsou správně inicializovány.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Získejte další index zepředu.
        //
        // Zvýšení `alive.start` o 1 udržuje invariant týkající se `alive`.
        // Kvůli této změně však na krátkou dobu živá zóna již není `data[alive]`, ale `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Přečtěte si prvek z pole.
            // BEZPEČNOST: `idx` je index do bývalé oblasti "alive" v
            // pole.Čtení tohoto prvku znamená, že `data[idx]` je nyní považován za mrtvý (tj. Nedotýkejte se).
            // Protože `idx` byl začátkem živé zóny, živá zóna je nyní znovu `data[alive]` a obnovuje všechny invarianty.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Získejte další index zezadu.
        //
        // Snížení `alive.end` o 1 udržuje invariant týkající se `alive`.
        // Kvůli této změně však na krátkou dobu živá zóna již není `data[alive]`, ale `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Přečtěte si prvek z pole.
            // BEZPEČNOST: `idx` je index do bývalé oblasti "alive" v
            // pole.Čtení tohoto prvku znamená, že `data[idx]` je nyní považován za mrtvý (tj. Nedotýkejte se).
            // Protože `idx` byl konec živé zóny, živá zóna je nyní znovu `data[alive]` a obnovuje všechny invarianty.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // BEZPEČNOST: Je to bezpečné: `as_mut_slice` vrací přesně dílčí řez
        // prvků, které ještě nebyly přesunuty a zbývá je zrušit.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Nikdy nebude podtečen kvůli invariantu `alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Iterátor skutečně hlásí správnou délku.
// Počet prvků "alive" (které se stále získají) je délka rozsahu `alive`.
// Délka tohoto rozsahu je zmenšena v `next` nebo `next_back`.
// V těchto metodách je vždy snížena o 1, ale pouze pokud je vrácena hodnota `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Všimněte si, že opravdu nemusíme odpovídat přesně stejnému živému rozsahu, takže můžeme klonovat pouze do offsetu 0 bez ohledu na to, kde je `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Naklonujte všechny živé prvky.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Napište klon do nového pole a poté aktualizujte jeho živý rozsah.
            // Pokud klonujeme panics, správně zrušíme předchozí položky.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Tiskněte pouze prvky, které ještě nebyly získány: k získaným prvkům již nemáme přístup.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}