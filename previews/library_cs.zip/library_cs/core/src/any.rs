//! Tento modul implementuje `Any` trait, který umožňuje dynamické psaní jakéhokoli typu `'static` prostřednictvím běhového odrazu.
//!
//! `Any` sám o sobě může být použit k získání `TypeId` a má více funkcí, když je použit jako objekt trait.
//! Jako `&dyn Any` (vypůjčený objekt trait) má metody `is` a `downcast_ref`, aby otestoval, zda je obsažená hodnota daného typu, a aby získal odkaz na vnitřní hodnotu jako typ.
//! Jako `&mut dyn Any` existuje také metoda `downcast_mut` pro získání proměnlivého odkazu na vnitřní hodnotu.
//! `Box<dyn Any>` přidává metodu `downcast`, která se pokouší převést na `Box<T>`.
//! Další informace najdete v dokumentaci k [`Box`].
//!
//! Všimněte si, že `&dyn Any` je omezeno na testování, zda je hodnota zadaného konkrétního typu, a nelze ji použít k testování, zda typ implementuje trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Chytré ukazatele a `dyn Any`
//!
//! Při používání `Any` jako objektu trait, zejména u typů jako `Box<dyn Any>` nebo `Arc<dyn Any>`, je třeba mít na paměti, že pouhé volání hodnoty `.type_id()` na hodnotu vytvoří `TypeId`*kontejneru*, nikoli podkladový objekt trait.
//!
//! Tomu lze zabránit převedením inteligentního ukazatele na `&dyn Any`, který vrátí `TypeId` objektu.
//! Například:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Pravděpodobněji budete chtít toto:
//! let actual_id = (&*boxed).type_id();
//! // ... než tohle:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Zvažte situaci, kdy chceme odhlásit hodnotu předanou funkci.
//! Známe hodnotu, na které pracujeme, implementuje Debug, ale neznáme její konkrétní typ.Chceme věnovat zvláštní pozornost určitým typům: v tomto případě vytisknout délku String hodnot před jejich hodnotou.
//! V době kompilace neznáme konkrétní typ naší hodnoty, takže místo toho musíme použít runtime reflexi.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Funkce protokolování pro jakýkoli typ, který implementuje Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Zkuste převést naši hodnotu na `String`.
//!     // Pokud bude úspěšný, chceme vypsat délku řetězce i jeho hodnotu.
//!     // Pokud ne, je to jiný typ: jednoduše jej vytiskněte bez ozdob.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Tato funkce chce před prací s parametrem odhlásit svůj parametr.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... dělat další práci
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Libovolný trait
///////////////////////////////////////////////////////////////////////////////

/// trait pro emulaci dynamického psaní.
///
/// Většina typů implementuje `Any`.Jakýkoli typ, který obsahuje nestatický odkaz, však není.
/// Další podrobnosti viz [module-level documentation][mod].
///
/// [mod]: crate::any
// Tento trait není nebezpečný, i když se spoléháme na specifika jeho funkce `type_id` jediného impl v nebezpečném kódu (např. `downcast`).Normálně by to byl problém, ale protože jediným implem `Any` je plošná implementace, žádný jiný kód nemůže implementovat `Any`.
//
// Mohli bychom věrohodně učinit tento trait nebezpečným-nezpůsobilo by to rozbití, protože kontrolujeme všechny implementace-ale rozhodli jsme se ne, protože to není skutečně nutné a můžeme uživatele zmást v rozlišení nebezpečných metod traits a nebezpečných (tj. `type_id` by bylo stále bezpečné zavolat, ale pravděpodobně bychom to chtěli označit v dokumentaci).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Získá `TypeId` z `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Metody rozšíření pro libovolné objekty trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Zajistěte, aby výsledek např. Spojení vlákna mohl být vytištěn a tudíž použit s `unwrap`.
// Možná již nebude potřeba, pokud odeslání funguje s upcastingem.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Vrátí `true`, pokud je krabicový typ stejný jako `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Získejte `TypeId` typu, s kterým je tato funkce vytvořena.
        let t = TypeId::of::<T>();

        // Získejte `TypeId` typu v objektu trait (`self`).
        let concrete = self.type_id();

        // Porovnejte oba typy TypeId na rovnosti.
        t == concrete
    }

    /// Vrátí nějaký odkaz na hodnotu v rámečku, pokud je typu `T`, nebo `None`, pokud není.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // BEZPEČNOST: stačí zkontrolovat, zda ukazujeme na správný typ, a můžeme se spolehnout
            // které kontrolují bezpečnost paměti, protože jsme implementovali Any pro všechny typy;nemohou existovat žádné jiné imply, protože by byly v rozporu s našimi impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Vrátí proměnlivý odkaz na hodnotu v rámečku, pokud je typu `T`, nebo `None`, pokud není.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // BEZPEČNOST: stačí zkontrolovat, zda ukazujeme na správný typ, a můžeme se spolehnout
            // které kontrolují bezpečnost paměti, protože jsme implementovali Any pro všechny typy;nemohou existovat žádné jiné imply, protože by byly v rozporu s našimi impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Vpřed na metodu definovanou u typu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Vpřed na metodu definovanou u typu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Vpřed na metodu definovanou u typu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Vpřed na metodu definovanou u typu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Vpřed na metodu definovanou u typu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Vpřed na metodu definovanou u typu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID a jeho metody
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` představuje globálně jedinečný identifikátor typu.
///
/// Každý `TypeId` je neprůhledný objekt, který neumožňuje kontrolu toho, co je uvnitř, ale umožňuje základní operace, jako je klonování, porovnání, tisk a zobrazování.
///
///
/// `TypeId` je aktuálně k dispozici pouze pro typy, které připisují `'static`, ale toto omezení může být v future odstraněno.
///
/// Zatímco `TypeId` implementuje `Hash`, `PartialOrd` a `Ord`, stojí za zmínku, že hodnoty hash a pořadí se u jednotlivých vydání Rust budou lišit.
/// Dejte si pozor na spoléhání se na ně uvnitř vašeho kódu!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Vrátí `TypeId` typu, s nímž byla vytvořena instance této obecné funkce.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Vrátí název typu jako řez řetězce.
///
/// # Note
///
/// Toto je určeno pro diagnostické použití.
/// Přesný obsah a formát vráceného řetězce nejsou specifikovány, kromě toho, že jde o popis nejlepšího úsilí typu.
/// Například mezi řetězce, které `type_name::<Option<String>>()` může vrátit, jsou `"Option<String>"` a `"std::option::Option<std::string::String>"`.
///
///
/// Vrácený řetězec nesmí být považován za jedinečný identifikátor typu, protože více typů se může namapovat na stejný název typu.
/// Podobně neexistuje žádná záruka, že se ve vráceném řetězci objeví všechny části typu: například specifikátory životnosti nejsou aktuálně zahrnuty.
/// Kromě toho se výstup může mezi verzemi kompilátoru měnit.
///
/// Aktuální implementace používá stejnou infrastrukturu jako diagnostika kompilátoru a ladění, ale to není zaručeno.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Vrátí název typu poukázané hodnoty jako řetězcový řez.
/// Toto je stejné jako `type_name::<T>()`, ale lze jej použít tam, kde typ proměnné není snadno dostupný.
///
/// # Note
///
/// Toto je určeno pro diagnostické použití.Přesný obsah a formát řetězce nejsou specifikovány, kromě toho, že jde o nejlepší popis typu.
/// Například `type_name_of_val::<Option<String>>(None)` může vrátit `"Option<String>"` nebo `"std::option::Option<std::string::String>"`, ale ne `"foobar"`.
///
/// Kromě toho se výstup může mezi verzemi kompilátoru měnit.
///
/// Tato funkce nevyřeší objekty trait, což znamená, že `type_name_of_val(&7u32 as &dyn Debug)` může vrátit `"dyn Debug"`, ale ne `"u32"`.
///
/// Název typu by neměl být považován za jedinečný identifikátor typu;
/// více typů může sdílet stejný název typu.
///
/// Aktuální implementace používá stejnou infrastrukturu jako diagnostika kompilátoru a ladění, ale to není zaručeno.
///
/// # Examples
///
/// Vytiskne výchozí typy celých čísel a float.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}