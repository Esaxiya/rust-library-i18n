//! Typy, které připnou data na své místo v paměti.
//!
//! Někdy je užitečné mít objekty, u nichž je zaručeno, že se nebudou hýbat, v tom smyslu, že se jejich umístění v paměti nezmění, a lze se na ně tedy spolehnout.
//! Ukázkovým příkladem takového scénáře by bylo budování samoreferenčních struktur, protože přesunutí objektu s ukazateli na sebe by je zneplatnilo, což by mohlo způsobit nedefinované chování.
//!
//! Na vysoké úrovni [`Pin<P>`] zajišťuje, že pointee jakéhokoli ukazatele typu `P` má stabilní umístění v paměti, což znamená, že jej nelze přesunout jinam a jeho paměť nelze uvolnit, dokud nebude zrušena.Říkáme, že pointee je "pinned".Věci se stanou jemnějšími, když diskutujeme o typech, které kombinují připnutá s nepripnutými daty;[see below](#projections-and-structural-pinning) pro více informací.
//!
//! Ve výchozím nastavení jsou všechny typy v Rust pohyblivé.
//! Rust umožňuje předávání všech typů podle hodnoty a běžné typy inteligentních ukazatelů, jako jsou [`Box<T>`] a `&mut T`, umožňují nahrazovat a přesouvat hodnoty, které obsahují: můžete se přesunout z [`Box<T>`] nebo můžete použít [`mem::swap`].
//! [`Pin<P>`] zabalí ukazatel typu `P`, takže [`Pin`]`<<[[Box`] `<T>>`funguje podobně jako obyčejný
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>>`spadne, stejně tak i jeho obsah a paměť se dostane
//!
//! uvolněno.Podobně je [`Pin`]`<&mut T>`hodně podobný `&mut T`.[`Pin<P>`] však neumožňuje klientům skutečně získat [`Box<T>`] nebo `&mut T` k připnutým datům, což znamená, že nemůžete použít operace jako [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` potřebuje `&mut T`, ale nemůžeme to získat.
//!     // Jsme zaseknutí, nemůžeme zaměnit obsah těchto odkazů.
//!     // Mohli bychom použít `Pin::get_unchecked_mut`, ale to je z nějakého důvodu nebezpečné:
//!     // není nám dovoleno jej používat k přemisťování věcí z `Pin`.
//! }
//! ```
//!
//! Stojí za to zopakovat, že [`Pin<P>`] nezmění *skutečnost, že kompilátor Rust považuje všechny typy za pohyblivé.[`mem::swap`] zůstává volatelný pro jakýkoli `T`.Místo toho [`Pin<P>`] zabraňuje přesunutí určitých* hodnot * (na které ukazují ukazatele zabalené v [`Pin<P>`]) tím, že znemožňuje volání metod, které na nich vyžadují `&mut T` (jako [`mem::swap`]).
//!
//! [`Pin<P>`] lze použít k zabalení libovolného typu ukazatele `P` a jako takový interaguje s [`Deref`] a [`DerefMut`].[`Pin<P>`], kde `P: Deref` by měl být považován za "`P`-style pointer" k připnutému `P::Target`-tedy, [`Pin`]`<`[`Box`] `<T>>`je vlastněný ukazatel na připnutý `T` a [`Pin`] `<<[[Rc`]`<T>>`je ukazatel počítaný jako odkaz na připnutý `T`.
//! Pro správnost se [`Pin<P>`] spoléhá na implementace [`Deref`] a [`DerefMut`], aby se nepohnuly ze svého parametru `self`, a pouze kdykoli vrátí ukazatel na připnutá data, když jsou volána na připnutém ukazateli.
//!
//! # `Unpin`
//!
//! Mnoho typů je vždy volně pohyblivých, i když jsou připnuté, protože se nespoléhají na stabilní adresu.To zahrnuje všechny základní typy (jako [`bool`], [`i32`] a reference) i typy skládající se výhradně z těchto typů.Typy, které se nestarají o připnutí, implementují auto [`Unpin`] auto-trait, které ruší účinek [`Pin<P>`].
//! U `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`a [`Box<T>`] fungují shodně, stejně jako [`Pin`] `<&mut T>` a `&mut T`.
//!
//! Všimněte si, že pinning a [`Unpin`] ovlivňují pouze špičatý typ `P::Target`, nikoli samotný typ ukazatele `P`, který byl zabalen do [`Pin<P>`].Například to, zda [`Box<T>`] je či není [`Unpin`], nemá žádný vliv na chování [" Pin`]` <<[[Box`]`<T>> `` (zde `T` je špičatý typ).
//!
//! # Příklad: samoreferenční struktura
//!
//! Než se pustíme do dalších podrobností, abychom vysvětlili záruky a možnosti spojené s `Pin<T>`, probereme několik příkladů, jak by to mohlo být použito.
//! Nebojte se [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Toto je samoreferenční struktura, protože pole řezu ukazuje na datové pole.
//! // O tom nemůžeme informovat kompilátor s běžným odkazem, protože tento vzor nelze popsat obvyklými výpůjčními pravidly.
//! //
//! // Místo toho použijeme surový ukazatel, i když je známo, že není nulový, protože víme, že ukazuje na řetězec.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Abychom zajistili, že se data nebudou vracet, když se funkce vrátí, umístíme je na hromadu, kde zůstanou po celou dobu životnosti objektu, a jediný způsob, jak k nim přistupovat, bude přes ukazatel na něj.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // ukazatel vytváříme pouze tehdy, když jsou data na místě, jinak se již přesunula, než jsme vůbec začali
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // víme, že je to bezpečné, protože úprava pole neposune celou strukturu
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Ukazatel by měl ukazovat na správné umístění, pokud se struktura nepohnula.
//! //
//! // Mezitím můžeme volně pohybovat ukazatelem.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Protože náš typ neimplementuje Unpin, kompilace se nezdaří:
//! // nechat mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Příklad: rušivý dvojitě propojený seznam
//!
//! V rušivém dvojitě propojeném seznamu kolekce ve skutečnosti alokuje paměť pro samotné prvky.
//! Přidělování je řízeno klienty a prvky mohou žít v rámci zásobníku, který žije kratší dobu než kolekce.
//!
//! Aby to fungovalo, má každý prvek v seznamu odkazy na svého předchůdce a nástupce.Elements can be added when they are pinned, because moving the elements around would invalidate the pointers.Implementace [`Drop`] propojeného prvku seznamu navíc opraví ukazatele jeho předchůdce a následníka, aby se odstranil ze seznamu.
//!
//! Rozhodující je, že musíme být schopni spoléhat se na to, že [`drop`] je volán.Pokud by mohl být prvek uvolněn nebo jinak zneplatněn bez volání [`drop`], ukazatele do něj ze sousedních prvků by se staly neplatnými, což by narušilo datovou strukturu.
//!
//! Proto připnutí také přichází s [související] zárukou.
//!
//! # `Drop` guarantee
//!
//! Účelem připnutí je schopnost spoléhat se na umístění některých dat do paměti.
//! Aby to fungovalo, je omezeno nejen přesouvání dat;omezeno je také uvolnění, opětovné použití nebo jiné zneplatnění paměti použité k ukládání dat.
//! Konkrétně pro připnutá data musíte zachovat invariant, že *jeho paměť nebude znehodnocena nebo přepracována od okamžiku, kdy bude připnuta, dokud nebude volána [`drop`]*.Pouze jednou se vrátí [`drop`] nebo panics, paměť může být znovu použita.
//!
//! Paměť může být "invalidated" přidělením, ale také nahrazením [`Some(v)`] [`None`] nebo voláním [`Vec::set_len`] na "kill" některé prvky ze vector.Může být přepracován pomocí [`ptr::write`] k jeho přepsání, aniž by bylo nutné nejprve volat destruktor.Nic z toho není povoleno pro připnutá data bez volání [`drop`].
//!
//! To je přesně ten druh záruky, že rušivý propojený seznam z předchozí části musí správně fungovat.
//!
//! Všimněte si, že tato záruka *neznamená*, že nedochází k úniku paměti!Stále je naprosto v pořádku nikdy nevolat [`drop`] na připnutém prvku (např. Stále můžete volat [`mem::forget`] na [" Pin`]` <`[` Box`]`<T>> `).V příkladu dvojnásobně propojeného seznamu by tento prvek zůstal v seznamu.Možná však nebudete muset uvolnit nebo znovu použít úložiště *bez volání [" drop`]*.
//!
//! # `Drop` implementation
//!
//! Pokud váš typ používá připnutí (například dva výše uvedené příklady), musíte být při implementaci [`Drop`] opatrní.Funkce [`drop`] přebírá `&mut self`, ale toto se nazývá *, i když byl váš typ dříve připnutý*!Je to, jako by překladač automaticky volal [`Pin::get_unchecked_mut`].
//!
//! To nikdy nemůže způsobit problém v bezpečném kódu, protože implementace typu, který spoléhá na připnutí, vyžaduje nebezpečný kód, ale mějte na paměti, že rozhodování o použití připnutí ve vašem typu (například implementací nějaké operace na [`Pin`]`<&Self>`nebo [`Pin`] `<&mut Self>`) má důsledky i pro vaši implementaci [`Drop`]: pokud mohl být připnut prvek vašeho typu, musíte s [`Drop`] zacházet jako s implicitním převzetím [`Pin`]`<&mut Já>`.
//!
//!
//! Například můžete implementovat `Drop` následujícím způsobem:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` je v pořádku, protože víme, že tato hodnota se po upuštění nikdy nepoužije.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Skutečný drop kód jde sem.
//!         }
//!     }
//! }
//! ```
//!
//! Funkce `inner_drop` má typ, který by měl mít [`drop`] *, takže je zajištěno, že nepoužíváte náhodně `self`/`this` způsobem, který je v rozporu s pinningem.
//!
//! Navíc, pokud je váš typ `#[repr(packed)]`, kompilátor automaticky přesune pole, aby je mohl zahodit.Mohlo by to dokonce udělat pro pole, která jsou náhodou dostatečně zarovnaná.V důsledku toho nelze použít připnutí u typu `#[repr(packed)]`.
//!
//! # Projekce a strukturální připnutí
//!
//! Při práci s připnutými strukturami vyvstává otázka, jak lze přistupovat k polím této struktury v metodě, která trvá pouze [`Pin`]`<&mut Struct>`.
//! Obvyklým přístupem je psát pomocné metody (tzv.*Projekce*), které promění [`Pin`]`<&mut Struct>`na odkaz na pole, ale jaký typ by měl mít tento odkaz?Je to [`Pin`]`<&mut Field>`nebo `&mut Field`?
//! Stejná otázka vyvstává u polí `enum` a také při zvažování typů container/wrapper, jako jsou [`Vec<T>`], [`Box<T>`] nebo [`RefCell<T>`].
//! (Tato otázka se týká jak proměnlivých, tak sdílených odkazů, pro ilustraci používáme častější případ proměnlivých odkazů.)
//!
//! Ukazuje se, že je ve skutečnosti na autorovi datové struktury, aby rozhodl, zda se připnutá projekce pro konkrétní pole změní z [" Pin`]` <&mut Struct> `na [" Pin`] `<&mut Field>` nebo `&mut Field`.Existují však určitá omezení a nejdůležitější omezení je *konzistence*:
//! každé pole lze *buď* promítnout na připnutou referenci,*nebo* nechat připnutí odstranit jako součást projekce.
//! Pokud jsou oba provedeny pro stejné pole, bude to pravděpodobně nevhodné!
//!
//! Jako autor datové struktury se pro každé pole rozhodnete, zda k tomuto poli připnete "propagates" nebo ne.
//! Připnutí, které se šíří, se také nazývá "structural", protože sleduje strukturu typu.
//! V následujících podkapitolách popisujeme úvahy, které je třeba provést pro každou z možností.
//!
//! ## Připnutí *není* strukturální pro `field`
//!
//! Může se zdát protiintuitivní, že pole připnuté struktury nemusí být připnuté, ale to je ve skutečnosti nejjednodušší volba: pokud nikdy nebude vytvořen [" Pin`]` <&mut Field>, nic se nemůže pokazit!Pokud se tedy rozhodnete, že některé pole nemá strukturální připnutí, musíte zajistit, že nikdy nevytvoříte připnutý odkaz na toto pole.
//!
//! Pole bez strukturálního připnutí mohou mít metodu projekce, která změní ["Pin"] <<&mut Struct> `na `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // To je v pořádku, protože `field` se nikdy nepovažuje za připnutý.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Můžete také `impl Unpin for Struct`*, i když* typ `field` není [`Unpin`].To, co si tento typ myslí o připnutí, není relevantní, když nikdy není vytvořen [" Pin`]` <&mut Field>.
//!
//! ## Připnutí *je* strukturální pro `field`
//!
//! Druhou možností je rozhodnout, že připnutí je "structural" pro `field`, což znamená, že pokud je struktura připnutá, pak také pole.
//!
//! To umožňuje psát projekci, která vytvoří [`Pin`]`<&mut Field>`, což bude svědkem toho, že pole je připnuté:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // To je v pořádku, protože `field` je připnutý, když je `self`.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Připevnění struktury však přichází s několika dalšími požadavky:
//!
//! 1. Struktura musí být pouze [`Unpin`], pokud jsou všechna strukturální pole [`Unpin`].Toto je výchozí nastavení, ale [`Unpin`] je bezpečný trait, takže jako autor struktury je vaší odpovědností *ne* přidat něco jako `impl<T> Unpin for Struct<T>`.
//! (Všimněte si, že přidání operace projekce vyžaduje nebezpečný kód, takže skutečnost, že [`Unpin`] je bezpečná trait, neporušuje zásadu, že si musíte dělat starosti s čímkoli, pokud používáte `nebezpečný`.)
//! 2. Destruktor struktury nesmí přesunout strukturní pole ze svého argumentu.Toto je přesný bod, který byl vznesen v [previous section][drop-impl]: `drop` trvá `&mut self`, ale struktura (a tedy jeho pole) mohla být připnuta dříve.
//!     Musíte zaručit, že ve své implementaci [`Drop`] nepřesunete pole.
//!     Zejména, jak již bylo vysvětleno dříve, to znamená, že vaše struktura *nesmí* být `#[repr(packed)]`.
//!     V této části se dozvíte, jak psát [`drop`] způsobem, který vám kompilátor pomůže, abyste náhodou nepřerušili připnutí.
//! 3. Musíte se ujistit, že držíte [`Drop` guarantee][drop-guarantee]:
//!     jakmile je vaše struktura připnutá, paměť obsahující obsah není přepsána nebo uvolněna bez volání destruktorů obsahu.
//!     To může být složité, jak dokazuje [`VecDeque<T>`]: destruktor [`VecDeque<T>`] může selhat při volání [`drop`] na všech prvcích, pokud jeden z destruktorů panics.To porušuje záruku [`Drop`], protože to může vést k uvolnění prvků bez volání jejich destruktoru.([`VecDeque<T>`] nemá žádné připevněné projekce, takže to nezpůsobuje nepříjemnosti.)
//! 4. Nesmíte nabízet žádné další operace, které by mohly vést k přesunutí dat ze strukturních polí, když je váš typ připnutý.Například pokud struktura obsahuje [`Option<T>`] a existuje operace typu " take` s typem `fn(Pin<&mut Struct<T>>) -> Option<T>`, lze tuto operaci použít k přesunutí `T` z připojeného `Struct<T>`-což znamená, že připnutí nemůže být strukturální pro pole, které to drží data.
//!
//!     U složitějšího příkladu přesunu dat mimo připnutý typ si představte, jestli [`RefCell<T>`] měl metodu `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Pak bychom mohli udělat následující:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     To je katastrofické, to znamená, že můžeme nejprve připnout obsah [`RefCell<T>`] (pomocí `RefCell::get_pin_mut`) a poté tento obsah přesunout pomocí proměnlivého odkazu, který jsme dostali později.
//!
//! ## Examples
//!
//! U typu jako [`Vec<T>`] mají obě možnosti (strukturální připnutí nebo ne) smysl.
//! [`Vec<T>`] se strukturálním připínáním může mít metody `get_pin`/`get_pin_mut` k získání připnutých odkazů na prvky.Mohlo by to však *ne* povolit volání [`pop`][Vec::pop] na připnutém [`Vec<T>`], protože by to posunulo (strukturálně připnutý) obsah!Také by to nemohlo dovolit [`push`][Vec::push], který by mohl přerozdělit a tím také přesunout obsah.
//!
//! [`Vec<T>`] bez strukturálního připnutí by mohl `impl<T> Unpin for Vec<T>`, protože obsah není nikdy připnutý a samotný [`Vec<T>`] je v pohodě i s přesunem.
//! V tomto okamžiku nemá připnutí vůbec žádný vliv na vector.
//!
//! Ve standardní knihovně typy ukazatelů obecně nemají strukturální připnutí, a proto nenabízejí projekce připnutí.Proto platí `Box<T>: Unpin` pro všechny `T`.
//! Dává to smysl pro typy ukazatelů, protože pohyb `Box<T>` ve skutečnosti nepohybuje `T`: [`Box<T>`] může být volně pohyblivý (aka `Unpin`), i když `T` není.Ve skutečnosti dokonce i [`Pin`]`<`[`Box`] `<T>>`a [`Pin`] `<&mut T>` jsou vždy [`Unpin`] samy, ze stejného důvodu: jejich obsah (`T`) je připnutý, ale samotné ukazatele lze přesouvat bez přesunu připnutých dat.
//! Pro [`Box<T>`] i [`Pin`]`<`[`Box`] `<T>>`, zda je obsah připnut, je zcela nezávislý na tom, zda je připnutý ukazatel, což znamená, že připnutí není * strukturální.
//!
//! Při implementaci kombinátoru [`Future`] budete obvykle potřebovat strukturované připnutí pro vnořené futures, protože k tomu, abyste mohli volat [`poll`], musíte k nim získat připnuté odkazy.
//! Pokud ale váš kombinátor obsahuje jakákoli další data, která nemusí být připnuta, můžete tato pole učinit ne strukturálními, a tedy k nim volně přistupovat s proměnlivým odkazem, i když právě máte [`Pin`]`<&mut Self>`(takový jako ve vaší vlastní implementaci [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Připnutý ukazatel.
///
/// Jedná se o obal kolem druhu ukazatele, díky kterému je tento ukazatel "pin" svou hodnotou na místě, což brání v přesunutí hodnoty odkazované tímto ukazatelem, pokud neimplementuje [`Unpin`].
///
///
/// *Vysvětlení připnutí naleznete v dokumentaci [`pin` module].*
///
/// [`pin` module]: self
///
// Note: níže odvozený `Clone` způsobuje nepříjemnost, protože je možné jej implementovat
// `Clone` pro proměnlivé odkazy.
// Další podrobnosti viz <https://internals.rust-lang.org/t/unsoundness-in-pin/11311>.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Následující implementace nejsou odvozeny, aby se předešlo problémům se zdravostí.
// `&self.pointer` by neměly být přístupné nedůvěryhodným implementacím trait.
//
// Další podrobnosti viz <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73>.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Vytvořte nový `Pin<P>` kolem ukazatele na některá data typu, který implementuje [`Unpin`].
    ///
    /// Na rozdíl od `Pin::new_unchecked` je tato metoda bezpečná, protože ukazatel `P` dereferences na typ [`Unpin`], který ruší záruky připnutí.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // BEZPEČNOST: poukázaná hodnota je `Unpin`, a proto nemá žádné požadavky
        // kolem připnutí.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Rozbalí tento `Pin<P>` a vrací podkladový ukazatel.
    ///
    /// To vyžaduje, aby data uvnitř tohoto `Pin` byla [`Unpin`], abychom mohli při rozbalování ignorovat připínací invarianty.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Vytvořte nový `Pin<P>` kolem odkazu na některá data typu, který může nebo nemusí implementovat `Unpin`.
    ///
    /// Pokud `pointer` dereferuje na typ `Unpin`, měla by se místo toho použít `Pin::new`.
    ///
    /// # Safety
    ///
    /// Tento konstruktor je nebezpečný, protože nemůžeme zaručit, že data, na která `pointer` ukazuje, jsou připnutá, což znamená, že data nebudou přesunuta nebo bude jejich úložiště znehodnoceno, dokud nebude zrušeno.
    /// Pokud vytvořená `Pin<P>` nezaručuje, že data, na která `P` odkazuje, jsou připnutá, jedná se o porušení smlouvy API a může vést k nedefinovanému chování v pozdějších operacích (safe).
    ///
    /// Použitím této metody vytváříte promise o implementacích `P::Deref` a `P::DerefMut`, pokud existují.
    /// Nejdůležitější je, že se nesmí přesunout ze svých argumentů `self`: `Pin::as_mut` a `Pin::as_ref` zavolá `DerefMut::deref_mut` a `Deref::deref`*na připnutém ukazateli* a očekávají, že tyto metody obhájí připínací invarianty.
    /// Navíc voláním této metody promise, že referenční dereference `P` nebude znovu přesunuta;zejména nesmí být možné získat `&mut P::Target` a poté se z této reference přesunout (například pomocí [`mem::swap`]).
    ///
    ///
    /// Například volání `Pin::new_unchecked` na `&'a mut T` je nebezpečné, protože zatímco jej můžete připnout pro danou dobu životnosti `'a`, nemáte žádnou kontrolu nad tím, zda se bude udržovat připnutý, jakmile `'a` skončí:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // To by mělo znamenat, že pointee `a` se už nikdy nemůže pohnout.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Adresa `a` se změnila na slot zásobníku `b`, takže `a` se přesunul, i když jsme ji dříve připnuli!Porušili jsme smlouvu o připnutí API.
    /////
    /// }
    /// ```
    ///
    /// Hodnota, jakmile je jednou připnuta, musí zůstat navždy připnutá (pokud její typ neimplementuje `Unpin`).
    ///
    /// Podobně volání `Pin::new_unchecked` na `Rc<T>` je nebezpečné, protože by mohla existovat aliasy stejných dat, na která se nevztahují omezení připnutí:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // To by mělo znamenat, že pointee se už nikdy nemůže pohnout.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Nyní, pokud byla `x` jedinou referencí, máme proměnlivý odkaz na data, která jsme připnuli výše, a kterou jsme mohli použít k přesunutí, jak jsme viděli v předchozím příkladu.
    ///     // Porušili jsme smlouvu o připnutí API.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Získá připnutý sdílený odkaz z tohoto připnutého ukazatele.
    ///
    /// Toto je obecná metoda přechodu z `&Pin<Pointer<T>>` na `Pin<&T>`.
    /// Je to bezpečné, protože jako součást smlouvy `Pin::new_unchecked` se pointee nemůže po vytvoření `Pin<Pointer<T>>` pohnout.
    ///
    /// "Malicious" implementace `Pointer::Deref` jsou rovněž vyloučeny ze smlouvy `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // BEZPEČNOST: viz dokumentace k této funkci
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Rozbalí tento `Pin<P>` a vrací podkladový ukazatel.
    ///
    /// # Safety
    ///
    /// Tato funkce není bezpečná.Musíte zaručit, že po volání této funkce budete i nadále považovat ukazatel `P` za připnutý, aby bylo možné potvrdit invarianty typu `Pin`.
    /// Pokud kód využívající výsledný `P` nepokračuje v udržování připnutí invarianty, což je porušení smlouvy API a může vést k nedefinovanému chování v pozdějších operacích (safe).
    ///
    ///
    /// Pokud jsou podkladová data [`Unpin`], měla by se místo nich použít [`Pin::into_inner`].
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Získá připnutou proměnlivou referenci z tohoto připnutého ukazatele.
    ///
    /// Toto je obecná metoda přechodu z `&mut Pin<Pointer<T>>` na `Pin<&mut T>`.
    /// Je to bezpečné, protože jako součást smlouvy `Pin::new_unchecked` se pointee nemůže po vytvoření `Pin<Pointer<T>>` pohnout.
    ///
    /// "Malicious" implementace `Pointer::DerefMut` jsou rovněž vyloučeny ze smlouvy `Pin::new_unchecked`.
    ///
    /// Tato metoda je užitečná, když provádíte více volání funkcí, které využívají připnutý typ.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // dělej něco
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` spotřebovává `self`, takže znovu vypěstujte `Pin<&mut Self>` přes `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // BEZPEČNOST: viz dokumentace k této funkci
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Přiřadí novou hodnotu paměti za připnutým odkazem.
    ///
    /// To přepíše připnutá data, ale to je v pořádku: jeho destruktor se spustí před přepsáním, takže není porušena žádná záruka připnutí.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Vytvoří nový kolík mapováním hodnoty interiéru.
    ///
    /// Například pokud jste chtěli získat `Pin` pole něčeho, můžete to použít k získání přístupu k tomuto poli v jednom řádku kódu.
    /// S těmito "pinning projections" však existuje několik gotchas;
    /// v dokumentaci [`pin` module] najdete další podrobnosti k tomuto tématu.
    ///
    /// # Safety
    ///
    /// Tato funkce není bezpečná.
    /// Musíte zaručit, že data, která vrátíte, se nebudou pohybovat, dokud se hodnota argumentu nepohybuje (například proto, že je to jedno z polí této hodnoty), a také, že se nepohnete z argumentu, který obdržíte funkce interiéru.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // BEZPEČNOST: bezpečnostní smlouva pro `new_unchecked` musí být
        // potvrzuje volající.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Získá sdílenou referenci z kolíku.
    ///
    /// To je bezpečné, protože není možné přesunout se ze sdílené reference.
    /// Může se zdát, že zde existuje problém s měnitelností interiéru: ve skutečnosti je *možné* přesunout `T` z `&RefCell<T>`.
    /// To však není problém, pokud také neexistuje `Pin<&T>` ukazující na stejná data a `RefCell<T>` vám nedovolí vytvořit připnutý odkaz na jeho obsah.
    ///
    /// Další podrobnosti najdete v diskusi o ["pinning projections"].
    ///
    /// Note: `Pin` také implementuje `Deref` do cíle, který lze použít pro přístup k vnitřní hodnotě.
    /// `Deref` však poskytuje pouze referenci, která žije po celou dobu výpůjčky `Pin`, nikoli po dobu životnosti samotného `Pin`.
    /// Tato metoda umožňuje přeměnit `Pin` na referenci se stejnou životností jako původní `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Převádí tento `Pin<&mut T>` na `Pin<&T>` se stejnou životností.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Získá proměnlivý odkaz na data uvnitř tohoto `Pin`.
    ///
    /// To vyžaduje, aby data uvnitř tohoto `Pin` byla `Unpin`.
    ///
    /// Note: `Pin` také implementuje `DerefMut` do dat, která lze použít pro přístup k vnitřní hodnotě.
    /// `DerefMut` však poskytuje pouze referenci, která žije po celou dobu výpůjčky `Pin`, nikoli po dobu životnosti samotného `Pin`.
    ///
    /// Tato metoda umožňuje přeměnit `Pin` na referenci se stejnou životností jako původní `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Získá proměnlivý odkaz na data uvnitř tohoto `Pin`.
    ///
    /// # Safety
    ///
    /// Tato funkce není bezpečná.
    /// Musíte zaručit, že nikdy nepřesunete data z proměnlivého odkazu, který obdržíte při volání této funkce, aby bylo možné potvrdit invarianty u typu `Pin`.
    ///
    ///
    /// Pokud jsou podkladová data `Unpin`, měla by se místo nich použít `Pin::get_mut`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Vytvořte nový čep mapováním hodnoty interiéru.
    ///
    /// Například pokud jste chtěli získat `Pin` pole něčeho, můžete to použít k získání přístupu k tomuto poli v jednom řádku kódu.
    /// S těmito "pinning projections" však existuje několik gotchas;
    /// v dokumentaci [`pin` module] najdete další podrobnosti k tomuto tématu.
    ///
    /// # Safety
    ///
    /// Tato funkce není bezpečná.
    /// Musíte zaručit, že data, která vrátíte, se nebudou pohybovat, dokud se hodnota argumentu nepohybuje (například proto, že je to jedno z polí této hodnoty), a také, že se nepohnete z argumentu, který obdržíte funkce interiéru.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // BEZPEČNOST: volající je odpovědný za to, že nepohybuje
        // hodnota z této reference.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // BEZPEČNOST: protože hodnota `this` zaručeně nebude mít
        // byl přesunut, je toto volání `new_unchecked` bezpečné.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Získejte připnutou referenci ze statické reference.
    ///
    /// To je bezpečné, protože `T` je vypůjčený na dobu životnosti `'static`, která nikdy nekončí.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // BEZPEČNOST: " Statická výpůjčka zaručuje, že data nebudou
        // moved/invalidated dokud neklesne (což nikdy není).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Získejte připnutou proměnlivou referenci ze statické proměnlivé reference.
    ///
    /// To je bezpečné, protože `T` je vypůjčený na dobu životnosti `'static`, která nikdy nekončí.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // BEZPEČNOST: " Statická výpůjčka zaručuje, že data nebudou
        // moved/invalidated dokud neklesne (což nikdy není).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: to znamená, že jakýkoli impl `CoerceUnsized`, který umožňuje vynucení z
// typ, který implikuje `Deref<Target=impl !Unpin>` na typ, který implikuje `Deref<Target=Unpin>`, je nezvukový.
// Jakýkoli takový impl by byl pravděpodobně nezdravý z jiných důvodů, takže musíme dávat pozor, abychom nedovolili, aby takové imply přistály v std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}