//! Modul pro práci s vypůjčenými daty.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait pro výpůjční data.
///
/// V Rust je běžné poskytnout různé reprezentace typu pro různé případy použití.
/// Například umístění úložiště a správu pro hodnotu lze konkrétně zvolit jako vhodné pro konkrétní použití prostřednictvím typů ukazatelů, jako je [`Box<T>`] nebo [`Rc<T>`].
/// Kromě těchto obecných obalů, které lze použít s jakýmkoli typem, poskytují některé typy volitelné fazety poskytující potenciálně nákladné funkce.
/// Příkladem takového typu je [`String`], který přidává schopnost rozšířit řetězec na základní [`str`].
/// To vyžaduje udržování dalších informací nepotřebných pro jednoduchý, neměnný řetězec.
///
/// Tyto typy poskytují přístup k podkladovým datům prostřednictvím odkazů na typ těchto dat.Říká se, že jsou " vypůjčeny jako` tohoto typu.
/// Například [`Box<T>`] si můžete vypůjčit jako `T`, zatímco [`String`] si můžete vypůjčit jako `str`.
///
/// Typy vyjadřují, že si je lze vypůjčit jako nějaký typ `T` implementací `Borrow<T>`, poskytnutím odkazu na `T` v metodě [`borrow`] trait.Typ si můžete půjčit zdarma v několika různých typech.
/// Pokud si chce jako typ měnitelně půjčit-což umožňuje úpravu podkladových dat, může dodatečně implementovat [`BorrowMut<T>`].
///
/// Při poskytování implementací pro další traits je dále třeba zvážit, zda by se měly chovat shodně s těmi základního typu v důsledku působení jako reprezentace tohoto základního typu.
/// Obecný kód obvykle používá `Borrow<T>`, když se spoléhá na stejné chování těchto dalších implementací trait.
/// Tyto traits se pravděpodobně objeví jako další trait bounds.
///
/// Zejména `Eq`, `Ord` a `Hash` musí být ekvivalentní pro vypůjčené a vlastněné hodnoty: `x.borrow() == y.borrow()` by měl poskytnout stejný výsledek jako `x == y`.
///
/// Pokud obecný kód pouze potřebuje pracovat pro všechny typy, které mohou poskytnout odkaz na související typ `T`, je často lepší použít [`AsRef<T>`], protože jej může bezpečně implementovat více typů.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Jako sběr dat vlastní [`HashMap<K, V>`] klíče i hodnoty.Pokud jsou skutečná data klíče zabalena do nějakého druhu správy, mělo by být stále možné vyhledat hodnotu pomocí odkazu na data klíče.
/// Například pokud je klíčem řetězec, je pravděpodobně uložen s hashovací mapou jako [`String`], zatímco by mělo být možné vyhledávat pomocí [`&str`][`str`].
/// `insert` tedy musí pracovat na `String`, zatímco `get` musí být schopen používat `&str`.
///
/// Mírně zjednodušené, příslušné části `HashMap<K, V>` vypadají takto:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // pole vynechána
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Celá hash mapa je obecná nad typem klíče `K`.Protože jsou tyto klíče uloženy s hashovací mapou, musí tento typ vlastnit data klíče.
/// Při vkládání páru klíč-hodnota je mapě dán takový `K` a musí najít správný hash kbelík a zkontrolovat, zda je klíč již na základě tohoto `K` přítomen.Vyžaduje tedy `K: Hash + Eq`.
///
/// Při hledání hodnoty na mapě by však vyžadování odkazu na `K` jako klíče k hledání vyžadovalo vždy vytvořit takovou vlastněnou hodnotu.
/// U řetězcových klíčů by to znamenalo, že je třeba vytvořit hodnotu `String` pouze pro hledání případů, kdy je k dispozici pouze `str`.
///
/// Místo toho je metoda `get` obecná nad typem podkladových dat klíče, která se v podpisu metody nazývá `Q`.Uvádí, že `K` si půjčuje jako `Q` tím, že požaduje `K: Borrow<Q>`.
/// Tím, že navíc vyžaduje `Q: Hash + Eq`, signalizuje požadavek, aby `K` a `Q` měly implementace `Hash` a `Eq` traits, které produkují identické výsledky.
///
/// Implementace `get` se opírá zejména o identické implementace `Hash` určením hash kbelíku klíče voláním `Hash::hash` na hodnotě `Q`, i když vložil klíč na základě hodnoty hash vypočítané z hodnoty `K`.
///
///
/// V důsledku toho se hashovací mapa rozbije, pokud `K` zabalení hodnoty `Q` vytvoří jiný hash než `Q`.Představte si například, že máte typ, který zalomí řetězec, ale porovná písmena ASCII ignorující jejich velká a malá písmena:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Protože dvě stejné hodnoty musí produkovat stejnou hodnotu hash, implementace `Hash` musí také ignorovat ASCII případ:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Může `CaseInsensitiveString` implementovat `Borrow<str>`?Určitě může poskytnout odkaz na řez řetězce prostřednictvím jeho vlastněného řetězce.
/// Ale protože se jeho implementace `Hash` liší, chová se odlišně od `str`, a proto ve skutečnosti nesmí implementovat `Borrow<str>`.
/// Pokud chce ostatním umožnit přístup k podkladovému `str`, může to udělat prostřednictvím `AsRef<str>`, který nenese žádné další požadavky.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Nezaměnitelně si půjčuje z vlastní hodnoty.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// trait pro proměnlivě výpůjční data.
///
/// Jako společník [`Borrow<T>`] umožňuje tento trait typu vypůjčit si jako podkladový typ poskytnutím proměnlivého odkazu.
/// Další informace o půjčování jako jiného typu najdete na [`Borrow<T>`].
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Proměnlivě si půjčuje od hodnoty ve vlastnictví.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}