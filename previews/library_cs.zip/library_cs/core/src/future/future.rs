#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future představuje asynchronní výpočet.
///
/// future je hodnota, která ještě nemusí dokončit výpočet.
/// Tento druh "asynchronous value" umožňuje vláknu pokračovat v užitečné práci, zatímco čeká na zpřístupnění hodnoty.
///
///
/// # Metoda `poll`
///
/// Základní metoda future, `poll`,*se pokusí* vyřešit future na konečnou hodnotu.
/// Tato metoda neblokuje, pokud hodnota není připravena.
/// Místo toho je naplánováno probuzení aktuální úlohy, když je možné dosáhnout dalšího pokroku opětovným dotazováním.
/// `context` předaný metodě `poll` může poskytnout [`Waker`], což je úchyt pro probuzení aktuální úlohy.
///
/// Když používáte future, obecně nebudete volat `poll` přímo, ale místo toho `.await` hodnotu.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Typ hodnoty vytvořené po dokončení.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Pokuste se vyřešit future na konečnou hodnotu a zaregistrujte aktuální úkol pro probuzení, pokud hodnota ještě není k dispozici.
    ///
    /// # Návratová hodnota
    ///
    /// Tato funkce vrací:
    ///
    /// - [`Poll::Pending`] pokud future ještě není připraven
    /// - [`Poll::Ready(val)`] s výsledkem `val` této future, pokud byla úspěšně dokončena.
    ///
    /// Jakmile je future hotový, klienti by jej již neměli `poll` znovu.
    ///
    /// Pokud future ještě není připraven, `poll` vrátí `Poll::Pending` a uloží klon [`Waker`] zkopírovaný z aktuální [`Context`].
    /// Tento [`Waker`] se poté probudí, jakmile může future dosáhnout pokroku.
    /// Například future čekající na to, aby se soket stal čitelným, by zavolal `.clone()` na [`Waker`] a uložil jej.
    /// Když přijde signál kamkoli, což naznačuje, že soket je čitelný, je volána [`Waker::wake`] a proběhne úloha soketu future.
    /// Jakmile je úkol probuzen, měl by se pokusit `poll` future znovu, což může nebo nemusí přinést konečnou hodnotu.
    ///
    /// Všimněte si, že u více hovorů na `poll` by mělo být naplánováno pouze probuzení [`Waker`] z [`Context`] předaného nejnovějšímu hovoru.
    ///
    /// # Runtime charakteristiky
    ///
    /// Samotné Futures jsou *inertní*;musí být *aktivně*`dotazováni`, aby dosáhli pokroku, což znamená, že pokaždé, když se aktuální úkol probudí, měl by se aktivně znovu" zeptat `, dokud nebude futures, o který má stále zájem.
    ///
    /// Funkce `poll` není volána opakovaně v těsné smyčce-místo toho by měla být volána pouze tehdy, když future naznačuje, že je připravena dělat pokrok (voláním `wake()`).
    /// Pokud znáte systémové volání `poll(2)` nebo `select(2)` na Unix, stojí za zmínku, že futures obvykle *ne* netrpí stejnými problémy jako "all wakeups must poll all events";jsou spíš jako `epoll(4)`.
    ///
    /// Implementace `poll` by se měla snažit o rychlý návrat a neměla by blokovat.Rychlý návrat zabrání zbytečnému ucpání vláken nebo smyček událostí.
    /// Pokud je předem známo, že volání `poll` může chvíli trvat, měla by být práce uvolněna do fondu vláken (nebo něco podobného), aby bylo zajištěno, že se `poll` může rychle vrátit.
    ///
    /// # Panics
    ///
    /// Po dokončení future (vrácení `Ready` z `poll`) může opětovné volání metody `poll` panic blokovat navždy, nebo způsobit jiné druhy problémů;`Future` trait neklade žádné požadavky na účinky takového volání.
    /// Protože však metoda `poll` není označena jako `unsafe`, platí obvyklá pravidla Rust: volání nesmí nikdy způsobit nedefinované chování (poškození paměti, nesprávné použití funkcí `unsafe` apod.), Bez ohledu na stav future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}