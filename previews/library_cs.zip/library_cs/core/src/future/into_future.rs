use crate::future::Future;

/// Přestavba na `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Výstup, který bude future produkovat po dokončení.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Na jaký druh future to děláme?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Vytvoří future z hodnoty.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}