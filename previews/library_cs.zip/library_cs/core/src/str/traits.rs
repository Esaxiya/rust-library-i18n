//! Implementace Trait pro `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Implementuje řazení řetězců.
///
/// Řetězce jsou seřazeny podle [lexicographically](Ord#lexicographical-comparison) podle jejich bajtových hodnot.
/// Toto objednává body kódu Unicode na základě jejich pozic v kódových grafech.
/// To nemusí být nutně stejné jako u objednávky "alphabetical", která se liší podle jazyka a národního prostředí.
/// Řazení řetězců podle kulturně uznávaných standardů vyžaduje data specifická pro národní prostředí, která jsou mimo rozsah typu `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Implementuje operace porovnání na řetězcích.
///
/// Řetězce jsou porovnávány [lexicographically](Ord#lexicographical-comparison) podle jejich bajtových hodnot.
/// Porovnává body kódu Unicode na základě jejich pozic v kódových grafech.
/// To nemusí být nutně stejné jako u objednávky "alphabetical", která se liší podle jazyka a národního prostředí.
/// Porovnání řetězců podle kulturně uznávaných standardů vyžaduje data specifická pro národní prostředí, která jsou mimo rozsah typu `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Implementuje dílčí řezy se syntaxí `&self[..]` nebo `&mut self[..]`.
///
/// Vrátí výřez celého řetězce, tj. Vrátí `&self` nebo `&mut self`.Ekvivalentní k&&self [0 ..
/// len] `nebo`&mut self [0 ..
/// len]`.
/// Na rozdíl od jiných operací indexování to nikdy nemůže panic.
///
/// Tato operace je *O*(1).
///
/// Před 1.20.0 byly tyto operace indexování stále podporovány přímou implementací `Index` a `IndexMut`.
///
/// Odpovídá `&self[0 .. len]` nebo `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Implementuje dílčí řezy se syntaxí `&self[begin .. end]` nebo `&mut self[begin .. end]`.
///
/// Vrátí výřez daného řetězce z rozsahu bajtů ["start", `end`).
///
/// Tato operace je *O*(1).
///
/// Před 1.20.0 byly tyto operace indexování stále podporovány přímou implementací `Index` a `IndexMut`.
///
/// # Panics
///
/// Panics pokud `begin` nebo `end` neukazují na počáteční posunutí bajtu znaku (jak je definováno `is_char_boundary`), pokud `begin > end` nebo `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // to bude panic:
/// // byte 2 leží v `ö`:
/// // &s [2 ..3];
///
/// // bajt 8 leží v `老`&s [1 ..
/// // 8];
///
/// // byte 100 je mimo řetězec&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // BEZPEČNOST: pouze zkontrolováno, že `start` a `end` jsou na hranici znaků,
            // a předáváme bezpečnou referenci, takže návratová hodnota bude také jedna.
            // Zkontrolovali jsme také hranice znaků, takže toto je platné UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // BEZPEČNOST: pouze zkontrolováno, že `start` a `end` jsou na hranici znaků.
            // Víme, že ukazatel je jedinečný, protože jsme jej získali z `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // BEZPEČNOST: volající zaručuje, že `self` je v mezích `slice`
        // který splňuje všechny podmínky pro `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // BEZPEČNOST: viz komentáře k `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary kontroluje, zda je index v [0, .len()] nemůže znovu použít `get` jako výše, kvůli problémům s NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // BEZPEČNOST: pouze zkontrolováno, že `start` a `end` jsou na hranici znaků,
            // a předáváme bezpečnou referenci, takže návratová hodnota bude také jedna.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Implementuje dílčí řezy se syntaxí `&self[.. end]` nebo `&mut self[.. end]`.
///
/// Vrátí řez daného řetězce z rozsahu bajtů [`0`, `end`).
/// Odpovídá `&self[0 .. end]` nebo `&mut self[0 .. end]`.
///
/// Tato operace je *O*(1).
///
/// Před 1.20.0 byly tyto operace indexování stále podporovány přímou implementací `Index` a `IndexMut`.
///
/// # Panics
///
/// Panics, pokud `end` neukazuje na počáteční posunutí bajtu znaku (jak je definováno `is_char_boundary`), nebo pokud `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // BEZPEČNOST: stačí zkontrolovat, zda je `end` na hranici znaku,
            // a předáváme bezpečnou referenci, takže návratová hodnota bude také jedna.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // BEZPEČNOST: stačí zkontrolovat, zda je `end` na hranici znaku,
            // a předáváme bezpečnou referenci, takže návratová hodnota bude také jedna.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // BEZPEČNOST: stačí zkontrolovat, zda je `end` na hranici znaku,
            // a předáváme bezpečnou referenci, takže návratová hodnota bude také jedna.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Implementuje dílčí řezy se syntaxí `&self[begin ..]` nebo `&mut self[begin ..]`.
///
/// Vrátí výřez daného řetězce z rozsahu bajtů ["start", `len`).Ekvivalent k " &self [začít ..
/// len] `nebo`&mut self [začít ..
/// len]`.
///
/// Tato operace je *O*(1).
///
/// Před 1.20.0 byly tyto operace indexování stále podporovány přímou implementací `Index` a `IndexMut`.
///
/// # Panics
///
/// Panics, pokud `begin` neukazuje na počáteční posunutí bajtu znaku (jak je definováno `is_char_boundary`), nebo pokud `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // BEZPEČNOST: stačí zkontrolovat, zda je `start` na hranici znaku,
            // a předáváme bezpečnou referenci, takže návratová hodnota bude také jedna.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // BEZPEČNOST: stačí zkontrolovat, zda je `start` na hranici znaku,
            // a předáváme bezpečnou referenci, takže návratová hodnota bude také jedna.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // BEZPEČNOST: volající zaručuje, že `self` je v mezích `slice`
        // který splňuje všechny podmínky pro `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // BEZPEČNOST: shodná s `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // BEZPEČNOST: stačí zkontrolovat, zda je `start` na hranici znaku,
            // a předáváme bezpečnou referenci, takže návratová hodnota bude také jedna.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Implementuje dílčí řezy se syntaxí `&self[begin ..= end]` nebo `&mut self[begin ..= end]`.
///
/// Vrátí řez daného řetězce z rozsahu bajtů [`begin`, `end`].Odpovídá `&self [begin .. end + 1]` nebo `&mut self[begin .. end + 1]`, kromě případů, kdy `end` má maximální hodnotu pro `usize`.
///
/// Tato operace je *O*(1).
///
/// # Panics
///
/// Panics, pokud `begin` neukazuje na počáteční posunutí bajtu znaku (jak je definováno `is_char_boundary`), pokud `end` neukazuje na koncový posun bajtu znaku (`end + 1` je buď počáteční posunutí bajtu nebo rovno `len`), pokud `begin > end`, nebo pokud `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Implementuje dílčí řezy se syntaxí `&self[..= end]` nebo `&mut self[..= end]`.
///
/// Vrátí řez daného řetězce z rozsahu bajtů [0, `end`].
/// Odpovídá `&self [0 .. end + 1]`, kromě případů, kdy `end` má maximální hodnotu pro `usize`.
///
/// Tato operace je *O*(1).
///
/// # Panics
///
/// Panics, pokud `end` neukazuje na koncový bajtový offset znaku (`end + 1` je buď počáteční bajtový offset definovaný `is_char_boundary`, nebo rovný `len`), nebo pokud `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // BEZPEČNOST: volající musí dodržovat bezpečnostní smlouvu pro `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Analyzovat hodnotu z řetězce
///
/// `Metoda [`from_str`] FromStr` se často používá implicitně, prostřednictvím metody [`parse`] [`str`].
/// Příklady najdete v dokumentaci [`parse`].
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` nemá celoživotní parametr, a proto můžete analyzovat pouze typy, které neobsahují celoživotní parametr samy.
///
/// Jinými slovy, můžete analyzovat `i32` s `FromStr`, ale ne `&i32`.
/// Můžete analyzovat strukturu, která obsahuje `i32`, ale ne ten, který obsahuje `&i32`.
///
/// # Examples
///
/// Základní implementace `FromStr` na příkladu typu `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Přidružená chyba, kterou lze vrátit při analýze.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Analyzuje řetězec `s`, aby vrátil hodnotu tohoto typu.
    ///
    /// Pokud je analýza úspěšná, vraťte hodnotu uvnitř [`Ok`], jinak, když je řetězec špatně formátovaný, vraťte chybu specifickou pro vnitřní [`Err`].
    /// Typ chyby je specifický pro implementaci trait.
    ///
    /// # Examples
    ///
    /// Základní použití s [`i32`], typem, který implementuje `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Analyzujte `bool` z řetězce.
    ///
    /// Získá `Result<bool, ParseBoolError>`, protože `s` může nebo nemusí být ve skutečnosti analyzovatelný.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Všimněte si, že v mnoha případech je metoda `.parse()` na `str` vhodnější.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}