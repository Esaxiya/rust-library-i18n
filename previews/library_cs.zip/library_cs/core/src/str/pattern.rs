//! Řetězcový vzor API.
//!
//! Pattern API poskytuje obecný mechanismus pro použití různých typů vzorů při prohledávání řetězce.
//!
//! Další podrobnosti najdete v traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] a [`DoubleEndedSearcher`].
//!
//! Ačkoli je toto API nestabilní, je vystaveno prostřednictvím stabilních API na typu [`str`].
//!
//! # Examples
//!
//! [`Pattern`] je [implemented][pattern-impls] ve stabilním API pro [`&str`][`str`], [`char`], plátky [`char`] a funkce a uzávěry implementující `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // char vzor
//! assert_eq!(s.find('n'), Some(2));
//! // plátek znaků
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // uzavírací vzor
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Řetězcový vzor.
///
/// `Pattern<'a>` vyjadřuje, že implementační typ lze použít jako vzor řetězce pro vyhledávání v [`&'a str`][str].
///
/// Například `'a'` a `"aa"` jsou vzory, které by odpovídaly indexu `1` v řetězci `"baaaab"`.
///
/// Samotný trait funguje jako builder pro přidružený typ [`Searcher`], který provádí skutečnou práci při hledání výskytů vzoru v řetězci.
///
///
/// V závislosti na typu vzoru se chování metod jako [`str::find`] a [`str::contains`] může změnit.
/// Níže uvedená tabulka popisuje některá z těchto chování.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Přidružený vyhledávač tohoto vzoru
    type Searcher: Searcher<'a>;

    /// Vytvoří přidružený vyhledávač z `self` a `haystack`, ve kterém se má hledat.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Zkontroluje, zda se vzor shoduje kdekoli v kupce sena
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Zkontroluje, zda se vzor shoduje v přední části kupce sena
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Zkontroluje, zda se vzor shoduje v zadní části kupce sena
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Odstraní vzor z přední části kupce sena, pokud odpovídá.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // BEZPEČNOST: Je známo, že `Searcher` vrací platné indexy.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Odstraní vzor ze zadní části kupce sena, pokud odpovídá.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // BEZPEČNOST: Je známo, že `Searcher` vrací platné indexy.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Výsledek volání [`Searcher::next()`] nebo [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Vyjadřuje, že shoda vzoru byla nalezena v `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Vyjadřuje, že `haystack[a..b]` byl odmítnut jako možná shoda vzoru.
    ///
    /// Všimněte si, že mezi dvěma " shody` může být více než jeden `Reject`, není tedy nutné je kombinovat do jednoho.
    ///
    ///
    Reject(usize, usize),
    /// Vyjadřuje, že každý bajt stohu sena byl navštíven, a končí tak iteraci.
    ///
    Done,
}

/// Hledač řetězcového vzoru.
///
/// Tento trait poskytuje metody pro hledání nepřekrývajících se shod vzoru počínaje od předního (left) řetězce.
///
/// Bude implementováno přidruženými typy `Searcher` modelu [`Pattern`] trait.
///
/// trait je označen jako nebezpečný, protože indexy vrácené metodami [`next()`][Searcher::next] musí ležet na platných hranicích utf8 v kupce sena.
/// To umožňuje spotřebitelům tohoto trait rozdělit kupku sena bez dalších kontrol za běhu.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter pro podkladový řetězec, který má být prohledán
    ///
    /// Vždy vrátí stejnou [`&str`][str].
    fn haystack(&self) -> &'a str;

    /// Provede další krok hledání začínající zepředu.
    ///
    /// - Vrátí [`Match(a, b)`][SearchStep::Match], pokud `haystack[a..b]` odpovídá vzoru.
    /// - Vrátí [`Reject(a, b)`][SearchStep::Reject], pokud `haystack[a..b]` nemůže odpovídat vzoru, i když jen částečně.
    /// - Vrátí [`Done`][SearchStep::Done], pokud byl navštíven každý bajt stohu sena.
    ///
    /// Proud hodnot [`Match`][SearchStep::Match] a [`Reject`][SearchStep::Reject] až do [`Done`][SearchStep::Done] bude obsahovat rozsahy indexů, které jsou přilehlé, nepřekrývající se, pokrývají celou hromadu sena a leží na hranicích utf8.
    ///
    ///
    /// Výsledek [`Match`][SearchStep::Match] musí obsahovat celý odpovídající vzor, výsledky [`Reject`][SearchStep::Reject] však lze rozdělit na libovolné mnoho sousedních fragmentů.Oba rozsahy mohou mít nulovou délku.
    ///
    /// Jako příklad může stream produkovat vzor `"aaa"` a kupa sena `"cbaaaaab"`
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Najde další výsledek [`Match`][SearchStep::Match].Viz [`next()`][Searcher::next].
    ///
    /// Na rozdíl od [`next()`][Searcher::next] neexistuje žádná záruka, že se vrácené rozsahy tohoto a [`next_reject`][Searcher::next_reject] budou překrývat.
    /// Tím se vrátí `(start_match, end_match)`, kde start_match je index, kde začíná zápas, a end_match je index po skončení zápasu.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Najde další výsledek [`Reject`][SearchStep::Reject].Viz [`next()`][Searcher::next] a [`next_match()`][Searcher::next_match].
    ///
    /// Na rozdíl od [`next()`][Searcher::next] neexistuje žádná záruka, že se vrácené rozsahy tohoto a [`next_match`][Searcher::next_match] budou překrývat.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Zpětný vyhledávač řetězcového vzoru.
///
/// Tento trait poskytuje metody pro hledání nepřekrývajících se shod vzoru počínaje od zadního (right) řetězce.
///
/// Bude implementováno přidruženými typy [`Searcher`] modelu [`Pattern`] trait, pokud vzor podporuje jeho vyhledávání zezadu.
///
///
/// Rozsahy indexů vrácené tímto trait se nemusí přesně shodovat s rozsahy dopředného vyhledávání vzad.
///
/// Z důvodu, proč je tento trait označen jako nebezpečný, podívejte se na něj jako nadřazený trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Provede další krok hledání začínající od zadní strany.
    ///
    /// - Vrátí [`Match(a, b)`][SearchStep::Match], pokud `haystack[a..b]` odpovídá vzoru.
    /// - Vrátí [`Reject(a, b)`][SearchStep::Reject], pokud `haystack[a..b]` nemůže odpovídat vzoru, i když jen částečně.
    /// - Vrátí [`Done`][SearchStep::Done], pokud byl navštíven každý bajt stohu sena
    ///
    /// Proud hodnot [`Match`][SearchStep::Match] a [`Reject`][SearchStep::Reject] až do [`Done`][SearchStep::Done] bude obsahovat rozsahy indexů, které jsou přilehlé, nepřekrývající se, pokrývají celou hromadu sena a leží na hranicích utf8.
    ///
    ///
    /// Výsledek [`Match`][SearchStep::Match] musí obsahovat celý odpovídající vzor, výsledky [`Reject`][SearchStep::Reject] však lze rozdělit na libovolné mnoho sousedních fragmentů.Oba rozsahy mohou mít nulovou délku.
    ///
    /// Jako příklad může vzor `"aaa"` a kupa sena `"cbaaaaab"` vytvářet proud `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Najde další výsledek [`Match`][SearchStep::Match].
    /// Viz [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Najde další výsledek [`Reject`][SearchStep::Reject].
    /// Viz [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Značka trait, která vyjadřuje, že pro implementaci [`DoubleEndedIterator`] lze použít [`ReverseSearcher`].
///
/// Za tímto účelem musí impl [`Searcher`] a [`ReverseSearcher`] dodržovat tyto podmínky:
///
/// - Všechny výsledky `next()` musí být totožné s výsledky `next_back()` v opačném pořadí.
/// - `next()` a `next_back()` se musí chovat jako dva konce rozsahu hodnot, to znamená, že nemohou "walk past each other".
///
/// # Examples
///
/// `char::Searcher` je `DoubleEndedSearcher`, protože hledání [`char`] vyžaduje pouze pohled na jeden po druhém, který se chová stejně z obou konců.
///
/// `(&str)::Searcher` není `DoubleEndedSearcher`, protože vzor `"aa"` v kupce sena `"aaa"` se shoduje jako `"[aa]a"` nebo `"a[aa]"`, podle toho, z které strany je hledán.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl za char
/////////////////////////////////////////////////////////////////////////////

/// Přidružený typ pro `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // safety invariant: `finger`/`finger_back` must be a valid utf8 byte index of `haystack` This invariant can be broken *within* next_match and next_match_back, however they must exit withinger on valid code point boundaries.
    //
    //
    /// `finger` je aktuální bajtový index dopředného vyhledávání.
    /// Představte si, že existuje před bajtem na jeho indexu, tj
    /// `haystack[finger]` je první bajt řezu, který musíme zkontrolovat během dopředného vyhledávání
    ///
    finger: usize,
    /// `finger_back` je aktuální bajtový index zpětného vyhledávání.
    /// Představte si, že existuje za bajtem na jeho indexu, tj
    /// haystack [finger_back, 1] je poslední bajt řezu, který musíme zkontrolovat během dopředného vyhledávání (a tedy první bajt, který má být zkontrolován při volání next_back()).
    ///
    finger_back: usize,
    /// Hledaná postava
    needle: char,

    // bezpečnostní invariant: `utf8_size` musí být menší než 5
    /// Počet bajtů, které `needle` zabírá při kódování v utf8.
    utf8_size: usize,
    /// Kopie `needle` kódovaná utf8
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // BEZPEČNOST: 1-4 zaručuje bezpečnost `get_unchecked`
        // 1. `self.finger` a `self.finger_back` jsou uchovávány na hranicích unicode (toto je neměnné)
        // 2. `self.finger >= 0` protože začíná na 0 a pouze se zvyšuje
        // 3. `self.finger < self.finger_back` protože jinak by char `iter` vrátil `SearchStep::Done`
        // 4.
        // `self.finger` přichází před koncem kupce sena, protože `self.finger_back` začíná na konci a pouze klesá
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // přidat posunutí bajtu aktuálního znaku bez překódování jako utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // získejte kupu sena po nalezení poslední postavy
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // poslední bajt jehly kódované utf8 BEZPEČNOST: máme invariant, který `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Nový prst je index bajtu, který jsme našli, plus jeden, protože jsme memchr'd pro poslední bajt znaku.
                //
                // Všimněte si, že to nám ne vždy dá prst na hranici UTF8.
                // Pokud jsme *nenašli* náš znak, mohli jsme indexovat na poslední bajt 3bajtového nebo 4bajtového znaku.
                // Nemůžeme jen přeskočit na další platný počáteční bajt, protože znak jako ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` nám dá při hledání třetího vždy najít druhý bajt.
                //
                //
                // To je však naprosto v pořádku.
                // I když máme invariant, že self.finger je na hranici UTF8, na tento invariant se v rámci této metody nespoléhá (spoléhá se na něj v CharSearcher::next()).
                //
                // Tuto metodu ukončíme, pouze když dosáhneme konce řetězce nebo pokud něco najdeme.Když něco najdeme, `finger` bude nastaven na hranici UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // nic nenašel, odejděte
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // nechme next_reject použít výchozí implementaci z Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // BEZPEČNOST: viz komentář k next() výše
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // odečíst posunutí bajtu aktuálního znaku bez překódování jako utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // dostat kupu sena až na poslední hledaný znak
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // poslední bajt jehly kódované utf8 BEZPEČNOST: máme invariant, který `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // prohledali jsme řez, který byl kompenzován self.finger, přidáním self.finger získáme původní index
                //
                let index = self.finger + index;
                // memrchr vrátí index bajtu, který chceme najít.
                // V případě znaku ASCII to skutečně bylo, kdybychom si přáli, aby náš nový prst byl ("after" nalezený znak v paradigmatu reverzní iterace).
                //
                // U vícebajtových znaků musíme přeskočit dolů o počet více bajtů, které mají, než ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // přesunout prst před nalezený znak (tj. na jeho počátečním indexu)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Zde nemůžeme použít finger_back=index, size + 1.
                // Pokud jsme našli poslední znak znaku různé velikosti (nebo prostředního bajtu jiného znaku), musíme narazit na finger_back dolů na `index`.
                // Tím se podobně stává, že `finger_back` již nemusí být na hranici, ale je to v pořádku, protože tuto funkci opouštíme pouze na hranici, nebo když je sena kompletně prohledána.
                //
                //
                // Na rozdíl od next_match to nemá problém s opakovanými bajty v utf-8, protože hledáme poslední bajt a při hledání v opačném směru můžeme najít pouze poslední bajt.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // nic nenašel, odejděte
                return None;
            }
        }
    }

    // nech next_reject_back použít výchozí implementaci z Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Hledá znaky, které se rovnají danému [`char`].
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl pro obálku MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Porovnejte délky interního iterátoru bajtových segmentů a zjistěte délku aktuálního znaku
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Porovnejte délky interního iterátoru bajtových segmentů a zjistěte délku aktuálního znaku
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl pro&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Změnit/Odebrat kvůli nejednoznačnosti ve smyslu.

/// Přidružený typ pro `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Vyhledá znaky, které se rovnají libovolnému z [`znaků`] s v řezu.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl pro F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Přidružený typ pro `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Vyhledá [" znaky`], které odpovídají danému predikátu.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl pro&&str
/////////////////////////////////////////////////////////////////////////////

/// Delegáti na `&str` impl.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl pro &str
/////////////////////////////////////////////////////////////////////////////

/// Nepřiřazení vyhledávání podřetězců.
///
/// Zpracuje vzor `""` jako vrací prázdné shody na každé hranici znaku.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Zkontroluje, zda se vzor shoduje v přední části kupce sena.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Odstraní vzor z přední části kupce sena, pokud odpovídá.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // BEZPEČNOST: předpona byla právě ověřena.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Zkontroluje, zda se vzor shoduje v zadní části kupce sena.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Odstraní vzor ze zadní části kupce sena, pokud odpovídá.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // BEZPEČNOST: přípona byla právě ověřena.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Obousměrný vyhledávač podřetězců
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Přidružený typ pro `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // prázdná jehla odmítne každý znak a porovná každý prázdný řetězec mezi nimi
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher produkuje platné *Match* indexy, které se rozdělují na hranici znaků, pokud to dělá správné párování a že kupka sena a jehla jsou platné UTF-8 *Rejects* z algoritmu může spadnout na jakékoli indexy, ale my je ručně přejdeme na další hranici znaků, aby byly v bezpečí utf-8.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // přeskočit na další hranici znaků
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // vypište případy `true` a `false`, abyste povzbudili kompilátor, aby specializoval tyto dva případy samostatně.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // přeskočit na další hranici znaků
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // vypište `true` a `false`, jako `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Interní stav obousměrného vyhledávacího algoritmu podřetězce.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// index kritické faktorizace
    crit_pos: usize,
    /// index kritické faktorizace pro obrácenou jehlu
    crit_pos_back: usize,
    period: usize,
    /// `byteset` je přípona (není součástí obousměrného algoritmu);
    /// je to 64bitový "fingerprint", kde každý nastavený bit `j` odpovídá a (byte&63)==j přítomnému v jehle.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// index do jehly, před kterou jsme již uzavřeli
    memory: usize,
    /// index do jehly, po kterém jsme již uzavřeli
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Obzvláště čitelné vysvětlení toho, co se zde děje, najdete v knize Crochemore a Rytter "Text Algorithms", ch 13.
        // Konkrétně viz kód pro "Algorithm CP" na str.
        // 323.
        //
        // Co se děje, je, že máme nějakou kritickou faktorizaci (u, v) jehly a chceme zjistit, zda u je přípona&v [.. období].
        // Pokud ano, používáme "Algorithm CP1".
        // Jinak použijeme "Algorithm CP2", který je optimalizován pro velkou periodu jehly.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // případ krátké doby-doba je přesná vypočítat samostatnou kritickou faktorizaci pro obrácenou jehlu x=u 'v' kde | v '|<period(x).
            //
            // To je urychleno již známým obdobím.
            // Všimněte si, že případ jako x= "acba" může být započítán přesně dopředu (crit_pos=1, období=3), zatímco je započítán s přibližným obdobím v opačném směru (crit_pos=2, období=2).
            // Používáme danou reverzní faktorizaci, ale dodržujeme přesné období.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // případ dlouhého období-máme přiblížení skutečnému období a nepoužíváme memorování.
            //
            //
            // Přibližte období dolní mezí max(|u|, |v|) + 1.
            // Kritická faktorizace je efektivní pro vyhledávání vpřed i vzad.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Fiktivní hodnota znamená, že období je dlouhé
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Jednou z hlavních myšlenek Two-Way je, že rozložíme jehlu na dvě poloviny (u, v) a začneme se snažit najít v v kupce sena skenováním zleva doprava.
    // Pokud se v shoduje, zkusíme porovnat u skenováním zprava doleva.
    // Jak daleko můžeme skočit, když narazíme na nesoulad, vše je založeno na skutečnosti, že (u, v) je pro jehlu kritickou faktorizací.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` používá `self.position` jako kurzor
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Zkontrolujte, zda máme prostor pro vyhledávání v pozici + jehla_last nemůže přetékat, pokud předpokládáme, že řezy jsou ohraničeny rozsahem isize.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Rychle přeskočte o velké porce nesouvisející s naším podřetězcem
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Zjistěte, zda se pravá část jehly shoduje
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Zjistěte, zda se levá část jehly shoduje
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Našli jsme shodu!
            let match_pos = self.position;

            // Note: přidejte self.period místo needle.len(), abyste měli překrývající se shody
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // nastaveno na needle.len(), self.period pro překrývající se zápasy
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Řídí se nápady v `next()`.
    //
    // Definice jsou symetrické, s period(x) = period(reverse(x)) a local_period(u, v) = local_period(reverse(v), reverse(u)), takže pokud (u, v) je kritická faktorizace, tak i (reverse(v), reverse(u)).
    //
    //
    // Pro obrácený případ jsme vypočítali kritickou faktorizaci x=u 'v' (pole `crit_pos_back`).Potřebujeme | u |<period(x) pro přední případ, a tedy | v '|<period(x) pro zpětný chod.
    //
    // Chcete-li hledat zpět v kupce sena, hledáme vpřed v obrácené kupce sena s obrácenou jehlou, přičemž nejprve se shodují první u 'a poté v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` používá `self.end` jako kurzor, takže `next()` a `next_back()` jsou nezávislé.
        //
        let old_end = self.end;
        'search: loop {
            // Zkontrolujte, zda máme na konci prostor pro hledání, needle.len() se omotá, když už nebude místo, ale kvůli limitům délky řezu se nikdy nemůže zabalit úplně zpět do délky kupce sena.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Rychle přeskočte o velké porce nesouvisející s naším podřetězcem
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Zjistěte, zda se levá část jehly shoduje
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Zjistěte, zda se pravá část jehly shoduje
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Našli jsme shodu!
            let match_pos = self.end - needle.len();
            // Note: sub self.period místo needle.len(), aby se překrývaly shody
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Vypočítejte maximální příponu `arr`.
    //
    // Maximální přípona je možná kritická faktorizace (u, v) `arr`.
    //
    // Vrátí (`i`, `p`), kde `i` je počáteční index v a `p` je období v.
    //
    // `order_greater` určuje, zda je lexikální pořadí `<` nebo `>`.
    // Musí být vypočítány obě objednávky-objednávka s největší `i` dává kritickou faktorizaci.
    //
    //
    // U případů s dlouhým obdobím není výsledné období přesné (je příliš krátké).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Odpovídá i v článku
        let mut right = 1; // Odpovídá j v článku
        let mut offset = 0; // Odpovídá k v článku, ale začíná na 0
        // aby odpovídalo indexování založenému na 0.
        let mut period = 1; // Odpovídá p v článku

        while let Some(&a) = arr.get(right + offset) {
            // `left` bude příchozí, když bude `right`.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Přípona je menší, tečka je zatím celá předpona.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Záloha opakováním aktuálního období.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Přípona je větší, začněte znovu od aktuálního umístění.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Vypočítejte maximální příponu zadní strany `arr`.
    //
    // Maximální přípona je možná kritická faktorizace (u ', v') `arr`.
    //
    // Vrátí `i`, kde `i` je počáteční index v ', zezadu;
    // vrátí se okamžitě po dosažení období `known_period`.
    //
    // `order_greater` určuje, zda je lexikální pořadí `<` nebo `>`.
    // Musí být vypočítány obě objednávky-objednávka s největší `i` dává kritickou faktorizaci.
    //
    //
    // U případů s dlouhým obdobím není výsledné období přesné (je příliš krátké).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Odpovídá i v článku
        let mut right = 1; // Odpovídá j v článku
        let mut offset = 0; // Odpovídá k v článku, ale začíná na 0
        // aby odpovídalo indexování založenému na 0.
        let mut period = 1; // Odpovídá p v článku
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Přípona je menší, tečka je zatím celá předpona.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Záloha opakováním aktuálního období.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Přípona je větší, začněte znovu od aktuálního umístění.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy umožňuje algoritmu buď co nejrychleji přeskočit neshody, nebo pracovat v režimu, kde relativně rychle vysílá odmítnutí.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Přeskočte, aby se intervaly shodovaly co nejrychleji
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Pravidelně emitujte odmítnutí
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}