//! Kompoziční asynchronní iterace.
//!
//! Pokud futures jsou asynchronní hodnoty, pak proudy jsou asynchronní iterátory.
//! Pokud jste se ocitli v asynchronní kolekci nějakého druhu a potřebujete provést operaci s prvky uvedené kolekce, rychle narazíte na 'streams'.
//! Proudy jsou často používány v idiomatickém asynchronním kódu Rust, takže stojí za to se s nimi seznámit.
//!
//! Než vysvětlíme více, promluvme si o tom, jak je tento modul strukturován:
//!
//! # Organization
//!
//! Tento modul je z velké části organizován podle typu:
//!
//! * [Traits] jsou hlavní částí: tyto traits definují, jaké druhy streamů existují a co s nimi můžete dělat.Metody těchto traits stojí za to věnovat nějaký čas navíc studiu.
//! * Funkce poskytují několik užitečných způsobů, jak vytvořit některé základní streamy.
//! * Struktury jsou často návratovými typy různých metod na traits tohoto modulu.Obvykle se budete chtít podívat na metodu, která vytváří `struct`, spíše než na samotný `struct`.
//! Další informace o tom, proč, najdete v části " [Prováděcí proud](#implementační proud)`.
//!
//! [Traits]: #traits
//!
//! A je to!Pojďme kopat do streamů.
//!
//! # Stream
//!
//! Srdcem a duší tohoto modulu je [`Stream`] trait.Jádro [`Stream`] vypadá takto:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Na rozdíl od `Iterator` rozlišuje `Stream` mezi metodou [`poll_next`], která se používá při implementaci `Stream`, a metodou (to-be-implemented) `next`, která se používá při konzumaci streamu.
//!
//! Spotřebitelé `Stream` musí vzít v úvahu pouze `next`, který při volání vrátí future, který získá `Option<Stream::Item>`.
//!
//! future vrácená `next` přinese `Some(Item)`, pokud existují prvky, a jakmile budou všechny vyčerpány, přinese `None`, což znamená, že iterace je dokončena.
//! Pokud čekáme na vyřešení něčeho asynchronního, future počká, dokud nebude stream znovu připraven.
//!
//! Jednotlivé streamy se mohou rozhodnout obnovit iteraci, a tak opětovné volání `next` může nebo nemusí nakonec v určitém okamžiku přinést `Some(Item)`.
//!
//! Plná definice aplikace [`Stream`] zahrnuje také řadu dalších metod, ale jsou to výchozí metody postavené na [`poll_next`], takže je máte zdarma.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Provádí se stream
//!
//! Vytvoření vlastního streamu zahrnuje dva kroky: vytvoření `struct` pro uchování stavu streamu a implementace [`Stream`] pro tento `struct`.
//!
//! Vytvořme stream s názvem `Counter`, který se počítá od `1` do `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Nejprve struktura:
//!
//! /// Proud, který počítá od jedné do pěti
//! struct Counter {
//!     count: usize,
//! }
//!
//! // chceme, aby náš počet začínal na jedné, přidejme tedy na pomoc metodu new().
//! // To není nezbytně nutné, ale je to pohodlné.
//! // Všimněte si, že začínáme `count` na nule, uvidíme proč v implementaci `poll_next()`'s níže.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Potom implementujeme `Stream` pro náš `Counter`:
//!
//! impl Stream for Counter {
//!     // budeme počítat s usize
//!     type Item = usize;
//!
//!     // poll_next() je jedinou požadovanou metodou
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Zvyšte náš počet.Proto jsme začali na nule.
//!         self.count += 1;
//!
//!         // Zkontrolujte, zda jsme počítání dokončili nebo ne.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Proudy jsou *líné*.To znamená, že pouhé vytvoření streamu _do_ moc neřeší.Ve skutečnosti se nic neděje, dokud nezavoláte `next`.
//! To je někdy zdrojem zmatku při vytváření streamu pouze pro jeho vedlejší účinky.
//! Kompilátor nás na tento druh chování upozorní:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;