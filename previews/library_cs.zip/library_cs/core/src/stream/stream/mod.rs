use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Rozhraní pro práci s asynchronními iterátory.
///
/// Toto je hlavní stream trait.
/// Další informace o konceptu streamů obecně najdete v [module-level documentation].
/// Zejména možná budete chtít vědět, jak na [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Typ položek získaných streamem.
    type Item;

    /// Pokuste se vytáhnout další hodnotu tohoto streamu, zaregistrujte aktuální úlohu pro probuzení, pokud hodnota ještě není k dispozici, a vraťte `None`, pokud je stream vyčerpán.
    ///
    /// # Návratová hodnota
    ///
    /// Existuje několik možných návratových hodnot, z nichž každá označuje odlišný stav streamu:
    ///
    /// - `Poll::Pending` znamená, že další hodnota tohoto streamu ještě není připravena.Implementace zajistí, že aktuální úkol bude upozorněn, až bude připravena další hodnota.
    ///
    /// - `Poll::Ready(Some(val))` znamená, že stream úspěšně vytvořil hodnotu `val` a při následných voláních `poll_next` může produkovat další hodnoty.
    ///
    /// - `Poll::Ready(None)` znamená, že stream byl ukončen a `poll_next` by neměl být znovu vyvolán.
    ///
    /// # Panics
    ///
    /// Jakmile je stream dokončen (vrátil `Ready(None)` from `poll_next`), opětovné volání jeho metody `poll_next` může panic blokovat navždy nebo způsobit jiné druhy problémů; `Stream` trait neklade žádné požadavky na účinky takového volání.
    ///
    /// Protože však metoda `poll_next` není označena jako `unsafe`, platí obvyklá pravidla Rust: volání nesmí nikdy způsobovat nedefinované chování (poškození paměti, nesprávné použití funkcí `unsafe` apod.), Bez ohledu na stav proudu.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Vrátí hranice zbývající délky streamu.
    ///
    /// Konkrétně `size_hint()` vrací n-tici, kde první prvek je dolní mez a druhý prvek je horní mez.
    ///
    /// Druhá polovina n-tice, která je vrácena, je [`Option`]`<`[`usize`] `>`.
    /// [`None`] zde znamená, že buď není známa horní mez, nebo je horní mez větší než [`usize`].
    ///
    /// # Poznámky k implementaci
    ///
    /// Není vynuceno, aby implementace streamu přinesla deklarovaný počet prvků.Buggy stream může přinést méně než dolní hranici nebo více než horní hranici prvků.
    ///
    /// `size_hint()` je primárně určen k použití pro optimalizace, jako je rezervace prostoru pro prvky proudu, ale nesmí být důvěryhodný např. k vynechání hraničních kontrol v nebezpečném kódu.
    /// Nesprávná implementace `size_hint()` by neměla vést k narušení bezpečnosti paměti.
    ///
    /// To znamená, že implementace by měla poskytovat správný odhad, protože jinak by to bylo porušení protokolu trait.
    ///
    /// Výchozí implementace vrací `(0,` [[None`]`)`, což je správné pro jakýkoli stream.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}