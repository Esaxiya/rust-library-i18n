#![stable(feature = "core_hint", since = "1.27.0")]

//! Rady pro kompilátor, který ovlivňuje, jak by měl být kód emitován nebo optimalizován.
//! Tipy mohou být čas kompilace nebo runtime.

use crate::intrinsics;

/// Informuje kompilátor, že tento bod v kódu není dosažitelný, což umožňuje další optimalizace.
///
/// # Safety
///
/// Dosažení této funkce je zcela *nedefinované chování*(UB).Kompilátor zejména předpokládá, že ke všem UB se nesmí nikdy stát, a proto eliminuje všechny větve, které se dostanou k volání `unreachable_unchecked()`.
///
/// Stejně jako všechny instance UB, pokud se tento předpoklad ukáže jako nesprávný, tj. Volání `unreachable_unchecked()` je ve skutečnosti dosažitelné mezi všemi možnými toky řízení, kompilátor použije nesprávnou strategii optimalizace a může někdy dokonce poškodit zdánlivě nesouvisející kód, což způsobí obtížné-k ladění problémů.
///
///
/// Tuto funkci použijte, pouze pokud prokážete, že jej kód nikdy nezavolá.
/// V opačném případě zvažte použití makra [`unreachable!`], které neumožňuje optimalizaci, ale při provedení bude panic.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` je vždy kladné (ne nula), proto `checked_div` nikdy nevrátí `None`.
/////
///     // Proto je else branch nedosažitelný.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // BEZPEČNOST: bezpečnostní smlouva pro `intrinsics::unreachable` musí
    // být podporován volajícím.
    unsafe { intrinsics::unreachable() }
}

/// Vydá strojovou instrukci, která signalizuje procesoru, že běží, v spin-loop zaneprázdněného čekání (" lock spin`).
///
/// Po přijetí signálu spin-loop může procesor optimalizovat své chování například úsporou energie nebo přepínáním vláken hyper.
///
/// Tato funkce se liší od [`thread::yield_now`], která se přímo vydává plánovači systému, zatímco `spin_loop` neinteraguje s operačním systémem.
///
/// Běžným případem použití pro `spin_loop` je implementace omezeného optimistického předení ve smyčce CAS v synchronizačních primitivech.
/// Aby se předešlo problémům, jako je prioritní inverze, důrazně se doporučuje ukončit smyčku rotace po konečném počtu iterací a provést odpovídající blokující syscall.
///
///
/// **Poznámka**: Na platformách, které nepodporují příjem nápovědy spin-loop, tato funkce nedělá vůbec nic.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Sdílená atomová hodnota, kterou vlákna použijí ke koordinaci
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Ve vlákně na pozadí nakonec nastavíme hodnotu
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Udělejte nějakou práci a poté hodnotu zveřejněte
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Zpět na naše aktuální vlákno, čekáme na nastavení hodnoty
/// while !live.load(Ordering::Acquire) {
///     // Spinovací smyčka je nápovědou k CPU, na kterou čekáme, ale pravděpodobně ne příliš dlouho
/////
///     hint::spin_loop();
/// }
///
/// // Hodnota je nyní nastavena
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // BEZPEČNOST: attr `cfg` zajišťuje, že toto provádíme pouze na cílech x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // BEZPEČNOST: attr `cfg` zajišťuje, že toto provádíme pouze na cílech x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // BEZPEČNOST: attr `cfg` zajišťuje, že toto provádíme pouze na cílech aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // BEZPEČNOST: attr `cfg` zajišťuje, že to provedeme pouze na cílech paží
            // s podporou funkce v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Funkce identity, která *__ naznačuje __* kompilátoru, aby byla maximálně pesimistická ohledně toho, co `black_box` dokáže.
///
/// Na rozdíl od [`std::convert::identity`] se doporučuje kompilátoru Rust předpokládat, že `black_box` může používat `dummy` jakýmkoli možným platným způsobem, ke kterému je povolen kód Rust, aniž by do volajícího kódu vložil nedefinované chování.
///
/// Díky této vlastnosti je `black_box` užitečný pro psaní kódu, ve kterém nejsou požadovány určité optimalizace, například měřítka.
///
/// Všimněte si však, že `black_box` je poskytován (a může být pouze) poskytován na základě "best-effort".Rozsah, v jakém může blokovat optimalizace, se může lišit v závislosti na použité platformě a back-endu gen-kódu.
/// Programy se v žádném případě nemohou spolehnout na *správnost*`black_box`.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Musíme "use" argument nějakým způsobem LLVM nemůže introspektovat, a na cílech, které ho podporují, můžeme k tomu obvykle využít inline sestavení.
    // Interpretace inline sestavy LLVM spočívá v tom, že je to černá skříňka.
    // Nejedná se o největší implementaci, protože pravděpodobně deoptimizuje více, než chceme, ale je zatím dostatečně dobrá.
    //
    //

    #[cfg(not(miri))] // To je jen náznak, takže je dobré přeskočit v Miri.
    // BEZPEČNOST: vložená sestava je zakázaná.
    unsafe {
        // FIXME: Nelze použít `asm!`, protože nepodporuje MIPS a jiné architektury.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}