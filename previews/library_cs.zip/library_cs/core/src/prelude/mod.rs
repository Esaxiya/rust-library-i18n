//! Libcore prelude
//!
//! Tento modul je určen pro uživatele libcore, kteří také neodkazují na libstd.
//! Tento modul se ve výchozím nastavení importuje, když se `#![no_std]` používá stejným způsobem jako standardní knihovna prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Verze 2015 jádra prelude.
///
/// Další informace najdete v [module-level documentation](self).
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Verze 2018 jádra prelude.
///
/// Další informace najdete v [module-level documentation](self).
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Verze 2021 jádra prelude.
///
/// Další informace najdete v [module-level documentation](self).
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Přidejte další věci.
}