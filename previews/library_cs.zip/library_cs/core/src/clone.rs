//! `Clone` trait pro typy, které nelze " implicitně zkopírovat`.
//!
//! V Rust jsou některé jednoduché typy "implicitly copyable" a když je přiřadíte nebo předáte jako argumenty, přijímač získá kopii a ponechá původní hodnotu na místě.
//! Tyto typy nevyžadují přidělení ke kopírování a nemají finalizátory (tj. Neobsahují vlastněná pole ani implementují [`Drop`]), takže kompilátor je považuje za levné a bezpečné kopírování.
//!
//! U ostatních typů musí být kopie vytvořeny explicitně podle konvence implementující [`Clone`] trait a voláním metody [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Základní příklad použití:
//!
//! ```
//! let s = String::new(); // Řetězcový typ implementuje Clone
//! let copy = s.clone(); // abychom to mohli naklonovat
//! ```
//!
//! Pro snadnou implementaci Clone trait můžete také použít `#[derive(Clone)]`.Příklad:
//!
//! ```
//! #[derive(Clone)] // přidáme Clone trait do struktury Morpheus
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // a nyní to můžeme naklonovat!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Běžný trait pro schopnost explicitně duplikovat objekt.
///
/// Liší se od [`Copy`] v tom, že [`Copy`] je implicitní a extrémně levný, zatímco `Clone` je vždy explicitní a může nebo nemusí být drahý.
/// Za účelem prosazení těchto vlastností vám Rust neumožňuje znovu implementovat [`Copy`], ale můžete znovu implementovat `Clone` a spustit libovolný kód.
///
/// Vzhledem k tomu, že `Clone` je obecnější než [`Copy`], můžete z [`Copy`] automaticky udělat i `Clone`.
///
/// ## Derivable
///
/// Tuto trait lze použít s `#[derive]`, pokud jsou všechna pole `Clone`." Odvozená` implementace [`Clone`] volá [`clone`] na každém poli.
///
/// [`clone`]: Clone::clone
///
/// U obecné struktury `#[derive]` implementuje `Clone` podmíněně přidáním vázaného `Clone` k obecným parametrům.
///
/// ```
/// // `derive` implementuje Clone pro čtení<T>když T je Klon.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Jak mohu implementovat `Clone`?
///
/// Typy, které jsou [`Copy`], by měly mít triviální implementaci `Clone`.Více formálně:
/// pokud `T: Copy`, `x: T` a `y: &T`, pak `let x = y.clone();` je ekvivalentní `let x = *y;`.
/// Ruční implementace by měly být opatrné, aby se zachoval tento invariant;nebezpečný kód se však na něj nesmí spoléhat, aby zajistil bezpečnost paměti.
///
/// Příkladem je obecná struktura obsahující ukazatel funkce.V tomto případě nelze implementaci `Clone` odvodit, ale lze ji implementovat jako:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Další implementátoři
///
/// Kromě [implementors listed below][impls] implementují následující typy také `Clone`:
///
/// * Typy funkčních položek (tj. Odlišné typy definované pro každou funkci)
/// * Typy ukazatelů funkcí (např. `fn() -> i32`)
/// * Typy polí pro všechny velikosti, pokud typ položky implementuje také `Clone` (např. `[i32; 123456]`)
/// * Typy n-tic, pokud každá komponenta také implementuje `Clone` (např. `()`, `(i32, bool)`)
/// * Uzávěrové typy, pokud nezachycují žádnou hodnotu z prostředí nebo pokud všechny takové zachycené hodnoty implementují `Clone` samy.
///   Všimněte si, že proměnné zachycené sdílenou referencí vždy implementují `Clone` (i když referent ne), zatímco proměnné zachycené proměnlivou referencí nikdy neimplementují `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Vrátí kopii hodnoty.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str implementuje Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Provede přiřazení kopírování z `source`.
    ///
    /// `a.clone_from(&b)` je ekvivalentní `a = b.clone()` ve funkčnosti, ale může být přepsán, aby se znovu použily prostředky `a`, aby se zabránilo zbytečnému přidělení.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Odvozte makro generující impl z trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): tyto struktury používá výhradně#[odvodit] k tvrzení, že každá součást typu implementuje Clone nebo Copy.
//
//
// Tyto struktury by se nikdy neměly objevit v uživatelském kódu.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implementace `Clone` pro primitivní typy.
///
/// Implementace, které nelze popsat v Rust, jsou implementovány v `traits::SelectionContext::copy_clone_conditions()` v `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Sdílené odkazy lze klonovat, ale měnitelné odkazy *nemohou*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Sdílené odkazy lze klonovat, ale měnitelné odkazy *nemohou*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}