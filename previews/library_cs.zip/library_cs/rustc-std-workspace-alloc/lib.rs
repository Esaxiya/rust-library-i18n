#![feature(no_core)]
#![no_core]

// Proč je tato crate potřeba, viz rustc-std-workspace-core.

// Přejmenujte crate, abyste se vyhnuli konfliktu s alokačním modulem v liballoc.
extern crate alloc as foo;

pub use foo::*;