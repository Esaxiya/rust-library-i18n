//! Implementace Rust panics prostřednictvím přerušení procesu
//!
//! Ve srovnání s implementací pomocí odvíjení je tento crate *mnohem* jednodušší!Jak již bylo řečeno, není to tak všestranné, ale tady to jde!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" užitečné zatížení a podložku k příslušnému přerušení na dané platformě.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // volejte std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Na Windows použijte mechanismus __fastfail specifický pro procesor.V Windows 8 a novějších to proces okamžitě ukončí bez spuštění jakýchkoli obslužných rutin výjimek v procesu.
            // V dřívějších verzích Windows bude tato posloupnost pokynů považována za narušení přístupu, které ukončí proces, ale bez nutného obejití všech obslužných rutin výjimek.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: toto je stejná implementace jako v lib0000 `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// To ... je trochu zvláštnost.Tl; dr;je to, že je to nutné pro správné propojení, delší vysvětlení je níže.
//
// Právě teď jsou všechny binární soubory libcore/libstd, které dodáváme, kompilovány s `-C panic=unwind`.Tím je zajištěno, že binární soubory jsou maximálně kompatibilní s co největším počtem situací.
// Kompilátor však vyžaduje "personality function" pro všechny funkce kompilované s `-C panic=unwind`.Tato funkce osobnosti je napevno zakódována na symbol `rust_eh_personality` a je definována položkou jazyka `eh_personality`.
//
// So...
// proč tu nedefinovat tu položku lang?Dobrá otázka!Způsob, jakým jsou runtime panic propojeny, je ve skutečnosti trochu subtilní v tom, že jsou "sort of" v obchodě crate kompilátoru, ale pouze ve skutečnosti propojeny, pokud jiný není ve skutečnosti propojen.
//
// To nakonec znamená, že jak tento crate, tak panic_unwind crate se mohou objevit v obchodě crate kompilátoru, a pokud oba definují položku jazyka `eh_personality`, pak dojde k chybě.
//
// Aby to zvládl, kompilátor vyžaduje pouze definici `eh_personality`, pokud je runtime panic, ke kterému je připojen, odvíjecí runtime, a jinak není nutné jej definovat (právem).
// V tomto případě však tato knihovna tento symbol pouze definuje, takže někde je alespoň nějaká osobnost.
//
// Tento symbol je v podstatě definován tak, aby umožňoval připojení až k binárním souborům libcore/libstd, ale nikdy by neměl být volán, protože vůbec neodpojujeme v odvíjecím modulu.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Na x86_64-pc-windows-gnu používáme naši vlastní osobnostní funkci, která potřebuje vrátit `ExceptionContinueSearch`, když předáváme všechny naše rámce.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Podobně jako výše odpovídá položka jazyka `eh_catch_typeinfo`, která se aktuálně používá pouze v Emscriptenu.
    //
    // Vzhledem k tomu, že panics negeneruje výjimky a zahraniční výjimky jsou aktuálně UB s -C panic=abort (i když se to může změnit), jakákoli volání catch_unwind nikdy nebudou používat tento typeinfo.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Tyto dva jsou volány našimi spouštěcími objekty na i686-pc-windows-gnu, ale nepotřebují nic dělat, takže těla jsou nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}