# Přispívání do stdarch

`stdarch` crate je více než ochoten přijímat příspěvky!Nejprve budete pravděpodobně chtít zkontrolovat úložiště a ujistit se, že testy projdou za vás:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Kde `<your-target-arch>` je trojitý terč, jak ho používá `rustup`, např. `x86_x64-unknown-linux-gnu` (bez předchozího `nightly-` nebo podobného).
Pamatujte také, že toto úložiště vyžaduje noční kanál Rust!
Výše uvedené testy ve skutečnosti vyžadují, aby byla ve vašem systému jako výchozí nastavena noční rust, aby bylo možné nastavit použití `rustup default nightly` (a `rustup default stable` pro návrat).

Pokud některý z výše uvedených kroků nefunguje, [please let us know][new]!

Dále vám můžeme pomoci [find an issue][issues], vybrali jsme několik značek [`help wanted`][help] a [`impl-period`][impl], které by mohly obzvláště využít nějakou nápovědu. 
Možná vás bude nejvíce zajímat [#40][vendor], implementující všechny vnitřní vlastnosti dodavatele na x86.Toto číslo má několik dobrých rad o tom, kde začít!

Pokud máte obecné otázky, neváhejte se [join us on gitter][gitter] a zeptejte se!Neváhejte pingat dotazy na@BurntSushi nebo@alexcrichton.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Jak psát příklady pro stdarch intrinsics

Existuje několik funkcí, které musí být povoleny, aby daná vnitřní funkce správně fungovala, a příklad musí být spuštěn pouze `cargo test --doc`, když je tato funkce podporována CPU.

Výsledkem je, že výchozí `fn main` generovaný `rustdoc` nebude fungovat (ve většině případů).
Zvažte použití následujících pokynů, abyste zajistili, že váš příklad funguje podle očekávání.

```rust
/// # // Potřebujeme cfg_target_feature, abychom zajistili, že příklad je pouze
/// # // spuštěno `cargo test --doc`, když CPU tuto funkci podporuje
/// # #![feature(cfg_target_feature)]
/// # // Potřebujeme target_feature, aby vnitřní fungoval
/// # #![feature(target_feature)]
/// #
/// # // rustdoc standardně používá `extern crate stdarch`, ale my potřebujeme
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Skutečná hlavní funkce
/// # fn main() {
/// #     // Spusťte to pouze v případě, že je podporována `<target feature>`
/// #     pokud cfg_feature_enabled! ("<target feature>"){
/// #         // Vytvořte funkci `worker`, která bude spuštěna pouze v případě, že je cílovým prvkem
/// #         // je podporován a ujistěte se, že je pro vašeho pracovníka povoleno `target_feature`
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         nebezpečné fn worker() {
/// // Sem napište svůj příklad.Zde bude fungovat funkce specifické pro funkce!Jděte divoce!
///
/// #         }
///
/// #         nebezpečné { worker(); }
/// #     }
/// # }
```

Pokud některá z výše uvedených syntaxí nevypadá dobře, část [Documentation as tests] v [Rust Book] popisuje syntaxi `rustdoc` docela dobře.
Jako vždy, neváhejte na [join us on gitter][gitter] a zeptejte se nás, jestli narazíte na nějaké problémy, a děkujeme vám za pomoc při vylepšování dokumentace `stdarch`!

# Alternativní pokyny k testování

Obecně se doporučuje, abyste ke spuštění testů použili `ci/run.sh`.
To vám však nemusí fungovat, např. Pokud používáte Windows.

V takovém případě se můžete vrátit k běhu `cargo +nightly test` a `cargo +nightly test --release -p core_arch` pro testování generování kódu.
Všimněte si, že to vyžaduje instalaci nočního nástrojového řetězce a aby `rustc` věděl o vašem cílovém triple a jeho CPU.
Zejména musíte nastavit proměnnou prostředí `TARGET` stejně jako pro `ci/run.sh`.
Kromě toho musíte nastavit `RUSTCFLAGS` (potřebujete `C`) k označení cílových funkcí, např `RUSTCFLAGS="-C -target-features=+avx2"`.
Můžete také nastavit `-C -target-cpu=native`, pokud vyvíjíte "just" proti vašemu aktuálnímu CPU.

Upozorňujeme, že když použijete tyto alternativní pokyny, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], např
testy generování instrukcí mohou selhat, protože je disassembler pojmenoval odlišně, např
může generovat `vaesenc` místo instrukcí `aesenc`, přestože se chovají stejně.
Tyto pokyny také provádějí méně testů, než by se normálně dělaly, takže se nedivte, že když nakonec vyžádáte vyžádání, mohou se u zde neuvedených testů zobrazit některé chyby.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






