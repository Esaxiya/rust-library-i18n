use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Používá se k tomu, abychom řekli našim anotacím `#[assert_instr]`, že jsou k dispozici všechny simd intrinsics pro testování jejich codegen, protože některé jsou brány za extra `-Ctarget-feature=+unimplemented-simd128`, který právě nemá ekvivalent v `#[target_feature]`.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}