`core::arch` - Základní vlastnosti specifické pro architekturu knihovny Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Modul `core::arch` implementuje vnitřní architektury závislé (např. SIMD).

# Usage 

`core::arch` je k dispozici jako součást `libcore` a je znovu exportován `libstd`.Dávejte přednost použití přes `core::arch` nebo `std::arch` než přes tento crate.
Nestabilní funkce jsou často k dispozici v nočních Rust prostřednictvím `feature(stdsimd)`.

Používání `core::arch` přes tento crate vyžaduje noční Rust a může se (a dělá) často zlomit.Jediné případy, kdy byste měli zvážit jeho použití prostřednictvím této crate, jsou:

* pokud potřebujete překompilovat `core::arch` sami, např. se zapnutými konkrétními cílovými funkcemi, které nejsou povoleny pro `libcore`/`libstd`.
Note: pokud jej potřebujete znovu zkompilovat pro nestandardní cíl, raději použijte `xargo` a případně znovu sestavte `libcore`/`libstd` místo použití tohoto crate.
  
* pomocí některých funkcí, které nemusí být k dispozici ani za nestabilními funkcemi Rust.Snažíme se je omezit na minimum.
Pokud potřebujete použít některé z těchto funkcí, otevřete problém, abychom je mohli vystavit v nočním Rust a odtud je můžete používat.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` je primárně distribuován za podmínek jak licence MIT, tak licence Apache (verze 2.0), s částmi krytými různými licencemi podobnými BSD.

Podrobnosti viz LICENSE-APACHE a LICENSE-MIT.

# Contribution

Pokud výslovně nestanovíte jinak, jakýkoli příspěvek, který jste úmyslně předložili k zařazení do `core_arch`, jak je definován v licenci Apache-2.0, bude mít dvojí licenci, jak je uvedeno výše, bez jakýchkoli dalších podmínek.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












