# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Knihovna pro získávání zpětných stop za běhu pro Rust.
Tato knihovna si klade za cíl zvýšit podporu standardní knihovny poskytnutím programatického rozhraní pro práci, ale také podporuje jednoduše snadný tisk aktuálního backtrace jako libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Chcete-li jednoduše zachytit backtrace a odložit jednání s ním na později, můžete použít typ `Backtrace` nejvyšší úrovně.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Pokud byste však chtěli více surového přístupu ke skutečné funkčnosti trasování, můžete přímo použít funkce `trace` a `resolve`.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Vyřešte tento ukazatel instrukce na název symbolu
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // pokračujte k dalšímu snímku
    });
}
```

# License

Tento projekt je licencován na základě jedné z těchto licencí

 * Licence Apache, verze 2.0, ([LICENSE-APACHE](LICENSE-APACHE) nebo http://www.apache.org/licenses/LICENSE-2.0)
 * Licence MIT ([LICENSE-MIT](LICENSE-MIT) nebo http://opensource.org/licenses/MIT)

podle vašeho výběru.

### Contribution

Pokud výslovně nestanovíte jinak, bude jakýkoli váš příspěvek záměrně odeslaný k zařazení do backtrace-rs, jak je definován v licenci Apache-2.0, licencován dvojím způsobem, jak je uvedeno výše, bez jakýchkoli dalších podmínek.







