use backtrace::Backtrace;

// Tento test funguje pouze na platformách, které mají funkční funkci `symbol_address` pro rámce, které hlásí počáteční adresu symbolu.
// Ve výsledku je povolen pouze na několika platformách.
//
const ENABLED: bool = cfg!(all(
    // Windows nebyl ve skutečnosti testován a OSX nepodporuje skutečné hledání ohraničujícího rámečku, takže toto zakažte
    //
    target_os = "linux",
    // Na ARM hledání obklopující funkce jednoduše vrátí samotnou ip.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}