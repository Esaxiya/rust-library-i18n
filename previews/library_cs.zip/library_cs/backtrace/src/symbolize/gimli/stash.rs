// používá se právě teď na Linux, takže povolte mrtvý kód jinde
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Jednoduchý alokátor arény pro vyrovnávací paměti bajtů.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Přidělí vyrovnávací paměť zadané velikosti a vrátí k ní proměnlivý odkaz.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // BEZPEČNOST: toto je jediná funkce, která kdy vytvoří proměnlivý
        // odkaz na `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // BEZPEČNOST: nikdy neodstraňujeme prvky z `self.buffers`, takže odkaz
        // k datům uvnitř jakékoli vyrovnávací paměti bude žít tak dlouho, jak to bude dělat `self`.
        &mut buffers[i]
    }
}