use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Vyřešte adresu na symbol předáním symbolu do zadaného uzavření.
///
/// Tato funkce vyhledá danou adresu v oblastech, jako je tabulka místních symbolů, dynamická tabulka symbolů nebo informace o ladění DWARF (v závislosti na aktivované implementaci), aby našla symboly, které se mají získat.
///
///
/// Uzavření nemusí být voláno, pokud nelze provést rozlišení, a může být také voláno více než jednou v případě vložených funkcí.
///
/// Získané symboly představují provedení na zadaném `addr`, vrací file/line páry pro danou adresu (pokud je k dispozici).
///
/// Všimněte si, že pokud máte `Frame`, doporučuje se místo tohoto použít funkci `resolve_frame`.
///
/// # Požadované funkce
///
/// Tato funkce vyžaduje povolení funkce `std` u `backtrace` crate a funkce `std` je ve výchozím nastavení povolena.
///
/// # Panics
///
/// Tato funkce se snaží nikdy panic, ale pokud `cb` poskytla panics, pak některé platformy vynutí dvojitý panic k přerušení procesu.
/// Některé platformy používají knihovnu C, která interně používá zpětná volání, která nelze odmotat, takže panikaření z `cb` může způsobit přerušení procesu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // podívejte se pouze na horní rám
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Vyřešte dříve zachycený snímek na symbol a předejte symbol do zadaného uzavření.
///
/// Tento functin plní stejnou funkci jako `resolve` kromě toho, že místo adresy bere `Frame` jako argument.
/// To může umožnit některým implementacím platformy zpětného trasování poskytnout přesnější informace o symbolech nebo například informace o vložených rámcích.
///
/// Doporučuje se to použít, pokud můžete.
///
/// # Požadované funkce
///
/// Tato funkce vyžaduje povolení funkce `std` u `backtrace` crate a funkce `std` je ve výchozím nastavení povolena.
///
/// # Panics
///
/// Tato funkce se snaží nikdy panic, ale pokud `cb` poskytla panics, pak některé platformy vynutí dvojitý panic k přerušení procesu.
/// Některé platformy používají knihovnu C, která interně používá zpětná volání, která nelze odmotat, takže panikaření z `cb` může způsobit přerušení procesu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // podívejte se pouze na horní rám
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Hodnoty IP ze rámců zásobníku jsou obvykle (always?) instrukce *po* volání, která je skutečným trasováním zásobníku.
// Symbolizující toto způsobí, že číslo filename/line bude o jedno dopředu a možná do prázdna, pokud je blízko konce funkce.
//
// Zdá se, že to v zásadě vždy platí na všech platformách, takže vždy odečteme jeden z vyřešeného ip, abychom jej vyřešili na předchozí instrukci volání namísto instrukce, která se vrací.
//
//
// V ideálním případě bychom to neudělali.
// V ideálním případě bychom od volajících API `resolve` vyžadovali, aby ručně provedli -1 a účet, který chtějí informace o poloze pro *předchozí* instrukci, ne aktuální.
// V ideálním případě bychom také vystavili na `Frame`, pokud jsme skutečně adresou další instrukce nebo proudu.
//
// Prozatím je to ale docela problém, takže vždy interně jeden odečteme.
// Spotřebitelé by měli pokračovat v práci a dosahovat docela dobrých výsledků, takže bychom měli být dost dobří.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Stejné jako `resolve`, pouze nebezpečné, protože je nesynchronizované.
///
/// Tato funkce nemá zaručené synchronizace, ale je k dispozici, když funkce `std` tohoto crate není kompilována.
/// Další funkce a příklady najdete ve funkci `resolve`.
///
/// # Panics
///
/// Viz informace o `resolve`, kde najdete upozornění na paniku `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Stejné jako `resolve_frame`, pouze nebezpečné, protože je nesynchronizované.
///
/// Tato funkce nemá zaručené synchronizace, ale je k dispozici, když funkce `std` tohoto crate není kompilována.
/// Další funkce a příklady najdete ve funkci `resolve_frame`.
///
/// # Panics
///
/// Viz informace o `resolve_frame`, kde najdete upozornění na paniku `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait představující rozlišení symbolu v souboru.
///
/// Tento trait je získán jako objekt trait uzávěru danému funkci `backtrace::resolve` a je prakticky odeslán, protože není známo, která implementace je za ním.
///
///
/// Symbol může poskytnout kontextové informace o funkci, například název, název souboru, číslo řádku, přesnou adresu atd.
/// Ne všechny informace jsou vždy k dispozici v symbolu, takže všechny metody vracejí `Option`.
///
///
pub struct Symbol {
    // TODO: toto doživotní vázání je třeba přetrvávat nakonec na `Symbol`,
    // ale to je momentálně zlomová změna.
    // Prozatím je to bezpečné, protože `Symbol` se rozdává pouze jako reference a nelze jej klonovat.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Vrátí název této funkce.
    ///
    /// Vrácenou strukturu lze použít k dotazování různých vlastností názvu symbolu:
    ///
    ///
    /// * Implementace `Display` vytiskne demangled symbol.
    /// * Je možné získat surovou hodnotu `str` symbolu (pokud je platná utf-8).
    /// * Je možné získat surové bajty pro název symbolu.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Vrátí počáteční adresu této funkce.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Vrátí nezpracovaný název souboru jako řez.
    /// To je užitečné zejména pro prostředí `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Vrátí číslo sloupce, kde se tento symbol aktuálně provádí.
    ///
    /// Pouze gimli zde aktuálně poskytuje hodnotu a dokonce i tehdy, pouze pokud `filename` vrátí `Some`, a proto je následně předmětem podobných upozornění.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Vrátí číslo řádku, kde se tento symbol aktuálně provádí.
    ///
    /// Tato návratová hodnota je obvykle `Some`, pokud `filename` vrací `Some`, a proto podléhá podobným výhradám.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Vrátí název souboru, kde byla tato funkce definována.
    ///
    /// To je v současné době k dispozici pouze při použití libbacktrace nebo gimli (např
    /// unix jiné platformy) a když je binární soubor zkompilován s debuginfo.
    /// Pokud není splněna žádná z těchto podmínek, pravděpodobně to vrátí `None`.
    ///
    /// # Požadované funkce
    ///
    /// Tato funkce vyžaduje povolení funkce `std` u `backtrace` crate a funkce `std` je ve výchozím nastavení povolena.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Možná analyzovaný symbol C++ , pokud analýza rozbitého symbolu jako Rust selhala.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Nezapomeňte zachovat tuto nulovou velikost, aby funkce `cpp_demangle` neměla při deaktivaci žádné náklady.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Obálka kolem názvu symbolu, která poskytuje ergonomické přístupy k demanglovanému názvu, hrubým bajtům, hrubému řetězci atd.
///
// Pokud není funkce `cpp_demangle` povolena, povolte mrtvý kód.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Vytvoří nový název symbolu ze surových podkladových bajtů.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Vrátí nezpracovaný název symbolu (mangled) jako `str`, pokud je symbol platný utf-8.
    ///
    /// Pokud chcete demangled verzi, použijte implementaci `Display`.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Vrátí nezpracovaný název symbolu jako seznam bajtů
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // To může být vytištěno, pokud demangled symbol není ve skutečnosti platný, takže tu chybu vyřešte elegantně tím, že ji nebudete šířit ven.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Pokuste se získat zpět tuto mezipaměť používanou k symbolizaci adres.
///
/// Tato metoda se pokusí uvolnit jakékoli globální datové struktury, které byly jinak uloženy globálně do mezipaměti nebo do vlákna, které obvykle představují analyzované informace DWARF nebo podobné.
///
///
/// # Caveats
///
/// I když je tato funkce vždy k dispozici, ve většině implementací vlastně nedělá nic.
/// Knihovny jako dbghelp nebo libbacktrace neposkytují zařízení k uvolnění stavu a správě přidělené paměti.
/// Pro tuto chvíli je funkce `gimli-symbolize` této crate jedinou funkcí, kde má tato funkce nějaký účinek.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}