//! Strategie symbolizace pomocí kódu pro analýzu DWARF v libbacktrace.
//!
//! Knihovna libbacktrace C, obvykle distribuovaná se gcc, podporuje nejen generování backtrace (které ve skutečnosti nepoužíváme), ale také symbolizuje backtrace a zpracovává trpasličí ladicí informace o věcech, jako jsou vložené rámy a co ne.
//!
//!
//! To je poměrně složité kvůli mnoha různým obavám, ale základní myšlenka je:
//!
//! * Nejprve voláme `backtrace_syminfo`.Pokud je to možné, získá se informace o symbolech z dynamické tabulky symbolů.
//! * Dále voláme `backtrace_pcinfo`.To bude analyzovat tabulky ladění, pokud jsou k dispozici, a umožní nám obnovit informace o vložených rámcích, názvech souborů, číslech řádků atd.
//!
//! Existuje spousta triků, jak dostat trpasličí tabulky do libbacktrace, ale doufejme, že to není konec světa a je při čtení níže dostatečně jasný.
//!
//! Toto je výchozí strategie symbolizace pro platformy jiné než MSVC a jiné než OSX.V libstd je to ale výchozí strategie pro OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Pokud je to možné, upřednostňujte název `function`, který pochází z debuginfo a může být obvykle přesnější například pro vložené snímky.
                // Pokud to není k dispozici, přejděte zpět na název tabulky symbolů uvedený v `symname`.
                //
                // Všimněte si, že `function` se někdy může cítit poněkud méně přesný, například když je uveden jako `try<i32,closure>`, není `std::panicking::try::do_call`.
                //
                // Není úplně jasné proč, ale celkově se název `function` zdá přesnější.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // zatím nic nedělej
}

/// Typ ukazatele `data` předaný do `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Jakmile je toto zpětné volání vyvoláno z `backtrace_syminfo`, když začneme řešit, přejdeme dále k volání `backtrace_pcinfo`.
    // Funkce `backtrace_pcinfo` bude konzultovat informace o ladění a pokusí se dělat věci, jako je obnovení informací file/line i vložených rámců.
    // Všimněte si však, že `backtrace_pcinfo` může selhat nebo neudělat moc, pokud nejsou k dispozici informace o ladění, takže pokud k tomu dojde, určitě zavoláme zpětné volání s alespoň jedním symbolem z `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Typ ukazatele `data` předaný do `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Rozhraní libbacktrace API podporuje vytváření stavu, ale nepodporuje zničení stavu.
// Osobně to chápu tak, že stát má být vytvořen a poté žít navždy.
//
// Rád bych zaregistroval obslužnou rutinu at_exit(), která tento stav vyčistí, ale libbacktrace k tomu neposkytuje žádný způsob.
//
// S těmito omezeními má tato funkce staticky stav v mezipaměti, který se vypočítá při prvním požadavku.
//
// Nezapomeňte, že zpětné sledování všeho se děje sériově (jeden globální zámek).
//
// Upozorňujeme, že nedostatek synchronizace zde je způsoben požadavkem na externí synchronizaci `resolve`.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Neprovádějte bezpečné funkce libbacktrace, protože jej vždy voláme synchronizovaným způsobem.
        //
        0,
        error_cb,
        ptr::null_mut(), // žádná další data
    );

    return STATE;

    // Všimněte si, že aby libbacktrace vůbec fungoval, musí najít informace o ladění DWARF pro aktuální spustitelný soubor.Obvykle to dělá prostřednictvím řady mechanismů, mimo jiné včetně:
    //
    // * /proc/self/exe na podporovaných platformách
    // * Název souboru byl předán explicitně při vytváření stavu
    //
    // Knihovna libbacktrace je velká skupina kódu C.To přirozeně znamená, že má chyby zabezpečení paměti, zejména při zpracování chybně laděného ladění.
    // Libstd se s nimi historicky setkal.
    //
    // Pokud se používá /proc/self/exe, můžeme je obvykle ignorovat, protože předpokládáme, že libbacktrace je "mostly correct" a jinak nedělá divné věci s informacemi o ladění trpaslíků "attempted to be correct".
    //
    //
    // Pokud však předáme název souboru, je to možné na některých platformách (jako BSD), kde může nebezpečný herec způsobit umístění libovolného souboru na dané místo.
    // To znamená, že když řekneme libbacktrace o názvu souboru, může používat libovolný soubor, což může způsobit segfaults.
    // Pokud však libbacktrace nic neřekneme, nebude to dělat nic na platformách, které nepodporují cesty jako /proc/self/exe!
    //
    // Vzhledem k tomu, že se snažíme co nejvíce snažit se *not* předat název souboru, ale musíme na platformách, které /proc/self/exe vůbec nepodporují.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Všimněte si, že v ideálním případě bychom použili `std::env::current_exe`, ale zde nemůžeme vyžadovat `std`.
            //
            // Použijte `_NSGetExecutablePath` k načtení aktuální spustitelné cesty do statické oblasti (které, pokud je příliš malé, vzdejte se).
            //
            //
            // Všimněte si, že zde vážně důvěřujeme libbacktrace, abychom nezemřeli na poškozené spustitelné soubory, ale určitě ano ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows má režim otevírání souborů, kde jej po otevření nelze odstranit.
            // To je obecně to, co zde chceme, protože chceme zajistit, aby se náš spustitelný soubor nezměnil zpod nás poté, co jsme jej předali libbacktrace, doufejme, že zmírní schopnost předávat libovolná data do libbacktrace (což může být nesprávně zpracováno).
            //
            //
            // Vzhledem k tomu, že zde trochu tancujeme, abychom se pokusili získat jakýsi zámek na náš vlastní obraz:
            //
            // * Získejte popis k aktuálnímu procesu, načtěte jeho název souboru.
            // * Otevřete soubor s tímto názvem se správnými příznaky.
            // * Znovu načtěte název souboru aktuálního procesu a ujistěte se, že je stejný
            //
            // Pokud to všechno projde, teoreticky jsme skutečně otevřeli soubor našeho procesu a máme záruku, že se to nezmění.FWIW spousta z toho je zkopírována z libstd historicky, takže toto je moje nejlepší interpretace toho, co se dělo.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Toto žije ve statické paměti, abychom jej mohli vrátit ..
                static mut BUF: [i8; N] = [0; N];
                // ... a toto žije v zásobníku, protože je to dočasné
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // záměrně sem propustit `handle`, protože otevření by mělo zachovat náš zámek tohoto názvu souboru.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Chceme vrátit řez, který je zakončen nulou, takže pokud bylo vše vyplněno a rovná se celkové délce, pak to přirovnáme k selhání.
                //
                //
                // V opačném případě se při návratu úspěchu ujistěte, že je v řezu zahrnut nul bajt.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // chyby backtrace jsou v současné době zameteny pod koberec
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Zavolejte API `backtrace_syminfo`, které (od načtení kódu) by mělo volat `syminfo_cb` přesně jednou (nebo pravděpodobně selže s chybou).
    // V `syminfo_cb` pak zvládneme více.
    //
    // Všimněte si, že to děláme, protože `syminfo` bude konzultovat tabulku symbolů a vyhledávat názvy symbolů, i když v binárním souboru nejsou žádné informace o ladění.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}