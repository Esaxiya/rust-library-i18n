use core::ffi::c_void;
use core::fmt;

/// Zkontroluje aktuální zásobník volání a předá všechny aktivní rámce do zadaného uzávěru k výpočtu trasování zásobníku.
///
/// Tato funkce je tahounem této knihovny při výpočtu trasování zásobníku pro program.Daný uzávěr `cb` je získán instancí `Frame`, které představují informace o tomto volacím rámci v zásobníku.
/// Uzávěrem se získá rámce shora dolů (naposledy nazývané funkce jako první).
///
/// Návratová hodnota uzávěru je údaj o tom, zda má zpětný chod pokračovat.Návratová hodnota `false` ukončí zpětný chod a vrátí se okamžitě.
///
/// Jakmile je `Frame` získán, budete pravděpodobně chtít zavolat `backtrace::resolve` a převést `ip` (instrukční ukazatel) nebo adresu symbolu na `Symbol`, pomocí kterého lze zjistit jméno a/nebo název souboru/číslo linky.
///
///
/// Všimněte si, že se jedná o funkci relativně nízké úrovně a pokud byste například chtěli zachytit backtrace, který bude zkontrolován později, může být vhodnější typ `Backtrace`.
///
/// # Požadované funkce
///
/// Tato funkce vyžaduje povolení funkce `std` u `backtrace` crate a funkce `std` je ve výchozím nastavení povolena.
///
/// # Panics
///
/// Tato funkce se snaží nikdy panic, ale pokud `cb` poskytla panics, pak některé platformy vynutí dvojitý panic k přerušení procesu.
/// Některé platformy používají knihovnu C, která interně používá zpětná volání, která nelze odmotat, takže panikaření z `cb` může způsobit přerušení procesu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // pokračovat ve stopě
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Stejné jako `trace`, pouze nebezpečné, protože je nesynchronizované.
///
/// Tato funkce nemá zaručené synchronizace, ale je k dispozici, když funkce `std` tohoto crate není kompilována.
/// Další funkce a příklady najdete ve funkci `trace`.
///
/// # Panics
///
/// Viz informace o `trace`, kde najdete upozornění na paniku `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait představující jeden snímek backtrace, poskytnutý funkci `trace` tohoto crate.
///
/// Uzavřením funkce trasování budou získány rámce a rám je prakticky odeslán, protože základní implementace není vždy známa až za běhu.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Vrátí aktuální ukazatel instrukce tohoto rámce.
    ///
    /// Toto je obvykle další instrukce, která se má provést v rámci, ale ne všechny implementace uvádějí tento seznam se 100% přesností (ale obecně je to docela blízko).
    ///
    ///
    /// Doporučuje se předat tuto hodnotu `backtrace::resolve`, aby se změnila na název symbolu.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Vrátí aktuální ukazatel zásobníku tohoto rámečku.
    ///
    /// V případě, že backend nemůže obnovit ukazatel zásobníku pro tento rámec, je vrácen nulový ukazatel.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Vrátí počáteční adresu symbolu rámce této funkce.
    ///
    /// To se pokusí převinout ukazatel instrukce vrácený `ip` na začátek funkce a vrátit tuto hodnotu.
    ///
    /// V některých případech však back-endy pouze vrátí `ip` z této funkce.
    ///
    /// Vrácená hodnota může být někdy použita, pokud `backtrace::resolve` selhal na `ip` uvedeném výše.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Vrátí základní adresu modulu, ke kterému rámec patří.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // To musí být na prvním místě, aby bylo zajištěno, že Miri má přednost před hostitelskou platformou
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // použito pouze v dbghelp symbolizuje
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}