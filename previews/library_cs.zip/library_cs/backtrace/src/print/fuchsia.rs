use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr provede zpětné volání, které obdrží ukazatel dl_phdr_info pro každý DSO, který byl propojen do procesu.
    // dl_iterate_phdr také zajišťuje, že dynamický linker je uzamčen od začátku do konce iterace.
    // Pokud zpětné volání vrátí nenulovou hodnotu, iterace je ukončena dříve.
    // 'data' bude předáno jako třetí argument zpětnému volání při každém volání.
    // 'size' udává velikost dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Musíme analyzovat ID sestavení a některá základní data záhlaví programu, což znamená, že potřebujeme také něco ze specifikace ELF.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Nyní musíme bit za bitem replikovat strukturu typu dl_phdr_info používanou aktuálním dynamickým linkerem fuchsie.
// Chromium má také tuto hranici ABI a crashpad.
// Nakonec bychom chtěli tyto případy přesunout, aby používaly elf-search, ale museli bychom to poskytnout v SDK a to ještě nebylo provedeno.
//
// Takže my (a oni) jsme uvízli, když musíme používat tuto metodu, která vede k těsnému spojení s fuchsií libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Nemáme žádný způsob, jak zjistit, zda jsou e_phoff a e_phnum platné.
    // libc by to pro nás měl zajistit, takže je bezpečné zde vytvořit plátek.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr představuje 64bitovou hlavičku programu ELF v endianness cílové architektury.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr představuje platnou hlavičku programu ELF a její obsah.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Nemáme žádný způsob, jak zkontrolovat, zda jsou p_addr nebo p_memsz platné.
    // Fuchsia's libc nejprve analyzuje noty, ale proto, že jsou zde, musí být tyto hlavičky platné.
    //
    // NoteIter nevyžaduje, aby byla podkladová data platná, ale vyžaduje, aby byly hranice platné.
    // Věříme, že libc zajistil, aby tomu tak bylo i zde.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Typ poznámky pro ID sestavení.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr představuje záhlaví poznámky ELF v endianness cíle.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Poznámka představuje poznámku ELF (záhlaví + obsah).
// Název je ponechán jako řez u8, protože není vždy ukončen hodnotou null a rust usnadňuje kontrolu, zda se bajty shodují.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter umožňuje bezpečně iterovat přes segment poznámky.
// Ukončí se, jakmile dojde k chybě nebo nejsou žádné další poznámky.
// Pokud iterujete přes neplatná data, bude fungovat, jako by nebyly nalezeny žádné poznámky.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Jedná se o invariant funkce, který udává ukazatel a velikost platný rozsah bajtů, které lze všechny číst.
    // Obsah těchto bajtů může být cokoli, ale rozsah musí být platný, aby to bylo bezpečné.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to zarovná 'x' na 'to' bajtové zarovnání za předpokladu, že 'to' je síla 2.
// Toto následuje standardní vzor v kódu analýzy ELF v C/C ++, kde se používá (x + to, 1)&-to.
// Rust vám nedovolí negovat použití, takže používám
// Převod doplňku 2 na jeho opětovné vytvoření.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 spotřebuje počet bajtů z řezu (je-li k dispozici) a navíc zajišťuje, aby byl konečný řez správně zarovnán.
// Pokud je buď požadovaný počet bajtů příliš velký, nebo řez nelze později znovu zarovnat kvůli nedostatku zbývajících bytů, vrátí se None a řez se nezmění.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Tato funkce nemá žádné skutečné invarianty, které musí volající dodržet, kromě toho, že 'bytes' by měl být zarovnán pro výkon (a na některých architekturách správnost).
// Hodnoty v polích Elf_Nhdr mohou být nesmysl, ale tato funkce nic takového nezajišťuje.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // To je bezpečné, pokud je dostatek místa a my jsme jen potvrdili, že ve výše uvedeném příkazu if by to nemělo být nebezpečné.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Všimněte si, že sice_of: :<Elf_Nhdr>() je vždy zarovnáno 4 bajty.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Zkontrolujte, zda jsme dospěli na konec.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Transmutujeme nhdr, ale pečlivě zvažujeme výslednou strukturu.
        // Nevěříme namesz ani descsz a na základě typu neděláme žádná nebezpečná rozhodnutí.
        //
        // Takže i kdybychom se dostali ven z úplného odpadu, měli bychom být stále v bezpečí.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Označuje, že segment je spustitelný.
const PERM_X: u32 = 0b00000001;
/// Označuje, že na segment lze zapisovat.
const PERM_W: u32 = 0b00000010;
/// Označuje, že segment je čitelný.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Představuje segment ELF za běhu.
struct Segment {
    /// Poskytuje runtime virtuální adresu obsahu tohoto segmentu.
    addr: usize,
    /// Udává velikost paměti obsahu tohoto segmentu.
    size: usize,
    /// Poskytne virtuální adresu modulu tohoto segmentu se souborem ELF.
    mod_rel_addr: usize,
    /// Poskytuje oprávnění nalezená v souboru ELF.
    /// Tato oprávnění však nemusí nutně představovat oprávnění přítomná za běhu.
    flags: Perm,
}

/// Umožňuje jednu iteraci nad segmenty z DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Představuje ELF DSO (Dynamic Shared Object).
/// Tento typ odkazuje na data uložená ve skutečném DSO namísto vytváření vlastní kopie.
struct Dso<'a> {
    /// Dynamický linker nám vždy dává jméno, i když je jméno prázdné.
    /// V případě hlavního spustitelného souboru bude toto jméno prázdné.
    /// V případě sdíleného objektu to bude soname (viz DT_SONAME).
    name: &'a str,
    /// Na Fuchsii mají prakticky všechny binární soubory ID sestavení, ale nejde o přísný požadavek.
    /// Neexistuje žádný způsob, jak poté porovnat informace DSO se skutečným souborem ELF, pokud neexistuje build_id, takže požadujeme, aby zde každý DSO měl jednu.
    ///
    /// DSO bez build_id jsou ignorovány.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Vrátí iterátor nad segmenty v tomto DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Tyto chyby kódují problémy, které vznikají při analýze informací o každém DSO.
///
enum Error {
    /// NameError znamená, že došlo k chybě při převodu řetězce ve stylu C na řetězec rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError znamená, že jsme nenašli ID sestavení.
    /// Může to být buď proto, že provozovatel distribuční soustavy neměl ID sestavení, nebo proto, že segment obsahující ID sestavení byl chybně vytvořen.
    ///
    BuildIDError,
}

/// Volá 'dso' nebo 'error' pro každé DSO propojené do procesu dynamickým linkerem.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter, který bude mít jednu z metod nazývaných foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr zajišťuje, že info.name bude ukazovat na platné místo.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Tato funkce vytiskne označení symbolizátoru Fuchsie pro všechny informace obsažené v DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}