//! Modul, který pomáhá při správě vazeb dbghelp na Windows
//!
//! Zpětné stopy na Windows (alespoň pro MSVC) jsou z velké části napájeny prostřednictvím `dbghelp.dll` a různých funkcí, které obsahuje.
//! Tyto funkce jsou aktuálně načítány *dynamicky* místo statického propojení s `dbghelp.dll`.
//! To v současné době provádí standardní knihovna (a teoreticky je tam vyžadována), ale je to snaha pomoci snížit statické závislosti dll knihovny, protože zpětné stopy jsou obvykle docela volitelné.
//!
//! Jak již bylo řečeno, `dbghelp.dll` se téměř vždy úspěšně načte na Windows.
//!
//! Všimněte si však, že protože načítáme veškerou tuto podporu dynamicky, nemůžeme ve skutečnosti použít surové definice v `winapi`, ale spíše musíme definovat typy ukazatelů funkcí sami a použít je.
//! Opravdu nechceme dělat duplikaci winapi, takže máme funkci Cargo `verify-winapi`, která tvrdí, že všechny vazby odpovídají těm ve winapi a tato funkce je povolena na CI.
//!
//! Nakonec si zde všimnete, že dll pro `dbghelp.dll` není nikdy uvolněn, a to je v současné době úmyslné.
//! Myšlenka spočívá v tom, že ji můžeme globálně ukládat do mezipaměti a používat ji mezi voláními API, abychom se vyhnuli nákladným loads/unloads.
//! Pokud je to problém pro detektory úniků nebo něco podobného, můžeme přejít most, když se tam dostaneme.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Pracujte na tom, že `SymGetOptions` a `SymSetOptions` nejsou přítomny v samotném winapi.
// Jinak se to používá pouze v případě, že dvakrát kontrolujeme typy proti winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Dosud není definováno ve winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // To je definováno ve winapi, ale je to nesprávné (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Dosud není definováno ve winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Toto makro se používá k definování struktury `Dbghelp`, která interně obsahuje všechny funkční ukazatele, které bychom mohli načíst.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Načtená knihovna DLL pro `dbghelp.dll`
            dll: HMODULE,

            // Každý ukazatel funkce pro každou funkci, kterou můžeme použít
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Zpočátku jsme nenačetli DLL
            dll: 0 as *mut _,
            // Na začátku jsou všechny funkce nastaveny na nulu, což znamená, že je třeba je dynamicky načíst.
            //
            $($name: 0,)*
        };

        // Pohodlí typedef pro každý typ funkce.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Pokusy o otevření `dbghelp.dll`.
            /// Vrátí úspěch, pokud to funguje, nebo chybu, pokud `LoadLibraryW` selže.
            ///
            /// Panics, pokud je knihovna již načtena.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Funkce pro každou metodu, kterou bychom chtěli použít.
            // Při volání buď načte ukazatel funkce v mezipaměti, nebo jej načte a vrátí načtenou hodnotu.
            // Zatížení se tvrdí, že uspějí.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Pohodlí proxy k použití zámků čištění k odkazování na funkce dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Inicializujte veškerou podporu potřebnou pro přístup k funkcím `dbghelp` API z této crate.
///
///
/// Tato funkce je **bezpečná**, má interně vlastní synchronizaci.
/// Všimněte si také, že je bezpečné volat tuto funkci vícekrát rekurzivně.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // První věcí, kterou musíme udělat, je synchronizovat tuto funkci.To lze volat souběžně z jiných vláken nebo rekurzivně v rámci jednoho vlákna.
        // Všimněte si, že je to složitější, protože to, co zde používáme, `dbghelp`,*také* je třeba synchronizovat se všemi ostatními volajícími do `dbghelp` v tomto procesu.
        //
        // Obvykle ve stejném procesu není tolik hovorů na `dbghelp` a pravděpodobně můžeme bezpečně předpokládat, že k němu přistupujeme pouze my.
        // Existuje však jeden primární další uživatel, kterého si musíme dělat starosti, a který jsme ironicky sami, ale ve standardní knihovně.
        // Standardní knihovna Rust závisí na této crate pro podporu backtrace a tato crate existuje také na crates.io.
        // To znamená, že pokud standardní knihovna tiskne zpáteční cestu panic, může závodit s tímto crate pocházejícím z crates.io, což způsobí segfaults.
        //
        // Abychom pomohli vyřešit tento problém se synchronizací, použijeme zde trik specifický pro Windows (je to koneckonců omezení synchronizace specifické pro Windows).
        // Pro ochranu tohoto volání vytvoříme *session-local* s názvem mutex.
        // Záměrem je, aby standardní knihovna a tento crate nemuseli sdílet API na úrovni Rust, aby se zde synchronizovali, ale místo toho mohou pracovat v zákulisí, aby se ujistili, že se synchronizují navzájem.
        //
        // Tímto způsobem, když je tato funkce volána prostřednictvím standardní knihovny nebo prostřednictvím crates.io, si můžeme být jisti, že se získává stejný mutex.
        //
        // Všechno tedy znamená, že první věcí, kterou zde uděláme, je to, že atomicky vytvoříme `HANDLE`, který je na Windows pojmenovaný mutex.
        // Trochu synchronizujeme s jinými vlákny sdílejícími tuto funkci konkrétně a zajišťujeme, aby byl na instanci této funkce vytvořen pouze jeden popisovač.
        // Všimněte si, že popisovač není nikdy uzavřen, jakmile je uložen v globálním.
        //
        // Poté, co jsme skutečně šli na zámek, jednoduše jej získáme a naše rukojeť `Init`, kterou rozdáme, bude zodpovědná za jeho případné zrušení.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Dobře, bože!Teď, když jsme všichni bezpečně synchronizovaní, začněme vlastně všechno zpracovávat.
        // Nejprve se musíme ujistit, že `dbghelp.dll` je v tomto procesu skutečně načten.
        // Děláme to dynamicky, abychom se vyhnuli statické závislosti.
        // Historicky to bylo provedeno kvůli řešení podivných problémů s propojováním a je zamýšleno tak, aby byly binární soubory trochu přenosnější, protože se jedná převážně jen o ladicí nástroj.
        //
        //
        // Jakmile jsme otevřeli `dbghelp.dll`, musíme v něm zavolat některé inicializační funkce, a to je podrobněji popsáno níže.
        // Děláme to však jen jednou, takže máme globální booleovský údaj, zda jsme již skončili, nebo ne.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Ujistěte se, že je nastaven příznak `SYMOPT_DEFERRED_LOADS`, protože podle vlastních dokumentů MSVC o tomto: "This is the fastest, most efficient way to use the symbol handler.", tak to udělejme!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Ve skutečnosti inicializujte symboly pomocí MSVC.Všimněte si, že to může selhat, ale ignorujeme to.
        // Není tu spousta dosavadního stavu techniky sama o sobě, ale zdá se, že LLVM interně ignoruje návratovou hodnotu a jedna z knihoven sanitizerů v LLVM vytiskne děsivé varování, pokud se to nezdaří, ale v zásadě to z dlouhodobého hlediska ignoruje.
        //
        //
        // Jedním z případů, které to pro Rust přijde hodně, je to, že jak standardní knihovna, tak i tato crate na crates.io chtějí soutěžit o `SymInitializeW`.
        // Standardní knihovna historicky chtěla inicializovat a poté většinu času vyčistit, ale teď, když používá tento crate, znamená to, že se někdo nejprve dostane k inicializaci a ten druhou tuto inicializaci vyzvedne.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}