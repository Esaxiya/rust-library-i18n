#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Formátovač pro zpětné stopy.
///
/// Tento typ lze použít k tisku útlumu bez ohledu na to, odkud útlum samotný pochází.
/// Pokud máte typ `Backtrace`, pak jeho implementace `Debug` již tento formát tisku používá.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Styly tisku, které můžeme tisknout
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Vytiskne zpětnou stopu, která v ideálním případě obsahuje pouze relevantní informace
    Short,
    /// Vytiskne backtrace, který obsahuje všechny možné informace
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Vytvořte nový `BacktraceFmt`, který zapíše výstup na dodaný `fmt`.
    ///
    /// Argument `format` bude řídit styl, ve kterém se vytiskne backtrace, a argument `print_path` se použije k tisku instancí názvů souborů `BytesOrWideString`.
    /// Tento typ sám neprovádí žádný tisk názvů souborů, ale k tomu je nutné toto zpětné volání.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Vytiskne preambuli pro zpětnou stopu, která se má vytisknout.
    ///
    /// To je na některých platformách vyžadováno, aby byly zpětné stopy plně symbolizovány později, a jinak by to měla být jen první metoda, kterou voláte po vytvoření `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Přidá rámeček na výstup zpětného sledování.
    ///
    /// Toto potvrzení vrátí instanci RAII `BacktraceFrameFmt`, kterou lze použít ke skutečnému tisku rámečku, a při zničení zvýší počítadlo rámečků.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Dokončí výstup zpětného toku.
    ///
    /// Toto je v současné době no-op, ale je přidáno pro kompatibilitu future s formáty backtrace.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // V současné době je zakázáno-včetně tohoto hook, aby bylo možné přidávat future.
        Ok(())
    }
}

/// Formátovač pouze pro jeden snímek útlumu.
///
/// Tento typ je vytvořen funkcí `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Vytiskne `BacktraceFrame` s tímto formátovačem snímků.
    ///
    /// Tím se rekurzivně vytisknou všechny instance `BacktraceSymbol` v `BacktraceFrame`.
    ///
    /// # Požadované funkce
    ///
    /// Tato funkce vyžaduje povolení funkce `std` u `backtrace` crate a funkce `std` je ve výchozím nastavení povolena.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Vytiskne `BacktraceSymbol` v `BacktraceFrame`.
    ///
    /// # Požadované funkce
    ///
    /// Tato funkce vyžaduje povolení funkce `std` u `backtrace` crate a funkce `std` je ve výchozím nastavení povolena.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: to není skvělé, že nakonec nic nevytiskneme
            // s názvy souborů jiných než utf8.
            // Naštěstí téměř všechno je utf8, takže by to nemělo být příliš špatné.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Vytiskne surové sledované `Frame` a `Symbol`, obvykle zevnitř surových zpětných volání tohoto crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Přidá nezpracovaný rámec do výstupu zpětného trasování.
    ///
    /// Tato metoda, na rozdíl od předchozí, přebírá nezpracované argumenty pro případ, že jsou zdrojem z různých umístění.
    /// Upozorňujeme, že toto může být voláno vícekrát pro jeden snímek.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Přidá do výstupu backtrace nezpracovaný rámec, včetně informací o sloupci.
    ///
    /// Tato metoda, stejně jako předchozí, přebírá nezpracované argumenty pro případ, že jsou zdrojem z různých umístění.
    /// Upozorňujeme, že toto může být voláno vícekrát pro jeden snímek.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsie nedokáže v rámci procesu symbolizovat, proto má speciální formát, který lze použít k symbolizaci později.
        // Vytiskněte to místo tisku adres v našem vlastním formátu zde.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Není třeba tisknout rámce "null", v zásadě to znamená, že systémová zpětná stopa byla trochu dychtivá vysledovat super daleko.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Abychom zmenšili velikost TCB v enklávě Sgx, nechceme implementovat funkčnost rozlišení symbolů.
        // Spíše zde můžeme vytisknout posun adresy, který lze později namapovat na správnou funkci.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Vytiskněte index rámečku a volitelný ukazatel instrukce rámečku.
        // Pokud jsme za prvním symbolem tohoto rámečku, vytiskneme pouze odpovídající mezery.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Další krok zapište název symbolu pomocí alternativního formátování pro další informace, pokud jsme úplným návratem.
        // Zde také zpracováváme symboly, které nemají název,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // A nakonec si vytiskněte číslo filename/line, pokud je k dispozici.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line jsou vytištěny na řádcích pod názvem symbolu, takže si vytiskněte vhodné mezery, abychom se mohli zarovnat doprava.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Delegujte naše interní zpětné volání, abyste vytiskli název souboru a poté vytiskli číslo řádku.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Přidejte číslo sloupce, pokud je k dispozici.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Záleží nám pouze na prvním symbolu rámečku
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}