#![stable(feature = "rust1", since = "1.0.0")]

//! Ukazatele pro počítání referencí bezpečné pro vlákna.
//!
//! Další podrobnosti najdete v dokumentaci [`Arc<T>`][Arc].

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Mírný limit na množství odkazů, které lze na `Arc` provést.
///
/// Překročení tohoto limitu přeruší váš program (i když ne nutně) u referencí _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer nepodporuje paměťové ploty.
// Chcete-li se vyhnout falešně pozitivním zprávám v implementaci Arc/Weak, použijte místo toho pro synchronizaci atomová zatížení.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Ukazatel počítání referencí bezpečný pro vlákna.'Arc' znamená " Atomically Reference Counted`.
///
/// Typ `Arc<T>` poskytuje sdílené vlastnictví hodnoty typu `T` přidělené v haldě.Vyvolání [`clone`][clone] na `Arc` vytvoří novou instanci `Arc`, která ukazuje na stejnou alokaci na haldě jako zdroj `Arc`, a zároveň zvyšuje počet odkazů.
/// Když je zničen poslední ukazatel `Arc` na danou alokaci, hodnota uložená v této alokaci (často označovaná jako "inner value") je také zrušena.
///
/// Sdílené odkazy v Rust ve výchozím nastavení nepovolují mutaci a `Arc` není výjimkou: nemůžete obecně získat proměnlivý odkaz na něco uvnitř `Arc`.Pokud potřebujete mutovat prostřednictvím `Arc`, použijte [`Mutex`][mutex], [`RwLock`][rwlock] nebo některý z typů [`Atomic`][atomic].
///
/// ## Bezpečnost závitu
///
/// Na rozdíl od [`Rc<T>`] používá `Arc<T>` pro počítání referencí atomové operace.To znamená, že je bezpečný pro vlákna.Nevýhodou je, že atomové operace jsou dražší než běžné přístupy do paměti.Pokud nesdílíte alokace počítané podle referencí mezi vlákny, zvažte použití [`Rc<T>`] pro nižší režii.
/// [`Rc<T>`] je bezpečné výchozí nastavení, protože kompilátor zachytí jakýkoli pokus o odeslání [`Rc<T>`] mezi vlákny.
/// Knihovna si však může zvolit `Arc<T>`, aby poskytla uživatelům knihovny větší flexibilitu.
///
/// `Arc<T>` bude implementovat [`Send`] a [`Sync`], pokud `T` implementuje [`Send`] a [`Sync`].
/// Proč nemůžete do `Arc<T>` vložit typ `T`, který není bezpečný pro vlákna, aby byl bezpečný pro vlákna?To může být zpočátku trochu protiintuitivní: koneckonců, nejde o bezpečnost závitu `Arc<T>`?Klíč je tento: `Arc<T>` umožňuje bezpečné vlákno mít více vlastnictví stejných dat, ale nepřidává bezpečnost vláken k jeho datům.
///
/// Zvažte `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] není [`Sync`], a pokud `Arc<T>` byl vždy [`Send`], `Arc <` [`RefCell<T>']`>` by bylo také.
/// Ale pak bychom měli problém:
/// [`RefCell<T>`] není bezpečné pro vlákna;sleduje počet výpůjček pomocí jiných než atomových operací.
///
/// Nakonec to znamená, že možná budete muset spárovat `Arc<T>` s nějakým typem [`std::sync`], obvykle [`Mutex<T>`][mutex].
///
/// ## Lámací cykly s `Weak`
///
/// Metodu [`downgrade`][downgrade] lze použít k vytvoření nevlastnícího ukazatele [`Weak`].Ukazatel [`Weak`] může být ['upgrade`][upgrade] d na `Arc`, ale vrátí [`None`], pokud již byla hodnota uložená v alokaci zrušena.
/// Jinými slovy, ukazatele `Weak` neudržují hodnotu uvnitř alokace naživu;ale *udržují* přidělení (záložní úložiště pro tuto hodnotu) naživu.
///
/// Cyklus mezi ukazateli `Arc` nebude nikdy uvolněn.
/// Z tohoto důvodu se [`Weak`] používá k přerušení cyklů.Například strom může mít silné ukazatele `Arc` z nadřazených uzlů na děti a ukazatele [`Weak`] z dětí zpět na jejich rodiče.
///
/// # Klonovací odkazy
///
/// Vytvoření nové reference z existujícího ukazatele spočítané reference se provádí pomocí `Clone` trait implementovaného pro [`Arc<T>`][Arc] a [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Dvě níže uvedené syntaxe jsou ekvivalentní.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b a foo jsou všechny oblouky, které ukazují na stejné paměťové místo
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` automaticky dereferences na `T` (přes [`Deref`][deref] trait), takže můžete volat metody `T` na hodnotě typu `Arc<T>`.Aby se předešlo střetům s metodami `T`, jsou samotné metody `Arc<T>` přidruženými funkcemi, které se nazývají pomocí [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// " Oblouk<T>Implementace traits jako `Clone` lze také volat pomocí plně kvalifikované syntaxe.
/// Někteří lidé dávají přednost použití plně kvalifikované syntaxe, zatímco jiní upřednostňují použití syntaxe volání metod.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Syntaxe volání metody
/// let arc2 = arc.clone();
/// // Plně kvalifikovaná syntaxe
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] nemá automaticky dereference k `T`, protože vnitřní hodnota již mohla být zrušena.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Sdílení některých neměnných dat mezi vlákny:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Upozorňujeme, že tyto testy zde ** neprovádíme.
// Tvůrci windows jsou velmi nešťastní, pokud vlákno přežije hlavní vlákno a poté současně skončí (něco zablokuje), takže se tomu úplně vyhneme tím, že tyto testy neprovedeme.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Sdílení proměnlivého [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Podívejte se na [`rc` documentation][rc_examples] pro další příklady počítání referencí obecně.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` je verze [`Arc`], která obsahuje nevlastnící odkaz na spravovanou alokaci.
/// Alokace je přístupná voláním [`upgrade`] na ukazateli `Weak`, který vrací [" Možnost`] <<[" Oblouk`] `<T>>`.
///
/// Vzhledem k tomu, že odkaz `Weak` se do vlastnictví nezapočítává, nezabrání tomu, aby byla hodnota uložená v alokaci zrušena, a samotný `Weak` neposkytuje žádné záruky ohledně toho, že hodnota stále existuje.
///
/// Může tedy vrátit [`None`], když [`upgrade`] d.
/// Všimněte si však, že odkaz `Weak`*nezabraňuje* přidělení samotné alokace (záložního úložiště).
///
/// Ukazatel `Weak` je užitečný pro uchování dočasného odkazu na alokaci spravovanou [`Arc`], aniž by bylo zabráněno tomu, aby byla zrušena jeho vnitřní hodnota.
/// Používá se také k prevenci cyklických odkazů mezi ukazateli [`Arc`], protože vzájemné vlastnictví odkazů by nikdy nedovolilo zrušit ani jeden [`Arc`].
/// Například strom může mít silné ukazatele [`Arc`] z nadřazených uzlů na děti a ukazatele `Weak` z dětí zpět na jejich rodiče.
///
/// Typickým způsobem, jak získat ukazatel `Weak`, je volání [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Jedná se o `NonNull`, který umožňuje optimalizovat velikost tohoto typu ve výčtu, ale není to nutně platný ukazatel.
    //
    // `Weak::new` nastaví to na `usize::MAX`, takže nemusí přidělit prostor na haldě.
    // To není hodnota, kterou skutečný ukazatel bude mít, protože RcBox má zarovnání alespoň 2.
    // To je možné pouze v případě `T: Sized`;bezrozměrný `T` se nikdy nehoupá.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// To je repr(C) až future-důkaz proti možnému přeskupení polí, což by narušilo jinak bezpečné [into|from]_raw() transmutovatelných vnitřních typů.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // hodnota usize::MAX funguje jako indikátor pro dočasnou "locking" schopnost upgradovat slabé ukazatele nebo downgradovat silné;toto se používá k vyhnutí se závodům v `make_mut` a `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Konstruuje nový `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Začněte počítat slabý ukazatel jako 1, což je slabý ukazatel, který drží všechny silné ukazatele (kinda), další informace najdete v std/rc.rs
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Vytvoří novou `Arc<T>` pomocí slabého odkazu na sebe.
    /// Pokus o upgrade slabé reference před návratem této funkce bude mít za následek hodnotu `None`.
    /// Slabá reference však může být volně klonována a uložena pro pozdější použití.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Vytvořte vnitřní ve stavu "uninitialized" s jedinou slabou referencí.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Je důležité, abychom se nevzdali vlastnictví slabého ukazatele, jinak by mohla být paměť uvolněna v době, kdy se vrátí `data_fn`.
        // Pokud bychom opravdu chtěli předat vlastnictví, mohli bychom pro sebe vytvořit další slabý ukazatel, ale to by vedlo k dalším aktualizacím slabého počtu odkazů, které by jinak nebyly nutné.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Nyní můžeme správně inicializovat vnitřní hodnotu a přeměnit naši slabou referenci na silnou referenci.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Výše uvedený zápis do datového pole musí být viditelný pro všechna vlákna, která sledují nenulový silný počet.
            // Proto potřebujeme alespoň "Release" objednávání, abychom mohli synchronizovat s `compare_exchange_weak` v `Weak::upgrade`.
            //
            // "Acquire" objednávka není nutná.
            // Při zvažování možného chování `data_fn` se musíme jen podívat na to, co by to mohlo dělat s odkazem na non-upgradovatelný `Weak`:
            //
            // - Může *klonovat*`Weak` a zvýšit tak slabý počet referencí.
            // - Může tyto klony odhodit a snížit tak slabý počet odkazů (ale nikdy na nulu).
            //
            // Tyto vedlejší účinky nás nijak neovlivňují a žádné další nežádoucí účinky nejsou možné pouze se samotným bezpečným kódem.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Silné reference by měly společně vlastnit sdílenou slabou referenci, takže nespouštějte destruktor pro naši starou slabou referenci.
        //
        mem::forget(weak);
        strong
    }

    /// Vytváří nový model `Arc` s neinicializovaným obsahem.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Odložená inicializace:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Vytváří nový `Arc` s neinicializovaným obsahem, přičemž paměť je vyplněna bajty `0`.
    ///
    ///
    /// Viz [`MaybeUninit::zeroed`][zeroed] pro příklady správného a nesprávného použití této metody.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruuje nový `Pin<Arc<T>>`.
    /// Pokud `T` neimplementuje `Unpin`, pak `data` bude připnut v paměti a nebude jej možné přesunout.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Vytvoří nový `Arc<T>` a vrátí chybu, pokud se přidělení nezdaří.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Začněte počítat slabý ukazatel jako 1, což je slabý ukazatel, který drží všechny silné ukazatele (kinda), další informace najdete v std/rc.rs
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Vytvoří nový `Arc` s neinicializovaným obsahem a vrátí chybu, pokud přidělení selže.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Odložená inicializace:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Vytvoří nový `Arc` s neinicializovaným obsahem, přičemž paměť je vyplněna bajty `0`, vrací chybu, pokud přidělení selže.
    ///
    ///
    /// Viz [`MaybeUninit::zeroed`][zeroed] pro příklady správného a nesprávného použití této metody.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Vrátí vnitřní hodnotu, pokud má `Arc` přesně jednu silnou referenci.
    ///
    /// Jinak se vrátí [`Err`] se stejným `Arc`, který byl předán.
    ///
    ///
    /// To uspěje, i když existují vynikající slabé reference.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Vytvořte slabý ukazatel k vyčištění implicitní silně slabé reference
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Vytvoří nový řez počítaný podle atomů s neinicializovaným obsahem.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Odložená inicializace:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Vytvoří nový řez počítaný podle atomů s neinicializovaným obsahem, přičemž paměť je vyplněna bajty `0`.
    ///
    ///
    /// Viz [`MaybeUninit::zeroed`][zeroed] pro příklady správného a nesprávného použití této metody.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Převede na `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Stejně jako u [`MaybeUninit::assume_init`] je na volajícím, aby zaručil, že vnitřní hodnota je skutečně v inicializovaném stavu.
    ///
    /// Volání, když obsah ještě není plně inicializován, způsobí okamžité nedefinované chování.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Odložená inicializace:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Převede na `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Stejně jako u [`MaybeUninit::assume_init`] je na volajícím, aby zaručil, že vnitřní hodnota je skutečně v inicializovaném stavu.
    ///
    /// Volání, když obsah ještě není plně inicializován, způsobí okamžité nedefinované chování.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Odložená inicializace:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Využívá `Arc` a vrací zabalený ukazatel.
    ///
    /// Aby se zabránilo úniku paměti, musí být ukazatel převeden zpět na `Arc` pomocí [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Poskytuje nezpracovaný ukazatel na data.
    ///
    /// Počty nejsou nijak ovlivněny a `Arc` se nespotřebovává.
    /// Ukazatel je platný tak dlouho, dokud jsou v `Arc` silné počty.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // BEZPEČNOST: To nemůže projít Deref::deref nebo RcBoxPtr::inner, protože
        // to je nutné k zachování původu raw/mut tak, aby např
        // `get_mut` může psát přes ukazatel po obnovení Rc přes `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Vytvoří `Arc<T>` ze surového ukazatele.
    ///
    /// Nezpracovaný ukazatel musel být dříve vrácen voláním [`Arc<U>::into_raw`][into_raw], kde `U` musí mít stejnou velikost a zarovnání jako `T`.
    /// To platí triviálně, pokud `U` je `T`.
    /// Všimněte si, že pokud `U` není `T`, ale má stejnou velikost a zarovnání, je to v podstatě jako transmutující odkazy různých typů.
    /// Další informace o tom, jaká omezení platí v tomto případě, najdete na [`mem::transmute`][transmute].
    ///
    /// Uživatel `from_raw` se musí ujistit, že konkrétní hodnota `T` je vynechána pouze jednou.
    ///
    /// Tato funkce je nebezpečná, protože nesprávné použití může vést k bezpečnosti paměti, i když k vrácenému `Arc<T>` nikdy není přistupováno.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Převeďte zpět na `Arc`, abyste zabránili úniku.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Další volání na `Arc::from_raw(x_ptr)` by byla paměťově nebezpečná.
    /// }
    ///
    /// // Paměť byla uvolněna, když `x` vyšel z rozsahu výše, takže `x_ptr` se teď houpá!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Chcete-li najít původní ArcInner, otočte offset.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Vytvoří nový ukazatel [`Weak`] na toto přidělení.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Toto uvolněné je v pořádku, protože kontrolujeme hodnotu v CAS níže.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // zkontrolujte, zda je momentálně slabý čítač "locked";pokud ano, otočte se.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: tento kód aktuálně ignoruje možnost přetečení
            // do usize::MAX;obecně je třeba upravit Rc i Arc, aby se vypořádaly s přetečením.
            //

            // Na rozdíl od Clone() potřebujeme, aby to bylo čtení Acquire, aby se synchronizovalo s zápisem pocházejícím z `is_unique`, aby se události před tímto zápisem staly před tímto čtením.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Ujistěte se, že nevytváříme visící Slabé
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Získá počet ukazatelů [`Weak`] na toto přidělení.
    ///
    /// # Safety
    ///
    /// Tato metoda je sama o sobě bezpečná, ale její správné použití vyžaduje zvláštní péči.
    /// Jiné vlákno může kdykoli změnit slabý počet, včetně potenciálně mezi voláním této metody a působením na výsledek.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Toto tvrzení je deterministické, protože jsme mezi vlákny nesdíleli `Arc` nebo `Weak`.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Pokud je slabý počet aktuálně uzamčen, byla hodnota počtu 0 těsně před přijetím zámku.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Získá počet silných ukazatelů (`Arc`) na toto přidělení.
    ///
    /// # Safety
    ///
    /// Tato metoda je sama o sobě bezpečná, ale její správné použití vyžaduje zvláštní péči.
    /// Další vlákno může kdykoli změnit silný počet, včetně potenciálně mezi voláním této metody a působením na výsledek.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Toto tvrzení je deterministické, protože jsme `Arc` nesdíleli mezi vlákny.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Zvyšuje počet silných odkazů na `Arc<T>` přidružený k poskytnutému ukazateli o jednu.
    ///
    /// # Safety
    ///
    /// Ukazatel musí být získán prostřednictvím `Arc::into_raw` a přidružená instance `Arc` musí být platná (tj
    /// silný počet musí být po dobu trvání této metody alespoň 1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Toto tvrzení je deterministické, protože jsme `Arc` nesdíleli mezi vlákny.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Ponechejte oblouk, ale nedotýkejte se refcountu zabalením do ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Nyní zvyšte refcount, ale nepouštějte ani nový refcount
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Snižuje počet silných odkazů na `Arc<T>` přidružený k poskytnutému ukazateli o jednu.
    ///
    /// # Safety
    ///
    /// Ukazatel musí být získán prostřednictvím `Arc::into_raw` a přidružená instance `Arc` musí být platná (tj
    /// silný počet musí být při vyvolání této metody alespoň 1).
    /// Tuto metodu lze použít k uvolnění finálního `Arc` a záložního úložiště, ale po vydání finálního `Arc` by se nemělo volat **.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Tato tvrzení jsou deterministická, protože jsme `Arc` nesdíleli mezi vlákny.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Tato bezpečnost je v pořádku, protože zatímco je tento oblouk živý, máme zaručeno, že vnitřní ukazatel je platný.
        // Dále víme, že samotná struktura `ArcInner` je `Sync`, protože i vnitřní data jsou `Sync`, takže si můžeme půjčit neměnný ukazatel na tento obsah.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Non-inlined část `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // V tuto chvíli zničte data, i když nemusíme uvolnit samotnou alokaci boxů (stále mohou ležet slabé ukazatele).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Odhoďte slabý ref společně držený všemi silnými odkazy
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Vrátí `true`, pokud dva `Arc`s ukazují na stejnou alokaci (ve žíle podobné [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Přidělí `ArcInner<T>` s dostatečným prostorem pro možná vnitřní velikost, kde má hodnota poskytnuté rozložení.
    ///
    /// Funkce `mem_to_arcinner` je volána s datovým ukazatelem a musí vrátit zpět (potenciálně tlustý) ukazatel pro `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Vypočítejte rozložení pomocí rozložení dané hodnoty.
        // Dříve bylo rozložení počítáno na výrazu `&*(ptr as* const ArcInner<T>)`, ale tím byla vytvořena nesprávně zarovnaná reference (viz #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Přidělí `ArcInner<T>` s dostatečným prostorem pro vnitřní velikost s možnou velikostí, kde má hodnota poskytnuté rozložení, v případě selhání alokace vrátí chybu.
    ///
    ///
    /// Funkce `mem_to_arcinner` je volána s datovým ukazatelem a musí vrátit zpět (potenciálně tlustý) ukazatel pro `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Vypočítejte rozložení pomocí rozložení dané hodnoty.
        // Dříve bylo rozložení počítáno na výrazu `&*(ptr as* const ArcInner<T>)`, ale tím byla vytvořena nesprávně zarovnaná reference (viz #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Inicializujte ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Přiděluje `ArcInner<T>` s dostatečným prostorem pro vnitřní velikost bez velikosti.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Přiřaďte `ArcInner<T>` pomocí dané hodnoty.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Zkopírujte hodnotu jako bajty
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Uvolněte alokaci bez upuštění obsahu
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Přidělí `ArcInner<[T]>` s danou délkou.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Zkopírujte prvky z řezu do nově přiděleného oblouku <\[T\]>
    ///
    /// Nebezpečný, protože volající musí buď převzít vlastnictví, nebo svázat `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Vytvoří `Arc<[T]>` z iterátoru, o kterém je známo, že má určitou velikost.
    ///
    /// Chování není definováno, pokud je velikost nesprávná.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Ochranu Panic při klonování T prvků.
        // V případě panic budou prvky, které byly zapsány do nové ArcInner, zahozeny a poté uvolněna paměť.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Ukazatel na první prvek
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Vše jasné.Zapomeňte na stráž, aby neuvolnil nový ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specializace trait použitá pro `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Vytvoří klon ukazatele `Arc`.
    ///
    /// Tím se vytvoří další ukazatel na stejnou alokaci, čímž se zvýší počet silných odkazů.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Použití uvolněného uspořádání je zde v pořádku, protože znalost původního odkazu brání jiným vláknům v chybném odstranění objektu.
        //
        // Jak je vysvětleno v [Boost documentation][1], Zvýšení počitadla referencí lze vždy provést pomocí memory_order_relaxed: Nové odkazy na objekt lze vytvořit pouze z existujícího odkazu a předání existujícího odkazu z jednoho vlákna do jiného musí již poskytovat požadovanou synchronizaci.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Musíme se však chránit před masivními výplatami v případě, že někdo ``mem: : zapomíná`` oblouky.
        // Pokud to neuděláme, počet může přetéct a uživatelé budou používat zdarma.
        // Racily saturujeme na `isize::MAX` za předpokladu, že neexistují ~2 miliardy vláken zvyšujících počet odkazů najednou.
        //
        // Tento branch nikdy nebude použit v žádném realistickém programu.
        //
        // Potratíme, protože takový program je neuvěřitelně zvrhlý a nestaráme se o jeho podporu.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Dá měnitelnou referenci do dané `Arc`.
    ///
    /// Pokud existují další ukazatele `Arc` nebo [`Weak`] na stejnou alokaci, pak `make_mut` vytvoří novou alokaci a vyvolá [`clone`][clone] na vnitřní hodnotu, aby zajistil jedinečné vlastnictví.
    /// Toto se také označuje jako clone-on-write.
    ///
    /// Všimněte si, že se to liší od chování [`Rc::make_mut`], které disociuje všechny zbývající ukazatele `Weak`.
    ///
    /// Viz také [`get_mut`][get_mut], který selže místo klonování.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Nebudu nic klonovat
    /// let mut other_data = Arc::clone(&data); // Nebudou klonována vnitřní data
    /// *Arc::make_mut(&mut data) += 1;         // Klony vnitřní data
    /// *Arc::make_mut(&mut data) += 1;         // Nebudu nic klonovat
    /// *Arc::make_mut(&mut other_data) *= 2;   // Nebudu nic klonovat
    ///
    /// // Nyní `data` a `other_data` ukazují na různé alokace.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Všimněte si, že máme silnou i slabou referenci.
        // Uvolnění pouze našeho silného odkazu tedy samo o sobě nezpůsobí uvolnění paměti.
        //
        // Použijte Acquire k zajištění toho, že uvidíme všechny zápisy do `weak`, ke kterým dojde před zápisem vydání (tj. Snížení) do `strong`.
        // Protože máme slabý počet, není šance, že by mohl být uvolněn samotný ArcInner.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Existuje další silný ukazatel, takže musíme klonovat.
            // Předem přidělte paměť, abyste mohli přímo klonovanou hodnotu zapsat.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Uvolněné postačuje výše uvedené, protože se jedná v zásadě o optimalizaci: vždy závodíme se slabými ukazateli.
            // V nejhorším případě zbytečně přidělíme nový oblouk.
            //

            // Odstranili jsme poslední silné doporučení, ale zbývají další slabé doporučení.
            // Přesuneme obsah do nového oblouku a zneplatníme další slabá doporučení.
            //

            // Všimněte si, že není možné, aby čtení `weak` poskytlo usize::MAX (tj. Uzamčeno), protože slabý počet lze uzamknout pouze vláknem se silným odkazem.
            //
            //

            // Realizujte náš vlastní implicitní slabý ukazatel, aby mohl ArcInner podle potřeby vyčistit.
            //
            let _weak = Weak { ptr: this.ptr };

            // Stačí jen ukrást data, zbývá jen Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Byli jsme jediným odkazem obou druhů;vrátit zpět silný počet ref.
            //
            this.inner().strong.store(1, Release);
        }

        // Stejně jako u `get_mut()` je bezpečnost v pořádku, protože naše reference byla buď jedinečná pro začátek, nebo se stala jednou při klonování obsahu.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Vrátí proměnlivý odkaz do dané `Arc`, pokud neexistují žádné další ukazatele `Arc` nebo [`Weak`] na stejnou alokaci.
    ///
    ///
    /// Vrací [`None`] jinak, protože není bezpečné mutovat sdílenou hodnotu.
    ///
    /// Viz také [`make_mut`][make_mut], který bude [`clone`][clone] vnitřní hodnotu, když existují další ukazatele.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Tato bezpečnost je v pořádku, protože máme zaručeno, že vrácený ukazatel je *pouze* ukazatel, který bude kdy vrácen T.
            // Náš počet odkazů je v tomto okamžiku zaručeně 1 a požadovali jsme, aby samotný oblouk byl `mut`, takže vracíme jediný možný odkaz na vnitřní data.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Vrátí proměnlivou referenci do dané `Arc` bez jakékoli kontroly.
    ///
    /// Viz také [`get_mut`], který je bezpečný a provádí příslušné kontroly.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Žádné další ukazatele `Arc` nebo [`Weak`] na stejnou alokaci nesmí být dereferencovány po dobu trvání vrácené půjčky.
    ///
    /// To je triviální případ, pokud takové ukazatele neexistují, například bezprostředně po `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Dáváme pozor, abychom *ne* vytvořili odkaz pokrývající pole "count", protože by to byl alias se současným přístupem k počtu odkazů (např.
        // od `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Určete, zda se jedná o jedinečný odkaz (včetně slabých odkazů) na podkladová data.
    ///
    ///
    /// To vyžaduje uzamčení slabého počtu odkazů.
    fn is_unique(&mut self) -> bool {
        // uzamkněte počet slabých ukazatelů, pokud se jeví jako jediný držák slabého ukazatele.
        //
        // Štítek pro získání zde zajišťuje vztah před spuštěním s jakýmkoli zápisem do `strong` (zejména v `Weak::upgrade`) před poklesem počtu `weak` (prostřednictvím `Weak::drop`, který používá verzi).
        // Pokud upgradovaný slabý ref nebyl nikdy zrušen, CAS zde selže, takže se nestaráme o synchronizaci.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // To musí být `Acquire` pro synchronizaci s poklesem počitadla `strong` v `drop`-jediný přístup, ke kterému dojde, když je zrušena jakákoli, ale poslední reference.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Vydání pro zápis se zde synchronizuje se čtením v `downgrade`, čímž účinně zabrání tomu, aby se výše uvedené čtení `strong` stalo po zápisu.
            //
            //
            self.inner().weak.store(1, Release); // uvolněte zámek
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Spadne `Arc`.
    ///
    /// Tím se sníží počet silných odkazů.
    /// Pokud počet silných odkazů dosáhne nuly, pak jsou pouze další odkazy (pokud existují) [`Weak`], takže `drop` budeme mít vnitřní hodnotu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Netiskne nic
    /// drop(foo2);   // Vytiskne "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Protože `fetch_sub` je již atomový, nemusíme synchronizovat s jinými vlákny, pokud nebudeme smazat objekt.
        // Stejná logika platí pro níže `fetch_sub` až `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Tento plot je nutný, aby se zabránilo změně pořadí použití údajů a jejich mazání.
        // Protože je označen `Release`, snížení počtu referencí se synchronizuje s tímto plotem `Acquire`.
        // To znamená, že k použití dat dojde před snížením počtu odkazů, ke kterému dojde před tímto plotem, ke kterému dojde před odstraněním dat.
        //
        // Jak je vysvětleno v [Boost documentation][1],
        //
        // > Je důležité vynutit možný přístup k objektu v jednom
        // > vlákno (prostřednictvím existujícího odkazu) na *stane se před* odstraněním
        // > objekt v jiném vlákně.Toho je dosaženo pomocí "release"
        // > operace po zrušení odkazu (jakýkoli přístup k objektu
        // > prostřednictvím tohoto odkazu se samozřejmě muselo stát dříve), a
        // > "acquire" před odstraněním objektu.
        //
        // Zejména, zatímco obsah oblouku je obvykle neměnný, je možné, aby vnitřní zápisy fungovaly na něco jako Mutex<T>.
        // Jelikož Mutex není získán, když je odstraněn, nemůžeme se spoléhat na jeho synchronizační logiku, aby zápisy ve vlákně A byly viditelné pro destruktor běžící ve vlákně B.
        //
        //
        // Všimněte si také, že plot Acquire by zde mohl být pravděpodobně nahrazen zátěží Acquire, což by mohlo zlepšit výkon ve velmi náročných situacích.Viz [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Pokus o sesazení `Arc<dyn Any + Send + Sync>` na konkrétní typ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Vytváří nový `Weak<T>`, aniž by přidělil jakoukoli paměť.
    /// Volání [`upgrade`] na návratovou hodnotu vždy dává [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Typ pomocníka umožňující přístup k počtu odkazů bez provádění jakýchkoli tvrzení o datovém poli.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Vrátí surový ukazatel na objekt `T`, na který ukazuje tento `Weak<T>`.
    ///
    /// Ukazatel je platný, pouze pokud existují silné odkazy.
    /// Ukazatel může být visící, nezarovnaný nebo jinak [`null`] jinak.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Oba ukazují na stejný objekt
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Silní zde ho udržují při životě, takže k objektu můžeme stále přistupovat.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ale už ne.
    /// // Můžeme udělat weak.as_ptr(), ale přístup k ukazateli by vedl k nedefinovanému chování.
    /// // assert_eq! ("ahoj", nebezpečné {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Pokud se ukazatel houpá, vrátíme sentinel přímo.
            // Toto nemůže být platná adresa užitečného zatížení, protože užitečné zatížení je minimálně stejně zarovnané jako ArcInner (usize).
            ptr as *const T
        } else {
            // BEZPEČNOST: pokud is_dangling vrátí hodnotu false, pak je ukazatel dereferencable.
            // Už v tomto okamžiku může být užitečné zatížení zrušeno a my musíme zachovat původ, proto používejte manipulaci surového ukazatele.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Spotřebuje `Weak<T>` a promění jej v surový ukazatel.
    ///
    /// Tím se slabý ukazatel převede na surový ukazatel, při zachování vlastnictví jedné slabé reference (slabý počet není touto operací upraven).
    /// Lze jej proměnit zpět na `Weak<T>` s [`from_raw`].
    ///
    /// Platí stejná omezení přístupu k cíli ukazatele jako u [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Převede surový ukazatel dříve vytvořený [`into_raw`] zpět na `Weak<T>`.
    ///
    /// To lze použít k bezpečnému získání silné reference (voláním [`upgrade`] později) nebo k uvolnění slabého počtu upuštěním `Weak<T>`.
    ///
    /// Trvá vlastnictví jedné slabé reference (s výjimkou ukazatelů vytvořených [`new`], protože tyto nic nevlastní; metoda na nich stále funguje).
    ///
    /// # Safety
    ///
    /// Ukazatel musí pocházet z [`into_raw`] a musí stále vlastnit jeho potenciálně slabý odkaz.
    ///
    /// V době volání je povoleno, aby silný počet byl 0.
    /// Toto však přebírá vlastnictví jedné slabé reference aktuálně představované jako surový ukazatel (slabý počet není touto operací upraven), a proto musí být spárován s předchozím voláním [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Snížit poslední slabý počet.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Viz Weak::as_ptr pro kontext, jak je odvozen vstupní ukazatel.

        let ptr = if is_dangling(ptr as *mut T) {
            // Toto je visící Slabý.
            ptr as *mut ArcInner<T>
        } else {
            // Jinak máme zaručeno, že ukazatel pochází z nerozmotávajícího se Slabého.
            // BEZPEČNOST: data_offset je bezpečné volat, protože ptr odkazuje na skutečné (potenciálně upuštěné) T.
            let offset = unsafe { data_offset(ptr) };
            // Otočíme tedy offset, abychom získali celý RcBox.
            // BEZPEČNOST: ukazatel pocházel z Weak, takže tento offset je bezpečný.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // BEZPEČNOST: nyní jsme obnovili původní ukazatel Slabý, takže můžeme vytvořit Slabý.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Pokusy o upgrade ukazatele `Weak` na [`Arc`], zpoždění poklesu vnitřní hodnoty, pokud bude úspěšné.
    ///
    ///
    /// Vrátí [`None`], pokud byla mezitím zrušena vnitřní hodnota.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Zničte všechny silné ukazatele.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Ke zvýšení silného počtu místo fetch_add používáme smyčku CAS, protože tato funkce by nikdy neměla brát referenční počet od nuly do jedné.
        //
        //
        let inner = self.inner()?;

        // Uvolněné načtení, protože jakýkoli zápis 0, který můžeme pozorovat, opouští pole v trvale nulovém stavu (takže čtení "stale" 0 je v pořádku) a jakákoli další hodnota je potvrzena pomocí CAS níže.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Podívejte se na komentáře v `Arc::clone`, proč to děláme (pro `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Uvolněný je v pořádku pro případ selhání, protože nemáme žádná očekávání ohledně nového stavu.
            // Získat je nutné, aby se případ úspěchu synchronizoval s `Arc::new_cyclic`, když lze vnitřní hodnotu inicializovat poté, co již byly vytvořeny odkazy `Weak`.
            // V takovém případě očekáváme pozorování plně inicializované hodnoty.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null zaškrtnuto výše
                Err(old) => n = old,
            }
        }
    }

    /// Získá počet silných ukazatelů (`Arc`) směřujících k této alokaci.
    ///
    /// Pokud byl `self` vytvořen pomocí [`Weak::new`], vrátí hodnotu 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Získá přiblížení počtu ukazatelů `Weak` směřujících k této alokaci.
    ///
    /// Pokud byl `self` vytvořen pomocí [`Weak::new`], nebo pokud nezůstanou žádné silné ukazatele, vrátí se 0.
    ///
    /// # Accuracy
    ///
    /// Kvůli podrobnostem implementace může být vrácená hodnota vypnuta o 1 v obou směrech, když ostatní vlákna manipulují s jakýmkoli `Arc`s nebo`Weak`s směřujícím ke stejné alokaci.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Protože jsme si všimli, že po přečtení slabého počtu existoval alespoň jeden silný ukazatel, víme, že implicitní slabá reference (přítomná, kdykoli jsou všechny silné reference aktivní) byla stále kolem, když jsme pozorovali slabý počet, a proto ji můžeme bezpečně odečíst.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Vrátí `None`, když je ukazatel visící a není přiděleno `ArcInner`, (tj. Když tento `Weak` byl vytvořen `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Dáváme pozor, abychom *ne* vytvořili odkaz pokrývající pole "data", protože pole může být současně mutováno (například pokud je zrušen poslední `Arc`, datové pole bude zrušeno na místě).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Vrátí `true`, pokud dva `Slabé` ukazují na stejnou alokaci (podobnou [`ptr::eq`]), nebo pokud oba neukazují na žádnou alokaci (protože byly vytvořeny pomocí `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Protože toto porovnává ukazatele, znamená to, že `Weak::new()` se budou navzájem rovnat, i když neukazují na žádnou alokaci.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Srovnání `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Vytvoří klon ukazatele `Weak`, který ukazuje na stejnou alokaci.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Přečtěte si komentáře v Arc::clone(), proč je to uvolněné.
        // To může použít fetch_add (ignorování zámku), protože slabý počet je uzamčen pouze tam, kde neexistují *žádné jiné* slabé ukazatele.
        //
        // (Takže v tomto případě nemůžeme tento kód spustit).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Podívejte se na komentáře v Arc::clone(), proč to děláme (pro mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Vytváří nový `Weak<T>` bez přidělení paměti.
    /// Volání [`upgrade`] na návratovou hodnotu vždy dává [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Spadne ukazatel `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Netiskne nic
    /// drop(foo);        // Vytiskne "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Pokud zjistíme, že jsme byli posledním slabým ukazatelem, pak je čas úplně uvolnit data.Podívejte se na diskuzi v Arc::drop() o uspořádání paměti
        //
        // Není nutné zde kontrolovat uzamčený stav, protože slabý počet lze uzamknout pouze v případě, že byl právě jeden slabý ref, což znamená, že pokles mohl teprve následně spustit ON zbývající slabý ref, což se může stát až po uvolnění zámku.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Děláme tuto specializaci zde, a ne jako obecnější optimalizaci na `&T`, protože by to jinak přidalo náklady na všechny kontroly rovnosti u referencí.
/// Předpokládáme, že `Arc`s se používají k ukládání velkých hodnot, které se pomalu klonují, ale také těžké pro kontrolu rovnosti, což způsobí, že se tyto náklady snáze vyplatí.
///
/// Je také větší pravděpodobnost, že budou mít dva klony `Arc`, které ukazují na stejnou hodnotu, než dva " &T`.
///
/// Můžeme to udělat, pouze když `T: Eq` jako `PartialEq` může být záměrně nereflexivní.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Rovnost pro dva `oblouky.
    ///
    /// Dva `Arc` jsou stejné, pokud jsou jejich vnitřní hodnoty stejné, i když jsou uloženy v různých alokacích.
    ///
    /// Pokud `T` také implementuje `Eq` (z čehož vyplývá reflexivita rovnosti), jsou dva " oblouky`, které ukazují na stejnou alokaci, vždy stejné.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Nerovnost pro dva `Arc`.
    ///
    /// Dva `Arc` jsou nerovné, pokud jsou jejich vnitřní hodnoty nerovné.
    ///
    /// Pokud `T` také implementuje `Eq` (z čehož vyplývá reflexivita rovnosti), dva " oblouky`, které ukazují na stejnou hodnotu, nejsou nikdy nerovné.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Částečné srovnání pro dva `Arc`s.
    ///
    /// Dva jsou porovnány voláním `partial_cmp()` na jejich vnitřních hodnotách.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Méně než srovnání pro dva `Arc`s.
    ///
    /// Dva jsou porovnány voláním `<` na jejich vnitřních hodnotách.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Porovnání " menší než nebo rovno`pro dva " obloukové`.
    ///
    /// Dva jsou porovnány voláním `<=` na jejich vnitřních hodnotách.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Větší než srovnání pro dva `Arc`s.
    ///
    /// Dva jsou porovnány voláním `>` na jejich vnitřních hodnotách.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Porovnání " větší než nebo rovno`pro dva " obloukové`.
    ///
    /// Dva jsou porovnány voláním `>=` na jejich vnitřních hodnotách.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Srovnání pro dva `Arc`s.
    ///
    /// Dva jsou porovnány voláním `cmp()` na jejich vnitřních hodnotách.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Vytvoří nový `Arc<T>` s hodnotou `Default` pro `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Přiřaďte řez počítaný podle referencí a vyplňte jej klonováním položek `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Přiřaďte `str` s počítáním referencí a zkopírujte do něj `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Přiřaďte `str` s počítáním referencí a zkopírujte do něj `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Přesuňte orámovaný objekt do nové alokace počítané podle referencí.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Přiřaďte řez počítaný podle referencí a přesuňte do něj položky `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Nechte Vec uvolnit paměť, ale ne zničit její obsah
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Vezme každý prvek v `Iterator` a shromáždí jej do `Arc<[T]>`.
    ///
    /// # Výkonové charakteristiky
    ///
    /// ## Obecný případ
    ///
    /// Obecně se shromažďování do `Arc<[T]>` provádí tak, že se nejprve shromažďuje do `Vec<T>`.To znamená, když píšete následující:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// chová se, jako bychom napsali:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Zde nastává první sada přidělení.
    ///     .into(); // Zde nastane druhá alokace pro `Arc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// To přidělí tolikrát, kolikrát je potřeba pro konstrukci `Vec<T>`, a poté se přidělí jednou pro přeměnu `Vec<T>` na `Arc<[T]>`.
    ///
    ///
    /// ## Iterátory známé délky
    ///
    /// Když váš `Iterator` implementuje `TrustedLen` a má přesnou velikost, bude pro `Arc<[T]>` provedena jedna alokace.Například:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Dojde zde pouze k jedné alokaci.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Specializace trait použitá pro sběr do `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // To je případ iterátoru `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // BEZPEČNOST: Musíme zajistit, aby iterátor měl přesnou délku a my ano.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Vraťte se k normální implementaci.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Získejte offset v rámci `ArcInner` pro užitečné zatížení za ukazatelem.
///
/// # Safety
///
/// Ukazatel musí ukazovat na (a mít platná metadata pro) dříve platnou instanci T, ale T je povoleno zrušit.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Zarovnejte velikost bez velikosti na konec ArcInner.
    // Protože RcBox je repr(C), bude to vždy poslední pole v paměti.
    // BEZPEČNOST: jelikož jedinými možnými typy bez velikosti jsou řezy, objekty trait,
    // a externích typů je požadavek na vstupní bezpečnost v současné době dostatečný pro splnění požadavků align_of_val_raw;toto je implementační detail jazyka, na který se nelze spoléhat mimo std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}