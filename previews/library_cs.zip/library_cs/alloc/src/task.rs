#![stable(feature = "wake_trait", since = "1.51.0")]
//! Typy a Traits pro práci s asynchronními úkoly.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Implementace probuzení úkolu na exekutora.
///
/// Tento trait lze použít k vytvoření [`Waker`].
/// Exekutor může definovat implementaci tohoto trait a použít jej k vytvoření Wakeru pro předání úkolům, které jsou prováděny na tomto exekutoru.
///
/// Tento trait je paměťově bezpečná a ergonomická alternativa ke konstrukci [`RawWaker`].
/// Podporuje společný návrh exekutora, ve kterém jsou data použitá k probuzení úlohy uložena v [`Arc`].
/// Někteří exekutoři (zejména pro vestavěné systémy) nemohou toto API používat, a proto pro tyto systémy existuje alternativa [`RawWaker`].
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Základní funkce `block_on`, která přebírá future a spouští ji do dokončení v aktuálním vlákně.
///
/// **Note:** Tento příklad vyměňuje správnost za jednoduchost.
/// Aby se zabránilo zablokování, implementace na úrovni produkce budou také muset zpracovat mezilehlé volání `thread::unpark`, stejně jako vnořené vyvolání.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Waker, který při volání probudí aktuální vlákno.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Spusťte future do dokončení v aktuálním vlákně.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Připojte future, aby mohl být dotazován.
///     let mut fut = Box::pin(fut);
///
///     // Vytvořte nový kontext, který bude předán future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Spusťte future až do dokončení.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Probuďte tento úkol.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Probuďte tento úkol, aniž byste spotřebovali buditele.
    ///
    /// Pokud exekutor podporuje levnější způsob probuzení bez konzumace budiče, měl by tuto metodu přepsat.
    /// Ve výchozím nastavení klonuje [`Arc`] a volá [`wake`] na klon.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // BEZPEČNOST: Je to bezpečné, protože raw_waker bezpečně vytváří
        // RawWaker z Arku<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Tato soukromá funkce pro konstrukci RawWakeru se používá spíše než
// vložením to do `From<Arc<W>> for RawWaker` impl, aby se zajistilo, že bezpečnost `From<Arc<W>> for Waker` nezávisí na správném odeslání trait, místo toho oba impls volají tuto funkci přímo a explicitně.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Chcete-li jej klonovat, zvyšte počet odkazů na oblouk.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Probuďte se podle hodnoty a přesuňte oblouk do funkce Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Wake by reference, wrap the waker in ManuallyDrop to avoid dropping it
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Snižte počet odkazů v oblouku při poklesu
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}