//! Ukazatele pro počítání referencí s jedním závitem.'Rc' znamená " Reference`
//! Counted'.
//!
//! Typ [`Rc<T>`][`Rc`] poskytuje sdílené vlastnictví hodnoty typu `T` přidělené v haldě.
//! Vyvolání [`clone`][clone] na [`Rc`] vytvoří nový ukazatel na stejnou alokaci v haldě.
//! Když je zničen poslední ukazatel [`Rc`] na danou alokaci, hodnota uložená v této alokaci (často označovaná jako "inner value") je také zrušena.
//!
//! Sdílené odkazy v Rust ve výchozím nastavení neumožňují mutaci a [`Rc`] není výjimkou: nemůžete obecně získat proměnlivý odkaz na něco uvnitř [`Rc`].
//! Pokud potřebujete měnitelnost, vložte [`Cell`] nebo [`RefCell`] do [`Rc`];viz [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] používá ne-atomové počítání referencí.
//! To znamená, že režie je velmi nízká, ale [`Rc`] nelze odeslat mezi vlákny, a následně [`Rc`] neimplementuje [`Send`][send].
//! Výsledkem je, že kompilátor Rust zkontroluje *v době kompilace*, že mezi vlákny neposíláte [`Rc`] s.
//! Pokud potřebujete vícevláknové počítání atomových referencí, použijte [`sync::Arc`][arc].
//!
//! Metodu [`downgrade`][downgrade] lze použít k vytvoření nevlastnícího ukazatele [`Weak`].
//! Ukazatel [`Weak`] může být [" upgrade`][upgrade] d na [`Rc`], ale vrátí [`None`], pokud již byla hodnota uložená v alokaci zrušena.
//! Jinými slovy, ukazatele `Weak` neudržují hodnotu uvnitř alokace naživu;nicméně *udržují* přidělení (záložní úložiště pro vnitřní hodnotu) naživu.
//!
//! Cyklus mezi ukazateli [`Rc`] nebude nikdy uvolněn.
//! Z tohoto důvodu se [`Weak`] používá k přerušení cyklů.
//! Například strom může mít silné ukazatele [`Rc`] z nadřazených uzlů na děti a ukazatele [`Weak`] z dětí zpět na jejich rodiče.
//!
//! `Rc<T>` automaticky dereferences to `T` (via the [`Deref`] trait), takže můžete volat metody `T` na hodnotě typu [`Rc<T>`][`Rc`].
//! Aby se předešlo střetům s metodami `T`, jsou samotné metody [`Rc<T>`][`Rc`] přidruženými funkcemi, které se nazývají pomocí [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! " Rc<T>Implementace traits jako `Clone` lze také volat pomocí plně kvalifikované syntaxe.
//! Někteří lidé dávají přednost použití plně kvalifikované syntaxe, zatímco jiní upřednostňují použití syntaxe volání metod.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Syntaxe volání metody
//! let rc2 = rc.clone();
//! // Plně kvalifikovaná syntaxe
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] nemá automaticky dereference k `T`, protože vnitřní hodnota již mohla být zrušena.
//!
//! # Klonovací odkazy
//!
//! Vytvoření nového odkazu na stejnou alokaci jako existujícího ukazatele počítaného odkazu se provádí pomocí `Clone` trait implementovaného pro [`Rc<T>`][`Rc`] a [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Dvě níže uvedené syntaxe jsou ekvivalentní.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a a b oba ukazují na stejné paměťové místo jako foo.
//! ```
//!
//! Syntaxe `Rc::clone(&from)` je nejvíce idiomatická, protože explicitněji vyjadřuje význam kódu.
//! Ve výše uvedeném příkladu tato syntaxe usnadňuje pochopení toho, že tento kód vytváří nový odkaz, nikoli kopíruje celý obsah foo.
//!
//! # Examples
//!
//! Zvažte scénář, kdy sadu `Gadgetů 'vlastní daný `Owner`.
//! Chceme, aby náš `Gadget`s poukazoval na jejich `Owner`.To nemůžeme udělat s jedinečným vlastnictvím, protože ke stejné `Owner` může patřit více než jeden gadget.
//! [`Rc`] umožňuje nám sdílet `Owner` mezi více `Gadget`s a nechat `Owner` zůstat přidělen tak dlouho, dokud na něm žádné body `Gadget` nebudou.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... další pole
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... další pole
//! }
//!
//! fn main() {
//!     // Vytvořte `Owner` s počítáním referencí.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Vytvořte `Gadget` patřící k `gadget_owner`.
//!     // Klonování `Rc<Owner>` nám dává nový ukazatel na stejnou alokaci `Owner`, čímž se zvyšuje počet odkazů v procesu.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Zlikvidujte naši lokální proměnnou `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // I přes upuštění od `gadget_owner` jsme stále schopni vytisknout název `Owner` z `Gadget`s.
//!     // Je to proto, že jsme upustili pouze od jednoho `Rc<Owner>`, nikoli od `Owner`, na který ukazuje.
//!     // Dokud existují další `Rc<Owner>` ukazující na stejnou alokaci `Owner`, zůstane aktivní.
//!     // Polní projekce `gadget1.owner.name` funguje, protože `Rc<Owner>` se automaticky dereferuje na `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Na konci funkce jsou `gadget1` a `gadget2` zničeny as nimi i poslední počítané odkazy na naši `Owner`.
//!     // Gadget Man je nyní také zničen.
//!     //
//! }
//! ```
//!
//! Pokud se naše požadavky změní a budeme také muset být schopni přejít z `Owner` na `Gadget`, narazíme na problémy.
//! Ukazatel [`Rc`] od `Owner` do `Gadget` zavádí cyklus.
//! To znamená, že jejich počet odkazů nikdy nemůže dosáhnout 0 a přidělení nikdy nebude zničeno:
//! únik paměti.Abychom to dokázali obejít, můžeme použít ukazatele [`Weak`].
//!
//! Rust ve skutečnosti zprvu dělá tuto smyčku poněkud obtížnou.Aby bylo možné dosáhnout dvou hodnot, které ukazují na sebe, musí být jedna z nich proměnlivá.
//! To je obtížné, protože [`Rc`] vynucuje bezpečnost paměti tím, že rozdává pouze sdílené odkazy na hodnotu, kterou zabalí, a tyto neumožňují přímou mutaci.
//! Část hodnoty, kterou chceme mutovat, musíme zabalit do [`RefCell`], který poskytuje *vnitřní mutabilitu*: metodu k dosažení mutability prostřednictvím sdílené reference.
//! [`RefCell`] vynucuje výpůjční pravidla Rust za běhu.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... další pole
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... další pole
//! }
//!
//! fn main() {
//!     // Vytvořte `Owner` s počítáním referencí.
//!     // Všimněte si, že jsme vložili vector `vlastníka` z`Gadget` do `RefCell`, abychom jej mohli mutovat prostřednictvím sdíleného odkazu.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Vytvořte `Gadget` patřící k `gadget_owner`, jako dříve.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Přidejte `Gadget` do svého `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` zde končí dynamická výpůjčka.
//!     }
//!
//!     // Iterace nad našimi `Gadget`s, tisk jejich podrobností.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` je `Weak<Gadget>`.
//!         // Protože ukazatele `Weak` nemohou zaručit, že přidělení stále existuje, musíme zavolat `upgrade`, který vrátí `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // V tomto případě víme, že alokace stále existuje, takže jednoduše `unwrap` `Option`.
//!         // Ve složitějším programu možná budete potřebovat ladné zpracování chyb pro výsledek `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Na konci funkce jsou `gadget_owner`, `gadget1` a `gadget2` zničeny.
//!     // Nyní neexistují žádné silné ukazatele (`Rc`) na gadgety, takže jsou zničeny.
//!     // Tím se vynuluje počet odkazů na Gadget Mana, takže bude také zničen.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// To je repr(C) až future-důkaz proti možnému přeskupení polí, což by narušilo jinak bezpečné [into|from]_raw() transmutovatelných vnitřních typů.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Ukazatel počítání referencí s jedním závitem.'Rc' znamená " Reference`
/// Counted'.
///
/// Další podrobnosti viz [module-level documentation](./index.html).
///
/// Vlastní metody `Rc` jsou všechny přidružené funkce, což znamená, že je musíte volat jako např. [`Rc::get_mut(&mut value)`][get_mut] místo `value.get_mut()`.
/// Tím se zabrání konfliktům s metodami vnitřního typu `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Tato bezpečnost je v pořádku, protože zatímco tento Rc je naživu, máme zaručeno, že vnitřní ukazatel je platný.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Konstruuje nový `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Všechny silné ukazatele vlastní implicitní slabý ukazatel, který zajišťuje, že slabý destruktor nikdy neuvolní alokaci, když je silný destruktor spuštěn, i když je slabý ukazatel uložen uvnitř silného.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Vytvoří novou `Rc<T>` pomocí slabého odkazu na sebe.
    /// Pokus o upgrade slabé reference před návratem této funkce bude mít za následek hodnotu `None`.
    ///
    /// Slabá reference však může být volně klonována a uložena pro pozdější použití.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... více polí
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Vytvořte vnitřní ve stavu "uninitialized" s jedinou slabou referencí.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Je důležité, abychom se nevzdali vlastnictví slabého ukazatele, jinak by mohla být paměť uvolněna v době, kdy se vrátí `data_fn`.
        // Pokud bychom opravdu chtěli předat vlastnictví, mohli bychom pro sebe vytvořit další slabý ukazatel, ale to by vedlo k dalším aktualizacím slabého počtu odkazů, které by jinak nebyly nutné.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Silné reference by měly společně vlastnit sdílenou slabou referenci, takže nespouštějte destruktor pro naši starou slabou referenci.
        //
        mem::forget(weak);
        strong
    }

    /// Vytváří nový model `Rc` s neinicializovaným obsahem.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Odložená inicializace:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Vytváří nový `Rc` s neinicializovaným obsahem, přičemž paměť je vyplněna bajty `0`.
    ///
    ///
    /// Viz [`MaybeUninit::zeroed`][zeroed] pro příklady správného a nesprávného použití této metody.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Vytvoří nový `Rc<T>` a vrátí chybu, pokud se přidělení nezdaří
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Všechny silné ukazatele vlastní implicitní slabý ukazatel, který zajišťuje, že slabý destruktor nikdy neuvolní alokaci, když je silný destruktor spuštěn, i když je slabý ukazatel uložen uvnitř silného.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Vytvoří nový `Rc` s neinicializovaným obsahem a vrátí chybu, pokud přidělení selže
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Odložená inicializace:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Vytvoří nový `Rc` s neinicializovaným obsahem, přičemž paměť je naplněna bajty `0`, vrací chybu, pokud přidělení selže
    ///
    ///
    /// Viz [`MaybeUninit::zeroed`][zeroed] pro příklady správného a nesprávného použití této metody.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Konstruuje nový `Pin<Rc<T>>`.
    /// Pokud `T` neimplementuje `Unpin`, pak `value` bude připnut v paměti a nebude jej možné přesunout.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Vrátí vnitřní hodnotu, pokud má `Rc` přesně jednu silnou referenci.
    ///
    /// Jinak se vrátí [`Err`] se stejným `Rc`, který byl předán.
    ///
    ///
    /// To uspěje, i když existují vynikající slabé reference.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // zkopírujte obsažený objekt

                // Označte Weaks, že je nelze povýšit snížením silného počtu, a poté odeberte implicitní ukazatel "strong weak" a zároveň zpracovávejte logiku přetažení pouhým vytvořením falešného slabého.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Vytvoří nový řez s počítáním odkazů s neinicializovaným obsahem.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Odložená inicializace:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Vytvoří nový řez s počítáním referencí s neinicializovaným obsahem, přičemž paměť je vyplněna bajty `0`.
    ///
    ///
    /// Viz [`MaybeUninit::zeroed`][zeroed] pro příklady správného a nesprávného použití této metody.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Převede na `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Stejně jako u [`MaybeUninit::assume_init`] je na volajícím, aby zaručil, že vnitřní hodnota je skutečně v inicializovaném stavu.
    ///
    /// Volání, když obsah ještě není plně inicializován, způsobí okamžité nedefinované chování.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Odložená inicializace:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Převede na `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Stejně jako u [`MaybeUninit::assume_init`] je na volajícím, aby zaručil, že vnitřní hodnota je skutečně v inicializovaném stavu.
    ///
    /// Volání, když obsah ještě není plně inicializován, způsobí okamžité nedefinované chování.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Odložená inicializace:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Využívá `Rc` a vrací zabalený ukazatel.
    ///
    /// Aby se zabránilo úniku paměti, musí být ukazatel převeden zpět na `Rc` pomocí [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Poskytuje nezpracovaný ukazatel na data.
    ///
    /// Počty nejsou nijak ovlivněny a `Rc` se nespotřebovává.
    /// Ukazatel je platný, pokud jsou v `Rc` silné počty.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // BEZPEČNOST: To nemůže projít Deref::deref nebo Rc::inner, protože
        // to je nutné k zachování původu raw/mut tak, aby např
        // `get_mut` může psát přes ukazatel po obnovení Rc přes `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Vytvoří `Rc<T>` ze surového ukazatele.
    ///
    /// Nezpracovaný ukazatel musel být dříve vrácen voláním [`Rc<U>::into_raw`][into_raw], kde `U` musí mít stejnou velikost a zarovnání jako `T`.
    /// To platí triviálně, pokud `U` je `T`.
    /// Všimněte si, že pokud `U` není `T`, ale má stejnou velikost a zarovnání, je to v podstatě jako transmutující odkazy různých typů.
    /// Další informace o tom, jaká omezení platí v tomto případě, najdete na [`mem::transmute`][transmute].
    ///
    /// Uživatel `from_raw` se musí ujistit, že konkrétní hodnota `T` je vynechána pouze jednou.
    ///
    /// Tato funkce je nebezpečná, protože nesprávné použití může vést k bezpečnosti paměti, i když k vrácenému `Rc<T>` nikdy není přistupováno.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Převeďte zpět na `Rc`, abyste zabránili úniku.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Další volání na `Rc::from_raw(x_ptr)` by byla paměťově nebezpečná.
    /// }
    ///
    /// // Paměť byla uvolněna, když `x` vyšel z rozsahu výše, takže `x_ptr` se teď houpá!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Obrátit posun a najít původní RcBox.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Vytvoří nový ukazatel [`Weak`] na toto přidělení.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Ujistěte se, že nevytváříme visící Slabé
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Získá počet ukazatelů [`Weak`] na toto přidělení.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Získá počet silných ukazatelů (`Rc`) na toto přidělení.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Vrátí `true`, pokud na tuto alokaci neexistují žádné jiné ukazatele `Rc` nebo [`Weak`].
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Vrátí proměnlivý odkaz do dané `Rc`, pokud neexistují žádné další ukazatele `Rc` nebo [`Weak`] na stejnou alokaci.
    ///
    ///
    /// Vrací [`None`] jinak, protože není bezpečné mutovat sdílenou hodnotu.
    ///
    /// Viz také [`make_mut`][make_mut], který bude [`clone`][clone] vnitřní hodnotu, když existují další ukazatele.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Vrátí proměnlivou referenci do dané `Rc` bez jakékoli kontroly.
    ///
    /// Viz také [`get_mut`], který je bezpečný a provádí příslušné kontroly.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Žádné další ukazatele `Rc` nebo [`Weak`] na stejnou alokaci nesmí být dereferencovány po dobu trvání vrácené půjčky.
    ///
    /// To je triviální případ, pokud takové ukazatele neexistují, například bezprostředně po `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Dáváme pozor, abychom *ne* vytvořili odkaz pokrývající pole "count", protože by to bylo v rozporu s přístupy k počtu odkazů (např.
        // od `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Vrátí `true`, pokud dva `Rc`s ukazují na stejnou alokaci (ve žíle podobné [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Dá měnitelnou referenci do dané `Rc`.
    ///
    /// Pokud existují další ukazatele `Rc` na stejnou alokaci, pak `make_mut` bude [`clone`] vnitřní hodnotu nové alokace, aby bylo zajištěno jedinečné vlastnictví.
    /// Toto se také označuje jako clone-on-write.
    ///
    /// Pokud na tuto alokaci neexistují žádné jiné ukazatele `Rc`, budou [`Weak`] ukazatele na tuto alokaci zrušeny.
    ///
    /// Viz také [`get_mut`], který selže místo klonování.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Nebudu nic klonovat
    /// let mut other_data = Rc::clone(&data);    // Nebudou klonována vnitřní data
    /// *Rc::make_mut(&mut data) += 1;        // Klony vnitřní data
    /// *Rc::make_mut(&mut data) += 1;        // Nebudu nic klonovat
    /// *Rc::make_mut(&mut other_data) *= 2;  // Nebudu nic klonovat
    ///
    /// // Nyní `data` a `other_data` ukazují na různé alokace.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] ukazatele budou odpojeny:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Musím naklonovat data, existují i další Rcs.
            // Předem přidělte paměť, abyste mohli přímo klonovanou hodnotu zapsat.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Stačí jen ukrást data, zbývá jen Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Odstranit implicitní silně slabý ref (není třeba vytvářet falešné Slabé zde-víme, že ostatní Weaks mohou za nás uklidit)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Tato bezpečnost je v pořádku, protože máme zaručeno, že vrácený ukazatel je *pouze* ukazatel, který bude kdy vrácen T.
        // Náš počet odkazů je v tomto okamžiku zaručeně 1 a požadovali jsme, aby samotný `Rc<T>` byl `mut`, takže vracíme jediný možný odkaz na alokaci.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Pokus o sesazení `Rc<dyn Any>` na konkrétní typ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Přidělí `RcBox<T>` s dostatečným prostorem pro možná vnitřní velikost, kde má hodnota poskytnuté rozložení.
    ///
    /// Funkce `mem_to_rcbox` je volána s datovým ukazatelem a musí vrátit zpět (potenciálně tlustý) ukazatel pro `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Vypočítejte rozložení pomocí rozložení dané hodnoty.
        // Dříve bylo rozložení počítáno na výrazu `&*(ptr as* const RcBox<T>)`, ale tím byla vytvořena nesprávně zarovnaná reference (viz #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Přidělí `RcBox<T>` s dostatečným prostorem pro vnitřní velikost s možnou velikostí, kde má hodnota poskytnuté rozložení, v případě selhání alokace vrátí chybu.
    ///
    ///
    /// Funkce `mem_to_rcbox` je volána s datovým ukazatelem a musí vrátit zpět (potenciálně tlustý) ukazatel pro `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Vypočítejte rozložení pomocí rozložení dané hodnoty.
        // Dříve bylo rozložení počítáno na výrazu `&*(ptr as* const RcBox<T>)`, ale tím byla vytvořena nesprávně zarovnaná reference (viz #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Přidělte rozložení.
        let ptr = allocate(layout)?;

        // Inicializujte RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Přiděluje `RcBox<T>` s dostatečným prostorem pro vnitřní velikost bez velikosti
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Přiřaďte `RcBox<T>` pomocí dané hodnoty.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Zkopírujte hodnotu jako bajty
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Uvolněte alokaci bez upuštění obsahu
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Přidělí `RcBox<[T]>` s danou délkou.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Zkopírujte prvky z řezu do nově přiděleného Rc <\[T\]>
    ///
    /// Nebezpečný, protože volající musí buď převzít vlastnictví, nebo svázat `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Vytvoří `Rc<[T]>` z iterátoru, o kterém je známo, že má určitou velikost.
    ///
    /// Chování není definováno, pokud je velikost nesprávná.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Ochranu Panic při klonování T prvků.
        // V případě panic budou prvky, které byly zapsány do nového RcBoxu, zahozeny a poté uvolněna paměť.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Ukazatel na první prvek
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Vše jasné.Zapomeňte na strážce, aby neuvolnil nový RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specializace trait použitá pro `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Spadne `Rc`.
    ///
    /// Tím se sníží počet silných odkazů.
    /// Pokud počet silných odkazů dosáhne nuly, pak jsou pouze další odkazy (pokud existují) [`Weak`], takže `drop` budeme mít vnitřní hodnotu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Netiskne nic
    /// drop(foo2);   // Vytiskne "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // zničit obsažený objekt
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // teď, když jsme zničili obsah, odeberte implicitní ukazatel "strong weak".
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Vytvoří klon ukazatele `Rc`.
    ///
    /// Tím se vytvoří další ukazatel na stejnou alokaci, čímž se zvýší počet silných odkazů.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Vytvoří nový `Rc<T>` s hodnotou `Default` pro `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack povolit specializaci na `Eq`, i když `Eq` má metodu.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Děláme tuto specializaci zde, a ne jako obecnější optimalizaci na `&T`, protože by to jinak přidalo náklady na všechny kontroly rovnosti u referencí.
/// Předpokládáme, že `Rc`s se používají k ukládání velkých hodnot, které se pomalu klonují, ale také těžké pro kontrolu rovnosti, což způsobí, že se tyto náklady snáze vyplatí.
///
/// Je také větší pravděpodobnost, že budou mít dva klony `Rc`, které ukazují na stejnou hodnotu, než dva " &T`.
///
/// Můžeme to udělat, pouze když `T: Eq` jako `PartialEq` může být záměrně nereflexivní.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Rovnost pro dvě `Rc`s.
    ///
    /// Dvě `Rc` jsou stejná, pokud jsou jejich vnitřní hodnoty stejné, i když jsou uloženy v různých alokacích.
    ///
    /// Pokud `T` také implementuje `Eq` (z čehož vyplývá reflexivita rovnosti), jsou dvě " Rc`, která ukazují na stejnou alokaci, vždy stejná.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Nerovnost pro dvě Rc.
    ///
    /// Dvě `Rc` jsou nerovné, pokud jsou jejich vnitřní hodnoty nerovné.
    ///
    /// Pokud `T` také implementuje `Eq` (z čehož vyplývá reflexivita rovnosti), dvě " Rc`, která ukazují na stejnou alokaci, nejsou nikdy nerovná.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Částečné srovnání dvou `Rc`.
    ///
    /// Dva jsou porovnány voláním `partial_cmp()` na jejich vnitřních hodnotách.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Méně než srovnání pro dvě `Rc`s.
    ///
    /// Dva jsou porovnány voláním `<` na jejich vnitřních hodnotách.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Porovnání " menší než nebo rovno`pro dvě " Rc`.
    ///
    /// Dva jsou porovnány voláním `<=` na jejich vnitřních hodnotách.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Větší než srovnání pro dvě `Rc`s.
    ///
    /// Dva jsou porovnány voláním `>` na jejich vnitřních hodnotách.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Porovnání " větší než nebo rovno`pro dvě " Rc`.
    ///
    /// Dva jsou porovnány voláním `>=` na jejich vnitřních hodnotách.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Srovnání pro dvě `Rc`s.
    ///
    /// Dva jsou porovnány voláním `cmp()` na jejich vnitřních hodnotách.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Přiřaďte řez počítaný podle referencí a vyplňte jej klonováním položek `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Přiřaďte řezem počítaný řetězec a zkopírujte do něj `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Přiřaďte řezem počítaný řetězec a zkopírujte do něj `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Přesuňte orámovaný objekt do nové alokace spočítané reference.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Přiřaďte řez počítaný podle referencí a přesuňte do něj položky `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Nechte Vec uvolnit paměť, ale ne zničit její obsah
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Vezme každý prvek v `Iterator` a shromáždí jej do `Rc<[T]>`.
    ///
    /// # Výkonové charakteristiky
    ///
    /// ## Obecný případ
    ///
    /// Obecně se shromažďování do `Rc<[T]>` provádí tak, že se nejprve shromažďuje do `Vec<T>`.To znamená, když píšete následující:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// chová se, jako bychom napsali:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Zde nastává první sada přidělení.
    ///     .into(); // Zde nastane druhá alokace pro `Rc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// To přidělí tolikrát, kolikrát je potřeba pro konstrukci `Vec<T>`, a poté se přidělí jednou pro přeměnu `Vec<T>` na `Rc<[T]>`.
    ///
    ///
    /// ## Iterátory známé délky
    ///
    /// Když váš `Iterator` implementuje `TrustedLen` a má přesnou velikost, bude pro `Rc<[T]>` provedena jedna alokace.Například:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Dojde zde pouze k jedné alokaci.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Specializace trait použitá pro sběr do `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // To je případ iterátoru `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // BEZPEČNOST: Musíme zajistit, aby iterátor měl přesnou délku a my ano.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Vraťte se k normální implementaci.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` je verze [`Rc`], která obsahuje nevlastnící odkaz na spravovanou alokaci.Alokace je přístupná voláním [`upgrade`] na ukazateli `Weak`, který vrací [`Option`]`<`[`Rc`] `<T>>`.
///
/// Vzhledem k tomu, že odkaz `Weak` se do vlastnictví nezapočítává, nezabrání tomu, aby byla hodnota uložená v alokaci zrušena, a samotný `Weak` neposkytuje žádné záruky ohledně toho, že hodnota stále existuje.
/// Může tedy vrátit [`None`], když [`upgrade`] d.
/// Všimněte si však, že odkaz `Weak`*nezabraňuje* přidělení samotné alokace (záložního úložiště).
///
/// Ukazatel `Weak` je užitečný pro uchování dočasného odkazu na alokaci spravovanou [`Rc`], aniž by bylo zabráněno tomu, aby byla zrušena jeho vnitřní hodnota.
/// Používá se také k prevenci cyklických odkazů mezi ukazateli [`Rc`], protože vzájemné vlastnictví odkazů by nikdy nedovolilo zrušit ani jeden [`Rc`].
/// Například strom může mít silné ukazatele [`Rc`] z nadřazených uzlů na děti a ukazatele `Weak` z dětí zpět na jejich rodiče.
///
/// Typickým způsobem, jak získat ukazatel `Weak`, je volání [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Jedná se o `NonNull`, který umožňuje optimalizovat velikost tohoto typu ve výčtu, ale není to nutně platný ukazatel.
    //
    // `Weak::new` nastaví to na `usize::MAX`, takže nemusí přidělit prostor na haldě.
    // To není hodnota, kterou skutečný ukazatel bude mít, protože RcBox má zarovnání alespoň 2.
    // To je možné pouze v případě `T: Sized`;bezrozměrný `T` se nikdy nehoupá.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Vytváří nový `Weak<T>`, aniž by přidělil jakoukoli paměť.
    /// Volání [`upgrade`] na návratovou hodnotu vždy dává [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Typ pomocníka umožňující přístup k počtu odkazů bez provádění jakýchkoli tvrzení o datovém poli.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Vrátí surový ukazatel na objekt `T`, na který ukazuje tento `Weak<T>`.
    ///
    /// Ukazatel je platný, pouze pokud existují silné odkazy.
    /// Ukazatel může být visící, nezarovnaný nebo jinak [`null`] jinak.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Oba ukazují na stejný objekt
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Silní zde ho udržují při životě, takže k objektu můžeme stále přistupovat.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ale už ne.
    /// // Můžeme udělat weak.as_ptr(), ale přístup k ukazateli by vedl k nedefinovanému chování.
    /// // assert_eq! ("ahoj", nebezpečné {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Pokud se ukazatel houpá, vrátíme sentinel přímo.
            // Toto nemůže být platná adresa užitečného zatížení, protože užitečné zatížení je alespoň stejně zarovnané jako RcBox (usize).
            ptr as *const T
        } else {
            // BEZPEČNOST: pokud is_dangling vrátí hodnotu false, pak je ukazatel dereferencable.
            // Už v tomto okamžiku může být užitečné zatížení zrušeno a my musíme zachovat původ, proto používejte manipulaci surového ukazatele.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Spotřebuje `Weak<T>` a promění jej v surový ukazatel.
    ///
    /// Tím se slabý ukazatel převede na surový ukazatel, při zachování vlastnictví jedné slabé reference (slabý počet není touto operací upraven).
    /// Lze jej proměnit zpět na `Weak<T>` s [`from_raw`].
    ///
    /// Platí stejná omezení přístupu k cíli ukazatele jako u [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Převede surový ukazatel dříve vytvořený [`into_raw`] zpět na `Weak<T>`.
    ///
    /// To lze použít k bezpečnému získání silné reference (voláním [`upgrade`] později) nebo k uvolnění slabého počtu upuštěním `Weak<T>`.
    ///
    /// Trvá vlastnictví jedné slabé reference (s výjimkou ukazatelů vytvořených [`new`], protože tyto nic nevlastní; metoda na nich stále funguje).
    ///
    /// # Safety
    ///
    /// Ukazatel musí pocházet z [`into_raw`] a musí stále vlastnit jeho potenciálně slabý odkaz.
    ///
    /// V době volání je povoleno, aby silný počet byl 0.
    /// Toto však přebírá vlastnictví jedné slabé reference aktuálně představované jako surový ukazatel (slabý počet není touto operací upraven), a proto musí být spárován s předchozím voláním [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Snížit poslední slabý počet.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Viz Weak::as_ptr pro kontext, jak je odvozen vstupní ukazatel.

        let ptr = if is_dangling(ptr as *mut T) {
            // Toto je visící Slabý.
            ptr as *mut RcBox<T>
        } else {
            // Jinak máme zaručeno, že ukazatel pochází z nerozmotávajícího se Slabého.
            // BEZPEČNOST: data_offset je bezpečné volat, protože ptr odkazuje na skutečné (potenciálně upuštěné) T.
            let offset = unsafe { data_offset(ptr) };
            // Otočíme tedy offset, abychom získali celý RcBox.
            // BEZPEČNOST: ukazatel pocházel z Weak, takže tento offset je bezpečný.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // BEZPEČNOST: nyní jsme obnovili původní ukazatel Slabý, takže můžeme vytvořit Slabý.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Pokusy o upgrade ukazatele `Weak` na [`Rc`], zpoždění poklesu vnitřní hodnoty, pokud bude úspěšné.
    ///
    ///
    /// Vrátí [`None`], pokud byla mezitím zrušena vnitřní hodnota.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Zničte všechny silné ukazatele.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Získá počet silných ukazatelů (`Rc`) směřujících k této alokaci.
    ///
    /// Pokud byl `self` vytvořen pomocí [`Weak::new`], vrátí hodnotu 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Získá počet ukazatelů `Weak` ukazujících na toto přidělení.
    ///
    /// Pokud nezůstanou žádné silné ukazatele, vrátí se nula.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // odečíst implicitní slabý ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Vrátí `None`, když je ukazatel visící a není přiděleno `RcBox`, (tj. Když tento `Weak` byl vytvořen `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Dáváme pozor, abychom *ne* vytvořili odkaz pokrývající pole "data", protože pole může být současně mutováno (například pokud je zrušen poslední `Rc`, datové pole bude zrušeno na místě).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Vrátí `true`, pokud dva `Slabé` ukazují na stejnou alokaci (podobnou [`ptr::eq`]), nebo pokud oba neukazují na žádnou alokaci (protože byly vytvořeny pomocí `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Protože toto porovnává ukazatele, znamená to, že `Weak::new()` se budou navzájem rovnat, i když neukazují na žádnou alokaci.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Srovnání `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Spadne ukazatel `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Netiskne nic
    /// drop(foo);        // Vytiskne "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // slabý počet začíná na 1 a bude nulový, pouze pokud všechny silné ukazatele zmizely.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Vytvoří klon ukazatele `Weak`, který ukazuje na stejnou alokaci.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Vytvoří novou `Weak<T>`, přidělí paměť pro `T` bez její inicializace.
    /// Volání [`upgrade`] na návratovou hodnotu vždy dává [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Zkontrolovali jsme_add, abychom mohli bezpečně jednat s mem::forget.Zejména
// pokud máte mem::forget Rcs (nebo Weaks), může počet odkazů přetéct a pak můžete uvolnit alokaci, zatímco existují vynikající Rcs (nebo Weaks).
//
// Potratíme, protože se jedná o tak zvrhlý scénář, že se nestaráme o to, co se stane-žádný skutečný program by to nikdy neměl zažít.
//
// To by mělo mít zanedbatelnou režii, protože ve skutečnosti nemusíte tolik klonovat v Rust díky vlastnictví a sémantice tahů.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Chceme přerušit přetečení namísto snížení hodnoty.
        // Počet odkazů nebude nikdy nulový, když se to volá;
        // nicméně zde vložíme přerušení, abychom naznačili LLVM při jinak zmeškané optimalizaci.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Chceme přerušit přetečení namísto snížení hodnoty.
        // Počet odkazů nebude nikdy nulový, když se to volá;
        // nicméně zde vložíme přerušení, abychom naznačili LLVM při jinak zmeškané optimalizaci.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Získejte offset v rámci `RcBox` pro užitečné zatížení za ukazatelem.
///
/// # Safety
///
/// Ukazatel musí ukazovat na (a mít platná metadata pro) dříve platnou instanci T, ale T je povoleno zrušit.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Zarovnejte hodnotu bez velikosti na konec RcBox.
    // Protože RcBox je repr(C), bude to vždy poslední pole v paměti.
    // BEZPEČNOST: jelikož jedinými možnými typy bez velikosti jsou řezy, objekty trait,
    // a externích typů je požadavek na vstupní bezpečnost v současné době dostatečný pro splnění požadavků align_of_val_raw;toto je implementační detail jazyka, na který se nelze spoléhat mimo std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}