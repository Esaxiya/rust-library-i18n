//! Nástroje pro formátování a tisk `String`s.
//!
//! Tento modul obsahuje podporu běhu pro rozšíření syntaxe [`format!`].
//! Toto makro je implementováno v kompilátoru, aby emitovalo volání tohoto modulu za účelem formátování argumentů za běhu do řetězců.
//!
//! # Usage
//!
//! Makro [`format!`] má být obeznámeno s těmi, kteří přicházejí z funkcí `printf`/`fprintf` C nebo `str.format` funkce Python.
//!
//! Některé příklady rozšíření [`format!`] jsou:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" s úvodními nulami
//! ```
//!
//! Z nich můžete vidět, že první argument je formátovací řetězec.Kompilátor vyžaduje, aby to byl řetězcový literál;nemůže to být předaná proměnná (za účelem kontroly platnosti).
//! Kompilátor poté analyzuje formátovací řetězec a určí, zda je poskytnutý seznam argumentů vhodný k předání do tohoto formátovacího řetězce.
//!
//! Chcete-li převést jednu hodnotu na řetězec, použijte metodu [`to_string`].Použije se formátování trait ve formátu [`Display`].
//!
//! ## Poziční parametry
//!
//! Každý argument formátování může určit, na který argument hodnoty odkazuje, a pokud je vynechán, předpokládá se, že je "the next argument".
//! Například formátovací řetězec `{} {} {}` bude trvat tři parametry a budou formátovány ve stejném pořadí, v jakém jsou uvedeny.
//! Řetězec formátu `{2} {1} {0}` by však formátoval argumenty v opačném pořadí.
//!
//! Věci mohou být trochu komplikované, jakmile začnete míchat dva typy pozičních specifikátorů.Specifikátor "next argument" lze považovat za iterátor nad argumentem.
//! Pokaždé, když je vidět specifikátor "next argument", iterátor postupuje.To vede k takovému chování:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Interní iterátor nad argumentem nebyl pokročilý v době, kdy je vidět první `{}`, takže vytiskne první argument.Poté, co dosáhne druhého `{}`, iterátor postoupil vpřed na druhý argument.
//! Parametry, které výslovně pojmenují svůj argument, v zásadě neovlivní parametry, které nepojmenují argument z hlediska pozičních specifikátorů.
//!
//! Řetězec formátu je vyžadován pro použití všech jeho argumentů, jinak se jedná o chybu při kompilaci.Ve řetězci formátu můžete odkazovat na stejný argument vícekrát.
//!
//! ## Pojmenované parametry
//!
//! Samotný Rust nemá ekvivalent pojmenovaných parametrů k funkci podobný Python, ale makro [`format!`] je přípona syntaxe, která mu umožňuje využívat pojmenované parametry.
//! Pojmenované parametry jsou uvedeny na konci seznamu argumentů a mají syntaxi:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Například následující výrazy [`format!`] používají pojmenovaný argument:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Není platné vkládat poziční parametry (ty bez jmen) za argumenty, které mají názvy.Stejně jako u pozičních parametrů není platné poskytovat pojmenované parametry, které nepoužívá formátovací řetězec.
//!
//! # Parametry formátování
//!
//! Každý formátovaný argument lze transformovat řadou parametrů formátování (odpovídá `format_spec` v [the syntax](#syntax)). Tyto parametry ovlivňují řetězcovou reprezentaci formátovaného parametru.
//!
//! ## Width
//!
//! ```
//! // Všechny tyto tisk "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Toto je parametr pro "minimum width", který by měl formát zabírat.
//! Pokud řetězec hodnoty nevyplní tolik znaků, použije se pro zabírání požadovaného místa výplň zadaná fill/alignment (viz níže).
//!
//! Hodnotu šířky lze také zadat jako [`usize`] v seznamu parametrů přidáním postfixu `$`, což znamená, že druhým argumentem je [`usize`] určující šířku.
//!
//! Odkaz na argument se syntaxí dolaru neovlivní čítač "next argument", takže je obvykle vhodné odkazovat na argumenty podle polohy nebo použít pojmenované argumenty.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Volitelný znak výplně a zarovnání je poskytován normálně ve spojení s parametrem [`width`](#width).Musí být definováno před `width`, hned za `:`.
//! To znamená, že pokud je formátovaná hodnota menší než `width`, budou kolem ní vytištěny některé další znaky.
//! Výplň přichází v následujících variantách pro různá zarovnání:
//!
//! * `[fill]<` - argument je zarovnán doleva ve sloupcích `width`
//! * `[fill]^` - argument je zarovnán na střed ve sloupcích `width`
//! * `[fill]>` - argument je zarovnán doprava ve sloupcích `width`
//!
//! Výchozí hodnota [fill/alignment](#fillalignment) pro nečíselné znaky je mezera a zarovnání doleva.Výchozí nastavení pro číselné formátory je také znak mezery, ale se zarovnáním doprava.
//! Pokud je pro numeriku zadán příznak `0` (viz níže), pak je implicitní znak výplně `0`.
//!
//! U některých typů nemusí být zarovnání implementováno.Zejména není obecně implementován pro `Debug` trait.
//! Dobrým způsobem, jak zajistit, aby byla použita výplň, je naformátovat váš vstup a poté tento výsledný řetězec doplnit, abyste získali svůj výstup:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => " Ahoj Some("hi")!`
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! To jsou všechny příznaky, které mění chování formátovacího modulu.
//!
//! * `+` - Toto je určeno pro číselné typy a označuje, že znaménko by mělo být vždy vytištěno.Pozitivní znaky se ve výchozím nastavení nikdy nevytisknou a záporné znaménko se ve výchozím nastavení vytiskne pouze u modelu `Signed` trait.
//! Tento příznak označuje, že by měl být vždy vytištěn správný znak (`+` nebo `-`).
//! * `-` - V současné době se nepoužívá
//! * `#` - Tento příznak označuje, že by měla být použita forma tisku "alternate".Alternativní formy jsou:
//!     * `#?` - pěkně vytiskněte formátování [`Debug`]
//!     * `#x` - předchází argument `0x`
//!     * `#X` - předchází argument `0x`
//!     * `#b` - předchází argument `0b`
//!     * `#o` - předchází argument `0o`
//! * `0` - To se používá k označení celočíselných formátů, že výplň do `width` by měla být provedena pomocí znaku `0`, stejně jako být přihlášena.
//! Formát jako `{:08}` by přinesl `00000001` pro celé číslo `1`, zatímco stejný formát by přinesl `-0000001` pro celé číslo `-1`.
//! Všimněte si, že negativní verze má o jednu nulu méně než pozitivní verze.
//!         Všimněte si, že vykládací nuly jsou vždy umístěny za znaménkem (pokud existuje) a před číslicemi.Při použití společně s příznakem `#` platí podobné pravidlo: vycpávky s nulami se vkládají za předponu, ale před číslice.
//!         Předpona je zahrnuta v celkové šířce.
//!
//! ## Precision
//!
//! U nečíselných typů to lze považovat za "maximum width".
//! Pokud je výsledný řetězec delší než tato šířka, pak je zkrácen až na tento počet znaků a tato zkrácená hodnota je emitována se správnými `fill`, `alignment` a `width`, pokud jsou tyto parametry nastaveny.
//!
//! U integrálních typů je toto ignorováno.
//!
//! U typů s plovoucí desetinnou čárkou to označuje, kolik číslic za desetinnou čárkou by se mělo vytisknout.
//!
//! Existují tři možné způsoby, jak určit požadovanou `precision`:
//!
//! 1. Celé číslo `.N`:
//!
//!    celé číslo `N` samo o sobě je přesnost.
//!
//! 2. Celé číslo nebo jméno následované znakem dolaru `.N$`:
//!
//!    jako přesnost použijte format *argument*`N` (což musí být `usize`).
//!
//! 3. Hvězdička `.*`:
//!
//!    `.*` znamená, že tento `{...}` je spojen spíše s *dvěma* vstupy formátu než s jedním: první vstup má přesnost `usize` a druhý obsahuje hodnotu pro tisk.
//!    Všimněte si, že v tomto případě, pokud použijete formátovací řetězec `{<arg>:<spec>.*}`, pak část `<arg>` odkazuje na* hodnotu * k tisku a `precision` musí přijít na vstupu před `<arg>`.
//!
//! Například následující volání všechna tisknou stejnou věc `Hello x is 0.01000`:
//!
//! ```
//! // Ahoj {arg 0 ("x")} je {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Ahoj {arg 1 ("x")} je {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Ahoj {arg 0 ("x")} je {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Ahoj {next arg ("x")} je {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Ahoj {next arg ("x")} je {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Ahoj {next arg ("x")} je {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Zatímco tyto:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! tisknout tři výrazně odlišné věci:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! V některých programovacích jazycích závisí chování funkcí formátování řetězců na nastavení národního prostředí operačního systému.
//! Funkce formátu poskytované standardní knihovnou Rust nemají žádnou koncepci národního prostředí a budou produkovat stejné výsledky ve všech systémech bez ohledu na konfiguraci uživatele.
//!
//! Například následující kód vždy vytiskne `1.5`, i když národní prostředí systému používá oddělovač desetinných míst než tečku.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Doslovné znaky `{` a `}` mohou být zahrnuty do řetězce jejich předcházením se stejným znakem.Například znak `{` je uniknut s `{{` a znak `}` je unikán s `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Abychom to shrnuli, zde najdete úplnou gramatiku řetězců formátu.
//! Syntaxe použitého formátovacího jazyka je čerpána z jiných jazyků, takže by neměla být příliš cizí.Argumenty jsou formátovány pomocí syntaxe podobné Python, což znamená, že argumenty jsou obklopeny `{}` namísto C-like `%`.
//! Skutečná gramatika pro syntaxi formátování je:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Ve výše uvedené gramatice nesmí `text` obsahovat žádné znaky `'{'` nebo `'}'`.
//!
//! # Formátování traits
//!
//! Když požadujete formátování argumentu konkrétním typem, ve skutečnosti požadujete, aby se argument připisoval konkrétní trait.
//! To umožňuje formátování více skutečných typů pomocí `{:x}` (například [`i8`] i [`isize`]).Aktuální mapování typů na traits je:
//!
//! * *nic* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] s malými hexadecimálními celými čísly
//! * `X?` ⇒ [`Debug`] s velkými hexadecimálními celými čísly
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! To znamená, že jakýkoli typ argumentu, který implementuje [`fmt::Binary`][`Binary`] trait, lze poté naformátovat pomocí `{:b}`.Pro tyto traits poskytuje implementace i řada primitivních typů standardní knihovna.
//!
//! Pokud není zadán žádný formát (jako v `{}` nebo `{:6}`), pak použitý formát trait je [`Display`] trait.
//!
//! Při implementaci formátu trait pro svůj vlastní typ budete muset implementovat metodu podpisu:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // náš vlastní typ
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Váš typ bude předán jako `self` by-reference a poté by funkce měla vydávat výstup do proudu `f.buf`.Je na každé implementaci formátu trait, aby správně dodržovala požadované parametry formátování.
//! Hodnoty těchto parametrů budou uvedeny v polích struktury [`Formatter`].Abychom tomu pomohli, struktura [`Formatter`] také poskytuje některé pomocné metody.
//!
//! Návratová hodnota této funkce je navíc [`fmt::Result`], což je alias typu [`Result`]`<(),`[[std: : fmt::Error`]`> `.
//! Implementace formátování by měly zajistit, aby šířily chyby z [`Formatter`] (např. Při volání [`write!`]).
//! Nikdy by však neměly chybně vracet chyby.
//! To znamená, že implementace formátování musí a může vrátit chybu pouze v případě, že předaná [`Formatter`] vrátí chybu.
//! Důvodem je, že na rozdíl od toho, co může naznačovat podpis funkce, je formátování řetězce neomylnou operací.
//! Tato funkce vrací pouze výsledek, protože zápis do podkladového proudu může selhat a musí poskytnout způsob, jak šířit skutečnost, že došlo k chybě, zpět do zásobníku.
//!
//! Příklad implementace formátování traits by vypadal takto:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Hodnota `f` implementuje `Write` trait, což je to, co se píše!makro očekává.
//!         // Toto formátování ignoruje různé příznaky poskytované formátovacím řetězcům.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Různé traits umožňují různé formy výstupu typu.
//! // Smyslem tohoto formátu je vytisknout velikost vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Respektujte příznaky formátování pomocí pomocné metody `pad_integral` na objektu Formatter.
//!         // Podrobnosti najdete v dokumentaci metody a funkci `pad` lze použít k vyplnění řetězců.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Tyto dva formátování traits mají odlišné účely:
//!
//! - [`fmt::Display`][`Display`] implementace tvrdí, že typ lze kdykoli věrně reprezentovat jako řetězec UTF-8.** Neočekává se, že všechny typy implementují [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] implementace by měly být implementovány pro **všechny** veřejné typy.
//!   Výstup bude obvykle představovat vnitřní stav co nejvěrněji.
//!   Účelem [`Debug`] trait je usnadnit ladění kódu Rust.Ve většině případů je použití `#[derive(Debug)]` dostačující a doporučené.
//!
//! Některé příklady výstupu z obou traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Související makra
//!
//! V rodině [`format!`] existuje řada souvisejících maker.Ty, které jsou aktuálně implementovány, jsou:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! This and [`writeln!`] are two macros which are used to emit the format string to a specified stream.Slouží k zabránění mezilehlému přidělení řetězců formátu a místo toho přímo zapisuje výstup.
//! Pod kapotou tato funkce ve skutečnosti vyvolává funkci [`write_fmt`] definovanou na [`std::io::Write`] trait.
//! Příklad použití je:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Toto a [`println!`] vydávají svůj výstup do stdout.Podobně jako u makra [`write!`] je cílem těchto maker vyhnout se mezilehlému přidělení při tisku výstupu.Příklad použití je:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Makra [`eprint!`] a [`eprintln!`] jsou identická s makry [`print!`] a [`println!`], kromě toho, že vydávají svůj výstup do stderr.
//!
//! ### `format_args!`
//!
//! Toto je zvědavé makro, které se používá k bezpečnému průchodu neprůhledného objektu popisujícího formátovací řetězec.Tento objekt nevyžaduje k vytvoření žádné přidělení haldy a odkazuje pouze na informace v zásobníku.
//! Pod kapotou jsou z hlediska toho implementována všechna související makra.
//! Nejprve je příklad použití:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Výsledkem makra [`format_args!`] je hodnota typu [`fmt::Arguments`].
//! Tuto strukturu lze poté předat funkcím [`write`] a [`format`] uvnitř tohoto modulu za účelem zpracování formátovacího řetězce.
//! Cílem tohoto makra je ještě více zabránit zprostředkující alokaci při práci s formátovacími řetězci.
//!
//! Například knihovna pro protokolování mohla použít standardní syntaxi formátování, ale interně by procházela kolem této struktury, dokud nebude určeno, kam má výstup směřovat.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Funkce `format` přebírá strukturu [`Arguments`] a vrací výsledný formátovaný řetězec.
///
///
/// Instanci [`Arguments`] lze vytvořit pomocí makra [`format_args!`].
///
/// # Examples
///
/// Základní použití:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Mějte na paměti, že použití [`format!`] může být výhodnější.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}