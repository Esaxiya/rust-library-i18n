#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Obsah nové paměti je neinicializován.
    Uninitialized,
    /// Je zaručeno, že nová paměť bude vynulována.
    Zeroed,
}

/// Nízkoúrovňový nástroj pro ergonomičtější přidělování, přerozdělování a přidělení vyrovnávací paměti na haldě, aniž byste se museli starat o všechny případy spojené s rohem.
///
/// Tento typ je vynikající pro vytváření vlastních datových struktur, jako jsou Vec a VecDeque.
/// Zejména:
///
/// * Produkuje `Unique::dangling()` na typech nulové velikosti.
/// * Produkuje `Unique::dangling()` při alokaci nulové délky.
/// * Vyhne se uvolnění `Unique::dangling()`.
/// * Zachytí všechna přetečení ve výpočtech kapacity (povýší je na "capacity overflow" panics).
/// * Chrání před 32bitovými systémy, které přidělují více než isize::MAX bajtů.
/// * Chrání před přetékáním vaší délky.
/// * Vyzývá `handle_alloc_error` k omylnému přidělení.
/// * Obsahuje `ptr::Unique` a poskytuje tak uživateli všechny související výhody.
/// * Použije přebytek vrácený od alokátoru k využití největší dostupné kapacity.
///
/// Tento typ každopádně nekontroluje paměť, kterou spravuje.Při upuštění *uvolní* svou paměť, ale *se* nepokusí * odhodit její obsah.
/// Je na uživateli `RawVec`, aby zvládl skutečné věci *uložené* uvnitř `RawVec`.
///
/// Všimněte si, že přebytek typů nulové velikosti je vždy nekonečný, takže `capacity()` vždy vrátí `usize::MAX`.
/// To znamená, že při použití tohoto typu u modelu `Box<[T]>` musíte být opatrní, protože `capacity()` nebude mít délku.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): To existuje, protože `#[unstable]` `const fn`s nemusí odpovídat `min_const_fn`, a proto je nelze volat ani v`min_const_fn`s.
    ///
    /// Pokud změníte `RawVec<T>::new` nebo závislosti, dejte pozor, abyste nezaváděli nic, co by skutečně porušovalo `min_const_fn`.
    ///
    /// NOTE: Tomuto hacku bychom se mohli vyhnout a zkontrolovat shodu s nějakým atributem `#[rustc_force_min_const_fn]`, který vyžaduje shodu s `min_const_fn`, ale nutně neumožňuje jeho volání v `stable(...) const fn`/uživatelský kód neumožňuje `foo`, když je `#[rustc_const_unstable(feature = "foo", issue = "01234")]` přítomen.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Vytvoří největší možnou `RawVec` (na haldě systému) bez přidělení.
    /// Pokud má `T` kladnou velikost, pak je to `RawVec` s kapacitou `0`.
    /// Pokud je `T` nulové velikosti, vytvoří `RawVec` s kapacitou `usize::MAX`.
    /// Užitečné pro implementaci zpožděného přidělení.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Vytvoří `RawVec` (na haldě systému) s přesně požadavky na kapacitu a zarovnání pro `[T; capacity]`.
    /// To odpovídá volání `RawVec::new`, když `capacity` je `0` nebo `T` je nulové velikosti.
    /// Pokud je `T` nulové velikosti, znamená to, že *nedostanete*`RawVec` s požadovanou kapacitou.
    ///
    /// # Panics
    ///
    /// Panics, pokud požadovaná kapacita překročí `isize::MAX` bajtů.
    ///
    /// # Aborts
    ///
    /// Přerušení na OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Stejně jako `with_capacity`, ale zaručuje, že vyrovnávací paměť je vynulována.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Rekonstituuje `RawVec` z ukazatele a kapacity.
    ///
    /// # Safety
    ///
    /// `ptr` musí být přidělen (na haldě systému) a s daným `capacity`.
    /// U velikostí typů `capacity` nesmí překročit `isize::MAX`.(týká se pouze 32bitových systémů).
    /// ZST vectors mohou mít kapacitu až `usize::MAX`.
    /// Pokud `ptr` a `capacity` pocházejí z `RawVec`, pak je to zaručeno.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Drobní Vecové jsou hloupí.Přeskočit na:
    // - 8, pokud je velikost prvku 1, protože jakýkoli alokátor haldy pravděpodobně zaokrouhlí požadavek menší než 8 bajtů na nejméně 8 bajtů.
    //
    // - 4 pokud jsou prvky střední velikosti (<=1 KiB).
    // - 1 jinak, aby se zabránilo plýtvání příliš velkým prostorem pro velmi krátké Vecs.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Jako `new`, ale parametrizovaný výběrem alokátoru pro vrácenou `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` znamená "unallocated".typy nulové velikosti jsou ignorovány.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Jako `with_capacity`, ale parametrizovaný výběrem alokátoru pro vrácenou `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Jako `with_capacity_zeroed`, ale parametrizovaný výběrem alokátoru pro vrácenou `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Převádí `Box<[T]>` na `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Převede celou vyrovnávací paměť na `Box<[MaybeUninit<T>]>` se zadaným `len`.
    ///
    /// Všimněte si, že to správně rekonstituuje všechny změny `cap`, které mohly být provedeny.(Podrobnosti viz popis typu.)
    ///
    /// # Safety
    ///
    /// * `len` - musí být větší nebo roven naposledy požadované kapacitě a-
    /// * `len` musí být menší nebo rovno `self.capacity()`.
    ///
    /// Všimněte si, že požadovaná kapacita a `self.capacity()` se mohou lišit, protože alokátor by mohl přerozdělit a vrátit větší blok paměti, než bylo požadováno.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Zdravý rozum-zkontrolujte polovinu bezpečnostního požadavku (druhou polovinu nemůžeme zkontrolovat).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Zde se vyhýbáme `unwrap_or_else`, protože nafoukne množství generovaného LLVM IR.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Rekonstituuje `RawVec` z ukazatele, kapacity a alokátoru.
    ///
    /// # Safety
    ///
    /// `ptr` musí být přidělen (prostřednictvím daného alokátoru `alloc`) a s daným `capacity`.
    /// U velikostí typů `capacity` nesmí překročit `isize::MAX`.
    /// (týká se pouze 32bitových systémů).
    /// ZST vectors mohou mít kapacitu až `usize::MAX`.
    /// Pokud `ptr` a `capacity` pocházejí z `RawVec` vytvořeného pomocí `alloc`, pak je to zaručeno.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Získá surový ukazatel na začátek přidělení.
    /// Všimněte si, že toto je `Unique::dangling()`, pokud `capacity == 0` nebo `T` má nulovou velikost.
    /// V prvním případě musíte být opatrní.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Získá kapacitu přidělení.
    ///
    /// Toto bude vždy `usize::MAX`, pokud je `T` nulové velikosti.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Vrátí sdílený odkaz na alokátor podporující tento `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Máme přidělenou část paměti, takže můžeme obejít kontroly běhu, abychom získali naše aktuální rozložení.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Zajišťuje, že vyrovnávací paměť obsahuje alespoň dostatek místa pro uložení prvků `len + additional`.
    /// Pokud již nemá dostatek kapacity, přerozdělí dostatek místa plus pohodlný uvolněný prostor, aby bylo možné získat amortizované chování *O*(1).
    ///
    /// Omezí toto chování, pokud by se zbytečně způsobilo panic.
    ///
    /// Pokud `len` překročí `self.capacity()`, může dojít k selhání skutečného přidělení požadovaného prostoru.
    /// To není opravdu nebezpečné, ale nebezpečný kód *, který napíšete*, který závisí na chování této funkce, se může zlomit.
    ///
    /// To je ideální pro implementaci operace hromadného stisknutí, jako je `extend`.
    ///
    /// # Panics
    ///
    /// Panics, pokud nová kapacita překročí `isize::MAX` bajtů.
    ///
    /// # Aborts
    ///
    /// Přerušení na OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // rezerva by se přerušila nebo zpanikařila, pokud by hodnota překročila `isize::MAX`, takže je nyní bezpečné ji nezaškrtnout.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Stejné jako `reserve`, ale vrátí se k chybám namísto paniky nebo přerušení.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Zajišťuje, že vyrovnávací paměť obsahuje alespoň dostatek místa pro uložení prvků `len + additional`.
    /// Pokud to ještě neudělá, přerozdělí minimální možné množství potřebné paměti.
    /// Obecně to bude přesně to množství potřebné paměti, ale v zásadě může alokátor vrátit více, než jsme požadovali.
    ///
    ///
    /// Pokud `len` překročí `self.capacity()`, může dojít k selhání skutečného přidělení požadovaného prostoru.
    /// To není opravdu nebezpečné, ale nebezpečný kód *, který napíšete*, který závisí na chování této funkce, se může zlomit.
    ///
    /// # Panics
    ///
    /// Panics, pokud nová kapacita překročí `isize::MAX` bajtů.
    ///
    /// # Aborts
    ///
    /// Přerušení na OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Stejné jako `reserve_exact`, ale vrátí se k chybám namísto paniky nebo přerušení.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Zmenší alokaci na zadanou částku.
    /// Pokud je daná částka 0, ve skutečnosti se zcela uvolní.
    ///
    /// # Panics
    ///
    /// Panics, pokud je daná částka *větší* než aktuální kapacita.
    ///
    /// # Aborts
    ///
    /// Přerušení na OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Vrátí se, pokud vyrovnávací paměť potřebuje růst, aby splnila potřebnou kapacitu navíc.
    /// Používá se hlavně k umožnění vložení rezervních volání bez vložení `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Tato metoda je obvykle instancována mnohokrát.Chceme, aby to bylo co nejmenší, aby se zlepšila doba kompilace.
    // Ale také chceme, aby co nejvíce jeho obsahu bylo staticky vypočítatelné, jak je to možné, aby generovaný kód běžel rychleji.
    // Proto je tato metoda pečlivě napsána tak, aby veškerý kód, který závisí na `T`, byl uvnitř, zatímco co nejvíce kódu, který nezávisí na `T`, je ve funkcích, které nejsou generické přes `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // To je zajištěno volajícími kontexty.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Protože vracíme kapacitu `usize::MAX`, když je `elem_size`
            // 0, dostat se sem nutně znamená, že `RawVec` je přeplněný.
            return Err(CapacityOverflow);
        }

        // S těmito kontrolami bohužel nemůžeme nic dělat.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // To zaručuje exponenciální růst.
        // Zdvojnásobení nemůže přetéct, protože `cap <= isize::MAX` a typ `cap` je `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` není generický nad `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Omezení u této metody jsou téměř stejná jako u `grow_amortized`, ale tato metoda je obvykle vytvořena méně často, takže je méně kritická.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Protože vracíme kapacitu `usize::MAX`, když je velikost typu
            // 0, dostat se sem nutně znamená, že `RawVec` je přeplněný.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` není generický nad `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Tato funkce je mimo `RawVec`, aby se minimalizovaly časy kompilace.Podrobnosti najdete v komentáři výše `RawVec::grow_amortized`.
// (Parametr `A` není významný, protože počet různých typů `A`, které jsou v praxi vidět, je mnohem menší než počet typů `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Zde zkontrolujte chybu, abyste minimalizovali velikost `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Alokátor kontroluje rovnost zarovnání
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Uvolní paměť, kterou vlastní `RawVec`*, aniž by se* pokusila odhodit její obsah.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Centrální funkce pro zpracování chyb rezervy.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Musíme zaručit následující:
// * Nikdy nepřidělujeme objekty velikosti `> isize::MAX` bajtů.
// * Nepřeplňujeme `usize::MAX` a ve skutečnosti přidělujeme příliš málo.
//
// Na 64bitové verzi stačí zkontrolovat přetečení, protože pokus o přidělení bajtů `> isize::MAX` určitě selže.
// Na 32bitových a 16bitových bitech musíme přidat další ochranu pro případ, že běžíme na platformě, která může využívat všechny 4 GB v uživatelském prostoru, např. PAE nebo x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Jedna centrální funkce odpovědná za přetečení kapacity hlášení.
// Tím zajistíte, že generování kódu související s těmito panics je minimální, protože v modulu je pouze jedno místo, které panics spíše než parta.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}