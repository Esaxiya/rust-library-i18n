use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Specializace trait použitá pro Vec::from_iter
///
/// ## Graf delegace:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Běžným případem je předání vector do funkce, která se okamžitě znovu sbírá do vector.
        // Můžeme to zkratovat, pokud IntoIter nebyl vůbec pokročilý.
        // Když to bylo pokročilé Můžeme také znovu použít paměť a přesunout data dopředu.
        // Ale uděláme to pouze tehdy, když výsledný Vec nebude mít více nevyužité kapacity, než by ho vytvořil prostřednictvím generické implementace FromIterator.
        //
        // Toto omezení není nezbytně nutné, protože chování přidělování Vec je záměrně nespecifikováno.
        // Je to však konzervativní volba.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // musí delegovat na spec_extend(), protože extend() sám deleguje na spec_from pro prázdné Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Toto využívá `iterator.as_slice().to_vec()`, protože spec_extend musí podniknout více kroků, aby mohl uvažovat o konečné kapacitě + délce, a tak udělat více práce.
// `to_vec()` přímo přiděluje správné množství a přesně jej vyplňuje.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): u cfg(test) není vlastní metoda `[T]::to_vec`, která je vyžadována pro tuto definici metody, k dispozici.
    // Místo toho použijte funkci `slice::to_vec`, která je k dispozici pouze u cfg(test) NB, viz modul slice::hack v slice.rs
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}