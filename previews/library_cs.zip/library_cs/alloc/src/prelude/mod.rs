//! Alloc Prelude
//!
//! Účelem tohoto modulu je zmírnit import běžně používaných položek modelu `alloc` crate přidáním globálního importu do horní části modulů:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;