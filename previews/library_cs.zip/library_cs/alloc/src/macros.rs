/// Vytvoří [`Vec`] obsahující argumenty.
///
/// `vec!` umožňuje definovat `Vec` se stejnou syntaxí jako maticové výrazy.
/// Existují dvě formy tohoto makra:
///
/// - Vytvořte [`Vec`] obsahující daný seznam prvků:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Vytvořte [`Vec`] z daného prvku a velikosti:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Všimněte si, že na rozdíl od výrazů pole tato syntaxe podporuje všechny prvky, které implementují [`Clone`], a počet prvků nemusí být konstantní.
///
/// To bude používat `clone` k duplikování výrazu, takže byste měli být opatrní při použití s typy, které mají nestandardní implementaci `Clone`.
/// Například `vec![Rc::new(1);5] `vytvoří vector pěti odkazů na stejnou celočíselnou hodnotu v rámečku, nikoli pět odkazů směřujících na samostatně celá čísla v rámečku.
///
///
/// Všimněte si také, že `vec![expr; 0]` je povolen a vytváří prázdný vector.
/// To však bude i nadále vyhodnocovat `expr` a okamžitě klesne výsledná hodnota, takže si pamatujte vedlejší účinky.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): u cfg(test) není vlastní metoda `[T]::into_vec`, která je vyžadována pro tuto definici makra, k dispozici.
// Místo toho použijte funkci `slice::into_vec`, která je k dispozici pouze u cfg(test) NB, viz modul slice::hack v slice.rs
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Vytvoří `String` pomocí interpolace běhových výrazů.
///
/// První argument, který `format!` obdrží, je formátovací řetězec.Musí to být řetězcový literál.Síla formátovacího řetězce je obsažena v souboru " {}.
///
/// Další parametry předané `format!` nahradí znak " {} ve formátovacím řetězci v uvedeném pořadí, pokud nejsou použity pojmenované nebo poziční parametry;viz [`std::fmt`] pro více informací.
///
///
/// Běžné použití pro `format!` je zřetězení a interpolace řetězců.
/// Stejná konvence se používá u maker [`print!`] a [`write!`], v závislosti na zamýšleném cíli řetězce.
///
/// Chcete-li převést jednu hodnotu na řetězec, použijte metodu [`to_string`].Použije se formátování trait ve formátu [`Display`].
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics pokud formátovací implementace trait vrátí chybu.
/// To označuje nesprávnou implementaci, protože `fmt::Write for String` nikdy nevrací samotnou chybu.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Vynutit uzel AST k výrazu, aby se zlepšila diagnostika v poloze vzoru.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}