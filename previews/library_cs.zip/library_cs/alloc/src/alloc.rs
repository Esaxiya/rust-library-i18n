//! Rozhraní API pro přidělování paměti

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Jedná se o magické symboly, které se nazývají globální alokátor.rustc je generuje pro volání `__rg_alloc` atd.
    // pokud existuje atribut `#[global_allocator]` (kód rozšiřující toto makro atributu generuje tyto funkce), nebo zavolat výchozí implementace v libstd (`__rdl_alloc` atd.
    //
    // v `library/std/src/alloc.rs`) jinak.
    // rustc fork z LLVM také speciální případy těchto názvů funkcí, aby je bylo možné optimalizovat jako `malloc`, `realloc` a `free`.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Globální alokátor paměti.
///
/// Tento typ implementuje [`Allocator`] trait přesměrováním volání alokátoru registrovanému s atributem `#[global_allocator]`, pokud existuje, nebo výchozím nastavením `std` crate.
///
///
/// Note: zatímco tento typ je nestabilní, k funkcím, které poskytuje, lze přistupovat prostřednictvím [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Přiřaďte paměť pomocí globálního alokátoru.
///
/// Tato funkce přeposílá volání metody [`GlobalAlloc::alloc`] alokátoru registrovaného s atributem `#[global_allocator]`, pokud existuje, nebo výchozí hodnota `std` crate.
///
///
/// Očekává se, že tato funkce bude zastaralá ve prospěch metody `alloc` typu [`Global`], když se tato funkce a [`Allocator`] trait stanou stabilní.
///
/// # Safety
///
/// Viz [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Znovu přidělte paměť globálnímu alokátoru.
///
/// Tato funkce přeposílá volání metody [`GlobalAlloc::dealloc`] alokátoru registrovaného s atributem `#[global_allocator]`, pokud existuje, nebo výchozí hodnota `std` crate.
///
///
/// Očekává se, že tato funkce bude zastaralá ve prospěch metody `dealloc` typu [`Global`], když se tato funkce a [`Allocator`] trait stanou stabilní.
///
/// # Safety
///
/// Viz [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Přerozdělte paměť pomocí globálního alokátoru.
///
/// Tato funkce přeposílá volání metody [`GlobalAlloc::realloc`] alokátoru registrovaného s atributem `#[global_allocator]`, pokud existuje, nebo výchozí hodnota `std` crate.
///
///
/// Očekává se, že tato funkce bude zastaralá ve prospěch metody `realloc` typu [`Global`], když se tato funkce a [`Allocator`] trait stanou stabilní.
///
/// # Safety
///
/// Viz [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Přiřaďte paměť s nulovou inicializací pomocí globálního alokátoru.
///
/// Tato funkce přeposílá volání metody [`GlobalAlloc::alloc_zeroed`] alokátoru registrovaného s atributem `#[global_allocator]`, pokud existuje, nebo výchozí hodnota `std` crate.
///
///
/// Očekává se, že tato funkce bude zastaralá ve prospěch metody `alloc_zeroed` typu [`Global`], když se tato funkce a [`Allocator`] trait stanou stabilní.
///
/// # Safety
///
/// Viz [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // BEZPEČNOST: `layout` má nenulovou velikost,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // BEZPEČNOST: Stejné jako `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // BEZPEČNOST: `new_size` je nenulová, protože `old_size` je větší nebo roven `new_size`
            // jak to vyžadují bezpečnostní podmínky.Jiné podmínky musí volající dodržet
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` pravděpodobně kontroluje `new_size >= old_layout.size()` nebo něco podobného.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // BEZPEČNOST: protože `new_layout.size()` musí být větší nebo roven `old_size`,
            // stará i nová alokace paměti jsou platné pro čtení a zápis pro `old_size` bajtů.
            // Také proto, že stará alokace ještě nebyla uvolněna, nemůže překrývat `new_ptr`.
            // Volání na `copy_nonoverlapping` je tedy bezpečné.
            // Bezpečnostní smlouva pro `dealloc` musí být potvrzena volajícím.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // BEZPEČNOST: `layout` má nenulovou velikost,
            // ostatní podmínky musí volající dodržet
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BEZPEČNOST: volající musí dodržovat všechny podmínky
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BEZPEČNOST: volající musí dodržovat všechny podmínky
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // BEZPEČNOST: volající musí dodržovat podmínky
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // BEZPEČNOST: `new_size` je nenulová.Jiné podmínky musí volající dodržet
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` pravděpodobně kontroluje `new_size <= old_layout.size()` nebo něco podobného.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // BEZPEČNOST: protože `new_size` musí být menší nebo roven `old_layout.size()`,
            // stará i nová alokace paměti jsou platné pro čtení a zápis pro `new_size` bajtů.
            // Také proto, že stará alokace ještě nebyla uvolněna, nemůže překrývat `new_ptr`.
            // Volání na `copy_nonoverlapping` je tedy bezpečné.
            // Bezpečnostní smlouva pro `dealloc` musí být potvrzena volajícím.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Alokátor pro jedinečné ukazatele.
// Tato funkce se nesmí odvíjet.Pokud ano, MIR codegen selže.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Tento podpis musí být stejný jako `Box`, jinak dojde k ICE.
// Když je do `Box` přidán další parametr (jako `A: Allocator`), musí se sem přidat také.
// Například pokud je `Box` změněn na `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, musí být také změněna tato funkce na `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Obslužná rutina chyby přidělení

extern "Rust" {
    // Toto je magický symbol pro volání obslužné rutiny chyb globálního přidělování.
    // rustc jej generuje pro volání `__rg_oom`, pokud existuje `#[alloc_error_handler]`, nebo pro volání výchozích implementací pod (`__rdl_oom`) jinak.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Přerušení při chybě nebo selhání přidělení paměti.
///
/// Volající API přidělení paměti, kteří chtějí přerušit výpočet v reakci na chybu přidělení, se doporučuje volat tuto funkci, spíše než přímo vyvolat `panic!` nebo podobné.
///
///
/// Výchozí chování této funkce je tisknout zprávu na standardní chybu a přerušit proces.
/// Může být nahrazen [`set_alloc_error_hook`] a [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Pro alloc test lze použít přímo `std::alloc::handle_alloc_error`.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // voláno přes vygenerovaný `__rust_alloc_error_handler`

    // pokud není `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // pokud existuje `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Specializujte klony do předem přidělené neinicializované paměti.
/// Používá `Box::clone` a `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Přidělení *first* může optimalizátoru umožnit vytvořit klonovanou hodnotu na místě, přeskočit místní a přesunout.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Vždy můžeme kopírovat na místě, aniž bychom museli zahrnovat místní hodnotu.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}