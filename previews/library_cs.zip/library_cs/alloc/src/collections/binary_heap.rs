//! Prioritní fronta implementovaná s binární hromadou.
//!
//! Vložení a vyskakování největšího prvku má časovou složitost *O*(log(*n*)).
//! Kontrola největšího prvku je *O*(1).Převod vector na binární haldu lze provést na místě a má složitost *O*(*n*).
//! Binární halda může být také převedena na tříděný vector na místě, což umožňuje jeho použití pro lokální haldu *O*(*n*\*log(* n*)).
//!
//! # Examples
//!
//! Toto je větší příklad, který implementuje [Dijkstra's algorithm][dijkstra] k vyřešení [shortest path problem][sssp] na [directed graph][dir_graph].
//!
//! Ukazuje, jak používat [`BinaryHeap`] s vlastními typy.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Fronta priorit závisí na `Ord`.
//! // Explicitně implementujte trait, aby se fronta stala min-haldy místo max-haldy.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Všimněte si, že objednávku otočíme na náklady.
//!         // V případě rovnosti bodů porovnáváme pozice, je tento krok nezbytný, aby byly implementace `PartialEq` a `Ord` konzistentní.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` je třeba také implementovat.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Každý uzel je reprezentován jako `usize`, pro kratší implementaci.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Dijkstrův nejkratší algoritmus cesty.
//!
//! // Začněte na `start` a pomocí `dist` sledujte aktuální nejkratší vzdálenost do každého uzlu.Tato implementace není paměťově efektivní, protože může ve frontě ponechat duplicitní uzly.
//! //
//! // Pro jednodušší implementaci také používá `usize::MAX` jako ověřovací hodnotu.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [uzel]=aktuální nejkratší vzdálenost od `start` do `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Jsme na `start` s nulovými náklady
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Nejprve prozkoumejte hranici s uzly s nižšími náklady (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Alternativně jsme mohli pokračovat v hledání všech nejkratších cest
//!         if position == goal { return Some(cost); }
//!
//!         // Důležité, protože jsme již možná našli lepší způsob
//!         if cost > dist[position] { continue; }
//!
//!         // Pro každý uzel, na který se můžeme dostat, zjistěte, zda můžeme najít cestu s nižšími náklady procházejícími tímto uzlem
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Pokud ano, přidejte jej na hranici a pokračujte
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Relaxace, nyní jsme našli lepší způsob
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Cíl nedosažitelný
//!     None
//! }
//!
//! fn main() {
//!     // Toto je směrovaný graf, který použijeme.
//!     // Čísla uzlů odpovídají různým stavům a váhy edge symbolizují náklady na přesun z jednoho uzlu do druhého.
//!     //
//!     // Hrany jsou jednosměrné.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Graf je reprezentován jako seznam sousedů, kde každý index, odpovídající hodnotě uzlu, má seznam odchozích hran.
//!     // Zvoleno pro svou účinnost.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Uzel 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Uzel 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Uzel 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Uzel 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Uzel 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Prioritní fronta implementovaná s binární hromadou.
///
/// To bude maximální hromada.
///
/// Jedná se o logickou chybu položky, která má být upravena takovým způsobem, že se pořadí položky vzhledem k jakékoli jiné položce, jak ji určuje `Ord` trait, změní, když je v haldě.
///
/// To je obvykle možné pouze prostřednictvím `Cell`, `RefCell`, globálního stavu, I/O nebo nebezpečného kódu.
/// Chování vyplývající z takové logické chyby není specifikováno, ale nebude mít za následek nedefinované chování.
/// To by mohlo zahrnovat panics, nesprávné výsledky, přerušení, úniky paměti a ukončení.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Odvození typu umožňuje vynechat explicitní podpis typu (což by v tomto příkladu bylo `BinaryHeap<i32>`).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Můžeme použít nahlédnout k pohledu na další položku v haldě.
/// // V tomto případě tam ještě nejsou žádné položky, takže dostaneme Žádný.
/// assert_eq!(heap.peek(), None);
///
/// // Přidejte nějaké skóre ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Nyní peek ukazuje nejdůležitější položku v haldě.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Můžeme zkontrolovat délku hromady.
/// assert_eq!(heap.len(), 3);
///
/// // Můžeme iterovat nad položkami v haldě, i když jsou vráceny v náhodném pořadí.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Pokud tyto výsledky namísto toho vyskočíme, měly by se vrátit v pořádku.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Hromadu můžeme vyčistit od všech zbývajících položek.
/// heap.clear();
///
/// // Halda by nyní měla být prázdná.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Lze použít `std::cmp::Reverse` nebo vlastní implementaci `Ord`, aby se z `BinaryHeap` stala halda.
/// Díky tomu `heap.pop()` vrátí nejmenší hodnotu namísto největší.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Zabalit hodnoty do `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Pokud tyto výsledky nyní vyskočíme, měly by se vrátit v opačném pořadí.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Časová složitost
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Hodnota pro `push` je očekávaná cena;dokumentace metody poskytuje podrobnější analýzu.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Struktura obalující proměnlivý odkaz na největší položku na `BinaryHeap`.
///
///
/// Tento `struct` je vytvořen metodou [`peek_mut`] na [`BinaryHeap`].
/// Další informace najdete v jeho dokumentaci.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // BEZPEČNOST: PeekMut je vytvořen pouze pro neprázdné hromady.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // BEZPEČNÉ: PeekMut je vytvořen pouze pro neprázdné hromady
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // BEZPEČNÉ: PeekMut je vytvořen pouze pro neprázdné hromady
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Odebere načtenou hodnotu z haldy a vrátí ji.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Vytvoří prázdný `BinaryHeap<T>`.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Vytvoří prázdnou `BinaryHeap` jako maximální hromadu.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Vytvoří prázdnou `BinaryHeap` se specifickou kapacitou.
    /// Toto předem přiděluje dostatek paměti pro prvky `capacity`, takže `BinaryHeap` nemusí být znovu přiděleno, dokud neobsahuje alespoň tolik hodnot.
    ///
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Vrátí proměnlivý odkaz na největší položku v binární haldě nebo `None`, pokud je prázdná.
    ///
    /// Note: Pokud dojde k úniku hodnoty `PeekMut`, halda může být v nekonzistentním stavu.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Časová složitost
    ///
    /// Pokud je položka upravena, pak je nejhorší časová složitost *O*(log(*n*)), jinak je to *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Odebere největší položku z binární haldy a vrátí ji, nebo `None`, pokud je prázdná.
    ///
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Časová složitost
    ///
    /// Nejhorší cena `pop` na hromadě obsahující prvky *n* je *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // BEZPEČNOST: !self.is_empty() znamená, že self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Zatlačí položku na binární haldu.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Časová složitost
    ///
    /// Očekávaná cena `push`, zprůměrovaná při každém možném pořadí tlačených prvků a při dostatečně velkém počtu stisknutí, je *O*(1).
    ///
    /// Toto je nejvýznamnější metrika nákladů, když tlačíte prvky, které *nejsou* již v žádném seřazeném vzoru.
    ///
    /// Časová složitost se zhoršuje, pokud jsou prvky tlačeny převážně vzestupně.
    /// V nejhorším případě jsou elementy tlačeny ve vzestupném seřazeném pořadí a amortizovaná cena za push je *O*(log(*n*)) proti haldě obsahující *n* prvky.
    ///
    /// Nejhorší cena za *jedno* volání na `push` je *O*(*n*).Nejhorší případ nastane, když je kapacita vyčerpána a potřebuje změnit velikost.
    /// Náklady na změnu velikosti byly amortizovány na předchozích obrázcích.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // BEZPEČNOST: Protože jsme posunuli nový předmět, znamená to, že
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Spotřebuje `BinaryHeap` a vrátí vector v seřazeném pořadí (ascending).
    ///
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // BEZPEČNOST: `end` přechází z `self.len() - 1` na 1 (oba jsou zahrnuty),
            //  takže je to vždy platný index pro přístup.
            //  Je bezpečný přístup k indexu 0 (tj. `ptr`), protože
            //  1 <=konec <self.len(), což znamená self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // BEZPEČNOST: `end` přechází z `self.len() - 1` na 1 (oba jsou zahrnuty), takže:
            //  0 <1 <=konec <= self.len(), 1 <self.len() Což znamená 0 <konec a konec <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Implementace sift_up a sift_down používají nebezpečné bloky za účelem přesunutí prvku ze vector (zanechání díry), posunutí podél ostatních a přesunutí odstraněného prvku zpět do vector na konečném místě díry.
    //
    // K reprezentaci se používá typ `Hole` a ujistěte se, že je díra na konci svého rozsahu vyplněna zpět, a to i na panic.
    // Použití díry snižuje konstantní faktor ve srovnání s používáním swapů, což zahrnuje dvakrát tolik tahů.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Volající musí zaručit, že `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Vyjměte hodnotu na `pos` a vytvořte díru.
        // BEZPEČNOST: Volající zaručuje, že pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // BEZPEČNOST: hole.pos()> start>=0, což znamená hole.pos()> 0
            //  a tak hole.pos(), 1 nemůže přetékat.
            //  To zaručuje, že nadřazený <hole.pos(), takže je to platný index a také!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // BEZPEČNOST: Stejné jako výše
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Vezměte prvek na `pos` a přesuňte ho dolů na hromadu, zatímco jeho děti jsou větší.
    ///
    ///
    /// # Safety
    ///
    /// Volající musí zaručit, že `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // BEZPEČNOST: Volající zaručuje, že pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Invariant smyčky: dítě==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // porovnejte s větším ze dvou dětí BEZPEČNOST: dítě <konec, 1 <self.len() a dítě + 1 <konec <= self.len(), takže jsou platnými indexy.
            //
            //  dítě==2 *hole.pos() + 1!= hole.pos() a dítě + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 nebo 2* hole.pos() + 2 by mohly přetéct, pokud T je ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // pokud jsme již v pořádku, přestaň.
            // BEZPEČNOST: dítě je nyní buď staré dítě, nebo staré dítě + 1
            //  Již jsme prokázali, že oba jsou <self.len() a!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // BEZPEČNOST: stejné jako výše.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // BEZPEČNOST: &&zkrat, což znamená, že v
        //  druhá podmínka již platí, že child==end, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // BEZPEČNOST: dítě je již prokázáno jako platný index a
            //  dítě==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Volající musí zaručit, že `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // BEZPEČNOST: pos <len zaručuje volající a
        //  samozřejmě len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Vezměte prvek na `pos` a přesuňte ho úplně dolů na hromadu, poté jej posuňte nahoru do své polohy.
    ///
    ///
    /// Note: To je rychlejší, když je známo, že je prvek velký/měl by být blíže ke dnu.
    ///
    /// # Safety
    ///
    /// Volající musí zaručit, že `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // BEZPEČNOST: Volající zaručuje, že pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Invariant smyčky: dítě==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // BEZPEČNOST: dítě <konec, 1 <self.len() a
            //  child + 1 <end <= self.len(), takže jsou platnými indexy.
            //  dítě==2 *hole.pos() + 1!= hole.pos() a dítě + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 nebo 2* hole.pos() + 2 by mohly přetéct, pokud T je ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // BEZPEČNOST: Stejné jako výše
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // BEZPEČNOST: child==end, 1 <self.len(), takže je to platný index
            //  a dítě==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // BEZPEČNOST: pos je poloha v díře a byla již prokázána
        //  být platným indexem.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // BEZPEČNOST: n začíná od self.len()/2 a klesá na 0.
            //  Jediný případ, kdy! (N <self.len()) je, pokud self.len() ==0, ale je to vyloučeno podmínkou smyčky.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Přesune všechny prvky `other` do `self`, přičemž `other` zůstane prázdný.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` bere operace O(len1 + len2) a přibližně 2 *(len1 + len2) srovnání v nejhorším případě, zatímco `extend` bere operace O(len2* log(len1)) a přibližně 1 *len2* log_2(len1) srovnání v nejhorším případě, za předpokladu len1>= len2.
        // U větších hromad se bod přechodu již neřídí touto úvahou a byl stanoven empiricky.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Vrátí iterátor, který načte prvky v pořadí haldy.
    /// Načtené prvky jsou odebrány z původní hromady.
    /// Zbývající prvky budou odstraněny při přetažení v pořadí haldy.
    ///
    /// Note:
    /// * `.drain_sorted()` je *O*(*n*\*log(* n*)); mnohem pomalejší než `.drain()`.
    ///   Ve většině případů byste měli použít druhou možnost.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // odstraní všechny prvky v pořadí haldy
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Zachová pouze prvky určené predikátem.
    ///
    /// Jinými slovy, odeberte všechny prvky `e` tak, aby `f(&e)` vrátil `false`.
    /// Prvky jsou navštěvovány v netříděném (a nespecifikovaném) pořadí.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // uchovávejte pouze sudá čísla
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Vrátí iterátor navštěvující všechny hodnoty v podkladovém vector v libovolném pořadí.
    ///
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Tiskněte 1, 2, 3, 4 v libovolném pořadí
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Vrátí iterátor, který načte prvky v pořadí haldy.
    /// Tato metoda spotřebovává původní haldu.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Vrátí největší položku v binární haldě nebo `None`, pokud je prázdná.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Časová složitost
    ///
    /// Cena je v nejhorším případě *O*(1).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Vrátí počet prvků, které může binární halda pojmout, aniž by došlo k realokaci.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Zarezervuje minimální kapacitu pro přesně `additional` více prvků, které mají být vloženy do dané `BinaryHeap`.
    /// Nedělá nic, pokud je kapacita již dostatečná.
    ///
    /// Všimněte si, že alokátor může dát kolekci více prostoru, než požaduje.
    /// Nelze tedy spoléhat na to, že kapacita bude přesně minimální.
    /// Upřednostňujte [`reserve`], pokud se očekávají vložení future.
    ///
    /// # Panics
    ///
    /// Panics, pokud nová kapacita přeteče `usize`.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Rezervuje kapacitu alespoň pro `additional` dalších prvků, které mají být vloženy do `BinaryHeap`.
    /// Kolekce může vyhradit více místa, aby se zabránilo častému přerozdělování.
    ///
    /// # Panics
    ///
    /// Panics, pokud nová kapacita přeteče `usize`.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Zlikviduje co nejvíce další kapacity.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Zruší kapacitu s dolní mezí.
    ///
    /// Kapacita zůstane minimálně stejně velká jako délka i dodaná hodnota.
    ///
    ///
    /// Pokud je aktuální kapacita menší než dolní limit, jedná se o ne-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Spotřebuje `BinaryHeap` a vrátí základní vector v libovolném pořadí.
    ///
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Vytiskne se v určitém pořadí
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Vrátí délku binární haldy.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Zkontroluje, zda je binární halda prázdná.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Vymaže binární haldu a vrátí iterátor nad odstraněnými prvky.
    ///
    /// Prvky jsou odstraněny v libovolném pořadí.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Spadne všechny položky z binární hromady.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Díra představuje díru ve výřezu, tj. Index bez platné hodnoty (protože byla přesunuta nebo duplikována).
///
/// Při poklesu `Hole` obnoví řez výplní polohy díry hodnotou, která byla původně odstraněna.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Vytvořte nový `Hole` v indexu `pos`.
    ///
    /// Nebezpečný, protože pos musí být v datovém segmentu.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // BEZPEČNÉ: pozice by měla být uvnitř řezu
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Vrátí odkaz na odstraněný prvek.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Vrátí odkaz na prvek v `index`.
    ///
    /// Nebezpečný, protože index musí být v datovém řezu a nesmí se rovnat poz.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Přesuňte díru na nové místo
    ///
    /// Nebezpečný, protože index musí být v datovém řezu a nesmí se rovnat poz.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // znovu vyplňte otvor
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Iterátor nad prvky `BinaryHeap`.
///
/// Tento `struct` je vytvořen [`BinaryHeap::iter()`].
/// Další informace najdete v jeho dokumentaci.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Odebrat ve prospěch `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Vlastní iterátor nad prvky `BinaryHeap`.
///
/// Tento `struct` je vytvořen [`BinaryHeap::into_iter()`] (poskytnut `IntoIterator` trait).
/// Další informace najdete v jeho dokumentaci.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Vypouštěcí iterátor nad prvky `BinaryHeap`.
///
/// Tento `struct` je vytvořen [`BinaryHeap::drain()`].
/// Další informace najdete v jeho dokumentaci.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Vypouštěcí iterátor nad prvky `BinaryHeap`.
///
/// Tento `struct` je vytvořen [`BinaryHeap::drain_sorted()`].
/// Další informace najdete v jeho dokumentaci.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Odebere prvky haldy v pořadí haldy.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Převádí `Vec<T>` na `BinaryHeap<T>`.
    ///
    /// Tato konverze se děje na místě a má časovou složitost *O*(*n*).
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Převádí `BinaryHeap<T>` na `Vec<T>`.
    ///
    /// Tento převod nevyžaduje žádný pohyb ani přidělování dat a má neustálou časovou složitost.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Vytvoří náročné iterátor, tj. Ten, který přesune každou hodnotu z binární haldy v libovolném pořadí.
    /// Po volání této binární haldy nelze použít.
    ///
    /// # Examples
    ///
    /// Základní použití:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Tiskněte 1, 2, 3, 4 v libovolném pořadí
    /// for x in heap.into_iter() {
    ///     // x má typ i32, ne &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}