use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Dočasně vyjme další, neměnný ekvivalent stejného rozsahu.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Vyhledá odlišné okraje listů ohraničující zadaný rozsah ve stromu.
    /// Vrátí buď dvojici různých úchytů do stejného stromu, nebo dvojici prázdných voleb.
    ///
    /// # Safety
    ///
    /// Pokud `BorrowType` není `Immut`, nepoužívejte duplicitní úchyty k návštěvě stejného KV dvakrát.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Ekvivalent k `(root1.first_leaf_edge(), root2.last_leaf_edge())`, ale efektivnější.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Najde dvojici okrajů listů ohraničujících konkrétní rozsah ve stromu.
    ///
    /// Výsledek má smysl pouze v případě, že je strom seřazen podle klíče, jako je strom v `BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // BEZPEČNOST: náš typ výpůjčky je neměnný.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Najde dvojici okrajů listů ohraničujících celý strom.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Rozdělí jedinečnou referenci do dvojice okrajů listů ohraničujících zadaný rozsah.
    /// Výsledkem jsou nejedinečné odkazy umožňující mutaci (some), které je nutné používat opatrně.
    ///
    /// Výsledek má smysl pouze v případě, že je strom seřazen podle klíče, jako je strom v `BTreeMap`.
    ///
    ///
    /// # Safety
    /// Nepoužívejte duplicitní úchyty k návštěvě stejného KV dvakrát.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Rozdělí jedinečnou referenci do dvojice okrajů listů, které ohraničují celý rozsah stromu.
    /// Výsledkem jsou nejedinečné odkazy umožňující mutaci (pouze hodnot), proto je nutné je používat opatrně.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Zde duplikujeme kořenový NodeRef-nikdy nenavštívíme stejný KV dvakrát a nikdy neskončíme s překrývajícími se odkazy na hodnoty.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Rozdělí jedinečnou referenci do dvojice okrajů listů, které ohraničují celý rozsah stromu.
    /// Výsledkem jsou nejedinečné odkazy umožňující masivně destruktivní mutaci, proto je nutné je používat s maximální opatrností.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Zde duplikujeme root NodeRef-nikdy k němu nebudeme přistupovat způsobem, který překrývá odkazy získané z root.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Vzhledem k popisovači listu edge vrátí [`Result::Ok`] s popisovačem do sousedního KV na pravé straně, který je buď ve stejném uzlu listu, nebo v uzlu předka.
    ///
    /// Pokud je list edge poslední ve stromu, vrátí [`Result::Err`] s kořenovým uzlem.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Vzhledem k popisovači listu edge vrátí [`Result::Ok`] s popisovačem do sousedního KV na levé straně, který je buď ve stejném uzlu listu, nebo v uzlu předka.
    ///
    /// Pokud je list edge první ve stromu, vrátí [`Result::Err`] s kořenovým uzlem.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Vzhledem k internímu úchytu edge vrátí [`Result::Ok`] s úchytem do sousedního KV na pravé straně, který je buď ve stejném vnitřním uzlu, nebo v předchůdci.
    ///
    /// Pokud je interní edge poslední ve stromu, vrátí [`Result::Err`] s kořenovým uzlem.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Daný popisovač listu edge do umírajícího stromu vrátí další list edge na pravé straně a pár klíč - hodnota mezi nimi, který je buď ve stejném uzlu listu, v uzlu předka, nebo neexistuje.
    ///
    ///
    /// Tato metoda také uvolní všechny node(s), kterých dosáhne na konec.
    /// To znamená, že pokud již neexistuje žádný pár klíč - hodnota, bude uvolněn celý zbytek stromu a nezbude nic, co by bylo možné vrátit.
    ///
    /// # Safety
    /// Daný edge nesmí být dříve vrácen protějškem `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Vzhledem k tomu, že rukojeť listu edge do umírajícího stromu vrátí další list edge na levé straně a pár klíč - hodnota mezi nimi, který je buď ve stejném uzlu listu, v uzlu předka, nebo neexistuje.
    ///
    ///
    /// Tato metoda také uvolní všechny node(s), kterých dosáhne na konec.
    /// To znamená, že pokud již neexistuje žádný pár klíč - hodnota, bude uvolněn celý zbytek stromu a nezbude nic, co by bylo možné vrátit.
    ///
    /// # Safety
    /// Daný edge nesmí být dříve vrácen protějškem `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Odděluje hromadu uzlů od listu až po kořen.
    /// To je jediný způsob, jak uvolnit zbytek stromu poté, co `deallocating_next` a `deallocating_next_back` okusují obě strany stromu a zasáhly stejný edge.
    /// Jelikož je zamýšleno pouze tehdy, když jsou vráceny všechny klíče a hodnoty, u žádného z klíčů nebo hodnot se neprovádí žádné vyčištění.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Přesune úchyt listu edge na další list edge a vrátí odkazy na klíč a hodnotu mezi nimi.
    ///
    ///
    /// # Safety
    /// Ve směru jízdy musí být další KV.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Přesune popisovač listu edge na předchozí list edge a vrátí odkazy na klíč a hodnotu mezi nimi.
    ///
    ///
    /// # Safety
    /// Ve směru jízdy musí být další KV.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Přesune úchyt listu edge na další list edge a vrátí odkazy na klíč a hodnotu mezi nimi.
    ///
    ///
    /// # Safety
    /// Ve směru jízdy musí být další KV.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Tohle je podle měřítek rychlejší.
        kv.into_kv_valmut()
    }

    /// Přesune popisovač listu edge na předchozí list a vrátí odkazy na klíč a hodnotu mezi nimi.
    ///
    ///
    /// # Safety
    /// Ve směru jízdy musí být další KV.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Tohle je podle měřítek rychlejší.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Přesune úchyt listu edge na další list edge a vrátí klíč a hodnotu mezi nimi, uvolní jakýkoli uzel, který po sobě zanechal, a ponechá odpovídající edge v nadřazeném uzlu visícím.
    ///
    /// # Safety
    /// - Ve směru jízdy musí být další KV.
    /// - Že KV nebyl dříve vrácen protějškem `next_back_unchecked` na žádné kopii úchytů použitých k procházení stromu.
    ///
    /// Jediným bezpečným způsobem, jak pokračovat v aktualizovaném popisovači, je porovnat jej, zrušit, znovu zavolat tuto metodu podle jejích bezpečnostních podmínek nebo zavolat protějšku `next_back_unchecked` podle jejích bezpečnostních podmínek.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Přesune úchyt listu edge na předchozí list edge a vrátí klíč a hodnotu mezi nimi, uvolní jakýkoli uzel, který po sobě zanechal, a ponechá odpovídající edge v nadřazeném uzlu visícím.
    ///
    /// # Safety
    /// - Ve směru jízdy musí být další KV.
    /// - Tento list edge nebyl dříve vrácen protějškem `next_unchecked` na žádné kopii rukojetí použitých k procházení stromem.
    ///
    /// Jediným bezpečným způsobem, jak pokračovat v aktualizovaném popisovači, je porovnat jej, zrušit, znovu zavolat tuto metodu podle jejích bezpečnostních podmínek nebo zavolat protějšku `next_unchecked` podle jejích bezpečnostních podmínek.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Vrátí nejvíce vlevo list edge v uzlu nebo pod ním, jinými slovy edge, který potřebujete jako první při navigaci vpřed (nebo jako poslední při navigaci vzad).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Vrátí pravý krajní list edge v uzlu nebo pod ním, jinými slovy edge, který potřebujete jako poslední při navigaci vpřed (nebo jako první při navigaci vzad).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Navštěvuje listové uzly a vnitřní KV v pořadí vzestupných klíčů a také navštěvuje vnitřní uzly jako celek v hloubce prvního řádu, což znamená, že vnitřní uzly předcházejí jejich jednotlivé KV a jejich podřízené uzly.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Vypočítá počet prvků ve (pod) stromu.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Vrátí list edge nejblíže KV pro dopřednou navigaci.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Vrátí list edge nejblíže KV pro zpětnou navigaci.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}