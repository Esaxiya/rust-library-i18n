use core::intrinsics;
use core::mem;
use core::ptr;

/// Tím se nahradí hodnota za jedinečným odkazem `v` voláním příslušné funkce.
///
///
/// Pokud se v uzávěru `change` objeví panic, celý proces bude přerušen.
#[allow(dead_code)] // zachovat jako ilustraci a pro použití future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Tím se nahradí hodnota za jedinečným odkazem `v` voláním příslušné funkce a vrátí se výsledek získaný tímto způsobem.
///
///
/// Pokud se v uzávěru `change` objeví panic, celý proces bude přerušen.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}