// Toto je pokus o implementaci podle ideálu
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Protože Rust ve skutečnosti nemá závislé typy a polymorfní rekurzi, vystačíme si se spoustou bezpečnosti.
//

// Hlavním cílem tohoto modulu je vyhnout se složitosti tím, že se stromem bude zacházeno jako s obecným (i když podivně tvarovaným) kontejnerem a nebude se zabývat většinou invariantů B-stromu.
//
// Jako takový tento modul nezajímá, zda jsou položky tříděny, které uzly mohou být nedostatečné, nebo dokonce co znamená nedostatečné.Spoléháme však na několik invariantů:
//
// - Stromy musí mít uniformní depth/height.To znamená, že každá cesta dolů k listu z daného uzlu má přesně stejnou délku.
// - Uzel délky `n` má klíče `n`, hodnoty `n` a hrany `n + 1`.
//   To znamená, že i prázdný uzel má alespoň jeden edge.
//   U listového uzlu "having an edge" znamená pouze to, že dokážeme identifikovat pozici v uzlu, protože okraje listu jsou prázdné a nepotřebují žádnou reprezentaci dat.
// V interním uzlu identifikuje edge pozici a obsahuje ukazatel na podřízený uzel.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Základní reprezentace listových uzlů a část reprezentace vnitřních uzlů.
struct LeafNode<K, V> {
    /// Chceme být kovariantní v `K` a `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Index tohoto uzlu do pole `edges` nadřazeného uzlu.
    /// `*node.parent.edges[node.parent_idx]` by měla být stejná věc jako `node`.
    /// Je zaručeno, že bude inicializováno pouze v případě, že `parent` nemá hodnotu null.
    parent_idx: MaybeUninit<u16>,

    /// Počet klíčů a hodnot, které tento uzel ukládá.
    len: u16,

    /// Pole ukládající skutečná data uzlu.
    /// Pouze první `len` prvky každého pole jsou inicializovány a platné.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Inicializuje nový `LeafNode` na místě.
    unsafe fn init(this: *mut Self) {
        // Jako obecnou zásadu necháváme pole neinicializovaná, pokud mohou být, protože by to mělo být ve Valgrindu o něco rychlejší a snáze sledovatelné.
        //
        unsafe {
            // parent_idx, klíče a valy jsou možná MožnáUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Vytvoří novou krabici `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Základní reprezentace interních uzlů.Stejně jako u `LeafNode`s, tyto by měly být skryty za`BoxedNode`s, aby se zabránilo upuštění neinicializovaných klíčů a hodnot.
/// Libovolný ukazatel na `InternalNode` lze přímo vrhnout na ukazatel na podkladovou část `LeafNode` uzlu, což umožňuje kódu působit na listové a vnitřní uzly obecně, aniž byste museli dokonce kontrolovat, na které z nich ukazatel směřuje.
///
/// Tato vlastnost je povolena použitím `repr(C)`.
///
#[repr(C)]
// gdb_providers.py používá tento název typu pro introspekci.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Ukazatele na podřízené objekty tohoto uzlu.
    /// `len + 1` z nich jsou považovány za inicializované a platné, kromě toho, že blízko konce, zatímco strom je držen prostřednictvím vypůjčeného typu `Dying`, některé z těchto ukazatelů visí.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Vytvoří novou krabici `InternalNode`.
    ///
    /// # Safety
    /// Invariant vnitřních uzlů spočívá v tom, že mají alespoň jeden inicializovaný a platný edge.
    /// Tato funkce nenastavuje takový edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Musíme pouze inicializovat data;hrany jsou MožnáUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Spravovaný, nenulový ukazatel na uzel.Jedná se buď o vlastněný ukazatel na `LeafNode<K, V>`, nebo o vlastněný ukazatel na `InternalNode<K, V>`.
///
/// `BoxedNode` však neobsahuje žádné informace o tom, který ze dvou typů uzlů ve skutečnosti obsahuje, a částečně kvůli tomuto nedostatku informací není samostatným typem a nemá žádný destruktor.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Kořenový uzel vlastněného stromu.
///
/// Všimněte si, že to nemá destruktor a musí se vyčistit ručně.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Vrátí nový vlastněný strom s vlastním kořenovým uzlem, který je zpočátku prázdný.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` nesmí být nula.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Proměnlivě si půjčuje vlastněný kořenový uzel.
    /// Na rozdíl od `reborrow_mut` je to bezpečné, protože návratovou hodnotu nelze použít ke zničení kořene a nemohou existovat další odkazy na strom.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Mírně proměnlivě si půjčuje vlastněný kořenový uzel.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Nevratně přechází na odkaz, který umožňuje procházení a nabízí destruktivní metody a nic jiného.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Přidá nový interní uzel s jediným edge směřujícím na předchozí kořenový uzel, udělá z tohoto nového uzlu kořenový uzel a vrátí jej.
    /// Tím se zvyšuje výška o 1 a je opakem `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, kromě toho, že jsme právě zapomněli, že jsme nyní interní:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Odebere interní kořenový uzel, přičemž jako nový kořenový uzel použije své první dítě.
    /// Jelikož je zamýšleno pouze v případě, že má kořenový uzel pouze jedno dítě, neprovádí se žádné čištění klíčů, hodnot a dalších dětí.
    ///
    /// Tím se sníží výška o 1 a je to opak `push_internal_level`.
    ///
    /// Vyžaduje výhradní přístup k objektu `Root`, ale ne ke kořenovému uzlu;
    /// nezruší platnost dalších popisovačů nebo odkazů na kořenový uzel.
    ///
    /// Panics, pokud neexistuje žádná vnitřní úroveň, tj. Pokud je kořenový uzel list.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // BEZPEČNOST: tvrdili jsme, že jsme interní.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // BEZPEČNOST: půjčili jsme si exkluzivně `self` a jeho typ výpůjčky je exkluzivní.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // BEZPEČNOST: první edge je vždy inicializován.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` je vždy kovariantní v `K` a `V`, i když `BorrowType` je `Mut`.
// To je technicky špatné, ale nemůže to vést k jakékoli bezpečnosti kvůli internímu použití `NodeRef`, protože v `K` a `V` zůstáváme zcela obecní.
//
// Kdykoli však veřejný typ zalomí `NodeRef`, ujistěte se, že má správnou odchylku.
//
/// Odkaz na uzel.
///
/// Tento typ má řadu parametrů, které řídí jeho chování:
/// - `BorrowType`: Fiktivní typ, který popisuje druh výpůjčky a nese celý život.
///    - Když se jedná o `Immut<'a>`, `NodeRef` se chová zhruba jako `&'a Node`.
///    - Když se jedná o `ValMut<'a>`, `NodeRef` se chová zhruba jako `&'a Node`, pokud jde o klíče a stromovou strukturu, ale také umožňuje koexistovat mnoho proměnlivých odkazů na hodnoty v celém stromu.
///    - Když se jedná o `Mut<'a>`, `NodeRef` se chová zhruba jako `&'a mut Node`, ačkoli metody vložení umožňují koexistovat proměnlivý ukazatel na hodnotu.
///    - Když se jedná o `Owned`, `NodeRef` funguje zhruba jako `Box<Node>`, ale nemá destruktor a musí být vyčištěn ručně.
///    - Když se jedná o `Dying`, `NodeRef` se stále chová zhruba jako `Box<Node>`, ale má metody pro ničení stromu kousek po kousku a běžné metody, které nejsou označeny jako nebezpečné pro volání, mohou vyvolat UB, pokud jsou volány nesprávně.
///
///   Protože jakýkoli `NodeRef` umožňuje navigaci ve stromu, `BorrowType` se efektivně vztahuje na celý strom, nejen na samotný uzel.
/// - `K` a `V`: Toto jsou typy klíčů a hodnot uložených v uzlech.
/// - `Type`: Může to být `Leaf`, `Internal` nebo `LeafOrInternal`.
/// Když je to `Leaf`, `NodeRef` ukazuje na listový uzel, když je to `Internal`, `NodeRef` ukazuje na interní uzel, a když je to `LeafOrInternal`, `NodeRef` může ukazovat na jakýkoli typ uzlu.
///   `Type` při použití mimo `NodeRef` má název `NodeType`.
///
/// `BorrowType` i `NodeType` omezují, jaké metody implementujeme, abychom využili bezpečnosti statického typu.Existují omezení ve způsobu, jakým můžeme tato omezení použít:
/// - Pro každý parametr typu můžeme definovat metodu pouze obecně nebo pro jeden konkrétní typ.
/// Například nemůžeme definovat metodu jako `into_kv` obecně pro všechny `BorrowType`, nebo jednou pro všechny typy, které nesou životnost, protože chceme, aby vrátila odkazy `&'a`.
///   Proto jej definujeme pouze pro nejméně výkonný typ `Immut<'a>`.
/// - Nemůžeme získat implicitní nátlak od řekněme `Mut<'a>` do `Immut<'a>`.
///   Proto musíme explicitně volat `reborrow` na výkonnějším `NodeRef`, abychom dosáhli metody jako `into_kv`.
///
/// Všechny metody na `NodeRef`, které vracejí nějaký druh odkazu, buď:
/// - Vezměte `self` podle hodnoty a vraťte životnost nesenou `BorrowType`.
///   Někdy pro vyvolání takové metody musíme zavolat `reborrow_mut`.
/// - Vezměte `self` odkazem a (implicitly) vrátí životnost této reference namísto životnosti přenášené `BorrowType`.
/// Tímto způsobem kontroluje výpůjčka, že `NodeRef` zůstane zapůjčen, pokud je použita vrácená reference.
///   Metody podporující vložku ohýbají toto pravidlo vrácením surového ukazatele, tj. Reference bez životnosti.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Počet úrovní, které jsou od sebe odděleny, a úroveň listů, konstanta uzlu, kterou nelze úplně popsat `Type`, a kterou samotný uzel neukládá.
    /// Musíme pouze uložit výšku kořenového uzlu a odvodit z něj výšku každého druhého uzlu.
    /// Musí být nula, pokud `Type` je `Leaf` a nenulová, pokud `Type` je `Internal`.
    ///
    ///
    height: usize,
    /// Ukazatel na list nebo vnitřní uzel.
    /// Definice `InternalNode` zajišťuje, že ukazatel je platný v obou směrech.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Rozbalte odkaz na uzel, který byl zabalen jako `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Zpřístupňuje data interního uzlu.
    ///
    /// Vrátí raw ptr, aby se zabránilo zneplatnění dalších odkazů na tento uzel.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // BEZPEČNOST: typ statického uzlu je `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Vypůjčuje si exkluzivní přístup k datům interního uzlu.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Najde délku uzlu.Toto je počet klíčů nebo hodnot.
    /// Počet hran je `len() + 1`.
    /// Všimněte si, že navzdory bezpečnému volání této funkce může mít vedlejší účinek zneplatnění proměnlivých odkazů, které vytvořil nebezpečný kód.
    ///
    pub fn len(&self) -> usize {
        // Klíčové je, že zde vstupujeme pouze do pole `len`.
        // Pokud je BorrowType marker::ValMut, mohou existovat vynikající proměnlivé odkazy na hodnoty, které nesmíme zneplatnit.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Vrátí počet úrovní, které jsou od sebe odděleny uzlem a listy.
    /// Nulová výška znamená, že uzel je samotný list.
    /// Pokud zobrazujete stromy s kořenem nahoře, číslo říká, ve které nadmořské výšce se uzel objeví.
    /// Pokud si představujete stromy s listy nahoře, číslo říká, jak vysoko se strom rozkládá nad uzlem.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Dočasně odebere další, neměnný odkaz na stejný uzel.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Vystavuje listovou část jakéhokoli listu nebo vnitřního uzlu.
    ///
    /// Vrátí raw ptr, aby se zabránilo zneplatnění dalších odkazů na tento uzel.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Uzel musí být platný alespoň pro část LeafNode.
        // Toto není odkaz v typu NodeRef, protože nevíme, zda by měl být jedinečný nebo sdílený.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Najde nadřazený prvek aktuálního uzlu.
    /// Vrátí `Ok(handle)`, pokud má aktuální uzel ve skutečnosti nadřazený prvek, kde `handle` ukazuje na edge nadřazeného objektu, který ukazuje na aktuální uzel.
    ///
    /// Vrátí `Err(self)`, pokud aktuální uzel nemá rodiče, čímž vrátí původní `NodeRef`.
    ///
    /// Název metody předpokládá, že zobrazujete stromy s kořenovým uzlem nahoře.
    ///
    /// `edge.descend().ascend().unwrap()` a `node.ascend().unwrap().descend()` by po úspěchu neměly dělat nic.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Musíme použít surové ukazatele na uzly, protože pokud je BorrowType marker::ValMut, mohou existovat vynikající proměnlivé odkazy na hodnoty, které nesmíme zneplatnit.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Všimněte si, že `self` nesmí být prázdný.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Všimněte si, že `self` nesmí být prázdný.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Vystavuje listovou část jakéhokoli listu nebo vnitřního uzlu v neměnném stromu.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // BEZPEČNOST: do tohoto stromu vypůjčeného jako `Immut` nemohou být žádné proměnlivé odkazy.
        unsafe { &*ptr }
    }

    /// Vypůjčí pohled do klíčů uložených v uzlu.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Podobně jako `ascend` získá odkaz na nadřazený uzel uzlu, ale také uvolní aktuální uzel v procesu.
    /// To není bezpečné, protože aktuální uzel bude stále přístupný, přestože je uvolněn.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Nebezpečně tvrdí kompilátoru statické informace, že tento uzel je `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Unsafely asserts to the compiler the static information that this node is an `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Dočasně odebere další, proměnlivý odkaz na stejný uzel.Dejte si pozor, protože tato metoda je velmi nebezpečná, a to dvojnásobně, protože se nemusí okamžitě jevit jako nebezpečná.
    ///
    /// Vzhledem k tomu, že proměnlivé ukazatele se mohou pohybovat kdekoli kolem stromu, lze vrácený ukazatel snadno použít k tomu, aby původní ukazatel visel, byl mimo hranice nebo neplatný podle pravidel skládaného výpůjčky.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) zvažte přidání ještě dalšího parametru typu do `NodeRef`, který omezuje použití navigačních metod na znovuzískané ukazatele a brání této bezpečnosti.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Půjčuje si exkluzivní přístup k listové části jakéhokoli listu nebo vnitřního uzlu.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // BEZPEČNOST: máme výhradní přístup k celému uzlu.
        unsafe { &mut *ptr }
    }

    /// Nabízí exkluzivní přístup k listové části jakéhokoli listu nebo interního uzlu.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // BEZPEČNOST: máme výhradní přístup k celému uzlu.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Půjčuje si exkluzivní přístup k prvku oblasti úložiště klíčů.
    ///
    /// # Safety
    /// `index` je v mezích 0..KAPACITA
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // BEZPEČNOST: volající nebude moci sám volat další metody
        // dokud neodpadne odkaz na klíčový řez, protože máme jedinečný přístup po celou dobu výpůjčky.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Vypůjčí si exkluzivní přístup k prvku nebo řezu oblasti úložiště hodnot uzlu.
    ///
    /// # Safety
    /// `index` je v mezích 0..KAPACITA
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // BEZPEČNOST: volající nebude moci sám volat další metody
        // dokud neodpadne odkaz na hodnotový řez, protože máme po celou dobu výpůjčky jedinečný přístup.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Vypůjčí si exkluzivní přístup k prvku nebo výřezu úložné oblasti uzlu pro obsah edge.
    ///
    /// # Safety
    /// `index` je v mezích 0..KAPACITA + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // BEZPEČNOST: volající nebude moci sám volat další metody
        // dokud nebude zrušena reference řezu edge, protože máme jedinečný přístup po celou dobu výpůjčky.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Uzel má více než `idx` inicializovaných prvků.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Vytváříme pouze odkaz na jeden prvek, který nás zajímá, abychom se vyhnuli aliasingu s vynikajícími odkazy na další prvky, zejména ty, které se vrátily volajícímu v dřívějších iteracích.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Z důvodu problému Rust #74679 se musíme donutit k neoznačeným ukazatelům pole.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Půjčuje si exkluzivní přístup k délce uzlu.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Nastaví odkaz uzlu na jeho nadřazený edge bez zneplatnění dalších odkazů na uzel.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Vymaže odkaz root na jeho nadřazený edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Přidá pár klíč - hodnota na konec uzlu.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Každá položka vrácená `range` je platným indexem edge pro uzel.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Přidá pár klíč-hodnota a edge, který přejde napravo od tohoto páru na konec uzlu.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Zkontroluje, zda je uzel uzlem `Internal` nebo uzlem `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Odkaz na konkrétní pár klíč - hodnota nebo edge v uzlu.
/// Parametr `Node` musí být `NodeRef`, zatímco `Type` může být buď `KV` (označující popisovač u páru klíč-hodnota) nebo `Edge` (označující popisovač na edge).
///
/// Všimněte si, že i uzly `Leaf` mohou mít popisovače `Edge`.
/// Místo toho, aby představovaly ukazatel na podřízený uzel, představují mezery, kde by podřízené ukazatele procházely mezi páry klíč-hodnota.
/// Například v uzlu s délkou 2 by existovaly 3 možné polohy edge, jedno nalevo od uzlu, jedno mezi dvěma páry a jedno napravo od uzlu.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Nepotřebujeme úplnou obecnost `#[derive(Clone)]`, protože `Node` bude jediný, který bude `Clone`able, když je to neměnný odkaz, a proto `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Načte uzel, který obsahuje edge nebo pár klíč - hodnota, na který tento úchyt ukazuje.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Vrátí pozici tohoto úchytu v uzlu.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Vytvoří nový popisovač pro pár klíč - hodnota v `node`.
    /// Nebezpečný, protože volající musí zajistit, aby `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Může to být veřejná implementace PartialEq, ale používá se pouze v tomto modulu.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Dočasně vyjme další, neměnnou rukojeť na stejném místě.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Nemůžeme použít Handle::new_kv nebo Handle::new_edge, protože neznáme náš typ
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Unsafely asserts to the compiler the static information that the handle's node is a `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Dočasně vyjme další, proměnlivý úchyt na stejném místě.
    /// Dejte si pozor, protože tato metoda je velmi nebezpečná, a to dvojnásobně, protože se nemusí okamžitě jevit jako nebezpečná.
    ///
    ///
    /// Podrobnosti viz `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Nemůžeme použít Handle::new_kv nebo Handle::new_edge, protože neznáme náš typ
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Vytvoří nový popisovač pro edge v `node`.
    /// Nebezpečný, protože volající musí zajistit, aby `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Vzhledem k indexu edge, kde chceme vložit do uzlu naplněného do kapacity, vypočítáme rozumný index KV děleného bodu a kde provést vložení.
///
/// Cílem bodu rozdělení je, aby jeho klíč a hodnota skončily v nadřazeném uzlu;
/// klíče, hodnoty a hrany nalevo od bodu rozdělení se stanou levým potomkem;
/// klíče, hodnoty a hrany napravo od bodu rozdělení se stanou tím správným potomkem.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust problém #74834 se pokouší vysvětlit tato symetrická pravidla.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Vloží nový pár klíč - hodnota mezi páry klíč - hodnota napravo a nalevo od tohoto edge.
    /// Tato metoda předpokládá, že v uzlu je dostatek místa, aby se nový pár vešel.
    ///
    /// Vrácený ukazatel ukazuje na vloženou hodnotu.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Vloží nový pár klíč - hodnota mezi páry klíč - hodnota napravo a nalevo od tohoto edge.
    /// Tato metoda rozdělí uzel, pokud není dostatek místa.
    ///
    /// Vrácený ukazatel ukazuje na vloženou hodnotu.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Opravuje nadřazený ukazatel a index v podřízeném uzlu, na který tento edge odkazuje.
    /// To je užitečné, když bylo změněno uspořádání hran,
    fn correct_parent_link(self) {
        // Vytvořte zpětný ukazatel bez zneplatnění dalších odkazů na uzel.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Vloží nový pár klíč - hodnota a edge, který přejde napravo od tohoto nového páru mezi tento edge a pár klíč - hodnota napravo od tohoto edge.
    /// Tato metoda předpokládá, že v uzlu je dostatek místa, aby se nový pár vešel.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Vloží nový pár klíč - hodnota a edge, který přejde napravo od tohoto nového páru mezi tento edge a pár klíč - hodnota napravo od tohoto edge.
    /// Tato metoda rozdělí uzel, pokud není dostatek místa.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Vloží nový pár klíč - hodnota mezi páry klíč - hodnota napravo a nalevo od tohoto edge.
    /// Tato metoda rozdělí uzel, pokud není dostatek místa, a pokusí se vložit oddělenou část do nadřazeného uzlu rekurzivně, dokud nebude dosaženo kořene.
    ///
    ///
    /// Pokud je vráceným výsledkem `Fit`, může být jeho uzlem uzlu tento uzel edge nebo předek.
    /// Pokud je vráceným výsledkem `Split`, kořenovým uzlem bude pole `left`.
    /// Vrácený ukazatel ukazuje na vloženou hodnotu.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Najde uzel, na který ukazuje tento edge.
    ///
    /// Název metody předpokládá, že zobrazujete stromy s kořenovým uzlem nahoře.
    ///
    /// `edge.descend().ascend().unwrap()` a `node.ascend().unwrap().descend()` by po úspěchu neměly dělat nic.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Musíme použít surové ukazatele na uzly, protože pokud je BorrowType marker::ValMut, mohou existovat vynikající proměnlivé odkazy na hodnoty, které nesmíme zneplatnit.
        // S přístupem k poli výšky se nemusíte bát, protože tato hodnota je zkopírována.
        // Pozor, jakmile je dereferencován ukazatel uzlu, přistupujeme k poli edge s odkazem (Rust problém #73987) a zneplatňujeme všechny další odkazy na nebo uvnitř pole, pokud by nějaké byly.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Nemůžeme volat samostatné metody klíče a hodnoty, protože volání druhé z nich zneplatní odkaz vrácený první.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Nahraďte klíč a hodnotu, na kterou odkazuje KV popisovač.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Pomáhá implementacím `split` pro konkrétní `NodeType` tím, že se stará o data listu.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Rozdělí základní uzel na tři části:
    ///
    /// - Uzel je zkrácen tak, aby obsahoval pouze páry klíč - hodnota nalevo od tohoto popisovače.
    /// - Klíč a hodnota, na které tento popisovač odkazuje, jsou extrahovány.
    /// - Všechny páry klíč - hodnota napravo od tohoto popisovače se vloží do nově přiděleného uzlu.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Odebere pár klíč - hodnota, na který ukazuje tento popisovač, a vrátí jej spolu s edge, do kterého se pár klíč - hodnota sbalil.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Rozdělí základní uzel na tři části:
    ///
    /// - Uzel je zkrácen tak, aby obsahoval pouze páry okrajů a párů klíč - hodnota nalevo od tohoto popisovače.
    /// - Klíč a hodnota, na které tento popisovač odkazuje, jsou extrahovány.
    /// - Všechny hrany a páry klíč - hodnota napravo od tohoto popisovače jsou vloženy do nově přiděleného uzlu.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Představuje relaci pro vyhodnocení a provedení operace vyvážení kolem interního páru klíč-hodnota.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Vybírá vyrovnávací kontext zahrnující uzel jako podřízený, tedy mezi KV okamžitě doleva nebo doprava v nadřazeném uzlu.
    /// Vrátí `Err`, pokud není žádný rodič.
    /// Panics, pokud je nadřazený objekt prázdný.
    ///
    /// Preferuje levou stranu, aby byla optimální, pokud je daný uzel nějak nedostatečný, což znamená, že má pouze méně prvků než jeho levý sourozenec a než jeho pravý sourozenec, pokud existují.
    /// V takovém případě je sloučení s levým sourozencem rychlejší, protože stačí pouze přesunout N prvků uzlu, místo toho, abychom je posunuli doprava a posunuli více než N prvků vpředu.
    /// Krádež od levého sourozence je také obvykle rychlejší, protože stačí posunout N prvků uzlu doprava, místo toho, abychom posunuli alespoň N prvků sourozence doleva.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Vrátí, zda je sloučení možné, tj. Zda je v uzlu dostatek místa pro kombinování centrálního KV s oběma sousedními podřízenými uzly.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Provede sloučení a nechá uzávěru rozhodnout, co se má vrátit.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // BEZPEČNOST: výška spojovaných uzlů je jedna pod výškou
                // uzlu tohoto edge, tedy nad nulou, takže jsou interní.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Sloučí nadřazený pár klíč - hodnota a oba sousední podřízené uzly do levého podřízeného uzlu a vrátí zmenšený nadřazený uzel.
    ///
    ///
    /// Panics, pokud nebudeme `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Sloučí nadřazený pár klíč - hodnota a oba sousední podřízené uzly do levého podřízeného uzlu a vrátí tento podřízený uzel.
    ///
    ///
    /// Panics, pokud nebudeme `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Sloučí nadřazený pár klíč - hodnota a oba sousední podřízené uzly do levého podřízeného uzlu a vrátí popisovač edge v tomto podřízeném uzlu, kde sledovaný podřízený uzel edge skončil,
    ///
    ///
    /// Panics, pokud nebudeme `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Odebere pár klíč - hodnota z levého podřízeného prvku a umístí jej do úložiště klíč - hodnota nadřazeného prvku, zatímco do starého podřízeného klíče posílá starý nadřazený pár klíč - hodnota.
    ///
    /// Vrátí popisovač edge v pravém dítěti odpovídající tomu, kde skončil původní edge určený `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Odebere pár klíč - hodnota z pravého podřízeného prvku a umístí jej do úložiště klíč - hodnota nadřazeného prvku, zatímco tlačí starý nadřazený pár klíč - hodnota na levé podřízené.
    ///
    /// Vrátí popisovač edge v levém dítěti určeném `track_left_edge_idx`, který se nepohyboval.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Tím se krade podobně jako u `steal_left`, ale krade se více prvků najednou.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Zajistěte, abychom mohli bezpečně krást.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Přesunout data listu.
            {
                // Udělejte místo ukradeným prvkům ve správném dítěti.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Přesuňte prvky z levého dítěte do pravého.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Přesuňte nejvíce ukradený pár k rodiči.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Přesuňte pár klíč - hodnota rodiče na správné dítě.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Udělejte si místo pro ukradené hrany.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Ukrást hrany.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Symetrický klon `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Zajistěte, abychom mohli bezpečně krást.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Přesunout data listu.
            {
                // Přesuňte nejvíce ukradený pár rodičům.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Přesuňte pár klíč - hodnota rodiče k levému dítěti.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Přesuňte prvky z pravého dítěte do levého.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Vyplňte mezeru tam, kde bývaly ukradené prvky.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Ukrást hrany.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Vyplňte mezeru tam, kde bývaly ukradené hrany.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Odebere všechny statické informace, které tvrdí, že tento uzel je uzlem `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Odebere všechny statické informace, které tvrdí, že tento uzel je uzlem `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Zkontroluje, zda je základním uzlem uzel `Internal` nebo uzel `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Přesunout příponu za `self` z jednoho uzlu do druhého.`right` musí být prázdný.
    /// První edge z `right` zůstává nezměněn.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Výsledek vložení, když uzel potřeboval expandovat nad svou kapacitu.
pub struct SplitResult<'a, K, V, NodeType> {
    // Změněný uzel ve stávajícím stromu s prvky a hranami, které patří nalevo od `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Některé klíče a hodnoty se oddělí, aby se vložily jinde.
    pub kv: (K, V),
    // Vlastní, nepřipojený, nový uzel s prvky a hranami, které patří napravo od `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Zda odkazy na uzly tohoto typu výpůjčky umožňují procházení do dalších uzlů ve stromu.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal není potřeba, děje se to pomocí výsledku `borrow_mut`.
        // Zakázáním procházení a vytvářením pouze nových odkazů na kořeny víme, že každý odkaz typu `Owned` je na kořenový uzel.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Vloží hodnotu do řezu inicializovaných prvků následovaných jedním neinicializovaným prvkem.
///
/// # Safety
/// Plátek má více než `idx` prvků.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Odebere a vrátí hodnotu z řezu všech inicializovaných prvků a zanechá za sebou jeden koncový neinicializovaný prvek.
///
///
/// # Safety
/// Plátek má více než `idx` prvků.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Posune prvky v polohách řezu `distance` doleva.
///
/// # Safety
/// Řez má alespoň `distance` prvků.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Posune prvky v polohách řezu `distance` doprava.
///
/// # Safety
/// Řez má alespoň `distance` prvků.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Přesune všechny hodnoty z řezu inicializovaných prvků na řez neinicializovaných prvků a ponechá `src` jako všechny neinicializované.
///
/// Funguje jako `dst.copy_from_slice(src)`, ale nevyžaduje, aby `T` byl `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;