use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modeluje reborrow nějaké jedinečné reference, když víte, že reborrow a všichni jeho potomci (tj. Všechny ukazatele a odkazy z ní odvozené) již nebudou v určitém okamžiku použity, poté budete chtít znovu použít původní jedinečnou referenci .
///
///
/// Kontrola výpůjček obvykle zvládne toto stohování výpůjček za vás, ale některé kontrolní toky, které toto stohování provádějí, jsou příliš komplikované na to, aby jej překladač mohl sledovat.
/// `DormantMutRef` vám umožňuje zkontrolovat výpůjčku sami, zatímco stále vyjadřujete svou skládanou povahu, a zapouzdřovat surový kód ukazatele, který je k tomu potřeba, bez nedefinovaného chování.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Zachyťte jedinečnou výpůjčku a okamžitě ji znovu vypůjčte.
    /// Pro kompilátor je životnost nové reference stejná jako životnost původní reference, ale promise ji budete používat po kratší dobu.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // BEZPEČNOST: výpůjčku držíme po celou dobu a prostřednictvím `_marker` a vystavujeme ji
        // pouze tento odkaz, takže je jedinečný.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Vrátit se k původnímu původně zapůjčenému výpůjčce.
    ///
    /// # Safety
    ///
    /// Reborrow musí být ukončen, tj. Reference vrácená `new` a všechny ukazatele a odkazy z ní odvozené, se již nesmí používat.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // BEZPEČNOST: naše vlastní bezpečnostní podmínky naznačují, že tato reference je opět jedinečná.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;