# `rustc-std-workspace-core` crate

Tento crate je podložka a prázdný crate, který jednoduše závisí na `libcore` a reexportuje veškerý jeho obsah.
crate je jádrem posílení standardní knihovny, aby byla závislá na crate z crates.io

Crates na crates.io, že standardní knihovna závisí na potřebě záviset na `rustc-std-workspace-core` crate z crates.io, který je prázdný.

V tomto úložišti používáme `[patch]` k přepsání na tento crate.
Výsledkem je, že crates na crates.io nakreslí závislost edge na `libcore`, verzi definovanou v tomto úložišti.
To by mělo čerpat všechny hrany závislostí, aby se zajistilo, že Cargo úspěšně sestaví crates!

Všimněte si, že crates na crates.io musí záviset na tomto crate s názvem `core`, aby vše fungovalo správně.K tomu mohou použít:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Pomocí klíče `package` je crate přejmenován na `core`, což znamená, že bude vypadat

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

když Cargo vyvolá kompilátor a splňuje implicitní směrnici `extern crate core` vloženou kompilátorem.




