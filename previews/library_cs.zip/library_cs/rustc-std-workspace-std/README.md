# `rustc-std-workspace-std` crate

Viz dokumentace k `rustc-std-workspace-core` crate.