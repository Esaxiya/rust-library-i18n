// rsbegin.o a rsend.o jsou takzvané "compiler runtime startup objects".
// Obsahují kód potřebný ke správné inicializaci modulu runtime kompilátoru.
//
// Když je propojen spustitelný nebo dylib obraz, veškerý uživatelský kód a knihovny jsou "sandwiched" mezi těmito dvěma soubory objektů, takže kód nebo data z rsbegin.o budou první v příslušných částech obrazu, zatímco kód a data z rsend.o budou poslední.
// Tento efekt lze použít k umístění symbolů na začátek nebo na konec oddílu a také k vložení požadovaných záhlaví nebo zápatí.
//
// Všimněte si, že skutečný vstupní bod modulu je umístěn v spouštěcím objektu C runtime (obvykle se nazývá `crtX.o`), který pak vyvolá zpětná volání inicializace dalších runtime komponent (zaregistrovaných prostřednictvím ještě další speciální sekce obrazu).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Označí začátek sekce Odvíjení rámce zásobníku
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Stírací prostor pro vnitřní účetnictví odvíječe.
    // To je definováno jako `struct object` v $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Odvíjejte informační rutiny registration/deregistration.
    // Podívejte se na dokumenty libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // zaregistrujte informace o odvíjení při spuštění modulu
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // zrušit registraci při vypnutí
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Běžná registrace init/uninit specifická pro MinGW
    pub mod mingw_init {
        // Spouštěcí objekty MinGW (crt0.o/dllcrt0.o) vyvolají globální konstruktory v sekcích .ctors a .dtors při spuštění a ukončení.
        // V případě knihoven DLL se to provádí, když je knihovna DLL načtena a uvolněna.
        //
        // Linker seřadí sekce, což zajistí, že naše zpětná volání budou umístěna na konci seznamu.
        // Protože konstruktory jsou spouštěny v opačném pořadí, zajišťuje to, že naše zpětná volání jsou první a poslední spuštěná.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: Inicializační zpětná volání C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: Zpětná volání ukončení C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}