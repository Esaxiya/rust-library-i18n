//! Obslužné programy pro analýzu datových toků kódovaných DWARF.
//! Viz standard <http://www.dwarfstd.org>, DWARF-4, oddíl 7, "Data Representation"
//!

// Tento modul zatím používá pouze x86_64-pc-windows-gnu, ale kompilujeme jej všude, abychom se vyhnuli regresím.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // Proudy DWARF jsou zabalené, takže např. u32 nemusí být nutně zarovnán na hranici 4 bajtů.
    // To může způsobit problémy na platformách s přísnými požadavky na zarovnání.
    // Zabalením dat do struktury "packed" říkáme back-endu, aby vygeneroval kód "misalignment-safe".
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // Kódování ULEB128 a SLEB128 jsou definována v oddílech 7.6, "Variable Length Data".
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}