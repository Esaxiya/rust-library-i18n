//! Implementace panics prostřednictvím odvíjení zásobníku
//!
//! Tento crate je implementací panics v Rust pomocí mechanismu odvíjení zásobníku "most native" platformy, pro kterou je kompilován.
//! To se v současné době dělí do tří kbelíků:
//!
//! 1. Cíle MSVC používají SEH v souboru `seh.rs`.
//! 2. Emscripten používá v souboru `emcc.rs` výjimky C++ .
//! 3. Všechny ostatní cíle používají libunwind/libgcc v souboru `gcc.rs`.
//!
//! Více dokumentace o každé implementaci najdete v příslušném modulu.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` není používán s Miri, takže tichá varování.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Spouštěcí objekty běhového prostředí Rust závisí na těchto symbolech, proto je zveřejněte.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Cíle, které nepodporují odvíjení.
        // - arch=wasm32
        // - os=none ("bare metal" cíle)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Použijte runtime Miri.
        // Stále musíme také načíst normální běh výše, protože rustc očekává, že odtud budou definovány určité položky lang.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Použijte skutečnou dobu běhu.
        use real_imp as imp;
    }
}

extern "C" {
    /// Obslužný program v libstd se volá, když je objekt panic vynechán mimo `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Obslužná rutina v libstd se volá, když je chycena cizí výjimka.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Vstupní bod pro vyvolání výjimky, stačí delegovat na implementaci specifickou pro platformu.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}