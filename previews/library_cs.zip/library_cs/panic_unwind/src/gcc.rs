//! Implementace panics podporovaná libgcc/libunwind (v nějaké formě).
//!
//! Informace o zpracování výjimek a odvíjení zásobníku najdete v "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) a dokumentech z něj propojených.
//! Jsou to také dobrá čtení:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Stručné shrnutí
//!
//! Zpracování výjimek probíhá ve dvou fázích: fáze vyhledávání a fáze čištění.
//!
//! V obou fázích odvíječ odvíjí stohovací rámce shora dolů pomocí informací z odkládacích rámců odvíjí sekce modulů aktuálního procesu ("module" zde označuje modul OS, tj. Spustitelný soubor nebo dynamickou knihovnu).
//!
//!
//! Pro každý rámec zásobníku vyvolá přidruženou "personality routine", jejíž adresa je také uložena v sekci informace o odvíjení.
//!
//! Ve fázi vyhledávání je úkolem rutiny osobnosti prozkoumat vyvolávaný objekt výjimky a rozhodnout, zda by měl být zachycen v tomto rámci zásobníku.Jakmile je identifikován rám obslužné rutiny, začíná fáze čištění.
//!
//! Ve fázi čištění odvíječ znovu vyvolá každou osobnostní rutinu.
//! Tentokrát rozhodne, který (pokud existuje) čisticí kód je třeba spustit pro aktuální rámec zásobníku.Pokud je to tak, ovládací prvek se přenese na speciální branch v těle funkce, "landing pad", který vyvolá destruktory, uvolní paměť atd.
//! Na konci přistávací podložky je ovládání přeneseno zpět do odvíječe a odvíjení pokračuje.
//!
//! Jakmile se stoh odvinul dolů na úroveň rámce obslužné rutiny, odvíjení se zastaví a poslední rutina osobnosti přenese kontrolu do záchytného bloku.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Identifikátor třídy výjimky Rust.
// Toto se používá rutinami osobnosti k určení, zda byla výjimka vyvolána jejich vlastním modulem runtime.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-prodejce, jazyk
    0x4d4f5a_00_52555354
}

// ID registrů byly pro každou architekturu zvednuty z TargetLowering::getExceptionPointerRegister() a TargetLowering::getExceptionSelectorRegister() LLVM, poté mapovány na čísla registrů DWARF pomocí tabulek definic registrů (obvykle<arch>RegisterInfo.td, vyhledejte "DwarfRegNum").
//
// Viz také http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Následující kód je založen na osobnostních rutinách C a C++ GCC.Odkaz viz:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI osobnostní rutina.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS místo toho používá výchozí rutinu, protože používá odvíjení SjLj.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Zpětné stopy na ARM budou volat rutinu osobnosti se stavem==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // V těchto případech chceme pokračovat v odvíjení zásobníku, jinak by všechny naše zpětné stopy skončily v __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // Odvíječ DWARF předpokládá, že_Unwind_Context obsahuje věci jako funkce a ukazatele LSDA, avšak ARM EHABI je umístí do objektu výjimky.
            // Chcete-li zachovat podpisy funkcí, jako je _Unwind_GetLanguageSpecificData(), které berou pouze kontextový ukazatel, rutiny osobnosti GCC skrývají ukazatel na context_object v kontextu pomocí umístění vyhrazeného pro AR02 "scratch register" (r12).
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Zásadnějším přístupem by bylo poskytnout úplnou definici ARM_Unwind_Context v našich vazbách libunwind a odtud přímo načíst požadovaná data a obejít funkce kompatibility DWARF.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI vyžaduje, aby rutina osobnosti aktualizovala hodnotu SP v mezipaměti bariéry objektu výjimky.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // Na ARM EHABI je osobnostní rutina zodpovědná za skutečné odvíjení jednoho rámce zásobníku před návratem (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // definované v libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Výchozí rutina osobnosti, která se používá přímo na většině cílů a nepřímo na Windows x86_64 prostřednictvím SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // U cílů x86_64 MinGW je odvíjecím mechanismem SEH, avšak data obsluhy odvíjení (aka LSDA) používají kódování kompatibilní s GCC.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Osobnostní rutina pro většinu našich cílů.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Zpáteční adresa ukazuje 1 bajt za instrukci volání, která by mohla být v dalším rozsahu IP v tabulce rozsahu LSDA.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Registrace informací o odvíjení rámečku
//
// Obrázek každého modulu obsahuje informační sekci o odvíjení rámečku (obvykle ".eh_frame").Když je modul do procesu loaded/unloaded, odvíječ musí být informován o umístění této části v paměti.Metody jejich dosažení se liší podle platformy.
// Na některých (např. Linux) může odvíječ sám objevit odvíjecí informační sekce (dynamickým výčtem aktuálně načtených modulů pomocí dl_iterate_phdr() API and finding their ".eh_frame" sections); ostatní, jako Windows, vyžadují, aby moduly aktivně registrovaly své odvíjející se informační sekce pomocí odvíjecího API.
//
//
// Tento modul definuje dva symboly, které jsou odkazovány a volány z rsbegin.rs k registraci našich informací s runtime GCC.
// Implementace odvíjení zásobníku je (prozatím) odložena na libgcc_eh, avšak Rust crates používá tyto vstupní body specifické pro Rust, aby se předešlo možným střetům s jakýmkoli runtime GCC.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}