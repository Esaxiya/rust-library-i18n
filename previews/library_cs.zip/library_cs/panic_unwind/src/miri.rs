//! Odvíjení panics pro Miri.
use alloc::boxed::Box;
use core::any::Any;

// Typ užitečného zatížení, které motor Miri šíří odvíjením pro nás.
// Musí mít velikost ukazatele.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri poskytovaná externí funkce pro zahájení odvíjení.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Užitečné zatížení, které předáme `miri_start_panic`, bude přesně argument, který dostaneme v `cleanup` níže.
    // Takže to jen jednou zabalíme, abychom dostali něco o velikosti ukazatele.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Obnovte základní `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}