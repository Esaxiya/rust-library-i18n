//! Windows SEH
//!
//! Na Windows (aktuálně pouze na MSVC) je výchozím mechanismem zpracování výjimek Structured Exception Handling (SEH).
//! To je zcela odlišné od zpracování výjimek založených na Dwarfovi (např. Jaké jiné platformy unix používají), pokud jde o interní prvky kompilátoru, takže LLVM musí mít pro SEH velkou podporu navíc.
//!
//! Stručně řečeno, co se tady stane, je:
//!
//! 1. Funkce `panic` volá standardní funkci Windows `_CxxThrowException`, aby vyvolala výjimku podobnou C++ a spustila proces odvíjení.
//! 2.
//! Všechny přistávací plochy generované kompilátorem používají osobnostní funkci `__CxxFrameHandler3`, funkci v CRT a odvíjecí kód v Windows použije tuto osobnostní funkci k provedení veškerého vyčištění kódu v zásobníku.
//!
//! 3. Všechna volání generovaná překladačem do `invoke` mají přistávací plochu nastavenou jako instrukci `cleanuppad` LLVM, která označuje začátek rutiny vyčištění.
//! Osobnost (v kroku 2, definovaná v CRT) je zodpovědná za spuštění čisticích rutin.
//! 4. Nakonec je spuštěn kód "catch" ve vnitřní `try` (generovaný kompilátorem), který indikuje, že ovládací prvek by se měl vrátit zpět k Rust.
//! To se provádí pomocí instrukce `catchswitch` plus instrukce `catchpad` v termínech LLVM IR, která nakonec vrátí normální ovládání do programu pomocí instrukce `catchret`.
//!
//! Některé specifické rozdíly od zpracování výjimek založených na gcc jsou:
//!
//! * Rust nemá žádnou vlastní osobnostní funkci, je místo toho *vždy*`__CxxFrameHandler3`.Kromě toho se neprovádí žádné další filtrování, takže nakonec zachytíme všechny výjimky C++ , které vypadají jako druh, který hodíme.
//! Všimněte si, že vyvolání výjimky do Rust je stejně nedefinované chování, takže by to mělo být v pořádku.
//! * Máme několik dat k přenosu přes odvíjející se hranici, konkrétně `Box<dyn Any + Send>`.Stejně jako u Dwarf výjimek jsou tyto dva ukazatele uloženy jako užitečné zatížení v samotné výjimce.
//! Na MSVC však není potřeba přidělení haldy navíc, protože při provádění funkcí filtru je zásobník volání zachován.
//! To znamená, že ukazatele jsou předávány přímo do `_CxxThrowException`, které jsou poté obnoveny ve funkci filtru, aby byly zapsány do rámce zásobníku vnitřní `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // To musí být Option, protože výjimku zachytíme odkazem a její destruktor je spuštěn běhovým modulem C++ .
    // Když vyjmeme Box z výjimky, musíme nechat výjimku v platném stavu, aby jeho destruktor běžel bez dvojitého upuštění Box.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Nejprve celá řada definic typů.Existuje zde několik zvláštností specifických pro platformu a spousta, která je jen očividně zkopírována z LLVM.Účelem toho všeho je implementovat níže uvedenou funkci `panic` prostřednictvím volání `_CxxThrowException`.
//
// Tato funkce má dva argumenty.První je ukazatel na data, která předáváme, což je v tomto případě náš objekt trait.Docela snadné najít!Další je však komplikovanější.
// Toto je ukazatel na strukturu `_ThrowInfo` a obecně je určen pouze k popisu vyvolávané výjimky.
//
// V současné době je definice tohoto typu [1] trochu chlupatá a hlavní zvláštností (a rozdílem od online článku) je, že na 32bitových ukazatelích jsou ukazatele, ale na 64bitových ukazatelích jsou vyjádřeny jako 32bitové posuny od Symbol `__ImageBase`.
//
// K vyjádření se používají makra `ptr_t` a `ptr!` v níže uvedených modulech.
//
// Bludiště definic typů také pečlivě sleduje, co LLVM vydává pro tento druh operace.Například pokud kompilujete tento kód C++ na MSVC a vydáte IR LLVM:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      void foo() { rust_panic a = {0, 1};
//          hodit;}
//
// To je v podstatě to, co se snažíme napodobit.Většina níže uvedených konstantních hodnot byla právě zkopírována z LLVM,
//
// V každém případě jsou všechny tyto struktury konstruovány podobným způsobem a pro nás je to jen poněkud upřímné.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Všimněte si, že zde záměrně ignorujeme pravidla pro manipulaci se jmény: nechceme, aby C++ dokázalo zachytit Rust panics pouhým prohlášením `struct rust_panic`.
//
//
// Při úpravách se ujistěte, že řetězec názvu typu přesně odpovídá řetězci použitému v `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Přední bajt `\x01` je ve skutečnosti magickým signálem pro LLVM, aby *ne* použil jakékoli jiné manglování, jako je předpona se znakem `_`.
    //
    //
    // Tento symbol je vtable používaný `std::type_info` v C++ .
    // Objekty typu `std::type_info`, deskriptory typů, mají ukazatel na tuto tabulku.
    // Na deskriptory typů odkazují výše definované struktury C++ EH a které konstruujeme níže.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Tento deskriptor typu se používá pouze při vyvolání výjimky.
// Zachytávací část je zpracována try intrinsic, která generuje svůj vlastní TypeDescriptor.
//
// To je v pořádku, protože běhové prostředí MSVC používá porovnání řetězců na názvu typu, aby odpovídalo TypeDescriptors spíše než rovnost ukazatele.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destruktor použitý, pokud se kód C++ rozhodne zachytit výjimku a zrušit ji bez jejího šíření.
// Část catch intrinsic try nastaví první slovo objektu výjimky na 0, aby ho destruktor přeskočil.
//
// Všimněte si, že x86 Windows používá konvenci volání "thiscall" pro členské funkce C++ namísto výchozí konvence volání "C".
//
// Funkce exception_copy je zde trochu speciální: je vyvolána modulem runtime MSVC pod blokem try/catch a panic, který zde generujeme, bude použit jako výsledek kopie výjimky.
//
// To se používá v běhovém prostředí C++ k podpoře zachycení výjimek s std::exception_ptr, které nemůžeme podporovat, protože Box<dyn Any>není klonovatelný.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException se na tomto rámci zásobníku provádí úplně, takže není třeba jinak přenášet `data` do haldy.
    // Právě předáme ukazatel zásobníku na tuto funkci.
    //
    // ManuallyDrop je zde potřeba, protože nechceme, aby byla výjimka zrušena při odvíjení.
    // Místo toho bude zrušeno výjimkou_cleanup, která je vyvolána běhovým modulem C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // To ... se může zdát překvapivé a oprávněně.Na 32bitových MSVC jsou ukazatele mezi těmito strukturami právě tyto ukazatele.
    // Na 64bitových MSVC jsou však ukazatele mezi strukturami spíše vyjádřeny jako 32bitové posuny od `__ImageBase`.
    //
    // V důsledku toho můžeme na 32bitovém MSVC deklarovat všechny tyto ukazatele ve `static`s výše.
    // Na 64bitových MSVC bychom museli ve statice vyjádřit odčítání ukazatelů, což Rust momentálně neumožňuje, takže to vlastně nemůžeme udělat.
    //
    // Další nejlepší věcí je pak vyplnění těchto struktur za běhu (panikaření je již stejně "slow path").
    // Takže zde reinterpretujeme všechna tato pole ukazatelů jako 32bitová celá čísla a poté do nich uložíme příslušnou hodnotu (atomicky, protože se může stát souběžná panics).
    //
    // Technicky runtime pravděpodobně provede natomatomické čtení těchto polí, ale teoreticky nikdy nečetli *špatnou* hodnotu, takže by to nemělo být špatné ...
    //
    // V každém případě v zásadě musíme něco takového udělat, dokud nebudeme moci vyjádřit více operací ve statice (a možná to nikdy nebudeme moci).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // NULL užitečné zatížení zde znamená, že jsme se sem dostali z (...) úlovku __rust_try.
    // To se stane, když se zachytí cizí výjimka, která není Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// To je vyžadováno existencí kompilátoru (např. Je to položka typu lang), ale kompilátor ji nikdy nevolá, protože __C_specific_handler nebo_except_handler3 je funkce osobnosti, která se vždy používá.
//
// Proto je to jen potratný útržek.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}