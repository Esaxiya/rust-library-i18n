# `rustc-std-workspace-core` crate

Бул crate-бул жөн гана `libcore` көз каранды болгон жана анын бардык мазмунун кайра экспортко чыгарган бош жана бош crate.
crate-бул стандарттуу китепкананы crates.io тен crates көз карандылыгына ээ кылуу мүмкүнчүлүгү.

Стандарттуу китепкана көз каранды болгон crates.io боюнча Crates, бош болгон crates.io ден `rustc-std-workspace-core` crate көз каранды.

Бул кампада ушул crate ге жокко чыгаруу үчүн `[patch]` колдонобуз.
Натыйжада, crates.io теги crates ушул репозиторийде аныкталган версиядан `libcore` ке edge көзкарандылыгын жаратат.
Бул Cargo crates ийгиликтүү курушун камсыз кылуу үчүн бардык көзкарандылык чектерин чийиши керек!

Бардык нерсенин туура иштеши үчүн, crates.io теги crates ушул crate ке `core` деген аталышта көз каранды болуш керек.Бул үчүн алар төмөнкүлөрдү колдоно алышат:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

`package` ачкычынын жардамы менен crate `core` болуп өзгөрүлүп, ал окшош болот

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

качан Cargo компиляторду чакырганда, компилятор сайган `extern crate core` көрсөтмөсүн канааттандырат.




