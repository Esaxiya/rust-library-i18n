//! Юникод тилкесинин тилимдери.
//!
//! *[See also the `str` primitive type](str).*
//!
//! `&str` түрү эки негизги сап түрүнүн бири, экинчиси `String`.
//! Анын `String` кесиптешинен айырмаланып, анын мазмунун карызга алышат.
//!
//! # Негизги колдонуу
//!
//! `&str` түрүндөгү негизги сап декларациясы:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Бул жерде биз сап тилкеси деп да белгилүү болгон саптуу сөзмө-сөз жарыялаганбыз.
//! String literals статикалык өмүргө ээ, демек, `hello_world` сабы бүтүндөй программанын иштешине кепилдик берет.
//!
//! Биз "hello_world" жашоосун так көрсөтө алабыз:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Бул модулдагы көптөгөн колдонуулар тесттик конфигурацияда гана колдонулат.
// Колдонулбаган_импорт эскертүүсүн жөндөгөнгө караганда, аларды өчүрүп койсоңуз болот.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `Concat<str>` теги `str` бул жерде мааниге ээ эмес.
/// trait параметринин бул түрү башка имплдди иштетүү үчүн гана бар.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // Катуу коддолгон циклдар бир кыйла тезирээк иштейт, сепаратордун узундугу кичинекей
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // нөлдүк эмес өлчөмдөгү өзүм билемдик
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Vec үчүн иштеген оптималдаштырылган кошулуу<T>(T: Copy) жана Stringдин ички vec Азыркы учурда (2018-05-13) түрүндө жыйынтык чыгаруу жана адистештирүү катасы бар (#36262 чыгарылышты караңыз) Ушул себептен SliceConcat<T>T: Copy жана SliceConcat үчүн адистештирилген эмес<str>бул функциянын бирден-бир колдонуучусу.
// Ал белгиленген убакка чейин өз ордунда калат.
//
// String-join чектери S: Карыз алуу<str>жана Vec-биригүү үчүн [[T]> [T] жана str экөө AsRef <[T]> имплементациялайт)
// => s.borrow().as_ref() жана бизде ар дайым кесимдер бар
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // биринчи кесинди-анын алдында сепаратор жок жалгыз
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // эгерде `len` эсептөөсү ашып кетсе, анда бириккен Vecтин жалпы узундугун эсептеп чыксак, анда биз panic эс тутумубуз түгөнүп калмак, ал эми калган функция коопсуздук үчүн алдын-ала бөлүнгөн бүт Vecти талап кылат
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // башталбаган буферди даярдоо
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // көчүрмө сепараторду жана кесиндилерди чексиз текшерип, кичинекей сепараторлорду масштабдуу өркүндөтүү үчүн катуу коддолгон жылыштар пайда болот (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Насыянын кызыктай жүзөгө ашырылышы узундугун эсептөө үчүн ар кандай тилимдерди жана чыныгы көчүрмөсүн кайтарып бере алат.
        //
        // Чакырылбай жаткан байттарды ачпашыбыз керек.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Сап тилимдеринин ыкмалары.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Көчүрбөй же бөлбөй туруп `Box<str>` ти `Box<[u8]>` ге айлантат.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Оюндун бардык дал келишин башка сап менен алмаштырат.
    ///
    /// `replace` жаңы [`String`] түзүп, ушул тилкедеги дайындарды ага көчүрөт.
    /// Ошентип жүрүп, үлгү боюнча дал келген нерселерди табууга аракет кылат.
    /// Эгер тапса, анда аларды алмаштыруучу сап тилкеси менен алмаштырат.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Үлгү дал келбегенде:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Оюндун биринчи N дал келүүсүн башка сап менен алмаштырат.
    ///
    /// `replacen` жаңы [`String`] түзүп, ушул тилкедеги дайындарды ага көчүрөт.
    /// Ошентип жүрүп, үлгү боюнча дал келген нерселерди табууга аракет кылат.
    /// Эгерде тапса, анда аларды алмаштыруучу сап тилкеси менен `count` жолу алмаштырат.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Үлгү дал келбегенде:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Кайра бөлүштүрүү убактысын кыскартууга үмүттөнөм
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Жаңы [`String`] катары ушул сап тилкесинин кичине тамга эквивалентин берет.
    ///
    /// 'Lowercase' Unicode Derived Core Property `Lowercase` шарттарына ылайык аныкталат.
    ///
    /// Кээ бир белгилер регистрди өзгөрткөндө бир нече белгилерге жайылып кетиши мүмкүн болгондуктан, бул функция параметрди ордунда өзгөртпөөнүн ордуна [`String`] берет.
    ///
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Сигма менен татаал мисал:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // бирок сөздүн аягында σ эмес, ς:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Иш кагаздары жок тилдер өзгөртүлбөйт:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ Σ ге карта түшүрөт, сөздүн аягында ς деп карташа турган жеринен башка.
                // Бул `SpecialCasing.txt` шарттуу (contextual) гана шарттуу, бирок тилден көзкарандысыз картография, андыктан жалпы "condition" механизмине ээ болбостон, аны катуу код менен жазыңыз.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // `Final_Sigma` аныктамасы үчүн.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Жаңы [`String`] катары ушул сап тилмесинин чоң тамга эквивалентин берет.
    ///
    /// 'Uppercase' Unicode Derived Core Property `Uppercase` шарттарына ылайык аныкталат.
    ///
    /// Кээ бир белгилер регистрди өзгөрткөндө бир нече белгилерге жайылып кетиши мүмкүн болгондуктан, бул функция параметрди ордунда өзгөртпөөнүн ордуна [`String`] берет.
    ///
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Сценарийлер регистрсиз өзгөртүлбөйт:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Бир белги бир нече болуп калышы мүмкүн:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Көчүрбөй же бөлбөй туруп [`Box<str>`] ти [`String`] ге айлантат.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// `n` сапты кайталап жаңы [`String`] түзөт.
    ///
    /// # Panics
    ///
    /// Эгерде кубаттуулук ашып кетсе, бул функция panic болот.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// Толуп кеткен panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Ар бир тамга ASCII чоң тамгасынын эквивалентине салыштырылган бул саптын көчүрмөсүн кайтарат.
    ///
    ///
    /// 'a' тен 'z' ке чейинки ASCII тамгалары 'A' тен 'Z' ке чейин картага түшүрүлөт, бирок ASCII эмес тамгалар өзгөрүүсүз болот.
    ///
    /// Орнундагы маанини чоңойтуш үчүн [`make_ascii_uppercase`] колдонуңуз.
    ///
    /// ASCII эмес белгилерден тышкары, ASCII тамгаларын чоңойтуу үчүн, [`to_uppercase`] колдонуңуз.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() UTF-8 инвариантын сактайт.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Ар бир тамга ASCII кичине тамгасына барабар келтирилген бул саптын көчүрмөсүн берет.
    ///
    ///
    /// 'A' тен 'Z' ке чейинки ASCII тамгалары 'a' тен 'z' ке чейин картага түшүрүлөт, бирок ASCII эмес тамгалар өзгөрүүсүз болот.
    ///
    /// Орнундагы маанисин төмөндөтүү үчүн, [`make_ascii_lowercase`] колдонуңуз.
    ///
    /// ASCII эмес символдордон тышкары ASCII белгилерин кичирейтүү үчүн [`to_lowercase`] колдонуңуз.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() UTF-8 инвариантын сактайт.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Сайттын жарактуу UTF-8 бар экендигин текшербей байт тилкесин кутуча тилкесине которот.
///
///
/// # Examples
///
/// Негизги колдонуу:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}