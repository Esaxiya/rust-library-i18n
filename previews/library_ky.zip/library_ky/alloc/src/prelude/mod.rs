//! Prelude бөлүү
//!
//! Бул модулдун максаты глобалдык импортту модулдардын үстүнө кошуу менен `alloc` crate кеңири колдонулган буюмдарынын импортун жеңилдетүү болуп саналат:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;