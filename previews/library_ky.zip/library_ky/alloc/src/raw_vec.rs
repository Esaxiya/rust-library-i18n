#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Жаңы эс тутумдун мазмуну инициализацияланбаган.
    Uninitialized,
    /// Жаңы эс тутумду нөлгө салууга кепилдик берилет.
    Zeroed,
}

/// Эстутум буферин эргономикалык жактан көбүрөөк бөлүштүрүү, бөлүштүрүү жана бөлүштүрүү үчүн төмөнкү деңгээлдеги утилита бурчтук учурлар жөнүндө кабатыр болбостон.
///
/// Бул түр Vec жана VecDeque сыяктуу жеке маалымат структураларыңызды курууга мыкты.
/// Өзгөчө:
///
/// * Нөл өлчөмү боюнча `Unique::dangling()` өндүрөт.
/// * `Unique::dangling()` ти нөлдүк узундугу боюнча бөлүп чыгарат.
/// * `Unique::dangling()` бошотуудан сактайт.
/// * Кубаттуулуктагы эсептөөлөрдүн баардык толуп кетүүлөрүн кармайт (аларды "capacity overflow" panics).
/// * isize::MAX байттан ашык бөлгөн 32-бит тутумунан сактануу.
/// * Сиздин узундугуңуздан ашып кетүүдөн сактаңыз.
/// * Жаңылыш бөлүштүрүү үчүн `handle_alloc_error` чакырат.
/// * `ptr::Unique` камтыйт жана колдонуучуга бардык тиешелүү артыкчылыктарды берет.
/// * Мүмкүн болгон эң чоң кубаттуулукту пайдалануу үчүн бөлүштүргүчтөн кайтарылып берилген ашыкчаны пайдаланат.
///
/// Бул тип, ал башкарган эс тутумду текшербейт.Түшүп калса *ал* эс тутумун бошотот, бирок анын мазмунун таштоого аракет кылбайт.
/// `RawVec` ичиндеги *сакталган* нерселерди иштетүү `RawVec` колдонуучусунун колунда.
///
/// Нөл өлчөмүндөгү типтердин ашыкчасы ар дайым чексиз экендигин эске алыңыз, андыктан `capacity()` ар дайым `usize::MAX` кайтарып берет.
/// Демек, бул түрдү `Box<[T]>` менен айландырганда этият болуңуз, анткени `capacity()` узундук бербейт.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Бул `#[unstable]` `const fn`s `min_const_fn` менен шайкеш келбегендиктен, аларды"min_const_fn`s "деп атоого болбойт, себеби бар.
    ///
    /// Эгер сиз `RawVec<T>::new` же көзкарандылыкты өзгөртө турган болсоңуз, анда `min_const_fn` ти чындыгында буза турган нерселерди киргизбөөгө аракет кылыңыз.
    ///
    /// NOTE: Биз бул хакердиктен алыс болуп, `min_const_fn` шайкештигин талап кылган `#[rustc_force_min_const_fn]` атрибуту менен шайкештигин текшерсек болот, бирок аны `stable(...) const fn`/колдонуучу коду менен чалып, `#[rustc_const_unstable(feature = "foo", issue = "01234")]` болгондо `foo` иштетпейт.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Бөлбөй туруп, мүмкүн болушунча ири `RawVec` (системанын үймөгүндө) түзөт.
    /// Эгерде `T` позитивдүү өлчөмгө ээ болсо, анда `0` сыйымдуулугу бар `RawVec` түзөт.
    /// Эгерде `T` нөл өлчөмүндө болсо, анда ал `usize::MAX` сыйымдуулугу менен `RawVec` түзөт.
    /// Кечиктирилген бөлүүнү ишке ашыруу үчүн пайдалуу.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// `[T; capacity]` үчүн кубаттуулугу жана тегиздөө талаптары менен `RawVec` (тутумдук үймөктө) түзөт.
    /// Бул `capacity` `0` же `T` нөл өлчөмүндө болгондо, `RawVec::new` чакырганга барабар.
    /// Эгер `T` нөл өлчөмүндө болсо, анда `RawVec` суралган кубаттуулукка ээ болбой тургандыгыңызды билдирет.
    ///
    /// # Panics
    ///
    /// Суралган кубаттуулук `isize::MAX` байттан ашса, Panics.
    ///
    /// # Aborts
    ///
    /// OOMдо токтотот.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// `with_capacity` сыяктуу, бирок кепилдик нөлгө салынат.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Көрсөткүчтөн жана сыйымдуулуктан `RawVec` калыбына келтирет.
    ///
    /// # Safety
    ///
    /// `ptr` (системанын үймөгүндө) жана берилген `capacity` менен бөлүштүрүлүшү керек.
    /// `capacity` көлөмү `isize::MAX` ашпашы керек.(32-бит тутумундагы көйгөй гана).
    /// ZST vectors `usize::MAX` чейин кубаттуулукка ээ болушу мүмкүн.
    /// Эгер `ptr` жана `capacity` `RawVec` тен чыкса, анда бул кепилденген.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Кичинекей вектер дудук.Өтүү:
    // - 8, эгерде элементтин көлөмү 1 болсо, анда ар кандай үймөктөрдү бөлүштүрүүчүлөр 8 байттан кеминде 8 байтка чейин сурамдарды тегеректеши мүмкүн.
    //
    // - 4 эгер элементтер орточо өлчөмдө болсо (<=1 KiB).
    // - 1 Болбосо, өтө кыска Vecs үчүн ашыкча орунду текке кетирбөө үчүн.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// `new` сыяктуу, бирок `RawVec` кайтарылып берилгендиги үчүн бөлүштүргүчтү тандоодо параметрлештирилген.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` "unallocated" дегенди билдирет.нөл өлчөмүндөгү түрлөрү эске алынбайт.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity` сыяктуу, бирок `RawVec` кайтарылып берилгендиги үчүн бөлүштүргүчтү тандоодо параметрлештирилген.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// `with_capacity_zeroed` сыяктуу, бирок `RawVec` кайтарылып берилгендиги үчүн бөлүштүргүчтү тандоодо параметрлештирилген.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>` ти `RawVec<T>` ке айландырат.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Көрсөтүлгөн `len` менен бүт буферди `Box<[MaybeUninit<T>]>` форматына которот.
    ///
    /// Эскерте кетүүчү нерсе, бул жасалган `cap` өзгөрүүлөрүн туура калыбына келтирет.(Чоо-жайын билүү үчүн түрдүн сүрөттөмөсүн караңыз.)
    ///
    /// # Safety
    ///
    /// * `len` акыркы суралган кубаттуулуктан чоң же барабар болушу керек жана
    /// * `len` `self.capacity()` тен аз же ага барабар болушу керек.
    ///
    /// Сураныч, талап кылынган кубаттуулук жана `self.capacity()` айырмаланышы мүмкүн, анткени бөлүштүрүүчү ашыкча бөлүштүрүп, суралганга караганда көбүрөөк эс тутумун кайтарып бере алат.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Коопсуздук талаптарынын жарымын акыл-эс менен текшерүү (калган жарымын биз текшере албайбыз).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Бул жерде биз `unwrap_or_else` тен качабыз, анткени ал LLVM IR көлөмүн пайда кылат.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Көрсөтүүчү, сыйымдуулук жана бөлүштүргүчтөн `RawVec` калыбына келтирет.
    ///
    /// # Safety
    ///
    /// `ptr` бөлүнүшү керек (берилген `alloc` бөлүштүрүүчү аркылуу), жана берилген `capacity` менен.
    /// `capacity` көлөмү `isize::MAX` ашпашы керек.
    /// (32-бит тутумундагы көйгөй гана).
    /// ZST vectors `usize::MAX` чейин кубаттуулукка ээ болушу мүмкүн.
    /// Эгерде `ptr` жана `capacity` `alloc` аркылуу түзүлгөн `RawVec` тен келсе, анда бул кепилденген.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Бөлүштүрүү башталганга чейин чийки көрсөткүчтү алат.
    /// Эгер `capacity == 0` же `T` нөл өлчөмүндө болсо, бул `Unique::dangling()` экендигин эске алыңыз.
    /// Мурунку учурда сиз этият болуңуз.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Бөлүштүрүү мүмкүнчүлүгүн алат.
    ///
    /// Эгер `T` нөл өлчөмүндө болсо, бул ар дайым `usize::MAX` болот.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Ушул `RawVec` колдогон бөлүштүрүүчү жөнүндө жалпы маалымдаманы кайтарып берет.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Бизде эс тутумдун бөлүнгөн бөлүгү бар, ошондуктан учурдагы жайгашуубузду алуу үчүн иштөө убактысын текшерүүдөн өтүп кете алабыз.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Буферде `len + additional` элементтерин кармоо үчүн жок дегенде жетиштүү орун бар экендигин камсыз кылат.
    /// Эгер ал жетиштүү көлөмгө ээ болбосо, амортизацияланган *O*(1) жүрүм-турумга жетиштүү орунду жана ыңгайлуу бош мейкиндикти кайрадан бөлүштүрөт.
    ///
    /// Эгерде бул өзүн-өзү panic пайда кылышына алып келсе, бул жүрүм-турумду чектейт.
    ///
    /// Эгер `len` `self.capacity()` ден ашып кетсе, анда ал талап кылынган мейкиндикти бөлүштүрө албай калышы мүмкүн.
    /// Бул чындыгында кооптуу эмес, бирок сиз *жазган* функциянын жүрүм-турумуна таянган кооптуу код бузулушу мүмкүн.
    ///
    /// Бул `extend` сыяктуу жапырт түртүү операциясын ишке ашыруу үчүн идеалдуу.
    ///
    /// # Panics
    ///
    /// Жаңы кубаттуулук `isize::MAX` байттан ашса Panics.
    ///
    /// # Aborts
    ///
    /// OOMдо токтотот.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // Эгерде Len `isize::MAX` тен ашып кетсе, резерв камтылмак же коркуп калмак, андыктан азыр текшерилбей эле койсо болот.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// `reserve` сыяктуу эле, бирок дүрбөлөңгө түшүүнүн же аборттун ордуна катачылыктарды кайтарып берет.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Буферде `len + additional` элементтерин кармоо үчүн жок дегенде жетиштүү орун бар экендигин камсыз кылат.
    /// Эгер ал жок болсо, анда зарыл болгон минималдуу эс тутумун бөлүп берет.
    /// Адатта, бул эс тутумдун керектүү көлөмү болот, бирок негизинен бөлүштүрүүчү биз сурагандан дагы көптү кайтарып бере алат.
    ///
    ///
    /// Эгер `len` `self.capacity()` ден ашып кетсе, анда ал талап кылынган мейкиндикти бөлүштүрө албай калышы мүмкүн.
    /// Бул чындыгында кооптуу эмес, бирок сиз *жазган* функциянын жүрүм-турумуна таянган кооптуу код бузулушу мүмкүн.
    ///
    /// # Panics
    ///
    /// Жаңы кубаттуулук `isize::MAX` байттан ашса Panics.
    ///
    /// # Aborts
    ///
    /// OOMдо токтотот.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// `reserve_exact` сыяктуу эле, бирок дүрбөлөңгө түшүүнүн же аборттун ордуна катачылыктарды кайтарып берет.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Бөлүнүүнү көрсөтүлгөн суммага чейин кыскарат.
    /// Эгерде берилген сумма 0 болсо, анда чындыгында толугу менен бөлүнөт.
    ///
    /// # Panics
    ///
    /// Эгерде берилген сумма учурдагы кубаттуулукка караганда * чоңураак болсо, Panics.
    ///
    /// # Aborts
    ///
    /// OOMдо токтотот.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Керек кошумча сыйымдуулукту аткаруу үчүн буфер өсүшү керек болсо, кайтып келет.
    /// Негизинен `grow` катмарын киргизбей резервдик чалууларды жасоо үчүн колдонулат.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Бул ыкма, адатта, көп жолу чагылдырылат.Ошентип, биз аны мүмкүн болушунча кичинекей болушун каалайбыз, компиляция убактысын жакшыртуу.
    // Бирок, биз ошондой эле, анын коддору тезирээк иштеши үчүн, анын мазмунун мүмкүн болушунча статикалык эсептөө болушун каалайбыз.
    // Демек, бул ыкма кылдаттык менен жазылган, ошондо `T` ке көз каранды болгон бардык коддор анын чегинде болот, ал эми `T` тен көзкаранды болбогон коддордун көпчүлүгү `T` тен жалпы эмес функцияларда болот.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Бул чалуунун контексттери менен камсыздалат.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // `elem_size` болгондо биз `usize::MAX` кубаттуулугун кайтарып беребиз
            // 0, бул жерге сөзсүз түрдө `RawVec` толуп калгандыгын билдирет.
            return Err(CapacityOverflow);
        }

        // Тилекке каршы, бул текшерүүлөр боюнча биз эч нерсе кыла албайбыз.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Бул экспоненциалдуу өсүштү кепилдейт.
        // Эки эсе ашып кете албайт, анткени `cap <= isize::MAX` жана `cap` түрү `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` караганда жалпы эмес.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Бул ыкмадагы чектөөлөр `grow_amortized` тегидей эле, бирок бул ыкма көбүнчө тез-тез жасалат, андыктан анча маанилүү эмес.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Түрү көлөмү болгондо, биз `usize::MAX` кубаттуулугун кайтарып бериңиз
            // 0, бул жерге сөзсүз түрдө `RawVec` толуп калгандыгын билдирет.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` караганда жалпы эмес.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Бул функция компиляция убактысын азайтуу үчүн `RawVec` тышында.Толугураак `RawVec::grow_amortized` жогорудагы комментарийди караңыз.
// (`A` параметри анчалык деле мааниге ээ эмес, анткени `A` түрлөрүнүн саны иш жүзүндө `T` түрлөрүнө караганда бир кыйла аз).
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // `RawVec::grow_*` өлчөмүн азайтуу үчүн бул жерде ката бар экендигин текшериңиз.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Бөлүштүрүүчү тегиздөө теңдигин текшерет
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// `RawVec`*таандык эстутумду* анын мазмунун таштоого аракет кылбастан бошотот.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Резервдик каталар менен иштөөнүн борбордук функциясы.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Биз төмөнкүлөргө кепилдик беришибиз керек:
// * Биз `> isize::MAX` байт өлчөмүндөгү объектилерди эч качан бөлбөйбүз.
// * Биз `usize::MAX` ашып кетпейт жана иш жүзүндө өтө аз бөлөбүз.
//
// 64-битте биз толуп кеткендигин текшеришибиз керек, анткени `> isize::MAX` байт бөлүштүрүү аракети оңунан чыкпайт.
// 32 биттик жана 16-биттеги колдонуучулар мейкиндигинде бардык 4 ГБ колдоно турган платформада иштеп жаткан учурда, биз кошумча коргоону кошушубуз керек, мисалы, PAE же x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Отчеттуулуктун кубаттуулугу ашып кетишине жооп берген бир борбордук функция.
// Бул panics менен байланышкан коддордун жаралышынын минималдуу болушун камсыз кылат, анткени panics модулунун ичинде бир топ орун эмес.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}