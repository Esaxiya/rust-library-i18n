#![stable(feature = "rust1", since = "1.0.0")]

//! Жипти коопсуз эсептөө көрсөткүчтөрү.
//!
//! Көбүрөөк маалымат алуу үчүн [`Arc<T>`][Arc] документтерин караңыз.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// `Arc` ке шилтеме берилиши мүмкүн болгон жумшак чектөө.
///
/// Ушул чектен ашып кетсе, _exactly_ `MAX_REFCOUNT + 1` шилтемелери аркылуу программаңызды (сөзсүз эмес) токтотот.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer эстутум тосмолорун колдобойт.
// Arc/Weak ишке ашырылышында жалган оң отчетторду алдын алуу үчүн, анын ордуна синхрондоштуруу үчүн атомдук жүктөмдөрдү колдонуңуз.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Жипке коопсуз шилтеме эсептөө көрсөткүчү.'Arc' 'Atomically Reference Counted' дегенди билдирет.
///
/// `Arc<T>` түрү үйүлүп берилген `T` тибиндеги мааниге жалпы ээликти камсыз кылат.[`clone`][clone] ти `Arc` ке чакыруу жаңы `Arc` инстанциясын пайда кылат, бул `Arc` булагы сыяктуу үймөктө бирдей бөлүштүрүүнү көрсөтүп, шилтеме санын көбөйтөт.
/// Берилген бөлүштүрүүгө акыркы `Arc` көрсөткүчү жок кылынганда, ошол бөлүштүрүүдөгү (көбүнчө "inner value" деп аталат) сакталып калган маани дагы төмөндөйт.
///
/// Rust деги жалпы шилтемелер мутацияны демейки шартта колдонууга жол бербейт жана `Arc` да өзгөчө жагдай эмес: жалпысынан `Arc` ичиндеги нерсеге өзгөрүлмө шилтеме ала албайсыз.Эгер сиз `Arc` аркылуу мутациялашыңыз керек болсо, [`Mutex`][mutex], [`RwLock`][rwlock] же [`Atomic`][atomic] түрлөрүнүн бирин колдонуңуз.
///
/// ## Жиптин коопсуздугу
///
/// [`Rc<T>`] тен айырмаланып, `Arc<T>` шилтеме менен эсептөө үчүн атомдук операцияларды колдонот.Бул анын жиптен корголгонун билдирет.Кемчилиги-жөнөкөй эс тутумга караганда, атомдук операциялар кымбатыраак.Эгерде сиз жиптер арасындагы шилтеме менен эсептелген бөлүштүрүүлөрдү бөлүшпөсөңүз, анда төмөнкү кошумча чыгымдар үчүн [`Rc<T>`] колдонуңуз.
/// [`Rc<T>`] коопсуз демейки болуп саналат, анткени компилятор [`Rc<T>`] жиптеринин арасына жөнөтүү аракетин жасайт.
/// Бирок, китепкана керектөөчүлөргө көбүрөөк ийкемдүүлүктү берүү үчүн `Arc<T>` ти тандашы мүмкүн.
///
/// `Arc<T>` `T` [`Send`] жана [`Sync`] жүзөгө ашырганча, [`Send`] жана [`Sync`] колдонот.
/// Эмне үчүн `T` жипке коопсуз болбошу үчүн, `T` жипсиз түрүн киргизе албайсыз?Башында, бул бир аз каршы-интуитивдүү болушу мүмкүн: акыры, `Arc<T>` жиптин коопсуздугу маанилүү эмеспи?Ачкыч бул: `Arc<T>` бир эле маалыматка бир нече ээлик кылуу үчүн аны коопсуз кылат, бирок ал маалыматка коопсуздукту кошпойт.
///
/// "Arc <" [`RefCell<T>"]">".
/// [`RefCell<T>`] [`Sync`] эмес, эгер `Arc<T>` ар дайым [`Send`] болсо, `Arc <` [`RefCell<T>`]`>`ошондой эле болмок.
/// Бирок андан кийин бизде көйгөй жаралмак:
/// [`RefCell<T>`] жип коопсуз эмес;ал атомдук эмес операцияларды колдонуу менен карыздарды эсептөөнү жүргүзөт.
///
/// Акыр-аягы, бул `Arc<T>` ти кандайдыр бир [`std::sync`] түрү менен, көбүнчө [`Mutex<T>`][mutex] менен жупташтыруу керек болушу мүмкүн дегенди билдирет.
///
/// ## `Weak` менен циклдерди бузуу
///
/// [`downgrade`][downgrade] методу ээлик кылбаган [`Weak`] көрсөткүчүн түзүүдө колдонулушу мүмкүн.[`Weak`] көрсөткүчү `Arc` ке [`upgrade '][upgrade] d болушу мүмкүн, бирок ал [`None`] дегенди кайтарып берет, эгерде бөлүштүрүүдө сакталып калган маани мурунтан эле түшүп калса.
/// Башка сөз менен айтканда, `Weak` көрсөткүчтөрү бөлүштүрүүнүн ичиндеги маанини сактап калбайт;ошентсе да, алар бөлүштүрүүнү (баалуулукка көмөкчү дүкөн) сактап калышат.
///
/// `Arc` көрсөткүчтөрүнүн ортосундагы цикл эч качан бөлүштүрүлбөйт.
/// Ушул себептен [`Weak`] циклдарды бузуу үчүн колдонулат.Мисалы, дарак ата-эне түйүндөрүнөн балдарга күчтүү `Arc` көрсөткүчтөрүн, ал эми балдардан ата-энелерине алып баруучу [`Weak`] көрсөткүчтөрүн алышы мүмкүн.
///
/// # Колдонулган шилтемелер
///
/// Учурдагы шилтеме эсептелген көрсөткүчтөн жаңы шилтеме түзүү [`Arc<T>`][Arc] жана [`Weak<T>`][Weak] үчүн жүзөгө ашырылган `Clone` trait колдонулат.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Төмөндөгү эки синтаксис барабар.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b жана foo-бул бирдей эс тутумун көрсөткөн Arcs
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` автоматтык түрдө `T` ке шилтеме берүү ([`Deref`][deref] trait аркылуу), андыктан `Arc<T>` типтеги мааниде "T" ыкмаларын чакыра аласыз."T" ыкмалары менен аталыштардын кагылышуусуна жол бербөө үчүн, `Arc<T>` методдору [fully qualified syntax] аркылуу аталган функциялар менен байланышкан:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// "Arc<T>traits `Clone` сыяктуу ишке ашырылышы толук квалификацияланган синтаксисти колдонуу деп аталышы мүмкүн.
/// Кээ бир адамдар толук квалификацияланган синтаксисти, ал эми башкалары ыкма-чакыруу синтаксисин колдонууну туура көрүшөт.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Ыкма-чакыруу синтаксиси
/// let arc2 = arc.clone();
/// // Толугу менен квалификацияланган синтаксис
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] `T` автоматтык түрдө ажыратылбайт, анткени ички маани буга чейин түшүп калган болушу мүмкүн.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Айрым өзгөрүлбөс маалыматтарды жиптер арасында бөлүшүү:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Биз бул тесттерди **иштетпейбиз**.
// windows куруучулары жип негизги жиптен ашып кетип, ошол эле учурда чыгып кетсе (бир нерсе туюкка кептелсе), биз бактысыз болуп калабыз, андыктан биз бул сыноолорду иштетпей, андан толугу менен алыс болобуз.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Өзгөрүлө турган [`AtomicUsize`] бөлүшүү:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Жалпысынан шилтеме эсептөөнүн көбүрөөк мисалдары үчүн [`rc` documentation][rc_examples] караңыз.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` башкарылуучу бөлүштүрүүгө менчиксиз шилтеме берген [`Arc`] версиясы.
/// Бөлүштүрүүгө `Weak` көрсөткүчү боюнча [`upgrade`] чалуу аркылуу жетүүгө болот, ал ["Option`]"<`[`Arc`] "<T>>`.
///
/// `Weak` шилтемеси менчикке эсептелбегендиктен, ал бөлүштүрүүдө сакталган маанинин түшүп кетишине жол бербейт жана `Weak` өзү дагы деле болсо ушул наркка эч кандай кепилдик бербейт.
///
/// Ошентип, ал [`None`] көлөмүн ["жаңыртуу"] күнү кайтып келиши мүмкүн.
/// Бирок `Weak` шилтемеси * бөлүп алуунун (көмөкчү дүкөндүн) бөлүнүшүнө жол бербей тургандыгын эске алыңыз.
///
/// `Weak` көрсөткүчү [`Arc`] тарабынан башкарылган бөлүштүрүүгө убактылуу шилтеме жасап, анын ички маанисинин түшүп кетишине жол бербөө үчүн пайдалуу.
/// Ошондой эле, [`Arc`] көрсөткүчтөрүнүн ортосундагы тегерек шилтемелердин алдын алуу үчүн колдонулат, анткени өз ара ээлик кылган шилтемелер эч качан [`Arc`] тин түшүшүнө жол бербейт.
/// Мисалы, дарак ата-эне түйүндөрүнөн балдарга күчтүү [`Arc`] көрсөткүчтөрүн, ал эми балдардан ата-энелерине алып баруучу `Weak` көрсөткүчтөрүн алышы мүмкүн.
///
/// `Weak` көрсөткүчүн алуунун типтүү жолу-[`Arc::downgrade`] чалуу.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Бул энумдарда ушул түрдүн көлөмүн оптималдаштырууга мүмкүндүк берүүчү `NonNull`, бирок сөзсүз түрдө туура көрсөткүч эмес.
    //
    // `Weak::new` үймөккө орун бөлүп бербеши үчүн, муну `usize::MAX` кылып коет.
    // Бул чыныгы көрсөткүчтүн мааниси эмес, анткени RcBox жок дегенде 2 тегиздөөчү.
    // Бул `T: Sized` болгондо гана мүмкүн болот;көлөмсүз `T` эч качан өчпөйт.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Бул repr(C) тен future ге мүмкүн болгон талааны кайра иретке келтирүүгө каршы, бул трансмутталуучу ички түрлөрдүн башкача коопсуз [into|from]_raw() ине тоскоол болот.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // usize::MAX мааниси убактылуу "locking" үчүн алсыз көрсөткүчтөрдү жаңыртуу же күчтүү көрсөткүчтөрдү төмөндөтүү үчүн кароолчу катары иштейт;бул `make_mut` жана `get_mut` жарыштарын болтурбоо үчүн колдонулат.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Жаңы `Arc<T>` курат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Алсыз көрсөткүчтөрдү эсептөөнү 1 деп баштаңыз, бул (kinda) күчтүү көрсөткүчтөрү кармаган алсыз көрсөткүч, көбүрөөк маалымат алуу үчүн std/rc.rs караңыз.
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Өзүнө алсыз шилтеме колдонуп жаңы `Arc<T>` курат.
    /// Бул функция кайтып келгенге чейин алсыз шилтемени жаңыртуу аракети `None` маанисине алып келет.
    /// Бирок, начар шилтеме эркин клондолуп, кийинчерээк колдонуу үчүн сакталышы мүмкүн.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Ички жагын "uninitialized" абалында бир гана алсыз шилтеме менен куруңуз.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Биз алсыз көрсөткүчкө ээликтен баш тартпашыбыз керек, антпесе `data_fn` кайтып келгенге чейин эс тутум бошоп калышы мүмкүн.
        // Эгерде биз чындыгында эле менчик укугун өткөрүп бергибиз келсе, анда өзүбүзгө кошумча алсыз көрсөткүчтү жаратмакпыз, бирок ал начар шилтеме санына кошумча жаңыртууларды алып келиши мүмкүн, антпесе, антпесе керек эмес.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Эми биз ички баалуулукту туура инициализациялап, алсыз маалымдамабызды күчтүү маалымдамага айланта алабыз.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Жогорудагы маалымат талаасына жазуу нөлгө тең эмес эсептөөнү байкаган жиптерге көрүнүп турушу керек.
            // Демек, `compare_exchange_weak` менен `Weak::upgrade` синхрондоштуруу үчүн, жок дегенде, "Release" буйрутмасы керек.
            //
            // "Acquire" буйрутма талап кылынбайт.
            // `data_fn` тин жүрүм-турумун карап жатканда, анын жаңыланбай турган `Weak` ке шилтеме берүү менен эмне кылышы керектигин карашыбыз керек:
            //
            // - Бул алсыз шилтеме санын көбөйтүп, `Weak`*клондой алат*.
            // - Ал клондорду төмөндөтүп, алсыз шилтеме санын азайта алат (бирок нөлгө чейин эч качан).
            //
            // Бул терс таасирлер бизге эч кандай таасир этпейт жана коопсуз коддун жардамы менен башка терс таасирлер мүмкүн эмес.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Күчтүү шилтемелер биргелешип жалпы алсыз маалымдамага ээ болушу керек, андыктан биздин эски алсыз шилтеме үчүн деструкторду иштетпеңиз.
        //
        mem::forget(weak);
        strong
    }

    /// Башталбаган мазмуну бар жаңы `Arc` курат.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Кийинкиге калтыруу:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Эстутум `0` байт менен толтурулган, башталбаган мазмуну бар жаңы `Arc` курат.
    ///
    ///
    /// Бул ыкманы туура жана туура эмес колдонуу мисалдары үчүн [`MaybeUninit::zeroed`][zeroed] ти караңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Жаңы `Pin<Arc<T>>` курат.
    /// Эгерде `T` `Unpin` ти ишке ашырбаса, анда `data` эс тутумуна тыгылып, жылдырылбай калат.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Жаңы `Arc<T>` курат, эгерде бөлүштүрүү болбой калса, ката кетет.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Алсыз көрсөткүчтөрдү эсептөөнү 1 деп баштаңыз, бул (kinda) күчтүү көрсөткүчтөрү кармаган алсыз көрсөткүч, көбүрөөк маалымат алуу үчүн std/rc.rs караңыз.
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Башталбаган мазмуну бар жаңы `Arc` курат, эгерде бөлүштүрүү болбой калса, ката кетет.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Кийинкиге калтыруу:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Баштала элек мазмуну бар жаңы `Arc` курат, эс тутуму `0` байт менен толтурулат, эгер бөлүштүрүү болбой калса, ката кетет.
    ///
    ///
    /// Бул ыкманы туура жана туура эмес колдонуу мисалдары үчүн [`MaybeUninit::zeroed`][zeroed] ти караңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Ички маанини кайтарып берет, эгер `Arc` бир күчтүү шилтеме болсо.
    ///
    /// Болбосо, [`Err`] берилген `Arc` менен кайтарылат.
    ///
    ///
    /// Мыкты шилтемелер болсо дагы, бул ийгиликке жетет.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Күчтүү-алсыз шилтемени тазалоо үчүн алсыз көрсөткүчтү жасаңыз
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Башталбаган мазмуну бар жаңы атомдук шилтеме менен эсептелген кесинди курат.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Кийинкиге калтыруу:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Эстутум `0` байт менен толтурулган, башталбаган мазмуну бар жаңы атомдук шилтеме менен эсептелген кесинди курат.
    ///
    ///
    /// Бул ыкманы туура жана туура эмес колдонуу мисалдары үчүн [`MaybeUninit::zeroed`][zeroed] ти караңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// `Arc<T>` ке которулат.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] сыяктуу эле, ички баалуулук чындыгында баштапкы абалда экендигине кепилдик берүү чалуучунун колунда.
    ///
    /// Мазмун толук кандуу баштала элек учурда, муну тез арада аныкталбаган жүрүм-турумга алып келет.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Кийинкиге калтыруу:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// `Arc<[T]>` ке которулат.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] сыяктуу эле, ички баалуулук чындыгында баштапкы абалда экендигине кепилдик берүү чалуучунун колунда.
    ///
    /// Мазмун толук кандуу баштала элек учурда, муну тез арада аныкталбаган жүрүм-турумга алып келет.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Кийинкиге калтыруу:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Оролгон көрсөткүчтү кайтарып, `Arc` керектейт.
    ///
    /// Эстутум чыгып кетпеши үчүн, көрсөткүчтү [`Arc::from_raw`] аркылуу `Arc` форматына которуу керек.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Берилген маалыматтарга чийки көрсөткүчтү берет.
    ///
    /// Санактарга эч кандай таасир этпейт жана `Arc` керектелбейт.
    /// Көрсөтүүчү `Arc` те күчтүү эсептөөлөр болгонго чейин жарактуу.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // КООПСУЗДУК: Бул Deref::deref же RcBoxPtr::inner аркылуу өтө албайт, анткени
        // мисалы, мисалы, raw/mut далилдигин сактап калуу үчүн талап кылынат
        // `get_mut` Rc `from_raw` аркылуу калыбына келтирилгенден кийин көрсөткүч аркылуу жаза алат.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Чийки көрсөткүчтөн `Arc<T>` курат.
    ///
    /// Чийки көрсөткүч мурун [`Arc<U>::into_raw`][into_raw] номерине чалып, `U` `T` менен бирдей өлчөмдө жана тегиздикте болушу керек.
    /// Эгер `U` `T` болсо, бул кичинекей чындык.
    /// Эгерде `U` `T` эмес, бирок көлөмү жана тегиздиги бирдей болсо, анда бул негизинен ар кандай типтеги шилтемелерди которууга окшош.
    /// Бул учурда кандай чектөөлөр колдонулаары жөнүндө көбүрөөк маалымат алуу үчүн [`mem::transmute`][transmute] караңыз.
    ///
    /// `from_raw` колдонуучусу белгилүү бир `T` маанисинин бир гана жолу түшүрүлүшүн текшериши керек.
    ///
    /// Бул функция кооптуу, анткени туура эмес колдонуу эс тутумдун коопсуздугуна алып келиши мүмкүн, кайтарылган `Arc<T>` эч качан колдонулбаса дагы.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Агып кетпеши үчүн `Arc` ке кайра которуңуз.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Мындан ары `Arc::from_raw(x_ptr)` чалуулары эс тутумга кооптуу болот.
    /// }
    ///
    /// // `x` жогорудагы алкактан чыгып кеткенде, эс тутум бошотулду, демек, `x_ptr` азыр илинип турат!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Баштапкы ArcInner табуу үчүн жылдырууну артка кайтарыңыз.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Бул бөлүштүрүүгө жаңы [`Weak`] көрсөткүчүн түзөт.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Бул Relaxed жарайт, анткени төмөндөгү CASтеги маанини текшерип жатабыз.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // алсыз эсептегичтин учурда "locked" экендигин текшерүү;эгер ошондой болсо, айландырыңыз.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: учурда бул код ашып кетүү мүмкүнчүлүгүн эске албайт
            // usize::MAX ичине;жалпы жонунан Rc жана Arc толуп кетишин жөндөө керек.
            //

            // Clone() тен айырмаланып, биз `is_unique` тен келген жазуу менен синхрондоштуруу үчүн, бул Окууга ээ болуу керек, ошондо ага чейин жазуу алдындагы окуялар ушул окуудан мурун болот.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Асылып турган Алсызды жаратпаганыбызга ынаныңыз
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Бул бөлүштүрүүгө [`Weak`] көрсөткүчтөрүнүн санын алат.
    ///
    /// # Safety
    ///
    /// Бул ыкма өзү эле коопсуз, бирок аны туура колдонуу өзгөчө кылдаттыкты талап кылат.
    /// Дагы бир жип алсыз санды каалаган убакта өзгөртө алат, анын ичинде ушул ыкманы чакыруу менен натыйжага иш-аракет кылуу.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Бул ырастама детерминисттик, анткени биз `Arc` же `Weak` темаларын ортосунда бөлүшө элекпиз.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Эгерде алсыз эсептөө учурда кулпуланып турган болсо, анда эсептөөнүн мааниси кулпуну алаардан мурун 0 болгон.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Бул бөлүштүрүүгө күчтүү (`Arc`) көрсөткүчтөрүнүн санын алат.
    ///
    /// # Safety
    ///
    /// Бул ыкма өзү эле коопсуз, бирок аны туура колдонуу өзгөчө кылдаттыкты талап кылат.
    /// Дагы бир жип күчтүү саноону каалаган убакта өзгөртө алат, анын ичинде ушул ыкманы колдонуп, анын натыйжасында иш алып баруу.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Бул ырастама детерминисттик, анткени биз `Arc` ти жиптер менен бөлүшө элекпиз.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Берилген көрсөткүч менен байланышкан `Arc<T>` көрсөткүчтөрүнүн санын көбөйтөт.
    ///
    /// # Safety
    ///
    /// Көрсөтүүчү `Arc::into_raw` аркылуу алынган болушу керек, жана ага байланыштуу `Arc` мисалы жарактуу болушу керек (б.а.
    /// күчтүү ыкма ушул ыкманын узактыгы үчүн кеминде 1) болушу керек.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Бул ырастама детерминисттик, анткени биз `Arc` ти жиптер менен бөлүшө элекпиз.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Arc сактап, бирок ManuallyDrop ороп, кайра саноого тийбегиле
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Эми кайра эсептөөнү көбөйтүңүз, бирок жаңы эсептөөнү таштабаңыз
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Берилген көрсөткүч менен байланышкан `Arc<T>` боюнча күчтүү шилтеме санын азайтуу.
    ///
    /// # Safety
    ///
    /// Көрсөтүүчү `Arc::into_raw` аркылуу алынган болушу керек, жана ага байланыштуу `Arc` мисалы жарактуу болушу керек (б.а.
    /// бул ыкманы колдонууда күчтүү сан жок дегенде 1) болушу керек.
    /// Бул ыкманы акыркы `Arc` жана резервдик сактагычты чыгаруу үчүн колдонсо болот, бирок акыркы `Arc` чыккандан кийин ** деп атоого болбойт.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Бул ырастоолор детерминдик мүнөздө, анткени биз `Arc` темаларын ортосунда бөлүшө элекпиз.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Бул кооптуу нерсе, анткени бул жаасы тирүү кезде, ички көрсөткүч жарактуу деп кепилдик беребиз.
        // Мындан тышкары, биз `ArcInner` структурасынын өзү `Sync` экендигин билебиз, анткени ички маалыматтар `Sync`, ошондуктан бул мазмунуна өзгөрбөс көрсөткүчтү сунуштайбыз.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop` сызыгы жок бөлүгү.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Ушул учурда дайындарды жок кылыңыз, бирок биз кутучаны бөлүп берүүнү өзүбүз бошото албайбыз (дагы деле алсырап турган көрсөткүчтөр болушу мүмкүн).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Бардык күчтүү шилтемелерге негизделген алсыз рефти таштаңыз
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Эгерде эки Arc` бирдей бөлүштүрүүнү көрсөткөн болсо ([`ptr::eq`] окшош венада), `true` берет.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Мүмкүн көлөмү бөлүнбөгөн ички мааниге жетиштүү орун менен `ArcInner<T>` бөлүп берет, анда мааниси берилген макети бар.
    ///
    /// `mem_to_arcinner` функциясы маалымат көрсөткүчү менен аталат жана `ArcInner<T>` үчүн (май болушу мүмкүн) көрсөткүчүн кайтарып бериши керек.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Берилген маанинин макетин колдонуп макетин эсептөө.
        // Буга чейин, макет `&*(ptr as* const ArcInner<T>)` сөз айкашы боюнча эсептелген, бирок бул туура эмес шилтеме жараткан (#54908 караңыз).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Мүмкүн көлөмү бөлүнбөгөн ички мааниге жетиштүү орун бар `ArcInner<T>` бөлүп берет, эгерде анын мааниси жайгаштырылган болсо, анда ката кайтарылып берилет.
    ///
    ///
    /// `mem_to_arcinner` функциясы маалымат көрсөткүчү менен аталат жана `ArcInner<T>` үчүн (май болушу мүмкүн) көрсөткүчүн кайтарып бериши керек.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Берилген маанинин макетин колдонуп макетин эсептөө.
        // Буга чейин, макет `&*(ptr as* const ArcInner<T>)` сөз айкашы боюнча эсептелген, бирок бул туура эмес шилтеме жараткан (#54908 караңыз).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // ArcInner инициализациясы
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Өлчөнбөгөн ички мааниге жетиштүү орун менен `ArcInner<T>` бөлүп берет.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Берилген маанини колдонуп `ArcInner<T>` үчүн бөлүп бериңиз.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Көчүрмө байт катары
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Мазмунун түшүрбөй бөлүүнү акысыз
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Берилген узундугу менен `ArcInner<[T]>` бөлүп берет.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Элементтерди тилимден жаңы бөлүнгөн Arc <\[T\]> көчүрүңүз
    ///
    /// Коопсуз эмес, анткени чалган адам менчик укугун алышы керек же `T: Copy` тутумун байлап алышы керек.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Белгилүү бир өлчөмдө экени белгилүү болгон итератордон `Arc<[T]>` курат.
    ///
    /// Өлчөмү туура эмес болсо, жүрүм-туруму аныкталбайт.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Т элементтерин клондоштуруп жатканда Panic сакчысы.
        // panic болгон учурда, жаңы ArcInner-ге жазылган элементтер түшүп, андан кийин эс тутум бошотулат.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Биринчи элементке көрсөткүч
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Баары ачык.Жаңы ArcInner бошотпошу үчүн, күзөтчүнү унутуңуз.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` үчүн колдонулган адистештирүү trait.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// `Arc` көрсөткүчүнүн клонун түзөт.
    ///
    /// Бул ошол эле бөлүштүрүүгө дагы бир көрсөткүчтү жаратып, күчтүү шилтеме санын көбөйтөт.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Жөнөкөй буйрутманы колдонсоңуз болот, анткени баштапкы шилтеме жөнүндө билим башка жиптерди объектини туура эмес өчүрүүдөн сактайт.
        //
        // [Boost documentation][1] те түшүндүрүлгөндөй, шилтеме эсептегичти көбөйтүү ар дайым memory_order_relaxed менен жүргүзүлүшү мүмкүн: Обьектке жаңы шилтемелер бар шилтеме аркылуу гана түзүлүшү мүмкүн жана бар шилтемени бир жиптен экинчисине өткөрүп берүү буга чейин талап кылынган синхрондоштурууну камсыз кылышы керек.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Бирок кимдир бирөө "mem: : forget`ing Arcs" болуп калса, ири суммадагы эсептөөлөрдөн сак болушубуз керек.
        // Эгерде биз муну аткарбасак, анда эсептөө ашып кетиши мүмкүн жана колдонуучулар акысыз колдонушат.
        // Бир эле жолу шилтеме санын көбөйтүүчү ~2 миллиард жип жок деп болжолдоп, биз `isize::MAX` ке каныктык.
        //
        // Бул branch эч качан эч кандай реалдуу программада кабыл алынбайт.
        //
        // Мындай программанын укмуштай деградацияга учураганынан улам биз бойдон алдырып салабыз жана аны колдогубуз келбейт.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Берилген `Arc` боюнча өзгөрүлмө шилтеме берет.
    ///
    /// Эгерде ошол эле бөлүштүрүүгө башка `Arc` же [`Weak`] көрсөткүчтөрү бар болсо, анда `make_mut` жаңы бөлүштүрүүнү жаратат жана уникалдуу ээликти камсыз кылуу үчүн ички мааниде [`clone`][clone] чакырат.
    /// Бул ошондой эле жазуу клону деп аталат.
    ///
    /// Бул [`Rc::make_mut`] кыймыл-аракетинен айырмаланып, калган `Weak` көрсөткүчтөрүн ажыратат.
    ///
    /// Клондоштургандан көрө, ишке ашпай турган [`get_mut`][get_mut] караңыз.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Эч нерсе клондобойт
    /// let mut other_data = Arc::clone(&data); // Ички маалыматтарды клондобойбуз
    /// *Arc::make_mut(&mut data) += 1;         // Ички маалыматтарды клондоштурат
    /// *Arc::make_mut(&mut data) += 1;         // Эч нерсе клондобойт
    /// *Arc::make_mut(&mut other_data) *= 2;   // Эч нерсе клондобойт
    ///
    /// // Азыр `data` жана `other_data` ар кандай бөлүштүрүүлөрдү көрсөтүшөт.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Көңүл буруңуз, биз күчтүү жана начар шилтеме менен бирге.
        // Ошентип, биздин күчтүү маалымдаманы чыгаруу гана эс тутумдун бөлүнүшүнө алып келбейт.
        //
        // `weak` жазуусун чыгарганга чейин `weak` жазуусун (башкача айтканда, төмөндөөлөрдү) `strong` ке чейин көрүп жаткандыгыбызды текшерүү үчүн, сатып ал.
        // Биз алсыз эсептөө жүргүзгөндүктөн, ArcInnerдин өзүн бөлүп салууга эч кандай мүмкүнчүлүк жок.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Дагы бир күчтүү көрсөткүч бар, ошондуктан биз клондошубуз керек.
            // Түздөн-түз клондолгон маанини жазууга мүмкүндүк берүү үчүн эс тутумду алдын-ала бөлүп алыңыз.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Жогоруда айтылгандарга жетиштүү, анткени бул оптимизация болуп саналат: биз ар дайым алсыз көрсөткүчтөрдү түшүрүп салабыз.
            // Эң жаманы, биз жаңы арканы керексиз бөлүп алабыз.
            //

            // Акыркы күчтүү рефти алып салдык, бирок дагы кошумча алсыз рефтер калды.
            // Мазмунду жаңы Аркага жылдырып, калган алсыз шилтемелерди жараксыз кылабыз.
            //

            // `weak` окуусунан usize::MAX (башкача айтканда, кулпуланган) чыгышы мүмкүн эмес экендигин эске алыңыз, анткени алсыз эсептөө күчтүү шилтеме менен жип менен гана бекитилет.
            //
            //

            // АркИнерди керек болгондо тазалап тургандай кылып, өзүбүздүн жашыруун алсыз көрсөткүчүбүздү материалдаштырыңыз.
            //
            let _weak = Weak { ptr: this.ptr };

            // Жөн гана маалыматтарды уурдап алса болот, алсыздар гана калды
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Биз ар кандай түрдөгү бирден-бир маалымдама болгонбуз;кайра күчтүү эсептөө.
            //
            this.inner().strong.store(1, Release);
        }

        // `get_mut()` сыяктуу эле, кооптуу нерсе, анткени биздин шилтеме баштоо үчүн уникалдуу болгон же анын мазмунун клондоштургандан кийин болду.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Эгерде ошол эле бөлүштүрүүгө башка `Arc` же [`Weak`] көрсөткүчтөрү жок болсо, берилген `Arc` ке өзгөрүлмө шилтемени кайтарып берет.
    ///
    ///
    /// Болбосо [`None`] кайтарып берет, анткени бөлүшүлгөн маанинин мутациясы коопсуз эмес.
    ///
    /// Ошондой эле [`make_mut`][make_mut] караңыз, башка көрсөткүчтөр болгондо ички маанини [`clone`][clone] кылат.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Бул кооптуу жагдай эч нерсе эмес, анткени кайтарылган көрсөткүч качан гана Т кайтара турган *жалгыз* көрсөткүч экендигине кепилдик бар.
            // Бул жерде биздин шилтемелерибиздин саны 1 деп кепилденет жана биз Arcтин `mut` болушун талап кылдык, ошондуктан ички маалыматтарга болгон бирден бир шилтемени кайтарып жатабыз.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Берилген `Arc` ке өзгөрүлмө шилтемени эч кандай текшерүүсүз кайтарып берет.
    ///
    /// Коопсуз жана тиешелүү текшерүүлөрдү жүргүзгөн [`get_mut`] караңыз.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Ушул эле бөлүштүрүүгө карата бардык башка `Arc` же [`Weak`] көрсөткүчтөрү кайтарылып алынган насыянын мөөнөтү ичинде берилбеши керек.
    ///
    /// Мындай көрсөткүчтөр жок болсо, мисалы, `Arc::new` тен кийин дароо эле болот.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Биз "count" талааларын камтыган шилтеме түзбөөгө * этияттык менен мамиле кылабыз, анткени бул шилтеме саноолоруна бир эле учурда мүмкүндүк берет (мис.
        // `Weak` тарабынан).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Бул негизги маалыматтарга уникалдуу шилтеме экендигин (анын ичинде алсыз шилтемелер) аныктаңыз.
    ///
    ///
    /// Бул үчүн начар шилтеме санагын кулпулоо талап кылынарын эске алыңыз.
    fn is_unique(&mut self) -> bool {
        // алсыз көрсөткүч ээси болуп көрүнсөк, алсыз көрсөткүчтөрдүн санын кулпулаңыз.
        //
        // Бул жерде сатып алуу этикеткасы `weak` санынын төмөндөшүнө чейин `strong` (айрыкча `Weak::upgrade`) менен болгон бардык жазуулар менен болгон мамилени камсыз кылат (`Weak::drop` аркылуу, ал релизди колдонот).
        // Эгерде жаңыланган начар шилтеме эч качан ташталбаса, анда CAS иштебей калат, андыктан биз синхрондоштурууну ойлобойбуз.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Бул `drop` эсептегичтин азаюусу менен синхрондоштуруу үчүн `Acquire` болушу керек-акыркы шилтемеден башка учурларда гана мүмкүнчүлүк болот.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Ушул жерде чыккан жазуу `downgrade` теги окуу менен синхрондоштурулуп, жогорудагы `strong` окуусун жазуудан кийин болтурбоого мүмкүндүк берет.
            //
            //
            self.inner().weak.store(1, Release); // кулпуну бошотуу
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// `Arc` ти түшүрөт.
    ///
    /// Бул күчтүү шилтеме санын азайтат.
    /// Эгерде күчтүү шилтеме саны нөлгө жетсе, анда башка шилтемелер гана бар (эгер бар болсо) [`Weak`], ошондуктан биз ички маанини `drop` кылабыз.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Эч нерсе басып чыгарбайт
    /// drop(foo2);   // "dropped!" басып чыгарат
    /// ```
    #[inline]
    fn drop(&mut self) {
        // `fetch_sub` буга чейин атомдук болгондуктан, объектти жок кылбасак, башка жиптер менен синхрондоштуруунун кажети жок.
        // Ушул эле логика төмөнкү `fetch_sub` үчүн `weak` санына колдонулат.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Бул тосмо маалыматтарды колдонуунун жана дайындардын өчүрүлүшүн алдын-алуу үчүн керек.
        // Ал `Release` деп белгиленгендиктен, эсептөө санынын төмөндөшү ушул `Acquire` тосмо менен шайкештештирилет.
        // Бул маалыматтарды колдонуу шилтеме санынын азайышына чейин болот дегенди билдирет, бул тосмого чейин болот, ал маалымат жок кылынганга чейин болот.
        //
        // [Boost documentation][1] те түшүндүрүлгөндөй,
        //
        // > Объектке мүмкүн болгон жеткиликтүүлүктү бирөө менен камсыз кылуу маанилүү
        // > өчүрүүдөн мурун * болушу үчүн (бар маалымдама аркылуу)
        // > объект башка жипте.Бул "release" менен жетишилет
        // > маалымдаманы таштагандан кийин иштөө (объектке каалаган мүмкүнчүлүк
        // > бул шилтеме аркылуу, албетте, мурун болгон), жана
        // > "acquire" объектти өчүрүүдөн мурун иштөө.
        //
        // Тактап айтканда, Arc мазмунун өзгөртпөсө да, Mutex сыяктуу нерселерге интерьер жазуусу мүмкүн<T>.
        // Mutex жок кылынганда, аны жок кылгандыктан, биз A синтездөө логикасына таянып, В агымында иштеп жаткан деструкторго көрүнүп турат.
        //
        //
        // Ошондой эле, бул жердеги сатып алуу тосмосун Acquire жүктөмүнө алмаштырууга мүмкүн экендигин, бул өтө карама-каршылыктуу кырдаалдарда иштөөнү жакшырта тургандыгын эске алыңыз.[2] караңыз.
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Конкреттүү түргө `Arc<dyn Any + Send + Sync>` түшүрүүгө аракет.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Эстутум бөлбөй, жаңы `Weak<T>` курат.
    /// Кайтарым мааниде [`upgrade`] чакыруу ар дайым [`None`] берет.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Маалымат талаасы жөнүндө эч кандай ырастоолорсуз, шилтемелердин саналышына мүмкүнчүлүк берүүчү жардамчы териңиз.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Ушул `Weak<T>` көрсөткөн `T` объектисине чийки көрсөткүчтү кайтарып берет.
    ///
    /// Көрсөтүүчү күчтүү шилтемелер болгондо гана жарактуу болот.
    /// Көрсөтүүчү илинип турушу мүмкүн, тегизделбеген, ал тургай [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Экөө тең бир нерсени көрсөтүп жатышат
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Бул жердеги күчтүү нерсе аны тирүү кармайт, ошондуктан биз объектке дагы кире алабыз.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Бирок мындан ары эмес.
    /// // Биз weak.as_ptr() жасай алабыз, бирок көрсөткүчкө жетүү аныкталбаган жүрүм-турумга алып келет.
    /// // assert_eq! ("салам", кооптуу {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Эгерде көрсөткүч илинип турса, биз күзөттү түз кайтарабыз.
            // Бул жарактуу жүктүн дареги болушу мүмкүн эмес, анткени жүк дегенде эле ArcInner (usize) менен теңдештирилген.
            ptr as *const T
        } else {
            // КООПСУЗДУК: эгер is_dangling жалган болсо, анда көрсөткүчтү ажыратууга болот.
            // Ушул учурда пайдалуу жүк түшүп калышы мүмкүн жана биз пробенттүүлүктү сакташыбыз керек, андыктан чийки көрсөткүч менен иштөөнү колдонуңуз.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// `Weak<T>` керектейт жана аны чийки көрсөткүчкө айлантат.
    ///
    /// Бул алсыз көрсөткүчтү чийки көрсөткүчкө айландырат, ошол эле учурда бир алсыз шилтеме ээсин сактап калат (алсыз эсептөө бул иш менен өзгөрүлбөйт).
    /// [`from_raw`] менен кайра `Weak<T>` кылса болот.
    ///
    /// [`as_ptr`] сыяктуу көрсөткүчтүн максатына жетүү чектөөлөрү колдонулат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Мурда [`into_raw`] тарабынан түзүлгөн чийки көрсөткүчтү `Weak<T>` ке кайра айлантат.
    ///
    /// Бул күчтүү шилтеме алуу үчүн колдонулушу мүмкүн ([`upgrade`] кийинчерээк чалып) же `Weak<T>` түшүрүп алсыз санын бөлүштүрүү үчүн.
    ///
    /// Бул бир алсыз шилтемеге ээлик кылат ([`new`] тарабынан түзүлгөн көрсөткүчтөрдү кошпогондо, анткени алар эч нерсеге ээ эмес; ыкма дагы деле болсо алардын үстүндө иштейт).
    ///
    /// # Safety
    ///
    /// Көрсөтүүчү [`into_raw`] тен келип чыккан жана дагы деле болсо анын начар шилтемесине ээ болушу керек.
    ///
    /// Чакырганда күчтүү эсептөө 0 болушу мүмкүн.
    /// Ошого карабастан, учурда чийки көрсөткүч катары көрсөтүлгөн бир алсыз шилтеме ээлик кылат (алсыз эсептөө бул иш-аракет менен өзгөрүлбөйт), демек, аны [`into_raw`] мурунку чакыруусу менен жупташтыруу керек.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Акыркы алсыз санды азайтуу.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Киргизүү көрсөткүчү кандайча алынгандыгы жөнүндө контекстти Weak::as_ptr караңыз.

        let ptr = if is_dangling(ptr as *mut T) {
            // Бул асылып турган Алсыз.
            ptr as *mut ArcInner<T>
        } else {
            // Болбосо, көрсөткүч тил табылгыс Алсыз тараптан келген деп кепилдик беребиз.
            // КООПСУЗДУК: data_offset чалууга болбойт, анткени ptr чыныгы (мүмкүн түшүрүлгөн) Т.
            let offset = unsafe { data_offset(ptr) };
            // Ошентип, RcBox толугу менен алуу үчүн жылдырууну артка кайтарабыз.
            // КООПСУЗДУК: көрсөткүч Алсыздан келип чыккан, ошондуктан бул жылыш коопсуз.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // КООПСУЗДУК: биз азыр алсыз көрсөткүчтү калыбына келтирдик, ошондуктан алсыздарды түзө алабыз.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// `Weak` көрсөткүчүн [`Arc`] деңгээлине көтөрүү аракети, эгер ийгиликтүү болсо, ички маанинин түшүшүн кечеңдетүү.
    ///
    ///
    /// Ички мааниси түшүп калган болсо, [`None`] берет.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Бардык күчтүү көрсөткүчтөрдү жок кылыңыз.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Биз fetch_add ордуна күчтүү эсептөөнү көбөйтүү үчүн CAS циклин колдонобуз, анткени бул функция эч качан шилтеме саноону нөлдөн бирге алып барбашы керек.
        //
        //
        let inner = self.inner()?;

        // Жайбаракаттык, анткени биз байкаган 0 ар кандай жазуу талааны биротоло нөл абалында калтырат (демек, 0 көрсөткүчүнүн "stale" көрсөткүчү жакшы) жана башка мааниси төмөндөгү CAS аркылуу тастыкталат.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Муну эмне үчүн кылганыбызды `Arc::clone` теги жорумдарды караңыз (`mem::forget` үчүн).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaxed ийгиликтүү иштебей калгандыгы үчүн жакшы, анткени бизде жаңы абал жөнүндө эч кандай үмүт жок.
            // Ийгиликке жетүү үчүн `Arc::new_cyclic` менен синхрондошуу үчүн, ички маанини `Weak` шилтемелери түзүлгөндөн кийин баштоого болот.
            // Бул учурда, биз толугу менен баштапкы маанисин байкоо күтөт.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // жогоруда белгиленген жок
                Err(old) => n = old,
            }
        }
    }

    /// Ушул бөлүштүрүүгө багытталган күчтүү (`Arc`) көрсөткүчтөрүнүн санын алат.
    ///
    /// Эгер `self` [`Weak::new`] аркылуу түзүлгөн болсо, анда 0 кайтарылат.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Ушул бөлүштүрүүгө багытталган `Weak` көрсөткүчтөрүнүн санынын болжолдуу санын алат.
    ///
    /// Эгерде `self` [`Weak::new`] аркылуу түзүлгөн болсо же калган күчтүү көрсөткүчтөр жок болсо, анда 0 кайтарылат.
    ///
    /// # Accuracy
    ///
    /// Ишке ашыруунун чоо-жайынан улам, башка жиптер кандайдыр бир "Arc`s"же"Weak`s" бөлүштүрүүнү көрсөтүп жатканда, кайтып келген маани эки тарапка тең өчүрүлүшү мүмкүн.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Алсыз эсептөөнү окугандан кийин, жок дегенде, бир күчтүү көрсөткүч болгонун байкагандыктан, алсыз саноону байкап жатканда, ачык эле алсыз шилтеме (ар кандай күчтүү шилтемелер тирүү болгондо дагы) бар экендигин билдик, ошондуктан аны коопсуз чыгарып алабыз.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Көрсөтүүчү илинип турганда жана бөлүнгөн `ArcInner` жок болгондо `None`, кайтарат (башкача айтканда, бул `Weak` `Weak::new` тарабынан түзүлгөндө).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Биз "data" талаасын камтыган шилтеме түзүүдөн * сак эмеспиз, анткени талаа бир эле учурда мутацияга учурашы мүмкүн (мисалы, акыркы `Arc` түшүрүлсө, анда маалымат талаасы өз ордуна ташталат).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Эки "Алсыз" бирдей бөлүштүрүүнү көрсөткөн болсо ([`ptr::eq`] окшош), же экөө тең кандайдыр бир бөлүштүрүүнү көрсөтпөсө, `true` берет (анткени алар `Weak::new()`) менен түзүлгөн).
    ///
    ///
    /// # Notes
    ///
    /// Бул көрсөткүчтөрдү салыштырганда, `Weak::new()` бири-бирине теңелет дегенди билдирет, бирок алар эч кандай бөлүштүрүүнү көрсөтүшпөйт.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` салыштыруу.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Ушул эле бөлүштүрүүнү көрсөткөн `Weak` көрсөткүчүнүн клонун түзөт.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Бул эмне үчүн жумшартылгандыгы жөнүндө Arc::clone() комментарийлерин караңыз.
        // Бул fetch_add колдонушу мүмкүн (кулпуну эске албай), анткени алсыз эсептөө *башка* алсыз көрсөткүч жок жерде гана кулпуланат.
        //
        // (Демек, биз мындай учурда бул кодду иштете албайбыз).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Муну эмне үчүн кылганыбызды Arc::clone() теги комментарийлерден караңыз (mem::forget үчүн).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Эс тутумун бөлбөй, жаңы `Weak<T>` курат.
    /// Кайтарым мааниде [`upgrade`] чакыруу ар дайым [`None`] берет.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` көрсөткүчүн түшүрөт.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Эч нерсе басып чыгарбайт
    /// drop(foo);        // "dropped!" басып чыгарат
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Эгер биз акыркы чабал көрсөткүч экенибизди билсек, анда маалыматты толугу менен бөлүштүрүүгө убакыт келди.Эстутумга буйрутма берүү жөнүндө Arc::drop() талкуусун караңыз
        //
        // Бул жерде кулпуланган абалды текшерүүнүн кажети жок, анткени алсыз эсептөөнү так бир алсыз реф болгон учурда гана жабууга болот, демек, кулап бошонгондон кийин гана боло турган алсыз солкулдатууну КҮЙҮРҮҮ мүмкүн.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Биз бул адистешүүнү ушул жерде жасап жатабыз, бирок `&T` боюнча жалпы оптимизация эмес, анткени бул башкача айтканда, бардык теңдикти текшерүүгө чыгымдарды кошот.
/// Биздин оюбузча, "Arc`s" чоң баалуулуктарды сактоо үчүн колдонулат, алар клондолушу жай, бирок теңдикти текшерүү үчүн оор, бул чыгым оңой төлөнөт.
///
/// Эки X&X`ге караганда бирдей мааниге ээ болгон эки `Arc` клону болушу мүмкүн.
///
/// Биз муну `T: Eq` `PartialEq` катары атайылап рефлексивдүү болушу мүмкүн болгондо гана жасай алабыз.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Эки "Arc" үчүн теңдик.
    ///
    /// Эки `Arc` ар кандай бөлүштүрүүдө сакталып турса дагы, алардын ички маанилери бирдей болсо, бирдей болот.
    ///
    /// Эгерде `T` `Eq` ти ишке ашырса (теңдиктин рефлекстүүлүгүн билдирет), ошол эле бөлүштүрүүгө багытталган эки Arc` ар дайым бирдей болот.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Эки "Arc`" үчүн теңсиздик.
    ///
    /// Ички мааниси тең эмес болсо, эки `Arc` тең эмес.
    ///
    /// Эгерде `T` ошондой эле `Eq` ти ишке ашырса (теңдиктин рефлекстүүлүгүн билдирет), ошол эле мааниге багытталган эки "Arc`" эч качан тең эмес.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Эки Arc` үчүн жарым-жартылай салыштыруу.
    ///
    /// Экөө ички баалуулуктары боюнча `partial_cmp()` чакыруу менен салыштырылат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Эки "Arc`" салыштырганда азыраак.
    ///
    /// Экөө ички баалуулуктары боюнча `<` чакыруу менен салыштырылат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// "Arc`" эки салыштырганда "аз же барабар".
    ///
    /// Экөө ички баалуулуктары боюнча `<=` чакыруу менен салыштырылат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Эки Arc`ке салыштырганда чоңураак.
    ///
    /// Экөө ички баалуулуктары боюнча `>` чакыруу менен салыштырылат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Arc`ди эки салыштырганда"чоң же барабар".
    ///
    /// Экөө ички баалуулуктары боюнча `>=` чакыруу менен салыштырылат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Эки Arc`ке салыштыруу.
    ///
    /// Экөө ички баалуулуктары боюнча `cmp()` чакыруу менен салыштырылат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// `T` үчүн `Default` мааниси бар жаңы `Arc<T>` түзөт.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Шилтеме менен эсептелген кесинди бөлүп, "v" пункттарын клондоо менен толтуруңуз.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Аныктама эсептелген `str` бөлүп, ага `v` көчүрүп алыңыз.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Аныктама эсептелген `str` бөлүп, ага `v` көчүрүп алыңыз.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Кутулган объектини шилтеме менен эсептелген жаңы бөлүштүрүүгө жылдырыңыз.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Шилтеме менен эсептелген кесинди бөлүп, ага "v" пункттарын жылдырыңыз.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Vecке эс тутумун бошотууга уруксат бериңиз, бирок анын мазмунун жок кылбаңыз
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// `Iterator` деги ар бир элементти алат жана `Arc<[T]>` ке чогултат.
    ///
    /// # Иштөө мүнөздөмөлөрү
    ///
    /// ## Жалпы иш
    ///
    /// Жалпы учурда, `Arc<[T]>` ичине чогултуу алгач `Vec<T>` ке чогултуу жолу менен жүргүзүлөт.Башкача айтканда, төмөнкүлөрдү жазууда:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// бул биз жазгандай сезилет:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Бөлүштүрүүлөрдүн биринчи топтому ушул жерде болот.
    ///     .into(); // `Arc<[T]>` үчүн экинчи бөлүштүрүү ушул жерде болот.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Бул `Vec<T>` ти куруу үчүн канча керек болсо, ошону менен `Vec<T>` ти `Arc<[T]>` ке айландыруу үчүн бир жолу бөлүп берет.
    ///
    ///
    /// ## Узундугу белгилүү итераторлор
    ///
    /// Сиздин `Iterator` `TrustedLen` ти ишке ашырганда жана анын өлчөмү так болгондо, `Arc<[T]>` үчүн бирден бөлүштүрүү жүргүзүлөт.Мисалы:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Бул жерде бир эле бөлүү болот.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// `Arc<[T]>` ке чогултуу үчүн колдонулган trait адистештирүүсү.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Бул `TrustedLen` итераторуна тиешелүү.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // КООПСУЗДУК: Биз итератордун так узундугуна ээ болушубуз керек жана бизде бар.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Кадимки турмушка кайтып келүү.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Көрсөткүчтүн артындагы жүк үчүн `ArcInner` ичинде ордун толтуруңуз.
///
/// # Safety
///
/// Көрсөтүүчү буга чейин жарактуу болгон Т нускасын көрсөтүп (жана алар үчүн жарактуу метадайындарга ээ) болушу керек, бирок Т түшүрүлүшү мүмкүн.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Өлчөнбөгөн маанини ArcInner аягына чейин тегизде.
    // RcBox repr(C) болгондуктан, ал ар дайым эс тутумдагы акыркы талаа болуп кала берет.
    // КООПСУЗДУК: кесилишсиз түрлөрү гана болушу мүмкүн болгондуктан, trait объектилери,
    // жана тышкы түрлөрү, киргизүү коопсуздугунун талабы учурда align_of_val_raw талаптарын канааттандыруу үчүн жетиштүү;бул тилдин std чегинен тышкары ишенүүгө болбой турган деталдары.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}