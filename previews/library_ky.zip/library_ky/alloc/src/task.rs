#![stable(feature = "wake_trait", since = "1.51.0")]
//! Асинхрондук тапшырмалар менен иштөө үчүн типтер жана Traits.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Аткаруучуга коюлган милдетти ойготуу.
///
/// Бул trait менен [`Waker`] түзүүгө болот.
/// Аткаруучу ушул trait дин ишке ашуусун аныктай алат жана ошол аткаруучуда аткарылган милдеттерге өтүү үчүн Вейкерди кура алат.
///
/// Бул trait-эстутумга коопсуз жана эргономикалык альтернатива, [`RawWaker`] курууга болот.
/// Бул тапшырманы ойготуу үчүн колдонулган маалыматтар [`Arc`] те сакталган жалпы аткаруучунун дизайнын колдойт.
/// Айрым аткаруучулар (айрыкча, камтылган тутумдар үчүн) бул API колдоно алышпайт, ошол себептен [`RawWaker`] ошол системалар үчүн альтернатива катары бар.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// future алып, аны учурдагы жипте аягына чейин иштетүүчү негизги `block_on` функциясы.
///
/// **Note:** Бул мисал жөнөкөйлүктүн тууралыгын түшүндүрөт.
/// Түпкүлүктүн алдын алуу үчүн, өндүрүштүк класстагы иш-аракеттер `thread::unpark` ке аралык чалууларды жана уюлдук чакырууларды иштетиши керек.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Чакырганда учурдагы жипти ойготуучу ойготкуч.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Учурдагы жипке аяктоо үчүн future иштетүү.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Сурамжылоого алынышы үчүн future кодун кадаңыз.
///     let mut fut = Box::pin(fut);
///
///     // future өткөрүлүп бериле турган жаңы контекстти түзүңүз.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Аяктоо үчүн future иштетүү.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Бул тапшырманы ойгот.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Бул тапшырманы ойготкучту жалмабай ойгот.
    ///
    /// Эгерде аткаруучу вейкерди колдонбостон ойготуунун арзан жолун колдосо, анда бул ыкманы жокко чыгарышы керек.
    /// Демейки шартта, ал [`Arc`] ти клондойт жана клондо [`wake`] чакырат.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // КООПСУЗДУК: бул коопсуз, анткени raw_waker коопсуз курат
        // Arc тартып келген RawWaker<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: RawWaker курууга арналган бул жеке функция, тескерисинче, колдонулат
// Муну `From<Arc<W>> for RawWaker` имплине кошуп, `From<Arc<W>> for Waker` коопсуздугу trait туура жөнөтүлүшүнөн көз каранды болбошу үчүн, анын ордуна экөө тең бул функцияны түздөн-түз жана так деп аташат.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Клондоштуруу үчүн жаа шилтемесинин санын көбөйтүңүз.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Арканы Wake::wake функциясына жылдырып, мааниси боюнча ойгонуңуз
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Шилтеме менен ойгонгула, стаканды түшүрбөө үчүн аны ManuallyDrop ороп ал
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Доонун эсептик сандыгын төмөндөтүү
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}