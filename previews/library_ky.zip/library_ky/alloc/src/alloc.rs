//! Эстутумду бөлүштүрүү API'лери

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Бул глобалдык бөлүштүргүчтү чакыруу үчүн сыйкырдуу белгилер.rustc аларды `__rg_alloc` ж.б. чалууга жаратат.
    // эгерде `#[global_allocator]` атрибуту бар болсо (ал макроттун атрибутун кеңейтүүчү код ошол функцияларды жаратат) же libstd (`__rdl_alloc` ж.б.) шартындагы аткарууларды аташ керек.
    //
    // башкача айтканда.
    // LLVM rustc fork да бул функциялардын аталыштарын `malloc`, `realloc` жана `free` сыяктуу оптималдаштырууга мүмкүнчүлүк берүүчү өзгөчө учурлар.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Глобалдык эс бөлүштүрүүчү.
///
/// Бул түр [`Allocator`] trait, эгер бар болсо `#[global_allocator]` атрибуту менен катталган бөлүштүрүүчүгө чалууларды багыттоо аркылуу же `std` crate демейки шартында ишке ашырат.
///
///
/// Note: бул түрү туруксуз болсо да, анын иштешине [free functions in `alloc`](self#functions) аркылуу жетүүгө болот.
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Эстутумду глобалдык бөлүштүргүч менен бөлүңүз.
///
/// Бул функция чалууларды `#[global_allocator]` атрибутунда катталган [`GlobalAlloc::alloc`] ыкмасына же `std` crate демейки шартына багыттайт.
///
///
/// Бул функция жана [`Allocator`] trait туруктуу болгондо, [`Global`] тибиндеги `alloc` ыкмасынын пайдасына эскириши күтүлүүдө.
///
/// # Safety
///
/// [`GlobalAlloc::alloc`] караңыз.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Эстутумду глобалдык бөлүштүрүүчү менен бөлүштүрүү.
///
/// Бул функция чалууларды `#[global_allocator]` атрибутунда катталган [`GlobalAlloc::dealloc`] ыкмасына же `std` crate демейки шартына багыттайт.
///
///
/// Бул функция жана [`Allocator`] trait туруктуу болгондо, [`Global`] тибиндеги `dealloc` ыкмасынын пайдасына эскириши күтүлүүдө.
///
/// # Safety
///
/// [`GlobalAlloc::dealloc`] караңыз.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Эстутумду глобалдык бөлүштүрүүчү менен кайрадан бөлүштүрүү.
///
/// Бул функция чалууларды `#[global_allocator]` атрибутунда катталган [`GlobalAlloc::realloc`] ыкмасына же `std` crate демейки шартына багыттайт.
///
///
/// Бул функция жана [`Allocator`] trait туруктуу болгондо, [`Global`] тибиндеги `realloc` ыкмасынын пайдасына эскириши күтүлүүдө.
///
/// # Safety
///
/// [`GlobalAlloc::realloc`] караңыз.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Нөл башталган эс тутумду глобалдык бөлүштүрүүчү менен бөлүштүрүңүз.
///
/// Бул функция чалууларды `#[global_allocator]` атрибутунда катталган [`GlobalAlloc::alloc_zeroed`] ыкмасына же `std` crate демейки шартына багыттайт.
///
///
/// Бул функция жана [`Allocator`] trait туруктуу болгондо, [`Global`] тибиндеги `alloc_zeroed` ыкмасынын пайдасына эскириши күтүлүүдө.
///
/// # Safety
///
/// [`GlobalAlloc::alloc_zeroed`] караңыз.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // КООПСУЗДУК: `layout` нөлгө барабар эмес,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // КООПСУЗДУК: `Allocator::grow` менен бирдей
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // КООПСУЗДУК: `new_size` нөлгө барабар эмес, анткени `old_size` `new_size` тен чоң же ага барабар
            // коопсуздук шарттары талап кылгандай.Чакырган адам башка шарттарды сакташы керек
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` , балким, `new_size >= old_layout.size()` же ушул сыяктуу нерселерди текшерет.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // КООПСУЗДУК: анткени `new_layout.size()` `old_size` тен чоң же ага барабар болушу керек,
            // эски жана жаңы эс бөлүү `old_size` байт үчүн окуу жана жазуу үчүн жарактуу.
            // Ошондой эле, эски бөлүштүрүү али бөлүштүрүлө элек болгондуктан, `new_ptr` менен кайталана албайт.
            // Ошентип, `copy_nonoverlapping` ке чалуу коопсуз.
            // `dealloc` үчүн коопсуздук келишими чалган адам тарабынан сакталууга тийиш.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // КООПСУЗДУК: `layout` нөлгө барабар эмес,
            // башка шарттар чалган адам тарабынан сакталышы керек
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // КООПСУЗДУК: бардык шарттарды чалган адам сакташы керек
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // КООПСУЗДУК: бардык шарттарды чалган адам сакташы керек
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // КООПСУЗДУК: шарттарды чалган адам сакташы керек
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // КООПСУЗДУК: `new_size` нөлгө барабар эмес.Чакырган адам башка шарттарды сакташы керек
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` , балким, `new_size <= old_layout.size()` же ушул сыяктуу нерселерди текшерет.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // КООПСУЗДУК: анткени `new_size` `old_layout.size()` тен кичине же ага барабар болушу керек,
            // эски жана жаңы эс бөлүү `new_size` байт үчүн окуу жана жазуу үчүн жарактуу.
            // Ошондой эле, эски бөлүштүрүү али бөлүштүрүлө элек болгондуктан, `new_ptr` менен кайталана албайт.
            // Ошентип, `copy_nonoverlapping` ке чалуу коопсуз.
            // `dealloc` үчүн коопсуздук келишими чалган адам тарабынан сакталууга тийиш.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Уникалдуу көрсөткүчтөр үчүн бөлүштүрүүчү.
// Бул функция бошобошу керек.Эгер ошондой болсо, MIR коду иштебей калат.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Бул кол `Box` менен бирдей болушу керек, антпесе ICE болот.
// `Box` ке кошумча параметр кошулганда (`A: Allocator` сыяктуу), бул жерде дагы кошуш керек.
// Мисалы, `Box` `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` болуп өзгөрсө, анда бул функцияны `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` кылып өзгөртүү керек.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Бөлүү катасын жөндөөчү

extern "Rust" {
    // Бул глобалдык бөлүштүрүү каталарын жөндөөчүнү чакыруунун сыйкырдуу белгиси.
    // rustc аны `#[alloc_error_handler]` бар болсо `__rg_oom` чакыруу үчүн, же болбосо (`__rdl_oom`) төмөндөгү демейки аткарууларды чакыруу үчүн жаратат.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Эстутумду бөлүштүрүү катасы же үзгүлтүккө учурагандыгы үчүн токтотуу
///
/// Бөлүү катасына жооп катары эсептөөнү токтотууну каалаган эс тутумун бөлүштүрүүчү API интерфейсинин чалуучуларына `panic!` же ага окшошторун түздөн-түз чакырбай, ушул функцияны чакыруу сунушталат.
///
///
/// Бул функциянын демейки жүрүм-туруму-билдирүүнү стандарттык катага басып чыгаруу жана процессти токтотуу.
/// Аны [`set_alloc_error_hook`] жана [`take_alloc_error_hook`] менен алмаштырса болот.
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Ажыратуу үчүн `std::alloc::handle_alloc_error` түздөн-түз колдонсо болот.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // түзүлгөн `__rust_alloc_error_handler` аркылуу чакырылган

    // эгер `#[alloc_error_handler]` жок болсо
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // эгер `#[alloc_error_handler]` бар болсо
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Клондорду алдын-ала бөлүнүп, инициализацияланбаган эс тутумга адистештирүү.
/// `Box::clone` жана `Rc`/`Arc::make_mut` тарабынан колдонулат.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // *Биринчи* бөлүп берүү оптимизаторго клондолгон маанини ордунда түзүп, локалды өткөрүп, жылып кетүүгө мүмкүндүк берет.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Биз ар дайым өз жерибизде көчүрүп алсак болот, жергиликтүү мааниге ээ болбойбуз.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}