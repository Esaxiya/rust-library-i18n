use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Vec::from_iter үчүн колдонулган адистештирүү trait
///
/// ## Делегациянын графиги:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Адатта, vector функциясына дароо кайра топтолгон vector функциясын өткөрүү.
        // Эгерде IntoIter такыр өркүндөтүлбөсө, биз аны кыска туташтырышыбыз мүмкүн.
        // Ал өркүндөтүлгөндө, биз эс тутумду дагы колдонуп, маалыматты алдыга жылдыра алабыз.
        // Бирок, биз пайда болгон Vec колдонулбаган кубаттуулукка ээ болгондо гана, муну жалпы FromIterator ишке ашыруусу аркылуу түзө алабыз.
        //
        // Бул чектөө катуу талап кылынбайт, анткени Vec компаниясынын бөлүштүрүү жүрүм-туруму атайылап белгиленбейт.
        // Бирок бул консервативдүү чечим.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // spec_extend() ке ыйгарым укук бериши керек, анткени extend() өзү бош Vecs үчүн spec_fromга өткөрүп берет
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Бул `iterator.as_slice().to_vec()` колдонот, анткени spec_extend акыркы сыйымдуулук + узундугу жөнүндө ой жүгүртүү үчүн көбүрөөк кадамдарды жасашы керек жана ошону менен көбүрөөк иш жасаш керек.
// `to_vec()` түздөн-түз туура сумманы бөлүштүрөт жана аны так толтурат.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): бул ыкманы аныктоо үчүн талап кылынган cfg(test) мүнөздүү `[T]::to_vec` ыкмасы жеткиликтүү эмес.
    // Анын ордуна cfg(test) NB менен гана жеткиликтүү `slice::to_vec` функциясын колдонуңуз, slice.rs модулундагы slice::hack көбүрөөк маалымат алуу үчүн
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}