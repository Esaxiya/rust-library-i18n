// `SetLenOnDrop` мааниси колдонуудан чыкканда vecтин узундугун белгилеңиз.
//
// Идеясы: SetLenOnDropтогу узундук талаасы локалдык өзгөрүлмө, аны оптимизатор көрө алат, Vecтин маалымат көрсөткүчү аркылуу бир дагы дүкөнгө окшош эмес.
// Бул #32155 псевдонимин талдоо маселесин чечүү жолу
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}