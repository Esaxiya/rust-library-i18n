use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Элементти алып салуу керектигин аныктоо үчүн жабууну колдонгон итератор.
///
/// Бул структура [`Vec::drain_filter`] тарабынан түзүлгөн.
/// Көбүрөөк маалымат алуу үчүн анын документтерин караңыз.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// `next` кийинки чалуу менен текшериле турган нерсенин индекси.
    pub(super) idx: usize,
    /// Ушул убакка чейин (removed) кургатылган заттардын саны.
    pub(super) del: usize,
    /// Кургактыкка чейин `vec` баштапкы узундугу.
    pub(super) old_len: usize,
    /// Чыпка сыноо предикаты.
    pub(super) pred: F,
    /// panic көрсөткөн желек фильтрдин сыноо предикатында пайда болду.
    /// Бул `DrainFilter` калдыгын керектөөнүн алдын алуу үчүн тамчы ишке ашырууда ишара катары колдонулат.
    /// Бардык иштетилбеген нерселер `vec` те артка жылдырылат, бирок мындан ары эч нерсе ташталбайт же чыпка предикаты тарабынан сыналбайт.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Негизги бөлүштүргүчкө шилтеме берет.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Индикатты *предикат чакырылгандан кийин* жаңыртыңыз.
                // Эгерде индекс жаңыланса жана panics предикаты болсо, анда бул индекстеги элемент ачыкка чыкмак.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Бул абдан бузулган абалы, жана, чынында, туура иш жок.
                        // Биз `pred` программасын иштетүүнү каалабайбыз, андыктан бардык иштетилбеген элементтерди артка жылдырып, векторго алар дагы деле бар экендигин билдиребиз.
                        //
                        // Артка жылдыруу, предикаттагы panic ге чейин акыркы ийгиликтүү агып чыккан нерсенин эки эсе түшүп кетишинин алдын алуу үчүн талап кылынат.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Чыпка предикаты али дүрбөлөңгө түшө элек болсо, калган элементтерди колдонууга аракет кылыңыз.
        // Калган элементтерди артка жылдырабыз, эгерде биз буга чейин дүрбөлөңгө түшкөнбү же бул жерде керектөө panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}