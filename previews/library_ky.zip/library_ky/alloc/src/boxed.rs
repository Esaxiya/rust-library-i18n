//! Үймөктөрдү бөлүштүрүү үчүн көрсөткүч түрү.
//!
//! [`Box<T>`], кокусунан 'box' деп аталат, Rust де үймөктөрдү бөлүштүрүүнүн жөнөкөй түрүн камсыз кылат.Кутулар бул бөлүштүрүү үчүн менчик укугун камсыз кылат жана алардын чектеринен чыгып кеткенде, алардын мазмунун таштайт.Кутучалар, алардын эч качан `isize::MAX` байттан ашпагандыгын камсыз кылат.
//!
//! # Examples
//!
//! [`Box`] түзүп, стекден үймөккө маанини жылдырыңыз:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! [`Box`] дан стекке [dereferencing] аркылуу маанини жылдырыңыз:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! Рекурсивдүү маалымат структурасын түзүү:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! Бул "Cons (1, Cons(2, Nil))`.
//!
//! Рекурсивдүү структуралар кутуга салынышы керек, анткени эгер `Cons` аныктамасы мындай болсо:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! Бул иштебейт.Себеби, `List` өлчөмү тизмеде канча элемент бар экендигине жараша болот, ошондуктан биз `Cons` үчүн канча эстутум бөлүп берүүнү билбейбиз.Аныкталган көлөмгө ээ [`Box<T>`] киргизүү менен, биз `Cons` канчалык чоң болушу керектигин билебиз.
//!
//! # Эстутум макети
//!
//! Нөл эмес өлчөмдөгү [`Box`] [`Global`] бөлүштүргүчүн бөлүштүрүү үчүн колдонот.[`Box`] жана [`Global`] бөлүштүргүчү менен бөлүнгөн чийки көрсөткүчтүн ортосунда эки жолду тең айландырууга болот, эгерде бөлүштүрүүчү менен колдонулган [`Layout`] түрүнө туура келсе.
//!
//! Тагыраак айтканда, `Layout::for_value(&*value)` менен [`Global`] бөлүштүргүч менен бөлүштүрүлгөн `value:* mut T` [`Box::<T>::from_raw(value)`] аркылуу кутуга айландырылышы мүмкүн.
//! Тескерисинче, [`Box::<T>::into_raw`] тен алынган `value:*mut T` эс тутуму [`Layout::for_value(&* value)`] менен [`Global`] бөлүштүргүчүн колдонуп бөлүштүрүлүшү мүмкүн.
//!
//! Нөл өлчөмүндөгү маанилер үчүн `Box` көрсөткүчү окуу жана жазуу үчүн [valid] болушу жана жетиштүү деңгээлде турушу керек.
//! Атап айтканда, чийки көрсөткүчкө кандайдыр бир тегизделген нөлдүк эмес бүтүндөй сандын ыргытылышы жарактуу көрсөткүчтү жаратат, бирок боштондукка чыккан мурун берилген эс тутумга багытталган көрсөткүч жараксыз.
//! Эгерде `Box::new` колдонууга мүмкүн болбосо, анда ZSTке кутуча куруунун сунуш кылынган жолу-[`ptr::NonNull::dangling`] колдонуу.
//!
//! `T: Sized` болгондо, `Box<T>` бир көрсөткүч катары чагылдырылат жана C көрсөткүчтөрү менен (башкача айтканда, C түрү `T*`) ABI менен шайкеш келет.
//! Демек, сизде экстернаттык "C" Rust функциялары бар болсо, анда Cден чалып, `Box<T>` түрлөрүн колдонуп, ошол Rust функцияларын аныктап, C тарабында `T*` функциясын колдонсоңуз болот.
//! Мисал катары, кандайдыр бир `Foo` маанисин жаратуучу жана жок кылуучу функцияларды жарыялаган ушул C баштыгын карап көрөлү:
//!
//! ```c
//! /* C баш */
//!
//! /* Чакырганга менчик укугун кайтарып берет */
//! struct Foo* foo_new(void);
//!
//! /* Чакыруучудан менчик укугун алат;NULL менен чакырганда, жок */
//! void foo_delete(struct Foo*);
//! ```
//!
//! Бул эки функция Rust де төмөнкүдөй ишке ашырылышы мүмкүн.Бул жерде, Cден `struct Foo*` түрү `Box<Foo>` ке которулуп, менчик укугун чектейт.
//! `foo_delete` үчүн жараксыз аргумент Rust де `Option<Box<Foo>>` катары берилгендигин дагы эске алыңыз, анткени `Box<Foo>` нөл болушу мүмкүн эмес.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! `Box<T>` C көрсөткүчү менен бирдей өкүлчүлүккө жана C ABIге ээ болсо дагы, бул сиз каалаган `T*` ти `Box<T>` ге айландырып, иштей турган нерселерди күтүүгө болот дегенди билдирбейт.
//! `Box<T>` баалуулуктар ар дайым толугу менен тегизделген, нөл эмес көрсөткүчтөр болот.Мындан тышкары, `Box<T>` үчүн деструктор глобалдык бөлүштүрүүчү менен баалуулукту бошотууга аракет кылат.Жалпысынан алганда, глобалдык бөлүштүргүчтөн чыккан көрсөткүчтөр үчүн `Box<T>` ти колдонуу эң мыкты тажрыйба.
//!
//! **Маанилүү.** Жок дегенде, азыркы учурда C тилинде аныкталган, бирок Rust ден алынган функциялар үчүн `Box<T>` түрлөрүн колдонуудан алыс болуңуз.Мындай учурларда, мүмкүн болушунча тыгызыраак С түрлөрүн чагылдыруу керек.
//! C аныктамасы `T*` колдонуп жаткан `Box<T>` сыяктуу түрлөрдү колдонуу, [rust-lang/unsafe-code-guidelines#198][ucg#198] сүрөттөлгөндөй, аныкталбаган жүрүм-турумга алып келиши мүмкүн.
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// Үймөктөрдү бөлүштүрүү үчүн көрсөткүч түрү.
///
/// Көбүрөөк маалымат алуу үчүн [module-level documentation](../../std/boxed/index.html) караңыз.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// Үймөккө эстутум бөлүп, андан кийин `x` жайгаштырат.
    ///
    /// Бул `T` нөл өлчөмүндө болсо, иш жүзүндө бөлбөйт.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// Башталбаган мазмуну бар жаңы кутучаны курат.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Кийинкиге калтыруу:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// Эстутум `0` байт менен толтурулган, башталбаган мазмуну бар жаңы `Box` курат.
    ///
    ///
    /// Бул ыкманы туура жана туура эмес колдонуу мисалдары үчүн [`MaybeUninit::zeroed`][zeroed] ти караңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// Жаңы `Pin<Box<T>>` курат.
    /// Эгерде `T` `Unpin` ти ишке ашырбаса, анда `x` эс тутумуна тыгылып, жылдырылбай калат.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// Үймөктөгү эс тутумду бөлүп, андан кийин `x` жайгаштырат, эгерде бөлүштүрүү болбой калса, ката кетет
    ///
    ///
    /// Бул `T` нөл өлчөмүндө болсо, иш жүзүндө бөлбөйт.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// Үймөдө инициализацияланбаган мазмуну бар жаңы кутуча курат, эгерде бөлүштүрүү болбой калса, ката кетет
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Кийинкиге калтыруу:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// Эстутум үйүлгөн `0` байт менен толтурулган, башталбаган мазмуну бар жаңы `Box` курат
    ///
    ///
    /// Бул ыкманы туура жана туура эмес колдонуу мисалдары үчүн [`MaybeUninit::zeroed`][zeroed] ти караңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// Берилген бөлүштүргүчтөгү эс тутумду бөлүп, андан кийин ага `x` жайгаштырат.
    ///
    /// Бул `T` нөл өлчөмүндө болсо, иш жүзүндө бөлбөйт.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// Берилген бөлүштүргүчтөгү эс тутумду бөлүштүрүп, андан кийин `x` ичине жайгаштырат, эгерде бөлүштүрүү болбой калса, ката кетет
    ///
    ///
    /// Бул `T` нөл өлчөмүндө болсо, иш жүзүндө бөлбөйт.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// Берилген бөлүштүргүчтөгү ачылбаган мазмуну бар жаңы кутучаны курат.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // Кийинкиге калтыруу:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Бөлүнүүнү unwrap_or_elseден артык көрүңүз, анткени кээде жабылбайт.
        // Бул коддун көлөмүн чоңойтот.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Берилген бөлүштүргүчтөгү инициализацияланбаган мазмуну бар жаңы кутучаны курат, эгер бөлүштүрүү болбой калса, ката кайтат
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // Кийинкиге калтыруу:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Берилген бөлүштүргүчтөгү эс тутум `0` байт менен толтурулуп, башталбаган мазмуну бар жаңы `Box` курат.
    ///
    ///
    /// Бул ыкманы туура жана туура эмес колдонуу мисалдары үчүн [`MaybeUninit::zeroed`][zeroed] ти караңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Бөлүнүүнү unwrap_or_elseден артык көрүңүз, анткени кээде жабылбайт.
        // Бул коддун көлөмүн чоңойтот.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Берилген бөлүштүргүчтүн эс тутуму `0` байт менен толтурулуп, баштала элек мазмуну бар жаңы `Box` курат, эгер бөлүштүрүү болбой калса, ката кетирет,
    ///
    ///
    /// Бул ыкманы туура жана туура эмес колдонуу мисалдары үчүн [`MaybeUninit::zeroed`][zeroed] ти караңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Жаңы `Pin<Box<T, A>>` курат.
    /// Эгерде `T` `Unpin` ти ишке ашырбаса, анда `x` эс тутумуна тыгылып, жылдырылбай калат.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// `Box<T>` ти `Box<[T]>` ке айландырат
    ///
    /// Бул конверсия үймөктө бөлүнбөйт жана өз ордунда болот.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// Оролгон маанисин кайтарып, `Box` сарптайт.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// Башталбаган мазмуну бар жаңы кутуча кесимчесин курат.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Кийинкиге калтыруу:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// Эстутум `0` байт менен толтурулган, инициализирленбеген жаңы кутуча тилкесин курат.
    ///
    ///
    /// Бул ыкманы туура жана туура эмес колдонуу мисалдары үчүн [`MaybeUninit::zeroed`][zeroed] ти караңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// Берилген бөлүштүргүчтөгү инициализацияланбаган курамы бар жаңы кутуча тилкесин курат.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // Кийинкиге калтыруу:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// Берилген бөлүштүргүчтөгү башталбаган мазмуну бар жаңы кутуча тилкесин курат, эс тутуму `0` байт менен толтурулат.
    ///
    ///
    /// Бул ыкманы туура жана туура эмес колдонуу мисалдары үчүн [`MaybeUninit::zeroed`][zeroed] ти караңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// `Box<T, A>` ке которулат.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] сыяктуу эле, ал чындап эле инициалдаштырылган абалда экендигине кепилдик берүү чалуучунун колунда.
    ///
    /// Мазмун толук кандуу баштала элек учурда, муну тез арада аныкталбаган жүрүм-турумга алып келет.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // Кийинкиге калтыруу:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// `Box<[T], A>` ке которулат.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] сыяктуу эле, маанилер чындыгында баштапкы абалда экендигине кепилдик берүү чалуучунун колунда.
    ///
    /// Мазмун толук кандуу баштала элек учурда, муну тез арада аныкталбаган жүрүм-турумга алып келет.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Кийинкиге калтыруу:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// Чийки көрсөткүчтөн кутуча курат.
    ///
    /// Бул функцияны чакыргандан кийин, чийки көрсөткүч пайда болгон `Box` таандык.
    /// Тактап айтканда, `Box` деструктору `T` деструкторун чакырып, бөлүнгөн эс тутумду бошотот.
    /// Бул коопсуз болушу үчүн, эс `Box` колдонгон [memory layout] ылайык бөлүштүрүлгөн болушу керек.
    ///
    ///
    /// # Safety
    ///
    /// Бул функция кооптуу, анткени туура эмес колдонуу эс тутумда көйгөйлөрдү жаратышы мүмкүн.
    /// Мисалы, эгер функция бир эле чийки көрсөткүчтө эки жолу чакырылса, анда эки эселенген пайда болушу мүмкүн.
    ///
    /// Коопсуздук шарттары [memory layout] бөлүмүндө баяндалган.
    ///
    /// # Examples
    ///
    /// Мурун [`Box::into_raw`] аркылуу чийки көрсөткүчкө айландырылган `Box` ти жаратыңыз:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Глобалдык бөлүштүргүчтү колдонуп, нөлдөн баштап `Box` ти кол менен түзүңүз:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // Жалпысынан .write `ptr` тин (uninitialized) мурунку мазмунун жок кылууга аракеттенбөө үчүн талап кылынат, бирок бул жөнөкөй мисал үчүн `*ptr = 5` да иштесе керек.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// Берилген бөлүштүргүчтө чийки көрсөткүчтөн кутуча курат.
    ///
    /// Бул функцияны чакыргандан кийин, чийки көрсөткүч пайда болгон `Box` таандык.
    /// Тактап айтканда, `Box` деструктору `T` деструкторун чакырып, бөлүнгөн эс тутумду бошотот.
    /// Бул коопсуз болушу үчүн, эс `Box` колдонгон [memory layout] ылайык бөлүштүрүлгөн болушу керек.
    ///
    ///
    /// # Safety
    ///
    /// Бул функция кооптуу, анткени туура эмес колдонуу эс тутумда көйгөйлөрдү жаратышы мүмкүн.
    /// Мисалы, эгер функция бир эле чийки көрсөткүчтө эки жолу чакырылса, анда эки эселенген пайда болушу мүмкүн.
    ///
    /// # Examples
    ///
    /// Мурун [`Box::into_raw_with_allocator`] аркылуу чийки көрсөткүчкө айландырылган `Box` ти жаратыңыз:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Тутум бөлүштүргүчүн колдонуп, нөлдөн баштап `Box` түзүңүз:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // Жалпысынан .write `ptr` тин (uninitialized) мурунку мазмунун жок кылууга аракеттенбөө үчүн талап кылынат, бирок бул жөнөкөй мисал үчүн `*ptr = 5` да иштесе керек.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// `Box` керектейт, оролгон чийки көрсөткүчтү кайтарып.
    ///
    /// Көрсөтүүчү туура тегизделип, нөлсүз болот.
    ///
    /// Бул функцияны чакыргандан кийин, чалган адам `Box` тарабынан башкарылган эс тутум үчүн жооп берет.
    /// Атап айтканда, чалган адам `T` ти колдонуп, `Box` колдонгон [memory layout] эске алып, эс тутумду бошотушу керек.
    /// Муну жасоонун эң оңой жолу-[`Box::from_raw`] функциясы менен чийки көрсөткүчтү кайра `Box` ке айландыруу, `Box` деструкторуна тазалоону жүргүзүү.
    ///
    ///
    /// Note: бул байланышкан функция, демек, аны `b.into_raw()` ордуна `Box::into_raw(b)` деп атоого туура келет.
    /// Бул ички түрдөгү метод менен эч кандай карама-каршылык болбошу үчүн.
    ///
    /// # Examples
    /// Автоматтык тазалоо үчүн [`Box::from_raw`] менен чийки көрсөткүчтү `Box` ке кайра айландыруу:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Деструкторду так иштетүү жана эс тутумун бөлүштүрүү менен кол менен тазалоо:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// `Box` сарптайт, оролгон чийки көрсөткүчтү жана бөлүштүргүчтү кайтарып берет.
    ///
    /// Көрсөтүүчү туура тегизделип, нөлсүз болот.
    ///
    /// Бул функцияны чакыргандан кийин, чалган адам `Box` тарабынан башкарылган эс тутум үчүн жооп берет.
    /// Атап айтканда, чалган адам `T` ти колдонуп, `Box` колдонгон [memory layout] эске алып, эс тутумду бошотушу керек.
    /// Муну жасоонун эң оңой жолу-[`Box::from_raw_in`] функциясы менен чийки көрсөткүчтү кайра `Box` ке айландыруу, `Box` деструкторуна тазалоону жүргүзүү.
    ///
    ///
    /// Note: бул байланышкан функция, демек, аны `b.into_raw_with_allocator()` ордуна `Box::into_raw_with_allocator(b)` деп атоого туура келет.
    /// Бул ички түрдөгү метод менен эч кандай карама-каршылык болбошу үчүн.
    ///
    /// # Examples
    /// Автоматтык тазалоо үчүн [`Box::from_raw_in`] менен чийки көрсөткүчтү `Box` ке кайра айландыруу:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Деструкторду так иштетүү жана эс тутумун бөлүштүрүү менен кол менен тазалоо:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // Box Stacked Borrows тарабынан "unique pointer" катары таанылат, бирок ички бул типтүү тутум үчүн чийки көрсөткүч болуп саналат.
        // Аны түздөн-түз чийки көрсөткүчкө айлантуу, "releasing" чийки кирүүгө уруксат берүүчү уникалдуу көрсөткүч деп таанылбайт, андыктан бардык чийки көрсөткүчтөр `Box::leak` аркылуу өтүшү керек.
        //
        // Чийки көрсөткүчкө * бурулса, туура иштейт.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// Негизги бөлүштүргүчкө шилтеме берет.
    ///
    /// Note: бул байланышкан функция, демек, аны `b.allocator()` ордуна `Box::allocator(&b)` деп атоого туура келет.
    /// Бул ички түрдөгү метод менен эч кандай карама-каршылык болбошу үчүн.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// `Box` ти керектейт жана агып чыгат, өзгөрүлмө маалымдаманы кайтарып берет, `&'a mut T`.
    /// `T` түрү тандалган өмүр бою `'a` эскириши керек экендигин эске алыңыз.
    /// Эгерде типтеги статикалык шилтемелер гана болсо же такыр жок болсо, анда бул `'static` болуп тандалышы мүмкүн.
    ///
    /// Бул функция, негизинен, программанын өмүрүнүн аягына чейин жашаган маалыматтар үчүн пайдалуу.
    /// Кайтарылган шилтемени таштоо эс тутумдун агып кетишине алып келет.
    /// Эгер бул кабыл алынбаса, анда `Box` чыгарган [`Box::from_raw`] функциясы менен шилтеме алгач оролушу керек.
    ///
    /// Бул `Box` ти түшүрсө болот, анда `T` туура талкаланат жана бөлүнгөн эс тутум бошотулат.
    ///
    /// Note: бул байланышкан функция, демек, аны `b.leak()` ордуна `Box::leak(b)` деп атоого туура келет.
    /// Бул ички түрдөгү метод менен эч кандай карама-каршылык болбошу үчүн.
    ///
    /// # Examples
    ///
    /// Жөнөкөй колдонуу:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// Өлчөмсүз маалыматтар:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// `Box<T>` ти `Pin<Box<T>>` ке айландырат
    ///
    /// Бул конверсия үймөктө бөлүнбөйт жана өз ордунда болот.
    ///
    /// Бул [`From`] аркылуу жеткиликтүү.
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // `T: !Unpin` болгондо `Pin<Box<T>>` идиштерин жылдыруу же алмаштыруу мүмкүн эмес, андыктан эч кандай кошумча талаптарды койбостон, аны түз эле бекитүү мүмкүн.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: Эч нерсе жасабаңыз, учурда тамчы компилятор тарабынан аткарылууда.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// T үчүн `Default` мааниси бар `Box<T>` түзөт.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// Ушул кутунун `clone()` мазмунун камтыган жаңы кутучаны кайтарып берет.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // Наркы бирдей
    /// assert_eq!(x, y);
    ///
    /// // Бирок алар уникалдуу объектилер
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // Түздөн-түз клондолгон маанини жазууга мүмкүндүк берүү үчүн эс тутумду алдын-ала бөлүп алыңыз.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// Жаңы булакты түзбөстөн, "булактын" мазмунун `self` ке көчүрөт.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // Наркы бирдей
    /// assert_eq!(x, y);
    ///
    /// // Жана эч кандай бөлүштүрүү болгон жок
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // бул маалыматтардын көчүрмөсүн түзөт
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// `T` жалпы түрүн `Box<T>` форматына которот
    ///
    /// Конверсия үймөккө бөлүнүп, `t` стекден ага түртөт.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// `Box<T>` ти `Pin<Box<T>>` ке айландырат
    ///
    /// Бул конверсия үймөктө бөлүнбөйт жана өз ордунда болот.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// `&[T]` ти `Box<[T]>` ке айландырат
    ///
    /// Бул которуу үймөккө бөлүнүп, `slice` көчүрмөсүн аткарат.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // &[u8] түзүңүз, ал <[u8]> кутучасын түзүү үчүн колдонулат
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// `&str` ти `Box<str>` ке айландырат
    ///
    /// Бул которуу үймөккө бөлүнүп, `s` көчүрмөсүн аткарат.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// `Box<str>` ти `Box<[u8]>` ке айландырат
    /// Бул конверсия үймөктө бөлүнбөйт жана өз ордунда болот.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // Box түзүү<str>ал Box [[u8]> түзүү үчүн колдонулат
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // &[u8] түзүңүз, ал <[u8]> кутучасын түзүү үчүн колдонулат
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// `[T; N]` ти `Box<[T]>` ке айландырат
    /// Бул которуу массивди жаңы үймөктөлгөн эс тутумга жылдырат.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Кутуну конкреттүү түргө түшүрүүгө аракет кылуу.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Кутуну конкреттүү түргө түшүрүүгө аракет кылуу.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// Кутуну конкреттүү түргө түшүрүүгө аракет кылуу.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ички Uniqти түздөн-түз кутудан алуу мүмкүн эмес, анын ордуна Unique аталышын берген * constге таштайбыз
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// Демейки эмес, `last()` тин I колдонулушун колдонгон көлөмдүү I үчүн адистештирүү.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}