//! Бинардык үймө менен жүзөгө ашырылган артыкчылыктуу кезек.
//!
//! Киргизүү жана ири элемент *O*(log(*n*)) убакыт татаалдыгына ээ.
//! Эң чоң элементти текшерүү *O*(1).vector ди бинардык үймөгө которуу жеринде жасалышы мүмкүн жана *O*(*n*) татаалдыгы бар.
//! Бинардык үймөктү ордунда сорттолгон vector ге айландырса болот, аны *O*(*n*\*log(* n*)) ордунда турган үй үчүн колдонууга болот).
//!
//! # Examples
//!
//! Бул [shortest path problem][sssp] ти [directed graph][dir_graph] те чечүү үчүн [Dijkstra's algorithm][dijkstra] ти ишке ашырган чоңураак мисал.
//!
//! Бул бажы түрлөрү менен [`BinaryHeap`] кантип колдонууну көрсөтөт.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Артыкчылыктуу кезек `Ord` көз каранды.
//! // trait программасын ачык-айкын жүзөгө ашырыңыз, андыктан кезек мак-үймөктүн ордуна мин-үймөк болуп калат.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Байкасаңыз, биз буйрутманы чыгымдар боюнча которобуз.
//!         // Добуштар тең болуп калган учурда, биз позицияларды салыштырабыз, бул кадам `PartialEq` жана `Ord` шаймандарын ырааттуу жүргүзүү үчүн керек.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` ошондой эле ишке ашырылышы керек.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Ар бир түйүн `usize` катары көрсөтүлүп, кыскача ишке ашырылат.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Dijkstra кыска жолдун алгоритми.
//!
//! // `start` баштап, ар бир түйүнгө чейинки эң кыска аралыкты көзөмөлдөө үчүн `dist` колдонуңуз.Бул иш-аракет эс тутумду үнөмдөбөйт, анткени кайталанган түйүндөрдү кезекте калтырышы мүмкүн.
//! //
//! // Ал ошондой эле жөнөкөй ишке ашыруу үчүн, күзөтчү мааниси катары `usize::MAX` колдонот.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [түйүн]= `start` ден `node` га чейинки учурдагы эң кыска аралык
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Биз нөлдүк наркы менен `start` дебиз
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Адегенде (min-heap) арзаныраак түйүндөр менен чек араны карап чыгыңыз
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Же болбосо, биз эң кыска жолдорду таба берсек болмок
//!         if position == goal { return Some(cost); }
//!
//!         // Маанилүү, биз буга чейин жакшы жолун тапкан болушу мүмкүн
//!         if cost > dist[position] { continue; }
//!
//!         // Ар бир түйүнгө жетүү үчүн, ушул түйүн аркылуу арзаныраак чыгым менен жол таба алабызбы, көрө аласыз
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Андай болсо, чек арага кошуп, уланта бериңиз
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Релаксация, биз мындан мыкты жолду таптык
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Максатка жетүү мүмкүн эмес
//!     None
//! }
//!
//! fn main() {
//!     // Бул биз колдоно турган багытталган график.
//!     // Түйүндүн сандары ар кандай абалга туура келет, ал эми edge салмагы бир түйүндөн экинчи түйүнгө өтүү баасын билдирет.
//!     //
//!     // Четтери бир тараптуу экендигин эске алыңыз.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // График ар бир индекстин, түйүн маанисине туура келген, чыккан кырлардын тизмесине ээ болгон чектеш тизме катары көрсөтүлөт.
//!     // Анын натыйжалуулугу үчүн тандалган.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Түйүн 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // 1-түйүн
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Түйүн 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Түйүн 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Түйүн 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Бинардык үймө менен жүзөгө ашырылган артыкчылыктуу кезек.
///
/// Бул максималдуу үймөк болот.
///
/// Буюмдун `Ord` trait тарабынан аныкталгандай, башка буюмга карата буйрутмасы үйүлүп жатканда өзгөрүлүп тургандай өзгөрүлүшү логикалык ката.
///
/// Адатта, бул `Cell`, `RefCell`, глобалдык абал, I/O же кооптуу код аркылуу гана мүмкүн.
/// Мындай логикалык катадан келип чыккан жүрүм-турум көрсөтүлгөн эмес, бирок аныкталбаган жүрүм-турумга алып келбейт.
/// Буга panics, туура эмес жыйынтыктар, токтотуулар, эс тутумдун агып кетиши жана токтотулбагандар кириши мүмкүн.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Тип боюнча тыянак бизге ачык типтеги колтамга (бул мисалда `BinaryHeap<i32>` болмок) калтырууга мүмкүнчүлүк берет.
/////
/// let mut heap = BinaryHeap::new();
///
/// // Үймөктөгү кийинки нерсени көрүү үчүн peekти колдонсок болот.
/// // Бул учурда, ал жакта эч нерсе жок, андыктан биз Жокту алабыз.
/// assert_eq!(heap.peek(), None);
///
/// // Бир нече упай кошуп көрөлү ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Азыр үймөктөгү эң маанилүү нерсени карап чыгуу.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Үймөнүн узундугун текшере алабыз.
/// assert_eq!(heap.len(), 3);
///
/// // Үйүлгөн нерселердин үстүнөн кайталай алабыз, бирок алар туш келди тартипте кайтарылып берилет.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Эгерде биз анын ордуна ушул упайларды койсок, анда алар ирээти менен кайтып келиши керек.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Үймөктү калган нерселерден тазалай алабыз.
/// heap.clear();
///
/// // Үймө эми бош болушу керек.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Же `std::cmp::Reverse` же колдонуучунун `Ord` жүзөгө ашырылышы `BinaryHeap` ти мин-үймөк кылуу үчүн колдонсо болот.
/// Бул `heap.pop()` эң чоңунун ордуна эң кичине маанини кайтарып берет.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // `Reverse` маанисин ороо
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Эгер биз ушул упайларды популярдуулукка койсок, анда алар тескерисинче кайтып келиши керек.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Убакыттын татаалдыгы
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// `push` үчүн мааниси күтүлгөн чыгым болуп саналат;методикалык документация кыйла кеңири талдоо берет.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// `BinaryHeap` форматындагы эң чоң нерсеге карата өзгөрүлмө шилтемени орогон структура.
///
///
/// Бул `struct` [`BinaryHeap`] боюнча [`peek_mut`] ыкмасы менен түзүлгөн.
/// Көбүрөөк маалымат алуу үчүн анын документтерин караңыз.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // КООПСУЗДУК: PeekMut бош эмес үймөктөр үчүн гана орнотулган.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // КООПСУЗ: PeekMut бош эмес үймөктөргө гана арналган
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // КООПСУЗ: PeekMut бош эмес үймөктөргө гана арналган
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Үймөдөн бааланган маанини алып салат жана кайтарып берет.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Бош `BinaryHeap<T>` түзөт.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Бош `BinaryHeap` ти максималдуу кылып түзөт.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Белгилүү бир кубаттуулуктагы бош `BinaryHeap` түзөт.
    /// Бул `capacity` элементтери үчүн жетиштүү эс тутумун алдын-ала бөлүштүрөт, андыктан `BinaryHeap` жок дегенде ушунча чоңдукту камтыганга чейин аны кайрадан бөлүштүрүүгө туура келбейт.
    ///
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Бинардык үймөктөгү эң чоң нерсеге өзгөрүлмө шилтеме берет, же ал бош болсо, `None`.
    ///
    /// Note: Эгерде `PeekMut` мааниси чыгып кетсе, анда үймөктө карама-каршы келген абал болушу мүмкүн.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Убакыттын татаалдыгы
    ///
    /// Эгерде нерсе өзгөртүлгөн болсо, анда убакыттын татаалдыгы *O*(log(*n*)) болуп саналат, антпесе *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Эң чоң нерсени экилик үймөктөн алып салат жана кайра кайтарат, же бош болсо `None`.
    ///
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Убакыттын татаалдыгы
    ///
    /// *N* элементтерин камтыган үймөктө `pop` наркынын начардыгы *O*(log(*n*)) болуп саналат.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // КООПСУЗДУК: !self.is_empty() self.len()> 0 дегенди билдирет
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Бир нерсени экилик үймөккө түртөт.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Убакыттын татаалдыгы
    ///
    /// Күчөтүлгөн `push` наркы, түртүлүп жаткан элементтердин мүмкүн болушунча иреттелгендиги боюнча жана жетиштүү сандагы түртүүлөр боюнча орто эсеп менен *O*(1).
    ///
    /// Бул кандайдыр бир иреттелген үлгүдө болбогон элементтерди түртүүдө эң маанилүү чыгымдардын көрсөткүчү.
    ///
    /// Элементтер негизинен өсүү тартибине түртүлсө, убакыттын татаалдыгы начарлайт.
    /// Эң начар учурда, элементтер иргелип өскөн тартипте түртүлөт жана амортизацияланган чыгым *n* элементтерин камтыган үймөгө каршы *O*(log(*n*)) түзөт.
    ///
    /// `push` номерине *бир* чалуунун эң начар учуру *O*(*n*).Эң начар учур кубаттуулугу бүтүп, көлөмүн өзгөртүү керек болгондо пайда болот.
    /// Өлчөмдүн өлчөмүн өзгөртүү мурунку көрсөткүчтөрдө амортизацияланган.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // КООПСУЗДУК: Жаңы нерсени түрттүргөнүбүздөн улам, ал ушуну билдирет
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// `BinaryHeap` керектейт жана vector иреттелген (ascending) тартибинде кайтарат.
    ///
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // КООПСУЗДУК: `end` `self.len() - 1` ден 1ге чейин (экөө тең камтылган),
            //  демек, бул ар дайым жарактуу индекске жетүү үчүн.
            //  0 индексине (б.а. `ptr`) кирүү коопсуз, анткени
            //  1 <=аягы <self.len(), бул self.len()>=2 дегенди билдирет.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // КООПСУЗДУК: `end` `self.len() - 1` ден 1ге чейин (экөө тең камтылган), ошондуктан:
            //  0 <1 <=аягы <= self.len(), 1 <self.len() Бул 0 <аягы жана аягы <self.len() дегенди билдирет.
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Sift_up жана sift_down шаймандарын vector ичинен жылдырып (тешик артта калтырып), калгандары боюнча жылышуу жана алынып салынган элементти кайра vector ичине тешиктин акыркы жеринде жылдыруу үчүн кооптуу блокторду колдонушат.
    //
    // Муну көрсөтүү үчүн `Hole` түрү колдонулат жана panic да, анын көлөмүнүн аягында тешик толтурулгандыгын текшерип алыңыз.
    // Тешикти колдонуу эки эсе көп кыймылдарды камтыган свопторду колдонууга салыштырмалуу туруктуу коэффициентти төмөндөтөт.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Чакыруучу `pos < self.len()` деп кепилдик бериши керек.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // `pos` баасын чыгарып, тешик жаратыңыз.
        // КООПСУЗДУК: Чалуучу pos <self.len() деп кепилдик берет
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // КООПСУЗДУК: hole.pos()> баштоо>=0, бул hole.pos()> 0 дегенди билдирет
            //  ошондуктан hole.pos(), 1дин астын ача албайт.
            //  Бул ата-эне <hole.pos() деп кепилдик берет, андыктан ал жарактуу индекс жана ошондой эле!= hole.pos() болот.
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // КООПСУЗДУК: Жогорудагыдай эле
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// `pos` элементин алып, аны үймөккө жылдырыңыз, ал эми анын балдары чоңураак.
    ///
    ///
    /// # Safety
    ///
    /// Чакыруучу `pos < end <= self.len()` деп кепилдик бериши керек.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // КООПСУЗДУК: Чакыруучу pos <end <= self.len() деп кепилдик берет.
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Цикл инвариант: бала==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // эки баланын чоңдору менен салыштырыңыз КООПСУЗДУК: child <end, 1 <self.len() and child + 1 <end <= self.len(), ошондуктан алар жарактуу индекстер.
            //
            //  бала==2 *hole.pos() + 1!= hole.pos() жана бала + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: T *ZST болсо, 2* hole.pos() + 1 же 2 * hole.pos() + 2 ашып кетиши мүмкүн
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // эгерде биз буга чейин тартипте болсок, анда токто.
            // КООПСУЗДУК: бала азыр же эски бала, же эски бала + 1
            //  Экөө тең <self.len() жана!= hole.pos() экендигин буга чейин далилдедик
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // КООПСУЗДУК: жогорудагыдай эле.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // КООПСУЗДУК: &&кыска туташуу, бул дегенди билдирет
        //  экинчи шарт, буга чейин бала==аягы, 1 <self.len() экендиги чын.
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // КООПСУЗДУК: бала буга чейин эле жарактуу индекс экендиги далилденген
            //  бала==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Чакыруучу `pos < self.len()` деп кепилдик бериши керек.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // КООПСУЗДУК: пос <ленге кепилдик берилген жана
        //  len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// `pos` элементин алып, үймөктүн аягына чейин жылдырып, андан кийин өз ордуна чейин элеңиз.
    ///
    ///
    /// Note: Бул элемент чоң экендиги белгилүү болгондо тезирээк болот/түбүнө жакын болушу керек.
    ///
    /// # Safety
    ///
    /// Чакыруучу `pos < self.len()` деп кепилдик бериши керек.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // КООПСУЗДУК: Чалуучу pos <self.len() деп кепилдик берет.
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Цикл инвариант: бала==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // КООПСУЗДУК: бала <аягы, 1 <self.len() жана
            //  child + 1 <end <= self.len(), ошондуктан алар жарактуу индекстер.
            //  бала==2 *hole.pos() + 1!= hole.pos() жана бала + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: T *ZST болсо, 2* hole.pos() + 1 же 2 * hole.pos() + 2 ашып кетиши мүмкүн
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // КООПСУЗДУК: Жогорудагыдай эле
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // КООПСУЗДУК: бала==аягы, 1 <self.len(), андыктан жарактуу индекс
            //  жана бала==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // КООПСУЗДУК: pos тешиктеги абал жана буга чейин далилденген
        //  жарактуу индекс.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // КООПСУЗДУК: n self.len()/2ден башталып, 0го төмөндөйт.
            //  ! (N <self.len())-бул self.len() ==0, бирок цикл шарты менен жокко чыгарылган бирден-бир учур.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// `other` тин бардык элементтерин `self` ке жылдырып, `other` ти бош калтырат.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` эң начар учурда O(len1 + len2) операцияларын жана болжол менен 2 *(len1 + len2) салыштырууларды, ал эми `extend` O(len2* log(len1)) операцияларын жана начар абалда 1 *len2* log_2(len1) салыштыруусун, len1>= len2 деп эсептешет.
        // Чоңураак үймөктөр үчүн, кроссовер чекити мындай ой жүгүртүүгө ылайык келбейт жана эмпирикалык жол менен аныкталат.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Үймөк тартибинде элементтерди чыгарган кайталоочу бөлүктү кайтарат.
    /// Алынган элементтер баштапкы үймөктөн алынып салынат.
    /// Калган элементтер үйүлгөн тартипте төмөндөйт.
    ///
    /// Note:
    /// * `.drain_sorted()` *O*(*n*\*log(* n*)); `.drain()` ке караганда бир кыйла жайыраак.
    ///   Көпчүлүк учурларда экинчисин колдонуу керек.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // үйүлгөн тартипте бардык элементтерди алып салат
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Предикат менен көрсөтүлгөн элементтерди гана сактайт.
    ///
    /// Башка сөз менен айтканда, `e` `false` кайтарып бере турган `e` элементтеринин бардыгын алып салыңыз.
    /// Элементтер иргелбеген (жана такталбаган) тартипте.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // жуп сандарды гана сактаңыз
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Негизги vector деги бардык баалуулуктарга, каалаган тартипте барган итераторду кайтарып берет.
    ///
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // 1, 2, 3, 4тү каалагандай тартипте басып чыгарыңыз
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Үймөк тартибинде элементтерди чыгарган кайталоочу бөлүктү кайтарат.
    /// Бул ыкма баштапкы үймөктү жалмайт.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Бинардык үймөктөгү эң чоң нерсени же ал бош болсо `None` берет.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Убакыттын татаалдыгы
    ///
    /// Баасы эң начар учурда *O*(1) болот.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Бинардык үймөктүн ээлей турган элементтеринин санын бөлүштүрбөстөн берет.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Берилген `BinaryHeap` ге `additional` элементтерин киргизүү үчүн минималдуу сыйымдуулукту сактайт.
    /// Кубаттуулугу буга чейин жетиштүү болсо, эч нерсе кылбайт.
    ///
    /// Белгилей кетүүчү нерсе, бөлүүчү коллекцияга ал сураганга караганда көбүрөөк орун бере алат.
    /// Ошондуктан кубаттуулукту минималдуу деп айтууга болбойт.
    /// Эгерде future киргизүүлөрү күтүлсө, [`reserve`] артыкчылыгы.
    ///
    /// # Panics
    ///
    /// Жаңы кубаттуулук `usize` ашып кетсе, Panics.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// `BinaryHeap` ичине киргизиле турган жок дегенде `additional` элементтери үчүн резервдик кубаттуулук.
    /// Коллекция тез-тез бөлүштүрүүдөн сактануу үчүн көбүрөөк орун камдашы мүмкүн.
    ///
    /// # Panics
    ///
    /// Жаңы кубаттуулук `usize` ашып кетсе, Panics.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Мүмкүн болушунча кошумча кубаттуулукту жокко чыгарат.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Төмөнкү чек менен кубаттуулукту жокко чыгарат.
    ///
    /// Кубаттуулугу, жок эле дегенде, узундугу жана берилген наркы сыяктуу эле чоң бойдон калат.
    ///
    ///
    /// Эгер учурдагы кубаттуулук төмөнкү чектен аз болсо, анда бул жокко эсе.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// `BinaryHeap` сарптайт жана негизделген vector ыктыярдуу тартипте кайтарат.
    ///
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Кандайдыр бир тартипте басып чыгарат
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Бинардык үймөнүн узундугун кайтарып берет.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Бинардык үймөнүн бош экендигин текшерет.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Бинардык үймөктү тазалап, алынып салынган элементтердин үстүнө кайталауучуну кайтарып берет.
    ///
    /// Элементтер каалагандай тартипте алынып салынат.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Бардык нерселерди экилик үймөдөн таштайт.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Тешик тилимдеги тешикти, башкача айтканда, жарактуу мааниси жок индексти билдирет (анткени ал көчүрүлгөн же копияланган).
///
/// Тамчы менен `Hole` тешиктин ордун алгач алынып салынган мааниге толтуруп, тилимди калыбына келтирет.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// `pos` индексинде жаңы `Hole` түзүңүз.
    ///
    /// Кооптуу, анткени pos маалымат тилкесинде болушу керек.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // КООПСУЗ: pos кесимдин ичинде болушу керек
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Четтетилген элементке шилтеме берет.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// `index` элементине шилтеме берет.
    ///
    /// Кооптуу, анткени индекс маалыматтардын тилкесинде болушу керек жана posга барабар эмес.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Тешикти жаңы жерге жылдырыңыз
    ///
    /// Кооптуу, анткени индекс маалыматтардын тилкесинде болушу керек жана posга барабар эмес.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // тешикти дагы толтур
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// `BinaryHeap` элементтеринин үстүнөн кайталоочу.
///
/// Бул `struct` [`BinaryHeap::iter()`] тарабынан түзүлгөн.
/// Көбүрөөк маалымат алуу үчүн анын документтерин караңыз.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]` пайдасына алып салуу
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// `BinaryHeap` элементтеринин үстүнөн итератор.
///
/// Бул `struct` [`BinaryHeap::into_iter()`] тарабынан түзүлгөн (`IntoIterator` trait тарабынан берилген).
/// Көбүрөөк маалымат алуу үчүн анын документтерин караңыз.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// `BinaryHeap` элементтеринин үстүнөн кургатуучу итератор.
///
/// Бул `struct` [`BinaryHeap::drain()`] тарабынан түзүлгөн.
/// Көбүрөөк маалымат алуу үчүн анын документтерин караңыз.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// `BinaryHeap` элементтеринин үстүнөн кургатуучу итератор.
///
/// Бул `struct` [`BinaryHeap::drain_sorted()`] тарабынан түзүлгөн.
/// Көбүрөөк маалымат алуу үчүн анын документтерин караңыз.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Үймөк элементтерин үймөк тартибинде жок кылат.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// `Vec<T>` ти `BinaryHeap<T>` ке айландырат.
    ///
    /// Бул конверсия өз ордунда жүрөт жана *O*(*n*) убакыт татаалдыгына ээ.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// `BinaryHeap<T>` ти `Vec<T>` ке айландырат.
    ///
    /// Бул конверсия эч кандай маалымат кыймылын же бөлүштүрүүнү талап кылбайт жана убакыттын татаалдыгына ээ.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Көп керектөөчү кайталоону жаратат, башкача айтканда, ар бир маанини экилик үймөдөн каалагандай тартипте чыгарат.
    /// Экинчи үймөктү ушул чакыргандан кийин колдонууга болбойт.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // 1, 2, 3, 4тү каалагандай тартипте басып чыгарыңыз
    /// for x in heap.into_iter() {
    ///     // x &i32 эмес, i32 түрүнө ээ
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}