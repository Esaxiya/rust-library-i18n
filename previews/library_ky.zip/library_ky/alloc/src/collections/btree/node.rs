// Бул идеалдын артынан ишке ашыруу аракети
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Rust чындыгында көз каранды түрлөрү жана полиморфтук рекурсиясы болбогондуктан, биз көптөгөн кооптуу жагдайларды жасайбыз.
//

// Бул модулдун негизги максаты-даракты жалпы (эгер кызыктай формада) контейнер катары карап, B-Tree инварианттарынын көпчүлүгү менен иштешүүдөн алыс болуп, татаалдыктан алыс болуу.
//
// Ушундайча, бул модулда жазуулар иреттелгенби, кайсы түйүндөр жетишсиз болушу мүмкүн, ал тургай underfull деген эмнени билдирет.Бирок, биз бир нече инварианттарга таянабыз:
//
// - Дарактар бирдиктүү depth/height болуш керек.Бул берилген түйүндөн жалбыракка чейинки ар бир жолдун узундугу бирдей экендигин билдирет.
// - Узундуктагы `n` түйүнүндө `n` баскычтары, `n` маанилери жана `n + 1` четтери бар.
//   Бул бош түйүндүн да жок дегенде бир edge бар экендигин билдирет.
//   Жалбырак түйүнү үчүн "having an edge" биз түйүндөгү абалды аныктай алабыз дегенди билдирет, анткени жалбырактын четтери бош жана эч кандай маалыматтарды көрсөтпөө керек.
// Ички түйүндө edge абалды аныктайт жана бала түйүнүнө көрсөткүчтү камтыйт.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Жалбырак түйүндөрүнүн түпкү көрүнүшү жана ички түйүндөрдүн бир бөлүгү.
struct LeafNode<K, V> {
    /// Биз `K` жана `V` те ковариант болгубуз келет.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Бул түйүндүн индекси энелик түйүндүн `edges` массивине кирет.
    /// `*node.parent.edges[node.parent_idx]` `node` менен бирдей болушу керек.
    /// Бул `parent` нөл болбогон учурда гана башталат деп кепилденет.
    parent_idx: MaybeUninit<u16>,

    /// Бул түйүндүн ачкычтарынын жана баалуулуктарынын саны сакталат.
    len: u16,

    /// Түйүндүн чыныгы маалыматтарын сактаган массивдер.
    /// Ар бир массивдин биринчи `len` элементтери гана инициалдаштырылган жана жарактуу.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Жаңы `LeafNode` өз ордунда башталат.
    unsafe fn init(this: *mut Self) {
        // Жалпы саясат катары, эгер мүмкүн болсо, талааларды башталбай калтырып коёбуз, анткени бул Валгриндде бир аз тезирээк жана байкоо жеңилирээк болушу керек.
        //
        unsafe {
            // parent_idx, ачкычтар жана валалар бардыгы Bəlkay Uninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Жаңы кутуча `LeafNode` түзөт.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Ички түйүндөрдүн түпкү чагылдырылышы."LeafNode" сыяктуу эле, башталбаган ачкычтарды жана баалуулуктарды түшүрбөө үчүн "BoxedNode" артында жашыруу керек.
/// `InternalNode` тин каалаган көрсөткүчү түздөн-түз түйүндүн негизги `LeafNode` бөлүгүнө көрсөткүчкө ыргытылышы мүмкүн, бул коддун жалбыракта жана ички түйүндөрдө жалпысынан иш алып баруусуна мүмкүндүк берет, көрсөткүч экөөнүн кайсынысын көрсөтүп жаткандыгын текшербестен.
///
/// Бул касиет `repr(C)` колдонуу менен иштетилген.
///
#[repr(C)]
// gdb_providers.py интроспекция үчүн ушул типтеги аталышты колдонот.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Бул түйүндүн балдарына көрсөткүчтөр.
    /// `len + 1` булар инициалдаштырылган жана жарактуу деп эсептелет, башкача айтканда, дарак `Dying` типтеги карыздар аркылуу кармалып турса, айрымдары илинип турат.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Жаңы кутуча `InternalNode` түзөт.
    ///
    /// # Safety
    /// Ички түйүндөрдүн инварианты-алардын жок дегенде бир инициалдаштырылган жана жарактуу edge болушу.
    /// Бул функция мындай edge орнотпойт.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Биз бир гана маалыматтарды баштоо керек;четтери мүмкүн Белгисиз.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Түйүнгө башкарылуучу, нөл эмес көрсөткүч.Бул `LeafNode<K, V>` же `InternalNode<K, V>` таандык көрсөткүч.
///
/// Бирок, `BoxedNode` түйүндөрдүн эки түрүнүн кайсынысы камтылгандыгы жөнүндө маалыматты камтыбайт, жана жарым-жартылай ушул маалыматтын жоктугунан улам, өзүнчө тип эмес жана эч кандай деструктору жок.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Менчик дарактын тамыр түйүнү.
///
/// Мында деструктор жок экендигин жана аны кол менен тазалоо керектигин эске алыңыз.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Баштапкы бош тамыр тамыры менен жаңы менчик даракты кайтарып берет.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` нөл болбошу керек.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Өзгөртүлгөн таандык тамыр түйүнүн карызга алат.
    /// `reborrow_mut` тен айырмаланып, бул коопсуз, анткени кайтарып берүү маанисин тамырды жок кылуу үчүн колдонууга болбойт жана даракка карата башка шилтемелер болушу мүмкүн эмес.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Менчик тамыр түйүнүн бир аз өзгөрүлмө түрдө карызга алат.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Кайра калыбына келтирилбестен, өтүүгө уруксат берүүчү жана кыйратуучу ыкмаларды сунуш кылган шилтеме.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Мурунку тамыр түйүнүн көрсөтүп бир edge менен жаңы ички түйүндү кошуп, ошол жаңы түйүндү тамыр түйүнүнө жасап, аны кайтарыңыз.
    /// Бул бийиктикти 1ге көбөйтөт жана `pop_internal_level` ке карама-каршы келет.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, башка нерсе, биз азыр ички дүйнөбүздү унутуп калдык:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Жаңы тамыр түйүнү катары биринчи баласын колдонуп, ички тамыр түйүнүн алып салат.
    /// Тамыр түйүнүндө бир гана бала болгондо гана аталышы керек болгондуктан, баскычтардын, баалуулуктардын жана башка балдардын эч биринде тазалоо жүргүзүлбөйт.
    ///
    /// Бул бийиктикти 1ге төмөндөтөт жана `push_internal_level` ке тескери.
    ///
    /// `Root` объектисине эксклюзивдүү мүмкүнчүлүктү талап кылат, бирок тамыр түйүнүнө эмес;
    /// ал башка туткаларды же тамыр түйүнүнө шилтемелерди жараксыз кылбайт.
    ///
    /// Эгерде ички деңгээл жок болсо, башкача айтканда, тамыр түйүнү жалбырак болсо, Panics.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // КООПСУЗДУК: биз ички деп ырастады.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // КООПСУЗДУК: биз `self` карызын гана алганбыз жана анын карыз түрү эксклюзивдүү.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // КООПСУЗДУК: биринчи edge ар дайым башталат.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` `K` жана `V` болгондо да, `BorrowType` `Mut` болгондо дагы, ковариант болуп саналат.
// Бул техникалык жактан туура эмес, бирок `NodeRef` тин ички колдонулушунан улам эч кандай кооптуулукка алып келбейт, анткени биз `K` жана `V` үстүнөн толук бойдон калабыз.
//
// Бирок, ачык типтеги `NodeRef` оролгон сайын, анын дисперсиясынын туура экендигине ынаныңыз.
//
/// Түйүнгө шилтеме.
///
/// Бул түрдө анын иштешин көзөмөлдөөчү бир катар параметрлер бар:
/// - `BorrowType`: Насыянын түрүн сүрөттөгөн жана өмүр бою ташыган манекен түрү.
///    - Бул `Immut<'a>` болгондо, `NodeRef` болжол менен `&'a Node` сыяктуу иштейт.
///    - Бул `ValMut<'a>` болгондо, `NodeRef` ачкычтарга жана дарактардын түзүлүшүнө карата болжол менен `&'a Node` сыяктуу иштейт, бирок ошондой эле дарактын ичиндеги өзгөрүлмө шилтемелердин чогуу жашашына мүмкүнчүлүк берет.
///    - Бул `Mut<'a>` болгондо, `NodeRef` болжол менен `&'a mut Node` сыяктуу иштейт, бирок киргизүү ыкмалары өзгөрүлмө көрсөткүчтүн мааниге ээ болушуна шарт түзөт.
///    - Бул `Owned` болгондо, `NodeRef` болжол менен `Box<Node>` сыяктуу иштейт, бирок деструктору жок жана аны кол менен тазалоо керек.
///    - Бул `Dying` болгондо, `NodeRef` болжол менен `Box<Node>` сыяктуу иштейт, бирок даракты аз-аздан жок кылуунун жолдору бар, ал эми кадимки ыкмалар, кооптуу деп аталып калбаса, UBди туура эмес чакырып алса болот.
///
///   Кандайдыр бир `NodeRef` дарактын ичинде жылып жүрүүгө мүмкүндүк бергендиктен, `BorrowType` түйүндүн өзүнө эле эмес, бүт даракка колдонулат.
/// - `K` жана `V`: Бул түйүндөрдө сакталган ачкычтардын жана баалуулуктардын түрлөрү.
/// - `Type`: Бул `Leaf`, `Internal` же `LeafOrInternal` болушу мүмкүн.
/// Бул `Leaf` болгондо, `NodeRef` жалбырак түйүнүн, ал `Internal` болгондо `NodeRef` ички түйүндү көрсөтөт, ал эми `LeafOrInternal` болгондо, `NodeRef` түйүндүн эки түрүн көрсөтүшү мүмкүн.
///   `Type` `NodeRef` тышында колдонулганда `NodeType` деп аталат.
///
/// `BorrowType` жана `NodeType` экөө тең статикалык типтеги коопсуздукту колдонуу үчүн кандай ыкмаларды колдонобуз.Мындай чектөөлөрдү колдонууда чектөөлөр бар:
/// - Ар бир типтин параметрлери үчүн, биз бир гана ыкманы жалпы түрүндө же белгилүү бир түрү үчүн аныктай алабыз.
/// Мисалы, биз `into_kv` сыяктуу ыкманы бардык `BorrowType` үчүн, же өмүр бою өткөргөн бардык түрлөрү үчүн бир жолу аныктай албайбыз, анткени `&'a` шилтемелерин кайтарып берүүнү каалайбыз.
///   Демек, биз аны эң аз кубаттуу `Immut<'a>` түрү үчүн гана аныктайбыз.
/// - Биз `Mut<'a>` дан `Immut<'a>` ге чейин ачык мажбурлай албайбыз.
///   Демек, `into_kv` сыяктуу ыкмага жетүү үчүн биз `reborrow` ти күчтүү `NodeRef` ке так чакырышыбыз керек.
///
/// `NodeRef` теги кандайдыр бир шилтеме берген бардык ыкмалар:
/// - `self` мааниси боюнча алып, `BorrowType` көтөргөн өмүрдү кайтарыңыз.
///   Кээде, мындай ыкманы колдонуу үчүн, биз `reborrow_mut` чалуу керек.
/// - `self` шилтемеси менен алып, (implicitly) `BorrowType` көтөргөн өмүрдүн ордуна, ошол маалымдаманын өмүрүн кайтарып берет.
/// Ошентип, насыя текшергичи `NodeRef` кайтарылып берилген шилтеме колдонулганга чейин, карыз болуп кала тургандыгына кепилдик берет.
///   Кыстарууну колдогон ыкмалар ушул эрежени чийки көрсөткүчтү, башкача айтканда, шилтемени өмүр бою кайтарып берүү жолу менен ийилет.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Түйүн менен жалбырактардын деңгээли өзүнчө турган деңгээлдердин саны, бул `Type` тарабынан толугу менен сүрөттөлбөй турган жана түйүн өзү сактай албаган түйүндүн туруктуусу.
    /// Бизге бир гана тамыр түйүнүнүн бийиктигин сактап, андан башка ар бир түйүндүн бийиктигин алуу керек.
    /// `Type` `Leaf` болсо нөл, `Type` `Internal` болсо нөл эмес болушу керек.
    ///
    ///
    height: usize,
    /// Жалбырактын же ички түйүндүн көрсөткүчү.
    /// `InternalNode` аныктамасы көрсөткүч эки жагынан тең жарактуу экендигин кепилдейт.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// `NodeRef::parent` катары таңгакталган түйүн маалымдамасын таңгактан чыгарыңыз.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Ички түйүндүн маалыматтарын ачыкка чыгарат.
    ///
    /// Ушул түйүнгө башка шилтемелерди жараксыз кылбоо үчүн чийки ptr кайтарат.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // КООПСУЗДУК: статикалык түйүндүн түрү `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Ички түйүндүн маалыматтарына өзгөчө мүмкүнчүлүктү алат.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Түйүндүн узундугун табат.Бул ачкычтардын же маанилердин саны.
    /// Четтеринин саны `len() + 1`.
    /// Коопсуз экендигине карабастан, ушул функцияны чакыруу кооптуу код жараткан өзгөрүлмө шилтемелерди жараксыз деп табуунун терс таасирин тийгизиши мүмкүн.
    ///
    pub fn len(&self) -> usize {
        // Эң башкысы, биз `len` талаасын ушул жерден гана көрө алабыз.
        // Эгер BorrowType marker::ValMut болсо, анда биз жокко чыгарбашыбыз керек болгон баалуулуктарга карата өзгөрүлмө шилтемелер болушу мүмкүн.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Түйүн менен жалбырактар бири-биринен бөлүнгөн деңгээлдердин санын кайтарат.
    /// Нөлдүн бийиктиги түйүндүн өзү жалбырак экендигин билдирет.
    /// Эгер тамыры үстүңкү дарактарды элестетсеңиз, түйүн кайсы бийиктикте пайда болгонун билдирет.
    /// Эгерде сиз үстүнө жалбырактары бар бактарды элестетсеңиз, анда дарак түйүндүн үстүнөн канчалык бийикке созулгандыгын билдирет.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Убактылуу ошол эле түйүнгө башка, өзгөрүлбөс шилтемени алып чыгат.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Ар кандай жалбырактын же ички түйүндүн жалбырак бөлүгүн ачыкка чыгарат.
    ///
    /// Ушул түйүнгө башка шилтемелерди жараксыз кылбоо үчүн чийки ptr кайтарат.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Түйүн жок дегенде LeafNode бөлүгү үчүн жарактуу болушу керек.
        // Бул NodeRef түрүндөгү шилтеме эмес, анткени биз уникалдуу же жалпы болушу керектигин билбейбиз.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Учурдагы түйүндүн ата-энесин табат.
    /// Эгерде учурдагы түйүндүн ата-энеси чындыгында `Ok(handle)` болсо, `handle` учурдагы түйүндү көрсөткөн ата-эненин edge көрсөтөт.
    ///
    /// Эгерде учурдагы түйүндүн ата-энеси жок болсо, баштапкы `NodeRef` кайтарып берип, `Err(self)` кайтарат.
    ///
    /// Методдун аталышы сизге дарактардын үстүнкү тамыры менен сүрөттөлөт.
    ///
    /// `edge.descend().ascend().unwrap()` жана `node.ascend().unwrap().descend()` экөө тең, ийгиликке жетишкенден кийин, эч нерсе кылбашы керек.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Түйүндөргө чийки көрсөткүчтөрдү колдонушубуз керек, анткени BorrowType marker::ValMut болсо, биз жараксыз кылбашыбыз керек болгон баалуулуктарга өзгөрүлмө шилтемелер болушу мүмкүн.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// `self` бош болбошу керек экендигин эске алыңыз.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// `self` бош болбошу керек экендигин эске алыңыз.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Кандайдыр бир жалбырактын же ички түйүндүн жалбырак бөлүгүн өзгөрбөс дарактын ичинде ачыкка чыгарат.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // КООПСУЗДУК: бул даракка `Immut` катары алынган өзгөрүлмө шилтемелер болушу мүмкүн эмес.
        unsafe { &*ptr }
    }

    /// Түйүндө сакталган ачкычтарга көрүнүштү карызга алат.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// `ascend` окшош, түйүндүн эне түйүнүнө шилтеме алат, бирок процесстеги учурдагы түйүндү бөлүштүрөт.
    /// Бул кооптуу, анткени бөлүнгөнүнө карабастан, учурдагы түйүнгө кирүүгө болот.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Бул түйүн `Leaf` деп статикалык маалыматты компиляторго кооптуу деп ырастайт.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Бул түйүн `Internal` деп статикалык маалыматты компиляторго кооптуу деп ырастайт.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Убактылуу ошол эле түйүнгө карата башка, өзгөрүлмө шилтеме чыгарат.Этият болуңуз, анткени бул ыкма өтө кооптуу болгондуктан, дароо эле кооптуу болуп көрүнбөшү мүмкүн.
    ///
    /// Өзгөрүлө турган көрсөткүчтөр бактын айланасында каалаган жеринде жүрө алгандыктан, кайтарылган көрсөткүч менен баштапкы көрсөткүчтү илинип, чегинен чыгып же жараксыз абалга келтирүү үчүн колдонсо болот.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) `NodeRef` ке дагы бир түрдөгү параметрди кошууну карап көрүңүз, бул кооптуулукка жол бербей, кайрадан төрөлгөн көрсөткүчтөрдө навигация ыкмаларын колдонууну чектейт.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Ар кандай жалбырактын же ички түйүндүн жалбырак бөлүгүнө эксклюзивдүү кирүү мүмкүнчүлүгүн алат.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // КООПСУЗДУК: биздин бүт түйүнгө эксклюзивдүү мүмкүнчүлүгүбүз бар.
        unsafe { &mut *ptr }
    }

    /// Бардык жалбырактын же ички түйүндүн жалбырак бөлүгүнө эксклюзивдүү жеткиликтүүлүктү сунуштайт.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // КООПСУЗДУК: биздин бүт түйүнгө эксклюзивдүү мүмкүнчүлүгүбүз бар.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Ачкыч сактоочу жайдын элементине эксклюзивдүү кирүү мүмкүнчүлүгүн алат.
    ///
    /// # Safety
    /// `index` 0. .МҮМКҮНЧҮЛҮКТҮН чегинде
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // КООПСУЗДУК: чалган адам өзүн-өзү издөө ыкмаларын колдоно албайт
        // насыянын өмүр бою уникалдуу мүмкүнчүлүгү бар болгондуктан, негизги кесинди шилтемеси ташталганга чейин.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Түйүндүн маанисин сактоочу жайдын элементине же тилимине өзгөчө жеткиликтүүлүктү карызга алат.
    ///
    /// # Safety
    /// `index` 0. .МҮМКҮНЧҮЛҮКТҮН чегинде
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // КООПСУЗДУК: чалган адам өзүн-өзү издөө ыкмаларын колдоно албайт
        // насыя боюнча өмүр бою уникалдуу мүмкүнчүлүккө ээ болгондуктан, нарк тилимине шилтеме берилгенге чейин.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// edge камтылганы үчүн түйүндүн сактагыч бөлүгүнүн элементине же тилимине өзгөчө мүмкүнчүлүк алат.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY + 1 чегинде
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // КООПСУЗДУК: чалган адам өзүн-өзү издөө ыкмаларын колдоно албайт
        // edge тилкесине шилтеме ташталганга чейин, анткени бизде карыздын өмүр бою уникалдуу мүмкүнчүлүгү бар.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Түйүндө `idx` баштапкы элементтер бар.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Башка элементтерге, тактап айтканда, мурунку кайталоолордо чалган адамга кайтарылып берилген нерселерге шилтеме бербөө үчүн, биз өзүбүздү кызыктырган бир гана элементке шилтеме түзөбүз.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Rust #74679 чыгарылышынан улам, биз масштабдагы массив көрсөткүчтөрүн мажбурлашыбыз керек.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Түйүндүн узундугуна эксклюзивдүү мүмкүнчүлүктү карызга алат.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Түйүндүн башка шилтемелерин жараксыз кылбай, анын edge энесине шилтемени орнотот.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Тамырдын ата-энеси edge менен байланышын тазалайт.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Ачкыч-маани жупун түйүндүн аягына кошот.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// `range` тарабынан кайтарылган ар бир нерсе түйүн үчүн жарактуу edge индекси болуп саналат.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Ачкыч-маани жупун жана edge ди ушул түгөйдүн оң жагына, түйүндүн аягына чейин кошот.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Түйүндүн `Internal` же `Leaf` түйүнү экендигин текшерет.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Түйүндүн ичиндеги белгилүү бир ачкыч-жупка же edge шилтемеси.
/// `Node` параметри `NodeRef` болушу керек, ал эми `Type` `KV` (ачкыч мааниси жупундагы тутканы билдирет) же `Edge` (edge туткасын белгилөө) болушу мүмкүн.
///
/// `Leaf` түйүндөрүндө да `Edge` туткалары болушу мүмкүн экендигин эске алыңыз.
/// Бала түйүнүнө көрсөткүчтү көрсөтүүнүн ордуна, алар балдар көрсөткүчтөрү ачкыч-мааниси түгөйлөрүнүн ортосунда кете турган боштукту чагылдырат.
/// Мисалы, узундугу 2 болгон түйүндө бирөө түйүндүн сол жагында, экөө эки түгөйдүн ортосунда, экинчиси түйүндүн оң жагында 3 edge жайгашуусу мүмкүн.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Бизге `#[derive(Clone)]` толук жалпылыгынын кереги жок, анткени `Node` бир гана жолу "Clone" болот, ал өзгөрүлбөс маалымдама болгондо, демек `Copy` болот.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Бул тутум көрсөткөн edge же ачкыч-маани жупун камтыган түйүндү алат.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Бул туткандын түйүндөгү абалын кайтарып берет.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// `node` те ачкыч-баалуулуктар жупунун жаңы туткасын түзөт.
    /// Кооптуу, анткени чалган адам `idx < node.len()` экендигин камсыздашы керек.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// PartialEq коомдук ишке ашырылышы мүмкүн, бирок ушул модулда гана колдонулат.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Убактылуу ошол эле жерге башка, өзгөрүлбөс туткасын алып чыгат.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Биз Handle::new_kv же Handle::new_edge колдоно албайбыз, анткени биздин түрүбүздү билбейбиз
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Компиляторго туткундун түйүнү `Leaf` экендиги жөнүндө статикалык маалыматты кооптуу деп ырастайт.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Ошол эле жердеги башка, өзгөрүлмө туткасын убактылуу алып чыгат.
    /// Сак болуңуз, анткени бул ыкма өтө кооптуу болгондуктан, дароо эле кооптуу болуп көрүнбөшү мүмкүн.
    ///
    ///
    /// Көбүрөөк маалымат алуу үчүн, `NodeRef::reborrow_mut` караңыз.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Биз Handle::new_kv же Handle::new_edge колдоно албайбыз, анткени биздин түрүбүздү билбейбиз
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// `node` те edge үчүн жаңы туткасын түзөт.
    /// Кооптуу, анткени чалган адам `idx <= node.len()` экендигин камсыздашы керек.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Кубаттуулукка толгон түйүнгө киргизгибиз келген edge индексин эске алганда, бөлүнгөн чекиттин KV индексин эсептейт жана кыстарууну кайда жасайбыз.
///
/// Бөлүнгөн чекиттин максаты анын ачкычы жана мааниси ата-эне түйүнүнө жетиши керек;
/// бөлүнгөн чекиттин сол жагындагы ачкычтар, баалуулуктар жана четтер сол балага айланат;
/// бөлүнгөн чекиттин оң жагындагы ачкычтар, маанилер жана четтер туура бала болуп калат.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust #74834 чыгарылышы ушул симметриялык эрежелерди түшүндүрүүгө аракет кылат.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ушул edge дин оң жана сол жагына ачкыч-мааниси түгөйлөрүнүн арасына жаңы ачкыч-маани жупун киргизет.
    /// Бул ыкма түйүндө жаңы түгөйгө ылайыктуу орун жетиштүү деп болжолдойт.
    ///
    /// Кайтарылган көрсөткүч киргизилген мааниге көрсөтөт.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ушул edge дин оң жана сол жагына ачкыч-мааниси түгөйлөрүнүн арасына жаңы ачкыч-маани жупун киргизет.
    /// Эгерде орун жетишсиз болсо, бул ыкма түйүндү бөлөт.
    ///
    /// Кайтарылган көрсөткүч киргизилген мааниге көрсөтөт.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Бул edge шилтеме берген баланын түйүнүндөгү ата-эненин көрсөткүчүн жана индексин оңдойт.
    /// Бул четтердин ирети өзгөргөндө пайдалуу,
    fn correct_parent_link(self) {
        // Түйүндүн башка шилтемелерин жараксыз кылбай, арткы көрсөткүчтү түзүңүз.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Ушул edge менен ушул edge дин оң жагындагы ачкыч-мааниси түгөйүнүн ортосуна ошол жаңы түгөйдүн оң жагына кете турган жаңы ачкыч-жупту жана edge киргизет.
    /// Бул ыкма түйүндө жаңы түгөйгө ылайыктуу орун жетиштүү деп болжолдойт.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Ушул edge менен ушул edge дин оң жагындагы ачкыч-мааниси түгөйүнүн ортосуна ошол жаңы түгөйдүн оң жагына кете турган жаңы ачкыч-жупту жана edge киргизет.
    /// Эгерде орун жетишсиз болсо, бул ыкма түйүндү бөлөт.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ушул edge дин оң жана сол жагына ачкыч-мааниси түгөйлөрүнүн арасына жаңы ачкыч-маани жупун киргизет.
    /// Эгер бул орун жетишсиз болсо, анда бул ыкма түйүндү бөлүп, бөлүнгөн бөлүктү түпкү түйүнгө рекурсивдүү түрдө, тамыр жеткенге чейин киргизүүгө аракет кылат.
    ///
    ///
    /// Эгер кайтарылган жыйынтык `Fit` болсо, анын туткасынын түйүнү ушул edge түйүнү же атасы болушу мүмкүн.
    /// Эгер кайтарылган жыйынтык `Split` болсо, `left` талаасы тамыр түйүнү болот.
    /// Кайтарылган көрсөткүч киргизилген мааниге көрсөтөт.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Ушул edge көрсөткөн түйүндү табат.
    ///
    /// Методдун аталышы сизге дарактардын үстүнкү тамыры менен сүрөттөлөт.
    ///
    /// `edge.descend().ascend().unwrap()` жана `node.ascend().unwrap().descend()` экөө тең, ийгиликке жетишкенден кийин, эч нерсе кылбашы керек.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Түйүндөргө чийки көрсөткүчтөрдү колдонушубуз керек, анткени BorrowType marker::ValMut болсо, биз жараксыз кылбашыбыз керек болгон баалуулуктарга өзгөрүлмө шилтемелер болушу мүмкүн.
        // Бийиктик талаасына кирүүдө эч кандай кооптонуу жок, анткени ал маани көчүрүлдү.
        // Сак болгула, түйүн көрсөткүчү ажыратылгандан кийин, биз чектердеги массивге шилтеме менен киребиз (Rust чыгарылышы #73987) жана массивге же анын ичиндеги башка шилтемелерди жараксыз деп табабыз.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Биз өзүнчө ачкыч жана баалуулук ыкмаларын атай албайбыз, анткени экинчисин чакырганда биринчиси кайтарылган шилтеме жараксыз болот.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// KV туткасы билдирген ачкычты жана маанини алмаштырыңыз.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Жалбырактар жөнүндө кам көрүү менен, белгилүү бир `NodeType` үчүн `split` программасын ишке ашырууга жардам берет.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Негизги түйүндү үч бөлүккө бөлөт:
    ///
    /// - Түйүн ушул туткадан сол жагындагы ачкыч-маани жуптарын гана камтышы үчүн кесилген.
    /// - Бул тутка көрсөткөн ачкыч жана маани алынып салынат.
    /// - Ушул туткадан оң жактагы ачкыч-маани жуптарынын бардыгы жаңы бөлүнгөн түйүнгө киргизилген.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Ушул туткасы көрсөтүлгөн ачкыч-мааниси түгөйүн алып салат жана ачкыч-мааниси түгөйү кулаган edge менен кошо кайтарат.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Негизги түйүндү үч бөлүккө бөлөт:
    ///
    /// - Түйүн ушул туткадан сол жактагы гана четтерди жана ачкыч-маани жуптарын камтыгандай кылып кесилген.
    /// - Бул тутка көрсөткөн ачкыч жана маани алынып салынат.
    /// - Ушул туткадан оң жактагы бардык кырлар жана ачкыч-маани жуптары жаңы бөлүнгөн түйүнгө киргизилген.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Ички ачкыч-баалуулук түгөйүнүн айланасында баланстоо операциясын баалоо жана жүргүзүү үчүн сессияны билдирет.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Бала кезиндеги түйүндү камтыган тең салмактуулук контекстин тандайт, демек, ата-эне түйүнүнө дароо солго же оңго карай КВ ортосунда.
    /// Ата-энеси жок болсо, `Err` берет.
    /// Эгер ата-эне бош болсо Panics.
    ///
    /// Эгерде берилген түйүн кандайдыр бир деңгээлде толук эмес болсо, анда оптималдуу болуш үчүн, сол жагын артык көрөт, анткени бул жерде анын бир тууганына караганда жана анын бир тууганына караганда азыраак элементтери бар экендигин билдирет.
    /// Мындай учурда, сол жактагы бир тууган менен биригүү тезирээк болот, анткени биз түйүндүн N элементтерин оңго жылдырбай, алдыдагы N элементтерден көп жылдыруунун ордуна гана жылдырышыбыз керек.
    /// Сол бир туугандан уурдоо, адатта, тезирээк болот, анткени биз бир эле элементтин жок дегенде N элементтерин солго жылдыруунун ордуна, N түйүнүн оңго жылдырышыбыз керек.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Биригүү мүмкүнбү, башкача айтканда, борбордук КВны жанаша жайгашкан эки бала түйүнү менен айкалыштырууга жетиштүү орун барбы же жокпу, кайтып келет.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Биригүүнү жүзөгө ашырат жана жабууну эмне чечип берерин чечет.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // КООПСУЗДУК: бириктирилген түйүндөрдүн бийиктиги бийиктиктен ылдый
                // ушул edge түйүнүнүн, ошентип нөлдөн жогору болгондуктан, алар ички.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Ата-эненин ачкыч-мааниси түгөйүн жана жанындагы эки баланын түйүндөрүн сол баланын түйүнүнө бириктирип, кичирейтилген ата-эне түйүнүн кайтарып берет.
    ///
    ///
    /// Panics, эгерде биз `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Ата-эненин ачкыч-мааниси түгөйүн жана жанындагы эки баланын түйүндөрүн сол баланын түйүнүнө бириктирип, ошол бала түйүнүн кайтарат.
    ///
    ///
    /// Panics, эгерде биз `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Ата-эненин ачкыч-мааниси түгөйүн жана жанындагы эки баланын түйүндөрүн сол баланын түйүнүнө бириктирип, edge байкалган бала edge аяктаган ошол түйүндөгү edge туткасын кайтарып берет,
    ///
    ///
    /// Panics, эгерде биз `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Эски ата-эне ачкыч-нар жупун туура балага түртүп, сол баладан ачкыч-баалуулук жубун алып, ата-эненин ачкыч-сактагычына жайгаштырат.
    ///
    /// `track_right_edge_idx` тарабынан көрсөтүлгөн баштапкы edge аяктаганга туура келген оң жактагы edge туткасын кайтарып берет.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Эски ата-эне ачкыч-мааниси түгөйүн сол балага түртүп жатканда, оң баладан ачкыч-жупту алып, ата-эненин ачкыч-сактагычына салат.
    ///
    /// `track_left_edge_idx` тарабынан көрсөтүлгөн сол баланын edge кыймылдаткычын кыймылдатпай кайтарат.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Бул `steal_left` окшош уурулук кылат, бирок бир эле учурда бир нече элементтерди уурдайт.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Биздин аман-эсен уурдап алышыбызга кам көрүңүз.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Жалбырак дайындарын жылдыруу.
            {
                // Уурдалган элементтерге ылайыктуу балада орун бериңиз.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Элементтерди сол баладан оңго жылдырыңыз.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Уурдалган сол жупту ата-энеге өткөрүп бериңиз.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Ата-эненин ачкыч мааниси жупун керектүү балага жылдырыңыз.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Уурдалган четтерге орун бошотуп бериңиз.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Чектерин уурдаңыз.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left` симметриялуу клону.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Биздин аман-эсен уурдап алышыбызга кам көрүңүз.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Жалбырак дайындарын жылдыруу.
            {
                // Уурдалган оң жупту ата-энеге өткөрүп бериңиз.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Ата-эненин ачкыч-мааниси жупун сол балага жылдырыңыз.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Элементтерди оң баладан солго жылдырыңыз.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Мурда уурдалган элементтер болгон жерди толтуруңуз.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Чектерин уурдаңыз.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Мурда уурдалган четтер болгон жерди толтуруңуз.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Бул түйүн `Leaf` түйүнү экендигин тастыктаган статикалык маалыматтарды жок кылат.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Бул түйүн `Internal` түйүнү экендигин тастыктаган статикалык маалыматтарды жок кылат.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Негизги түйүн `Internal` түйүнү же `Leaf` түйүнү экендигин текшерет.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// `self` тен кийинки суффиксти бир түйүндөн экинчи түйүнүнө жылдырыңыз.`right` бош болушу керек.
    /// `right` биринчи edge өзгөрүүсүз бойдон калууда.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Киргизүү натыйжасы, качан түйүн өзүнүн мүмкүнчүлүгүнөн ашып жайылышы керек.
pub struct SplitResult<'a, K, V, NodeType> {
    // `kv` сол жагына таандык элементтери жана четтери бар болгон дарактын өзгөртүлгөн түйүнү.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Кээ бир ачкыч жана маани бөлүнүп, башка жерге киргизилет.
    pub kv: (K, V),
    // `kv` оң жагына таандык элементтери жана четтери бар жаңы түйүн.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Ушул карыз түрүндөгү түйүндөргө шилтемелер бактын башка түйүндөрүнө өтүүгө мүмкүнчүлүк береби.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal кереги жок, ал `borrow_mut` натыйжасын колдонуу менен болот.
        // Траверсалды өчүрүп, жана тамырларга жаңы шилтемелерди жаратуу менен, биз `Owned` түрүндөгү ар бир шилтеме тамыр түйүнүнө тиешелүү экендигин билебиз.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Баштапкы элементтердин кесиндисине бир маани киргизилет, андан кийин бир башталбаган элементтер.
///
/// # Safety
/// Кесектин `idx` ашык элементтери бар.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Бардык инициалдаштырылган элементтердин кесиндисинен бир маанини алып салат жана кайтарып берет, андан кийин бир инициализацияланбаган элемент калат.
///
///
/// # Safety
/// Кесектин `idx` ашык элементтери бар.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// `distance` позицияларындагы элементтерди солго жылдырат.
///
/// # Safety
/// Кесилгенде кеминде `distance` элементтери бар.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// `distance` позицияларындагы элементтерди оңго жылдырат.
///
/// # Safety
/// Кесилгенде кеминде `distance` элементтери бар.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Бардык баалуулуктарды инициалдаштырылган элементтердин кесиндисинен баштап, башталбаган элементтердин кесиндисине жылдырып, бардык инициализацияланбаган катары `src` артта калат.
///
/// `dst.copy_from_slice(src)` сыяктуу иштейт, бирок `T` тин `Copy` болушун талап кылбайт.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;