use core::intrinsics;
use core::mem;
use core::ptr;

/// Бул `v` уникалдуу шилтемесинин артындагы маанини тиешелүү функцияны чакыруу менен алмаштырат.
///
///
/// Эгерде `change` жабылышында panic пайда болсо, анда бүт процесс токтотулат.
#[allow(dead_code)] // сүрөттө жана future колдонуу үчүн сактаңыз
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Бул тиешелүү функцияны чакырып, `v` уникалдуу шилтемесинин артындагы маанини алмаштырат жана жолдо алынган натыйжаны кайтарат.
///
///
/// Эгерде `change` жабылышында panic пайда болсо, анда бүт процесс токтотулат.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}