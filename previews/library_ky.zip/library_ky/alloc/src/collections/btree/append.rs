use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Бардык ачкыч-маани жуптарын эки көтөрүлүүчү итераторлордун бирикмесинен кошуп, жолдо `length` өзгөрмөсүн көбөйтөт.Экинчиси, тамчы иштеткен адам чочуп кеткенде, чалып жаткан кишинин агып кетпешин жеңилдетет.
    ///
    /// Эгерде эки итератор бирдей ачкычты жасаса, анда бул ыкма жупту сол итератордон түшүрүп, жупту оң итератордон кошот.
    ///
    /// Эгерде сиз дарактын `BTreeMap` сыяктуу катуу көтөрүлүү тартибинде бүтүшүн кааласаңыз, анда эки итератор тең ачкычтарды, алардын ар бири дарактын бардык баскычтарынан чоң, анын ичинде кире беришинде дарактын ичинде болгон бардык ачкычтарды жасашы керек.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Биз `left` жана `right` ны сызыктуу убакытта иреттелген ырааттуулукка бириктирүүгө даярданабыз.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Ошол эле учурда, биз даракты сызыктуу убакытта иреттелген ырааттуулуктан курабыз.
        self.bulk_push(iter, length)
    }

    /// Бардык ачкыч-жуптарды бактын башына түртүп, жолдо `length` өзгөрмөсүн көбөйтөт.
    /// Экинчиси, кайталоочу чочуп кеткенде, чалып жаткан адамга маалыматтын чыгып кетпешин жеңилдетет.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Бардык ачкыч-жуптарды кайталап, аларды керектүү деңгээлдеги түйүндөргө түртүп салыңыз.
        for (key, value) in iter {
            // Ачкыч-маани жупун учурдагы жалбырак түйүнүнө түртүп көрүңүз.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Бош орун калган жок, жогору көтөрүлүп, ал жакка түрт.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Бош орун калган түйүн табылды, ушул жерге түрт.
                                open_node = parent;
                                break;
                            } else {
                                // Дагы көтөрүлүңүз.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Биз жогору жактабыз, жаңы тамыр түйүнүн түзүп, ошол жерге түртүп салыңыз.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Ачкыч-маани жупун жана жаңы оң субтракты басыңыз.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Кайра оң жактагы эң жалбыракка ылдый түшүңүз.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Итераторлор дүрбөлөңгө түшсө дагы, картанын тиркелген элементтерин түшүрүп жаткандыгына ынануу үчүн, ар бир кайталоонун узундугун көбөйтүңүз.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Эки иреттелген ырааттуулукту бир катарга бириктирүү үчүн итератор
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Эгер эки ачкыч бирдей болсо, оң булактан ачкыч-маани жупун кайтарат.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}