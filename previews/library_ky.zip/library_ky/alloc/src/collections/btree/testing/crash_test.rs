use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Айрым окуяларды көзөмөлдөөчү кыйроо тестинин муляждык инстанцияларынын планы.
/// Кээ бир учурларда panic конфигурацияланган болушу мүмкүн.
/// Окуялар `clone`, `drop` же анонимдүү `query`.
///
/// Crash test муляждары идентификатор тарабынан аныкталат жана буйрулат, ошондуктан аларды BTreeMap ичинде ачкыч катары колдонсо болот.
/// Атайын колдонулганда, `Debug` trait ден тышкары, crate де аныкталган эч нерсеге таянбайт.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Кырсык тестинин жасалма дизайнын түзөт.`id` инстанциялардын тартибин жана теңдигин аныктайт.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Ал кандай окуяларды башынан өткөргөндүгүн жана panics ыктыярдуу түрдө иштелип чыкканын текшерип, иштен чыгуучу муляждын мисалын түзөт.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Думиянын нускалары канча жолу клондолгонун кайтарып берет.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Думмиянын канча жолу алынып салынгандыгын кайтарып берет.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// `query` мүчөсүнүн канча жолу муляждын нускалары чакырылгандыгын кайтарып берет.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Натыйжасы буга чейин берилген айрым анонимдүү суроо.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}