//! Өсүүчү шакек буфери менен ишке ашырылган эки тараптуу кезек.
//!
//! Бул кезекте идиштин эки учунан *O*(1) амортизацияланган кыстармалар жана алынып салынды.
//! Ошондой эле vector сыяктуу *O*(1) индекстөөсү бар.
//! Камтылган элементтердин көчүрүлүшү талап кылынбайт, эгерде камтылган түр жөнөтүлсө, кезек жөнөтүлөт.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Эки кубаттуулуктун эң чоңу

/// Өсүүчү шакек буфери менен ишке ашырылган эки тараптуу кезек.
///
/// "default" түрүн кезек катары колдонуу кезекке кошуу үчүн [`push_back`], кезектен алып салуу үчүн [`pop_front`].
///
/// [`extend`] жана [`append`] ушундай жол менен арткы бетке түртөт жана `VecDeque` үстүнөн кайталоо алдыга артка өтөт.
///
/// `VecDeque` шакекче буфер болгондуктан, анын элементтери сөзсүз түрдө эс тутумга туташ эмес.
/// Эгер сиз элементтерге бир кесим түрүндө, мисалы, натыйжалуу сорттоо үчүн жеткиңиз келсе, [`make_contiguous`] колдоно аласыз.
/// Ал элементтери оролуп калбашы үчүн `VecDeque` ди айландырып, өзгөрүлмө кесинди эми жанаша турган элементтер тизмегине кайтарат.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // куйрук жана баш буфердеги көрсөткүчтөр.
    // Tail ар дайым окула турган биринчи элементти көрсөтөт, Head ар дайым маалыматтардын кайсы жерге жазылышы керектигин көрсөтүп турат.
    //
    // Эгерде куйрук==баш болсо, буфер бош.Рингбуфердин узундугу экөөнүн ортосундагы аралык катары аныкталат.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Деструктор кулап түшкөндө, анын ичиндеги бардык нерселер үчүн иштейт (адатта же ачуу учурунда).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // [T] үчүн тамчы колдонуу
            ptr::drop_in_place(front);
        }
        // RawVec бөлүштүрүүнү иштетет
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Бош `VecDeque<T>` түзөт.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Бир кыйла ыңгайлуу
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Бир кыйла ыңгайлуу
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Нөл өлчөмдөрү үчүн биз ар дайым максималдуу кубаттуулуктабыз
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Ptrди кесимге айландырыңыз
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Ptr тилкесин тилекке айландырыңыз
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Элементти буферден чыгарат
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Буферге элементти жазып, аны жылдырат.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Буфер толук кубаттуулукта болсо, `true` берет.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Берилген логикалык элемент индексинин негизги буфердеги индексин кайтарат.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Берилген логикалык элемент индекс + addend үчүн негизги буфердеги индексти кайтарып берет.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Берилген логикалык элемент индексинин негизги буфердеги индексин кайтарат, subtrahend.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// src ден dstке чейинки узундуктагы эс тутумунун Лен блокун көчүрөт
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// src ден dstке чейинки узундуктагы эс тутумунун Лен блокун көчүрөт
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Эс тутумунун потенциалдуу оролуучу блогун src ден destке чейин көчүрөт.
    /// (abs(dst - src) + len) cap() тен чоң болбошу керек (src менен destтин ортосунда эң көп дегенде бири-биринин үстүнөн кайчылашкан аймак болушу керек).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src оробойт, дст оробойт
                //
                //        S...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst src чейин, src оробойт, dst оройт
                //
                //
                //    S...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // Dst чейин src, src оробойт, dst оройт
                //
                //
                //              S...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst src чейин, src оройт, dst оробойт
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // Dst чейин src, src оройт, dst оробойт
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst src чейин, src оройт, dst оройт
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // Dst чейин src, src оройт, dst оройт
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... Д.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Биз жаңы гана жайгаштырылгандыгыбызды аныктоо үчүн, баш жана куйрук бөлүктөрүн айланып өтөт.
    /// Коопсуз эмес, анткени ал эски кубаттуулукка ишенет.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // TH шакек буферинин эң кыска чектеш бөлүгүн жылдырыңыз
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // A Nop
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Бош `VecDeque` түзөт.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Кеминде `capacity` элементтерине орун бар бош `VecDeque` түзөт.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 анткени рингбуфер ар дайым бир орун бош калтырат
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Берилген индекстеги элементке шилтеме берет.
    ///
    /// 0 индексиндеги элемент кезектин алдыңкы бөлүгү.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Берилген индекстеги элементке өзгөрүлмө шилтеме берет.
    ///
    /// 0 индексиндеги элемент кезектин алдыңкы бөлүгү.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// `i` жана `j` индекстери боюнча элементтерди алмаштырат.
    ///
    /// `i` жана `j` барабар болушу мүмкүн.
    ///
    /// 0 индексиндеги элемент кезектин алдыңкы бөлүгү.
    ///
    /// # Panics
    ///
    /// Panics, эгерде эки индекс тең чектен чыкса.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// `VecDeque` ээлей алган элементтердин санын бөлүштүрбөй туруп берет.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Берилген `VecDeque` ге `additional` элементтерин киргизүү үчүн минималдуу сыйымдуулукту сактайт.
    /// Кубаттуулугу буга чейин жетиштүү болсо, эч нерсе кылбайт.
    ///
    /// Белгилей кетүүчү нерсе, бөлүүчү коллекцияга ал сураганга караганда көбүрөөк орун бере алат.
    /// Ошондуктан кубаттуулукту минималдуу деп айтууга болбойт.
    /// Эгерде future киргизүүлөрү күтүлсө, [`reserve`] артыкчылыгы.
    ///
    /// # Panics
    ///
    /// Жаңы кубаттуулук `usize` ашып кетсе, Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Берилген `VecDeque` ичине киргизиле турган `additional` элементтерден кем эмесинин резервдик кубаттуулугу.
    /// Коллекция тез-тез бөлүштүрүүдөн сактануу үчүн көбүрөөк орун камдашы мүмкүн.
    ///
    /// # Panics
    ///
    /// Жаңы кубаттуулук `usize` ашып кетсе, Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Берилген `VecDeque<T>` ге `additional` элементтерин киргизүү үчүн минималдуу кубаттуулукту сактоого аракет кылат.
    ///
    /// `try_reserve_exact` чакыргандан кийин, кубаттуулук `self.len() + additional` тен чоң же ага барабар болот.
    /// Кубаттуулугу буга чейин жетиштүү болсо, эч нерсе кылбайт.
    ///
    /// Белгилей кетүүчү нерсе, бөлүүчү коллекцияга ал сураганга караганда көбүрөөк орун бере алат.
    /// Демек, кубаттуулукту минималдуу деп айтууга болбойт.
    /// Эгерде future киргизүүлөрү күтүлсө, `reserve` артыкчылыгы.
    ///
    /// # Errors
    ///
    /// Эгерде кубаттуулук `usize` ашып кетсе же бөлүштүрүүчү иштебей калгандыгын билдирсе, анда ката кайтарылып берилет.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Эстутумду алдын-ала сактап коюңуз, эгер мүмкүн болбосо, чыгып жатабыз
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Эми биз билебиз, бул мүмкүн эмес OOM(Out-Of-Memory) биздин ортосунда татаал иш
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // абдан татаал
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Берилген `VecDeque<T>` те жок дегенде `additional` элементтерин киргизүү үчүн кубаттуулукту резервге алууга аракет кылат.
    /// Коллекция тез-тез бөлүштүрүүдөн сактануу үчүн көбүрөөк орун камдашы мүмкүн.
    /// `try_reserve` чакыргандан кийин, кубаттуулук `self.len() + additional` тен чоң же ага барабар болот.
    /// Эгерде кубаттуулук буга чейин жетиштүү болсо, эч нерсе кылбайт.
    ///
    /// # Errors
    ///
    /// Эгерде кубаттуулук `usize` ашып кетсе же бөлүштүрүүчү иштебей калгандыгын билдирсе, анда ката кайтарылып берилет.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Эстутумду алдын-ала сактап коюңуз, эгер мүмкүн болбосо, чыгып жатабыз
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Азыр биз бул татаал ишибиздин ортосунда OOM мүмкүн эместигин билдик
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // абдан татаал
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// `VecDeque` сыйымдуулугун мүмкүн болушунча кыскартат.
    ///
    /// Ал узундукка мүмкүн болушунча жакын түшөт, бирок бөлүп берүүчү дагы бир нече элементтерге орун бар экендигин `VecDeque` ке билдириши мүмкүн.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Төмөнкү чек менен `VecDeque` сыйымдуулугун кичирейтет.
    ///
    /// Кубаттуулугу, жок эле дегенде, узундугу жана берилген наркы сыяктуу эле чоң бойдон калат.
    ///
    ///
    /// Эгер учурдагы кубаттуулук төмөнкү чектен аз болсо, анда бул жокко эсе.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Биз `self.len()` да, `self.capacity()` да эч качан `usize::MAX` боло албагандыктан, ашып кетүүдөн чочулабайбыз.
        // +1 анткени рингбуфер ар дайым бир орун бош калтырат.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Үч учур бар:
            //   Бардык элементтер керектүү чектерден тышкары Элементтер жанаша, ал эми баш каалаган чектерден тышкары Элементтер үзүлүштүү, ал эми куйрук каалаган чектерден тышкары
            //
            //
            // Башка учурларда, элементтердин позициялары таасир этпейт.
            //
            // Башындагы элементтерди жылдыруу керектигин көрсөтөт.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Элементтерди каалаган чектерден жылдырыңыз (target_capдан кийинки позициялар)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Биринчи `len` элементтерин сактап, калганын таштап, `VecDeque` ти кыскартат.
    ///
    ///
    /// Эгер `len` "VecDeque" учурдагы узундугунан чоңураак болсо, анда эч кандай таасир бербейт.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Деструктор кулап түшкөндө, анын ичиндеги бардык нерселер үчүн иштейт (адатта же ачуу учурунда).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Коопсуз, анткени:
        //
        // * `drop_in_place` ке өткөн ар кандай кесим жарактуу;экинчи учурда `len <= front.len()` бар жана `len > self.len()` ге кайтуу биринчи учурда `begin <= back.len()` ти камсыз кылат
        //
        // * VecDequeтин башын `drop_in_place` чакыруудан мурун которушат, андыктан `drop_in_place` panics болсо эки эсе эч кандай мааниге ээ болбойт.
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Экинчи жарым panics деструктору болгондо дагы, түшүп калгандыгын текшериңиз.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Алдыңкы-арткы кайткычты кайтарат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Өзгөрүлө турган шилтемелерди кайтарган алдыңкы артка кайткычты кайтарат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // КООПСУЗДУК: Ички `IterMut` коопсуздук инварианты негизделген, анткени
        // `ring` биз жаратабыз-бул өмүр бою бериле турган тилим. '.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// `VecDeque` мазмунун кезеги менен камтыган бир кесим жупту кайтарып берет.
    ///
    /// Эгер мурун [`make_contiguous`] деп аталып калса, анда `VecDeque` тин бардык элементтери биринчи тилимде болот, ал эми экинчи кесинди бош калат.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// `VecDeque` мазмунун кезеги менен камтыган бир кесим жупту кайтарып берет.
    ///
    /// Эгер мурун [`make_contiguous`] деп аталып калса, анда `VecDeque` тин бардык элементтери биринчи тилимде болот, ал эми экинчи кесинди бош калат.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// `VecDeque` элементтеринин санын кайтарат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// `VecDeque` бош болсо, `true` берет.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// `VecDeque` ичинде көрсөтүлгөн диапазонду камтыган итераторду түзөт.
    ///
    /// # Panics
    ///
    /// Panics, эгерде баштапкы чекит акыркы чекиттен чоңураак болсо же акыркы чекит vector дин узундугунан чоңураак болсо.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Толук диапазону бардык мазмунун камтыйт
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // &self теги жалпы маалымдама '_ of Iterде сакталат.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// `VecDeque` ичинде көрсөтүлгөн өзгөрүлмө диапазонду камтыган итераторду түзөт.
    ///
    /// # Panics
    ///
    /// Panics, эгерде баштапкы чекит акыркы чекиттен чоңураак болсо же акыркы чекит vector дин узундугунан чоңураак болсо.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Толук диапазону бардык мазмунун камтыйт
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // КООПСУЗДУК: Ички `IterMut` коопсуздук инварианты негизделген, анткени
        // `ring` биз жаратабыз-бул өмүр бою бериле турган тилим. '.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// `VecDeque` те көрсөтүлгөн диапазонду алып салган жана алынып салынган нерселерди берген дренаждык итераторду түзөт.
    ///
    /// Эскертүү 1: Итератор аягына чейин керектелбесе дагы, элементтердин диапазону алынып салынат.
    ///
    /// Эскертүү 2: Эгерде `Drain` мааниси түшпөсө, бирок алган карызынын мөөнөтү бүтсө (мисалы, `mem::forget` эсебинен), анда канча элемент деккеден чыгарылганы белгисиз.
    ///
    ///
    /// # Panics
    ///
    /// Panics, эгерде баштапкы чекит акыркы чекиттен чоңураак болсо же акыркы чекит vector дин узундугунан чоңураак болсо.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Толугу менен бардык мазмунун тазалайт
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Эстутумдун коопсуздугу
        //
        // Drain биринчи жолу жаратылганда, баштапкы деукция кыскартылат, эгерде Drain деструктору эч качан иштебей калса, анда эч кандай инициализацияланбаган же жылдырылбаган элементтер таптакыр жеткиликтүү эмес.
        //
        //
        // Drain ptr::read маанисин алып салат.
        // Бүткөндөн кийин, калган маалыматтар тешикти жабуу үчүн кайра көчүрүлүп, head/tail маанилери туура калыбына келтирилет.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Деканын элементтери үч сегментке бөлүнөт:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=drain_tail;h=drain_head
        //
        // Биз drain_tail деп self.head деп, ал эми drain_head жана self.head үчүн after_tail жана after_head катары Drain де сактайбыз.
        // Бул ошондой эле натыйжалуу массивди кыскартат, эгерде Drain чыгып кетсе, биз drain башталгандан кийин мүмкүн болгон жылыш маанилерин унутуп калдык.
        //
        //
        //        T th H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" drain башталгандан кийин drain аяктагандан жана Drain деструктору иштетилгенден кийинки маанилер жөнүндө.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Эң башкысы, биз бул жерде `self` тен гана жалпы шилтемелерди түзүп, андан окуйбуз.
                // Биз `self` номерине кат жазбайбыз жана өзгөрүлмө шилтеме менен кайра төрөлбөйбүз.
                // Демек, биз `deque` үчүн жогоруда түзүлгөн чийки көрсөткүч жарактуу бойдон калууда.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Бардык баалуулуктарды алып салып, `VecDeque` ти тазалайт.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Эгерде `VecDeque` берилген мааниге барабар элементти камтыса, `true` берет.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Алдыңкы элементке шилтеме берет, же `VecDeque` бош болсо `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Алдыңкы элементке өзгөрүлмө шилтеме берет, же `VecDeque` бош болсо `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Арткы элементке шилтеме берет, же `VecDeque` бош болсо `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Арткы элементке өзгөрүлмө шилтеме берет, же `VecDeque` бош болсо `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Биринчи элементти алып салат жана аны кайтарат, же `VecDeque` бош болсо `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// `VecDeque` тен акыркы элементти алып салат жана эгер ал бош болсо `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// `VecDeque` элементин алдын-ала көрсөтөт.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// `VecDeque` арткы бөлүгүнө элемент тиркейт.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: `head == 0` дегенди эске алышыбыз керек
        // `self` тыгыз экендигин?
        self.tail <= self.head
    }

    /// `VecDeque` тин каалаган жеринен бир элементти алып салат жана аны биринчи элементке алмаштырат.
    ///
    ///
    /// Бул буйрутманы сактабайт, бирок *O*(1).
    ///
    /// Эгерде `index` чектен чыкса, `None` берет.
    ///
    /// 0 индексиндеги элемент кезектин алдыңкы бөлүгү.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// `VecDeque` тин каалаган жеринен бир элементти алып салат жана аны акыркы элемент менен алмаштырат.
    ///
    ///
    /// Бул буйрутманы сактабайт, бирок *O*(1).
    ///
    /// Эгерде `index` чектен чыкса, `None` берет.
    ///
    /// 0 индексиндеги элемент кезектин алдыңкы бөлүгү.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// `VecDeque` ичине `index` элементин киргизип, индекстери `index` тен жогору же барабар болгон бардык элементтерди артка жылдырат.
    ///
    ///
    /// 0 индексиндеги элемент кезектин алдыңкы бөлүгү.
    ///
    /// # Panics
    ///
    /// Panics, эгер `index` "VecDeque" узундугунан чоңураак болсо
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Шакек буфериндеги элементтердин эң аз санын жылдырып, берилген объектти кыстарыңыз
        //
        // Эң көп len/2, 1 элемент жылдырылат. O(min(n, n-i))
        //
        // Негизги үч учур бар:
        //  Элементтер жанаша
        //      - куйрук 0 болгондо өзгөчө учур, элементтер үзгүлтүккө учурап, ал эми куйрук бөлүктө болсо, элементтер үзгүлтүккө учурап, кыстарма баш бөлүктө болот
        //
        //
        // Алардын ар бири үчүн дагы эки учур бар:
        //  Кыстаруу куйрукка жакын Кыстаруу башка жакыныраак
        //
        // Ачкыч: H, self.head
        //      T, self.tail o, Жарактуу элемент I, Киргизүү элемент А, М пунктун киргизгенден кийин болушу керек элемент, Элемент жылдырылган
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [A oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // чектеш, куйрукка жакын киргизиңиз:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // чектеш, куйрук менен куйрукка жакыныраак 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       ММ

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Мурунтан эле куйругун жылдыргандыктан, биз `index - 1` элементтерин гана көчүрөбүз.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // чектеш, башына жакын коюңуз:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // караңгы, куйрукка, куйрукка жакыныраак киргизүү:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // үзгүлтүксүз, башына, куйрук бөлүгүнө жакын коюңуз:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // элементтерди жаңы башка чейин көчүрүү
                    self.copy(1, 0, self.head);

                    // акыркы элементти буфердин түбүндөгү бош жерге көчүрүү
                    self.copy(0, self.cap() - 1, 1);

                    // ^ элементтерин кошпогондо, idx ден алдыга аягына жылдыруу
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // үзгүлтүктүү, киргизүү куйрукка, баш бөлүккө жакыныраак жана ички буфердеги нөл индексинде:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // элементтерди жаңы куйрукка чейин көчүрүү
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // акыркы элементти буфердин түбүндөгү бош жерге көчүрүү
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // үзгүлтүктүү, куйрукка жакын коюңуз, баш бөлүгү:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // элементтерди жаңы куйрукка чейин көчүрүү
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // акыркы элементти буфердин түбүндөгү бош жерге көчүрүү
                    self.copy(self.cap() - 1, 0, 1);

                    // элементтерди idx-1 кошпогондо, idx-1 ден алдыга аягына жылдырыңыз
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // үзгүлтүксүз, башка, баш бөлүмүнө жакын коюңуз:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // Кайра эсептеп чыгыш керек болгондуктан, куйрук өзгөрүлүп кеткен болушу мүмкүн
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// X001ден `index` деги элементти алып салат жана кайтарат.
    /// Кайсы учу алып салуу чекитине жакыныраак болсо, орун бошотуп, бардык жабыр тарткан элементтер жаңы позицияларга жылдырылат.
    ///
    /// Эгерде `index` чектен чыкса, `None` берет.
    ///
    /// 0 индексиндеги элемент кезектин алдыңкы бөлүгү.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Негизги үч учур бар:
        //  Элементтер бири-бирине шайкеш келет Элементтер үзгүлтүккө учурайт жана алып салуу куйрук бөлүгүндө. Элементтер үзүлүштүү жана алып салуу баш бөлүгүндө
        //
        //      - элементтер техникалык жактан бири-бирине жакын болгондо, бирок self.head =0 болгон өзгөчө учур
        //
        // Алардын ар бири үчүн дагы эки учур бар:
        //  Кыстаруу куйрукка жакын Кыстаруу башка жакыныраак
        //
        // Ачкыч: H, self.head
        //      T, self.tail o, жарактуу элемент x, алып салуу үчүн белгиленген элемент R, алынып салынып жаткан элементти көрсөтөт M, элемент жылдырылгандыгын көрсөтөт
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // чектеш, куйрукка жакын алып салыңыз:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // чектеш, башына жакын алып салуу:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // караңгы, куйрукка, куйрукка жакыныраак алып салуу:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // караңгы, башка жакын алып салуу, баш бөлүм:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // караңгы, башына, куйрук бөлүгүнө жакын алып салуу:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // же жарым-жартылай, баштын, куйрук бөлүктүн жанындагы алып салуу:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // куйрук бөлүгүндө элементтерди тартуу
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Төмөнкү суунун алдын алат.
                    if self.head != 0 {
                        // биринчи элементти бош жерге көчүрүү
                        self.copy(self.cap() - 1, 0, 1);

                        // баш бөлүгүндөгү элементтерди артка жылдырыңыз
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // караңгы, куйрукка жакын алып салуу, баш бөлүм:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // idxке чейинки элементтерди тартуу
                    self.copy(1, 0, idx);

                    // акыркы элементти бош жерге көчүрүү
                    self.copy(0, self.cap() - 1, 1);

                    // элементтерди куйруктан алдыга жылдырып, акыркысын кошпогондо
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Берилген индекс боюнча `VecDeque` ти экиге бөлөт.
    ///
    /// Жаңы бөлүнгөн `VecDeque` кайтарып берет.
    /// `self` `[0, at)` элементтерин камтыйт, ал эми `VecDeque` `[at, len)` элементтерин камтыйт.
    ///
    /// `self` сыйымдуулугу өзгөрүлбөйт.
    ///
    /// 0 индексиндеги элемент кезектин алдыңкы бөлүгү.
    ///
    /// # Panics
    ///
    /// Panics, эгер `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` биринчи жарымында жатат.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // экинчи жарымдын бардыгын эле алсаңыз болот.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` экинчи жарымында жатат, биринчи жарымында өткөрүп жиберген элементтерибизди эске алуу керек.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Буферлердин учтары турган жерде тазалоо
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// `other` тин бардык элементтерин `self` ке жылдырып, `other` ти бош калтырат.
    ///
    /// # Panics
    ///
    /// Panics, эгерде элементтердин жаңы саны `usize` ашып кетсе.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // naive impl
        self.extend(other.drain(..));
    }

    /// Предикат менен көрсөтүлгөн элементтерди гана сактайт.
    ///
    /// Башка сөз менен айтканда, бардык `e` элементтерин алып салыңыз, мисалы `f(&e)` жалган болуп кайтат.
    /// Бул ыкма өз ордунда иштеп, ар бир элементке баштапкы тартипте так бир жолу барып, сакталып калган элементтердин иреттүүлүгүн сактайт.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Так буйрук индекс сыяктуу тышкы абалды көзөмөлдөө үчүн пайдалуу болушу мүмкүн.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Бул panic же аборт кылышы мүмкүн
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Буфердин көлөмүн эки эсеге көбөйтүңүз.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// `VecDeque` ти X0XXге барабар кылып, ашыкча элементтерди арткы элементтерден алып салуу же `generator` артка чакыруу менен пайда болгон элементтерди кошуу менен, `VecDeque` ти ордуна келтирет.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Бул декенин ички сактагычын кайрадан иретке келтирет, ошондуктан ал бири-бирине жакын кесинди болуп, кайра кайтарылат.
    ///
    /// Бул ыкма киргизилген элементтердин ордун бөлбөйт жана алардын ордун өзгөртпөйт.Өзгөрүлө турган кесинди кайтарып бергенде, муну декти сорттоо үчүн колдонсо болот.
    ///
    /// Ички сактагыч бири-бирине жакын болгондон кийин, [`as_slices`] жана [`as_mut_slices`] ыкмалары `VecDeque` тин мазмунун бир тилимде кайтарып берет.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Декенин мазмунун сорттоо.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // декти сорттоо
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // аны тескери тартипте сорттоо
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Жанаша тилимге өзгөрүлгүс мүмкүнчүлүк алуу.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // биз `slice` деуктун бардык элементтерин камтыйт деп ишенсек болот, ошол эле учурда `buf` ке өзгөрүүсүз мүмкүнчүлүк бар.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // бир эле жол менен куйрукту көчүрүп алууга бош орун жетиштүү, демек, башты артка жылдырып, андан кийин куйрукту туура жерге көчүрөбүз.
            //
            //
            // тартып: DEFGH .... ABC
            // кимге: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Учурда караган жокпуз .... ABCDEFGH
            // чектеш болушу керек, анткени `head` бул учурда `0` болмок.
            // Балким, биз муну өзгөрткүбүз келет, бирок анча деле маанилүү эмес, анткени бир нече жерде `is_contiguous` биз `buf[tail..head]` ти колдонуп кессек болот дегенди билдирет.
            //
            //

            // башты бир жолу көчүрүүгө бош орун жетиштүү, демек, биз алгач куйрукту алдыга жылдырып, андан кийин башты туура жерге көчүрөбүз.
            //
            //
            // келген: FGH .... ABCDE
            // to: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // акысыз, баш менен куйруктан кичине, демек, "swap" куйрукту жана башты жай басышыбыз керек.
            //
            //
            // келген: EFGHI ... ABCD же HIJK.ABCDEFG
            // кимге: ABCDEFGHI ... же ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Жалпы көйгөй мындай окшойт GHIJKLM ... ABCDEF, ар кандай свопторго чейин ABCDEFM ... GHIJKL, 1 алмашуудан кийин ABCDEFGHIJM ... KL, сол edge темп-дүкөнгө жеткенге чейин алмашуу
                //                  - андан кийин алгоритмди жаңы (smaller) дүкөнү менен өчүрүп күйгүзүңүз Кээде temp дүкөнү буфердин аягында туура edge турганда жетилет, демек, биз азыраак своптор менен туура буйрукка жетиштик!
                //
                // E.g
                // EF..ABCD ABCDEF .., төрт гана своп алмашуудан кийин, биз аягына чыктык
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Эки тараптуу кезек `mid` орундарын сол жакка бурат.
    ///
    /// Equivalently,
    /// - `mid` пунктун биринчи позицияга бурат.
    /// - Биринчи `mid` элементтерин ачып, аларды аягына чейин түртөт.
    /// - `len() - mid` орундарды оңго бурат.
    ///
    /// # Panics
    ///
    /// Эгерде `mid` `len()` тен чоңураак болсо.
    /// `mid == len()` _not_ panic жасаарын жана иштен чыкпаган айлануу экендигин эске алыңыз.
    ///
    /// # Complexity
    ///
    /// `*O*(min(mid, len() - mid))` убактысын алат жана ашыкча орун жок.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Эки тараптуу кезек `k` орундарын оңго бурат.
    ///
    /// Equivalently,
    /// - Биринчи нерсени `k` абалына айландырат.
    /// - Акыркы `k` буюмдарын жарып, аларды алдыга түртөт.
    /// - `len() - k` орундарды солго бурат.
    ///
    /// # Panics
    ///
    /// Эгерде `k` `len()` тен чоңураак болсо.
    /// `k == len()` _not_ panic жасаарын жана иштен чыкпаган айлануу экендигин эске алыңыз.
    ///
    /// # Complexity
    ///
    /// `*O*(min(k, len() - k))` убактысын алат жана ашыкча орун жок.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // КООПСУЗДУК: төмөнкү эки ыкма айлануу суммасын талап кылат
    // деканын узундугунун жарымынан аз болушу.
    //
    // `wrap_copy` `min(x, cap() - x) + copy_len <= cap()` талап кылат, бирок `min` ге караганда, эч качан кубаттуулуктун жарымынан ашпайт, ошондуктан бул жакка чалуу туура болот, анткени биз кубаттуулуктун жарымынан ашпаган узундуктун жарымынан аз нерсе менен чалып жатабыз.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Бинардык экран ушул `VecDeque` элементин издейт.
    ///
    /// Эгер маани табылса, анда дал келген элементтин индексин камтыган [`Result::Ok`] кайтарылат.
    /// Эгерде бир нече матч болсо, анда матчтардын кайсынысы болбосун кайтарылышы мүмкүн.
    /// Эгерде маани табылбаса, [`Result::Err`] кайтарылып берилет, анда иреттелген тартипти сактоо менен дал келген элементти киргизүүгө болот.
    ///
    ///
    /// # Examples
    ///
    /// Төрт элементтин сериясын издейт.
    /// Биринчиси табылган, уникалдуу аныкталган позиция менен;экинчи жана үчүнчүсү табылган жок;төртүнчүсү `[1, 4]` каалаган позициясына дал келиши мүмкүн.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Эгерде сиз иреттелген `VecDeque` ке бир нерсени киргизгиңиз келсе, иреттөө тартибин сактаңыз:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Бинардык система ушул `VecDeque` ти компаратордун функциясы менен издейт.
    ///
    /// Салыштыргыч функциясы, анын аргументи `Less`, `Equal` же `Greater` экендигин каалаган максатка салыштырганда, буйрук кодун кайтарып, негизги `VecDeque` тин иреттөө тартибине шайкеш келген тартипти ишке ашырышы керек.
    ///
    ///
    /// Эгер маани табылса, анда дал келген элементтин индексин камтыган [`Result::Ok`] кайтарылат.Эгерде бир нече матч болсо, анда матчтардын кайсынысы болбосун кайтарылышы мүмкүн.
    /// Эгерде маани табылбаса, [`Result::Err`] кайтарылып берилет, анда иреттелген тартипти сактоо менен дал келген элементти киргизүүгө болот.
    ///
    /// # Examples
    ///
    /// Төрт элементтин сериясын издейт.Биринчиси табылган, уникалдуу аныкталган позиция менен;экинчи жана үчүнчүсү табылган жок;төртүнчүсү `[1, 4]` каалаган позициясына дал келиши мүмкүн.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Binary издөө бул сорттолгон `VecDeque` ачкыч чыгаруу функциясы менен.
    ///
    /// `VecDeque` баскыч боюнча иргелет деп ойлойбуз, мисалы [`make_contiguous().sort_by_key()`](#method.make_contiguous) менен бир эле ачкычты алуу функциясын колдонуп.
    ///
    ///
    /// Эгер маани табылса, анда дал келген элементтин индексин камтыган [`Result::Ok`] кайтарылат.
    /// Эгерде бир нече матч болсо, анда матчтардын кайсынысы болбосун кайтарылышы мүмкүн.
    /// Эгерде маани табылбаса, [`Result::Err`] кайтарылып берилет, анда иреттелген тартипти сактоо менен дал келген элементти киргизүүгө болот.
    ///
    /// # Examples
    ///
    /// Төрт элементтин катарларын экинчи элементтери боюнча иреттелген жуптардын кесиндисинде издейт.
    /// Биринчиси табылган, уникалдуу аныкталган позиция менен;экинчи жана үчүнчүсү табылган жок;төртүнчүсү `[1, 4]` каалаган позициясына дал келиши мүмкүн.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// `VecDeque` ти `len()` new_lenге барабар кылып, ашыкча элементтерди артынан алып салуу же `value` клондорун арткы бетке кошуу менен өзгөртөт.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Берилген логикалык элемент индексинин негизги буфердеги индексин кайтарат.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // көлөмү ар дайым 2ге барабар
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Буферде окула турган элементтердин санын эсептеңиз
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // көлөмү ар дайым 2ге барабар
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Ар дайым үч бөлүккө бөлүнөт, мисалы: self: [a b c|d e f] other: [0 1 2 3|4 5] front=3, mid=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // X_Hash::hash_slice ти as_slices ыкмасы менен кайтылган тилмелерде колдонуу мүмкүн эмес, анткени алардын узундугу бирдей декада айырмаланышы мүмкүн.
        //
        //
        // Хэшер анын ыкмаларына дал келген бирдей чалуулардын эквиваленттүүлүгүн гана кепилдейт.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// `VecDeque` наркы боюнча элементтерди берген арткы-арткы итераторго сарптайт.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Бул функция төмөнкүлөрдүн моралдык эквиваленти болушу керек:
        //
        //      iter.into_iter() өлчөмүндөгү нерсе үчүн {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// [`Vec<T>`] ти [`VecDeque<T>`] ке айландырыңыз.
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Бул мүмкүн болушунча кайра бөлүштүрүүдөн качат, бирок анын шарттары катаал жана өзгөрүлүшү мүмкүн, ошондуктан `Vec<T>` `From<VecDeque<T>>` келип чыкпаса жана кайра бөлүштүрүлбөсө, анда ага ишенбөө керек.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // ZSTлерге кубаттуулук жөнүндө тынчсызданууга эч кандай бөлүү жок, бирок `VecDeque` `Vec` сыяктуу узундукту көтөрө албайт.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Эгерде кубаттуулугу эки кубаттуулукка ээ болбосо, өтө эле кичинекей же жок дегенде бир бош орунга ээ болбосо, көлөмүбүздү өзгөртүү керек.
            // Биз муну `Vec` режиминде жүргөндө жасайбыз, андыктан заттар panic ге түшүп калат.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// [`VecDeque<T>`] ти [`Vec<T>`] ке айландырыңыз.
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Бул эч качан кайра бөлүштүрүүнүн кажети жок, бирок *O*(*n*) кыймылын жасашы керек, эгерде тегерек буфер бөлүштүрүүнүн башында болбосо.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Бул *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Бул үчүн маалыматтарды өзгөртүү керек.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}