//! Бир жиптүү эсептөө көрсөткүчтөрү.'Rc' 'Маалымдама дегенди билдирет
//! Counted'.
//!
//! [`Rc<T>`][`Rc`] түрү үйүлүп бөлүнгөн `T` типтеги мааниге жалпы ээликти камсыз кылат.
//! [`clone`][clone] ти [`Rc`] ке чакырганда, үймөктө ошол эле бөлүштүрүүгө жаңы көрсөткүч пайда болот.
//! Берилген бөлүштүрүүгө акыркы [`Rc`] көрсөткүчү жок кылынганда, ошол бөлүштүрүүдөгү (көбүнчө "inner value" деп аталат) сакталып калган маани дагы төмөндөйт.
//!
//! Rust деги жалпы шилтемелер мутацияны демейки шартта колдонууга жол бербейт жана [`Rc`] да өзгөчө жагдай эмес: жалпысынан [`Rc`] ичиндеги нерсеге өзгөрүлмө шилтеме ала албайсыз.
//! Эгер сизге өзгөрүлмө керек болсо, [`Rc`] ичине [`Cell`] же [`RefCell`] коюңуз;[an example of mutability inside an `Rc`][mutability] карагыла.
//!
//! [`Rc`] атомдук эмес эсептөө колдонот.
//! Бул кошумча чыгым өтө төмөн дегенди билдирет, бирок [`Rc`] жиптер арасына жөнөтүлбөйт, демек [`Rc`] [`Send`][send] ти ишке ашырбайт.
//! Натыйжада, Rust компилятору *компиляция убагында* сиз жиптердин арасына [`Rc`] жибербей жатканыңызды текшерет.
//! Эгерде сизге көп сайлуу, атомдук шилтеме эсептөө керек болсо, [`sync::Arc`][arc] колдонуңуз.
//!
//! [`downgrade`][downgrade] ыкмасы ээлик кылбаган [`Weak`] көрсөткүчүн түзүүдө колдонулушу мүмкүн.
//! [`Weak`] көрсөткүчү [`Rc`] ке [`upgrade '][upgrade] d болушу мүмкүн, бирок, [`None`], эгерде бөлүштүрүүдө сакталып калган маани мурунтан эле түшүп калса, кайтып келет.
//! Башка сөз менен айтканда, `Weak` көрсөткүчтөрү бөлүштүрүүнүн ичиндеги маанини сактап калбайт;ошентсе да, алар бөлүштүрүүнү (ички баалуулук үчүн көмөкчү дүкөн) сактап калышат.
//!
//! [`Rc`] көрсөткүчтөрүнүн ортосундагы цикл эч качан бөлүштүрүлбөйт.
//! Ушул себептен [`Weak`] циклдарды бузуу үчүн колдонулат.
//! Мисалы, дарак ата-эне түйүндөрүнөн балдарга күчтүү [`Rc`] көрсөткүчтөрүн, ал эми балдардан ата-энелерине алып баруучу [`Weak`] көрсөткүчтөрүн алышы мүмкүн.
//!
//! `Rc<T>` автоматтык түрдө `T` ке шилтеме берет ([`Deref`] trait аркылуу), андыктан [`Rc<T>`][`Rc`] типтеги мааниге "T" ыкмаларын чакыра аласыз.
//! "T" ыкмалары менен аталыштардын кагылышуусуна жол бербөө үчүн, [`Rc<T>`][`Rc`] методдору [fully qualified syntax] колдонулган байланышкан функциялар болуп саналат:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>traits `Clone` сыяктуу ишке ашырылышы толук квалификацияланган синтаксисти колдонуу деп аталышы мүмкүн.
//! Кээ бир адамдар толук квалификацияланган синтаксисти, ал эми башкалары ыкма-чакыруу синтаксисин колдонууну туура көрүшөт.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Ыкма-чакыруу синтаксиси
//! let rc2 = rc.clone();
//! // Толугу менен квалификацияланган синтаксис
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] `T` автоматтык түрдө ажыратылбайт, анткени ички маани буга чейин түшүп калган болушу мүмкүн.
//!
//! # Колдонулган шилтемелер
//!
//! Учурдагы шилтеме эсептелген көрсөткүч менен бирдей бөлүштүрүүгө жаңы шилтеме түзүү, [`Rc<T>`][`Rc`] жана [`Weak<T>`][`Weak`] үчүн жүзөгө ашырылган `Clone` trait колдонулат.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Төмөндөгү эки синтаксис барабар.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a жана b экөө тең foo менен бирдей эс тутумун көрсөтөт.
//! ```
//!
//! `Rc::clone(&from)` синтаксиси эң идиомикалык болуп саналат, анткени ал коддун маанисин так түшүндүрөт.
//! Жогорудагы мисалда, бул синтаксис бул коддун foo мазмунун толугу менен көчүрүп алгандан көрө, жаңы шилтеме жаратып жаткандыгын көрүүнү жеңилдетет.
//!
//! # Examples
//!
//! "Гаджет" топтому берилген `Owner` ке таандык сценарийди карап көрөлү.
//! Гаджетибиз алардын `Owner` көрсөткүчүн көрсөткүбүз келет.Биз муну уникалдуу менчик укугу менен жасай албайбыз, анткени бир эле гаджет бир эле `Owner` ке таандык болушу мүмкүн.
//! [`Rc`] бир нече "Гаджет" ортосунда `Owner` бөлүшүүгө мүмкүнчүлүк берет жана `Owner` анда турган `Gadget` упайлары бөлүнгөнчө сакталып кала берет.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... башка талаалар
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... башка талаалар
//! }
//!
//! fn main() {
//!     // Маалымдама эсептелген `Owner` түзүңүз.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `gadget_owner` ке таандык "Гаджет" түзүңүз.
//!     // `Rc<Owner>` клондоштуруу, ошол эле `Owner` бөлүштүрүүгө жаңы көрсөткүчтү берет, бул процесстеги шилтеме санын көбөйтөт.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Биздин жергиликтүү өзгөрүлмө `gadget_owner` ти жок кылыңыз.
//!     drop(gadget_owner);
//!
//!     // `gadget_owner` ти түшүргөнүбүзгө карабастан, биз Gadget'тын `Owner` аталышын басып чыгара алабыз.
//!     // Себеби биз көрсөткөн `Owner` эмес, бир гана `Rc<Owner>` түшүрдүк.
//!     // Ошол эле `Owner` бөлүштүрүүнү көрсөткөн башка `Rc<Owner>` бар болсо, ал түз эфирде калат.
//!     // Талаа проекциясы `gadget1.owner.name` иштейт, анткени `Rc<Owner>` автоматтык түрдө `Owner` ке шилтеме берет.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Функциянын аягында `gadget1` жана `gadget2` жок кылынат жана алар менен биздин `Owner` ке акыркы эсептелген шилтемелер.
//!     // Гаджет адамы эми жок кылынат.
//!     //
//! }
//! ```
//!
//! Эгер биздин талаптар өзгөрүлүп, биз `Owner` дан `Gadget` ке чейин өтө алышыбыз керек болсо, биз көйгөйлөргө туш болобуз.
//! `Owner` тен `Gadget` ке чейинки [`Rc`] көрсөткүчү циклди киргизет.
//! Демек, алардын шилтемелеринин саны эч качан 0го жетпейт жана бөлүштүрүү эч качан жок кылынбайт:
//! эс тутумдун агып кетиши.Ушуну айланып өтүү үчүн [`Weak`] көрсөткүчтөрүн колдонсок болот.
//!
//! Rust чындыгында биринчи кезекте ушул циклди чыгарууну бир аз татаалдаштырат.Бир-бирине багытталган эки баалуулук менен аякташ үчүн, алардын бири өзгөрүлмө болушу керек.
//! Бул кыйын, себеби [`Rc`] эс тутумдун коопсуздугун анын оролгон маанисине жалпы шилтемелерди берүү менен гана күчөтөт жана бул түз мутацияга жол бербейт.
//! Мутацияны каалаган бөлүктүн [`RefCell`] ичине оролушубуз керек, ал *ички өзгөрүүнү* камсыз кылат: жалпы шилтеме аркылуу өзгөрүлмөлүүлүккө жетүү ыкмасы.
//! [`RefCell`] иштеп жатканда Rust карыз алуу эрежелерин аткарат.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... башка талаалар
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... башка талаалар
//! }
//!
//! fn main() {
//!     // Маалымдама эсептелген `Owner` түзүңүз.
//!     // Биз "Гаджет" ээсинин vector ээсин `RefCell` ичине жайгаштыргандыгыбызды эске алып, аны жалпы шилтеме аркылуу мутация кыла алабыз.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Мурунку сыяктуу `gadget_owner` ке таандык "Гаджет" түзүңүз.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Gadget'ты `Owner` ке кошуңуз.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` динамикалык карыз ушул жерде бүтөт.
//!     }
//!
//!     // Алардын гаджеттерин кайталап, алардын деталдарын басып чыгарыңыз.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` `Weak<Gadget>` болуп саналат.
//!         // `Weak` көрсөткүчтөрү бөлүштүрүү дагы эле бар экенине кепилдик бере албагандыктан, `Option<Rc<Gadget>>` номерин кайтарып берген `upgrade` номерине чалуу керек.
//!         //
//!         //
//!         // Бул учурда, биз бөлүштүрүү дагы эле бар экендигин билебиз, ошондуктан биз `unwrap` `Option`.
//!         // Тагыраак айтканда, `None` натыйжасы үчүн сизге ката кетирилген ката талап кылынышы мүмкүн.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Функциянын аягында `gadget_owner`, `gadget1` жана `gadget2` жок кылынат.
//!     // Азыр гаджеттерге күчтүү (`Rc`) көрсөткүчтөрү жок болгондуктан, алар жок кылынды.
//!     // Ушуну менен Гаджет адамынын шилтемеси жокко чыгарылат, ошондуктан ал дагы жок кылынат.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Бул repr(C) тен future ге мүмкүн болгон талааны кайра иретке келтирүүгө каршы, бул трансмутталуучу ички түрлөрдүн башкача коопсуз [into|from]_raw() ине тоскоол болот.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Бир жиптүү шилтеме эсептөө көрсөткүчү.'Rc' 'Маалымдама дегенди билдирет
/// Counted'.
///
/// Көбүрөөк маалымат алуу үчүн [module-level documentation](./index.html) караңыз.
///
/// `Rc` тин мүнөздүү методдору-бул бардык байланышкан функциялар, демек, аларды `value.get_mut()` ордуна [`Rc::get_mut(&mut value)`][get_mut] деп атоого туура келет.
/// Бул ички `T` типтеги ыкмалар менен карама-каршылыктардан сактайт.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Бул кооптуулук туура эмес, анткени Rc тирүү кезинде, ички көрсөткүч жарактуу деп кепилдик беребиз.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Жаңы `Rc<T>` курат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Бардык күчтүү көрсөткүчтөргө таандык болгон ачык-айкын алсыз көрсөткүч бар, ал күчтүү деструктор иштеп жатканда алсыз деструктор эч качан бөлүштүрүүнү бошотпойт, алсыз көрсөткүч күчтүү ичинде сакталса дагы.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Өзүнө алсыз шилтеме колдонуп жаңы `Rc<T>` курат.
    /// Бул функция кайтып келгенге чейин алсыз шилтемени жаңыртуу аракети `None` маанисине алып келет.
    ///
    /// Бирок, начар шилтеме эркин клондолуп, кийинчерээк колдонуу үчүн сакталышы мүмкүн.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... дагы талаалар
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Ички жагын "uninitialized" абалында бир гана алсыз шилтеме менен куруңуз.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Биз алсыз көрсөткүчкө ээликтен баш тартпашыбыз керек, антпесе `data_fn` кайтып келгенге чейин эс тутум бошоп калышы мүмкүн.
        // Эгерде биз чындыгында эле менчик укугун өткөрүп бергибиз келсе, анда өзүбүзгө кошумча алсыз көрсөткүчтү жаратмакпыз, бирок ал начар шилтеме санына кошумча жаңыртууларды алып келиши мүмкүн, антпесе, антпесе керек эмес.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Күчтүү шилтемелер биргелешип жалпы алсыз маалымдамага ээ болушу керек, андыктан биздин эски алсыз шилтеме үчүн деструкторду иштетпеңиз.
        //
        mem::forget(weak);
        strong
    }

    /// Башталбаган мазмуну бар жаңы `Rc` курат.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Кийинкиге калтыруу:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Эстутум `0` байт менен толтурулган, башталбаган мазмуну бар жаңы `Rc` курат.
    ///
    ///
    /// Бул ыкманы туура жана туура эмес колдонуу мисалдары үчүн [`MaybeUninit::zeroed`][zeroed] ти караңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Жаңы `Rc<T>` курат, эгерде бөлүштүрүү ишке ашпай калса, ката кетет
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Бардык күчтүү көрсөткүчтөргө таандык болгон ачык-айкын алсыз көрсөткүч бар, ал күчтүү деструктор иштеп жатканда алсыз деструктор эч качан бөлүштүрүүнү бошотпойт, алсыз көрсөткүч күчтүү ичинде сакталса дагы.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Баштала элек мазмун менен жаңы `Rc` курат, эгерде бөлүштүрүү болбой калса, ката кетирет
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Кийинкиге калтыруу:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Баштала элек мазмун менен жаңы `Rc` курат, эс тутум `0` байт менен толтурулат, эгер бөлүштүрүү болбой калса, ката кайтат.
    ///
    ///
    /// Бул ыкманы туура жана туура эмес колдонуу мисалдары үчүн [`MaybeUninit::zeroed`][zeroed] ти караңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Жаңы `Pin<Rc<T>>` курат.
    /// Эгерде `T` `Unpin` ти ишке ашырбаса, анда `value` эс тутумуна тыгылып, жылдырылбай калат.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Ички маанини кайтарып берет, эгер `Rc` бир күчтүү шилтеме болсо.
    ///
    /// Болбосо, [`Err`] берилген `Rc` менен кайтарылат.
    ///
    ///
    /// Мыкты шилтемелер болсо дагы, бул ийгиликке жетет.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // камтылган объектини көчүрүү

                // Алсыздарга көрсөткөндөй, аларды күчтүү санды төмөндөтүү менен алдыга жылдыруу мүмкүн эмес, андан кийин көмүскө "strong weak" көрсөткүчүн алып салыңыз, ал эми жалган Алсызды ойлоп табуунун логикасы менен иштеңиз.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Башталбаган мазмуну бар жаңы шилтеме эсептелген кесинди курат.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Кийинкиге калтыруу:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Эстутум `0` байт менен толтурулган, инициализацияланбаган мазмуну бар жаңы шилтеме эсептелген кесинди курат.
    ///
    ///
    /// Бул ыкманы туура жана туура эмес колдонуу мисалдары үчүн [`MaybeUninit::zeroed`][zeroed] ти караңыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>` ке которулат.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] сыяктуу эле, ички баалуулук чындыгында баштапкы абалда экендигине кепилдик берүү чалуучунун колунда.
    ///
    /// Мазмун толук кандуу баштала элек учурда, муну тез арада аныкталбаган жүрүм-турумга алып келет.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Кийинкиге калтыруу:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>` ке которулат.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] сыяктуу эле, ички баалуулук чындыгында баштапкы абалда экендигине кепилдик берүү чалуучунун колунда.
    ///
    /// Мазмун толук кандуу баштала элек учурда, муну тез арада аныкталбаган жүрүм-турумга алып келет.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Кийинкиге калтыруу:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Оролгон көрсөткүчтү кайтарып, `Rc` керектейт.
    ///
    /// Эстутум чыгып кетпеши үчүн, көрсөткүчтү [`Rc::from_raw`][from_raw] колдонуп `Rc` форматына кайтаруу керек.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Берилген маалыматтарга чийки көрсөткүчтү берет.
    ///
    /// Санактарга эч кандай таасир этпейт жана `Rc` керектелбейт.
    /// Көрсөтүүчү `Rc` те күчтүү эсептөөлөр болгонго чейин жарактуу.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // КООПСУЗДУК: Бул Deref::deref же Rc::inner аркылуу өтө албайт, анткени
        // мисалы, мисалы, raw/mut далилдигин сактап калуу үчүн талап кылынат
        // `get_mut` Rc `from_raw` аркылуу калыбына келтирилгенден кийин көрсөткүч аркылуу жаза алат.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Чийки көрсөткүчтөн `Rc<T>` курат.
    ///
    /// Чийки көрсөткүч мурун [`Rc<U>::into_raw`][into_raw] номерине чалып, `U` `T` менен бирдей өлчөмдө жана тегиздикте болушу керек.
    /// Эгер `U` `T` болсо, бул кичинекей чындык.
    /// Эгерде `U` `T` эмес, бирок көлөмү жана тегиздиги бирдей болсо, анда бул негизинен ар кандай типтеги шилтемелерди которууга окшош.
    /// Бул учурда кандай чектөөлөр колдонулаары жөнүндө көбүрөөк маалымат алуу үчүн [`mem::transmute`][transmute] караңыз.
    ///
    /// `from_raw` колдонуучусу белгилүү бир `T` маанисинин бир гана жолу түшүрүлүшүн текшериши керек.
    ///
    /// Бул функция кооптуу, анткени туура эмес колдонуу эс тутумдун коопсуздугуна алып келиши мүмкүн, кайтарылган `Rc<T>` эч качан колдонулбаса дагы.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Агып кетпеши үчүн `Rc` ке кайра которуңуз.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Мындан ары `Rc::from_raw(x_ptr)` чалуулары эс тутумга кооптуу болот.
    /// }
    ///
    /// // `x` жогорудагы алкактан чыгып кеткенде, эс тутум бошотулду, демек, `x_ptr` азыр илинип турат!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Түпнуска RcBox табуу үчүн жылдырууну артка кайтарыңыз.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Бул бөлүштүрүүгө жаңы [`Weak`] көрсөткүчүн түзөт.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Асылып турган Алсызды жаратпаганыбызга ынаныңыз
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Бул бөлүштүрүүгө [`Weak`] көрсөткүчтөрүнүн санын алат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Бул бөлүштүрүүгө күчтүү (`Rc`) көрсөткүчтөрүнүн санын алат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Бул бөлүштүрүүгө башка `Rc` же [`Weak`] көрсөткүчтөрү жок болсо, `true` берет.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Эгерде ошол эле бөлүштүрүүгө башка `Rc` же [`Weak`] көрсөткүчтөрү жок болсо, берилген `Rc` ке өзгөрүлмө шилтемени кайтарып берет.
    ///
    ///
    /// Болбосо [`None`] кайтарып берет, анткени бөлүшүлгөн маанинин мутациясы коопсуз эмес.
    ///
    /// Ошондой эле [`make_mut`][make_mut] караңыз, башка көрсөткүчтөр болгондо ички маанини [`clone`][clone] кылат.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Берилген `Rc` ке өзгөрүлмө шилтемени эч кандай текшерүүсүз кайтарып берет.
    ///
    /// Коопсуз жана тиешелүү текшерүүлөрдү жүргүзгөн [`get_mut`] караңыз.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Ушул эле бөлүштүрүүгө карата бардык башка `Rc` же [`Weak`] көрсөткүчтөрү кайтарылып алынган насыянын мөөнөтү ичинде берилбеши керек.
    ///
    /// Мындай көрсөткүчтөр жок болсо, мисалы, `Rc::new` тен кийин дароо эле болот.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // "count" талааларын камтыган маалымдама түзбөө үчүн * этияттык менен мамиле кылабыз, анткени бул шилтеме саноолоруна кирүүгө каршы келет (мис.
        // `Weak` тарабынан).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Эгерде эки Rc` бирдей бөлүштүрүүнү көрсөткөн болсо ([`ptr::eq`] окшош венада), `true` берет.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Берилген `Rc` ке өзгөрүлмө шилтеме берет.
    ///
    /// Эгерде ушул эле бөлүштүрүүгө башка `Rc` көрсөткүчтөрү бар болсо, анда `make_mut` уникалдуу ээликти камсыз кылуу үчүн ички бөлүштүрүүнү жаңы бөлүштүрүүгө [`clone`] кылат.
    /// Бул ошондой эле жазуу клону деп аталат.
    ///
    /// Эгерде бул бөлүштүрүүгө башка `Rc` көрсөткүчтөрү жок болсо, анда [`Weak`] көрсөткүчтөрү ажыратылат.
    ///
    /// Клондоштургандан көрө, ишке ашпай турган [`get_mut`] караңыз.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Эч нерсе клондобойт
    /// let mut other_data = Rc::clone(&data);    // Ички маалыматтарды клондобойбуз
    /// *Rc::make_mut(&mut data) += 1;        // Ички маалыматтарды клондоштурат
    /// *Rc::make_mut(&mut data) += 1;        // Эч нерсе клондобойт
    /// *Rc::make_mut(&mut other_data) *= 2;  // Эч нерсе клондобойт
    ///
    /// // Азыр `data` жана `other_data` ар кандай бөлүштүрүүлөрдү көрсөтүшөт.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] көрсөткүчтөр ажыратылат:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Маалыматтарды клондош керек, башка Rcs бар.
            // Түздөн-түз клондолгон маанини жазууга мүмкүндүк берүү үчүн эс тутумду алдын-ала бөлүп алыңыз.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Жөн гана маалыматтарды уурдап алса болот, алсыздар гана калды
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Күчтүү жана алсыз рефиксти алып салыңыз (бул жерде жасалма Алсызды ойлоп табуунун кажети жок-биз үчүн башка Алсыздар тазалайт)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Бул кооптуу жагдай эч нерсе эмес, анткени кайтарылган көрсөткүч качан гана Т кайтара турган *жалгыз* көрсөткүч экендигине кепилдик бар.
        // Биздин шилтемелерибиздин саны ушул учурда 1 деп кепилденет жана биз `Rc<T>` `mut` болушун талап кылдык, ошондуктан бөлүштүрүү боюнча бирден-бир шилтемени кайтарып жатабыз.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Конкреттүү түргө `Rc<dyn Any>` түшүрүүгө аракет.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Мүмкүн көлөмү бөлүнбөгөн ички мааниге жетиштүү орун менен `RcBox<T>` бөлүп берет, анда мааниси берилген макети бар.
    ///
    /// `mem_to_rcbox` функциясы маалымат көрсөткүчү менен аталат жана `RcBox<T>` үчүн (май болушу мүмкүн) көрсөткүчүн кайтарып бериши керек.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Берилген маанинин макетин колдонуп макетин эсептөө.
        // Буга чейин макет `&*(ptr as* const RcBox<T>)` сөз айкашы боюнча эсептелген, бирок бул туура эмес шилтеме жараткан (#54908 караңыз).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Мүмкүн көлөмү бөлүнбөгөн ички мааниге жетиштүү орун бар `RcBox<T>` бөлүп берет, эгерде анын мааниси жайгаштырылган болсо, анда ката кайтарылып берилет.
    ///
    ///
    /// `mem_to_rcbox` функциясы маалымат көрсөткүчү менен аталат жана `RcBox<T>` үчүн (май болушу мүмкүн) көрсөткүчүн кайтарып бериши керек.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Берилген маанинин макетин колдонуп макетин эсептөө.
        // Буга чейин макет `&*(ptr as* const RcBox<T>)` сөз айкашы боюнча эсептелген, бирок бул туура эмес шилтеме жараткан (#54908 караңыз).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Макет үчүн бөлүңүз.
        let ptr = allocate(layout)?;

        // RcBox инициализациясы
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Өлчөнбөгөн ички мааниге жетиштүү орун менен `RcBox<T>` бөлүп берет
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Берилген маанини колдонуп `RcBox<T>` үчүн бөлүп бериңиз.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Көчүрмө байт катары
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Мазмунун түшүрбөй бөлүүнү акысыз
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Берилген узундугу менен `RcBox<[T]>` бөлүп берет.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Элементтерди кесимден жаңы бөлүнгөн Rc <\[T\]> га көчүрүңүз
    ///
    /// Коопсуз эмес, анткени чалган адам менчик укугун алышы керек же `T: Copy` тутумун байлап алышы керек
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Белгилүү бир өлчөмдө экени белгилүү болгон итератордон `Rc<[T]>` курат.
    ///
    /// Өлчөмү туура эмес болсо, жүрүм-туруму аныкталбайт.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Т элементтерин клондоштуруп жатканда Panic сакчысы.
        // panic болгон учурда, жаңы RcBoxко жазылган элементтер ташталат, андан кийин эс тутум бошотулат.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Биринчи элементке көрсөткүч
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Баары ачык.Жаңы RcBox бошотпошу үчүн сакчыны унутуңуз.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` үчүн колдонулган адистештирүү trait.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// `Rc` ти түшүрөт.
    ///
    /// Бул күчтүү шилтеме санын азайтат.
    /// Эгерде күчтүү шилтеме саны нөлгө жетсе, анда башка шилтемелер гана бар (эгер бар болсо) [`Weak`], ошондуктан биз ички маанини `drop` кылабыз.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Эч нерсе басып чыгарбайт
    /// drop(foo2);   // "dropped!" басып чыгарат
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // камтылган объектини жок кылуу
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // мазмунун жок кылгандыктан, ачык эмес "strong weak" көрсөткүчүн алып салыңыз.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// `Rc` көрсөткүчүнүн клонун түзөт.
    ///
    /// Бул ошол эле бөлүштүрүүгө дагы бир көрсөткүчтү жаратып, күчтүү шилтеме санын көбөйтөт.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// `T` үчүн `Default` мааниси бар жаңы `Rc<T>` түзөт.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// `Eq` ыкмасы бар болсо да, `Eq` боюнча адистештирилген уруксат Hack.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Биз бул адистешүүнү ушул жерде жасап жатабыз, бирок `&T` боюнча жалпы оптимизация эмес, анткени бул башкача айтканда, бардык теңдикти текшерүүгө чыгымдарды кошот.
/// Биздин оюбузча, "Rc`s чоң маанилерди сактоо үчүн колдонулат, алар клондолушу жай, бирок теңдикти текшерүү үчүн оор, ошондуктан бул чыгым оңой төлөнөт.
///
/// Эки X&X`ге караганда бирдей мааниге ээ болгон эки `Rc` клону болушу мүмкүн.
///
/// Биз муну `T: Eq` `PartialEq` катары атайылап рефлексивдүү болушу мүмкүн болгондо гана жасай алабыз.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Эки `Rc` үчүн теңдик.
    ///
    /// Эки `Rc`, эгер алардын ички баалуулуктары бирдей болсо, алар ар кандай бөлүштүрүүдө сакталса дагы.
    ///
    /// Эгерде `T` `Eq` ти ишке ашырса (теңдиктин рефлекстүүлүгүн билдирет), ошол эле бөлүштүрүүнү көрсөткөн эки `Rc` ар дайым бирдей болот.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Эки `Rc` үчүн теңсиздик.
    ///
    /// Ички мааниси тең эмес болсо, эки `Rc` тең эмес.
    ///
    /// Эгерде `T` `Eq` ти ишке ашырса (теңдиктин рефлекстүүлүгүн билдирет), ошол эле бөлүштүрүүгө багытталган эки Rc` эч качан тең эмес.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Эки "Rc`" үчүн жарым-жартылай салыштыруу.
    ///
    /// Экөө ички баалуулуктары боюнча `partial_cmp()` чакыруу менен салыштырылат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Эки "Rc`" салыштырганда азыраак.
    ///
    /// Экөө ички баалуулуктары боюнча `<` чакыруу менен салыштырылат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Эки Rc`ге салыштырганда 'аз же барабар'.
    ///
    /// Экөө ички баалуулуктары боюнча `<=` чакыруу менен салыштырылат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Эки Rc`ге салыштырганда чоңураак.
    ///
    /// Экөө ички баалуулуктары боюнча `>` чакыруу менен салыштырылат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Эки Rc`ге салыштырганда"чоң же барабар".
    ///
    /// Экөө ички баалуулуктары боюнча `>=` чакыруу менен салыштырылат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Эки "Rc" үчүн салыштыруу.
    ///
    /// Экөө ички баалуулуктары боюнча `cmp()` чакыруу менен салыштырылат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Шилтеме менен эсептелген кесинди бөлүп, "v" пункттарын клондоо менен толтуруңуз.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Шилтеме катары саналган сап тилкесин бөлүп, ага `v` көчүрүңүз.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Шилтеме катары саналган сап тилкесин бөлүп, ага `v` көчүрүңүз.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Кутулган объектини жаңы, шилтеме эсептелгенге, бөлүүгө жылдырыңыз.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Шилтеме менен эсептелген кесинди бөлүп, ага "v" пункттарын жылдырыңыз.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Vecке эс тутумун бошотууга уруксат бериңиз, бирок анын мазмунун жок кылбаңыз
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// `Iterator` деги ар бир элементти алат жана `Rc<[T]>` ке чогултат.
    ///
    /// # Иштөө мүнөздөмөлөрү
    ///
    /// ## Жалпы иш
    ///
    /// Жалпы учурда, `Rc<[T]>` ичине чогултуу алгач `Vec<T>` ке чогултуу жолу менен жүргүзүлөт.Башкача айтканда, төмөнкүлөрдү жазууда:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// бул биз жазгандай сезилет:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Бөлүштүрүүлөрдүн биринчи топтому ушул жерде болот.
    ///     .into(); // `Rc<[T]>` үчүн экинчи бөлүштүрүү ушул жерде болот.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Бул `Vec<T>` ти куруу үчүн канча керек болсо, ошону менен `Vec<T>` ти `Rc<[T]>` ке айландыруу үчүн бир жолу бөлүп берет.
    ///
    ///
    /// ## Узундугу белгилүү итераторлор
    ///
    /// Сиздин `Iterator` `TrustedLen` ти ишке ашырганда жана анын өлчөмү так болгондо, `Rc<[T]>` үчүн бирден бөлүштүрүү жүргүзүлөт.Мисалы:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Бул жерде бир эле бөлүү болот.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// `Rc<[T]>` ке чогултуу үчүн колдонулган trait адистештирүүсү.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Бул `TrustedLen` итераторуна тиешелүү.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // КООПСУЗДУК: Биз итератордун так узундугуна ээ болушубуз керек жана бизде бар.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Кадимки турмушка кайтып келүү.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` башкарылуучу бөлүштүрүүгө менчиксиз шилтеме берген [`Rc`] версиясы.Бөлүштүрүүгө `Weak` көрсөткүчү боюнча [`upgrade`] чакыруу аркылуу жетүүгө болот, ал ["Опция`]"<`[`Rc`] "<T>>`.
///
/// `Weak` шилтемеси менчикке эсептелбегендиктен, ал бөлүштүрүүдө сакталган маанинин түшүп кетишине жол бербейт жана `Weak` өзү дагы деле болсо ушул наркка эч кандай кепилдик бербейт.
/// Ошентип, ал [`None`] көлөмүн ["жаңыртуу"] күнү кайтып келиши мүмкүн.
/// Бирок `Weak` шилтемеси * бөлүп алуунун (көмөкчү дүкөндүн) бөлүнүшүнө жол бербей тургандыгын эске алыңыз.
///
/// `Weak` көрсөткүчү [`Rc`] тарабынан башкарылган бөлүштүрүүгө убактылуу шилтеме жасап, анын ички маанисинин түшүп кетишине жол бербөө үчүн пайдалуу.
/// Ошондой эле, [`Rc`] көрсөткүчтөрүнүн ортосундагы тегерек шилтемелердин алдын алуу үчүн колдонулат, анткени өз ара ээлик кылган шилтемелер эч качан [`Rc`] тин түшүшүнө жол бербейт.
/// Мисалы, дарак ата-эне түйүндөрүнөн балдарга күчтүү [`Rc`] көрсөткүчтөрүн, ал эми балдардан ата-энелерине алып баруучу `Weak` көрсөткүчтөрүн алышы мүмкүн.
///
/// `Weak` көрсөткүчүн алуунун типтүү жолу-[`Rc::downgrade`] чалуу.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Бул энумдарда ушул түрдүн көлөмүн оптималдаштырууга мүмкүндүк берүүчү `NonNull`, бирок сөзсүз түрдө туура көрсөткүч эмес.
    //
    // `Weak::new` үймөккө орун бөлүп бербеши үчүн, муну `usize::MAX` кылып коет.
    // Бул чыныгы көрсөткүчтүн мааниси эмес, анткени RcBox жок дегенде 2 тегиздөөчү.
    // Бул `T: Sized` болгондо гана мүмкүн болот;көлөмсүз `T` эч качан өчпөйт.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Эстутум бөлбөй, жаңы `Weak<T>` курат.
    /// Кайтарым мааниде [`upgrade`] чакыруу ар дайым [`None`] берет.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Маалымат талаасы жөнүндө эч кандай ырастоолорсуз, шилтемелердин саналышына мүмкүнчүлүк берүүчү жардамчы териңиз.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Ушул `Weak<T>` көрсөткөн `T` объектисине чийки көрсөткүчтү кайтарып берет.
    ///
    /// Көрсөтүүчү күчтүү шилтемелер болгондо гана жарактуу болот.
    /// Көрсөтүүчү илинип турушу мүмкүн, тегизделбеген, ал тургай [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Экөө тең бир нерсени көрсөтүп жатышат
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Бул жердеги күчтүү нерсе аны тирүү кармайт, ошондуктан биз объектке дагы кире алабыз.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Бирок мындан ары эмес.
    /// // Биз weak.as_ptr() жасай алабыз, бирок көрсөткүчкө жетүү аныкталбаган жүрүм-турумга алып келет.
    /// // assert_eq! ("салам", кооптуу {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Эгерде көрсөткүч илинип турса, биз күзөттү түз кайтарабыз.
            // Бул жарактуу жүктүн дареги болушу мүмкүн эмес, анткени жүк, жок дегенде, RcBox (usize) менен дал келген.
            ptr as *const T
        } else {
            // КООПСУЗДУК: эгер is_dangling жалган болсо, анда көрсөткүчтү ажыратууга болот.
            // Ушул учурда пайдалуу жүк түшүп калышы мүмкүн жана биз пробенттүүлүктү сакташыбыз керек, андыктан чийки көрсөткүч менен иштөөнү колдонуңуз.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>` керектейт жана аны чийки көрсөткүчкө айлантат.
    ///
    /// Бул алсыз көрсөткүчтү чийки көрсөткүчкө айландырат, ошол эле учурда бир алсыз шилтеме ээсин сактап калат (алсыз эсептөө бул иш менен өзгөрүлбөйт).
    /// [`from_raw`] менен кайра `Weak<T>` кылса болот.
    ///
    /// [`as_ptr`] сыяктуу көрсөткүчтүн максатына жетүү чектөөлөрү колдонулат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Мурда [`into_raw`] тарабынан түзүлгөн чийки көрсөткүчтү `Weak<T>` ке кайра айлантат.
    ///
    /// Бул күчтүү шилтеме алуу үчүн колдонулушу мүмкүн ([`upgrade`] кийинчерээк чалып) же `Weak<T>` түшүрүп алсыз санын бөлүштүрүү үчүн.
    ///
    /// Бул бир алсыз шилтемеге ээлик кылат ([`new`] тарабынан түзүлгөн көрсөткүчтөрдү кошпогондо, анткени алар эч нерсеге ээ эмес; ыкма дагы деле болсо алардын үстүндө иштейт).
    ///
    /// # Safety
    ///
    /// Көрсөтүүчү [`into_raw`] тен келип чыккан жана дагы деле болсо анын начар шилтемесине ээ болушу керек.
    ///
    /// Чакырганда күчтүү эсептөө 0 болушу мүмкүн.
    /// Ошого карабастан, учурда чийки көрсөткүч катары көрсөтүлгөн бир алсыз шилтеме ээлик кылат (алсыз эсептөө бул иш-аракет менен өзгөрүлбөйт), демек, аны [`into_raw`] мурунку чакыруусу менен жупташтыруу керек.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Акыркы алсыз санды азайтуу.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Киргизүү көрсөткүчү кандайча алынгандыгы жөнүндө контекстти Weak::as_ptr караңыз.

        let ptr = if is_dangling(ptr as *mut T) {
            // Бул асылып турган Алсыз.
            ptr as *mut RcBox<T>
        } else {
            // Болбосо, көрсөткүч тил табылгыс Алсыз тараптан келген деп кепилдик беребиз.
            // КООПСУЗДУК: data_offset чалууга болбойт, анткени ptr чыныгы (мүмкүн түшүрүлгөн) Т.
            let offset = unsafe { data_offset(ptr) };
            // Ошентип, RcBox толугу менен алуу үчүн жылдырууну артка кайтарабыз.
            // КООПСУЗДУК: көрсөткүч Алсыздан келип чыккан, ошондуктан бул жылыш коопсуз.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // КООПСУЗДУК: биз азыр алсыз көрсөткүчтү калыбына келтирдик, ошондуктан алсыздарды түзө алабыз.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// `Weak` көрсөткүчүн [`Rc`] деңгээлине көтөрүү аракети, эгер ийгиликтүү болсо, ички маанинин түшүшүн кечеңдетүү.
    ///
    ///
    /// Ички мааниси түшүп калган болсо, [`None`] берет.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Бардык күчтүү көрсөткүчтөрдү жок кылыңыз.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Ушул бөлүштүрүүгө багытталган күчтүү (`Rc`) көрсөткүчтөрүнүн санын алат.
    ///
    /// Эгер `self` [`Weak::new`] аркылуу түзүлгөн болсо, анда 0 кайтарылат.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Ушул бөлүштүрүүгө багытталган `Weak` көрсөткүчтөрүнүн санын алат.
    ///
    /// Эгерде күчтүү көрсөткүчтөр калбаса, анда ал нөлгө айланат.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // жашыруун алсыз ptrди алып салуу
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Көрсөтүүчү илинип турганда жана бөлүнгөн `RcBox` жок болгондо `None`, кайтарат (башкача айтканда, бул `Weak` `Weak::new` тарабынан түзүлгөндө).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Биз "data" талаасын камтыган шилтеме түзүүдөн * сак эмеспиз, анткени талаа бир эле учурда мутацияга учурашы мүмкүн (мисалы, акыркы `Rc` түшүрүлсө, анда маалымат талаасы өз ордуна ташталат).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Эки "Алсыз" бирдей бөлүштүрүүнү көрсөткөн болсо ([`ptr::eq`] окшош), же экөө тең кандайдыр бир бөлүштүрүүнү көрсөтпөсө, `true` берет (анткени алар `Weak::new()`) менен түзүлгөн).
    ///
    ///
    /// # Notes
    ///
    /// Бул көрсөткүчтөрдү салыштырганда, `Weak::new()` бири-бирине теңелет дегенди билдирет, бирок алар эч кандай бөлүштүрүүнү көрсөтүшпөйт.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` салыштыруу.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` көрсөткүчүн түшүрөт.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Эч нерсе басып чыгарбайт
    /// drop(foo);        // "dropped!" басып чыгарат
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // алсыз эсептөө 1 ден башталып, бардык күчтүү көрсөткүчтөр жок болуп кеткенде гана нөлгө барат.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Ушул эле бөлүштүрүүнү көрсөткөн `Weak` көрсөткүчүнүн клонун түзөт.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Жаңы `Weak<T>` ти куруп, `T` үчүн эс тутумду инициалдаштырбастан бөлүп берет.
    /// Кайтарым мааниде [`upgrade`] чакыруу ар дайым [`None`] берет.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: mem::forget менен аман-эсен күрөшүү үчүн биз бул жерге текшердик.Өзгөчө
// эгер сиз mem::forget Rcs (же алсыздар) болсо, анда реферминг ашып кетиши мүмкүн, ошондо сиз көрүнүктүү Rcs (же алсыздар) бар болгон учурда бөлүүнү бошотсоңуз болот.
//
// Биз бойдон алдырып салабыз, анткени бул өтө начарлап кеткен сценарий болгондуктан, эмне болуп кетээрине көңүл бөлбөйбүз-бир дагы чыныгы программа буга туш болбошу керек.
//
// Буга кошумча жеңилдиктер болушу керек, анткени Rust де менчик укугуна жана кыймыл-семантикасына байланыштуу ушунчалык көп клондоштуруунун кажети жок.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Биз наркты түшүрбөй, ашыкча таштоону токтоткубуз келет.
        // Бул чакырылганда шилтеме саны эч качан нөл болбойт;
        // Ошентсе да, биз башка жол менен өткөрүлүп берилген оптималдаштыруу боюнча LLVM жөнүндө ишарат кылуу үчүн бул жерге аборт киргизебиз.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Биз наркты түшүрбөй, ашыкча таштоону токтоткубуз келет.
        // Бул чакырылганда шилтеме саны эч качан нөл болбойт;
        // Ошентсе да, биз башка жол менен өткөрүлүп берилген оптималдаштыруу боюнча LLVM жөнүндө ишарат кылуу үчүн бул жерге аборт киргизебиз.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Көрсөткүчтүн артындагы жүк үчүн `RcBox` ичинде ордун толтуруңуз.
///
/// # Safety
///
/// Көрсөтүүчү буга чейин жарактуу болгон Т нускасын көрсөтүп (жана алар үчүн жарактуу метадайындарга ээ) болушу керек, бирок Т түшүрүлүшү мүмкүн.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Өлчөнбөгөн маанини RcBoxтун аягына чейин тегизде.
    // RcBox repr(C) болгондуктан, ал ар дайым эс тутумдагы акыркы талаа болуп кала берет.
    // КООПСУЗДУК: кесилишсиз түрлөрү гана болушу мүмкүн болгондуктан, trait объектилери,
    // жана тышкы түрлөрү, киргизүү коопсуздугунун талабы учурда align_of_val_raw талаптарын канааттандыруу үчүн жетиштүү;бул тилдин std чегинен тышкары ишенүүгө болбой турган деталдары.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}