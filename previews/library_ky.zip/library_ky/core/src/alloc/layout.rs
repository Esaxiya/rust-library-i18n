use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Бул функция бир жерде колдонулуп, аны ишке ашырууга болот, буга чейинки аракеттер rustc жай кылган:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Эстутум блогунун макети.
///
/// `Layout` мисалы эс тутумдун белгилүү бир жайгашуусун сүрөттөйт.
/// Сиз `Layout` түзүп, бөлүп берүүчүгө берүү үчүн киргизүү катары.
///
/// Бардык макеттер байланышкан өлчөмгө жана экөөнүн кубаттуулугуна ылайыкташтырылган.
///
/// (`GlobalAlloc` эс тутумдун бардык талаптары нөлгө барабар өлчөмдө болушун талап кылганына карабастан, макеттердин нөлгө барабар өлчөмдө болушу талап кылынбайт *.
/// Чакыруучу ушул сыяктуу шарттардын аткарылышын камсыздашы керек, талаптары жогору конкреттүү бөлүштүргүчтөрдү колдонушу керек же `Allocator` жумшак интерфейсин колдонушу керек.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // суралган эс тутумунун байт менен өлчөнгөн көлөмү.
    size_: usize,

    // байт менен өлчөнгөн суралган эстутум блогун тегиздөө.
    // биз муну ар дайым экөөнүн күчү деп эсептейбиз, анткени API сыяктуу `posix_memalign` муну талап кылат жана ал макет конструкторлорун таңуулоого негиздүү чектөө болуп саналат.
    //
    //
    // (Бирок, биз аналогдук түрдө "align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.) талап кылбайбыз
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Берилген `size` жана `align` тен `Layout` курат же төмөнкү шарттардын бири аткарылбаса `LayoutError` кайтарат:
    ///
    /// * `align` нөл болбошу керек,
    ///
    /// * `align` эки күч болушу керек,
    ///
    /// * `size`, жакын `align` эселенгенге чейин тегеректелгенде, ашып кетпеши керек (б.а. тегеректелген маани `usize::MAX` тен аз же ага барабар болушу керек).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (экөөнүн кубаттуулугу тегиздөө дегенди билдирет!=0.)

        // Тегеректелген өлчөмү:
        //   size_rounded_up=(size + align, 1)&! (align, 1);
        //
        // Жогору жактан тегиздөө!=0 экендигин билебиз.
        // Эгер кошуу (тегиздөө, 1) ашып кетпесе, тегеректөө туура болот.
        //
        // Тескерисинче,&менен маскировкалоо! (Align, 1) төмөнкү тартиптеги биттерди гана алып салат.
        // Ошентип, ашыкча сумма менен ашып кетсе,&-mask масштабы жокко чыгара албайт.
        //
        //
        // Жогоруда суммадан ашыкча сумманы текшерүү зарыл жана жетиштүү экендигин билдирет.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // КООПСУЗДУК: `from_size_align_unchecked` үчүн шарттар түзүлгөн
        // жогоруда текшерилген.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Бардык текшерүүлөрдөн өтүп, макет түзөт.
    ///
    /// # Safety
    ///
    /// Бул функция кооптуу, анткени [`Layout::from_size_align`] алдын-ала шарттарын текшербейт.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // КООПСУЗДУК: чалган адам `align` нөлдөн жогору экендигин камсыздашы керек.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Бул макет эс тутуму үчүн байт менен минималдуу өлчөм.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Бул макет эс тутуму үчүн минималдуу байт тегиздөө.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// `T` түрүндөгү маанини кармоо үчүн ылайыктуу `Layout` курат.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // КООПСУЗДУК: тегиздөө Rust экөөнүн кубаттуулугуна кепилденет
        // көлөмү + тегиздөө айкалышы биздин дарек мейкиндигине туура келет деп кепилденет.
        // Натыйжада, текшерилбеген конструкторду колдонуп, panics кодун киргизүүдөн алыс болуңуз, эгерде ал жетиштүү деңгээлде оптимизацияланбаса.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` үчүн көмөкчү структураны бөлүштүрүү үчүн колдонула турган жазууну сүрөттөгөн макетин чыгарат (ал trait же кесим сыяктуу башка көлөмсүз болушу мүмкүн).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // КООПСУЗДУК: эмне үчүн кооптуу вариантты колдонуп жаткандыгын `new` негиздемесин караңыз
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` үчүн көмөкчү структураны бөлүштүрүү үчүн колдонула турган жазууну сүрөттөгөн макетин чыгарат (ал trait же кесим сыяктуу башка көлөмсүз болушу мүмкүн).
    ///
    /// # Safety
    ///
    /// Төмөнкү шарттар сакталганда гана, бул функцияны чалууга болот:
    ///
    /// - Эгерде `T` `Sized` болсо, анда бул функция ар дайым чалууга коопсуз.
    /// - Эгерде `T` өлчөмсүз куйругу:
    ///     - [slice], андан кийин кесиндилердин куйругунун узундугу интализацияланган бүтүн сандардан туруп,*бүт маанинин* өлчөмү (динамикалык куйрук узундугу + статикалык чоңдуктагы префикс) `isize` менен дал келиши керек.
    ///     - а [trait object], анда көрсөткүчтүн vtable бөлүгү көлөмсүз конфигурация менен алынган `T` түрү үчүн жарактуу vtableды көрсөтүп,*бүт маанинин* өлчөмү (динамикалык куйрук узундугу + статикалык өлчөмдөгү префикс) `isize` ге туура келиши керек.
    ///
    ///     - (unstable) [extern type], анда бул функция ар дайым чалууга коопсуз, бирок panic же башкача айтканда, туура эмес маанини кайтарып бериши мүмкүн, анткени сырткы типтин жайгашуусу белгисиз.
    ///     Бул тышкы түрдөгү куйрукка шилтеме берүү боюнча [`Layout::for_value`] сыяктуу эле жүрүм-турум.
    ///     - Болбосо, бул функцияны чакырууга консервативдүү жол берилбейт.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // КООПСУЗДУК: биз ушул функциялардын өбөлгөлөрүн чалып жаткан адамга өткөрүп беребиз
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // КООПСУЗДУК: эмне үчүн кооптуу вариантты колдонуп жаткандыгын `new` негиздемесин караңыз
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Асылып турган, бирок ушул Макетке ылайыкташтырылган `NonNull` түзөт.
    ///
    /// Маанилүү көрсөткүч жарактуу көрсөткүчтү билдириши мүмкүн экендигин эске алыңыз, демек, аны "not yet initialized" кароолчу мааниси катары колдонууга болбойт.
    /// Бөлүп берген түрлөрү башка жолдор менен инициализацияны байкап турушу керек.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // КООПСУЗДУК: тегиздөө нөлгө тең келбейт
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// `self` сыяктуу макеттин маанисин камтый турган жазууну сүрөттөгөн макет түзөт, бирок `align` тегиздөөсүнө дал келет (байт менен өлчөнөт).
    ///
    ///
    /// Эгер `self` белгиленген тегиздөөгө жооп берсе, анда `self` кайтарат.
    ///
    /// Кайтарылган макет башка тегизделгенине карабастан, бул ыкма жалпы өлчөмгө эч кандай кошумча кошпой тургандыгын эске алыңыз.
    /// Башка сөз менен айтканда, эгер `K` 16 өлчөмгө ээ болсо, `K.align_to(32)` дагы деле 16 өлчөмгө ээ болот.
    ///
    /// Эгерде `self.size()` менен берилген `align` айкалышы [`Layout::from_size_align`] тизмесиндеги шарттарды бузса, ката кайтарат.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Төмөнкү дарек `align` (байт менен өлчөнөт) канааттандырылышын камсыз кылуу үчүн `self` кийин киргизген толтуруу көлөмүн кайтарып берет.
    ///
    /// мисалы, эгер `self.size()` 9 болсо, анда `self.padding_needed_for(4)` 3ти кайтарат, анткени бул 4 тегизделген даректи алуу үчүн талап кылынган эң аз байт байт саны (тиешелүү эс тутум блогу 4 тегизделген даректен башталат деп эсептесек).
    ///
    ///
    /// Бул функциянын кайтарым маанисинин мааниси жок, эгер `align` экөөнүн кубаттуулугу болбосо.
    ///
    /// Кайтарылган маанинин пайдалуулугу `align` эс тутумдун бөлүнгөн блогу үчүн баштапкы даректин тегизделишинен аз же барабар болушун талап кылат.Бул чектөөнү канааттандыруунун бир жолу-`align <= self.align()` камсыз кылуу.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Тегеректелген маани:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // андан кийин толтурулган айырманы кайтарабыз: `len_rounded_up - len`.
        //
        // Биз модулдук арифметиканы төмөнкүлөрдө колдонобуз:
        //
        // 1. тегиздөө> 0 деп кепилденет, ошондуктан тегиздөө, 1 ар дайым жарактуу.
        //
        // 2.
        // `len + align - 1` эң көп дегенде `align - 1` ашып кетиши мүмкүн, ошондуктан `!(align - 1)` менен&-маска ашып кетсе, `len_rounded_up` өзү 0 болуп калат.
        //
        //    Ошентип, `len` ге кошулганда, кайтарылган толтуруу 0 берет, бул `align` тегиздөөсүн анча-мынча канааттандырат.
        //
        // (Албетте, көлөмү жана толтурулган көлөмү жогорудагы эстутум блокторун бөлүштүрүү аракеттери, бөлүштүргүч ката кетириши керек.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Бул макеттин көлөмүн макеттин тегиздөөсүнүн эселенгенине чейин тегеректөө менен макет түзөт.
    ///
    ///
    /// Бул `padding_needed_for` натыйжасын макеттин учурдагы көлөмүнө кошууга барабар.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Бул ашып кете албайт.Макеттин инвариантынан цитата келтирүү:
        // > `size`, жакын `align` эселенгенге чейин тегеректелгенде,
        // > ашып кетпеши керек (б.а., тегеректелген маани төмөн болушу керек
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// `self` үлгүлөрүнүн `n` жазуусун сүрөттөгөн макет түзүп, ар бир нусканын талап кылынган өлчөмү жана тегиздигин камсыз кылуу үчүн ар биринин ортосунда ылайыктуу көлөмдө толтуруу менен.
    /// Ийгиликке жеткенде, `(k, offs)` кайтып келет, анда `k`-массивдин макети жана `offs`-массивдеги ар бир элементтин башталышынын ортосундагы аралык.
    ///
    /// Арифметикалык ашып кетсе, `LayoutError` кайтарып берет.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Бул ашып кете албайт.Макеттин инвариантынан цитата келтирүү:
        // > `size`, жакын `align` эселенгенге чейин тегеректелгенде,
        // > ашып кетпеши керек (б.а., тегеректелген маани төмөн болушу керек
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // КООПСУЗДУК: self.align буга чейин эле жарактуу экени белгилүү жана ал эми бөлүштүрүү көлөмү болгон
        // мурунтан эле толтурулган.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// `self` үчүн жазууну сүрөттөгөн макет түзөт, андан кийин `next`, анын ичинде `next` туура тегизделишин камсыз кылуу үчүн керектүү толтуруу, бирок *артында толтуруу жок*.
    ///
    /// C өкүлчүлүгүнүн `repr(C)` макетине дал келүү үчүн, бардык талаалар менен жайгаштырууну кеңейткенден кийин `pad_to_align` номерине чалуу керек.
    /// (`repr(Rust)`, as it is unspecified.) демейки Rust өкүлчүлүгүнүн жайгашуусуна дал келүү жолу жок
    ///
    /// Эки бөлүктүн теңдештирилишин камсыз кылуу үчүн, алынган макетти тегиздөө `self` жана `next` максимумдарын түзөрүн эске алыңыз.
    ///
    /// `Ok((k, offset))` кайтарып берет, мында `k` бириктирилген жазуунун макети, ал `offset`-байланган жазуу жазуусунун ичине орнотулган `next` башталышынын салыштырмалуу жайгашуусу (жазуунун өзү 0 жылыштан башталат деп эсептелген).
    ///
    ///
    /// Арифметикалык ашып кетсе, `LayoutError` кайтарып берет.
    ///
    /// # Examples
    ///
    /// `#[repr(C)]` структурасынын жайгашуусун жана анын талааларынын схемаларынан талаалардын жылыштарын эсептөө үчүн:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // `pad_to_align` менен аягына чыгарууну унутпаңыз!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // анын иштей тургандыгын текшерүү
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// `self` үлгүлөрүнүн `n` жазуусун сүрөттөгөн макет түзөт, ар бир нусканын ортосунда эч кандай толтуруу жок.
    ///
    /// `repeat` тен айырмаланып, `repeat_packed` `self` тин кайталанган инстанцияларынын туура тегизделишине кепилдик бербейт, ал тургай, `self` данасы туура тегизделген болсо дагы.
    /// Башка сөз менен айтканда, эгер `repeat_packed` тарабынан кайтарылган макет массивди бөлүштүрүү үчүн колдонулса, анда массивдеги бардык элементтердин туура тегизделишине кепилдик жок.
    ///
    /// Арифметикалык ашып кетсе, `LayoutError` кайтарып берет.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// `self` үчүн жазууну сүрөттөгөн макет түзүп, андан кийин `next` экөөнүн ортосунда кошумча толтуруу жок.
    /// Эч кандай толтуруу салынбагандыктан, `next` тегиздөөсү эч кандай мааниге ээ эмес жана натыйжада макетке * такыр кошулбайт.
    ///
    ///
    /// Арифметикалык ашып кетсе, `LayoutError` кайтарып берет.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// `[T; n]` үчүн жазууну сүрөттөгөн макет түзөт.
    ///
    /// Арифметикалык ашып кетсе, `LayoutError` кайтарып берет.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` же башка `Layout` конструкторуна берилген параметрлер анын документтелген чектөөлөрүн канааттандырбайт.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (биз trait катасынын төмөнкү агымындагы импл үчүн бул керек)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}