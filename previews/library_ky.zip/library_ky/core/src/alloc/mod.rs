//! Эстутумду бөлүштүрүү API'лери

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError` катасы бул бөлүштүрүү катасын көрсөтөт, бул ресурстардын түгөнгөндүгүнөн же ушул бөлүштүрүүчү менен берилген киргизүү аргументтерин айкалыштырганда туура эмес нерседен улам келип чыгышы мүмкүн.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (биз trait катасынын төмөнкү агымындагы импл үчүн бул керек)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// `Allocator` программасын ишке ашыруу [`Layout`][] аркылуу сүрөттөлгөн маалыматтардын каалаган блокторун бөлүп, өстүрүп, кичирейтип, бөлүштүрө алат.
///
/// `Allocator` ZST'лерде, маалымдамаларда же акылдуу көрсөткүчтөрдө ишке ашырылышы үчүн иштелип чыккан, анткени `MyAlloc([u8; N])` сыяктуу бөлүштүргүчтү бөлүнгөн эс тутумга жаңыртпастан, жылдырууга болбойт.
///
/// [`GlobalAlloc`][] тен айырмаланып, `Allocator` те нөлдүк өлчөмдө бөлүштүрүүгө жол берилет.
/// Эгерде негизги бөлүштүрүүчү муну колдобосо (jemalloc сыяктуу) же нөл көрсөткүчтү кайтарып берсе (мисалы, `libc::malloc`), бул ишке ашырылышы керек.
///
/// ### Учурда бөлүнгөн эс тутум
///
/// Айрым методдор эс тутум блогун * учурда бөлүштүрүүчү аркылуу бөлүштүрүүнү талап кылат.Бул дегенибиз:
///
/// * ошол эс тутумунун баштапкы дареги мурун [`allocate`], [`grow`] же [`shrink`] тарабынан кайтарылып берилген жана
///
/// * кийинчерээк эс тутуму бөлүштүрүлө элек, бул жерде блоктор [`deallocate`] ге өткөрүлүп берилип, же X002 кайтарган [`grow`] же [`shrink`] аркылуу алмаштырылган.
///
/// Эгерде `grow` же `shrink` `Err` ти кайтарып берсе, анда өткөн көрсөткүч жарактуу бойдон калат.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Эстутумга ылайыктуу
///
/// Айрым ыкмалар макет *эс тутум блогуна туура келерин талап кылат*.
/// "fit" эс тутуму үчүн макет (же эквиваленттүү, эстутум блогу "fit" макети үчүн) дегенди билдирет, төмөнкү шарттар сакталышы керек:
///
/// * Блок [`layout.align()`] сыяктуу тегиздөө менен бөлүштүрүлүшү керек, жана
///
/// * Берилген [`layout.size()`] `min ..= max` чегинде болушу керек, мында:
///   - `min` блокту бөлүштүрүү үчүн акыркы колдонулган макеттин өлчөмү жана
///   - `max` [`allocate`], [`grow`] же [`shrink`] кайтарылган акыркы чыныгы көлөмү.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Бөлүштүргүчтөн кайтарылган эстутум блоктору жарактуу эс тутумду көрсөтүп, нуска жана анын бардык клондору түшкөнгө чейин күчүн сактап турушу керек,
///
/// * бөлүштүргүчтү клондоштуруу же жылдыруу, бул бөлүштүргүчтөн кайтарылган эстутум блокторун жараксыз кылбашы керек.Клондоштурулган бөлүштүрүүчү өзүн ошол эле бөлүштүргүчтөй алып жүрүшү керек жана
///
/// * [*currently allocated*] болгон эс тутум блогуна көрсөткүч бөлүп берүүнүн башка ыкмасына өткөрүлүп берилиши мүмкүн.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Эстутум блогун бөлүү аракеттери.
    ///
    /// Ийгиликке жеткенде, `layout` өлчөмү жана тегиздөө кепилдиктерине жооп берген [`NonNull<[u8]>`][NonNull] кайтарып берет.
    ///
    /// Кайтарылган блоктун көлөмү `layout.size()` тарабынан белгиленгенден чоңураак болушу мүмкүн жана анын мазмуну башталбашы мүмкүн.
    ///
    /// # Errors
    ///
    /// `Err` кайтып келсе, эс тутумдун түгөнгөндүгүн же `layout` бөлүп берүүнүн көлөмүнө же тегиздөө чектөөлөрүнө жооп бербестигин көрсөтөт.
    ///
    /// Ишке ашыруулар `Err` ти эс-тутумду жоготуудан же чочутуудан эмес, эс-тутумуңузду кайтарып берүүгө чакырабыз, бирок бул катуу талап эмес.
    /// (Тактап айтканда: бул trait ди эс тутумдун чарчап калышын токтотуучу жергиликтүү бөлүштүрүү китепканасынын үстүнөн колдонуу * мыйзамдуу).
    ///
    /// Бөлүштүрүү катасына байланыштуу эсептөөнү токтотууну каалаган кардарларга `panic!` же ага окшош нерселерди түздөн-түз чакырбастан, [`handle_alloc_error`] функциясын чакыруу сунушталат.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// `allocate` сыяктуу жүрөт, бирок ошондой эле кайтарылган эстутум нөл-инициалдаштырылган камсыз кылат.
    ///
    /// # Errors
    ///
    /// `Err` кайтып келсе, эс тутумдун түгөнгөндүгүн же `layout` бөлүп берүүнүн көлөмүнө же тегиздөө чектөөлөрүнө жооп бербестигин көрсөтөт.
    ///
    /// Ишке ашыруулар `Err` ти эс-тутумду жоготуудан же чочутуудан эмес, эс-тутумуңузду кайтарып берүүгө чакырабыз, бирок бул катуу талап эмес.
    /// (Тактап айтканда: бул trait ди эс тутумдун чарчап калышын токтотуучу жергиликтүү бөлүштүрүү китепканасынын үстүнөн колдонуу * мыйзамдуу).
    ///
    /// Бөлүштүрүү катасына байланыштуу эсептөөнү токтотууну каалаган кардарларга `panic!` же ага окшош нерселерди түздөн-түз чакырбастан, [`handle_alloc_error`] функциясын чакыруу сунушталат.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // КООПСУЗДУК: `alloc` жарактуу эс тутумун кайтарат
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// `ptr` шилтеме берген эс тутумду бөлүштүрөт.
    ///
    /// # Safety
    ///
    /// * `ptr` ушул бөлүштүрүүчү аркылуу [*currently allocated*] эс тутумунун блогун белгилеши керек жана
    /// * `layout` эс тутуму [*fit*] болушу керек.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Эстутум блогун кеңейтүү аракеттери.
    ///
    /// Белги жана бөлүнгөн эс тутумдун чыныгы көлөмүн камтыган жаңы [`NonNull<[u8]>`][NonNull] берет.Көрсөтүүчү `new_layout` тарабынан сүрөттөлгөн маалыматтарды кармоо үчүн ылайыктуу.
    /// Муну ишке ашыруу үчүн, бөлүштүрүүчү `ptr` шилтемесин жаңы жайгаштырууга ылайыкташтыра алат.
    ///
    /// Эгер бул `Ok` кайтарып берсе, анда `ptr` шилтеме берген эстутум блогуна ээлик кылуу ушул бөлүштүргүчкө өткөн.
    /// Эстутум бошотулган же бошотулбаган болушу мүмкүн, эгерде ал ушул ыкманын кайтарым мааниси аркылуу кайра чалып жаткан адамга өткөрүлүп берилбесе, жараксыз деп табылышы керек.
    ///
    /// Эгер бул ыкма `Err` көрсөткүчүн кайтарып берсе, анда эс тутум блогуна ээлик кылуу бул бөлүштүргүчкө өткөрүлүп берилген эмес жана эс тутум блогунун мазмуну өзгөрүлбөйт.
    ///
    /// # Safety
    ///
    /// * `ptr` ушул бөлүштүрүүчү аркылуу [*currently allocated*] эс тутумунун блогун белгилеши керек.
    /// * `old_layout` эс тутуму [*fit*] болушу керек (`new_layout` аргументи ага туура келбейт.)
    /// * `new_layout.size()` `old_layout.size()` тен чоң же ага барабар болушу керек.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Эгерде жаңы схема бөлүүчүнүн өлчөмүнө жана бөлүүчүнүн тегиздөө чектөөлөрүнө жооп бербесе же башкача жол менен өспөй калса, `Err` кайтарып берет.
    ///
    /// Ишке ашыруулар `Err` ти эс-тутумду жоготуудан же чочутуудан эмес, эс-тутумуңузду кайтарып берүүгө чакырабыз, бирок бул катуу талап эмес.
    /// (Тактап айтканда: бул trait ди эс тутумдун чарчап калышын токтотуучу жергиликтүү бөлүштүрүү китепканасынын үстүнөн колдонуу * мыйзамдуу).
    ///
    /// Бөлүштүрүү катасына байланыштуу эсептөөнү токтотууну каалаган кардарларга `panic!` же ага окшош нерселерди түздөн-түз чакырбастан, [`handle_alloc_error`] функциясын чакыруу сунушталат.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // КООПСУЗДУК: анткени `new_layout.size()` чоң же барабар болушу керек
        // `old_layout.size()`, эски жана жаңы эс бөлүү `old_layout.size()` байт үчүн окуу жана жазуу үчүн жарактуу.
        // Ошондой эле, эски бөлүштүрүү али бөлүштүрүлө элек болгондуктан, `new_ptr` менен кайталана албайт.
        // Ошентип, `copy_nonoverlapping` ке чалуу коопсуз.
        // `dealloc` үчүн коопсуздук келишими чалган адам тарабынан сакталууга тийиш.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `grow` сыяктуу жүрөт, бирок ошондой эле жаңы мазмунду кайтаруудан мурун нөлгө койгонун кепилдейт.
    ///
    /// Эстутум блогу ийгиликтүү чалгандан кийин төмөнкү мазмунду камтыйт
    /// `grow_zeroed`:
    ///   * `0..old_layout.size()` байт баштапкы бөлүштүрүүдөн сакталып калган.
    ///   * Байт `old_layout.size()..old_size` бөлүштүргүчтү ишке ашырууга жараша сакталып калат же нөлгө түшүрүлөт.
    ///   `old_size` `grow_zeroed` чалуусунан мурунку эс тутумунун өлчөмүн билдирет, ал бөлүнгөндө алгач суралган өлчөмдөн чоңураак болушу мүмкүн.
    ///   * `old_size..new_size` байттары нөлгө түшүрүлдү.`new_size` `grow_zeroed` чалуусунан кайтарылган эс тутумунун көлөмүн билдирет.
    ///
    /// # Safety
    ///
    /// * `ptr` ушул бөлүштүрүүчү аркылуу [*currently allocated*] эс тутумунун блогун белгилеши керек.
    /// * `old_layout` эс тутуму [*fit*] болушу керек (`new_layout` аргументи ага туура келбейт.)
    /// * `new_layout.size()` `old_layout.size()` тен чоң же ага барабар болушу керек.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Эгерде жаңы схема бөлүүчүнүн өлчөмүнө жана бөлүүчүнүн тегиздөө чектөөлөрүнө жооп бербесе же башкача жол менен өспөй калса, `Err` кайтарып берет.
    ///
    /// Ишке ашыруулар `Err` ти эс-тутумду жоготуудан же чочутуудан эмес, эс-тутумуңузду кайтарып берүүгө чакырабыз, бирок бул катуу талап эмес.
    /// (Тактап айтканда: бул trait ди эс тутумдун чарчап калышын токтотуучу жергиликтүү бөлүштүрүү китепканасынын үстүнөн колдонуу * мыйзамдуу).
    ///
    /// Бөлүштүрүү катасына байланыштуу эсептөөнү токтотууну каалаган кардарларга `panic!` же ага окшош нерселерди түздөн-түз чакырбастан, [`handle_alloc_error`] функциясын чакыруу сунушталат.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // КООПСУЗДУК: анткени `new_layout.size()` чоң же барабар болушу керек
        // `old_layout.size()`, эски жана жаңы эс бөлүү `old_layout.size()` байт үчүн окуу жана жазуу үчүн жарактуу.
        // Ошондой эле, эски бөлүштүрүү али бөлүштүрүлө элек болгондуктан, `new_ptr` менен кайталана албайт.
        // Ошентип, `copy_nonoverlapping` ке чалуу коопсуз.
        // `dealloc` үчүн коопсуздук келишими чалган адам тарабынан сакталууга тийиш.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Эстутум блогун кичирейтүү аракеттери.
    ///
    /// Белги жана бөлүнгөн эс тутумдун чыныгы көлөмүн камтыган жаңы [`NonNull<[u8]>`][NonNull] берет.Көрсөтүүчү `new_layout` тарабынан сүрөттөлгөн маалыматтарды кармоо үчүн ылайыктуу.
    /// Муну ишке ашыруу үчүн, бөлүштүрүүчү `ptr` шилтемесин жаңы жайгаштырууга ылайыкташтырышы мүмкүн.
    ///
    /// Эгер бул `Ok` кайтарып берсе, анда `ptr` шилтеме берген эстутум блогуна ээлик кылуу ушул бөлүштүргүчкө өткөн.
    /// Эстутум бошотулган же бошотулбаган болушу мүмкүн, эгерде ал ушул ыкманын кайтарым мааниси аркылуу кайра чалып жаткан адамга өткөрүлүп берилбесе, жараксыз деп табылышы керек.
    ///
    /// Эгер бул ыкма `Err` көрсөткүчүн кайтарып берсе, анда эс тутум блогуна ээлик кылуу бул бөлүштүргүчкө өткөрүлүп берилген эмес жана эс тутум блогунун мазмуну өзгөрүлбөйт.
    ///
    /// # Safety
    ///
    /// * `ptr` ушул бөлүштүрүүчү аркылуу [*currently allocated*] эс тутумунун блогун белгилеши керек.
    /// * `old_layout` эс тутуму [*fit*] болушу керек (`new_layout` аргументи ага туура келбейт.)
    /// * `new_layout.size()` `old_layout.size()` тен кичине же ага барабар болушу керек.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Эгерде жаңы схема бөлүүчүнүн көлөмүнө жана бөлүүчүнүн тегиздөө чектөөлөрүнө жооп бербесе же башкача түрдө кичирейип калбаса, `Err` кайтарып берет.
    ///
    /// Ишке ашыруулар `Err` ти эс-тутумду жоготуудан же чочутуудан эмес, эс-тутумуңузду кайтарып берүүгө чакырабыз, бирок бул катуу талап эмес.
    /// (Тактап айтканда: бул trait ди эс тутумдун чарчап калышын токтотуучу жергиликтүү бөлүштүрүү китепканасынын үстүнөн колдонуу * мыйзамдуу).
    ///
    /// Бөлүштүрүү катасына байланыштуу эсептөөнү токтотууну каалаган кардарларга `panic!` же ага окшош нерселерди түздөн-түз чакырбастан, [`handle_alloc_error`] функциясын чакыруу сунушталат.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // КООПСУЗДУК: анткени `new_layout.size()` төмөн же ага барабар болушу керек
        // `old_layout.size()`, эски жана жаңы эс бөлүү `new_layout.size()` байт үчүн окуу жана жазуу үчүн жарактуу.
        // Ошондой эле, эски бөлүштүрүү али бөлүштүрүлө элек болгондуктан, `new_ptr` менен кайталана албайт.
        // Ошентип, `copy_nonoverlapping` ке чалуу коопсуз.
        // `dealloc` үчүн коопсуздук келишими чалган адам тарабынан сакталууга тийиш.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Бул `Allocator` мисалы үчүн "by reference" адаптерин түзөт.
    ///
    /// Кайтып келген адаптер `Allocator` ти ишке ашырат жана жөн гана карызга алат.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // КООПСУЗДУК: коопсуздук келишимин чалган адам сакташы керек
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // КООПСУЗДУК: коопсуздук келишимин чалган адам сакташы керек
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // КООПСУЗДУК: коопсуздук келишимин чалган адам сакташы керек
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // КООПСУЗДУК: коопсуздук келишимин чалган адам сакташы керек
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}