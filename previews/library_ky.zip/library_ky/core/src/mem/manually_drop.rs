use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Компиляторду "Т" деструкторун автоматтык түрдө чалуудан сактай турган ором.
/// Бул ором 0 чыгымдарды талап кылат.
///
/// `ManuallyDrop<T>` `T` сыяктуу макет оптимизациясына дуушар болот.
/// Натыйжада, компилятор анын мазмунуна байланыштуу божомолдорго эч кандай таасир этпейт.
/// Мисалы, `ManuallyDrop<&mut T>` ти [`mem::zeroed`] менен инициалдаштыруу-бул аныкталбаган жүрүм-турум.
/// Эгер сиз башталбаган маалыматты иштетишиңиз керек болсо, анын ордуна [`MaybeUninit<T>`] колдонуңуз.
///
/// `ManuallyDrop<T>` ичиндеги мааниге кирүү коопсуз экендигин унутпаңыз.
/// Бул мазмуну ташталган `ManuallyDrop<T>` жалпыга ачык API аркылуу ачыкка чыкпашы керек дегенди билдирет.
/// Демек, `ManuallyDrop::drop` кооптуу.
///
/// # `ManuallyDrop` жана заказды таштаңыз.
///
/// Rust аныкталган [drop order] баалуулуктарга ээ.
/// Талаа же жергиликтүү тургундар белгилүү бир тартипте ташталганына ынануу үчүн, декларацияларды жашыруун таштоо буйругу туура болгондой кылып иреттеңиз.
///
/// Төмөнкү буйрукту көзөмөлдөө үчүн `ManuallyDrop` колдонсо болот, бирок бул кооптуу кодду талап кылат жана ачуу болгондо аны туура жасоо кыйын.
///
///
/// Мисалы, белгилүү бир талаа башкалардан кийин ташталганына ынангыңыз келсе, аны структуранын акыркы талаасы кылыңыз:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` кийин ташталат.
///     // Rust декларация иретинде талаалардын түшүрүлүшүнө кепилдик берет.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Кол менен түшүрүлүүчү маанини ороп коюңуз.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Сиз дагы деле коопсуз мааниси боюнча иштей алат
    /// assert_eq!(*x, "Hello");
    /// // Бирок `Drop` бул жерде иштетилбейт
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// `ManuallyDrop` контейнеринен бааны бөлүп алат.
    ///
    /// Бул маанини кайрадан түшүрүүгө мүмкүнчүлүк берет.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Бул `Box` төмөндөйт.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// `ManuallyDrop<T>` контейнериндеги маанини алып чыгат.
    ///
    /// Бул ыкма, биринчи кезекте, маанилерди тамчы менен жылдырууга арналган.
    /// [`ManuallyDrop::drop`] колдонуп, маанини кол менен түшүрүүнүн ордуна, ушул ыкманы колдонуп, маанини алып, каалаганча колдонсоңуз болот.
    ///
    /// Мүмкүн болушунча, анын ордуна [`into_inner`][`ManuallyDrop::into_inner`] ти колдонуу артык, бул `ManuallyDrop<T>` тин мазмунун кайталоого жол бербейт.
    ///
    ///
    /// # Safety
    ///
    /// Бул функция кошумча контейнердин маанисин өзгөртпөстөн, камтылган маанини маанилик жактан алып чыгат.
    /// Бул `ManuallyDrop` кайрадан колдонулбашы үчүн, сиздин милдетиңиз.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // КООПСУЗДУК: биз кепилденген маалымдамадан окуп жатабыз
        // окуу үчүн жарактуу болушу керек.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Камтылган маанисин кол менен түшүрөт.Бул камтылган мааниге көрсөткүч менен [`ptr::drop_in_place`] чакырууга барабар.
    /// Ушундайча, камтылган маани топтолгон структура болбосо, деструктор маанисин жылдырбастан ордунда чакырылат жана ошону менен [pinned] маалыматтарын коопсуз таштоо үчүн колдонсо болот.
    ///
    /// Эгер сиз баалуулукка ээ болсоңуз, анын ордуна [`ManuallyDrop::into_inner`] колдоно аласыз.
    ///
    /// # Safety
    ///
    /// Бул функция камтылган маанинин деструкторун иштетет.
    /// Деструктор өзү жасаган өзгөрүүлөрдөн тышкары, эс тутуму өзгөрүүсүз калат, ал эми компилятор `T` түрү үчүн жарактуу болгон бир аз үлгү кармайт.
    ///
    ///
    /// Бирок, бул "zombie" мааниси коопсуз кодго дуушар болбошу керек жана бул функцияны бир нече жолу атоого болбойт.
    /// Чоңдукту түшүргөндөн кийин аны колдонуу же бир нече жолу түшүрүп салуу, аныкталбаган жүрүм-турумга алып келиши мүмкүн (`drop` кылганга жараша).
    /// Адатта, бул тип системасы тарабынан алдын-алынат, бирок `ManuallyDrop` колдонуучулары ошол кепилдиктерди компилятордун жардамысыз эле сакташы керек.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // КООПСУЗДУК: өзгөрүлмө шилтеме көрсөткөн маанини түшүрүп жатабыз
        // жазуу үчүн жарактуу деп кепилденген.
        // `slot` кайрадан түшүп калбашы үчүн, чалган адамга көз каранды.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}