use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// `T` инициализацияланбаган учурларын куруу үчүн ором түрү.
///
/// # Инициализация инвариант
///
/// Компилятор, жалпысынан, өзгөрүлмө түрүнүн талаптарына ылайык өзгөрүлмө туура инициализацияланган деп эсептейт.Мисалы, шилтеме түрүндөгү өзгөрүлмө NULL болбошу керек.
/// Бул инвариант, аны *ар дайым* сактоо керек, кооптуу коддордо дагы.
/// Натыйжада, шилтеме түрүндөгү өзгөрмөнү нөлгө киргизүү, [undefined behavior][ub] заматта пайда кылат, бул шилтеме эс тутумга жетүү үчүн көнүп калбасын.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // аныкталбаган жүрүм-турум!⚠️
/// // `MaybeUninit<&i32>` менен барабар код:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // аныкталбаган жүрүм-турум!⚠️
/// ```
///
/// Бул компилятор тарабынан ар кандай оптималдаштыруу үчүн колдонулат, мисалы, иштөө убактысын текшерүү жана `enum` планын оптималдаштыруу.
///
/// Ошо сыяктуу эле, толугу менен инициализацияланбаган эстутумда кандайдыр бир мазмун болушу мүмкүн, ал эми `bool` ар дайым `true` же `false` болушу керек.Демек, башталбаган `bool` түзүү-аныкталбаган жүрүм-турум:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // аныкталбаган жүрүм-турум!⚠️
/// // `MaybeUninit<bool>` менен барабар код:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // аныкталбаган жүрүм-турум!⚠️
/// ```
///
/// Анын үстүнө, инициализацияланбаган эс тутумдун туруктуу мааниси жоктугу өзгөчө ("fixed" "it won't change without being written to" маанисин билдирет).Бир эле башталбаган байтты бир нече жолу окуу ар кандай натыйжаларды бериши мүмкүн.
/// Бул өзгөрүлмө бүтүндөй түргө ээ болсо дагы, кандайдыр бир *туруктуу* бит үлгүсүн камтый турган болсо дагы, инициализацияланбаган маалыматтардын өзгөрүлмө болушун аныктайт.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // аныкталбаган жүрүм-турум!⚠️
/// // `MaybeUninit<i32>` менен барабар код:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // аныкталбаган жүрүм-турум!⚠️
/// ```
/// (Баштала элек бүтүн сандардын тегерегиндеги эрежелер азырынча аягына чыга электигине көңүл буруңуз, бирок алар бүткүчө, алардан алыс болуңуз.)
///
/// Анын үстүнө, көпчүлүк типтеги типтеги деңгээлде инициалдаштырылгандан тышкары кошумча инварианттар бар экендигин унутпаңыз.
/// Мисалы, `1`-инициалдаштырылган [`Vec<T>`] инициалдаштырылган деп эсептелет (учурдагы ишке ашыруу шартында; бул туруктуу кепилдикти түзбөйт), анткени компилятордун бирден-бир талабы, маалымат көрсөткүчү нөл болбошу керек.
/// Мындай `Vec<T>` түзүү *дароо* аныкталбаган жүрүм-турумга алып келбейт, бирок көпчүлүк коопсуз иш-аракеттер (анын ичинде аны таштоо) менен аныкталбаган жүрүм-турумга алып келет.
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` кооптуу кодду баштапкы берилиштер менен иштөөгө мүмкүнчүлүк берет.
/// Бул бул жердеги маалыматтар инициалдаштырылбашы мүмкүн экендигин көрсөткөн түзүүчүгө сигнал:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Ачык башталбаган шилтеме түзүңүз.
/// // Компилятор `MaybeUninit<T>` ичиндеги маалыматтар жараксыз болушу мүмкүн экендигин билет, демек бул UB эмес:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Аны жарактуу мааниге кой.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Баштапкы маалыматты көчүрүп алыңыз-буга `x` туура башталгандан кийин гана * уруксат берилет!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Андан кийин түзүүчү бул код боюнча туура эмес божомолдорду же оптимизацияларды жасабоону билет.
///
/// Сиз `MaybeUninit<T>` ти `Option<T>` сыяктуу бир аз деп эсептесеңиз болот, бирок иштөө убактысын көзөмөлдөбөй жана коопсуздукту текшербестен.
///
/// ## out-pointers
///
/// "out-pointers" ти ишке ашыруу үчүн `MaybeUninit<T>` колдонсоңуз болот: функциялардан маалыматтарды кайтаруунун ордуна, (uninitialized) эс тутумуна көрсөткүчтү өткөрүп, натыйжаны киргизиңиз.
/// Чакыруучу эс-тутумдун кандайча сакталып калышын көзөмөлдөп, керексиз кадамдардан алыс болгуңуз келсе, бул пайдалуу болушу мүмкүн.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` эски мазмунун таштабайт, бул маанилүү.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Эми биз билебиз `v` инициалдаштырылган!Бул ошондой эле vector туура түшүп калганына ынандырат.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Массивдин элементтерин инициализациялоо
///
/// `MaybeUninit<T>` массивдин ар бир элементин инициализациялоо үчүн колдонсо болот:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Баштала элек `MaybeUninit` массивин түзүңүз.
///     // `assume_init` коопсуз, анткени биз бул жерде баштапкы инициалды баштадык деп талап кылып жаткан түр, балким, инициализацияны талап кылбаган "MaybeUninit" топтому.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // `MaybeUninit` ти таштоо эч нерсе кылбайт.
///     // Ошентип, `ptr::write` ордуна чийки көрсөткүч дайындоосун колдонуу эски инициализацияланбаган маанинин түшүшүнө алып келбейт.
/////
///     // Ошондой эле, эгер ушул цикл учурунда panic бар болсо, бизде эс тутумдун агып чыгышы бар, бирок эс тутумдун коопсуздугуна байланыштуу маселе жок.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Баары башталды.
///     // Массивди баштапкы түргө өткөрүңүз.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Ошондой эле, төмөнкү деңгээлдеги түзүмдөрдөн табылган жарым-жартылай инициалдаштырылган массивдер менен иштесеңиз болот.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Баштала элек `MaybeUninit` массивин түзүңүз.
/// // `assume_init` коопсуз, анткени биз бул жерде баштапкы инициалды баштадык деп талап кылып жаткан түр, балким, инициализацияны талап кылбаган "MaybeUninit" топтому.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Биз дайындаган элементтердин санын эсептөө.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Массивдеги ар бир нерсе үчүн, эгерде биз аны бөлүп берсек, түшүрүңүз.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Ар бир талаа структурасын баштоо
///
/// Сиз структураларды талаа боюнча инициализациялоо үчүн `MaybeUninit<T>` жана [`std::ptr::addr_of_mut`] макросун колдоно аласыз:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` талаасын инициализациялоо
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` талаасын инициализациялоо Эгерде бул жерде panic бар болсо, анда `name` талаасындагы `String` агып чыгат.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Бардык талаалар инициалдаштырылган, андыктан инициалдаштырылган Foo алуу үчүн `assume_init` номерине чалабыз.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` `T` сыяктуу көлөмү, тегиздиги жана ABI бар экендигине кепилдик берилет:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Бирок `MaybeUninit<T>` камтылган * түрү сөзсүз түрдө бир эле макет эмес экендигин унутпаңыз;Rust жалпысынан `Foo<T>` талаалары `T` жана `U` көлөмү жана тегиздиги бирдей болсо дагы, `Foo<U>` сыяктуу тартипке ээ деп кепилдик бербейт.
///
/// Мындан тышкары, `MaybeUninit<T>` үчүн кандайдыр бир биттик маани жарактуу болгондуктан, компилятор non-zero/niche-filling оптимизациясын колдоно албайт, натыйжада чоңураак өлчөмгө алып келет:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Эгерде `T` FFI-коопсуз болсо, анда `MaybeUninit<T>` да ошондой болот.
///
/// `MaybeUninit` `#[repr(transparent)]` болсо (ал `T` менен бирдей өлчөмдө, тегизделүүдө жана АБИде кепилдик берет), бул мурунку эскертүүлөрдүн эч бирин өзгөртпөйт *.
/// `Option<T>` жана `Option<MaybeUninit<T>>` дагы деле ар кандай өлчөмгө ээ болушу мүмкүн, ал эми `T` типтеги талааны камтыган типтер ал талаа `MaybeUninit<T>` болгондон башкача жайгаштырылышы (жана өлчөмдө) болушу мүмкүн.
/// `MaybeUninit` бирикменин түрү, ал эми профсоюздардагы `#[repr(transparent)]` туруксуз (караңыз: [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Убакыттын өтүшү менен `#[repr(transparent)]` тин кесиптик бирликтердеги так кепилдиктери өзгөрүлүп, `MaybeUninit` `#[repr(transparent)]` бойдон кала бериши мүмкүн.
/// Айткандай, `MaybeUninit<T>` анын көлөмү, тегиздиги жана XIX менен бирдей ABI экендигине *ар дайым* кепилдик берет;жөн гана `MaybeUninit` кепилдикти ишке ашыруу жолу өнүгүшү мүмкүн.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Башка түрлөрүн ороп алгыдай кылып, буюмду тандаңыз.Бул генераторлор үчүн пайдалуу.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()` чалуу эмес, биз ал үчүн жетиштүү инициалдаштырылган жокпу, биле албайбыз.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Берилген маани менен инициалдаштырылган жаңы `MaybeUninit<T>` түзөт.
    /// Бул функциянын кайтарым наркы боюнча [`assume_init`] номерине чалсаңыз болот.
    ///
    /// Эскертүү, `MaybeUninit<T>` ти түшүрсөңүз, "T" тамчы кодун эч качан чакырбайт.
    /// `T` инициалдаштырылган болсо, анын түшүп кетишин камсыз кылуу сиздин милдетиңиз.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Башталбаган абалда жаңы `MaybeUninit<T>` түзөт.
    ///
    /// Эскертүү, `MaybeUninit<T>` ти түшүрсөңүз, "T" тамчы кодун эч качан чакырбайт.
    /// `T` инициалдаштырылган болсо, анын түшүп кетишин камсыз кылуу сиздин милдетиңиз.
    ///
    /// Айрым мисалдар үчүн [type-level documentation][MaybeUninit] караңыз.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Башталбаган абалда `MaybeUninit<T>` элементтеринин жаңы массивин түзүңүз.
    ///
    /// Note: future Rust версиясында бул ыкма массивдин түзмө-түз синтаксиси [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) уруксат бергенде керексиз болуп калышы мүмкүн.
    ///
    /// Төмөндөгү мисалда `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` колдонсо болот.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Чындыгында окулган (мүмкүн кичине) маалыматтардын бир бөлүгүн кайтарып берет
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // КООПСУЗДУК: Башталбаган `[MaybeUninit<_>; LEN]` жарактуу.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Эстутум `0` байт менен толтурулуп, башталбаган абалда жаңы `MaybeUninit<T>` түзөт.Бул буга чейин туура инициалдаштырууну талап кылабы же жокпу, `T` тен көз каранды.
    ///
    /// Мисалы, `MaybeUninit<usize>::zeroed()` инициалдаштырылган, бирок `MaybeUninit<&'static i32>::zeroed()` эмес, себеби шилтемелер нөл болбошу керек.
    ///
    /// Эскертүү, `MaybeUninit<T>` ти түшүрсөңүз, "T" тамчы кодун эч качан чакырбайт.
    /// `T` инициалдаштырылган болсо, анын түшүп кетишин камсыз кылуу сиздин милдетиңиз.
    ///
    /// # Example
    ///
    /// Бул функцияны туура колдонуу: структураны нөл менен баштоо, мында структуранын бардык талаалары бит үлгүсүн 0 жарактуу маани катары сактай алат.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Туура эмес* бул функцияны колдонуу: `0` түрү үчүн жарактуу бит үлгүсү болбогондо, `x.zeroed().assume_init()` чакыруу:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Жуптун ичинде биз жарактуу дискриминантка ээ болбогон `NotZero` түзөбүз.
    /// // Бул аныкталбаган жүрүм-турум.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // КООПСУЗДУК: бөлүнгөн эс тутумга `u.as_mut_ptr()` балл.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// `MaybeUninit<T>` маанисин белгилейт.
    /// Бул мурунку маанини түшүрбөй эле үстүнөн жазат, андыктан деструкторду иштетип жиберүүнү каалабасаңыз, муну эки жолу колдонуудан сак болуңуз.
    ///
    /// Сиздин ыңгайлуулугуңуз үчүн, бул `self` мазмунуна (азыр коопсуз инициализацияланган) өзгөрүлмө шилтемесин кайтарып берет.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // КООПСУЗДУК: Биз жаңы эле ушул маанидеги инициалды баштадык.
        unsafe { self.assume_init_mut() }
    }

    /// Камтылган мааниге көрсөткүчтү алат.
    /// Бул көрсөткүчтөн окуу же аны шилтемеге айландыруу, `MaybeUninit<T>` инициалдаштырылбаса, аныкталбаган кыймыл-аракет.
    /// Бул көрсөткүч (non-transitively) көрсөткөн эс тутумга жазуу аныкталбаган жүрүм-турум (`UnsafeCell<T>` ичинен тышкары).
    ///
    /// # Examples
    ///
    /// Бул ыкманы туура колдонуу:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<T>` ке шилтеме түзүңүз.Бул туура, анткени биз аны демилгеледик.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// Бул ыкманын *туура эмес* колдонулушу:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Баштала элек vector шилтемесин түздүк!Бул аныкталбаган жүрүм-турум.⚠️
    /// ```
    ///
    /// (Баштала элек маалыматтарга шилтемелердин айланасындагы эрежелер азырынча аягына чыга электигине көңүл буруңуз, бирок алар бүткүчө, андан алыс болуңуз.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` жана `ManuallyDrop` экөө тең `repr(transparent)`, андыктан көрсөткүчтү бере алабыз.
        self as *const _ as *const T
    }

    /// Камтылган мааниге өзгөрүлмө көрсөткүчтү алат.
    /// Бул көрсөткүчтөн окуу же аны шилтемеге айландыруу, `MaybeUninit<T>` инициалдаштырылбаса, аныкталбаган кыймыл-аракет.
    ///
    /// # Examples
    ///
    /// Бул ыкманы туура колдонуу:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<Vec<u32>>` ке шилтеме түзүңүз.
    /// // Бул туура, анткени биз аны демилгеледик.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// Бул ыкманын *туура эмес* колдонулушу:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Баштала элек vector шилтемесин түздүк!Бул аныкталбаган жүрүм-турум.⚠️
    /// ```
    ///
    /// (Баштала элек маалыматтарга шилтемелердин айланасындагы эрежелер азырынча аягына чыга электигине көңүл буруңуз, бирок алар бүткүчө, андан алыс болуңуз.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` жана `ManuallyDrop` экөө тең `repr(transparent)`, андыктан көрсөткүчтү бере алабыз.
        self as *mut _ as *mut T
    }

    /// `MaybeUninit<T>` контейнеринен бааны бөлүп алат.Бул маалыматтардын түшүп кетишин камсыз кылуунун эң сонун жолу, анткени алынган `T` кадимки тамчы менен иштөөгө тийиш.
    ///
    /// # Safety
    ///
    /// Чакырган адам `MaybeUninit<T>` чындыгында баштапкы абалда экендигине кепилдик бере алат.Мазмун толук кандуу баштала элек учурда, муну тез арада аныкталбаган жүрүм-турумга алып келет.
    /// [type-level documentation][inv] инициализациясы инвариант жөнүндө көбүрөөк маалыматты камтыйт.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Анын үстүнө, көпчүлүк типтеги типтеги деңгээлде инициалдаштырылгандан тышкары кошумча инварианттар бар экендигин унутпаңыз.
    /// Мисалы, `1`-инициалдаштырылган [`Vec<T>`] инициалдаштырылган деп эсептелет (учурдагы ишке ашыруу шартында; бул туруктуу кепилдикти түзбөйт), анткени компилятордун бирден-бир талабы, маалымат көрсөткүчү нөл болбошу керек.
    ///
    /// Мындай `Vec<T>` түзүү *дароо* аныкталбаган жүрүм-турумга алып келбейт, бирок көпчүлүк коопсуз иш-аракеттер (анын ичинде аны таштоо) менен аныкталбаган жүрүм-турумга алып келет.
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Бул ыкманы туура колдонуу:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// Бул ыкманын *туура эмес* колдонулушу:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` баштала элек болгондуктан, бул акыркы сап аныкталбаган жүрүм-турумга себеп болду.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // КООПСУЗДУК: чалган адам `self` инициализациялангандыгына кепилдик бериши керек.
        // Бул ошондой эле `self` `value` варианты болушу керек дегенди билдирет.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// `MaybeUninit<T>` контейнериндеги маанини окуйт.Натыйжада, `T` тамчы менен кадимкидей иштөөгө тийиш.
    ///
    /// Мүмкүн болушунча, анын ордуна [`assume_init`] ти колдонуу артык, бул `MaybeUninit<T>` тин мазмунун кайталоого жол бербейт.
    ///
    /// # Safety
    ///
    /// Чакырган адам `MaybeUninit<T>` чындыгында баштапкы абалда экендигине кепилдик бере алат.Мазмун толук кандуу баштала элек кезде муну атоо аныкталбаган жүрүм-турумга себеп болот.
    /// [type-level documentation][inv] инициализациясы инвариант жөнүндө көбүрөөк маалыматты камтыйт.
    ///
    /// Мындан тышкары, бул ошол эле маалыматтардын көчүрмөсүн `MaybeUninit<T>` артында калтырат.
    /// Берилген маалыматтардын бир нече көчүрмөсүн колдонууда (`assume_init_read` телефон номерине бир нече жолу чалып, же алгач `assume_init_read`, андан кийин [`assume_init`] чалуу аркылуу), чындыгында, ушул маалыматтардын кайталанышын камсыз кылуу сизге жүктөлөт.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Бул ыкманы туура колдонуу:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` `Copy` болуп саналат, ошондуктан биз бир нече жолу окуй алабыз.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` маанисин копиялоо туура, андыктан бир нече жолу окусак болот.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// Бул ыкманын *туура эмес* колдонулушу:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Эми биз бир эле vector дин эки нускасын түзүп, экөө тең түшүп калгандан кийин эки эселенген ⚠️ге алып келдик!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // КООПСУЗДУК: чалган адам `self` инициализациялангандыгына кепилдик бериши керек.
        // `self.as_ptr()` тен окуу коопсуз, анткени `self` инициалдаштырылышы керек.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Камтылган маанисин ордуна таштайт.
    ///
    /// Эгер сизде `MaybeUninit` ээси болсо, анын ордуна [`assume_init`] колдонсоңуз болот.
    ///
    /// # Safety
    ///
    /// Чакырган адам `MaybeUninit<T>` чындыгында баштапкы абалда экендигине кепилдик бере алат.Мазмун толук кандуу баштала элек кезде муну атоо аныкталбаган жүрүм-турумга себеп болот.
    ///
    /// Анын үстүнө, `T` типтеги бардык кошумча инварианттар канааттандырылышы керек, анткени `T` (же анын мүчөлөрү) `Drop` ишке ашырылышы буга ишениши мүмкүн.
    /// Мисалы, `1`-инициалдаштырылган [`Vec<T>`] инициалдаштырылган деп эсептелет (учурдагы ишке ашыруу шартында; бул туруктуу кепилдикти түзбөйт), анткени компилятордун бирден-бир талабы, маалымат көрсөткүчү нөл болбошу керек.
    ///
    /// Мындай `Vec<T>` ти түшүрсөңүз, аныкталбаган жүрүм-турумга себеп болот.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // КООПСУЗДУК: чалган адам `self` инициалдаштырылгандыгына кепилдик бериши керек
        // `T` бардык инварианттарын канааттандырат.
        // Эгерде андай болсо, маанини жерге таштоо коопсуз болот.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Камтылган мааниге жалпы шилтеме алат.
    ///
    /// Бул ишке киргизилген, бирок `MaybeUninit` (`.assume_init()`) колдонулушуна жол бербей) ээ болгон `MaybeUninit` ке жеткиңиз келсе, пайдалуу болушу мүмкүн.
    ///
    /// # Safety
    ///
    /// Мазмун толук баштала элек кезде муну атаса, аныкталбаган жүрүм-турум пайда болот: `MaybeUninit<T>` чындыгында баштапкы абалда экендигине кепилдик берүү чалуучунун колунда.
    ///
    ///
    /// # Examples
    ///
    /// ### Бул ыкманы туура колдонуу:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` инициализациясы:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Эми биздин `MaybeUninit<_>` инициалдаштырылгандыгы белгилүү болгондон кийин, ага жалпы шилтеме түзсө болот:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // КООПСУЗДУК: `x` башталды.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### Бул ыкманын * туура эмес колдонулушу:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Баштала элек vector шилтемесин түздүк!Бул аныкталбаган жүрүм-турум.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `Cell::set` колдонуп `MaybeUninit` инициализациясы:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Баштала элек `Cell<bool>` ке шилтеме: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // КООПСУЗДУК: чалган адам `self` инициализациялангандыгына кепилдик бериши керек.
        // Бул ошондой эле `self` `value` варианты болушу керек дегенди билдирет.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Камтылган мааниге өзгөрүлмө (unique) шилтемесин алат.
    ///
    /// Бул ишке киргизилген, бирок `MaybeUninit` (`.assume_init()`) колдонулушуна жол бербей) ээ болгон `MaybeUninit` ке жеткиңиз келсе, пайдалуу болушу мүмкүн.
    ///
    /// # Safety
    ///
    /// Мазмун толук баштала элек кезде муну атаса, аныкталбаган жүрүм-турум пайда болот: `MaybeUninit<T>` чындыгында баштапкы абалда экендигине кепилдик берүү чалуучунун колунда.
    /// Мисалы, `.assume_init_mut()` ти `MaybeUninit` инициализациясы үчүн колдонууга болбойт.
    ///
    /// # Examples
    ///
    /// ### Бул ыкманы туура колдонуу:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Киргизүү буферинин *бардык* байттарын инициализациялайт.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf` инициализациясы:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Эми биз `buf` инициализациялангандыгын билебиз, андыктан аны `.assume_init()` кылышыбыз мүмкүн.
    /// // Бирок, `.assume_init()` ти колдонуу 2048 байттын `memcpy` түрткү бериши мүмкүн.
    /// // Биздин буфер аны көчүрбөстөн башталды деп ырастоо үчүн, биз `&mut MaybeUninit<[u8; 2048]>` ти `&mut [u8; 2048]` ге көтөрөбүз:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // КООПСУЗДУК: `buf` башталды.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Эми биз `buf` ти кадимки кесинди катары колдоно алабыз:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### Бул ыкманын * туура эмес колдонулушу:
    ///
    /// Маанилүү инициалдаштыруу үчүн `.assume_init_mut()` колдоно албайсыз:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Баштала элек `bool` ке (mutable) шилтемесин түздүк!
    ///     // Бул аныкталбаган жүрүм-турум.⚠️
    /// }
    /// ```
    ///
    /// Мисалы, баштала элек буферге [`Read`] жасай албайсыз:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) инициализацияланбаган эстутумга шилтеме!
    ///                             // Бул аныкталбаган жүрүм-турум.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Акырындык менен инициалдаштырууну жүргүзүү үчүн түз талаа мүмкүнчүлүгүн колдоно албайсыз:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) инициализацияланбаган эстутумга шилтеме!
    ///                  // Бул аныкталбаган жүрүм-турум.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) инициализацияланбаган эстутумга шилтеме!
    ///                  // Бул аныкталбаган жүрүм-турум.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Учурда биз жогоруда айтылгандардын туура эместигине ишенебиз, башкача айтканда, бизде инициализацияланбаган маалыматтарга шилтемелер бар (мисалы, `libcore/fmt/float.rs` де).
    // Стабилизациядан мурун эрежелер боюнча акыркы чечимди кабыл алышыбыз керек.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // КООПСУЗДУК: чалган адам `self` инициализациялангандыгына кепилдик бериши керек.
        // Бул ошондой эле `self` `value` варианты болушу керек дегенди билдирет.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// `MaybeUninit` контейнерлеринин массивинен баалуулуктарды бөлүп алат.
    ///
    /// # Safety
    ///
    /// Массивдин бардык элементтери инициалдаштырылган абалда экендигине кепилдик берүү чалуучунун колунда.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // КООПСУЗДУК: Эми бардык элементтерди баштапкы сапатка киргизгенде коопсуз
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Чакыруучу массивдин бардык элементтеринин инициализациялангандыгына кепилдик берет
        // * `MaybeUninit<T>` жана Tдин бирдей жайгашуусуна кепилдик берилет
        // * Балким, Unnint түшпөйт, ошондуктан эки жолу эркиндик жок, ошондуктан конверсия коопсуз болот
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Бардык элементтер инициалдаштырылган деп эсептесеңиз, аларга бир кесим алыңыз.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` элементтеринин чындыгында баштапкы абалда экендигине кепилдик берүү чалуучунун колунда.
    ///
    /// Мазмун толук кандуу баштала элек кезде муну атоо аныкталбаган жүрүм-турумга алып келет.
    ///
    /// Көбүрөөк маалымат жана мисал үчүн [`assume_init_ref`] караңыз.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // КООПСУЗДУК: кесимди `*const [T]` кө куюу коопсуз, анткени чалган адам кепилдик берет
        // `slice` инициализацияланган жана "Балким, Uninit" `T` менен бирдей жайгаштырылгандыгына кепилдик берет.
        // Алынган көрсөткүч жарактуу, анткени ал `slice` ке таандык эс тутумду билдирет, бул шилтеме болуп саналат жана окууга жарактуу деп кепилденет.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Бардык элементтер инициалдаштырылган деп эсептесеңиз, аларга өзгөрүлмө кесинди алыңыз.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` элементтеринин чындыгында баштапкы абалда экендигине кепилдик берүү чалуучунун колунда.
    ///
    /// Мазмун толук кандуу баштала элек кезде муну атоо аныкталбаган жүрүм-турумга алып келет.
    ///
    /// Көбүрөөк маалымат жана мисалдар үчүн [`assume_init_mut`] караңыз.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // КООПСУЗДУК: `slice_get_ref` үчүн коопсуздук эскертүүлөрүнө окшош, бирок бизде
        // өзгөрүлмө шилтеме, ошондой эле жазуу үчүн жарактуу деп кепилденет.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Массивдин биринчи элементине көрсөткүчтү алат.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Массивдин биринчи элементине өзгөрүлмө көрсөткүчтү алат.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// `src` тен `this` ге чейинки элементтерди көчүрүп, `this` инитирленген мазмунуна өзгөрүлмө шилтемени кайтарып берет.
    ///
    /// Эгерде `T` `Copy` ти ишке ашырбаса, [`write_slice_cloned`] колдонуңуз
    ///
    /// Бул [`slice::copy_from_slice`] окшош.
    ///
    /// # Panics
    ///
    /// Бул функция panic болот, эгер эки тилимдин узундугу ар башка болсо.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // КООПСУЗДУК: биз лендин бардык элементтерин запастагы кубаттуулукка көчүрүп алдык
    /// // азыр vecтин биринчи src.len() элементтери жарактуу.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // КООПСУЗДУК: &[T] жана&[MaybeUninit<T>] бирдей планга ээ
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // КООПСУЗДУК: Жарактуу элементтер жаңы эле `this` ке көчүрүлдү, андыктан ал инициализацияланган
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// `src` тен `this` ге чейинки элементтерди клондоштуруп, `this` инитализацияланган мазмунуна өзгөрүлмө шилтеме берет.
    /// Мурунтан эле ритуалдаштырылган элементтердин бардыгы ташталбайт.
    ///
    /// Эгерде `T` `Copy` ти ишке ашырса, [`write_slice`] колдонуңуз
    ///
    /// Бул [`slice::clone_from_slice`] окшош, бирок учурдагы элементтерди түшүрбөйт.
    ///
    /// # Panics
    ///
    /// Бул функция panic болот, эгер эки тилимдин узундугу ар башка болсо же `Clone` panics ишке ашырылса.
    ///
    /// Эгерде panic бар болсо, буга чейин клондолгон элементтер ташталат.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // КООПСУЗДУК: биз лендин бардык элементтерин запастык кубаттуулукка клондоштурдук
    /// // азыр vecтин биринчи src.len() элементтери жарактуу.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // copy_from_sliceден айырмаланып, бул тилимде clone_from_slice деп аталбайт, себеби `MaybeUninit<T: Clone>` Cloneду иштетпейт.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // КООПСУЗДУК: бул чийки тилкеге баштапкы объектилер гана киргизилет
                // ошондуктан, аны таштоого уруксат берилет.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Аларды бирдей узундукта кесишибиз керек
        // чекти текшерүү үчүн, ал эми оптимизатор жөнөкөй учурларда memcpy түзөт (мисалы T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // күзөт керек b/c panic клон учурунда болушу мүмкүн
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // КООПСУЗДУК: Жарактуу элементтер жаңы эле `this` форматында жазылган, андыктан ал жандандырылган
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}