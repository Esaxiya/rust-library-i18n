//! Эстутум менен иштөөнүн негизги функциялары.
//!
//! Бул модуль түрлөрдүн көлөмүн жана тегиздигин сурап билүү, эс тутумун инициализациялоо жана манипуляциялоо функцияларын камтыйт.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Менчикти жана "forgets" ти анын кыйраткычын **иштетпестен** мааниси жөнүндө алат.
///
/// Үймөктүн эстутуму же файл туткасы сыяктуу баалаган бардык ресурстар жеткиликсиз абалда түбөлүккө калат.Бирок, бул эс тутумга багытталган көрсөткүчтөр жарактуу бойдон калат деп кепилдик бере албайт.
///
/// * Эгер эс тутумуңузду кетиргиңиз келсе, [`Box::leak`] караңыз.
/// * Эстутумга чийки көрсөткүч алгыңыз келсе, [`Box::into_raw`] караңыз.
/// * Эгер анын маанисин жок кылгыңыз келсе, анын деструкторун иштетип, [`mem::drop`] караңыз.
///
/// # Safety
///
/// `forget` `unsafe` деп белгиленген эмес, анткени Rust дин коопсуздук кепилдиктеринде деструкторлор ар дайым иштей тургандыгына кепилдик жок.
/// Мисалы, программа [`Rc`][rc] колдонуп шилтеме циклин түзө алат же деструкторлорду иштетпей чыгуу үчүн [`process::exit`][exit] чакыра алат.
/// Ошентип, `mem::forget` ти коопсуз коддон алуу Rust дин коопсуздук кепилдиктерин түп-тамырынан бери өзгөртпөйт.
///
/// Башкача айтканда, эс тутум же I/O объектилери сыяктуу ресурстардын агып кетиши адатта жагымсыз.
/// Айрым учурларда FFI же кооптуу коддорду колдонуу муктаждыгы келип чыгат, бирок ошентсе дагы, [`ManuallyDrop`] адатта артыкчылыктуу.
///
/// Маанини унутууга жол берилгендиктен, сиз жазган `unsafe` коду ушул мүмкүнчүлүккө жол бериши керек.Сиз маани бере албайсыз жана чалуучу сөзсүз түрдө анын деструкторун иштетет деп күтүүгө болбойт.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget` каноникалык коопсуз пайдалануу `Drop` trait тарабынан ишке ашырылган маанинин деструкторун айланып өтүү болуп саналат.Мисалы, бул `File` агып чыгат, б.а.
/// өзгөрүлмө алган мейкиндикти кайтарып алыңыз, бирок эч качан негизги тутум ресурсун жаппаңыз:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Бул мурунку ресурстарга ээлик кылуу Rust тышкаркы кодго өткөндө, мисалы, чийки файлдын дескрипторун С кодуна өткөрүп берүү менен пайдалуу.
///
/// # `ManuallyDrop` менен мамиле
///
/// `mem::forget`*эстутумга* ээликти өткөрүп берүү үчүн да колдонулушу мүмкүн, бирок бул ката кетирбейт.
/// [`ManuallyDrop`] ордуна колдонулушу керек.Мисалы, ушул кодексти карап көрөлү:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // `v` мазмунун колдонуп `String` куруңуз
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // агып `v`, анткени анын эс тутуму азыр `s` тарабынан башкарылат
/// mem::forget(v);  // ERROR, v жараксыз жана аны функцияга өткөрбөө керек
/// assert_eq!(s, "Az");
/// // `s` түздөн-түз түшүп, анын эс тутуму бөлүштүрүлгөн.
/// ```
///
/// Жогорудагы мисалда эки маселе бар:
///
/// * Эгерде `String` курулушу менен `mem::forget()` чакыруусунун ортосунда дагы көп код кошулган болсо, анын ичиндеги panic эки эселенген боштукка алып келиши мүмкүн, анткени ошол эле эс тутумду `v` жана `s` башкарат.
/// * `v.as_mut_ptr()` чалып, `s` маалыматка ээлик укугун өткөрүп бергенден кийин, `v` мааниси жараксыз.
/// Мааниси `mem::forget` ке жаңы көчүрүлгөндө дагы (аны текшербейт), айрым түрлөрү алардын маанилерине катуу талаптарды коюп, аларды илинип турганда же жараксыз кылып салышат.
/// Жараксыз баалуулуктарды кандайдыр бир жол менен колдонуу, анын ичинде аларды функцияларга өткөрүп берүү же аларды кайтаруу, аныкталбаган жүрүм-турумду түзөт жана компилятор тарабынан айтылган божомолдорду бузушу мүмкүн.
///
/// `ManuallyDrop` ке өтүү эки маселени тең алдын алат:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // `v` ти чийки бөлүктөрүнө бөлүп салуудан мурун, анын түшүп кетпөөсүн текшерип алыңыз!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Азыр `v` бөлүп.Бул операциялар panic жасай албайт, андыктан агып кетиши мүмкүн эмес.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Акыры, `String` куруп алыңыз.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` түздөн-түз түшүп, анын эс тутуму бөлүштүрүлгөн.
/// ```
///
/// `ManuallyDrop` эки эселенген нерсени бекем алдын алат, анткени биз "v`" деструкторун башка нерсе жасоодон мурун өчүрөбүз.
/// `mem::forget()` буга жол бербейт, анткени ал аргументин колдонуп, `v` тен керектүү нерселерди чыгарып алгандан кийин гана аны чакырууга аргасыз кылат.
/// `ManuallyDrop` куруу менен сапты куруунун ортосунда panic киргизилген болсо дагы (бул коддо көрсөтүлгөндөй болбойт), ал эки эсе эркин эмес, агып кетишине алып келет.
/// Башкача айтканда, `ManuallyDrop` (эки эселенген) таштоо жагындагы каталардын ордуна, агып кетүү жагынан ката кетирген.
///
/// Ошондой эле, `ManuallyDrop` менчик укугун `s` кө өткөрүп бергенден кийин "touch" `v` ке ээ болушубузга жол бербейт-`v` менен иштешүүнүн акыркы этабы анын деструкторун иштетпей жок кылуу.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// [`forget`] сыяктуу, бирок ошондой эле өлчөмсүз баалуулуктарды кабыл алат.
///
/// Бул функция жөн гана `unsized_locals` функциясы турукташып калганда алынып салынууга тийиш.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Түрдүн көлөмүн байт менен кайтарат.
///
/// Тагыраак айтканда, бул массивдеги ырааттуу элементтердин байт менен жылдырылышы, ошол нерсенин түрүнө, анын ичинде тегиздөө толтуруу.
///
/// Ошентип, `T` жана `n` узундугу үчүн `[T; n]` `n * size_of::<T>()` өлчөмүнө ээ.
///
/// Жалпысынан, түрдүн көлөмү компиляцияларда туруктуу эмес, бирок примитивдер сыяктуу конкреттүү түрлөрү бар.
///
/// Төмөнкү таблицада примитивдердин көлөмү келтирилген.
///
/// Түрү |size_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Мындан тышкары, `usize` жана `isize` бирдей өлчөмгө ээ.
///
/// `*const T`, `&T`, `Box<T>`, `Option<&T>` жана `Option<Box<T>>` типтеринин көлөмү бирдей.
/// Эгерде `T` өлчөмү болсо, анда анын бардык түрлөрү `usize` менен бирдей өлчөмдө болот.
///
/// Көрсөткүчтүн өзгөрүлмө болушу анын көлөмүн өзгөртпөйт.Ошентип, `&T` жана `&mut T` бирдей өлчөмгө ээ.
/// `*const T` жана `* mut T` үчүн.
///
/// # `#[repr(C)]` буюмдарынын көлөмү
///
/// Заттар үчүн `C` өкүлчүлүгү аныкталган жайгашуу бар.
/// Ушул макет менен, бардык талаалардын көлөмү туруктуу болсо, буюмдардын көлөмү дагы туруктуу болот.
///
/// ## Курамдардын көлөмү
///
/// `structs` үчүн көлөмү төмөнкү алгоритм менен аныкталат.
///
/// Декларация ирети менен буйрулган структуранын ар бир талаасы үчүн:
///
/// 1. Талаанын көлөмүн кошуңуз.
/// 2. Учурдун көлөмүн кийинки талаанын [alignment] эселенгенине чейин тегеректеңиз.
///
/// Акыр-аягы, структуранын көлөмүн анын [alignment] эселенгенине чейин тегеректеңиз.
/// Түзүмдүн тегизделиши, адатта, анын бардык талааларындагы эң чоң тегиздөө болуп саналат;бул `repr(align(N))` колдонуу менен өзгөртүлүшү мүмкүн.
///
/// `C` тен айырмаланып, нөлдүк структуралар көлөмү боюнча бир байтка чейин тегеректелбейт.
///
/// ## Enums өлчөмү
///
/// Дискриминанттан башка эч кандай маалыматты камтыбаган энумдардын көлөмү алар түзгөн платформанын C энуму менен бирдей.
///
/// ## Союздардын көлөмү
///
/// Бирликтин көлөмү анын эң чоң талаасынын көлөмү.
///
/// `C` тен айырмаланып, нөлдүк бирликтер көлөмү бир байтка чейин тегеректелбейт.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Айрым примитивдер
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Айрым массивдер
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Көрсөтүүчү көлөмүнүн теңдиги
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` колдонуу.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Биринчи талаанын көлөмү 1, андыктан көлөмүнө 1 кошуңуз.Өлчөмү 1.
/// // Экинчи талаанын тегиздиги 2, ошондуктан көлөмдү толтуруу үчүн 1ди кошуңуз.Өлчөмү 2.
/// // Экинчи талаанын көлөмү 2, андыктан көлөмүнө 2ди кошуңуз.Көлөмү 4.
/// // Үчүнчү талаанын тегиздөөсү 1, ошондуктан толтуруу үчүн ченге 0 кошуңуз.Көлөмү 4.
/// // Үчүнчү талаанын көлөмү 1, андыктан көлөмүнө 1 кошуңуз.Өлчөмү 5.
/// // Акыр-аягы, структуранын тегиздиги 2 (анткени анын талааларындагы эң чоң тегиздөө 2), ошондуктан толтуруу үчүн өлчөмгө 1 кошуңуз.
/// // Өлчөмү 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple структуралары ошол эле эрежелерди сактайт.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Талааларды иретке келтирүү көлөмүн төмөндөтүшү мүмкүн экендигин эске алыңыз.
/// // Эки толтурулган байтты да `third` ти `second` чейин коюу менен алып салабыз.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Бирликтин көлөмү-эң чоң талаанын көлөмү.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Көрсөтүлгөн маанинин өлчөмүн байт менен кайтарат.
///
/// Бул, адатта, `size_of::<T>()` менен бирдей.
/// Бирок, `T` * статикалык белгилүү өлчөмгө ээ болбогондо, мисалы, [`[T]`][slice] кесинди же [trait object], анда `size_of_val` динамикалык белгилүү өлчөмдү алуу үчүн колдонулушу мүмкүн.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // КООПСУЗДУК: `val` бул шилтеме, андыктан жарактуу чийки көрсөткүч
    unsafe { intrinsics::size_of_val(val) }
}

/// Көрсөтүлгөн маанинин өлчөмүн байт менен кайтарат.
///
/// Бул, адатта, `size_of::<T>()` менен бирдей.Бирок, `T`*статикалык белгилүү өлчөмү жок* болгондо, мисалы, [`[T]`][slice] кесинди же [trait object], анда `size_of_val_raw` динамикалык белгилүү өлчөмдү алуу үчүн колдонулушу мүмкүн.
///
/// # Safety
///
/// Төмөнкү шарттар сакталганда гана, бул функцияны чалууга болот:
///
/// - Эгерде `T` `Sized` болсо, анда бул функция ар дайым чалууга коопсуз.
/// - Эгерде `T` өлчөмсүз куйругу:
///     - [slice], андан кийин кесинди куйругунун узундугу инициалдаштырылган бүтүн сан болуп,*бүт маанинин* өлчөмү (динамикалык куйрук узундугу + статикалык чоңдуктагы префикс) `isize` дал келиши керек.
///     - бир [trait object], анда көрсөткүчтүн vtable бөлүгү көлөмсүз мажбурлоо жолу менен алынган жарактуу vtableды көрсөтүп,*бүт маанинин* өлчөмү (динамикалык куйрук узундугу + статикалык өлчөмдөгү префикс) `isize` ге туура келиши керек.
///
///     - (unstable) [extern type], анда бул функция ар дайым чалууга коопсуз, бирок panic же башкача айтканда, туура эмес маанини кайтарып бериши мүмкүн, анткени сырткы типтин жайгашуусу белгисиз.
///     Бул [`size_of_val`] сырткы түрү куйруктуу түргө шилтеме берүү менен бирдей жүрүм-турум.
///     - Болбосо, бул функцияны чакырууга консервативдүү жол берилбейт.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // КООПСУЗДУК: чалган адам чийки көрсөткүчтү камсыздашы керек
    unsafe { intrinsics::size_of_val(val) }
}

/// Түрдүн [ABI] талап кылынган минималдык тегиздөөсүн кайтарат.
///
/// `T` тибиндеги мааниге карата ар бир шилтеме ушул санга эселенип турушу керек.
///
/// Бул түзүм талаалары үчүн колдонулган тегиздөө.Бул артыкчылыктуу тегиздөө караганда кичинекей болушу мүмкүн.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` көрсөткөн маанинин түрүнүн [ABI] талап кылынган минималдуу тегиздөөсүн кайтарат.
///
/// `T` тибиндеги мааниге карата ар бир шилтеме ушул санга эселенип турушу керек.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // КООПСУЗДУК: val бул шилтеме, андыктан жарактуу чийки көрсөткүч
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Түрдүн [ABI] талап кылынган минималдык тегиздөөсүн кайтарат.
///
/// `T` тибиндеги мааниге карата ар бир шилтеме ушул санга эселенип турушу керек.
///
/// Бул түзүм талаалары үчүн колдонулган тегиздөө.Бул артыкчылыктуу тегиздөө караганда кичинекей болушу мүмкүн.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` көрсөткөн маанинин түрүнүн [ABI] талап кылынган минималдуу тегиздөөсүн кайтарат.
///
/// `T` тибиндеги мааниге карата ар бир шилтеме ушул санга эселенип турушу керек.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // КООПСУЗДУК: val бул шилтеме, андыктан жарактуу чийки көрсөткүч
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `val` көрсөткөн маанинин түрүнүн [ABI] талап кылынган минималдуу тегиздөөсүн кайтарат.
///
/// `T` тибиндеги мааниге карата ар бир шилтеме ушул санга эселенип турушу керек.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Төмөнкү шарттар сакталганда гана, бул функцияны чалууга болот:
///
/// - Эгерде `T` `Sized` болсо, анда бул функция ар дайым чалууга коопсуз.
/// - Эгерде `T` өлчөмсүз куйругу:
///     - [slice], андан кийин кесинди куйругунун узундугу инициалдаштырылган бүтүн сан болуп,*бүт маанинин* өлчөмү (динамикалык куйрук узундугу + статикалык чоңдуктагы префикс) `isize` дал келиши керек.
///     - бир [trait object], анда көрсөткүчтүн vtable бөлүгү көлөмсүз мажбурлоо жолу менен алынган жарактуу vtableды көрсөтүп,*бүт маанинин* өлчөмү (динамикалык куйрук узундугу + статикалык өлчөмдөгү префикс) `isize` ге туура келиши керек.
///
///     - (unstable) [extern type], анда бул функция ар дайым чалууга коопсуз, бирок panic же башкача айтканда, туура эмес маанини кайтарып бериши мүмкүн, анткени сырткы типтин жайгашуусу белгисиз.
///     Бул [`align_of_val`] сырткы түрү куйруктуу түргө шилтеме берүү менен бирдей жүрүм-турум.
///     - Болбосо, бул функцияны чакырууга консервативдүү жол берилбейт.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // КООПСУЗДУК: чалган адам чийки көрсөткүчтү камсыздашы керек
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Эгерде `T` тибиндеги маанилерди түшүрсө, `true` кайтарып берет.
///
/// Бул таза оптимизация кеңеши жана консервативдүү түрдө жүзөгө ашырылышы мүмкүн:
/// ал чындыгында түшүрүүнүн кажети жок түрлөрү үчүн `true` кайтарып бере алат.
/// Ошентип, `true` ар дайым кайтып келсе, бул функцияны туура ишке ашыруу болот.Бирок бул иш жүзүндө `false` көрсөткүчүн кайтарса, анда `T` ти түшүрүүнүн эч кандай терс таасири жок болот.
///
/// Маалыматтарды кол менен түшүрүп алуу керек болгон коллекциялар сыяктуу нерселердин төмөн деңгээлде аткарылышы, ушул функцияны колдонуп, жок кылынгандан кийин, алардын мазмунун түшүрбөөгө аракет кылышы керек.
///
/// Бул релиздерди түзүүдө айырмачылыктарды жаратпашы мүмкүн (бул жерде эч кандай терс таасирлери жок цикл оңой эле табылып, жок кылынат), бирок мүчүлүштүктөрдү оңдоо үчүн чоң утуш болот.
///
/// [`drop_in_place`] бул текшерүүнү мурунтан эле жүргүзүп жаткандыгын эске алыңыз, андыктан сиздин жумуш көлөмүңүз [`drop_in_place`] чалуулардын саны азая турган болсо, анда аны колдонуу ашыкча болбойт.
/// Айрыкча, сиз бир кесим [`drop_in_place`] жасай аласыз, ошондо бардык баалуулуктар үчүн бир need_drop текшерүүсү болот.
///
/// Vec сыяктуу түрлөрү, андыктан `needs_drop` колдонбостон `drop_in_place(&mut self[..])`.
/// Ал эми [`HashMap`] сыяктуу түрлөрү бир-бирден баалуулуктарды түшүрүшү керек жана ушул API колдонулушу керек.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Коллекция `needs_drop` ти кандайча колдоно аларынын мисалы:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // маалыматтарды таштоо
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Бардык нөлгө байт-шаблон менен көрсөтүлгөн `T` түрүнүн маанисин кайтарып берет.
///
/// Бул, мисалы, `(u8, u16)` теги толтурулган байт сөзсүз түрдө нөлгө түшпөйт дегенди билдирет.
///
/// Бардык нөлгө байт-үлгү кандайдыр бир `T` түрүнүн жарактуу маанисин билдирет деген кепилдик жок.
/// Мисалы, нөлгө байт-үлгү шилтеме түрлөрү ("&T`, `&mut T`) жана функция көрсөткүчтөрү үчүн жарактуу эмес.
/// Мындай типтерде `zeroed` колдонуп, токтоосуз [undefined behavior][ub] пайда болот, анткени [the Rust compiler assumes][inv] ар дайым инициалдаштырылган деп эсептеген өзгөрмөнүн жарактуу мааниси бар.
///
///
/// Бул [`MaybeUninit::zeroed().assume_init()`][zeroed] сыяктуу таасир берет.
/// Бул кээде FFI үчүн пайдалуу, бирок, адатта, андан оолак болуу керек.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Бул функцияны туура колдонуу: бүтүн санды нөлгө киргизүү.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Туура эмес* бул функцияны колдонуу: шилтемени нөл менен инициалдаштыруу.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Аныкталбаган жүрүм-турум!
/// let _y: fn() = unsafe { mem::zeroed() }; // Жана кайра!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // КООПСУЗДУК: чалган адам нөлгө барабар `T` үчүн жарактуу деп кепилдик бериши керек.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Эч нерсе кылбай,`T` түрүндөгү маанини чыгаргандай түр көрсөтүп, Rust дин эс тутумун инициализациялоону текшерет.
///
/// **Бул функция эскирген.** Анын ордуна [`MaybeUninit<T>`] колдонуңуз.
///
/// Эскирүүнүн себеби, функцияны негизинен туура колдонууга болбойт: ал [`MaybeUninit::uninit().assume_init()`][uninit] сыяктуу таасир берет.
///
/// [`assume_init` documentation][assume_init] түшүндүргөндөй, [the Rust compiler assumes][inv] баалуулуктар туура башталган.
/// Натыйжада, мис
/// `mem::uninitialized::<bool>()` `bool` ти кайтарып берүү үчүн токтоосуз аныкталбаган жүрүм-турумду шарттайт, ал `true` же `false` эмес.
/// Эң жаманы, бул жерде кайтарылып алынган нерселер сыяктуу чындыгында инициализацияланбаган эстутум өзгөчө, ал компилятор анын туруктуу мааниге ээ эместигин билет.
/// Ушундан улам, ал өзгөрүлмө бүтүн түргө ээ болсо дагы, инициализацияланбаган маалыматтардын өзгөрүүсүз болушун аныктайт.
/// (Баштала элек бүтүн сандардын тегерегиндеги эрежелер азырынча аягына чыга электигине көңүл буруңуз, бирок алар бүткүчө, алардан алыс болуңуз.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // КООПСУЗДУК: чалган адам `T` үчүн бирдиктүү мааниге ээ экендигине кепилдик бериши керек.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Эки бирин өзгөртпөстөн, экинчисин деинициалдаштырбастан, алмаштырат.
///
/// * Демейки же муляждык маани менен алмаштыргыңыз келсе, [`take`] караңыз.
/// * Эгер сиз эски маанини кайтарып, өткөн балл менен алмаштыргыңыз келсе, [`replace`] караңыз.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // КООПСУЗДУК: чийки көрсөткүчтөр баардыгын канааттандырган коопсуз өзгөрүлмө шилтемелерден түзүлгөн
    // `ptr::swap_nonoverlapping_one` боюнча чектөөлөр
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Мурунку `dest` маанисин кайтарып, `T` демейки мааниси менен `dest` тин ордун басат.
///
/// * Эгер эки өзгөрмөнүн маанисин алмаштыргыңыз келсе, [`swap`] караңыз.
/// * Эгер демейки маанинин ордуна өткөн маани менен алмаштыргыңыз келсе, [`replace`] караңыз.
///
/// # Examples
///
/// Жөнөкөй мисал:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` аны "empty" маанисине алмаштыруу менен структуралык талаага ээлик кылууга мүмкүндүк берет.
/// `take` сиз төмөнкүдөй көйгөйлөргө туш болушуңуз мүмкүн:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// `T` сөзсүз түрдө [`Clone`] программасын ишке ашыра бербейт, ошондуктан ал `self.buf` ти клондоп, баштапкы абалга келтире албайт.
/// Бирок `take` баштапкы маанисин `self` тен ажыратып, аны кайтарып берүү үчүн колдонсо болот:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Мурунку `dest` маанисин кайтарып, `src` шилтеме берилген `dest` ичине жылдырат.
///
/// Эч кандай маани түшүрүлбөйт.
///
/// * Эгер эки өзгөрмөнүн маанисин алмаштыргыңыз келсе, [`swap`] караңыз.
/// * Эгер сиз демейки маани менен алмаштыргыңыз келсе, [`take`] караңыз.
///
/// # Examples
///
/// Жөнөкөй мисал:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` структуралык талааны башка мааниге алмаштыруу менен керектөөгө мүмкүндүк берет.
/// `replace` сиз төмөнкүдөй көйгөйлөргө туш болушуңуз мүмкүн:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// `T` сөзсүз түрдө [`Clone`] ти ишке ашыра бербейт, андыктан көчүп кетпеш үчүн `self.buf[i]` ти клондоштура албайбыз.
/// Бирок `replace` ошол индекстеги баштапкы маанини `self` тен ажыратып, аны кайтарып берүүгө колдонсо болот:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // КООПСУЗДУК: Биз `dest` тен окуйбуз, бирок кийинчерээк ага `src` деп жазабыз,
    // эски маани кайталанбагандай.
    // Эч нерсе ташталбайт жана бул жерде эч нерсе panic болбойт.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Бааны жок кылат.
///
/// Муну аргументтин [`Drop`][drop] ишке ашырылышын чакыруу менен жасайт.
///
/// Бул, мисалы, `Copy` жүзөгө ашырган түрлөрү үчүн эч кандай натыйжа бербейт
/// integers.
/// Мындай маанилер көчүрүлүп, _then_ функциянын ичине көчүрүлөт, андыктан функция ушул чакыруудан кийин дагы сакталып калат.
///
///
/// Бул функция сыйкырдуу эмес;ал түзмө-түз катары аныкталат
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// `_x` функцияга өткөндүктөн, функция кайтып келгиче автоматтык түрдө түшүрүлөт.
///
/// [drop]: Drop
///
/// # Examples
///
/// Негизги колдонуу:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // ачык vector таштоо
/// ```
///
/// [`RefCell`] карыз алуу эрежелерин иштеп жаткан маалда аткаргандыктан, `drop` [`RefCell`] карызын чыгара алат:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // ушул уячадагы өзгөрүлмө карыздан баш тартуу
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Бүтүн сандар жана [`Copy`] ти ишке ашырган башка түрлөрү `drop` тарабынан таасирленбейт.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x` көчүрмөсү жылдырылып ташталат
/// drop(y); // `y` көчүрмөсү жылдырылып ташталат
///
/// println!("x: {}, y: {}", x, y.0); // дагы деле бар
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src` түрүн `&U` деп чечмелейт, андан кийин камтылган маанини жылдырбастан `src` окуйт.
///
/// Бул функция `src` көрсөткүчү [`size_of::<U>`][size_of] байт үчүн `&T` ти `&U` ке которуп, андан кийин `&U` ти окуу менен жарактуу деп эсептейт (башкача айтканда, `&U` `&T` ке караганда катуу тегиздөө талаптарын койсо дагы, туура жол менен жасалат).
/// Ошондой эле, `src` тен чыккандын ордуна камтылган маанинин көчүрмөсүн кооптуу шартта түзүп берет.
///
/// Эгерде `T` жана `U` өлчөмдөрү ар башка болсо, анда бул компиляция учурунда кетирилген ката эмес, бирок `T` жана `U` көлөмү бирдей болгон жерде ушул функцияны иштетүү сунушталат.Бул функция, эгер `U` `T` тен чоңураак болсо, [undefined behavior][ub] ти иштетет.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // 'foo_array' тен маалыматтарды көчүрүп алып, 'Foo' катары караңыз
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Көчүрүлгөн маалыматтарды өзгөртүү
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array' тин мазмуну өзгөрүлбөшү керек болчу
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Эгер U түздөө талабы жогору болсо, src ылайыктуу тегизделбеши мүмкүн.
    if align_of::<U>() > align_of::<T>() {
        // КООПСУЗДУК: `src` бул окуу үчүн жарактуу экенине кепилденген шилтеме.
        // Чакыруучу чыныгы трансмутациянын коопсуздугуна кепилдик бериши керек.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // КООПСУЗДУК: `src` бул окуу үчүн жарактуу экенине кепилденген шилтеме.
        // Биз `src as *const U` туура тегизделгенин текшердик.
        // Чакыруучу чыныгы трансмутациянын коопсуздугуна кепилдик бериши керек.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Энумдун дискриминантын билдирүүчү тунук эмес түр.
///
/// Көбүрөөк маалымат алуу үчүн ушул модулдагы [`discriminant`] функциясын караңыз.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Бул trait ишке ашырылышы мүмкүн эмес, анткени биз Tде эч кандай чекти каалабайбыз.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// `v` теги enum вариантын уникалдуу аныктаган маанини берет.
///
/// Эгерде `T` enum болбосо, анда бул функцияны чакыруу аныкталбаган жүрүм-турумга алып келбейт, бирок кайтарым мааниси аныкталбайт.
///
///
/// # Stability
///
/// Enum аныктамасы өзгөрсө, enum вариантынын дискриминанты өзгөрүшү мүмкүн.
/// Айрым варианттардын дискриминанты ошол эле компилятор менен түзүлгөн компиляциялар ортосунда өзгөрбөйт.
///
/// # Examples
///
/// Бул чыныгы маалыматтарды эске албай, маалыматтарды ташыган энумдарды салыштыруу үчүн колдонсо болот:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// `T` түрүндөгү enum түрүндөгү варианттардын санын кайтарып берет.
///
/// Эгерде `T` enum болбосо, анда бул функцияны чакыруу аныкталбаган жүрүм-турумга алып келбейт, бирок кайтарым мааниси аныкталбайт.
/// Ошол эле учурда, эгер `T` `usize::MAX` караганда көбүрөөк варианттары бар enum болсо, кайтарым мааниси такталбайт.
/// Жашабаган варианттар эсептелет.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}