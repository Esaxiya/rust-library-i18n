//! `Clone` trait 'жашыруун көчүрүлбөйт' түрлөрү үчүн.
//!
//! Rust де кээ бир жөнөкөй түрлөрү "implicitly copyable" болуп саналат жана аларды дайындаганда же аргумент катары бергенде, алуучу баштапкы маанисин ордунда калтырып, көчүрмөсүн алат.
//! Бул типтер көчүрүүгө бөлүштүрүүнү талап кылбайт жана финалдаштыргычтары жок (б.а. аларда менчик кутучалар жок же [`Drop`] шайманы жок), андыктан компилятор аларды көчүрүүгө арзан жана коопсуз деп эсептейт.
//!
//! Башка типтер үчүн көчүрмөлөр [`Clone`] trait конвенциясы жана [`clone`] ыкмасын колдонуу менен ачык түрдө жасалышы керек.
//!
//! [`clone`]: Clone::clone
//!
//! Колдонуунун негизги мисалы:
//!
//! ```
//! let s = String::new(); // String түрү Клонду ишке ашырат
//! let copy = s.clone(); // ошондуктан биз аны клондоштура алабыз
//! ```
//!
//! Clone trait программасын оңой ишке ашыруу үчүн, `#[derive(Clone)]` колдонсоңуз болот.Мисалы:
//!
//! ```
//! #[derive(Clone)] // Morpheus структурасына Clone trait кошобуз
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // эми биз аны клондой алабыз!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Объектти так копиялоо мүмкүнчүлүгү үчүн кеңири тараган trait.
///
/// [`Copy`] тен айырмаланып турат, бул [`Copy`] ачык эмес жана өтө арзан, ал эми `Clone` ар дайым ачык жана кымбат эмес болушу мүмкүн.
/// Ушул мүнөздөмөлөрдү колдонуу үчүн, Rust [`Copy`] ти ишке ашырууга мүмкүнчүлүк бербейт, бирок сиз `Clone` ти кайталап, каалаган кодду иштете аласыз.
///
/// `Clone` [`Copy`] караганда жалпы болгондуктан, [`Copy`] нерсени `Clone` кылып автоматтык түрдө жасай аласыз.
///
/// ## Derivable
///
/// Эгерде бардык талаалар `Clone` болсо, бул trait ти `#[derive]` менен колдонсо болот.[`Clone`] программасын ишке ашыруу ар бир талаага [`clone`] чакырат.
///
/// [`clone`]: Clone::clone
///
/// Жалпы структура үчүн, `#[derive]` жалпы параметрлерге байланышкан `Clone` кошуу менен шарттуу түрдө `Clone` ишке ашырат.
///
/// ```
/// // `derive` Окуу үчүн Клонду ишке ашырат<T>качан Т клон болот.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## `Clone` ти кантип ишке ашырсам болот?
///
/// [`Copy`] түрлөрү `Clone` маанисиз ишке ашырылышы керек.Дагы расмий:
/// эгер `T: Copy`, `x: T` жана `y: &T` болсо, анда `let x = y.clone();` `let x = *y;` менен барабар.
/// Кол менен жүзөгө ашыруу ушул инвариантты сактоо үчүн этият болушу керек;бирок кооптуу код эс тутумдун коопсуздугун камсыз кылуу үчүн ага ишенбеши керек.
///
/// Мисал катары, функция көрсөткүчүн кармаган жалпы структура келтирилген.Бул учурда, `Clone` ишке ашышы мүмкүн эмес ', бирок төмөнкүдөй ишке ашырылышы мүмкүн:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Кошумча аткаруучулар
///
/// [implementors listed below][impls] тышкары, төмөнкү түрлөрү `Clone` жүзөгө ашырат:
///
/// * Функциянын пункт түрлөрү (б.а., ар бир функция үчүн аныкталган түрлөрү)
/// * Функциянын көрсөткүчтөрүнүн түрлөрү (мис., `fn() -> i32`)
/// * Массив түрлөрү, бардык өлчөмдөр үчүн, эгерде объект түрү `Clone` үлгүсүн колдонсо (мисалы, `[i32; 123456]`)
/// * Tuple түрлөрү, эгерде ар бир компонент `Clone` ти ишке ашырса (мисалы, `()`, `(i32, bool)`)
/// * Жабуу түрлөрү, эгерде алар айлана-чөйрөдөн эч кандай мааниге ээ болбосо же алынган бардык ушул баалуулуктар `Clone` ти өздөштүрсө.
///   Белгилей кетчү нерсе, жалпы шилтеме менен алынган өзгөрүлмө ар дайым `Clone` (референт жок болсо дагы) колдонот, ал эми өзгөрүлмө шилтеме менен алынган өзгөрүлмө эч качан `Clone` болбойт.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Маанинин көчүрмөсүн кайтарып берет.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str Клонду ишке ашырат
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// `source` тен көчүрмө-тапшырманы аткарат.
    ///
    /// `a.clone_from(&b)` функциясы боюнча `a = b.clone()` эквивалентине ээ, бирок ашыкча бөлүштүрүүлөргө жол бербөө үчүн `a` ресурстарын кайра колдонуу үчүн жокко чыгарылышы мүмкүн.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// trait `Clone` имплинин түзүүчү макроэлектроника.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): бул структуралар ар бир компоненттин Clone же Copy көчүрмөсүн аткаргандыгын ырастоо үчүн#[derive] тарабынан гана колдонулат.
//
//
// Бул түзүмдөр колдонуучунун кодунда эч качан болбошу керек.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Баштапкы түрлөрү үчүн `Clone` ишке ашыруу.
///
/// Rust де сүрөттөлбөй турган иш-чаралар `traits::SelectionContext::copy_clone_conditions()` те `rustc_trait_selection` те жүзөгө ашырылат.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Жалпы шилтемелерди клондоштурса болот, бирок өзгөрүлмө шилтемелер *мүмкүн эмес*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Жалпы шилтемелерди клондоштурса болот, бирок өзгөрүлмө шилтемелер *мүмкүн эмес*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}