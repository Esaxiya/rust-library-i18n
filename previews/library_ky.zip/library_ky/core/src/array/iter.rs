//! Массивдер үчүн `IntoIter` таандык итераторду аныктайт.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// [array] итератору.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Бул биз кайталап жаткан массив.
    ///
    /// `i` индекси бар элементтер, анда `alive.start <= i < alive.end` чыга элек жана алаптын жарактуу жазуулары болуп саналат.
    /// `i < alive.start` же `i >= alive.end` индекстери бар элементтер мурунтан эле алынган жана мындан ары аларга кирүүгө болбойт!Ошол өлгөн элементтер таптакыр башталбаган абалда болушу мүмкүн!
    ///
    ///
    /// Ошентип, инварианттар:
    /// - `data[alive]` тирүү (б.а. жарактуу элементтерди камтыйт)
    /// - `data[..alive.start]` жана `data[alive.end..]` өлүп калган (б.а. элементтер мурунтан эле окулган жана аларга тийбеш керек!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data` теги элементтер али чыга элек.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Берилген `array` үстүнөн жаңы итератор түзөт.
    ///
    /// *Эскертүү*: бул ыкма future де, [`IntoIterator` is implemented for arrays][array-into-iter] тен кийин эскирген болушу мүмкүн.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `value` түрү бул жерде `&i32` эмес, `i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // КООПСУЗДУК: Трансмут чындыгында коопсуз.`MaybeUninit` документтери
        // promise:
        //
        // > `MaybeUninit<T>` бирдей өлчөмгө жана тегиздикке ээ экендигине кепилдик берилет
        // > `T` катары.
        //
        // Документтер `MaybeUninit<T>` массивинен `T` массивине которууну көрсөтөт.
        //
        //
        // Ушуну менен, инициализация инварианттарды канааттандырат.

        // FIXME(LukasKalbertodt): бул жерде const generics менен иштегенден кийин, чындыгында `mem::transmute` колдонуңуз:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Ага чейин, биз `mem::transmute_copy` ти колдонуп, башкача түрүндө биттик көчүрмө түзө алабыз, андан кийин `array` ти унутуп койбошубуз керек.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Азырынча түшүрүлө элек бардык элементтердин өзгөрбөс тилкесин кайтарып берет.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // КООПСУЗДУК: `alive` ичиндеги бардык элементтер туура башталгандыгын билебиз.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Азырынча түшүрүлө элек бардык элементтердин өзгөрүлмө кесиндисин кайтарып берет.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // КООПСУЗДУК: `alive` ичиндеги бардык элементтер туура башталгандыгын билебиз.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Алдыдан кийинки индексти алыңыз.
        //
        // `alive.start` ди 1ге көбөйтүү `alive` ке карата инвариантты сактайт.
        // Бирок, ушул өзгөрүүгө байланыштуу, кыска убакыттын ичинде тирүү зона `data[alive]` эмес, `data[idx..alive.end]` болуп калды.
        //
        self.alive.next().map(|idx| {
            // Массивдеги элементти окуп чыгыңыз.
            // КООПСУЗДУК: `idx`-бул мурунку "alive" аймагына кирген индекс
            // массивБул элементти окуу `data[idx]` азыр өлдү деп эсептелет (башкача айтканда, тийбегиле).
            // `idx` жандуу зонанын башталышы болгондуктан, тирүү зона кайрадан `data[alive]` болуп, бардык инварианттарды калыбына келтирүүдө.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Арткы индексин алыңыз.
        //
        // `alive.end` ди 1ге азайтуу `alive` ке карата инвариантты сактайт.
        // Бирок, ушул өзгөрүүгө байланыштуу, кыска убакыттын ичинде тирүү зона `data[alive]` эмес, `data[alive.start..=idx]` болуп калды.
        //
        self.alive.next_back().map(|idx| {
            // Массивдеги элементти окуп чыгыңыз.
            // КООПСУЗДУК: `idx`-бул мурунку "alive" аймагына кирген индекс
            // массивБул элементти окуу `data[idx]` азыр өлдү деп эсептелет (башкача айтканда, тийбегиле).
            // `idx` тирүү зонанын аягы болгондуктан, тирүү зона кайрадан `data[alive]` болуп, бардык инварианттарды калыбына келтирүүдө.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // КООПСУЗДУК: Бул коопсуз: `as_mut_slice` толук тилимди кайтарып берет
        // чыгарыла элек жана түшүрүлө элек элементтердин
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // "Live.start <=" инварианттыгынан улам эч качан агып кетпейт
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Итератор чындыгында туура узундукту билдирет.
// "alive" элементтеринин саны (дагы деле түшө берет) `alive` диапазонунун узундугу.
// Бул диапазон `next` же `next_back` узундугу боюнча азайтылат.
// Ал ар дайым ошол ыкмаларда 1ге азайтылат, бирок `Some(_)` кайтарылса гана.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Эскертүү, биз чындыгында эле бирдей тирүү диапазонго дал келүүнүн кажети жок, андыктан `self` кайда экендигине карабастан, 0 офсетине өтсөк болот.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Бардык тирүү элементтерди клондоштуруу.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Жаңы массивге клон жазып, анын тирүү чегин жаңыртыңыз.
            // Эгер panics клондосо, анда мурунку элементтерди туура таштайбыз.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Азырынча түшүрүлө элек элементтерди гана басып чыгарыңыз: эми алынган элементтерге кире албайбыз.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}