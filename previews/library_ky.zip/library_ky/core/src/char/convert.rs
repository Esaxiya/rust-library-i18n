//! Белгилерди өзгөртүү.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32` ти `char` ке которот.
///
/// Бардык [`char`] жарактуу [` u32 '] с, жана бирине куюла тургандыгын эске алыңыз
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Бирок, тескерисинче, туура эмес: жарактуу [`u32`] тең жарактуу [`char`] с эмес.
/// `from_u32()` Эгер [`char`] үчүн жарактуу маани болбосо, `None` кайтарып берет.
///
/// Ушул функциялардын кооптуу версиясы үчүн, бул текшерүүлөргө көңүл бурбайт, [`from_u32_unchecked`] караңыз.
///
///
/// # Examples
///
/// Негизги колдонуу:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Киргизүү жараксыз [`char`] болбогондо `None` кайтаруу:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Жарактуулугун эске албай, `u32` ти `char` ке которот.
///
/// Бардык [`char`] жарактуу [` u32 '] с, жана бирине куюла тургандыгын эске алыңыз
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Бирок, тескерисинче, туура эмес: жарактуу [`u32`] тең жарактуу [`char`] с эмес.
/// `from_u32_unchecked()` буга көңүл бурбай, [`char`] ке сокурдук менен ыргытып жиберип, жараксыз бирөөнү жаратышы мүмкүн.
///
///
/// # Safety
///
/// Бул функция кооптуу, анткени жараксыз `char` маанисин түзүшү мүмкүн.
///
/// Бул функциянын коопсуз версиясын көрүү үчүн [`from_u32`] функциясын караңыз.
///
/// # Examples
///
/// Негизги колдонуу:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // КООПСУЗДУК: чалган адам `i` жарактуу кубаттуулук экендигине кепилдик бериши керек.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`] ти [`u32`] ке айландырат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`] ти [`u64`] ке айландырат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Char код чекитинин маанисине чыгарылат, андан кийин нөлгө чейин 64 битке чейин узартылат.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] караңыз
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`] ти [`u128`] ке айландырат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Char код чекитинин маанисине чыгарылат, андан кийин нөлгө чейин 128 битке чейин узартылат.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] караңыз
        c as u128
    }
}

/// 0x00 ..=0xFF форматындагы байтты `char` ке, анын коддук чекити бирдей мааниге ээ, U + 0000 ..=U + 00FF.
///
/// Юникод IANA ISO-8859-1 деп атаган символдор менен байттарды натыйжалуу чечмелейт.
/// Бул коддоо ASCII менен шайкеш келет.
///
/// Бул ISO/IEC 8859-1 акадан айырмаланып турарын эске алыңыз
/// ISO 8859-1 (бир аз дефис менен), ал кандайдыр бир символго берилбеген "blanks", байт баалуулуктарын калтырат.
/// ISO-8859-1 (IANA бири) аларды C0 жана C1 башкаруу коддоруна ыйгарат.
///
/// Белгилей кетүүчү нерсе, бул *Windows* 1252 ака менен айырмаланат
/// 1252 коду, ал ISO/IEC 8859-1 суперсети болуп саналат, ал айрым (баардыгын эмес!) боштуктарды тыныш белгилерине жана ар кандай латын тамгаларына ыйгарат.
///
/// Башка нерселерди чаташтырыш үчүн, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` жана `windows-1252`-бул калган боштуктарды тиешелүү C0 жана C1 башкаруу коддору менен толтурган Windows-1252 суперсети үчүн лакап ат.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`] ти [`char`] ке айландырат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Чарчаны талдоодо кайтарылып берилүүчү ката.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // КООПСУЗДУК: юридикалык коддун мааниси экендигин текшерди
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Катанын түрү u32 дан charга которулбай калганда кайтарылды.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Берилген радиустагы цифраны `char` ке айландырат.
///
/// Бул жерде 'radix' кээде 'base' деп да аталат.
/// Экөөнүн радиусу экилик санды, ондуктун радиусун, ондукту жана он алтылыкты, он алтылыкты эсептеп, кээ бир жалпы маанилерди берет.
///
/// Ыктыярдуу радикалдар колдоого алынат.
///
/// `from_digit()` Эгер берилген радиуста сан болбосо, `None` кайтып келет.
///
/// # Panics
///
/// 36дан чоңураак радиус берилген болсо Panics.
///
/// # Examples
///
/// Негизги колдонуу:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // 11-ондук 16-базанын бир цифрасы
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Киргизүү цифра болбогондо `None` кайтаруу:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// panic пайда кылган чоң радиусту өткөрүү:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}