//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// `char` ээ боло турган эң жогорку жарактуу код чекити.
    ///
    /// `char`-бул [Unicode Scalar Value], демек ал [Code Point], бирок белгилүү бир чекте гана.
    /// `MAX` жарактуу [Unicode Scalar Value] эң жогорку жарактуу код чекити.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () кодун чечмелөө катасын көрсөтүү үчүн Юникоддо колдонулат.
    ///
    /// Ал, мисалы, [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) ге начар калыптанган UTF-8 байт бергенде пайда болушу мүмкүн.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Юникод `char` жана `str` ыкмаларынын бөлүктөрүнө негизделген [Unicode](http://www.unicode.org/) версиясы.
    ///
    /// Юникоддун жаңы версиялары үзгүлтүксүз чыгып турат, андан кийин Юникодго жараша стандарттык китепканада бардык ыкмалар жаңыртылып турат.
    /// Ошондуктан кээ бир `char` жана `str` методдорунун жүрүм-туруму жана туруктуу мааниси убакыттын өтүшү менен өзгөрүп турат.
    /// Бул * өзгөрүлмө өзгөрүү деп эсептелбейт.
    ///
    /// Версияны номерлөө схемасы [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) те түшүндүрүлөт.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// `iter` теги коддолгон UTF-16 коду боюнча итератор түзүп, жупташтырылбаган суррогаттарды "Err`s" деп кайтарат.
    ///
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// `Err` натыйжаларын алмаштыруу белгиси менен алмаштырып, жоготуучу декодерди алууга болот:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32` ти `char` ке которот.
    ///
    /// Бардык `char`лер жарактуу ['u32'], жана бирине куюла тургандыгын эске алыңыз
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Бирок, тескерисинче, туура эмес: жарактуу [`u32`] бардык эле жарактуу`char`с эмес.
    /// `from_u32()` Эгер `char` үчүн жарактуу маани болбосо, `None` кайтарып берет.
    ///
    /// Ушул функциялардын кооптуу версиясы үчүн, бул текшерүүлөргө көңүл бурбайт, [`from_u32_unchecked`] караңыз.
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Киргизүү жараксыз `char` болбогондо `None` кайтаруу:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Жарактуулугун эске албай, `u32` ти `char` ке которот.
    ///
    /// Бардык `char`лер жарактуу ['u32'], жана бирине куюла тургандыгын эске алыңыз
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Бирок, тескерисинче, туура эмес: жарактуу [`u32`] бардык эле жарактуу`char`с эмес.
    /// `from_u32_unchecked()` буга көңүл бурбай, `char` ке сокурдук менен ыргытып жиберип, жараксыз бирөөнү жаратышы мүмкүн.
    ///
    ///
    /// # Safety
    ///
    /// Бул функция кооптуу, анткени жараксыз `char` маанисин түзүшү мүмкүн.
    ///
    /// Бул функциянын коопсуз версиясын көрүү үчүн [`from_u32`] функциясын караңыз.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // КООПСУЗДУК: коопсуздук келишимин чалган адам сакташы керек.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Берилген радиустагы цифраны `char` ке айландырат.
    ///
    /// Бул жерде 'radix' кээде 'base' деп да аталат.
    /// Экөөнүн радиусу экилик санды, ондуктун радиусун, ондукту жана он алтылыкты, он алтылыкты эсептеп, кээ бир жалпы маанилерди берет.
    ///
    /// Ыктыярдуу радикалдар колдоого алынат.
    ///
    /// `from_digit()` Эгер берилген радиуста сан болбосо, `None` кайтып келет.
    ///
    /// # Panics
    ///
    /// 36дан чоңураак радиус берилген болсо Panics.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // 11-ондук 16-базанын бир цифрасы
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Киргизүү цифра болбогондо `None` кайтаруу:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// panic пайда кылган чоң радиусту өткөрүү:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// `char` берилген радиуста орун алгандыгын текшерет.
    ///
    /// Бул жерде 'radix' кээде 'base' деп да аталат.
    /// Экөөнүн радиусу экилик санды, ондуктун радиусун, ондукту жана он алтылыкты, он алтылыкты эсептеп, кээ бир жалпы маанилерди берет.
    ///
    /// Ыктыярдуу радикалдар колдоого алынат.
    ///
    /// [`is_numeric()`] менен салыштырганда, бул функция `0-9`, `a-z` жана `A-Z` белгилерин гана тааныйт.
    ///
    /// 'Digit' төмөнкү белгилерден гана турары аныкталды:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit' жөнүндө кененирээк түшүнүк алуу үчүн, [`is_numeric()`] караңыз.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// 36дан чоңураак радиус берилген болсо Panics.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// panic пайда кылган чоң радиусту өткөрүү:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// `char` ти берилген радиустагы цифрага которот.
    ///
    /// Бул жерде 'radix' кээде 'base' деп да аталат.
    /// Экөөнүн радиусу экилик санды, ондуктун радиусун, ондукту жана он алтылыкты, он алтылыкты эсептеп, кээ бир жалпы маанилерди берет.
    ///
    /// Ыктыярдуу радикалдар колдоого алынат.
    ///
    /// 'Digit' төмөнкү белгилерден гана турары аныкталды:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Эгерде `char` берилген радиустагы цифраны билдирбесе, `None` кайтарып берет.
    ///
    /// # Panics
    ///
    /// 36дан чоңураак радиус берилген болсо Panics.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Сандан өтпөсө, натыйжада:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// panic пайда кылган чоң радиусту өткөрүү:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // `radix` туруктуу жана 10 же андан кичине болгон учурларда аткаруу ылдамдыгын жакшыртуу үчүн код ушул жерге бөлүнөт
        //
        let val = if likely(radix <= 10) {
            // Эгер цифра болбосо, радикалдан чоңураак сан түзүлөт.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Белгинин он алтылык Юникоддон качышын камсыз кылган итераторду "char`s" деп кайтарат.
    ///
    /// Бул `\u{NNNNNN}` формасындагы Rust синтаксисиндеги белгилерден качып кутулат, анда `NNNNNN` он алтылыкты чагылдырат.
    ///
    ///
    /// # Examples
    ///
    /// Итератор катары:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Түздөн-түз `println!` колдонуу:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Экөө тең барабар:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` колдонуу:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 коду c==0 үчүн бир цифраны басып чыгаруу керектигин эсептейт жана (ал бирдей)(31, 32) суунун түшүшүнө жол бербейт
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // эң маанилүү алты сандык көрсөткүч
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Кеңейтилген Grapheme коддук чекиттеринен качууга мүмкүнчүлүк берген `escape_debug` тин кеңейтилген версиясы.
    /// Бул бизге саптын башталышында боштук белгилери сыяктуу белгилерди жакшыраак форматтоого мүмкүндүк берет.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// "Char`s" символдун түзмө-түз качуу кодун берген итераторду кайтарат.
    ///
    /// Бул `Debug` `str` же `char` ишке ашырылышына окшогон белгилерден качып кетет.
    ///
    ///
    /// # Examples
    ///
    /// Итератор катары:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Түздөн-түз `println!` колдонуу:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Экөө тең барабар:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` колдонуу:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// "Char`s" символдун түзмө-түз качуу кодун берген итераторду кайтарат.
    ///
    /// Демейки шартта, ар кандай тилдерде, анын ичинде C++ 11 жана ушул сыяктуу С-үй-бүлө тилдеринде мыйзамдуу болгон адабияттарды чыгаруу жагына ылайык тандалган.
    /// Так эрежелер:
    ///
    /// * Tab `\t` катары качып кетти.
    /// * Араба кайтуу `\r` катары качып кетти.
    /// * Line feed `\n` катары качып кетти.
    /// * Single quote `\'` деп качып кетти.
    /// * Кош цитата `\"` катары качып кетти.
    /// * Арткы сызык `\\` катары качып кетти.
    /// * 'Басылып чыгарыла турган ASCII' `0x20` .. `0x7e` камтылган ар кандай символдон качып кутула албайбыз.
    /// * Бардык башка белгилерге он алтылык Юникоддун качуусу берилген;[`escape_unicode`] карагыла.
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Итератор катары:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Түздөн-түз `println!` колдонуу:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Экөө тең барабар:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` колдонуу:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// UTF-8 коддолгон болсо, `char` талап кылынган байттардын санын кайтарат.
    ///
    /// Бул байттардын саны ар дайым 1ден 4кө чейин, анын ичинде.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` түрү анын мазмунунун UTF-8 экендигине кепилдик берет, ошондуктан ар бир код чекити `char` жана `&str` дин өзүндө көрсөтүлсө, анын узактыгын салыштыра алабыз:
    ///
    ///
    /// ```
    /// // Чарс катары
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // экөө тең үч байт түрүндө чагылдырылышы мүмкүн
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // &str катары, бул экөө UTF-8 менен коддолгон
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // бардыгы алты байт алышкандыгын көрө алабыз ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... &str сыяктуу
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// UTF-16 коддолгон болсо, `char` керек болгон 16 биттик код бирдигинин санын кайтарат.
    ///
    ///
    /// Бул түшүнүктү көбүрөөк түшүндүрүү үчүн [`len_utf8()`] үчүн документтерди караңыз.
    /// Бул функция күзгү, бирок UTF-8 ордуна UTF-16 үчүн.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Берилген байт буферине бул белгини UTF-8 деп коддолот, андан кийин коддолгон символду камтыган буфердин сублипсин кайтарат.
    ///
    ///
    /// # Panics
    ///
    /// Эгерде буфер жетишсиз болсо, Panics.
    /// Узундугу төрт буфер ар кандай `char` ти коддоо үчүн жетиштүү.
    ///
    /// # Examples
    ///
    /// Ушул эки мисалда тең 'ß' эки байтты коддойт.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Буфер өтө кичинекей:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // КООПСУЗДУК: `char` суррогат эмес, андыктан бул UTF-8 жарактуу.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Берилген `u16` буферине бул белгини UTF-16 катары коддоп, андан кийин коддолгон белгини камтыган буфердин сублипсин кайтарат.
    ///
    ///
    /// # Panics
    ///
    /// Эгерде буфер жетишсиз болсо, Panics.
    /// Узундугу 2 буфер каалаган `char` ти коддоо үчүн жетиштүү.
    ///
    /// # Examples
    ///
    /// Ушул эки мисалда тең '𝕊' эки u16 кодун алат.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Буфер өтө кичинекей:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Бул `char` `Alphabetic` касиетине ээ болсо, `true` берет.
    ///
    /// `Alphabetic` [Unicode Standard] 4-бөлүмүндө (Белги касиеттери) сүрөттөлгөн жана [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] те көрсөтүлгөн.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // сүйүү көп нерсе, бирок алфавит эмес
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Бул `char` `Lowercase` касиетине ээ болсо, `true` берет.
    ///
    /// `Lowercase` [Unicode Standard] 4-бөлүмүндө (Белги касиеттери) сүрөттөлгөн жана [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] те көрсөтүлгөн.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Ар кандай кытай сценарийлеринде жана пунктуациясында орун жок, ошондуктан:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Бул `char` `Uppercase` касиетине ээ болсо, `true` берет.
    ///
    /// `Uppercase` [Unicode Standard] 4-бөлүмүндө (Белги касиеттери) сүрөттөлгөн жана [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] те көрсөтүлгөн.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Ар кандай кытай сценарийлеринде жана пунктуациясында орун жок, ошондуктан:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Бул `char` `White_Space` касиетине ээ болсо, `true` берет.
    ///
    /// `White_Space` [Unicode Character Database][ucd] [`PropList.txt`] те көрсөтүлгөн.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // үзүлбөгөн мейкиндик
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Эгерде `char` [`is_alphabetic()`] же [`is_numeric()`] талаптарын канааттандырса, `true` кайтарып берет.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Эгерде `char` башкаруу коддору үчүн жалпы категорияга ээ болсо, `true` берет.
    ///
    /// Башкаруу коддору (`Cc` жалпы категориясы бар коддук чекиттер) [Unicode Standard] 4-бөлүмүндө (Белги касиеттери) сүрөттөлгөн жана [Unicode Character Database][ucd] [`UnicodeData.txt`] те көрсөтүлгөн.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// // U + 009C, STRING ТЕРМИНАТОРУ
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Бул `char` `Grapheme_Extend` касиетине ээ болсо, `true` берет.
    ///
    /// `Grapheme_Extend` [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] сүрөттөлгөн жана [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] көрсөтүлгөн.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Бул `char` сандар үчүн жалпы категориялардын бири болсо, `true` берет.
    ///
    /// Сандар үчүн жалпы категориялар (ондук сандар үчүн `Nd`, тамга сыяктуу сандык белгилер үчүн `Nl` жана башка сандык белгилер үчүн `No`) [Unicode Character Database][ucd] [`UnicodeData.txt`] те көрсөтүлгөн.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Ушул `char` тин кичине картасынын картасын бир же андан көп кылып берген итераторду кайтарат
    /// `char`s.
    ///
    /// Эгерде бул `char` кичине картага түшүрбөсө, анда итератор ошол эле `char` берет.
    ///
    /// Эгерде бул `char` [Unicode Character Database][ucd] [`UnicodeData.txt`] берген бир-бирден кичинекей картага ээ болсо, анда кайталоочу `char` берет.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Эгер бул `char` өзгөчө ойлорду талап кылса (мисалы, бир нече `char`s), итератор [`SpecialCasing.txt`] берген`char` (лорду) берет.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Бул иш шартсыз картага түшүрүүнү аткарбастан аткарат.Башкача айтканда, которуу контекстке жана тилге көз каранды эмес.
    ///
    /// [Unicode Standard] те, 4-бөлүмдө (Белгилердин касиеттери) иштин картографиясын жалпысынан талкуулайт жана 3-бөлүмдө (Conformance) иштин конверсиясынын демейки алгоритмин талкуулайт.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Итератор катары:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Түздөн-түз `println!` колдонуу:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Экөө тең барабар:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` колдонуу:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Кээде натыйжа бирден ашык белги берет:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Баш тамга жана кичине тамга болбогон белгилер өзүнө айланат.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Ушул `char` тин башкы тамга картасын бир же андан көп кылып берген итераторду кайтарат
    /// `char`s.
    ///
    /// Эгерде бул `char` чоң тамга менен картага түшүрбөсө, анда итератор ошол эле `char` берет.
    ///
    /// Эгерде бул `char` [Unicode Character Database][ucd] [`UnicodeData.txt`] тарабынан берилген бирден-бир чоң картага ээ болсо, анда кайталоочу `char` берет.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Эгер бул `char` өзгөчө ойлорду талап кылса (мисалы, бир нече `char`s), итератор [`SpecialCasing.txt`] берген`char` (лорду) берет.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Бул иш шартсыз картага түшүрүүнү аткарбастан аткарат.Башкача айтканда, которуу контекстке жана тилге көз каранды эмес.
    ///
    /// [Unicode Standard] те, 4-бөлүмдө (Белгилердин касиеттери) иштин картографиясын жалпысынан талкуулайт жана 3-бөлүмдө (Conformance) иштин конверсиясынын демейки алгоритмин талкуулайт.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Итератор катары:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Түздөн-түз `println!` колдонуу:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Экөө тең барабар:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` колдонуу:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Кээде натыйжа бирден ашык белги берет:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Баш тамга жана кичине тамга болбогон белгилер өзүнө айланат.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Жергиликтүү тил жөнүндө эскертүү
    ///
    /// Латын тилинде 'i' эквиваленти экөөнүн ордуна беш түргө ээ:
    ///
    /// * 'Dotless': I/ı, кээде ï деп жазылат
    /// * 'Dotted': İ/i
    ///
    /// Чекиттүү 'i' латын тамгасы менен бирдей экендигин эске алыңыз.Ошондуктан:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Бул жерде `upper_i` мааниси тексттин тилине таянат: эгер биз `en-US` болсо, ал `"I"`, ал эми `tr_TR` болсо, `"İ"` болушу керек.
    /// `to_uppercase()` муну эске албайт, ошондуктан:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// тилдерде колдонулат.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Мааниси ASCII чегинде экендигин текшерет.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Маанинин көчүрмөсүн ASCII чоң тамга эквивалентинде жасайт.
    ///
    /// 'a' тен 'z' ке чейинки ASCII тамгалары 'A' тен 'Z' ке чейин картага түшүрүлөт, бирок ASCII эмес тамгалар өзгөрүүсүз болот.
    ///
    /// Орнундагы маанини чоңойтуш үчүн [`make_ascii_uppercase()`] колдонуңуз.
    ///
    /// ASCII эмес белгилерден тышкары, ASCII тамгаларын чоңойтуу үчүн, [`to_uppercase()`] колдонуңуз.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Маанинин көчүрмөсүн ASCII кичинекей тамга эквивалентинде жасайт.
    ///
    /// 'A' тен 'Z' ке чейинки ASCII тамгалары 'a' тен 'z' ке чейин картага түшүрүлөт, бирок ASCII эмес тамгалар өзгөрүүсүз болот.
    ///
    /// Орнундагы маанисин төмөндөтүү үчүн, [`make_ascii_lowercase()`] колдонуңуз.
    ///
    /// ASCII эмес символдордон тышкары ASCII белгилерин кичирейтүү үчүн [`to_lowercase()`] колдонуңуз.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Эки чоңдук ASCII регистрге сезимсиз дал келгенин текшерет.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` менен барабар.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Бул түрдү ордуна ASCII баш тамга эквивалентине которот.
    ///
    /// 'a' тен 'z' ке чейинки ASCII тамгалары 'A' тен 'Z' ке чейин картага түшүрүлөт, бирок ASCII эмес тамгалар өзгөрүүсүз болот.
    ///
    /// Мурунку баасын өзгөртпөстөн, жаңы баш тамга маанисин кайтаруу үчүн [`to_ascii_uppercase()`] колдонуңуз.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Бул түрдү ордуна ASCII кичинекей тамга эквивалентине которот.
    ///
    /// 'A' тен 'Z' ке чейинки ASCII тамгалары 'a' тен 'z' ке чейин картага түшүрүлөт, бирок ASCII эмес тамгалар өзгөрүүсүз болот.
    ///
    /// Мурунку баасын өзгөртпөстөн, жаңы кичине маанини кайтаруу үчүн [`to_ascii_lowercase()`] колдонуңуз.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Бул маани ASCII алфавиттик белги экендигин текшерет:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', же
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Бул маанинин ASCII чоң тамга белгиси экендигин текшерет:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Бул маани ASCII кичине тамга экендигин текшерет:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Бул маани ASCII тамга-цифралык белгиси экендигин текшерет:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', же
    /// - U + 0061 'a' ..=U + 007A 'z', же
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Бул маани ASCII ондук цифрасы экендигин текшерет:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Бул маани ASCII он алтылык цифрасы экендигин текшерет:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', же
    /// - U + 0041 'A' ..=U + 0046 'F', же
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Бул маани ASCII тыныш белгилери экендигин текшерет:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, же
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, же
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, же
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Бул маани ASCII графикалык белгиси экендигин текшерет:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Бул маани ASCII боштук символу экендигин текшерет:
    /// U + 0020 космос, U + 0009 горизонталдык таблица, U + 000A линиялуу тоют, U + 000C формадагы тоют, же U + 000D ташуунун кайтып келиши.
    ///
    /// Rust WhatWG Infra Standard [definition of ASCII whitespace][infra-aw] колдонот.Кеңири колдонулган дагы бир нече аныктамалар бар.
    /// Мисалы, [the POSIX locale][pct] курамына U + 000B VERTICAL TAB, ошондой эле жогоруда көрсөтүлгөн бардык белгилер кирет, бирок-ошол эле спецификациядан-[Bourne shell деги "field splitting" үчүн демейки эреже][bfs]*гана* SPACE, HORIZONTAL TAB жана Боштук катары LINE FEED.
    ///
    ///
    /// Эгерде сиз мурунтан бар болгон файл форматын иштете турган программа жазып жатсаңыз, анда бул функцияны колдонуудан мурун, анын боштук мейкиндигин кандай форматта аныктагандыгын текшериңиз.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Бул маани ASCII башкаруу символу экендигин текшерет:
    /// U + 0000 NUL ..=U + 001F БӨЛҮКТҮ СЕПАРАТОР, же U + 007F ӨЧҮРҮҮ.
    /// Ак мейкиндиктин көпчүлүк ASCII белгилери башкаруучу белгилер экендигин, бирок SPACE андай эмес экендигин эске алыңыз.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Берилген байт буферине чийки u32 маанисин UTF-8 катары коддоп, андан кийин коддолгон белгини камтыган буфердин сублипсин кайтарат.
///
///
/// `char::encode_utf8` тен айырмаланып, бул ыкма суррогаттык диапазондогу кодоиндерди дагы иштетет.
/// (Суррогаттык диапазондо `char` түзүү UB.) Натыйжада [generalized UTF-8] жарактуу, бирок UTF-8 жараксыз.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Эгерде буфер жетишсиз болсо, Panics.
/// Узундугу төрт буфер ар кандай `char` ти коддоо үчүн жетиштүү.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Берилген `u16` буферине UTF-16 катары чийки u32 маанисин коддоп, андан кийин коддолгон белгини камтыган буфердин көмүскө бөлүгүн кайтарат.
///
///
/// `char::encode_utf16` тен айырмаланып, бул ыкма суррогаттык диапазондогу кодоиндерди дагы иштетет.
/// (Суррогаттык диапазондо `char` түзүү UB.)
///
/// # Panics
///
/// Эгерде буфер жетишсиз болсо, Panics.
/// Узундугу 2 буфер каалаган `char` ти коддоо үчүн жетиштүү.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // КООПСУЗДУК: ар бир кол жазууга жетиштүү бит бар же жок экендигин текшерет
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP аркылуу түшөт
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Кошумча учактар орун басарларга бөлүнүп киришет.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}