#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Көрсөтүлгөн типтеги көрсөткүчтүн метадайындарынын түрүн берет.
///
/// # Көрсөткүчтүн метадайындары
///
/// Rust деги чийки көрсөткүчтөрдүн түрлөрү жана шилтеме түрлөрү эки бөлүктөн турат деп ойлошубуз мүмкүн:
/// маанинин эс тутум дарегин камтыган маалымат көрсөткүчү жана айрым метадайындар.
///
/// Статикалык чоңдуктагы типтер үчүн (`Sized` traits ди ишке ашыруучу), ошондой эле `extern` түрлөрү үчүн көрсөткүчтөр "ичке" деп айтылат: метадайындар нөл өлчөмүндө жана анын түрү `()`.
///
///
/// [dynamically-sized types][dst] көрсөткүчтөрү "кенен" же "семиз" деп аталат, алардын нөлдүк эмес метадайындары бар:
///
/// * Акыркы талаасы DST болгон структуралар үчүн метадайындар акыркы талаанын метадайындары болуп саналат
/// * `str` түрү үчүн метадайындар `usize` байт менен узундугу
/// * `[T]` сыяктуу кесинди түрлөрү үчүн метадайындар `usize` өлчөмүндөгү узундугу
/// * `dyn SomeTrait` сыяктуу trait объектилери үчүн метадайындар [`DynMetadata<Self>`][DynMetadata] (мисалы, `DynMetadata<dyn SomeTrait>`)
///
/// future тилинде Rust тили ар башка көрсөткүч метадайындары бар жаңы типтерге ээ болушу мүмкүн.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Бул trait дин чекити анын `Metadata` байланышкан түрү, ал жогоруда баяндалгандай `()` же `usize` же `DynMetadata<_>`.
/// Ал ар бир түрү үчүн автоматтык түрдө ишке ашырылат.
/// Тийиштүү чеги жок болсо дагы, жалпы контекстте ишке ашырылат деп болжолдоого болот.
///
/// # Usage
///
/// Чийки көрсөткүчтөрдү [`to_raw_parts`] ыкмасы менен маалымат дарегине жана мета-маалымат компоненттерине ажыратууга болот.
///
/// Же болбосо, метадайындарды [`metadata`] функциясы менен гана чыгарып алса болот.
/// Маалымдаманы [`metadata`] ке өткөрүп, ачыктан-ачык мажбурлоого болот.
///
/// (possibly-wide) көрсөткүчүн [`from_raw_parts`] же [`from_raw_parts_mut`] даректеринен жана метадайындарынан кайра бириктирүүгө болот.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// `Self` көрсөткүчтөрү жана шилтемелердеги метадайындардын түрү.
    #[lang = "metadata_type"]
    // NOTE: `static_assert_expected_bounds_for_metadata` ичинде trait bounds кармаңыз
    //
    // `library/core/src/ptr/metadata.rs` менен бул жердегилер менен шайкештештирилген:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Ушул trait псевдонимин жүзөгө ашырган типтерге көрсөткүчтөр "ичке".
///
/// Бул статикалык-Size` жана `extern` түрлөрүн камтыйт.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: муну trait лакап аттары тилде туруктуу болгонго чейин турукташтырбайсызбы?
pub trait Thin = Pointee<Metadata = ()>;

/// Көрсөткүчтүн метадайындарын бөлүп алыңыз.
///
/// `*mut T`, `&T` же `&mut T` типтеги маанилер түздөн-түз `* const T` ке мажбурлагандыктан, ушул функцияга берилиши мүмкүн.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // КООПСУЗДУК: `PtrRepr` бирлигинен мааниге жетүү * const Tден бери коопсуз
    // жана PtrComponents<T>бирдей эс макетине ээ.
    // Бул кепилдикти std гана бере алат.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Маалымат дарегинен жана метадайындардан (possibly-wide) чийки көрсөткүчтү түзөт.
///
/// Бул функция коопсуз, бирок кайтарылган көрсөткүч сөзсүз түрдө жокко чыгарылышы мүмкүн эмес.
/// Кесиндилер үчүн, коопсуздук талаптары үчүн [`slice::from_raw_parts`] документтерин караңыз.
/// trait объектилери үчүн метадайындар көрсөткүчтөн ошол эле эскирген типке келиши керек.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // КООПСУЗДУК: `PtrRepr` бирлигинен мааниге жетүү * const Tден бери коопсуз
    // жана PtrComponents<T>бирдей эс макетине ээ.
    // Бул кепилдикти std гана бере алат.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Чийки `*mut` көрсөткүчү, тескерисинче, чийки `* const` көрсөткүчүнөн айырмаланып, [`from_raw_parts`] сыяктуу эле функцияны аткарат.
///
///
/// Көбүрөөк маалымат алуу үчүн [`from_raw_parts`] тин документтерин караңыз.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // КООПСУЗДУК: `PtrRepr` бирлигинен мааниге жетүү * const Tден бери коопсуз
    // жана PtrComponents<T>бирдей эс макетине ээ.
    // Бул кепилдикти std гана бере алат.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// `T: Copy` байланышын болтурбоо үчүн кол маани керек.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// `T: Clone` байланышын болтурбоо үчүн кол маани керек.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait объектинин түрү үчүн метадайындар.
///
/// Бул trait объектисинин ичинде сакталган бетон түрүн иштетүү үчүн бардык керектүү маалыматтарды чагылдырган vtable (виртуалдык чалуулар жадыбалы) көрсөткүчү.
/// Vtable курамында төмөнкүлөр бар:
///
/// * түрүнүн көлөмү
/// * тип тегиздөө
/// * түрдөгү `drop_in_place` имплдин көрсөткүчү (жөнөкөй эски маалыматтар үчүн тыюу салынышы мүмкүн)
/// * trait түрүн жүзөгө ашыруунун бардык ыкмаларын көрсөткөн
///
/// Биринчи үчөө өзгөчө экендигин эске алыңыз, анткени алар каалаган trait объектилерин бөлүштүрүп, таштап жана бөлүштүрүп алышы керек.
///
/// Бул структураны `dyn` trait объектиси болбогон (мисалы `DynMetadata<u64>`) типтик параметр менен атоого болот, бирок ал структуранын маанисин алуу мүмкүн эмес.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Бардык vtablesдин жалпы префикси.Андан кийин trait методдорунун функционалдык көрсөткүчтөрү чыгат.
///
/// `DynMetadata::size_of` ж.б. жеке ишке ашыруу чоо-жайы.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Ушул vtable менен байланышкан түрдүн көлөмүн кайтарып берет.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Ушул vtable менен байланышкан типтин тегиздөөсүн кайтарат.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Өлчөмүн жана тегиздөөсүн `Layout` катары кайтарып берет
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // КООПСУЗДУК: компилятор бул VTableди Rust бетон түрүнө бөлүп чыгарган
        // жарактуу макетке ээ экендиги белгилүү.`Layout::for_value` тегидей жүйөө.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// `Dyn: $Trait` чек араларын болтурбоо үчүн колдонмо имплдер.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}