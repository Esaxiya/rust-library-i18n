use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Чийки эмес `*mut T` тегерегиндеги ором, бул оромдун ээсинин референтке ээ экендигин көрсөтөт.
/// `Box<T>`, `Vec<T>`, `String` жана `HashMap<K, V>` сыяктуу абстракцияларды куруу үчүн пайдалуу.
///
/// `*mut T` айырмаланып, `Unique<T>` "as if" иштейт, бул `T` мисалы болгон.
/// Эгер `T` `Send`/`Sync` болсо, ал `Send`/`Sync` ти ишке ашырат.
/// Ошондой эле, `T` мисалы күтүүгө мүмкүн болгон күчтүү лакап кепилдиктердин түрүн билдирет:
/// көрсөткүчтүн референти ага ээ болгон уникалдуу жолсуз өзгөртүлбөшү керек.
///
/// Эгер `Unique` ти максатыңызга ылайыктуу деп туура эмес деп билсеңиз, анда семантикасы начарыраак `NonNull` ти колдонуп көрүңүз.
///
///
/// `*mut T` тен айырмаланып, көрсөткүч эч качан ажыратылбаса дагы, көрсөткүч ар дайым нөл болбошу керек.
/// Энумдар тыюу салынган маанини дискриминант катары колдонушу үчүн-`Option<Unique<T>>` `Unique<T>` менен бирдей өлчөмдө болот.
/// Бирок, эгерде ал ажыратылбаса, көрсөткүч дагы деле солгундашы мүмкүн.
///
/// `*mut T` айырмаланып, `Unique<T>` `T` караганда ковариант болуп саналат.
/// Бул Unique компаниясынын лакап аталышынын талаптарын колдогон ар кандай түргө туура келиши керек.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: бул маркердин дисперсияга эч кандай кесепети жок, бирок зарыл
    // анткени биз `T` логикалуу түрдө ээ экенибизди түшүнүү үчүн dropck үчүн.
    //
    // Чоо-жайын көрүү үчүн:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` көрсөткүчтөр `Send`, эгер `T` `Send` болсо, анткени алар шилтеме берген маалыматтар эч нерсеге негизделбейт.
/// Эскертүү, бул лакап инвариант тип системасы тарабынан аткарылбайт;`Unique` колдонулган абстракция аны аткарышы керек.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` көрсөткүчтөр `Sync`, эгер `T` `Sync` болсо, анткени алар шилтеме берген маалыматтар эч нерсеге негизделбейт.
/// Эскертүү, бул лакап инвариант тип системасы тарабынан аткарылбайт;`Unique` колдонулган абстракция аны аткарышы керек.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Асылып турган, бирок жакшы шайкеш келген жаңы `Unique` түзөт.
    ///
    /// Бул `Vec::new` сыяктуу жалкоо бөлүштүрүүчү түрлөрүн баштоо үчүн пайдалуу.
    ///
    /// Көрсөткүч мааниси `T` үчүн жарактуу көрсөткүчтү көрсөтүшү мүмкүн экендигин эске алыңыз, демек, аны "not yet initialized" кароолчу мааниси катары колдонбош керек.
    /// Бөлүп берген түрлөрү башка жолдор менен инициализацияны байкап турушу керек.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // КООПСУЗДУК: mem::align_of() жарактуу, нөл эмес көрсөткүчтү кайтарып берет.The
        // new_unchecked() чалуу шарттары сакталат.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Жаңы `Unique` түзөт.
    ///
    /// # Safety
    ///
    /// `ptr` нөл болбошу керек.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // КООПСУЗДУК: чалган адам `ptr` нөл эмес экендигине кепилдик бериши керек.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Эгерде `ptr` нөл эмес болсо, жаңы `Unique` түзөт.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // КООПСУЗДУК: Көрсөтүүчү мурунтан эле текшерилген жана нөл эмес.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Негизги `*mut` көрсөткүчүн алат.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Мазмунду кыскартуу.
    ///
    /// Натыйжада, өмүр бою өзүн-өзү байланыштырат, ошондуктан бул "as if" жүрүм-туруму, карызга алынып жаткан Т мисалы болгон.
    /// Эгер узак (unbound) өмүрү керек болсо, `&*my_ptr.as_ptr()` колдонуңуз.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // КООПСУЗДУК: чалган адам `self` баардык талаптарга жооп берерине кепилдик бериши керек
        // маалымдама үчүн талаптар.
        unsafe { &*self.as_ptr() }
    }

    /// Мазмунду өзгөртөбүз.
    ///
    /// Натыйжада, өмүр бою өзүн-өзү байланыштырат, ошондуктан бул "as if" жүрүм-туруму, карызга алынып жаткан Т мисалы болгон.
    /// Эгер узак (unbound) өмүрү керек болсо, `&mut *my_ptr.as_ptr()` колдонуңуз.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // КООПСУЗДУК: чалган адам `self` баардык талаптарга жооп берерине кепилдик бериши керек
        // өзгөрүлмө шилтеме боюнча талаптар.
        unsafe { &mut *self.as_ptr() }
    }

    /// Башка типтеги көрсөткүчкө ыргытылат.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // КООПСУЗДУК: Unique::new_unchecked() жаңы уникалдуу жана муктаждыктарды жаратат
        // берилген көрсөткүч нөл болбошу керек.
        // Өзүбүздү көрсөткүч катары өткөрүп жаткандыктан, ал нөл болушу мүмкүн эмес.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // КООПСУЗДУК: өзгөрүлмө шилтеме нөл болушу мүмкүн эмес
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}