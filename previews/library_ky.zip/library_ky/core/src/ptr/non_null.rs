use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` бирок нөл эмес жана ковариант.
///
/// Бул көп учурда чийки көрсөткүчтөрдү колдонуп, маалымат структураларын курууда колдонула турган туура нерсе, бирок кошумча касиеттеринен улам, колдонуу кыйла кооптуу.`NonNull<T>` колдонуш керектигине көзүңүз жетпесе, `*mut T` ти колдонуңуз!
///
/// `*mut T` тен айырмаланып, көрсөткүч эч качан ажыратылбаса дагы, көрсөткүч ар дайым нөл болбошу керек.Энумдар тыюу салынган маанини дискриминант катары колдонушу үчүн-`Option<NonNull<T>>` `* mut T` өлчөмүндөй.
/// Бирок, эгерде ал ажыратылбаса, көрсөткүч дагы деле солгундашы мүмкүн.
///
/// `*mut T` тен айырмаланып, `NonNull<T>` `T` үстүнөн ковариант болуп тандалган.Бул ковариант түрлөрүн курууда `NonNull<T>` колдонууга мүмкүндүк берет, бирок чындыгында ковариант болбошу керек болгон түрдө колдонулса, анда негизсиздик коркунучу пайда болот.
/// (Карама-каршы тандоо `*mut T` үчүн жасалган, бирок техникалык жактан кооптуу функцияларды чакыруудан улам гана болушу мүмкүн.)
///
/// Коварианс `Box`, `Rc`, `Arc`, `Vec` жана `LinkedList` сыяктуу эң коопсуз абстракциялар үчүн туура келет.Бул Rust кадимки жалпы XOR өзгөрүлмө эрежелерине ылайык келген коомдук API сунуш кылгандыгы үчүн ушундай болду.
///
/// Эгер сиздин түрүңүз коварияттуу боло албаса, анда анын инвариантты камсыз кылган кошумча талаасы бар экендигин текшерип көрүшүңүз керек.Көбүнчө бул талаа `PhantomData<Cell<T>>` же `PhantomData<&'a mut T>` сыяктуу [`PhantomData`] түрү болот.
///
/// `NonNull<T>` `&T` үчүн `From` мисалы бар экендигин байкаңыз.Бирок, бул (а көрсөткүчүнөн алынган) жалпы шилтеме аркылуу мутация, мутация [`UnsafeCell<T>`] ичинде болбосо, аныкталбаган жүрүм-турум экендигин өзгөртпөйт.Ошол эле жалпы шилтемеден өзгөрүлмө шилтеме түзүүгө болот.
///
/// Бул `From` мисалын `UnsafeCell<T>` сиз колдонгондо, `as_mut` эч качан чакырылбашы жана `as_ptr` эч качан мутация үчүн колдонулбашы үчүн сиздин милдетиңиз.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` көрсөткүчтөр `Send` эмес, анткени алар шилтеме берген дайындар ылакап болушу мүмкүн.
// NB, бул имплементтин кереги жок, бирок ката жөнүндө жакшыраак билдирүүлөрдү бериши керек.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` көрсөткүчтөр `Sync` эмес, анткени алар шилтеме берген дайындар ылакап болушу мүмкүн.
// NB, бул имплементтин кереги жок, бирок ката жөнүндө жакшыраак билдирүүлөрдү бериши керек.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Асылып турган, бирок жакшы шайкеш келген жаңы `NonNull` түзөт.
    ///
    /// Бул `Vec::new` сыяктуу жалкоо бөлүштүрүүчү түрлөрүн баштоо үчүн пайдалуу.
    ///
    /// Көрсөткүч мааниси `T` үчүн жарактуу көрсөткүчтү көрсөтүшү мүмкүн экендигин эске алыңыз, демек, аны "not yet initialized" кароолчу мааниси катары колдонбош керек.
    /// Бөлүп берген түрлөрү башка жолдор менен инициализацияны байкап турушу керек.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // КООПСУЗДУК: mem::align_of() нөлдүк эмес колдонууну кайтарат, андан кийин ырасталат
        // а * мут Т.
        // Демек, `ptr` нөл эмес жана new_unchecked() чалуу шарттары сакталат.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Мааниге бөлүшүлгөн шилтемелерди кайтарып берет.[`as_ref`] тен айырмаланып, бул маанини инициалдаштырууну талап кылбайт.
    ///
    /// Өзгөрүлө турган кесиптеши үчүн [`as_uninit_mut`] караңыз.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Бул ыкманы чакырганда, төмөнкүлөрдүн бардыгы чын экенине ынануу керек:
    ///
    /// * Көрсөтүүчү туура тегизделиши керек.
    ///
    /// * [the module documentation] те аныкталган мааниде "dereferencable" болушу керек.
    ///
    /// * Сиз Rust лакап аты эрежелерин колдонушуңуз керек, анткени кайтарылган `'a` өмүрү өзүм билемдик менен тандалып алынган жана сөзсүз түрдө маалыматтын чыныгы жашоосун чагылдырбайт.
    ///
    ///   Атап айтканда, ушул өмүр бою, көрсөткүч көрсөткөн эс тутум мутацияланбашы керек (`UnsafeCell` ичинен тышкары).
    ///
    /// Бул ыкманын натыйжасы колдонулбаса дагы колдонулат!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // КООПСУЗДУК: чалган адам `self` баардык талаптарга жооп берерине кепилдик бериши керек
        // маалымдама үчүн талаптар.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Мааниге уникалдуу шилтемелерди кайтарат.[`as_mut`] тен айырмаланып, бул маанини инициалдаштырууну талап кылбайт.
    ///
    /// Жалпы кесиптеши үчүн [`as_uninit_ref`] караңыз.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Бул ыкманы чакырганда, төмөнкүлөрдүн бардыгы чын экенине ынануу керек:
    ///
    /// * Көрсөтүүчү туура тегизделиши керек.
    ///
    /// * [the module documentation] те аныкталган мааниде "dereferencable" болушу керек.
    ///
    /// * Сиз Rust лакап аты эрежелерин колдонушуңуз керек, анткени кайтарылган `'a` өмүрү өзүм билемдик менен тандалып алынган жана сөзсүз түрдө маалыматтын чыныгы жашоосун чагылдырбайт.
    ///
    ///   Атап айтканда, ушул өмүр бою, көрсөткүч көрсөткөн эс тутумга башка көрсөткүч аркылуу жетүүгө (окууга жана жазууга) жол берилбеши керек.
    ///
    /// Бул ыкманын натыйжасы колдонулбаса дагы колдонулат!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // КООПСУЗДУК: чалган адам `self` баардык талаптарга жооп берерине кепилдик бериши керек
        // маалымдама үчүн талаптар.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Жаңы `NonNull` түзөт.
    ///
    /// # Safety
    ///
    /// `ptr` нөл болбошу керек.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // КООПСУЗДУК: чалган адам `ptr` нөл эмес экендигине кепилдик бериши керек.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Эгерде `ptr` нөл эмес болсо, жаңы `NonNull` түзөт.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // КООПСУЗДУК: Көрсөтүүчү мурунтан эле текшерилген жана нөл эмес
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// [`std::ptr::from_raw_parts`] көрсөткүчүнөн айырмаланып, `NonNull` көрсөткүчү кайтарылып берилбесе, [`std::ptr::from_raw_parts`] сыяктуу эле функцияны аткарат.
    ///
    ///
    /// Көбүрөөк маалымат алуу үчүн [`std::ptr::from_raw_parts`] тин документтерин караңыз.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // КООПСУЗДУК: `ptr::from::raw_parts_mut` натыйжасы нөл эмес, анткени `data_address` болуп саналат.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Көрсөткүчтү дарек жана мета-берилиш компоненттерине ажырата аласыз.
    ///
    /// Көрсөткүчтү кийин [`NonNull::from_raw_parts`] менен калыбына келтирүүгө болот.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Негизги `*mut` көрсөткүчүн алат.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Жалпы мааниге шилтеме берет.Эгер маани инициализацияланбаса, анын ордуна [`as_uninit_ref`] колдонулушу керек.
    ///
    /// Өзгөрүлө турган кесиптеши үчүн [`as_mut`] караңыз.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Бул ыкманы чакырганда, төмөнкүлөрдүн бардыгы чын экенине ынануу керек:
    ///
    /// * Көрсөтүүчү туура тегизделиши керек.
    ///
    /// * [the module documentation] те аныкталган мааниде "dereferencable" болушу керек.
    ///
    /// * Көрсөтүүчү `T` инициалдаштырылган нускасын көрсөтүшү керек.
    ///
    /// * Сиз Rust лакап аты эрежелерин колдонушуңуз керек, анткени кайтарылган `'a` өмүрү өзүм билемдик менен тандалып алынган жана сөзсүз түрдө маалыматтын чыныгы жашоосун чагылдырбайт.
    ///
    ///   Атап айтканда, ушул өмүр бою, көрсөткүч көрсөткөн эс тутум мутацияланбашы керек (`UnsafeCell` ичинен тышкары).
    ///
    /// Бул ыкманын натыйжасы колдонулбаса дагы колдонулат!
    /// (Инификациялоо бөлүгү азырынча толук чечиле элек, бирок ага чейин бирден-бир коопсуз ыкма алардын чындыгында инициалдаштырылышын камсыз кылуу болуп саналат.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // КООПСУЗДУК: чалган адам `self` баардык талаптарга жооп берерине кепилдик бериши керек
        // маалымдама үчүн талаптар.
        unsafe { &*self.as_ptr() }
    }

    /// Мааниге уникалдуу шилтеме берет.Эгер маани инициализацияланбаса, анын ордуна [`as_uninit_mut`] колдонулушу керек.
    ///
    /// Жалпы кесиптеши үчүн [`as_ref`] караңыз.
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Бул ыкманы чакырганда, төмөнкүлөрдүн бардыгы чын экенине ынануу керек:
    ///
    /// * Көрсөтүүчү туура тегизделиши керек.
    ///
    /// * [the module documentation] те аныкталган мааниде "dereferencable" болушу керек.
    ///
    /// * Көрсөтүүчү `T` инициалдаштырылган нускасын көрсөтүшү керек.
    ///
    /// * Сиз Rust лакап аты эрежелерин колдонушуңуз керек, анткени кайтарылган `'a` өмүрү өзүм билемдик менен тандалып алынган жана сөзсүз түрдө маалыматтын чыныгы жашоосун чагылдырбайт.
    ///
    ///   Атап айтканда, ушул өмүр бою, көрсөткүч көрсөткөн эс тутумга башка көрсөткүч аркылуу жетүүгө (окууга жана жазууга) жол берилбеши керек.
    ///
    /// Бул ыкманын натыйжасы колдонулбаса дагы колдонулат!
    /// (Инификациялоо бөлүгү азырынча толук чечиле элек, бирок ага чейин бирден-бир коопсуз ыкма алардын чындыгында инициалдаштырылышын камсыз кылуу болуп саналат.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // КООПСУЗДУК: чалган адам `self` баардык талаптарга жооп берерине кепилдик бериши керек
        // өзгөрүлмө шилтеме боюнча талаптар.
        unsafe { &mut *self.as_ptr() }
    }

    /// Башка типтеги көрсөткүчкө ыргытылат.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // КООПСУЗДУК: `self` сөзсүз түрдө нөл болбогон `NonNull` көрсөткүчү
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Жука көрсөткүчтөн жана узундуктан нөлдүк чийки кесинди жаратат.
    ///
    /// `len` аргументи-бул байттардын саны эмес,**элементтердин саны**.
    ///
    /// Бул функция коопсуз, бирок кайтарып берүү маанисин кооптуу деп айтууга болот.
    /// Тилектин коопсуздугу боюнча [`slice::from_raw_parts`] документтерин караңыз.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // биринчи элементтин көрсөткүчү менен баштаганда кесим көрсөткүчтү түзүү
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Эске салсак, бул мисал жасалма түрдө ушул ыкманын колдонулушун көрсөтөт, бирок `тилим= NonNull::from(&x[..]);` would be a better way to write code like this.) болсун
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // КООПСУЗДУК: `data` сөзсүз түрдө нөл болбогон `NonNull` көрсөткүчү
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Ноль эмес чийки кесиндинин узундугун кайтарып берет.
    ///
    /// Кайтарылган маани-бул байттардын саны эмес,**элементтердин саны**.
    ///
    /// Бул функция жараксыз, чийки кесинди кесимге алмаштырылбай калса дагы, коопсуз, анткени көрсөткүчтүн дареги туура эмес.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Нөл эмес көрсөткүчтү кесимдин буферине кайтарат.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // КООПСУЗДУК: Биз билебиз, `self` жок.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Чийки көрсөткүчтү кесимдин буферине кайтарат.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Мүмкүн демилгеленбеген маанилердин бөлүгүнө бөлүшүлгөн шилтемени кайтарып берет.[`as_ref`] тен айырмаланып, бул маанини инициалдаштырууну талап кылбайт.
    ///
    /// Өзгөрүлө турган кесиптеши үчүн [`as_uninit_slice_mut`] караңыз.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Бул ыкманы чакырганда, төмөнкүлөрдүн бардыгы чын экенине ынануу керек:
    ///
    /// * Көрсөтүүчү `ptr.len() * mem::size_of::<T>()` көп байт үчүн окуу үчүн [valid] болушу керек жана ал туура тегизделиши керек.Бул, айрыкча, билдирет:
    ///
    ///     * Бул тилкенин бүтүндөй эс тутуму бир гана бөлүнгөн объекттин ичинде камтылышы керек!
    ///       Кесилген тилкелер эч качан бир нече бөлүнгөн объектилерге жайылбайт.
    ///
    ///     * Көрсөткүч нөлдүк узундуктагы тилимдер үчүн дагы тегизделиши керек.
    ///     Мунун бир себеби, enum макетин оптимизациялоо шилтемелерге (анын ичинде каалаган узундуктагы кесиндилерге) туура келип, аларды башка маалыматтардан айырмалоо үчүн эч кандай мааниге ээ эмес.
    ///
    ///     [`NonNull::dangling()`] жардамы менен нөл узундугу кесилген тилкелер үчүн `data` катары колдонула турган көрсөткүчтү алууга болот.
    ///
    /// * Кесектин `ptr.len() * mem::size_of::<T>()` жалпы көлөмү `isize::MAX` тен чоң болбошу керек.
    ///   [`pointer::offset`] коопсуздук документтерин караңыз.
    ///
    /// * Сиз Rust лакап аты эрежелерин колдонушуңуз керек, анткени кайтарылган `'a` өмүрү өзүм билемдик менен тандалып алынган жана сөзсүз түрдө маалыматтын чыныгы жашоосун чагылдырбайт.
    ///   Атап айтканда, ушул өмүр бою, көрсөткүч көрсөткөн эс тутум мутацияланбашы керек (`UnsafeCell` ичинен тышкары).
    ///
    /// Бул ыкманын натыйжасы колдонулбаса дагы колдонулат!
    ///
    /// Ошондой эле [`slice::from_raw_parts`] караңыз.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // КООПСУЗДУК: чалган адам `as_uninit_slice` үчүн коопсуздук келишимин сакташы керек.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Мүмкүн демилгеленбеген маанилердин тилкесине уникалдуу шилтеме берет.[`as_mut`] тен айырмаланып, бул маанини инициалдаштырууну талап кылбайт.
    ///
    /// Жалпы кесиптеши үчүн [`as_uninit_slice`] караңыз.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Бул ыкманы чакырганда, төмөнкүлөрдүн бардыгы чын экенине ынануу керек:
    ///
    /// * Көрсөтүүчү `ptr.len() * mem::size_of::<T>()` көптөгөн байттарды окуу жана жазуу үчүн [valid] болушу керек жана ал туура тегизделиши керек.Бул, айрыкча, билдирет:
    ///
    ///     * Бул тилкенин бүтүндөй эс тутуму бир гана бөлүнгөн объекттин ичинде камтылышы керек!
    ///       Кесилген тилкелер эч качан бир нече бөлүнгөн объектилерге жайылбайт.
    ///
    ///     * Көрсөткүч нөлдүк узундуктагы тилимдер үчүн дагы тегизделиши керек.
    ///     Мунун бир себеби, enum макетин оптимизациялоо шилтемелерге (анын ичинде каалаган узундуктагы кесиндилерге) туура келип, аларды башка маалыматтардан айырмалоо үчүн эч кандай мааниге ээ эмес.
    ///
    ///     [`NonNull::dangling()`] жардамы менен нөл узундугу кесилген тилкелер үчүн `data` катары колдонула турган көрсөткүчтү алууга болот.
    ///
    /// * Кесектин `ptr.len() * mem::size_of::<T>()` жалпы көлөмү `isize::MAX` тен чоң болбошу керек.
    ///   [`pointer::offset`] коопсуздук документтерин караңыз.
    ///
    /// * Сиз Rust лакап аты эрежелерин колдонушуңуз керек, анткени кайтарылган `'a` өмүрү өзүм билемдик менен тандалып алынган жана сөзсүз түрдө маалыматтын чыныгы жашоосун чагылдырбайт.
    ///   Атап айтканда, ушул өмүр бою, көрсөткүч көрсөткөн эс тутумга башка көрсөткүч аркылуу жетүүгө (окууга жана жазууга) жол берилбеши керек.
    ///
    /// Бул ыкманын натыйжасы колдонулбаса дагы колдонулат!
    ///
    /// Ошондой эле [`slice::from_raw_parts_mut`] караңыз.
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Бул коопсуз, анткени `memory` окууга жана `memory.len()` көптөгөн байттарга жазууга жарактуу.
    /// // Бул жерде `memory.as_mut()` номерине чалууга тыюу салынгандыгын эске алыңыз, анткени мазмун инициализацияланбай калышы мүмкүн.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // КООПСУЗДУК: чалган адам `as_uninit_slice_mut` үчүн коопсуздук келишимин сакташы керек.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Чийки көрсөткүчтү чек араны текшербестен, элементке же субслипке кайтарып берет.
    ///
    /// Бул ыкманы чектен тышкаркы индекс менен чакыруу же `self` аныкталбаган учурда,*[аныкталбаган жүрүм-турум]*, натыйжада көрсөткүч колдонулбаса дагы.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // КООПСУЗДУК: чалып жаткан адам `self` тин ажыратылышы жана `index` чегинде болушу керек.
        // Натыйжада, көрсөткүч NULL болушу мүмкүн эмес.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // КООПСУЗДУК: Уникалдуу көрсөткүч нөл болушу мүмкүн эмес, андыктан шарттар
        // new_unchecked() сыйлашат.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // КООПСУЗДУК: өзгөрүлмө шилтеме нөл болушу мүмкүн эмес.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // КООПСУЗДУК: Шилтеме жокко эсе, андыктан анын шарттары
        // new_unchecked() сыйлашат.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}