// ignore-tidy-filelength

//! Тилимдерди башкаруу жана манипуляция.
//!
//! Көбүрөөк маалымат алуу үчүн [`std::slice`] караңыз.
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Таза rust мемчр ишке ашыруу, rust-memchr алынган
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Бул функция жалпыга маалым, анткени бирдиктүү сыноочу хепсорттун башка жолу жок.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Тилектеги элементтердин санын кайтарып берет.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // КООПСУЗДУК: const үнү, анткени биз узун талаасын usize катары которобуз (ал болушу керек)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // КООПСУЗДУК: бул коопсуз, анткени `&[T]` жана `FatPtr<T>` бирдей жайгаштырылган.
            // `std` гана бул кепилдикти бере алат.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Бул туруктуу болгондо `crate::ptr::metadata(self)` менен алмаштырыңыз.
            // Ушул жазуудан кийин "Const-stable functions can only call other const-stable functions" катасы пайда болду.
            //

            // КООПСУЗДУК: `PtrRepr` бирлигинен мааниге жетүү * const Tден бери коопсуз
            // жана PtrComponents<T>бирдей эс макетине ээ.
            // Бул кепилдикти std гана бере алат.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Эгерде кесиндинин узундугу 0 болсо, `true` берет.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Кесектин биринчи элементин, же бош болсо `None` берет.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Бөлүктүн биринчи элементине өзгөрүлмө көрсөткүчтү кайтарат, же ал бош болсо `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Кесектин биринчи жана калган бардык элементтерин кайтарат, же ал бош болсо `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Кесектин биринчи жана калган бардык элементтерин кайтарат, же ал бош болсо `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Кесектин акыркы жана калган элементтеринин бардыгын, же бош болсо `None` берет.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Кесектин акыркы жана калган элементтеринин бардыгын, же бош болсо `None` берет.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Кесектин акыркы элементин, же бош болсо `None` берет.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Өзгөрүлө турган көрсөткүчтү тилимдеги акыркы нерсеге кайтарат.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Индекстин түрүнө жараша элементке же подписке шилтеме берет.
    ///
    /// - Эгер позиция берилген болсо, анда ошол позициядагы элементке шилтеме берет же чектен тышкары болсо `None`.
    ///
    /// - Эгерде диапазон берилген болсо, анда ошол диапазонго туура келген субсликаны, же чектен тышкары болсо `None` берет.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Индекстин түрүнө жараша элементке же субсликага карата өзгөрүлмө шилтемени кайтарат ([`get`] караңыз) же индекс чектен чыкса, `None`.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Чек араларды текшербестен, элементке же подписке шилтеме берет.
    ///
    /// Коопсуз альтернатива үчүн [`get`] караңыз.
    ///
    /// # Safety
    ///
    /// Бул ыкманы чектен чыккан индекс менен чакыруу *[аныкталбаган жүрүм-турум]*, натыйжада алынган шилтеме колдонулбаса дагы.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // КООПСУЗДУК: чалган адам `get_unchecked` коопсуздук талаптарынын көпчүлүгүн сакташы керек;
        // кесинди ажыратууга болот, анткени `self` бул коопсуз шилтеме.
        // Кайтарылган көрсөткүч коопсуз, анткени `SliceIndex` impls анын кепилдиги болушу керек.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Элементке же подписке карата өзгөрүлмө шилтемени, чек араларды текшербестен кайтарат.
    ///
    /// Коопсуз альтернатива үчүн [`get_mut`] караңыз.
    ///
    /// # Safety
    ///
    /// Бул ыкманы чектен чыккан индекс менен чакыруу *[аныкталбаган жүрүм-турум]*, натыйжада алынган шилтеме колдонулбаса дагы.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // КООПСУЗДУК: чалган адам `get_unchecked_mut` үчүн коопсуздук талаптарын сакташы керек;
        // кесинди ажыратууга болот, анткени `self` бул коопсуз шилтеме.
        // Кайтарылган көрсөткүч коопсуз, анткени `SliceIndex` impls анын кепилдиги болушу керек.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Чийки көрсөткүчтү кесимдин буферине кайтарат.
    ///
    /// Чакыруучу бул функция көрсөткүчтүн эскиришинен ашып кетишин камсыз кылышы керек, антпесе ал таштандыга багытталат.
    ///
    /// Чакыруучу, ошондой эле (non-transitively) көрсөткүчү көрсөткөн эс тутумга ушул көрсөткүчтү же андан алынган кандайдыр бир көрсөткүчтү колдонуп (`UnsafeCell` ичинен тышкары) эч качан жазылбашы керек.
    /// Эгер кесиндинин мазмунун өзгөртүү керек болсо, [`as_mut_ptr`] колдонуңуз.
    ///
    /// Ушул тилимде айтылган контейнерди өзгөртүү анын буферин кайрадан бөлүштүрүүгө алып келиши мүмкүн, андыктан ага болгон көрсөткүчтөр жараксыз болуп калат.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Тилектин буферине кооптуу өзгөрүлмө көрсөткүчтү кайтарат.
    ///
    /// Чакыруучу бул функция көрсөткүчтүн эскиришинен ашып кетишин камсыз кылышы керек, антпесе ал таштандыга багытталат.
    ///
    /// Ушул тилимде айтылган контейнерди өзгөртүү анын буферин кайрадан бөлүштүрүүгө алып келиши мүмкүн, андыктан ага болгон көрсөткүчтөр жараксыз болуп калат.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Кесилген эки чийки көрсөткүчтү кайтарып берет.
    ///
    /// Кайтарылган диапазон жарым-жартылай ачык, демек, аяктагы көрсөткүч тилменин акыркы элементин *бир өткөндүгүн* билдирет.
    /// Ошентип, бош кесинди эки бирдей көрсөткүч менен, ал эми эки көрсөткүчтүн айырмасы тилимдин көлөмүн билдирет.
    ///
    /// Ушул көрсөткүчтөрдү колдонуу боюнча эскертүүлөрдү [`as_ptr`] караңыз.Аяктоочу көрсөткүч кошумча этияттыкты талап кылат, анткени тилимдеги жарактуу элементти көрсөтпөйт.
    ///
    /// Бул функция чет өлкөлүк интерфейстер менен иштешүү үчүн пайдалуу, алар эки көрсөткүчтү колдонуп, эс тутумундагы бир катар элементтерге кайрылышат, анткени C++ .
    ///
    ///
    /// Ошондой эле, бир элементтин көрсөткүчү ушул бөлүктүн элементине таандык экендигин текшерүү пайдалуу болушу мүмкүн:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // КООПСУЗДУК: `add` бул жерде коопсуз, анткени:
        //
        //   - Эки көрсөткүч бир эле объекттин бөлүгү болуп саналат, анткени объектти түздөн-түз көрсөтүү дагы маанилүү.
        //
        //   - Тилектин көлөмү бул жерде белгиленгендей, эч качан isize::MAX байттан чоң болбойт:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Тилкелер дарек мейкиндигинин аягына өтпөгөндүктөн, анда эч нерсе оролгон эмес.
        //
        // pointer::add документтерин караңыз.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Кесилген эки кооптуу өзгөрүлмө көрсөткүчтү кайтарып берет.
    ///
    /// Кайтарылган диапазон жарым-жартылай ачык, демек, аяктагы көрсөткүч тилменин акыркы элементин *бир өткөндүгүн* билдирет.
    /// Ошентип, бош кесинди эки бирдей көрсөткүч менен, ал эми эки көрсөткүчтүн айырмасы тилимдин көлөмүн билдирет.
    ///
    /// Ушул көрсөткүчтөрдү колдонуу боюнча эскертүүлөрдү [`as_mut_ptr`] караңыз.
    /// Аяктоочу көрсөткүч кошумча этияттыкты талап кылат, анткени тилимдеги жарактуу элементти көрсөтпөйт.
    ///
    /// Бул функция чет өлкөлүк интерфейстер менен иштешүү үчүн пайдалуу, алар эки көрсөткүчтү колдонуп, эс тутумундагы бир катар элементтерге кайрылышат, анткени C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // КООПСУЗДУК: `add` бул жерде эмне үчүн коопсуз экендигин жогорудагы as_ptr_range() караңыз.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Тилектин эки элементин алмаштырат.
    ///
    /// # Arguments
    ///
    /// * а, Биринчи элементтин индекси
    /// * б, экинчи элементтин индекси
    ///
    /// # Panics
    ///
    /// Panics, эгер `a` же `b` чектен чыкса.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Бир vector ден эки өзгөрүлмө насыя ала албайсыз, анын ордуна чийки көрсөткүчтөрдү колдонуңуз.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // КООПСУЗДУК: `pa` жана `pb` коопсуз өзгөрүлмө шилтемелердин жардамы менен иштелип чыккан
        // тилимдеги элементтерге, ошондуктан жарактуу жана тегизделгенине кепилдик берилет.
        // `a` жана `b` артындагы элементтерге кирүү текшерилгенин жана чектен чыкканда panic болоорун эске алыңыз.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Кесимдеги элементтердин орундарын, ордунда, тескери бурат.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Өтө кичинекей түрлөрү үчүн, ар бир адам кадимки жолдо начар окуйт.
        // Чоңураак бөлүктү жүктөө жана реестрди артка кайтаруу менен, натыйжасыз тегизделбеген load/store эске алып, биз жакшы иштей алабыз.
        //

        // Идеалында LLVM муну биз үчүн жасамак, анткени ал биз менен караганда тегизделбеген окуу натыйжалуубу же жокпу (мисалы, ар кандай ARM версияларынын ортосунда өзгөрүүлөр болот) жана эң жакшы көлөмдүн көлөмү кандай болот.
        // Тилекке каршы, LLVM 4.0 (2017-05) боюнча ал циклди гана ачат, андыктан биз муну өзүбүз жасашыбыз керек.
        // (Гипотеза: тескерисинче, кыйынчылык жаратат, анткени капталдары ар башкача тегизделиши мүмкүн-узундугу так болуп калса-ортодо толугу менен шайкештирилген SIMDди колдонуу үчүн алдын-ала жана постлюддарды чыгарууга жол жок.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Usize режиминдеги u8s режимин кайтаруу үчүн llvm.bswap ички колдонмосун колдонуңуз
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // КООПСУЗДУК: Бул жерде бир нече нерсени текшерүүгө болот:
                //
                // - Жогорудагы cfg текшерүүсүнөн улам `chunk` 4 же 8 экендигин эске алыңыз.Демек, `chunk - 1` позитивдүү.
                // - `i` индекси менен индекстөө жакшы, анткени циклди текшерүү кепилдик берет
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - `ln - i - chunk = ln - (i + chunk)` индекси менен индекстөө жакшы:
                //   - `i + chunk > 0` кичинекей чындык.
                //   - Цикл текшерүүсү кепилдик берет:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, ошентип алып салуу кемибейт.
                // - `read_unaligned` жана `write_unaligned` чалуулары жакшы:
                //   - `pa` `i` индексин көрсөтөт, анда `i < ln / 2 - (chunk - 1)` (жогоруда караңыз) жана `pb` индекси `ln - i - chunk`, ошондуктан экөө тең `self` аягына чейин жок дегенде `chunk` көп байт.
                //
                //   - Бардык башталган эс тутум жарактуу `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // u32 форматында u16-ны артка кайтаруу үчүн 16-жолу айландырууну колдонуңуз
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // КООПСУЗДУК: Колдонулбаган u32 `i + 1 < ln` болсо `i` тен окууга болот
                // (жана албетте `i < ln`), анткени ар бир элемент 2 байт, биз 4 окуп жатабыз.
                //
                // `i + chunk - 1 < ln / 2` # ал эми абалы
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Узундугу 2ге бөлүнгөндүктөн, ал чегинде болушу керек.
                //
                // Бул ошондой эле `0 < i + chunk <= ln` шарты ар дайым урматталат жана `pb` көрсөткүчүн коопсуз колдонууга болот дегенди билдирет.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // КООПСУЗДУК: `i` кесиндинин жарымынан кем эмес
            // `i` жана `ln - i - 1` кирүү коопсуз (`i` 0 ден башталат жана `ln / 2 - 1` ашпайт).
            // Натыйжада, `pa` жана `pb` көрсөткүчтөрү жарактуу жана тегизделген, аларды окууга жана жазууга болот.
            //
            //
            unsafe {
                // Чектерди алдын алуу үчүн кооптуу своп.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Кесилген кайталанма бөлүктү кайтарып берет.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Ар бир маанини өзгөртүүгө мүмкүндүк берген кайталоочу бөлүктү кайтарып берет.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Узундугу `size` болгон бардык жанаша windows аралыгында кайталоочу кайтып келет.
    /// windows кабатталып жатат.
    /// Эгерде тилим `size` тен кыска болсо, анда кайталоочу эч кандай маанини бербейт.
    ///
    /// # Panics
    ///
    /// Panics, эгер `size` 0 болсо.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Эгерде кесинди `size` тен кыска болсо:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Кесимдин башынан баштап, бир эле учурда `chunk_size` элементтеринин аралыгындагы кайталанма бөлүктү кайтарып берет.
    ///
    /// Бөлүктөр кесинди жана бири-бирине дал келбейт.Эгерде `chunk_size` кесиндинин узундугун бөлбөсө, анда акыркы бөлүктүн узундугу `chunk_size` болбойт.
    ///
    /// Ар дайым `chunk_size` элементтеринин бөлүктөрүн кайтарып берген ушул итератордун вариантын [`chunks_exact`] караңыз, ал эми ошол эле кайталоочу үчүн [`rchunks`], бирок тилимдин аягынан баштап.
    ///
    ///
    /// # Panics
    ///
    /// Panics, эгер `chunk_size` 0 болсо.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Кесимдин башынан баштап, бир эле учурда `chunk_size` элементтеринин аралыгындагы кайталанма бөлүктү кайтарып берет.
    ///
    /// Бөлүктөр өзгөрүлмө кесинди жана бири-бирине дал келбейт.Эгерде `chunk_size` кесиндинин узундугун бөлбөсө, анда акыркы бөлүктүн узундугу `chunk_size` болбойт.
    ///
    /// Ар дайым `chunk_size` элементтеринин бөлүктөрүн кайтарып берген ушул итератордун вариантын [`chunks_exact_mut`] караңыз, ал эми ошол эле кайталоочу үчүн [`rchunks_mut`], бирок тилимдин аягынан баштап.
    ///
    ///
    /// # Panics
    ///
    /// Panics, эгер `chunk_size` 0 болсо.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Кесимдин башынан баштап, бир эле учурда `chunk_size` элементтеринин аралыгындагы кайталанма бөлүктү кайтарып берет.
    ///
    /// Бөлүктөр кесинди жана бири-бирине дал келбейт.
    /// Эгерде `chunk_size` тилимдин узундугун бөлбөсө, анда `chunk_size-1` чейин акыркы элементтер алынып салынат жана аларды кайталоочу функциядан `remainder` функциясынан алууга болот.
    ///
    ///
    /// Ар бир бөлүктүн `chunk_size` элементтерине ээ болгондуктан, компилятор көбүнчө алынган кодду [`chunks`] ке караганда жакшы оптималдаштыра алат.
    ///
    /// Бул итератордун вариантын [`chunks`] караңыз, ал калган бөлүгүн дагы кичинекей бөлүк кылып берет, ал эми [`rchunks_exact`] ошол эле итератор үчүн, бирок кесинин аягынан баштап.
    ///
    /// # Panics
    ///
    /// Panics, эгер `chunk_size` 0 болсо.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Кесимдин башынан баштап, бир эле учурда `chunk_size` элементтеринин аралыгындагы кайталанма бөлүктү кайтарып берет.
    ///
    /// Бөлүктөр өзгөрүлмө кесинди жана бири-бирине дал келбейт.
    /// Эгерде `chunk_size` тилимдин узундугун бөлбөсө, анда `chunk_size-1` чейин акыркы элементтер алынып салынат жана аларды кайталоочу функциядан `into_remainder` функциясынан алууга болот.
    ///
    ///
    /// Ар бир бөлүктүн `chunk_size` элементтерине ээ болгондуктан, компилятор көбүнчө алынган кодду [`chunks_mut`] ке караганда жакшыраак оптималдаштыра алат.
    ///
    /// Бул итератордун вариантын [`chunks_mut`] караңыз, ал калган бөлүгүн дагы кичинекей бөлүк кылып берет, ал эми [`rchunks_exact_mut`] ошол эле итератор үчүн, бирок кесинин аягынан баштап.
    ///
    /// # Panics
    ///
    /// Panics, эгер `chunk_size` 0 болсо.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Калдык жок деп, тилимди `N`-элемент массивинин тилимине бөлөт.
    ///
    ///
    /// # Safety
    ///
    /// Бул качан гана деп аталышы мүмкүн
    /// - Кесүү толугу менен "N`-элементтин бөлүктөрүнө (ака `self.len() % N == 0`)) бөлүнөт.
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // КООПСУЗДУК: 1 элементтен турган бөлүктөр эч качан калбайт
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // КООПСУЗДУК: (6) кесиндисинин узундугу 3кө барабар
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Булар негизсиз болмок:
    /// // бөлүкчөлөр: &[[_;5]]= slice.as_chunks_unchecked()//Тилектин узундугу 5 бөлүкчөнүн эселиги эмес:&[[_;0]]= slice.as_chunks_unchecked()//Нөлгө чейинки бөлүктөргө эч качан уруксат берилбейт
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // КООПСУЗДУК: Биздин алдын-ала шарт-ушуну атоого эмне керек
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // КООПСУЗДУК: Биз ичине `new_len * N` элементтердин кесиндисин ыргыттык
        // `new_len` көп `N` элементтеринин кесиндилери.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Тилмени башынан баштап `N` элементтүү массивдин кесиндисине бөлүп, узундугу `N` ашпаган калган калдыкка бөлөт.
    ///
    ///
    /// # Panics
    ///
    /// Panics, эгер `N` 0 болсо, анда бул ыкма турукташканга чейин компиляцияланган убакыт катасы болуп өзгөрүлөт.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // КООПСУЗДУК: Биз буга чейин нөлгө паника кылып, курулуш менен камсыз кылганбыз
        // субсидиянын узундугу Nдин эсе экендиги.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Тилмени аягынан баштап `N` элементтүү массивдин кесиндисине жана узундугу `N` тен такыр калбаган бөлүккө бөлөт.
    ///
    ///
    /// # Panics
    ///
    /// Panics, эгер `N` 0 болсо, анда бул ыкма турукташканга чейин компиляцияланган убакыт катасы болуп өзгөрүлөт.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // КООПСУЗДУК: Биз буга чейин нөлгө паника кылып, курулуш менен камсыз кылганбыз
        // субсидиянын узундугу Nдин эсе экендиги.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Кесимдин башынан баштап, бир эле учурда `N` элементтеринин аралыгындагы кайталанма бөлүктү кайтарып берет.
    ///
    /// Бөлүктөр массив шилтемелери жана бири-бирине дал келбейт.
    /// Эгерде `N` тилимдин узундугун бөлбөсө, анда `N-1` чейин акыркы элементтер алынып салынат жана аларды кайталоочу функциядан `remainder` функциясынан алууга болот.
    ///
    ///
    /// Бул метод [`chunks_exact`] тин жалпы жалпы эквиваленти болуп саналат.
    ///
    /// # Panics
    ///
    /// Panics, эгер `N` 0 болсо, анда бул ыкма турукташканга чейин компиляцияланган убакыт катасы болуп өзгөрүлөт.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Калдык жок деп, тилимди `N`-элемент массивинин тилимине бөлөт.
    ///
    ///
    /// # Safety
    ///
    /// Бул качан гана деп аталышы мүмкүн
    /// - Кесүү толугу менен "N`-элементтин бөлүктөрүнө (ака `self.len() % N == 0`)) бөлүнөт.
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // КООПСУЗДУК: 1 элементтен турган бөлүктөр эч качан калбайт
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // КООПСУЗДУК: (6) кесиндисинин узундугу 3кө барабар
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Булар негизсиз болмок:
    /// // бөлүкчөлөр: &[[_;5]]= slice.as_chunks_unchecked_mut()//Тилектин узундугу 5 бөлүкчөнүн эселиги эмес:&[[_;0]]= slice.as_chunks_unchecked_mut()//Нөлгө чейинки бөлүктөргө эч качан уруксат берилбейт
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // КООПСУЗДУК: Биздин алдын-ала шарт-ушуну атоого эмне керек
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // КООПСУЗДУК: Биз ичине `new_len * N` элементтердин кесиндисин ыргыттык
        // `new_len` көп `N` элементтеринин кесиндилери.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Тилмени башынан баштап `N` элементтүү массивдин кесиндисине бөлүп, узундугу `N` ашпаган калган калдыкка бөлөт.
    ///
    ///
    /// # Panics
    ///
    /// Panics, эгер `N` 0 болсо, анда бул ыкма турукташканга чейин компиляцияланган убакыт катасы болуп өзгөрүлөт.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // КООПСУЗДУК: Биз буга чейин нөлгө паника кылып, курулуш менен камсыз кылганбыз
        // субсидиянын узундугу Nдин эсе экендиги.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Тилмени аягынан баштап `N` элементтүү массивдин кесиндисине жана узундугу `N` тен такыр калбаган бөлүккө бөлөт.
    ///
    ///
    /// # Panics
    ///
    /// Panics, эгер `N` 0 болсо, анда бул ыкма турукташканга чейин компиляцияланган убакыт катасы болуп өзгөрүлөт.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // КООПСУЗДУК: Биз буга чейин нөлгө паника кылып, курулуш менен камсыз кылганбыз
        // субсидиянын узундугу Nдин эсе экендиги.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Кесимдин башынан баштап, бир эле учурда `N` элементтеринин аралыгындагы кайталанма бөлүктү кайтарып берет.
    ///
    /// Бөлүктөр өзгөрүлмө массив шилтемелери жана бири-бирине дал келбейт.
    /// Эгерде `N` тилимдин узундугун бөлбөсө, анда `N-1` чейин акыркы элементтер алынып салынат жана аларды кайталоочу функциядан `into_remainder` функциясынан алууга болот.
    ///
    ///
    /// Бул метод [`chunks_exact_mut`] тин жалпы жалпы эквиваленти болуп саналат.
    ///
    /// # Panics
    ///
    /// Panics, эгер `N` 0 болсо, анда бул ыкма турукташканга чейин компиляцияланган убакыт катасы болуп өзгөрүлөт.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Кесимдин башынан баштап, X001 X 01X элементтеринин бири-бирине кайчылаштырылган кайталанма бөлүктү кайтарып берет.
    ///
    ///
    /// Бул [`windows`] тин жалпы эквиваленти.
    ///
    /// Эгерде `N` тилимдин өлчөмүнөн чоңураак болсо, анда ал windows дегенди бербейт.
    ///
    /// # Panics
    ///
    /// Panics, эгер `N` 0 болсо.
    /// Бул ыкма турукташканга чейин, балким, компиляция убагында ката болуп өзгөрүлөт.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Бөлүктүн аягынан баштап, бир эле учурда `chunk_size` элементтеринин үстүнөн кайталоочу кайтып келет.
    ///
    /// Бөлүктөр кесинди жана бири-бирине дал келбейт.Эгерде `chunk_size` кесиндинин узундугун бөлбөсө, анда акыркы бөлүктүн узундугу `chunk_size` болбойт.
    ///
    /// Ар дайым `chunk_size` элементтеринин бөлүктөрүн кайтарып берген ушул итератордун вариантын [`rchunks_exact`] караңыз, ал эми ошол эле кайталоочу үчүн [`chunks`], бирок тилимдин башынан баштап.
    ///
    ///
    /// # Panics
    ///
    /// Panics, эгер `chunk_size` 0 болсо.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Бөлүктүн аягынан баштап, бир эле учурда `chunk_size` элементтеринин үстүнөн кайталоочу кайтып келет.
    ///
    /// Бөлүктөр өзгөрүлмө кесинди жана бири-бирине дал келбейт.Эгерде `chunk_size` кесиндинин узундугун бөлбөсө, анда акыркы бөлүктүн узундугу `chunk_size` болбойт.
    ///
    /// Ар дайым `chunk_size` элементтеринин бөлүктөрүн кайтарып берген ушул итератордун вариантын [`rchunks_exact_mut`] караңыз, ал эми ошол эле кайталоочу үчүн [`chunks_mut`], бирок тилимдин башынан баштап.
    ///
    ///
    /// # Panics
    ///
    /// Panics, эгер `chunk_size` 0 болсо.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Бөлүктүн аягынан баштап, бир эле учурда `chunk_size` элементтеринин үстүнөн кайталоочу кайтып келет.
    ///
    /// Бөлүктөр кесинди жана бири-бирине дал келбейт.
    /// Эгерде `chunk_size` тилимдин узундугун бөлбөсө, анда `chunk_size-1` чейин акыркы элементтер алынып салынат жана аларды кайталоочу функциядан `remainder` функциясынан алууга болот.
    ///
    /// Ар бир бөлүктүн `chunk_size` элементтерине ээ болгондуктан, компилятор көбүнчө алынган кодду [`chunks`] ке караганда жакшы оптималдаштыра алат.
    ///
    /// Бул итератордун вариантын [`rchunks`] караңыз, ал калдыкты дагы кичинекей бөлүк кылып берет, ал эми [`chunks_exact`] ошол эле итератор үчүн, бирок тилимдин башынан башталат.
    ///
    ///
    /// # Panics
    ///
    /// Panics, эгер `chunk_size` 0 болсо.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Бөлүктүн аягынан баштап, бир эле учурда `chunk_size` элементтеринин үстүнөн кайталоочу кайтып келет.
    ///
    /// Бөлүктөр өзгөрүлмө кесинди жана бири-бирине дал келбейт.
    /// Эгерде `chunk_size` тилимдин узундугун бөлбөсө, анда `chunk_size-1` чейин акыркы элементтер алынып салынат жана аларды кайталоочу функциядан `into_remainder` функциясынан алууга болот.
    ///
    /// Ар бир бөлүктүн `chunk_size` элементтерине ээ болгондуктан, компилятор көбүнчө алынган кодду [`chunks_mut`] ке караганда жакшыраак оптималдаштыра алат.
    ///
    /// Бул итератордун вариантын [`rchunks_mut`] караңыз, ал калдыкты дагы кичинекей бөлүк кылып берет, ал эми [`chunks_exact_mut`] ошол эле итератор үчүн, бирок тилимдин башынан башталат.
    ///
    ///
    /// # Panics
    ///
    /// Panics, эгер `chunk_size` 0 болсо.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Тилектин үстүнөн кайталоочу элементти кайтарып берет, аларды бөлүү үчүн предикаттын жардамы менен элементтердин бири-бирине дал келбеген түрлөрүн чыгарат.
    ///
    /// Предикат эки элементтин артынан ээрчишет, демек, предикат `slice[0]` жана `slice[1]`, андан кийин `slice[1]` жана `slice[2]` ж.б.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Бул ыкманы сорттолгон чакан бөлүктөрдү бөлүп алуу үчүн колдонсо болот:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Тилектин үстүндөгү кайталанма элементти кайталап, элементтердин бири-бирин кайталабаган өзгөрүлмө өзгөрүүлөрүн жаратат, аларды бөлүү үчүн предикат колдонулат.
    ///
    /// Предикат эки элементтин артынан ээрчишет, демек, предикат `slice[0]` жана `slice[1]`, андан кийин `slice[1]` жана `slice[2]` ж.б.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Бул ыкманы сорттолгон чакан бөлүктөрдү бөлүп алуу үчүн колдонсо болот:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Индекс боюнча бир кесим экиге бөлөт.
    ///
    /// Биринчисинде `[0, mid)` индекстери камтылат (`mid` индексин кошпогондо), экинчисинде `[mid, len)` (`len` индексинин өзүн кошпогондо) бардык индекстер камтылат.
    ///
    ///
    /// # Panics
    ///
    /// Panics, эгер `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // КООПСУЗДУК: `[ptr; mid]` жана `[mid; len]` `self` ичинде, бул
        // `from_raw_parts_mut` талаптарын аткарат.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Бир өзгөрүлмө кесимди индексте экиге бөлөт.
    ///
    /// Биринчисинде `[0, mid)` индекстери камтылат (`mid` индексин кошпогондо), экинчисинде `[mid, len)` (`len` индексинин өзүн кошпогондо) бардык индекстер камтылат.
    ///
    ///
    /// # Panics
    ///
    /// Panics, эгер `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // КООПСУЗДУК: `[ptr; mid]` жана `[mid; len]` `self` ичинде, бул
        // `from_raw_parts_mut` талаптарын аткарат.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Чектерди текшербей, бир кесимди индекс боюнча экиге бөлөт.
    ///
    /// Биринчисинде `[0, mid)` индекстери камтылат (`mid` индексин кошпогондо), экинчисинде `[mid, len)` (`len` индексинин өзүн кошпогондо) бардык индекстер камтылат.
    ///
    ///
    /// Коопсуз альтернатива үчүн [`split_at`] караңыз.
    ///
    /// # Safety
    ///
    /// Бул ыкманы чектен чыккан индекс менен чакыруу *[аныкталбаган жүрүм-турум]*, натыйжада алынган шилтеме колдонулбаса дагы.Чалган адам `0 <= mid <= self.len()` экендигин камсыздашы керек.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // КООПСУЗДУК: Чакыруучу `0 <= mid <= self.len()` экендигин текшериши керек
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Чектерди текшербестен, өзгөрүлмө бир кесимди индекс боюнча экиге бөлөт.
    ///
    /// Биринчисинде `[0, mid)` индекстери камтылат (`mid` индексин кошпогондо), экинчисинде `[mid, len)` (`len` индексинин өзүн кошпогондо) бардык индекстер камтылат.
    ///
    ///
    /// Коопсуз альтернатива үчүн [`split_at_mut`] караңыз.
    ///
    /// # Safety
    ///
    /// Бул ыкманы чектен чыккан индекс менен чакыруу *[аныкталбаган жүрүм-турум]*, натыйжада алынган шилтеме колдонулбаса дагы.Чалган адам `0 <= mid <= self.len()` экендигин камсыздашы керек.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // КООПСУЗДУК: Чакыруучу `0 <= mid <= self.len()` экендигин текшериши керек.
        //
        // `[ptr; mid]` жана `[mid; len]` кабатталбайт, андыктан өзгөрүлмө маалымдаманы кайтарып берүү жакшы.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// `pred` менен дал келген элементтери менен бөлүнгөн субликалардын үстүнөн кайталоону кайтарат.
    /// Дал келген элемент кичи тилкелерде камтылбайт.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Эгерде биринчи элемент дал келсе, бош тилим кайталоочу тарабынан кайтарылган биринчи нерсе болот.
    /// Ошо сыяктуу эле, тилимдеги акыркы элемент дал келсе, бош тилим кайталоочу тарабынан кайтарылган акыркы нерсе болот:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Эгер дал келген эки элемент түздөн-түз жанаша турган болсо, анда алардын ортосунда бош кесинди болот:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// `pred` менен дал келген элементтер менен бөлүнгөн, өзгөрүлө турган кичи тилкелердин артынан кайталоону кайтарат.
    /// Дал келген элемент кичи тилкелерде камтылбайт.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// `pred` менен дал келген элементтери менен бөлүнгөн субликалардын үстүнөн кайталоону кайтарат.
    /// Дал келген элемент мурунку субсидиянын аягында терминатор катары камтылган.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Эгер тилимдин акыркы элементине дал келсе, ал элемент мурунку тилимдин аяктагычы катары каралат.
    ///
    /// Ошол тилим кайталоочу тарабынан кайтарылган акыркы нерсе болот.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// `pred` менен дал келген элементтер менен бөлүнгөн, өзгөрүлө турган кичи тилкелердин артынан кайталоону кайтарат.
    /// Дал келген элемент мурунку субсидияда терминатор катары камтылган.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Кесимдин аягынан баштап, артка карай иштеп, `pred` дал келген элементтери менен бөлүнгөн субсекциялардын үстүнө кайталоону кайтарды.
    /// Дал келген элемент кичи тилкелерде камтылбайт.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `split()` сыяктуу эле, эгерде биринчи же акыркы элемент дал келсе, анда бош тилим кайталоочу тарабынан кайтарылган биринчи (же акыркы) пункт болуп калат.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// `pred` дал келген элементтер менен бөлүнгөн, өзгөрүлө турган субсекциялардын арасына кайталоону, тилимдин аягынан баштап, артка иштетүүнү кайтарат.
    /// Дал келген элемент кичи тилкелерде камтылбайт.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Көпчүлүк `n` элементтерин кайтарып берүү менен гана чектелген, `pred` дал келген элементтер менен бөлүнгөн субликалардын үстүнөн кайталоону кайтарат.
    /// Дал келген элемент кичи тилкелерде камтылбайт.
    ///
    /// Кайтарылган акыркы элемент, эгерде бар болсо, кесиндинин калган бөлүгүн камтыйт.
    ///
    /// # Examples
    ///
    /// Бөлүмдү 3кө бөлүнүүчү сандарга бир жолу басып чыгарыңыз (б.а., `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Көпчүлүк `n` элементтерин кайтарып берүү менен гана чектелген, `pred` дал келген элементтер менен бөлүнгөн субликалардын үстүнөн кайталоону кайтарат.
    /// Дал келген элемент кичи тилкелерде камтылбайт.
    ///
    /// Кайтарылган акыркы элемент, эгерде бар болсо, кесиндинин калган бөлүгүн камтыйт.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Көпчүлүк `n` элементтерин кайтарып берүү менен чектелген `pred` дал келген элементтери менен бөлүнгөн субликалардын үстүнөн кайталанма кайтарды.
    /// Бул тилимдин аягында башталып, артка карай иштейт.
    /// Дал келген элемент кичи тилкелерде камтылбайт.
    ///
    /// Кайтарылган акыркы элемент, эгерде бар болсо, кесиндинин калган бөлүгүн камтыйт.
    ///
    /// # Examples
    ///
    /// Бөлүмдү 3кө бөлүнгөн сандарга бөлүп, аягынан баштап бир жолу басып чыгарыңыз (б.а., `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Көпчүлүк `n` элементтерин кайтарып берүү менен чектелген `pred` дал келген элементтери менен бөлүнгөн субликалардын үстүнөн кайталанма кайтарды.
    /// Бул тилимдин аягында башталып, артка карай иштейт.
    /// Дал келген элемент кичи тилкелерде камтылбайт.
    ///
    /// Кайтарылган акыркы элемент, эгерде бар болсо, кесиндинин калган бөлүгүн камтыйт.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Эгерде кесиндиде берилген маанидеги элемент болсо, `true` берет.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Эгер сизде `&T` жок болсо, бирок `&U` сыяктуу `T: Borrow<U>` болсо (мис., Мис
    /// `Сап: Карыз алуу<str>`), сиз `iter().any` колдоно аласыз:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // `String` кесиндиси
    /// assert!(v.iter().any(|e| e == "hello")); // `&str` менен издөө
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Эгерде `needle` кесиндинин префикси болсо, `true` берет.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Эгерде `needle` бош кесинди болсо, ар дайым `true` кайтарып берет:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Эгерде `needle` кесиндинин суффикси болсо, `true` берет.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Эгерде `needle` бош кесинди болсо, ар дайым `true` кайтарып берет:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Префикси алынып салынган сублицаны кайтарат.
    ///
    /// Эгерде тилим `prefix` менен башталса, `Some` оролгон префикстен кийин сублицаны кайтарып берет.
    /// Эгерде `prefix` бош болсо, анда жөн гана баштапкы тилимди кайтарып бериңиз.
    ///
    /// Эгерде тилим `prefix` менен башталбаса, `None` кайтарат.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Бул функция, качан жана качан SlicePattern татаалдашса, аны кайра жазуу керек болот.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Жок кылынган суффикс менен сублицаны кайтарат.
    ///
    /// Эгерде тилим `suffix` менен бүтсө, `Some` оролуп, суффикстин алдында кайталанат.
    /// Эгерде `suffix` бош болсо, анда жөн гана баштапкы тилимди кайтарып бериңиз.
    ///
    /// Эгерде кесинди `suffix` менен бүтпөсө, `None` берет.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Бул функция, качан жана качан SlicePattern татаалдашса, аны кайра жазуу керек болот.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Бинардык файл ушул сорттолгон бөлүктү белгилүү бир элементти издейт.
    ///
    /// Эгер маани табылса, анда дал келген элементтин индексин камтыган [`Result::Ok`] кайтарылат.
    /// Эгерде бир нече матч болсо, анда матчтардын кайсынысы болбосун кайтарылышы мүмкүн.
    /// Эгерде маани табылбаса, [`Result::Err`] кайтарылып берилет, анда иреттелген тартипти сактоо менен дал келген элементти киргизүүгө болот.
    ///
    ///
    /// Ошондой эле [`binary_search_by`], [`binary_search_by_key`] жана [`partition_point`] караңыз.
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Төрт элементтин сериясын издейт.
    /// Биринчиси табылган, уникалдуу аныкталган позиция менен;экинчи жана үчүнчүсү табылган жок;төртүнчүсү `[1, 4]` каалаган позициясына дал келиши мүмкүн.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Эгерде сиз иреттелген vector элементин киргизгиңиз келсе, иреттөө тартибин сактаңыз:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Экилик бул иреттелген бөлүктү компаратор функциясы менен издейт.
    ///
    /// Компаратордун функциясы, анын кесиндисинин `Less`, `Equal` же `Greater` керектүү максаттуу экендигин көрсөтүүчү буйрук кодун кайтарып, негизги кесинди иреттөө тартибине шайкеш келген тартипти ишке ашырышы керек.
    ///
    ///
    /// Эгер маани табылса, анда дал келген элементтин индексин камтыган [`Result::Ok`] кайтарылат.Эгерде бир нече матч болсо, анда матчтардын кайсынысы болбосун кайтарылышы мүмкүн.
    /// Эгерде маани табылбаса, [`Result::Err`] кайтарылып берилет, анда иреттелген тартипти сактоо менен дал келген элементти киргизүүгө болот.
    ///
    /// Ошондой эле [`binary_search`], [`binary_search_by_key`] жана [`partition_point`] караңыз.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Төрт элементтин сериясын издейт.Биринчиси табылган, уникалдуу аныкталган позиция менен;экинчи жана үчүнчүсү табылган жок;төртүнчүсү `[1, 4]` каалаган позициясына дал келиши мүмкүн.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // КООПСУЗДУК: чалууну төмөнкү инварианттар коопсуз кылат:
            // - `mid >= 0`
            // - `mid < size`: `mid` `[left; right)` менен чектелген.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Бири-бирибизди эмес, if/else башкаруу агымын колдонушубуздун себеби, дал келген нерселерди салыштыруу иш-аракеттери, ал сезгичтикке дал келет.
            //
            // Бул u8 үчүн x86 asm: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Экилик бул сорттолгон кесимди ачып алуу функциясы менен издейт.
    ///
    /// Бөлүм ачкыч боюнча иргелет деп ойлойбуз, мисалы [`sort_by_key`] менен ошол эле баскычты алуу функциясын колдонуп.
    ///
    /// Эгер маани табылса, анда дал келген элементтин индексин камтыган [`Result::Ok`] кайтарылат.
    /// Эгерде бир нече матч болсо, анда матчтардын кайсынысы болбосун кайтарылышы мүмкүн.
    /// Эгерде маани табылбаса, [`Result::Err`] кайтарылып берилет, анда иреттелген тартипти сактоо менен дал келген элементти киргизүүгө болот.
    ///
    ///
    /// Ошондой эле [`binary_search`], [`binary_search_by`] жана [`partition_point`] караңыз.
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Төрт элементтин катарларын экинчи элементтери боюнча иреттелген жуптардын кесиндисинде издейт.
    /// Биринчиси табылган, уникалдуу аныкталган позиция менен;экинчи жана үчүнчүсү табылган жок;төртүнчүсү `[1, 4]` каалаган позициясына дал келиши мүмкүн.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // `slice::sort_by_key` crate `alloc` болгондуктан Lint rustdoc::broken_intra_doc_links уруксат берилет, жана `core` курууда азырынча жок.
    //
    // төмөнкү crate: #74481 шилтемелери.Примитивдер libstd (#73423) менен гана документтештирилгендиктен, иш жүзүндө бул эч качан үзгүлтүккө учурабайт.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Кесимди сорттойт, бирок бирдей элементтердин тизилишин сактабай калышы мүмкүн.
    ///
    /// Бул сорт туруксуз (б.а. бирдей элементтердин ордун өзгөртүшү мүмкүн), ордунда (б.а. бөлбөйт) жана *O*(*n*\*log(* n*)) эң начар учур).
    ///
    /// # Учурдагы ишке ашыруу
    ///
    /// Учурдагы алгоритм Орсон Питерстин [pattern-defeating quicksort][pdqsort] ке негизделген, ал рандомизацияланган киксорт ылдамдыгынын ылдамдыгын жана тезирээк эң оор учурду айкалыштырат, ал эми белгилүү бир схемалар менен кесилген тилкелер боюнча сызыктуу убакытты алат.
    /// Бул деградацияланган учурларды болтурбоо үчүн кээ бир рандомизацияны колдонот, бирок туруктуу seed менен детерминисттик жүрүм-турумду камсыз кылат.
    ///
    /// Адатта, туруктуу сорттоого караганда ылдамыраак болот, мисалы, кесинди бир нече бириктирилген иреттелген ырааттуулуктардан турат.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Кесүүнү компаратор функциясы менен сорттойт, бирок бирдей элементтердин ирээтин сактабай калышы мүмкүн.
    ///
    /// Бул сорт туруксуз (б.а. бирдей элементтердин ордун өзгөртүшү мүмкүн), ордунда (б.а. бөлбөйт) жана *O*(*n*\*log(* n*)) эң начар учур).
    ///
    /// Компаратор функциясы тилимдеги элементтердин жалпы ирээтин аныкташы керек.Эгерде буйрутма жалпы болбосо, анда элементтердин ирети такталбайт.Буйрутма жалпы буйрук болуп саналат, эгерде (бардык `a`, `b` жана `c` үчүн):
    ///
    /// * жалпы жана антисимметриялык: `a < b`, `a == b` же `a > b` тин бири туура, жана
    /// * өткөөл, `a < b` жана `b < c` `a < c` билдирет.Ошол эле `==` жана `>` үчүн да болушу керек.
    ///
    /// Мисалы, [`f64`] [`Ord`] ти ишке ашырбаса, анткени `NaN != NaN`, биз тилкеде `NaN` болбогонун билгенде, `partial_cmp` ти биздин сорттоо функциябыз катары колдонсок болот.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Учурдагы ишке ашыруу
    ///
    /// Учурдагы алгоритм Орсон Питерстин [pattern-defeating quicksort][pdqsort] ке негизделген, ал рандомизацияланган киксорт ылдамдыгынын ылдамдыгын жана тезирээк эң оор учурду айкалыштырат, ал эми белгилүү бир схемалар менен кесилген тилкелер боюнча сызыктуу убакытты алат.
    /// Бул деградацияланган учурларды болтурбоо үчүн кээ бир рандомизацияны колдонот, бирок туруктуу seed менен детерминисттик жүрүм-турумду камсыз кылат.
    ///
    /// Адатта, туруктуу сорттоого караганда ылдамыраак болот, мисалы, кесинди бир нече бириктирилген иреттелген ырааттуулуктардан турат.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // тескери сорттоо
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Баскычты бөлүп алуу функциясы менен кесинди сорттойт, бирок бирдей элементтердин ордун сактабай калышы мүмкүн.
    ///
    /// Бул сорт туруксуз (б.а. бирдей элементтердин ордун өзгөртүшү мүмкүн), ордунда (б.а. бөлүштүрбөйт) жана *O*(m\* * n *\* log(*n*)) эң начар, мында негизги функция *O*(*м*).
    ///
    /// # Учурдагы ишке ашыруу
    ///
    /// Учурдагы алгоритм Орсон Питерстин [pattern-defeating quicksort][pdqsort] ке негизделген, ал рандомизацияланган киксорт ылдамдыгынын ылдамдыгын жана тезирээк эң оор учурду айкалыштырат, ал эми белгилүү бир схемалар менен кесилген тилкелер боюнча сызыктуу убакытты алат.
    /// Бул деградацияланган учурларды болтурбоо үчүн кээ бир рандомизацияны колдонот, бирок туруктуу seed менен детерминисттик жүрүм-турумду камсыз кылат.
    ///
    /// Ачкыч чалуу стратегиясына байланыштуу, [`sort_unstable_by_key`](#method.sort_unstable_by_key) ачкыч функциясы кымбат болгон учурларда [`sort_by_cached_key`](#method.sort_by_cached_key) ке караганда жайыраак болушу мүмкүн.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Тилмени `index` теги элемент акыркы иреттелген абалда тургандай кылып иреттеңиз.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// `index` теги элемент акыркы иреттелген абалында тургандай кылып, тилмени компаратор функциясы менен кайрадан иреттеңиз.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// `index` теги элемент акыркы иреттелген абалда тургандай кылып, бөлүктү бөлүп алуу функциясы менен кайрадан иреттеңиз.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Тилмени `index` теги элемент акыркы иреттелген абалда тургандай кылып иреттеңиз.
    ///
    /// Бул кайра иреттөө кошумча касиетке ээ, `i < index` абалындагы кандайдыр бир маани `j > index` абалындагы кандайдыр бир мааниден кичине же ага барабар болот.
    /// Мындан тышкары, бул иреттөө туруксуз (б.а.
    /// каалаган бирдей элементтер `index` абалында аякташы мүмкүн, ордунда (б.а.
    /// бөлбөйт) жана *O*(*n*) эң начар учур.
    /// Бул функция башка китепканаларда "kth element" деп да белгилүү/.
    /// Ал төмөнкүдөй үч эселенген өлчөмдү берет: берилген индекстеги бирден кичине элементтердин бардыгы, берилген индекстеги маанилер жана берилген элементтерден чоң элементтер.
    ///
    ///
    /// # Учурдагы ишке ашыруу
    ///
    /// Учурдагы алгоритм [`sort_unstable`] үчүн колдонулган ошол эле киксорс алгоритминин ылгоочу бөлүгүнө негизделген.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` болгондо Panics, демек, бош тилкелерде ар дайым panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Ортоңку табуу
    /// v.select_nth_unstable(2);
    ///
    /// // Көрсөтүлгөн индекс боюнча иреттөө ыкмасынын негизинде кесинди төмөнкүлөрдүн бири болот деп гана кепилдик беребиз.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// `index` теги элемент акыркы иреттелген абалында тургандай кылып, тилмени компаратор функциясы менен кайрадан иреттеңиз.
    ///
    /// Бул кайра иреттөө кошумча касиетке ээ, `i < index` позициясындагы кандайдыр бир маани `j > index` абалындагы компаратор функциясын колдонуп, кандайдыр бир мааниден кичине же ага барабар болот.
    /// Андан тышкары, бул кайра иреттөө туруксуз (башкача айтканда, бирдей элементтердин саны `index` абалына келип калышы мүмкүн), ордунда (б.а. бөлбөйт) жана *O*(*n*) эң начар.
    /// Бул функция башка китепканаларда "kth element" деп да белгилүү.
    /// Берилген компаратор функциясын колдонуу менен, ал төмөнкү көрсөткүчтөрдүн үчүлүгүн берет: берилген индекстеги бирден кичине элементтердин бардыгы, берилген индекстеги маанилер жана берилген индекстегилерден чоң элементтер.
    ///
    ///
    /// # Учурдагы ишке ашыруу
    ///
    /// Учурдагы алгоритм [`sort_unstable`] үчүн колдонулган ошол эле киксорс алгоритминин ылгоочу бөлүгүнө негизделген.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` болгондо Panics, демек, бош тилкелерде ар дайым panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Кесилген тилке азайып бараткан иреттелгендей медиананы табыңыз.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Көрсөтүлгөн индекс боюнча иреттөө ыкмасынын негизинде кесинди төмөнкүлөрдүн бири болот деп гана кепилдик беребиз.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// `index` теги элемент акыркы иреттелген абалда тургандай кылып, бөлүктү бөлүп алуу функциясы менен кайрадан иреттеңиз.
    ///
    /// Бул кайра иреттөө кошумча касиетке ээ, `i < index` абалындагы кандайдыр бир маани `j > index` позициясындагы ачкычтарды алуу функциясын колдонуп, кандайдыр бир мааниден кичине же ага барабар болот.
    /// Андан тышкары, бул кайра иреттөө туруксуз (башкача айтканда, бирдей элементтердин саны `index` абалына келип калышы мүмкүн), ордунда (б.а. бөлбөйт) жана *O*(*n*) эң начар.
    /// Бул функция башка китепканаларда "kth element" деп да белгилүү.
    /// Берилген ачкычты алуу функциясын колдонуу менен, ал төмөнкүдөй үч эселенген өлчөмдү берет: берилген индекстеги бирден кичине элементтердин бардыгы, берилген индекстеги маани жана берилген индекстеги элементтерден чоң элементтер.
    ///
    ///
    /// # Учурдагы ишке ашыруу
    ///
    /// Учурдагы алгоритм [`sort_unstable`] үчүн колдонулган ошол эле киксорс алгоритминин ылгоочу бөлүгүнө негизделген.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` болгондо Panics, демек, бош тилкелерде ар дайым panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Медиананы массив абсолюттук мааниге ылайык иреттелгендей кылып кайтарыңыз.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Көрсөтүлгөн индекс боюнча иреттөө ыкмасынын негизинде кесинди төмөнкүлөрдүн бири болот деп гана кепилдик беребиз.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Бардык ырааттуу кайталанган элементтерди [`PartialEq`] trait ишке ашырылышына ылайык, тилимдин аягына жылдырат.
    ///
    ///
    /// Эки кесимди кайтарып берет.Биринчиси ырааттуу кайталанган элементтерди камтыбайт.
    /// Экинчисинде бардык дубликаттар белгиленген тартипте камтылган.
    ///
    /// Эгерде тилке иреттелген болсо, биринчи кайтарылып берилген тилкеде эч кандай көчүрмө жок.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Берилген барабардык мамилесин канааттандырган, үзүндүнүн биринчи элементтеринен башкасынын бардыгын кесиндинин аягына жылдырат.
    ///
    /// Эки кесимди кайтарып берет.Биринчиси ырааттуу кайталанган элементтерди камтыбайт.
    /// Экинчисинде бардык дубликаттар белгиленген тартипте камтылган.
    ///
    /// `same_bucket` функциясы тилимден эки элементке шилтеме берилет жана элементтердин бирдей салыштыргандыгын аныкташы керек.
    /// Элементтер алардын тилкесиндеги иретинен тескери тартипте өтөт, андыктан `same_bucket(a, b)` `true` кайтарса, кесиндин аягында `a` жылдырылат.
    ///
    ///
    /// Эгерде тилке иреттелген болсо, биринчи кайтарылып берилген тилкеде эч кандай көчүрмө жок.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // `self` жөнүндө өзгөрүлмө шилтеме болсо да,*каалаган* өзгөрүүлөрдү жасай албайбыз.`same_bucket` чалуулары panic болушу мүмкүн, андыктан тилимдин ар дайым жарактуу абалда болушун камсыз кылышыбыз керек.
        //
        // Муну биз свопту колдонуу жолу менен чечебиз;биз бардык элементтердин үстүнөн кайталап, аягында алмаштырабыз, ошондо биз сактап калгысы келген элементтер алдыңкы, ал эми четке кагууну каалагандар арткы болот.
        // Андан кийин кесимди бөлүп алсак болот.
        // Бул операция дагы эле `O(n)`.
        //
        // Мисал: Биз ушул абалда баштайбыз, анда `r` "кийинки" дегенди билдирет
        // "жана `w` кийинки_жазууну "билдирет.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // self[r] ти өз алдынча [w-1] менен салыштырганда, бул кайталанма эмес, ошондуктан биз self[r] жана self[w] (r==w сыяктуу натыйжалар жок) менен алмаштырабыз, андан кийин r жана w экөөнү көбөйтүп, бизге төмөнкүнү калтырабыз:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r] ти өзүн-өзү [w-1] менен салыштырганда, бул маани кайталанма, андыктан биз `r` көбөйтүп, калганынын бардыгын өзгөрүүсүз калтырабыз:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r] ти өзүн [w-1] менен салыштырганда, бул кайталанма эмес, андыктан self[r] жана self[w] алмаштырыңыз жана r жана w алга жылыңыз:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Кайра кайталабаңыз:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Көчүрмө, advance r. End кесинди.W-де бөлүү.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // КООПСУЗДУК: `while` шарты `next_read` жана `next_write` кепилдик берет
        // `len` ден аз, андыктан `self` ичинде.
        // `prev_ptr_write` бир элементти `ptr_write` чейин көрсөтөт, бирок `next_write` 1ден башталат, андыктан `prev_ptr_write` эч качан 0дон кем болбойт жана кесиндин ичинде болот.
        // Бул `ptr_read`, `prev_ptr_write` жана `ptr_write` айырмалоо жана `ptr.add(next_read)`, `ptr.add(next_write - 1)` жана `prev_ptr_write.offset(1)` колдонуу талаптарын аткарат.
        //
        //
        // `next_write` ошондой эле ар бир цикл үчүн эң көп дегенде бир жолу көбөйтүлөт, анткени аны алмаштыруу керек болгондо эч бир элемент өткөрүлүп берилбейт.
        //
        // `ptr_read` жана `prev_ptr_write` эч качан бир эле элементти көрсөтпөйт.Бул `&mut *ptr_read`, `&mut* prev_ptr_write` коопсуз болушу үчүн талап кылынат.
        // Түшүндүрмө жөн гана `next_read >= next_write` ар дайым чындык, ошондуктан `next_read > next_write - 1` дагы.
        //
        //
        //
        //
        //
        unsafe {
            // Чийки көрсөткүчтөрдү колдонуу менен чек араларды текшерүүдөн алыс болуңуз.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Кийинки элементтердин бардыгынан башкасынын бардыгын ошол эле ачкычка чечилген бөлүктүн аягына жылдырат.
    ///
    ///
    /// Эки кесимди кайтарып берет.Биринчиси ырааттуу кайталанган элементтерди камтыбайт.
    /// Экинчисинде бардык дубликаттар белгиленген тартипте камтылган.
    ///
    /// Эгерде тилке иреттелген болсо, биринчи кайтарылып берилген тилкеде эч кандай көчүрмө жок.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Бөлүктү биринчи `mid` элементтери аягына чейин, ал эми акыркы `self.len() - mid` элементтери алдыга жылып тургандай кылып, кесинди ордунда айландырат.
    /// `rotate_left` номерине чалгандан кийин, `mid` индексиндеги элемент тилимдеги биринчи элемент болуп калат.
    ///
    /// # Panics
    ///
    /// Эгер `mid` кесиндинин узундугунан чоңураак болсо, бул функция panic болот.`mid == self.len()` _not_ panic жасаарын жана тыюу салынбаган айлануу экендигин эске алыңыз.
    ///
    /// # Complexity
    ///
    /// Сызыктуу (`self.len()`) убакытта) алат.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Сублицени айландыруу:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // КООПСУЗДУК: `[p.add(mid) - mid, p.add(mid) + k)` диапазону анчалык деле мааниге ээ эмес
        // `ptr_rotate` талап кылгандай, окуу жана жазуу үчүн жарактуу.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Бөлүктү биринчи `self.len() - k` элементтери аягына чейин, ал эми акыркы `k` элементтери алдыга жылып тургандай кылып, кесинди ордунда айландырат.
    /// `rotate_right` номерине чалгандан кийин, `self.len() - k` индексиндеги элемент тилимдеги биринчи элемент болуп калат.
    ///
    /// # Panics
    ///
    /// Эгер `k` кесиндинин узундугунан чоңураак болсо, бул функция panic болот.`k == self.len()` _not_ panic жасаарын жана тыюу салынбаган айлануу экендигин эске алыңыз.
    ///
    /// # Complexity
    ///
    /// Сызыктуу (`self.len()`) убакытта) алат.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Сублицени айландыруу:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // КООПСУЗДУК: `[p.add(mid) - mid, p.add(mid) + k)` диапазону анчалык деле мааниге ээ эмес
        // `ptr_rotate` талап кылгандай, окуу жана жазуу үчүн жарактуу.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// `value` клондоштуруу менен `self` элементтерин толтурат.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Жабууну бир нече жолу чалып кайтып келген `self` элементтерин толтурат.
    ///
    /// Бул ыкма жаңы баалуулуктарды түзүү үчүн жабууну колдонот.Эгер сиз [`Clone`] берилген маанини кааласаңыз, [`fill`] колдонуңуз.
    /// Эгерде сиз [`Default`] trait маанисин өндүрүү үчүн колдонгуңуз келсе, [`Default::default`] аргумент катары бере аласыз.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// `src` ден `self` ге элементтерди көчүрөт.
    ///
    /// `src` узундугу `self` менен бирдей болушу керек.
    ///
    /// Эгерде `T` `Copy` ти ишке ашырса, анда [`copy_from_slice`] ти колдонуу кыйла натыйжалуу болушу мүмкүн.
    ///
    /// # Panics
    ///
    /// Бул функция panic болот, эгер эки тилимдин узундугу ар башка болсо.
    ///
    /// # Examples
    ///
    /// Бир кесимден экинчисин клондоо:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Кесилген тилкелер бирдей узундукта болушу керек болгондуктан, биз баштапкы кесимди төрт элементтен экиге бөлөбүз.
    /// // Муну жасабасак, ал panic болот.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust, белгилүү бир көлөмдөгү белгилүү бир маалыматка өзгөрүлбөс шилтемелерсиз бир гана өзгөрүлмө шилтеме болушу мүмкүн деп талап кылат.
    /// Ушундан улам, `clone_from_slice` ти бир кесимге колдонууга аракет кылуу, компиляция иштебей калат:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Бул боюнча иштөө үчүн, биз [`split_at_mut`] колдонуп, бир кесимден эки бөлүкчөлөрүн түзө алабыз:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// `src` дан `self` ке чейинки бардык элементтерди memcpy колдонуп көчүрөт.
    ///
    /// `src` узундугу `self` менен бирдей болушу керек.
    ///
    /// Эгерде `T` `Copy` ти ишке ашырбаса, [`clone_from_slice`] колдонуңуз.
    ///
    /// # Panics
    ///
    /// Бул функция panic болот, эгер эки тилимдин узундугу ар башка болсо.
    ///
    /// # Examples
    ///
    /// Эки элементти тилимден экинчисине көчүрүү:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Кесилген тилкелер бирдей узундукта болушу керек болгондуктан, биз баштапкы кесимди төрт элементтен экиге бөлөбүз.
    /// // Муну жасабасак, ал panic болот.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust, белгилүү бир көлөмдөгү белгилүү бир маалыматка өзгөрүлбөс шилтемелерсиз бир гана өзгөрүлмө шилтеме болушу мүмкүн деп талап кылат.
    /// Ушундан улам, `copy_from_slice` ти бир кесимге колдонууга аракет кылуу, компиляциянын иштебей калышына алып келет:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Бул боюнча иштөө үчүн, биз [`split_at_mut`] колдонуп, бир кесимден эки бөлүкчөлөрүн түзө алабыз:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // panic код жолу чалуу сайтына көгөрүп калбоо үчүн суук функцияга киргизилген.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // КООПСУЗДУК: `self` аныктамасы боюнча `self.len()` элементтери үчүн жарактуу жана `src` болгон
        // бирдей узундукта экени текшерилген.
        // Бөлүктөр бири-бирине дал келе албайт, анткени өзгөрүлмө шилтемелер эксклюзивдүү.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Memmove колдонуп, тилимдердин бир бөлүгүнөн экинчи бөлүгүнө элементтерди көчүрөт.
    ///
    /// `src` көчүрүлө турган `self` чегинде.
    /// `dest` көчүрүлө турган `self` алкагындагы баштапкы индекс, ал `src` менен бирдей узундукта болот.
    /// Эки диапазон бири-бирине дал келиши мүмкүн.
    /// Эки диапазондун учтары `self.len()` тен кичине же ага барабар болушу керек.
    ///
    /// # Panics
    ///
    /// Бул функция panic болот, эгерде диапазон тилимдин аягынан ашып кетсе же `src` аягы баштала электе.
    ///
    ///
    /// # Examples
    ///
    /// Төрт байтты бир кесимге көчүрүү:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // КООПСУЗДУК: `ptr::copy` үчүн шарттардын бардыгы жогоруда текшерилген,
        // ошондой эле `ptr::add` үчүн.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// `self` теги бардык элементтерди `other` теги элементтер менен алмаштырат.
    ///
    /// `other` узундугу `self` менен бирдей болушу керек.
    ///
    /// # Panics
    ///
    /// Бул функция panic болот, эгер эки тилимдин узундугу ар башка болсо.
    ///
    /// # Example
    ///
    /// Эки элементти тилимдер боюнча алмаштыруу:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust, белгилүү бир көлөмдөгү белгилүү бир маалыматка бир гана өзгөрүлмө шилтеме болушу мүмкүн деп талап кылат.
    ///
    /// Ушундан улам, `swap_with_slice` ти бир кесимге колдонууга аракет кылуу, компиляция иштебей калат:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Бул боюнча иштөө үчүн, биз [`split_at_mut`] колдонуп, бир кесимден эки өзгөрүлмө суб-тилимдерин түзө алабыз:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // КООПСУЗДУК: `self` аныктамасы боюнча `self.len()` элементтери үчүн жарактуу жана `src` болгон
        // бирдей узундукта экени текшерилген.
        // Бөлүктөр бири-бирине дал келе албайт, анткени өзгөрүлмө шилтемелер эксклюзивдүү.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// `align_to{,_mut}` үчүн орто жана кийинки кесиндинин узундугун эсептөө функциясы.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Биз `rest` жөнүндө эмне кылышыбыз керек, биз кандай ``U` "катарын эң төмөнкү" T`s"санына киргизе алабыз.
        //
        // Ар бир мындай "multiple" үчүн канча "T`" керек.
        //
        // Мисалы T=u8 U=u16 карайлы.Андан кийин биз 2 Цга 1 U салсак болот.Simple.
        // Эми, мисалы, size_of: : учурун карап көрөлү.<T>=16, size_of::<U>=24.</u>
        // `rest` кесиминдеги ар бир 3 Ts ордуна 2 Us орното алабыз.
        // Бир аз татаал.
        //
        // Муну эсептөөчү формула:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Кеңейтилген жана жөнөкөйлөтүлгөн:
        //
        // Us=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Бактыга жараша, мунун бардыгы туруктуу бааланат ... бул жерде иш маанилүү эмес!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // кайталанма Штейндин алгоритми Биз дагы эле бул `const fn` ди жасашыбыз керек (эгерде биз рекурсивдик алгоритмге кайтып барышыбыз керек), анткени мунун бардыгын жөндөө үчүн llvmге таянуу ... жакшы, бул мага ыңгайсыздык жаратат.
            //
            //

            // КООПСУЗДУК: `a` жана `b` нөлгө барабар эмес экендиги текшерилет.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // б-дан 2 факторунун бардыгын алып салыңыз
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // КООПСУЗДУК: `b` нөл эмес экендиги текшерилет.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Бул билим менен куралданып, биз канча U`га батаарыбызды таба алабыз!
        let us_len = self.len() / ts * us;
        // Жана эң көп тилкелер канча T` болот!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Бөлүктү башка типтеги тилмеге которуп, түрлөрүнүн тегизделишин камсыз кылыңыз.
    ///
    /// Бул ыкма бөлүктү үч айырмаланган тилимге бөлөт: префикс, жаңы типтеги орто тилке жана жалбырак тилкеси.
    /// Метод ортоңку тилимди белгилүү бир түргө жана киргизүү тилкесине эң чоң узундукка айландырышы мүмкүн, бирок сиздин алгоритмдин иштеши анын тууралыгына эмес, ошого гана байланыштуу болушу керек.
    ///
    /// Киргизилген маалыматтардын бардыгы префикс же суффикс тилкеси катары кайтарылып берилишине жол берилет.
    ///
    /// Бул ыкма `T` киргизүү элементтери же `U` чыгыш элементи нөл өлчөмүндө болгондо жана эч нерсени бөлбөй туруп, баштапкы тилимди кайтарып бергенде эч кандай максат жок.
    ///
    /// # Safety
    ///
    /// Бул ыкма негизинен кайтарылып берилген ортоңку тилимдеги элементтерге карата `transmute` болуп саналат, андыктан `transmute::<T, U>` ке байланыштуу бардык эскертүүлөр ушул жерде колдонулат.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Бул функциянын көпчүлүгү туруктуу бааланарын эске алыңыз,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // атайын ZSTлерди иштетүү, башкача айтканда-аларды таптакыр колдонбоңуз.
            return (self, &[], &[]);
        }

        // Алгач, биринчи жана экинчи тилимдердин ортосунда кайсы учурда экиге бөлүнөөрүбүздү билип алыңыз.
        // ptr.align_offset менен оңой.
        let ptr = self.as_ptr();
        // КООПСУЗДУК: Коопсуздук боюнча толук комментарий алуу үчүн `align_to_mut` ыкмасын караңыз.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // КООПСУЗДУК: эми `rest` сөзсүз түрдө тегизделген, андыктан төмөндөгү `from_raw_parts` жакшы,
            // анткени чалуучу биз `T` ти `U` ке коопсуз өткөрө алабыз деп кепилдик берет.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Бөлүктү башка типтеги тилмеге которуп, түрлөрүнүн тегизделишин камсыз кылыңыз.
    ///
    /// Бул ыкма бөлүктү үч айырмаланган тилимге бөлөт: префикс, жаңы типтеги орто тилке жана жалбырак тилкеси.
    /// Метод ортоңку тилимди белгилүү бир түргө жана киргизүү тилкесине эң чоң узундукка айландырышы мүмкүн, бирок сиздин алгоритмдин иштеши анын тууралыгына эмес, ошого гана байланыштуу болушу керек.
    ///
    /// Киргизилген маалыматтардын бардыгы префикс же суффикс тилкеси катары кайтарылып берилишине жол берилет.
    ///
    /// Бул ыкма `T` киргизүү элементтери же `U` чыгыш элементи нөл өлчөмүндө болгондо жана эч нерсени бөлбөй туруп, баштапкы тилимди кайтарып бергенде эч кандай максат жок.
    ///
    /// # Safety
    ///
    /// Бул ыкма негизинен кайтарылып берилген ортоңку тилимдеги элементтерге карата `transmute` болуп саналат, андыктан `transmute::<T, U>` ке байланыштуу бардык эскертүүлөр ушул жерде колдонулат.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Бул функциянын көпчүлүгү туруктуу бааланарын эске алыңыз,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // атайын ZSTлерди иштетүү, башкача айтканда-аларды таптакыр колдонбоңуз.
            return (self, &mut [], &mut []);
        }

        // Алгач, биринчи жана экинчи тилимдердин ортосунда кайсы учурда экиге бөлүнөөрүбүздү билип алыңыз.
        // ptr.align_offset менен оңой.
        let ptr = self.as_ptr();
        // КООПСУЗДУК: Бул жерде биз U үчүн тегизделген көрсөткүчтөрдү колдонобуз
        // калган ыкма.Бул U үчүн багытталган тегиздөө менен көрсөткүчтү&[T] өткөрүп берүү жолу менен жүргүзүлөт.
        // `crate::ptr::align_offset` туура тизилген жана жарактуу `ptr` көрсөткүчү менен аталат (ал `self` ке шилтеме аркылуу келип чыгат) жана экөөнүн кубаттуулугу бар (анткени U үчүн тегиздөөдөн келип чыгат), анын коопсуздук чектөөлөрүн канааттандырат.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Мындан кийин биз `rest` колдоно албайбыз, бул анын `mut_ptr` каймана атын жараксыз кылат!КООПСУЗДУК: `align_to` үчүн комментарийлерди караңыз.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Бул кесиндинин элементтеринин иреттелгенин текшерет.
    ///
    /// Башкача айтканда, ар бир `a` элементи жана анын кийинки `b` элементи үчүн `a <= b` болушу керек.Эгерде кесинди толугу менен нөлгө же бир элементке ээ болсо, `true` кайтарылып берилет.
    ///
    /// Эгерде `Self::Item` `PartialOrd` болсо, `Ord` эмес, жогорудагы аныктамада, эгерде ар кандай эки нерсени салыштыруу мүмкүн болбосо, анда `false` функциясы кайтарылып берилет.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Берилген компаратор функциясын колдонуп, ушул кесиндинин элементтеринин сорттолгонун текшерет.
    ///
    /// `PartialOrd::partial_cmp` колдонуунун ордуна, бул функция берилген эки `compare` функциясын колдонуп, эки элементтин иреттүүлүгүн аныктайт.
    /// Мындан тышкары, бул [`is_sorted`] барабар;Көбүрөөк маалымат алуу үчүн анын документтерин караңыз.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Берилген ачкычты алуу функциясын колдонуп, ушул тилимдин элементтери сорттолгонун текшерет.
    ///
    /// Тилменин элементтерин түздөн-түз салыштыруунун ордуна, бул функция `f` тарабынан аныкталган элементтердин ачкычтарын салыштырат.
    /// Мындан тышкары, бул [`is_sorted`] барабар;Көбүрөөк маалымат алуу үчүн анын документтерин караңыз.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Берилген предикатка ылайык бөлүү чекитинин индексин кайтарат (экинчи бөлүктүн биринчи элементинин индекси).
    ///
    /// Берилген предикат боюнча кесинди бөлүштүрүлөт деп болжолдонот.
    /// Демек, предикат туура келген бардык элементтер тилимдин башында, ал эми предикат жалган болуп кайткан бардык элементтер аягында болот.
    ///
    /// Мисалы, [7, 15, 3, 5, 4, 12, 6] деген предикат боюнча бөлүнөт x% 2!=0 (бардык так сандар башында, бардыгы тең аягында).
    ///
    /// Эгерде бул тилим бөлүштүрүлбөсө, анда кайтарылган натыйжа такталбаган жана маанисиз болот, анткени бул ыкма экилик издөөнүн бир түрүн жүргүзөт.
    ///
    /// Ошондой эле [`binary_search`], [`binary_search_by`] жана [`binary_search_by_key`] караңыз.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // КООПСУЗДУК: Качан `left < right`, `left <= mid < right`.
            // Ошондуктан `left` ар дайым жогорулайт жана `right` ар дайым төмөндөйт жана алардын экөө тең тандалат.Эки учурда тең `left <= right` канааттандырылат.Демек, эгер `left < right` кадамда, `left <= right` кийинки кадамда канааттандырылат.
            //
            // Демек, `left != right`, `0 <= left < right <= len` канааттандырылат жана эгерде бул `0 <= mid < len` дагы канааттандырылса.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Аларды бирдей узундукта кесишибиз керек
        // оптимизаторго чекти текшерүүнү жеңилдетүү үчүн.
        // Бирок ага ишенүүгө болбой тургандыктан, бизде Т: Көчүрүү боюнча атайын адистик бар.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Бош кесинди жаратат.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Өзгөрүлө турган бош кесимчени түзөт.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Учурда `strip_prefix` жана `strip_suffix` тарабынан колдонулган тилимдердеги оймо-чиймелер.
/// future чекитинде биз `core::str::Pattern` ти (жазуу учурунда `str` менен чектелет) тилимдерге жалпылайбыз деп үмүттөнөбүз, ошондо бул trait алмаштырылат же жоюлат.
///
pub trait SlicePattern {
    /// Дал келген элементтин түрү.
    type Item;

    /// Учурда `SlicePattern` керектөөчүлөрү бир кесимге муктаж.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}