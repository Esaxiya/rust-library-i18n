//! Кесимдерди иреттөө
//!
//! Бул модуль Орсон Питерстин үлгүсүн жеңген киксортуна негизделген сорттоо алгоритмин камтыйт: <https://github.com/orlp/pdqsort>
//!
//!
//! Туруксуз сорттоо libcore менен шайкеш келет, анткени ал биздин туруктуу сорттоо ишибизден айырмаланып, эс тутумду бөлбөйт.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Түшкөндө, `src` дан `dest` ке көчүрүлөт.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // КООПСУЗДУК: Бул жардамчы класс.
        //          Туура болушу үчүн, анын колдонулушун караңыз.
        //          Тактап айтканда, `src` жана `dst` `ptr::copy_nonoverlapping` талап кылгандай дал келбейт деп ишениш керек.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Биринчи же чоң элементти кезиктирмейинче, биринчи элементти оңго жылдырат.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // КООПСУЗДУК: Төмөндөгү кооптуу иш-аракеттер байланыштырылган текшерүүсүз индекстөөнү камтыйт (`get_unchecked` жана `get_unchecked_mut`)
    // жана (`ptr::copy_nonoverlapping`) эс тутумун көчүрүү.
    //
    // а.Индекстөө:
    //  1. Массивдин көлөмүн>=2 деп текшердик.
    //  2. Биз жасай турган бардык индекстөө ар дайым эң көп дегенде {0 <= index < len} ортосунда болот.
    //
    // б.Эстутумду көчүрүү
    //  1. Жарактуу экенине кепилденген шилтемелерге көрсөткүчтөрдү алып жатабыз.
    //  2. Алар бири-бирине дал келбейт, анткени биз кесиндилердин айырмачылык индекстерин көрсөткөнбүз.
    //     Тактап айтканда, `i` жана `i-1`.
    //  3. Эгер кесинди туура тегизделсе, элементтер туура тегизделет.
    //     Тилкенин туура тегизделишин текшерүү чалуучунун милдети.
    //
    // Толугураак маалымат алуу үчүн төмөндөгү комментарийлерди караңыз.
    unsafe {
        // Эгерде алгачкы эки элемент иштен чыккан болсо ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Биринчи элементти стек менен бөлүнгөн өзгөрмөгө окуп чыгыңыз.
            // Эгерде panics салыштыруу операциясын жүргүзсөңүз, анда `hole` түшүп калат жана автоматтык түрдө кайра тилимге жазат.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // "I`-" элементин сол жакка жылдырып, тешикти оңго жылдырыңыз.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` түшүп, ошону менен `v` деги калган тешикке `tmp` көчүрөт.
        }
    }
}

/// Акыркы элементти кичирээк же бирдей элементке жолукканга чейин солго жылдырат.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // КООПСУЗДУК: Төмөндөгү кооптуу иш-аракеттер байланыштырылган текшерүүсүз индекстөөнү камтыйт (`get_unchecked` жана `get_unchecked_mut`)
    // жана (`ptr::copy_nonoverlapping`) эс тутумун көчүрүү.
    //
    // а.Индекстөө:
    //  1. Массивдин көлөмүн>=2 деп текшердик.
    //  2. Биз жасай турган бардык индекстөө ар дайым эң көп дегенде `0 <= index < len-1` ортосунда болот.
    //
    // б.Эстутумду көчүрүү
    //  1. Жарактуу экенине кепилденген шилтемелерге көрсөткүчтөрдү алып жатабыз.
    //  2. Алар бири-бирине дал келбейт, анткени биз кесиндилердин айырмачылык индекстерин көрсөткөнбүз.
    //     Тактап айтканда, `i` жана `i+1`.
    //  3. Эгер кесинди туура тегизделсе, элементтер туура тегизделет.
    //     Тилкенин туура тегизделишин текшерүү чалуучунун милдети.
    //
    // Толугураак маалымат алуу үчүн төмөндөгү комментарийлерди караңыз.
    unsafe {
        // Эгерде акыркы эки элемент иштен чыккан болсо ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Акыркы элементти стек менен бөлүнгөн өзгөрмөгө окуп чыгыңыз.
            // Эгерде panics салыштыруу операциясын жүргүзсөңүз, анда `hole` түшүп калат жана автоматтык түрдө кайра тилимге жазат.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // "I`-" элементин оңго жылдырып, тешикти солго жылдырыңыз.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` түшүп, ошону менен `v` деги калган тешикке `tmp` көчүрөт.
        }
    }
}

/// Жарым-жартылай бир нече элементтерди жылдырып, бир кесимди жарым-жартылай сорттойт.
///
/// Кесим аягында иреттелген болсо, `true` берет.Бул функция *O*(*n*) эң начар.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Өткөрүлө турган катардан тышкары жуптардын максималдуу саны.
    const MAX_STEPS: usize = 5;
    // Эгерде кесинди андан кыска болсо, анда эч кандай элементтерди жылдырбаңыз.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // КООПСУЗДУК: Биз буга чейин `i < len` менен байланышкан текшерүүнү так жүргүзгөнбүз.
        // Биздин кийинки индекстөөбүз `0 <= index < len` диапазонунда гана
        unsafe {
            // Кийинки жуп тартипсиз элементтерди табыңыз.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Бүттүкпү?
        if i == len {
            return true;
        }

        // Элементтерди кыска массивдерге жылдырбаңыз, бул иштин чыгымдарын талап кылат.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Табылган жуп элементтерди алмаштырыңыз.Бул аларды туура тартипке салат.
        v.swap(i - 1, i);

        // Кичинекей элементти солго жылдырыңыз.
        shift_tail(&mut v[..i], is_less);
        // Чоңураак элементти оңго жылдырыңыз.
        shift_head(&mut v[i..], is_less);
    }

    // Чектелген сандагы кадамдарда тилмени сорттой алган жокмун.
    false
}

/// Кесүү иретин колдонуп, бир кесимди сорттойт, бул *O*(*n*^ 2) эң начар учур.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// He00ortту колдонуп `v` сорттойт, бул *O*(*n*\*log(* n*)) эң начар учурга) кепилдик берет.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Бул экилик үймө инварианттуу `parent >= child` ти сыйлайт.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node` балдары:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Андан чоңураак баланы тандаңыз.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Эгерде инвариант `node` деңгээлинде болсо, токтоңуз.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // `node` ти чоңураак бала менен алмаштырып, бир кадам ылдый жылдырып, электен өткөрүүнү улантыңыз.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Үймөктү сызыктуу убакытта куруңуз.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Үймөдөн максималдуу элементтерди поп.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `v` ти `pivot` тен кичинекей элементтерге бөлүп, андан кийин `pivot` тен чоң же ага барабар элементтерди бөлөт.
///
///
/// `pivot` тен кичине элементтердин санын кайтарат.
///
/// Тармактык иш-аракеттердин баасын минималдаштыруу максатында, бөлүү блок-блок менен жүргүзүлөт.
/// Бул идея [BlockQuicksort][pdf] кагазында келтирилген.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Типтүү блоктогу элементтердин саны.
    const BLOCK: usize = 128;

    // Бөлүү алгоритми аяктаганга чейин төмөнкү кадамдарды кайталайт:
    //
    // 1. Айланмага чоң же барабар элементтерди аныктоо үчүн, сол тараптан блок издеңиз.
    // 2. Бөлүгүнөн кичине элементтерди аныктоо үчүн оң тараптан блок изиңиз.
    // 3. Сол жана оң тараптын ортосунда аныкталган элементтерди алмашуу.
    //
    // Элементтер блогу үчүн төмөнкү өзгөрмөлөрдү сактайбыз:
    //
    // 1. `block` - Блоктогу элементтердин саны.
    // 2. `start` - `offsets` массивине көрсөткүчтү баштаңыз.
    // 3. `end` - `offsets` массивине көрсөткүчтү аяктоо.
    // 4. `офсеттер, блоктун ичиндеги иштен чыккан элементтердин индекси.

    // Сол жактагы учурдагы блок (`l` ден `l.add(block_l)`) ге чейин).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Оң жактагы учурдагы блок (`r.sub(block_r)` to `r`) тен).
    // КООПСУЗДУК: .add() үчүн документтештирүүдө `vec.as_ptr().add(vec.len())` ар дайым коопсуз деп айтылып жүрөт
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Биз VLA алганда, `min(v.len() узундуктагы бир массив түзүп көрүңүз, тескерисинче, 2 * БЛОК) "
    // узундугу `BLOCK` белгиленген эки чоң массивге караганда.VLA'лар кэш натыйжалуу болушу мүмкүн.

    // `l` (inclusive) жана `r` (exclusive) көрсөткүчтөрүнүн ортосундагы элементтердин санын кайтарып берет.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // `l` жана `r` жакындап калганда, блок-блок бөлүштүрүү менен алектенебиз.
        // Андан кийин калган элементтерди ортосунда бөлүштүрүү үчүн бир аз жамоо иштерин жасайбыз.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Калган элементтердин саны (бурулушка салыштырмалуу дагы деле болсо).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Блоктун өлчөмдөрүн сол жана оң блоктор бири-бирине дал келбестигин жөндөңүз, бирок калган боштукту толугу менен жабуу үчүн тегиздөө.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // `block_l` элементтерин сол жагынан издөө.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // КООПСУЗДУК: Төмөндөгү кооптуулук операциялары `offset` колдонууну камтыйт.
                //         Функция талап кылган шарттарга ылайык, биз аларды канааттандырабыз, анткени:
                //         1. `offsets_l` стек менен бөлүштүрүлөт, демек, өзүнчө бөлүнгөн объект катары каралат.
                //         2. `is_less` функциясы `bool` кайтарып берет.
                //            `bool` экранга чыгаруу эч качан `isize` ашып кетпейт.
                //         3. Биз `block_l` `<= BLOCK` болот деп кепилдик бердик.
                //            Мындан тышкары, `end_l` алгач стекде жарыяланган `offsets_` старттык көрсөткүчүнө коюлган.
                //            Ошентип, биз эң начар учурда да (`is_less` тин бардык чакыруулары жалган болуп чыгат), биз эң көп дегенде 1 байт болуп, аягына чыгабыз.
                //        Бул жерде дагы бир кооптуу иш-`elem` ти ажыратуу.
                //        Бирок, `elem` алгач ар дайым жарактуу болгон кесинди баштоочу көрсөткүч болгон.
                unsafe {
                    // Тармаксыз салыштыруу.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // `block_r` элементтерин оң жагынан издөө.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // КООПСУЗДУК: Төмөндөгү кооптуулук операциялары `offset` колдонууну камтыйт.
                //         Функция талап кылган шарттарга ылайык, биз аларды канааттандырабыз, анткени:
                //         1. `offsets_r` стек менен бөлүштүрүлөт, демек, өзүнчө бөлүнгөн объект катары каралат.
                //         2. `is_less` функциясы `bool` кайтарып берет.
                //            `bool` экранга чыгаруу эч качан `isize` ашып кетпейт.
                //         3. Биз `block_r` `<= BLOCK` болот деп кепилдик бердик.
                //            Мындан тышкары, `end_r` алгач стекде жарыяланган `offsets_` старттык көрсөткүчүнө коюлган.
                //            Ошентип, биз эң начар учурда дагы (`is_less` бардык чакырыктары чындыкка дал келет), биз эң көп дегенде 1 байт болуп аягына чыгабыз.
                //        Бул жерде дагы бир кооптуу иш-`elem` ти ажыратуу.
                //        Бирок, `elem` башында `1 *sizeof(T)` аяктагандан кийин, биз ага жетээрден мурун `1* sizeof(T)` менен азайттык.
                //        Мындан тышкары, `block_r` `BLOCK` тен аз деп ырасталган жана `elem` ошондуктан тилимдин башталышын көрсөтөт.
                unsafe {
                    // Тармаксыз салыштыруу.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Сол жана оң капталдарын алмаштырууга жараксыз элементтердин саны.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Ошол учурда бир жупту алмаштырбай, циклдик пермутация жүргүзүү натыйжалуу болот.
            // Бул алмаштырууга такыр туура келбейт, бирок азыраак эстутум операцияларын колдонуп ушундай натыйжа берет.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Сол блоктогу бардык иштен чыккан элементтер жылдырылды.Кийинки блокко өтүңүз.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Оң блоктогу бардык иштен чыккан элементтер жылдырылды.Мурунку блокко жылдыруу.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Азыр эң көп дегенде бир блокту (солго же оңго) жылдырылууга тийиш, алардын иштен чыккан элементтери бар.
    // Мындай калган элементтерди алардын блогунун чегинде аягына чейин жылдырууга болот.
    //

    if start_l < end_l {
        // Сол блок калган.
        // Анын калган иретке келтирилген элементтерин оң жакка жылдырыңыз.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Оң блок калган.
        // Анын калган иретке келтирилген элементтерин сол жакка жылдырыңыз.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Башка кыла турган эч нерсе жок, биз бүттүк.
        width(v.as_mut_ptr(), l)
    }
}

/// `v` ти `v[pivot]` тен кичинекей элементтерге бөлүп, андан кийин `v[pivot]` тен чоң же ага барабар элементтерди бөлөт.
///
///
/// Кортежди кайтарат:
///
/// 1. `v[pivot]` тен кичине элементтердин саны.
/// 2. Эгерде `v` мурунтан эле бөлүштүрүлгөн болсо.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Бөлүктү тилимдин башына коюңуз.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Натыйжалуулук үчүн топтомду бөлүштүрүлгөн өзгөрмөгө айлантып окуп чыгыңыз.
        // Эгерде panics салыштыруу операциясы жүргүзүлсө, анда бурама автоматтык түрдө кайра тилимге жазылат.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Туура эмес элементтердин биринчи жупун табыңыз.
        let mut l = 0;
        let mut r = v.len();

        // КООПСУЗДУК: Төмөндөгү кооптуулук массивди индекстөөнү камтыйт.
        // Биринчиси: Бул жерде биз `l < r` аркылуу чек араларды текшерип жатабыз.
        // Экинчиси үчүн: Бизде башында `l == 0` жана `r == v.len()` бар жана биз индекстөө иш-аракеттеринде `l < r` экендигин текшерип турдук.
        //                     Бул жерден биз `r` жок дегенде `r == l` болушу керек экендигин билебиз, ал биринчисинен баштап жарактуу деп көрсөтүлгөн.
        unsafe {
            // Айланмага чоң же барабар болгон биринчи элементти табыңыз.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Чоңураак болгон акыркы элементти табыңыз.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` алкактын чегинен чыгып, бурулушту (ал стек менен бөлүштүрүлгөн өзгөрмө) баштапкы тилкесине кайра жазат.
        // Бул кадам коопсуздукту камсыз кылууда өтө маанилүү!
        //
    };

    // Бөлүктү эки бөлүктүн ортосуна коюңуз.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// `v` ти `v[pivot]` ке тең элементтерге бөлүп, андан кийин `v[pivot]` тен чоң элементтер.
///
/// Айланмага барабар элементтердин санын кайтарат.
/// `v` бурулуштан кичинекей элементтерди камтыбайт деп болжолдонууда.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Бөлүктү тилимдин башына коюңуз.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Натыйжалуулук үчүн топтомду бөлүштүрүлгөн өзгөрмөгө айлантып окуп чыгыңыз.
    // Эгерде panics салыштыруу операциясы жүргүзүлсө, анда бурама автоматтык түрдө кайра тилимге жазылат.
    // КООПСУЗДУК: Бул жердеги көрсөткүч жарактуу, анткени ал бир кесимге шилтеме жасап алынган.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Эми тилимди бөлүп алыңыз.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // КООПСУЗДУК: Төмөндөгү кооптуулук массивди индекстөөнү камтыйт.
        // Биринчиси: Бул жерде биз `l < r` аркылуу чек араларды текшерип жатабыз.
        // Экинчиси үчүн: Бизде башында `l == 0` жана `r == v.len()` бар жана биз индекстөө иш-аракеттеринде `l < r` экендигин текшерип турдук.
        //                     Бул жерден биз `r` жок дегенде `r == l` болушу керек экендигин билебиз, ал биринчисинен баштап жарактуу деп көрсөтүлгөн.
        unsafe {
            // Чакырыктан чоңураак биринчи элементти табыңыз.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Бийликке барабар болгон акыркы элементти табыңыз.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Бүттүкпү?
            if l >= r {
                break;
            }

            // Табылган жупту тартиптен тышкары элементтер менен алмаштырыңыз.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Биз бурулушка барабар `l` элементтерин таптык.Пивоттун өзүн эсепке алуу үчүн 1 кошуңуз.
    l + 1

    // `_pivot_guard` алкактын чегинен чыгып, бурулушту (ал стек менен бөлүштүрүлгөн өзгөрмө) баштапкы тилкесине кайра жазат.
    // Бул кадам коопсуздукту камсыз кылууда өтө маанилүү!
}

/// Квиксорттогу тең салмактуулуксуз бөлүктөргө алып келиши мүмкүн болгон калыптарды бузуу максатында кээ бир элементтерди чачыратат.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Джордж Марсаглия тарабынан жазылган "Xorshift RNGs" кагаздан жасалма кокустук сандар генератору.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Бул сан модулу менен туш келди сандарды алыңыз.
        // Саны `usize` туура келет, анткени `len` `isize::MAX` тен чоң эмес.
        let modulus = len.next_power_of_two();

        // Айрым негизги талапкерлер ушул индекстин жанында болот.Келгиле, аларды рандомизация кылалы.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // `len` модулун кокустан жаратыңыз.
            // Бирок, кымбат операцияларды болтурбоо үчүн, биз алгач аны эки кубаттуулуктун модулу менен алабыз, андан кийин `[0, len - 1]` диапазонуна дал келгенге чейин `len` ге төмөндөйбүз.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` `2 * len` тен аз экендигине кепилдик берилет.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// `v` форматындагы бурулушту тандап, кесинди мурунтан эле иреттелген болсо, индексти жана `true` кайтарат.
///
/// `v` теги элементтер процессте иреттелген болушу мүмкүн.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Медианалардын медианасын тандоо үчүн минималдуу узундук.
    // Кыска тилмелер үчтөн медиана ыкмасын колдонушат.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Бул функцияны аткарууга мүмкүн болгон своптордун максималдуу саны.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Биз үч бурчтукту тандап алганы жатабыз.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Индекстерди иргеп жатканда биз аткара турган своптордун жалпы санын эсептейт.
    let mut swaps = 0;

    if len >= 8 {
        // `v[a] <= v[b]` деп индекстерди алмаштырат.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // `v[a] <= v[b] <= v[c]` деп индекстерди алмаштырат.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // `v[a - 1], v[a], v[a + 1]` медианасын табат жана `a` индексин сактайт.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // `a`, `b` жана `c` кварталдарынан медианаларды табыңыз.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // `a`, `b` жана `c` арасындагы медиананы табыңыз.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Своптардын максималдуу саны аткарылды.
        // Кесилген тилкенин төмөндөшү же көбүнчө төмөндөө мүмкүнчүлүгү бар, андыктан тескери бурулуп, аны тезирээк иргөөгө жардам берет.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v` рекурсивдүү түрлөрү.
///
/// Эгерде тилимде баштапкы массивде мурункусу болсо, анда ал `pred` деп көрсөтүлөт.
///
/// `limit` - `heapsort` ке өткөнгө чейин салмаксыз болгон бөлүктөрдүн саны.
/// Эгерде нөл болсо, анда бул функция дароо үймөңкүргө өтөт.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ушул узундукка чейинки кесиндилер сорттоо ирети менен иргелет.
    const MAX_INSERTION: usize = 20;

    // Эгер акыркы бөлүштүрүү акылга сыярлык салмактуу болсо.
    let mut was_balanced = true;
    // Эгер акыркы бөлүштүрүү элементтерди аралаштырбаса, анда туура (тилим мурунтан эле бөлүштүрүлгөн).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Кыска кесиндилер кыстырма сорту аркылуу иргелет.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Эгер өтө эле жаман бурулуш тандоолор жасалып калса, анда `O(n * log(n))` эң начар учурга кепилдик берүү үчүн, кайрадан хепсортка түшүңүз.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Эгерде акыркы бөлүштүрүү тең салмаксыз болгон болсо, анда кээ бир элементтерди аралаштырып, тилимдеги калыптарды бузуп көрүңүз.
        // Бул жолу жакшыраак бурулушту тандап алабыз деп үмүттөнөбүз.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Бийликти тандап, кесинди мурунтан эле иреттелгенби же жокпу, болжолдоп көрүңүз.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Эгерде акыркы бөлүштүрүү татаалдаштырылып, элементтер аралашпаса жана бурулуш тандоо алдын-ала айтылса, тилим мурунтан эле иреттелген болушу мүмкүн ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Бир нече иштен чыккан элементтерди аныктап, аларды туура позицияларга которуп көрүңүз.
            // Эгер кесинди толугу менен иргелип бүтсө, биз бүттүк.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Эгерде тандалган бурулуш мурункуга барабар болсо, анда бул тилимдеги эң кичинекей элемент.
        // Кесилген тилкени барабар элементтерге жана чоңураак элементтерге бөлүңүз.
        // Көбүнчө, бул кесиндиде көптөгөн кайталануучу элементтер камтылганда урунат.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Бөлүгүнөн чоңураак элементтерди иргей бериңиз.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Кесимди бөлүү.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Кесимди `left`, `pivot` жана `right` кылып бөлүңүз.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Рекурсивдик чалуулардын жалпы санын минималдаштыруу жана стек мейкиндигин азыраак пайдалануу үчүн гана кыска жолго өтүңүз.
        // Андан кийин узунураак жагын улантыңыз (бул куйрук рекурсиясына окшош).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// *O*(*n*\*log(* n*)) эң начар учур) болуп саналган `v` үлгүсүн жеңилдетүүчү киксортту колдонуп сорттойт.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Сорттоонун нөл өлчөмдөгү түрлөрү боюнча эч кандай мааниси жок.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Балансташтырылбаган бөлүктөрдүн санын `floor(log2(len)) + 1` менен чектеңиз.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Мындай узундуктагы кесиндилер үчүн аларды ылгап алуу тезирээк болот.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Бийликти тандаңыз
        let (pivot, _) = choose_pivot(v, is_less);

        // Эгерде тандалган бурулуш мурункуга барабар болсо, анда бул тилимдеги эң кичинекей элемент.
        // Кесилген тилкени барабар элементтерге жана чоңураак элементтерге бөлүңүз.
        // Көбүнчө, бул кесиндиде көптөгөн кайталануучу элементтер камтылганда урунат.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Эгерде биз индекстен өткөн болсок, анда биз жакшыбыз.
                if mid > index {
                    return;
                }

                // Болбосо, бурулуштан чоң элементтерди иреттөөнү улантыңыз.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Кесимди `left`, `pivot` жана `right` кылып бөлүңүз.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Эгерде mid==индекси болсо, анда биз бүттүк, анткени partition() ортодон кийинки бардык элементтер ортосунан чоң же ага барабар деп кепилдик берет.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Сорттоонун нөл өлчөмдөгү түрлөрү боюнча эч кандай мааниси жок.Эчнерсе кылба.
    } else if index == v.len() - 1 {
        // Max элементин таап, аны массивдин акыркы ордуна коюңуз.
        // Биз бул жерде `unwrap()` колдоно алабыз, анткени v бош болбошу керектигин билебиз.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Min элементин таап, аны массивдин биринчи ордуна коюңуз.
        // Биз бул жерде `unwrap()` колдоно алабыз, анткени v бош болбошу керектигин билебиз.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}