//! Тилектин кайталагычы колдонгон макроэлементтер.

// In_pl бош жана len көрсөткүчтөрү чоң өзгөрүүлөрдү жасайт
macro_rules! is_empty {
    // ZST итераторунун узундугун кандайча коддогонубуз, бул ZST үчүн да, ZST эмес үчүн дагы иштейт.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Айрым чектерден арылуу үчүн (`position` ти караңыз), узундукту күтүлбөгөн жерден эсептейбиз.
// ("Codegen/slice-position-bounds-check" менен текшерилген.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // биз кээде кооптуу блоктун ичинде колдонулат

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Бул _cannot_ `unchecked_sub` колдонот, анткени биз ZST тилкесинин узундуктуу узундугун көрсөтүү үчүн оромого көз карандыбыз.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Биз `start <= end` экенин билебиз, андыктан `offset_from` ке караганда жакшыраак жасай алабыз, ага кол коюлушу керек.
            // Бул жерге тиешелүү желектерди орнотуу менен биз LLVMге айта алабыз, бул чек араларды текшерүүнү жок кылууга жардам берет.
            // КООПСУЗДУК: Инвариант түрү боюнча, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Ошондой эле LLVMге көрсөткүчтөрдүн түрүнүн өлчөмүнүн так эселенгендиги менен айырмаланып турса, ал `len() == 0` ти `(end - start) < size` ордуна `start == end` чейин оптималдаштыра алат.
            //
            // КООПСУЗДУК: Түрү инварианттуу болуп, көрсөткүчтөр ушундай болуп тегизделет
            //         алардын ортосундагы аралык пуинттердин өлчөмүнүн эселенген болушу керек
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` жана `IterMut` итераторлорунун жалпы аныктамасы
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Биринчи элементти кайтарып, итератордун башталышын 1ге алдыга жылдырат.
        // Кесилген функцияга салыштырмалуу өнүмдүүлүктү бир кыйла жакшыртат.
        // Итератор бош болбошу керек.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Акыркы элементти кайтарып, итератордун аягын 1 ге артка жылдырат.
        // Кесилген функцияга салыштырмалуу өнүмдүүлүктү бир кыйла жакшыртат.
        // Итератор бош болбошу керек.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Т ZST болгондо, кайталоочу учту `n` артка жылдырып, итераторду кичирейтет.
        // `n` `self.len()` ашпашы керек.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Итератордун кесиндисин түзүү үчүн жардамчы функциясы.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // КООПСУЗДУК: итератор көрсөткүчү бар кесимден жасалган
                // `self.ptr` жана узундугу `len!(self)`.
                // Бул `from_raw_parts` үчүн бардык өбөлгөлөрдүн аткарылышына кепилдик берет.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Итератордун башын `offset` элементтери менен алдыга жылдырып, эски стартты кайтарып берүүчү жардамчы функциясы.
            //
            // Кооптуу, анткени офсет `self.len()` ашпашы керек.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // КООПСУЗДУК: чалган адам `offset` `self.len()` ашпагандыгына кепилдик берет,
                    // демек, бул жаңы көрсөткүч `self` ичинде болгондуктан, эч кандай мааниге ээ эмес.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Итератордун аягын `offset` элементтери менен артка жылдырып, жаңы аягын кайтарып берүүчү жардамчы функция.
            //
            // Кооптуу, анткени офсет `self.len()` ашпашы керек.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // КООПСУЗДУК: чалган адам `offset` `self.len()` ашпагандыгына кепилдик берет,
                    // бул `isize` ашып кетпейт деп кепилденген.
                    // Ошондой эле, пайда болгон көрсөткүч `slice` чегинде, ал `offset` үчүн башка талаптарды аткарат.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // тилимдери менен ишке ашырылышы мүмкүн, бирок бул чек араларды текшерүүдөн качат

                // КООПСУЗДУК: `assume` чалуулары тилимдин башталгыч көрсөткүчүнөн бери коопсуз
                // нөл эмес болушу керек, ал эми ZST эмес кесиндилердин кесиндилери дагы нөл мааниге ээ болбошу керек.
                // `next_unchecked!` номерине чалуу коопсуз, анткени алгач итератордун бош экендигин текшеребиз.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Бул итератор азыр бош.
                    if mem::size_of::<T>() == 0 {
                        // Биз муну ушундай кылышыбыз керек, анткени `ptr` эч качан 0 болбошу мүмкүн, бирок `end` болушу мүмкүн (оромого байланыштуу).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // КООПСУЗДУК: эгерде T ZST болбосо, анда 0 болушу мүмкүн эмес, анткени ptr 0 жана end>=ptr эмес
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // КООПСУЗДУК: Биз чек арабыздабыз.`post_inc_start` ZST үчүн дагы туура иш кылат.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // `try_fold` колдонгон демейки ишке ашырууну жокко чыгарабыз, анткени бул жөнөкөй ишке ашыруу LLVM IRди аз жаратат жана тезирээк түзүлөт.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // `try_fold` колдонгон демейки ишке ашырууну жокко чыгарабыз, анткени бул жөнөкөй ишке ашыруу LLVM IRди аз жаратат жана тезирээк түзүлөт.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // `try_fold` колдонгон демейки ишке ашырууну жокко чыгарабыз, анткени бул жөнөкөй ишке ашыруу LLVM IRди аз жаратат жана тезирээк түзүлөт.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // `try_fold` колдонгон демейки ишке ашырууну жокко чыгарабыз, анткени бул жөнөкөй ишке ашыруу LLVM IRди аз жаратат жана тезирээк түзүлөт.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // `try_fold` колдонгон демейки ишке ашырууну жокко чыгарабыз, анткени бул жөнөкөй ишке ашыруу LLVM IRди аз жаратат жана тезирээк түзүлөт.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // `try_fold` колдонгон демейки ишке ашырууну жокко чыгарабыз, анткени бул жөнөкөй ишке ашыруу LLVM IRди аз жаратат жана тезирээк түзүлөт.
            // Ошондой эле, `assume` чек араны текшерүүдөн качат.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // КООПСУЗДУК: циклдин инварианты менен чектелгенибизге кепилдик берилет:
                        // качан `i >= n`, `self.next()` `None` кайтарат жана цикл үзүлөт.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // `try_fold` колдонгон демейки ишке ашырууну жокко чыгарабыз, анткени бул жөнөкөй ишке ашыруу LLVM IRди аз жаратат жана тезирээк түзүлөт.
            // Ошондой эле, `assume` чек араны текшерүүдөн качат.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // КООПСУЗДУК: `i` `n` тен төмөн болушу керек, анткени ал `n` те башталат
                        // жана азайып баратат.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // КООПСУЗДУК: чалган адам `i` чегинде экенине кепилдик бериши керек
                // негизги кесинди, андыктан `i` `isize` ти толтура албайт, жана кайтарылган шилтемелердин кесиндинин бир элементине шилтеме берилиши кепилденет жана ошону менен жарактуу болот.
                //
                // Ошондой эле, чалып жаткан адам бизди бир эле индекс менен экинчи жолу чакырышпайт деп кепилдик бере тургандыгын жана бул подкладкага жете турган башка ыкмалар колдонулбай тургандыгына кепилдик бергендигин эске алыңыз, андыктан кайтарылган шилтеме өзгөрүлүп турса, анда
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // тилимдери менен ишке ашырылышы мүмкүн, бирок бул чек араларды текшерүүдөн качат

                // КООПСУЗДУК: `assume` чалуулары коопсуз, анткени тилимдин баштоочу көрсөткүчү нөл болбошу керек,
                // жана ZST эмес кесиндилердин кесинди да нөл эмес чекитке ээ болушу керек.
                // `next_back_unchecked!` номерине чалуу коопсуз, анткени алгач итератордун бош экендигин текшеребиз.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Бул итератор азыр бош.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // КООПСУЗДУК: Биз чек арабыздабыз.`pre_dec_end` ZST үчүн дагы туура иш кылат.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}