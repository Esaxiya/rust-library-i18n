// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// `[mid-left, mid+right)` диапазонун айлантып, `mid` деги элемент биринчи элементке айланат.Эквиваленттүү, `left` элементтерин солго же `right` элементтерин оңго бурат.
///
/// # Safety
///
/// Көрсөтүлгөн диапазон окуу жана жазуу үчүн жарактуу болушу керек.
///
/// # Algorithm
///
/// 1-алгоритм `left + right` кичине чоңдуктары же чоң `T` үчүн колдонулат.
/// Элементтер `mid - left` тен баштап, `left + right` модулу менен `right` кадамдары менен алдыга жылып, акыркы позицияларына жылдырылат, андыктан убактылуу гана убакыт талап кылынат.
/// Акыр-аягы, биз кайра `mid - left` келет.
/// Бирок, эгер `gcd(left + right, right)` 1 болбосо, жогорудагы кадамдар элементтердин үстүнөн өткөрүлүп жиберилген.
/// Мисалы:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Бактыга жараша, жыйынтыкталган элементтердин арасынан өткөрүлүп берилген элементтердин саны ар дайым бирдей болот, андыктан биз баштапкы позициябыздын ордун толтуруп, көбүрөөк айлампаларды жасай алабыз (айлампалардын жалпы саны `gcd(left + right, right)` value)).
///
/// Акыры, бардык элементтер бир жолу жана бир жолу жыйынтыкталат.
///
/// Алгоритм 2 эгер `left + right` чоң, бирок `min(left, right)` кичинекей болсо, стек буферине батат.
/// `min(left, right)` элементтери буферге көчүрүлүп, башкаларга `memmove` колдонулат, ал эми буфердеги элементтер пайда болгон жердин карама-каршы тарабындагы тешикке кайра жылдырылат.
///
/// Векторлоштурулган алгоритмдер `left + right` чоң болгондон кийин жогорудагыдан ашып түшөт.
/// 1-алгоритмди векторлоштуруп, бир нече ирет айландырса болот, бирок орто эсеп менен `left + right` өтө чоң эмес, ал эми бир раунддун эң жаман учуру ошол жерде болот.
/// Анын ордуна, 3-алгоритм `min(left, right)` элементтерин бир аз айландыруу маселеси калганга чейин кайталап алмаштырууну колдонот.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// качан `left < right` алмашуу сол тараптан болот.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. бул учурлар текшерилбесе, төмөндөгү алгоритмдер иштебей калышы мүмкүн
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Алгоритм 1 Микробишмарктар кокустук жылышуулардын орточо көрсөткүчү болжол менен `left + right == 32` чейин жакшыраак экендигин көрсөтүп турат, бирок эң начар көрсөткүч 16 чамасында дагы бузулат.
            // 24 орто жолду тандап алган.
            // Эгерде `T` өлчөмү 4 `usize`ден чоң болсо, анда бул алгоритм башка алгоритмдерден да ашып түшөт.
            //
            //
            let x = unsafe { mid.sub(left) };
            // биринчи турдун башталышы
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` `gcd(left + right, right)` эсептөө жолу менен табууга болот, бирок gcdди кошумча эффект катары эсептеген бир циклди жасоо, андан кийин калган бөлүгүн жасоо
            //
            //
            let mut gcd = right;
            // Эталондор көрсөткөндөй, убактылуу бир жолу окуп, артка көчүрүп, аягында убактылуу жазуунун ордуна, убакытты алмаштыруу тезирээк.
            // Бул убактылуу адамдарды алмаштыруу же алмаштыруу циклинде экөөнү башкаруунун ордуна, бир гана эс тутумдун дарегин колдонгондугу менен байланыштуу болушу мүмкүн.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // `i` көбөйтүүнүн ордуна, анын чектен тышкары экендигин текшерүүнүн ордуна, `i` кийинки өсүштүн чегинен чыгып кетишин текшеребиз.
                // Бул көрсөткүчтөрдүн же `usize` оролушунун алдын алат.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // биринчи турдун аягы
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // бул шарттуу `left + right >= 15` болсо, ушул жерде болушу керек
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // бөлүктү дагы тегерек менен бүтүр
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` нөл өлчөмүндөгү тип эмес, ошондуктан анын көлөмүнө бөлсөк болот.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Алгоритм 2 `[T; 0]` бул T үчүн ылайыкташтырылган камсыз кылуу болуп саналат
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Алгоритм 3 Алгоритмдин алмашуу жолу бар, анда бул алгоритмдин акыркы алмашуусу кайда болоору жана ушул алгоритм сыяктуу чектеш бөлүктөрдү алмаштыруунун ордуна ошол акыркы бөлүктү колдонуп жасоо, бирок бул ыкма дагы тезирээк.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Алгоритм 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}