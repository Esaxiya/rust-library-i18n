//! ASCII `[u8]` боюнча операциялар.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Бул тилектеги бардык байттардын ASCII чегинде экендигин текшерет.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Эки кесинди ASCII регистрге сезимсиз дал келгенин текшерет.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` менен бирдей, бирок убактылуу материалдарды бөлбөй жана көчүрбөй.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Бул бөлүктү ASCII чоң тамга ордуна барабар кылып которот.
    ///
    /// 'a' тен 'z' ке чейинки ASCII тамгалары 'A' тен 'Z' ке чейин картага түшүрүлөт, бирок ASCII эмес тамгалар өзгөрүүсүз болот.
    ///
    /// Мурунку баасын өзгөртпөстөн, жаңы баш тамга маанисин кайтаруу үчүн [`to_ascii_uppercase`] колдонуңуз.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Бул бөлүктү ордуна ASCII кичинекей тамга эквивалентине которот.
    ///
    /// 'A' тен 'Z' ке чейинки ASCII тамгалары 'a' тен 'z' ке чейин картага түшүрүлөт, бирок ASCII эмес тамгалар өзгөрүүсүз болот.
    ///
    /// Мурунку баасын өзгөртпөстөн, жаңы кичине маанини кайтаруу үчүн [`to_ascii_lowercase`] колдонуңуз.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// `v` сөзүндөгү байт nonascii (>=128) болсо, `true` берет.
/// utf8 тастыктоосу үчүн окшош нерсени жасаган `../str/mod.rs` тен Snarfed.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Оптималдаштырылган ASCII тести, анда колдонмолордун ордуна байт-а-операцияларынын ордуна колдонулат (мүмкүн болсо).
///
/// Биз колдонгон алгоритм жөнөкөй.Эгер `s` өтө кыска болсо, анда биз ар бир байтты текшерип, аны менен бүтүрөбүз.Болбосо:
///
/// - Биринчи сөздү тегизделбеген жүктөм менен окуңуз.
/// - Көрсөткүчтү тегиздеп, кийинки сөздөрдү тегизделген жүктөр менен аягына чейин окуп чыгыңыз.
/// - Түзүлбөгөн жүктөм менен `s` тен акыркы `usize` ти окуңуз.
///
/// Эгерде ушул жүктөрдүн арасынан `contains_nonascii` (above) чындыгында кайтып келе турган нерсе чыкса, анда биз анын жоопу жалган экендигин билебиз.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Эгерде биз сөзмө-сөз ишке ашыруудан эч нерсе утпасак, анда кайра скалярдык циклге түшүңүз.
    //
    // Биз муну `size_of::<usize>()` `usize` үчүн жетиштүү деңгээлде тегизделбеген архитектуралар үчүн жасайбыз, анткени бул кызыктай edge иши.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Биринчи сөздү ар дайым тегизделбей окуйбуз, бул `align_offset` дегенди билдирет
    // 0, биз дагы бирдей мааниге ээ болуп, тегизделген окуу үчүн.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // КООПСУЗДУК: Биз жогоруда `len < USIZE_SIZE` текшеребиз.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Биз муну жогоруда кандайдыр бир мааниде текшердик.
    // `offset_to_aligned` же `align_offset` же `USIZE_SIZE` экендигин эске алыңыз, экөө тең жогоруда ачык текшерилген.
    //
    debug_assert!(offset_to_aligned <= len);

    // КООПСУЗДУК: word_ptr бул (туура тегизделген) usize ptr, биз аны окуу үчүн колдонобуз
    // кесиндин ортоңку бөлүгү.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` - `word_ptr` байт индекси, циклди текшерүү үчүн колдонулат.
    let mut byte_pos = offset_to_aligned;

    // Паранойя тегиздөө жөнүндө текшерет, анткени биз бир катар жүктөлбөгөн жүктөрдү жасайбыз.
    // Чындыгында, `align_offset` те катага жол бербөө мүмкүн эмес.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Кийинки сөздөрдү акыркы тегизделген сөзгө чейин окуп чыгыңыз, кийинчерээк куйрукту текшерүү үчүн жасала турган акыркы өз алдынча сөздү кошпогондо, куйрук ар дайым бирден `usize` болгондо, branch `byte_pos == len` ашыкча болот.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Акыл-эс текшерип, окуган чектерде
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Биздин `byte_pos` жөнүндө божомолдорубуз ошол бойдон турат.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // КООПСУЗДУК: Биз `word_ptr` туура дал келгенин билебиз (себеби
        // `align_offset`), жана бизде `word_ptr` менен аягына чейин жетиштүү байт бар экендигин билебиз
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // КООПСУЗДУК: Биз `byte_pos <= len - USIZE_SIZE` экенин билебиз, бул ошону билдирет
        // ушул `add` тен кийин, `word_ptr` эң көп дегенде аягына чыгат.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Чындыгында бир гана `usize` калганын текшерүү үчүн ден-соолукту текшерүү.
    // Бул биздин цикл шартыбыз менен кепилдениши керек.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // КООПСУЗДУК: Бул биз башында текшерген `len >= USIZE_SIZE` ке таянат.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}