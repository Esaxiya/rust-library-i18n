use crate::iter::{FusedIterator, TrustedLen};

/// Бир элементти чексиз кайталаган жаңы итераторду түзөт.
///
/// `repeat()` функциясы бир маанини кайра-кайра кайталайт.
///
/// `repeat()` сыяктуу чексиз итераторлор [`Iterator::take()`] сыяктуу адаптерлер менен колдонулат, аларды чектүү кылуу үчүн.
///
/// Эгер сизге керек болгон итератордун элемент түрү `Clone` программасын ишке ашырбаса, же кайталанган элементти эс тутумунда сактап калгыңыз келбесе, анда анын ордуна [`repeat_with()`] функциясын колдонсоңуз болот.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Негизги колдонуу:
///
/// ```
/// use std::iter;
///
/// // төрт саны 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // уф, дагы төртөө
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// [`Iterator::take()`] менен чектүү өтүү:
///
/// ```
/// use std::iter;
///
/// // акыркы мисал өтө эле көп болчу.Төрт гана төртөөбүз болсун.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... эми бүттүк
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Элементти чексиз кайталаган кайталоочу.
///
/// Бул `struct` [`repeat()`] функциясы менен түзүлгөн.Көбүрөөк маалымат алуу үчүн анын документтерин караңыз.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}