use crate::iter::{FusedIterator, TrustedLen};

/// Берилген жабууну, ретрансляторду колдонуу менен `A` типтеги элементтерди чексиз кайталаган жаңы итераторду түзөт, `F: FnMut() -> A`.
///
/// `repeat_with()` функциясы ретрансляторду кайра-кайра чакырат.
///
/// `repeat_with()` сыяктуу чексиз итераторлор [`Iterator::take()`] сыяктуу адаптерлер менен колдонулат, аларды чектүү кылуу үчүн.
///
/// Эгер сизге керек болгон итератордун элемент түрү [`Clone`] программасын ишке ашырса жана баштапкы элементти эс тутумунда сактап калуу туура болсо, анда анын ордуна [`repeat()`] функциясын колдонуу керек.
///
///
/// `repeat_with()` чыгарган итератор [`DoubleEndedIterator`] эмес.
/// Эгер [`DoubleEndedIterator`] ти кайтарып берүү үчүн `repeat_with()` керек болсо, анда колдонуу ишиңизди түшүндүрүп, GitHub маселесин ачыңыз.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Негизги колдонуу:
///
/// ```
/// use std::iter;
///
/// // келгиле, бизде `Clone` эмес түрдүн кандайдыр бир мааниси бар же ал кымбат болгондуктан али эс тутумда сакталышын каалабайт:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // түбөлүккө белгилүү бир мааниси:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Мутацияны колдонуу жана чектүү:
///
/// ```rust
/// use std::iter;
///
/// // Нөлдөн экөөнүн үчүнчү кубатына чейин:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... эми бүттүк
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Берилген жабууну `F: FnMut() -> A` колдонуу менен `A` типтеги элементтерди чексиз кайталаган итератор.
///
///
/// Бул `struct` [`repeat_with()`] функциясы менен түзүлгөн.
/// Көбүрөөк маалымат алуу үчүн анын документтерин караңыз.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}