use crate::ops::{ControlFlow, Try};

/// Эки четинен тең элементтерди бере алган итератор.
///
/// `DoubleEndedIterator` ти ишке ашыра турган нерсе, [`Iterator`] ти ишке ашыра турган нерсенин үстүнөн дагы бир кошумча жөндөмгө ээ: буюмдарды артынан, ошондой эле алдыдан алуу мүмкүнчүлүгү.
///
///
/// Артка да, артка да бирдей диапазондо иштеп, кесилишпестигин белгилей кетүү керек: ортодо жолукканда кайталоо бүттү.
///
/// [`Iterator`] протоколуна окшош түрдө, бир жолу `DoubleEndedIterator` [`None`] ти [`next_back()`] тен кайтарат, аны кайра чакырып, [`Some`] ти кайра кайтарып бербеши мүмкүн.
/// [`next()`] жана [`next_back()`] ушул максатта алмаштырылат.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Негизги колдонуу:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Итератордун аягындагы элементти алып салат жана кайтарат.
    ///
    /// Башка элементтер жок болгондо `None` берет.
    ///
    /// [trait-level] документтеринде көбүрөөк маалымат камтылган.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// "DoubleEndedIterator" ыкмалары берген элементтер [Iterator`] ыкмаларынан айырмаланышы мүмкүн:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Итераторду `n` элементтери аркасынан алдыга жылдырат.
    ///
    /// `advance_back_by` [`advance_by`] тин тескери версиясы болуп саналат.Бул ыкма `n` элементтерин [`None`] жолукканга чейин [`next_back`] `n` чейин чалып, арткы бөлүктөн баштайт.
    ///
    /// `advance_back_by(n)` итератор `n` элементтери менен ийгиликтүү алга жылса, [`Ok(())`] кайтып келет, же [`None`] кездешсе, [`Err(k)`] болот, мында `k`-элементтердин саны түгөнгөнгө чейин өркүндөтүлгөн элементтердин саны (б.а.
    /// итератордун узундугу).
    /// `k` ар дайым `n` тен аз экендигин эске алыңыз.
    ///
    /// `advance_back_by(0)` чалуу эч кандай элементтерди талап кылбайт жана ар дайым [`Ok(())`] кайтарып берет.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // гана `&3` өткөрүлүп берилди
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Итератордун аягынан `n`th элементин кайтарат.
    ///
    /// Бул [`Iterator::nth()`] тин түпкү версиясы.
    /// Көпчүлүк индекстөө операциялары сыяктуу эле, эсептөө нөлдөн башталат, ошондуктан `nth_back(0)` биринчи маанини аягынан, `nth_back(1)` экинчисин ж.б.
    ///
    ///
    /// Аяктоо менен кайтарылган элементтин ортосундагы бардык элементтер, анын ичинде кайтарылган элемент да сарпталарын эске алыңыз.
    /// Бул ошондой эле `nth_back(0)` бир эле кайталоочуга бир нече жолу чалып, ар кандай элементтерди кайтарып берет дегенди билдирет.
    ///
    /// `nth_back()` [`None`] кайтып келет, эгер `n` итератордун узундугунан чоң же ага барабар болсо.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// `nth_back()` номерине бир нече жолу чалып, кайталоочу артка кайтпайт:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Эгерде `n + 1` элементтерден аз болсо, `None` кайтарылат:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Бул [`Iterator::try_fold()`] версиясынын тескери версиясы: итератордун артынан баштап элементтерди алат.
    ///
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Ал кыска туташкандыктан, калган элементтер дагы эле итератор аркылуу жеткиликтүү.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Итератордун элементтерин арткы бөлүктөн баштап, бирдиктүү, акыркы мааниге чейин кыскартуучу кайталоочу ыкма.
    ///
    /// Бул [`Iterator::fold()`] тин тескери версиясы: ал арткы арткы бөлүктөн баштап элементтерди алат.
    ///
    /// `rfold()` эки аргументти талап кылат: баштапкы маани жана эки аргумент менен жабуу: 'accumulator' жана элемент.
    /// Жабуу аккумулятордун кийинки кайталоо үчүн маанисин берет.
    ///
    /// Баштапкы мааниси-бул аккумулятордун биринчи чалууда алган мааниси.
    ///
    /// Бул жабууну ар бир итератордун ар бир элементине колдонгондон кийин, `rfold()` аккумуляторду кайтарып берет.
    ///
    /// Бул операция кээде 'reduce' же 'inject' деп аталат.
    ///
    /// Бүктөө сизде бир нерсенин жыйнагы болгондо жана андан бир гана баалуулук чыгаргыңыз келгенде пайдалуу.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // а-нын бардык элементтеринин суммасы
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Бул мисал баштапкы мааниден баштап, ар бир элементтин артынан алдыңкы бөлүгүнө чейин уланган сап курат:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Арткы бөлүгүнөн предикатты канааттандырган итератордун элементин издейт.
    ///
    /// `rfind()` `true` же `false` кайтаруучу жабууну алат.
    /// Бул жабууну аягына чейин кайталоочу элементтин ар бир элементине колдонот жана эгер алардын кайсынысы болбосун `true` болсо, анда `rfind()` [`Some(element)`] кайтарат.
    /// Эгерде алардын бардыгы `false` кайтарса, ал [`None`] кайтарат.
    ///
    /// `rfind()` кыска туташуу;башкача айтканда, жабылуу `true` кайтарылаары менен, ал кайра иштетүүнү токтотот.
    ///
    /// `rfind()` шилтеме алгандыктан, көптөгөн итераторлор шилтемелердин үстүнөн кайталанышат, бул аргумент кош шилтеме болгон жерде түшүнүксүз жагдайга алып келет.
    ///
    /// Бул таасирди `&&x` менен төмөнкү мисалдардан көрө аласыз.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Биринчи `true` ти токтотуу:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // дагы элементтер бар болгондуктан, биз дагы деле `iter` колдоно алабыз.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}