/// Анын так узундугун билген кайталоочу.
///
/// Көпчүлүк [`Iterator`дун] канча жолу кайталанарын билишпейт, бирок кээ бирлери билишет.
/// Эгер кайталоочу канча жолу кайталай алаарын билсе, анда ал маалыматка жеткиликтүүлүк пайдалуу болушу мүмкүн.
/// Мисалы, артка кайталоону кааласаңыз, аягы кайда экенин билүү жакшы башталат.
///
/// `ExactSizeIterator` ти ишке ашырууда [`Iterator`] ти дагы ишке ашыруу керек.
/// Аткарганда, [`Iterator::size_hint`] * ишке ашырылышы кайталоочу көлөмүн так кайтарып бериши керек.
///
/// [`len`] ыкмасы демейки ишке ашырылышына ээ, андыктан аны колдонбошуңуз керек.
/// Бирок, сиз демейкиге караганда бир кыйла натыйжалуу ишке ашырууну камсыз кыла аласыз, андыктан аны жокко чыгаруу мааниге ээ.
///
///
/// Белгилей кетүүчү нерсе, бул trait коопсуз trait болгондуктан, кайтарылган узундук туура экендигине *кепилдик бербейт* жана * бере албайт.
/// Демек, `unsafe` коду ** [`Iterator::size_hint`] тууралыгына ишенбеши керек.
/// Туруксуз жана кооптуу [`TrustedLen`](super::marker::TrustedLen) trait бул кошумча кепилдик берет.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Негизги колдонуу:
///
/// ```
/// // чектүү диапазон канча жолу кайталана тургандыгын так билет
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs], биз [`Iterator`] ишке ашырдык, `Counter`.
/// Келгиле, ал үчүн `ExactSizeIterator` ишке ашыралы:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Калган кайталоолордун санын оңой эле эсептеп алабыз.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Эми биз аны колдоно алабыз!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Итератордун так узундугун кайтарып берет.
    ///
    /// Ишке ашыруу, [`None`] кайтарардан мурун, итератордун `len()` [`Some(T)`] маанисинен так `len()` деңгээлде кайтып келишин камсыз кылат.
    ///
    /// Бул ыкма демейки шартта ишке ашырылат, андыктан аны түздөн-түз ишке ашырбоо керек.
    /// Бирок, сиз натыйжалуу ишке ашырууну камсыз кыла алсаңыз, анда аны жасай аласыз.
    /// Мисал үчүн [trait-level] документтерин караңыз.
    ///
    /// Бул функция [`Iterator::size_hint`] функциясы сыяктуу коопсуздук кепилдиктерине ээ.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// // чектүү диапазон канча жолу кайталана тургандыгын так билет
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Бул ырастоо өтө эле коргонуучу, бирок инвариантты текшерет
        // trait тарабынан кепилденген.
        // Эгер бул trait rust-ички болсо, биз debug_assert колдоно алмакпыз !;assert_eq!бардык Rust колдонуучуларынын аткарылышын дагы текшерет.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Итератор бош болсо, `true` берет.
    ///
    /// Бул ыкма [`ExactSizeIterator::len()`] колдонуп демейки ишке ашырууга ээ, андыктан аны өзүңүз эле ишке ашыруунун кажети жок.
    ///
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}