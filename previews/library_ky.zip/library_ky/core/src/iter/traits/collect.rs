/// [`Iterator`] тен которуу.
///
/// `FromIterator` түрү үчүн, аны кайталоочудан кандайча түзүлө тургандыгын аныктайсыз.
/// Бул кандайдыр бир түрдөгү коллекцияны сүрөттөгөн типтер үчүн кеңири тараган.
///
/// [`FromIterator::from_iter()`] сейрек ачык деп аталат жана анын ордуна [`Iterator::collect()`] ыкмасы аркылуу колдонулат.
///
/// Көбүрөөк мисалдар үчүн [`Iterator::collect()`]'s документтерин караңыз.
///
/// Ошондой эле караңыз: [`IntoIterator`].
///
/// # Examples
///
/// Негизги колдонуу:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// `FromIterator` ти кыйыр түрдө колдонуу үчүн [`Iterator::collect()`] колдонуу:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Сиздин тип үчүн `FromIterator` ишке ашыруу:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Үлгү жыйнагы, бул жөн гана Vecтин үстүндөгү ором<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Келгиле, ага бир нече ыкмаларды берели, ошондо биз бирөөсүн түзүп, ага бир нерселерди кошо алабыз.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // жана биз FromIterator программасын ишке ашырабыз
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Эми жаңы итератор жасай алабыз ...
/// let iter = (0..5).into_iter();
///
/// // ... жана андан MyCollection жаса
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // да чыгармаларды чогултуу!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Итератордун маанисин түзөт.
    ///
    /// Көбүрөөк маалымат алуу үчүн [module-level documentation] караңыз.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// [`Iterator`] ке айландыруу.
///
/// `IntoIterator` түрү үчүн, аны итераторго кантип айландырууну аныктайсыз.
/// Бул кандайдыр бир түрдөгү коллекцияны сүрөттөгөн типтер үчүн кеңири тараган.
///
/// `IntoIterator` ти ишке ашыруунун бир артыкчылыгы, сиздин түрүңүз [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) болот.
///
///
/// Ошондой эле караңыз: [`FromIterator`].
///
/// # Examples
///
/// Негизги колдонуу:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Сиздин тип үчүн `IntoIterator` ишке ашыруу:
///
/// ```
/// // Үлгү жыйнагы, бул жөн гана Vecтин үстүндөгү ором<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Келгиле, ага бир нече ыкмаларды берели, ошондо биз бирөөсүн түзүп, ага бир нерселерди кошо алабыз.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // жана биз IntoIterator программасын ишке ашырабыз
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Эми жаңы коллекция жасай алабыз ...
/// let mut c = MyCollection::new();
///
/// // ... ага бир аз нерселерди кошуу ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... анан аны Итераторго айландырыңыз:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// `IntoIterator` ти trait bound катары колдонуу кадимки көрүнүш.Бул дагы деле болсо итератор болгондо гана, киргизүү коллекциясынын түрүн өзгөртүүгө мүмкүндүк берет.
/// Кошумча чектерди чектөө менен көрсөтсө болот
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Кайталанып жаткан элементтердин түрү.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Муну кайсыл итераторго айландырып жатабыз?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Бир мааниден кайталоочу түзөт.
    ///
    /// Көбүрөөк маалымат алуу үчүн [module-level documentation] караңыз.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Итератордун мазмунун камтыган жыйнакты кеңейтүү.
///
/// Итераторлор бир катар баалуулуктарды жаратат, ал эми жыйнактарды бир катар баалуулуктар катарында кароого болот.
/// `Extend` trait бул боштукту жоюп, ошол итератордун мазмунун камтыган коллекцияны кеңейтүүгө мүмкүндүк берет.
/// Коллекцияны мурунтан эле бар ачкыч менен кеңейткенде, ал жазуу жаңыртылат же бирдей ачкыч менен бир нече жазууга уруксат берген жыйнактарда, ошол жазуу киргизилет.
///
///
/// # Examples
///
/// Негизги колдонуу:
///
/// ```
/// // Сиз Stringди айрым белгилер менен узарта аласыз:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` ишке ашыруу:
///
/// ```
/// // Үлгү жыйнагы, бул жөн гана Vecтин үстүндөгү ором<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Келгиле, ага бир нече ыкмаларды берели, ошондо биз бирөөсүн түзүп, ага бир нерселерди кошо алабыз.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // MyCollection i32лердин тизмеси болгондуктан, биз i32 үчүн кеңейтүүнү ишке ашырабыз
/// impl Extend<i32> for MyCollection {
///
///     // Бул конкреттүү типтеги кол тамга менен бир аз жөнөкөй: биз i32s берген Iteratorга айландырыла турган нерсенин бардыгына кеңейтүүнү чакыра алабыз.
///     // Себеби, MyCollection ичине киргизүү үчүн бизге i32 керек.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Ишке ашыруу абдан жөнөкөй: итератор аркылуу цикл жана add() ар бир элементти өзүбүзгө.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // коллекциябызды дагы үч сан менен кеңейте берели
/// c.extend(vec![1, 2, 3]);
///
/// // биз бул элементтерди аягына чейин коштук
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Итератордун мазмунун камтыган жыйнакты кеңейтет.
    ///
    /// Бул trait үчүн бирден-бир талап кылынган ыкма болгондуктан, [trait-level] документтеринде көбүрөөк маалыматтар камтылган.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// // Сиз Stringди айрым белгилер менен узарта аласыз:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Так бир элементтен турган коллекцияны кеңейтет.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Берилген кошумча элементтер үчүн коллекциядагы резервдердин сыйымдуулугу.
    ///
    /// жарыяланбаган ишке ашыруу эч нерсе кылбайт.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}