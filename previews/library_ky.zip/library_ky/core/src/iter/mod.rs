//! Композиттик тышкы кайталоо.
//!
//! Эгерде сиз өзүңүздү кандайдыр бир түрдөгү коллекция менен тапкан болсоңуз жана аталган коллекциянын элементтерине операция жасашыңыз керек болсо, анда тез арада 'iterators' ке түшөсүз.
//! Итеративдүү Rust кодунда итераторлор кеңири колдонулат, андыктан алар менен таанышуу керек.
//!
//! Көбүрөөк түшүндүрүүдөн мурун, бул модуль кандайча түзүлүп жаткандыгы жөнүндө сүйлөшөлү:
//!
//! # Organization
//!
//! Бул модуль негизинен түрлөрү боюнча уюштурулган:
//!
//! * [Traits] негизги бөлүгү болуп саналат: бул traits кандай итераторлор бар экендигин жана алар менен эмне кылууга боло тургандыгын аныктайт.Бул traits ыкмалары кошумча окуу убактысын сарптоого арзыйт.
//! * [Functions] негизги итераторлорду түзүүнүн пайдалуу жолдору менен камсыз кылыңыз.
//! * [Structs] көп учурда бул модулдун traits ар кандай ыкмаларын кайтарып берүүчү түрлөрү болуп саналат.Адатта, `struct` эмес, `struct` түзүүчү ыкманы карап көргүңүз келет.
//! Эмнеге байланыштуу кененирээк маалымат алуу үчүн, '[Implementing Iterator](#ишке ашыруу-итератор)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Дал ушул!Келгиле, итераторлорду изилдеп көрөлү.
//!
//! # Iterator
//!
//! Бул модулдун жүрөгү жана жаны [`Iterator`] trait.[`Iterator`] ядросу төмөнкүдөй көрүнөт:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Итератордун [`next`] ыкмасы бар, ал чакырганда ["Опция"] `кайтарат<Item>".
//! [`next`] элементтер бар болгондо [`Some(Item)`] кайтарып берет жана алардын бардыгы түгөнүп бүткөндөн кийин `None` кайталанып бүткөнүн көрсөтөт.
//! Айрым кайталоочулар кайталоону улантууну тандап алышы мүмкүн, ошондуктан кайрадан [`next`] чалып, [`Some(Item)`] кайтып келе башташы мүмкүн (мисалы, [`TryIter`] караңыз).
//!
//!
//! ["Итератордун" толук аныктамасында дагы бир катар башка ыкмалар бар, бирок алар [`next`] үстүнө курулган демейки ыкмалар, ошондуктан аларды акысыз аласыз.
//!
//! Итераторлор дагы композиттик мүнөздө жана аларды иштетүүнүн татаал түрлөрүн бириктирүү үчүн чынжыр менен байлоо кеңири таралган.Көбүрөөк маалымат алуу үчүн төмөнкү [Adapters](#adapters) бөлүмүн караңыз.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Кайталоонун үч формасы
//!
//! Жыйнактан итераторлорду түзө турган үч жалпы ыкма бар:
//!
//! * `iter()`, кайталанган `&T`.
//! * `iter_mut()`, кайталанган `&mut T`.
//! * `into_iter()`, кайталанган `T`.
//!
//! Стандарттуу китепканадагы ар кандай нерселер, керек болсо, үчөөнүн бирин же бир нечесин ишке ашырышы мүмкүн.
//!
//! # Итераторду ишке ашыруу
//!
//! Өзүңүздүн итераторуңузду түзүү эки баскычты камтыйт: итератордун абалын кармап туруу үчүн `struct` түзүү, андан кийин X002 үчүн [`Iterator`].
//! Ушул себептен бул модулда "struct`s" көп: ар бир итератор жана итератор адаптери үчүн бирден болот.
//!
//! Келгиле, `1` тен `5` ке чейин эсептелген `Counter` деген итератор жасайбыз:
//!
//! ```
//! // Биринчиден, структура:
//!
//! /// Бирден бешке чейин эсептелген итератор
//! struct Counter {
//!     count: usize,
//! }
//!
//! // эсептөөбүз бирден башталышын каалайбыз, андыктан жардам берүү үчүн new() ыкмасын кошолу.
//! // Бул өтө зарыл эмес, бирок ыңгайлуу.
//! // `count` ти нөлдөн баштай тургандыгыбызды эске алыңыз, эмне үчүн төмөндө `next()`'s ишке ашырылышынан көрөбүз.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Андан кийин, биз `Counter` үчүн `Iterator` ишке ашырабыз:
//!
//! impl Iterator for Counter {
//!     // биз usize менен санайбыз
//!     type Item = usize;
//!
//!     // next() талап кылынган бирден-бир ыкма
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Биздин саныбызды көбөйт.Ошондуктан биз нөлдөн баштадык.
//!         self.count += 1;
//!
//!         // Санап бүттүкпү же жокпу, текшерип көрүңүз.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Эми биз аны колдоно алабыз!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! [`next`] номерине чалуу кайталанат.Rust `None` жеткенге чейин сиздин итераторуңузда [`next`] чакыра турган конструкцияга ээ.Андан кийинкисин карап көрөлү.
//!
//! Ошондой эле `Iterator` ички `next` деп аталган `nth` жана `fold` сыяктуу ыкмаларды демейки ишке ашырууну камсыз кылат.
//! Бирок, `nth` жана `fold` сыяктуу ыкмаларды колдонуучунун аткаруусуна жазуу мүмкүн, эгерде аларды итератор `next` чакырбай эле натыйжалуу эсептей алса.
//!
//! # `for` циклдар жана `IntoIterator`
//!
//! Rust нин `for` цикл синтаксиси-бул чындыгында итераторлор үчүн кант.Бул жерде `for` негизги мисалы:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Бул сандарды бирден бешке чейин, ар бири өз сабында басып чыгарат.Бирок сиз бул жерден бир нерсени байкайсыз: биз эч качан vector итераторун өндүрүү үчүн эч нерсе чакырган эмеспиз.Эмне берет?
//!
//! Стандарттуу китепканада бир нерсени итераторго айлантуу үчүн trait бар: [`IntoIterator`].
//! Бул trait [`into_iter`] деген бир ыкмага ээ, ал [`IntoIterator`] ти ишке ашыруучу нерсени итераторго айландырат.
//! Келгиле, ошол `for` циклин дагы бир жолу карап чыгалы жана аны түзүүчү эмнеге айландырат:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust муну шекерден ажыратат:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Биринчиден, биз `into_iter()` маанисине чалабыз.Андан кийин, биз кайтып келген итераторго дал келип, `None` көргөнгө чейин [`next`] номерин кайра-кайра чакырабыз.
//! Ошол учурда, биз `break` укуругунан чыгып, кайталап бүттүк.
//!
//! Бул жерде дагы бир кичинекей бит бар: стандарттуу китепкана [`IntoIterator`] программасынын кызыктуу программасын камтыйт:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Башка сөз менен айтканда, бардык ["Итератордун" [`IntoIterator`] жүзөгө ашырат, жөн гана өзүлөрүн кайтарып.Бул эки нерсени билдирет:
//!
//! 1. Эгер сиз [`Iterator`] жазып жатсаңыз, анда аны `for` цикли менен колдонсоңуз болот.
//! 2. Эгер сиз коллекция түзүп жаткан болсоңуз, анда [`IntoIterator`] программасын ишке ашыруу сиздин коллекцияны `for` цикли менен колдонууга мүмкүндүк берет.
//!
//! # Шилтеме менен кайталоо
//!
//! [`into_iter()`] `self` маанисин алгандыктан, `for` циклин колдонуп, коллекциянын үстүнөн кайталоо ошол жыйнакты керектейт.Көбүнчө, коллекцияңызды сарптабай кайталоону кааласаңыз болот.
//! Көпчүлүк коллекциялар адаттагыдай `iter()` жана `iter_mut()` деп аталган шилтемелер боюнча итераторлорду сунуш кылган ыкмаларды сунуш кылышат:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` дагы эле ушул функцияга таандык.
//! ```
//!
//! Эгерде `C` түрүндөгү коллекция `iter()` менен камсыз кылса, анда ал, адатта, X0 `IntoIterator` ти `&C` үчүн, `iter()` ти жөн гана аткара турган ишке ашырат.
//! Ошо сыяктуу эле, `iter_mut()` ти камсыз кылган `C` жыйнагы, `&mut C` үчүн `IntoIterator` ти `iter_mut()` ке өткөрүп берүү менен жалпысынан ишке ашырат.Бул ыңгайлуу стенографияны берет:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // `values.iter_mut()` сыяктуу
//!     *x += 1;
//! }
//! for x in &values { // `values.iter()` сыяктуу
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Көптөгөн коллекцияларда `iter()` сунушталса, алардын бардыгы эле `iter_mut()` сунуштабайт.
//! Мисалы, [`HashSet<T>`] же [`HashMap<K, V>`] баскычтарынын мутациясы, эгер ачкыч таштандылары өзгөрсө, коллекцияны карама-каршы абалга келтириши мүмкүн, андыктан бул жыйнактар `iter()` гана сунуш кылат.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! [`Iterator`] алып, башка [`Iterator`] ти кайтарган функциялар көбүнчө "адаптер адаптери" деп аталат, анткени алар 'адаптердин формасы
//! pattern'.
//!
//! Жалпы итератор адаптерлерине [`map`], [`take`] жана [`filter`] кирет.
//! Көбүрөөк билүү үчүн, алардын документтерин караңыз.
//!
//! Эгерде кайталоочу адаптер panics болсо, анда ал такталбаган (бирок эс тутумга коопсуз) абалда болот.
//! Бул абал Rust версиялары боюнча бирдей бойдон кала тургандыгына кепилдик берилбейт, андыктан панорамага кабылган итератор кайтарган так маанилерге ишенүүдөн алыс болуңуз.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Итераторлор (жана [adapters](#adapters)) итератору *жалкоо*. Бул дегенибиз, жөн гана итераторду түзүү _do_ деген сөз эмес. [`next`] номерине чалганга чейин эч нерсе болбойт.
//! Итераторду анын терс таасирлери үчүн гана түзүп жатканда, бул кээде башаламандыктын булагы болуп саналат.
//! Мисалы, [`map`] ыкмасы кайталанган ар бир элементтин жабылышын чакырат:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Бул эч кандай баалуулуктарды басып чыгарбайт, анткени биз аны колдонуудан көрө, кайталоочу гана жасадык.Компилятор бизге мындай жүрүм-турум жөнүндө эскертет:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! [`map`] терс таасирлери үчүн жазуунун идиомикалык жолу-`for` циклин колдонуу же [`for_each`] ыкмасын чакыруу:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Итераторду баалоонун дагы бир кеңири таралган жолу-жаңы жыйнак чыгаруу үчүн [`collect`] ыкмасын колдонуу.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Итераторлор чектүү болушу шарт эмес.Мисалы, ачык диапазон чексиз кайталоочу болуп саналат:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Чексиз итераторду чектелгенге айландыруу үчүн [`take`] итератор адаптерин колдонуу кеңири таралган:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Бул `0` менен `4` сандарын ар бири өз сабында басып чыгарат.
//!
//! Чексиз итераторлордогу методдор, ал тургай, натыйжаны чектелген убакытта математикалык жол менен аныктоого мүмкүн болгон методдор да токтобошу мүмкүн экендигин эсиңизден чыгарбаңыз.
//! Тактап айтканда, жалпылап айтканда, ар кандай элементтерди кайталоону талап кылган [`min`] сыяктуу ыкмалар эч кандай чексиз кайталоочулар үчүн ийгиликтүү кайтып келбейт.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Ой жок!Чексиз цикл!
//! // `ones.min()` чексиз циклди пайда кылат, андыктан биз ушул чекке жете албайбыз!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;