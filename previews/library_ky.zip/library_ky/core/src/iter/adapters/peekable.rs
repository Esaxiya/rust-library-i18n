use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// Кийинки элементке милдеттүү эмес шилтеме берген `peek()` менен кайталоочу.
///
///
/// Бул `struct` [`Iterator`] боюнча [`peekable`] ыкмасы менен түзүлгөн.
/// Көбүрөөк маалымат алуу үчүн анын документтерин караңыз.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// Эч ким жок болсо дагы, бааланган баалуулукту унутпаңыз.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// Peekable унутпашы керек, эгер `.peek()` ыкмасында Эч ким көрүнбөсө.
// Бул `.peek() камсыз кылат;.peek();` же `.peek();.next();` бир гана жолу негизги итераторду алдыга жылдырат.
// Бул өзүнөн-өзү итераторду эритпейт.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// Итераторду алга жылдырбастан next() маанисине шилтеме берет.
    ///
    /// [`next`] сыяктуу эле, эгер бир мааниси бар болсо, ал `Some(T)` менен оролот.
    /// Бирок кайталоо бүткөн болсо, `None` кайтарылып берилет.
    ///
    /// [`next`]: Iterator::next
    ///
    /// `peek()` шилтемени кайтарып бергендиктен жана көптөгөн кайталоочулар шилтемелердин үстүнөн кайталанышкандыктан, кайтып келген маани эки эселенген түшүнүксүз жагдай болушу мүмкүн.
    /// Бул таасирди төмөндөгү мисалдардан көрө аласыз.
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() бизге future менен таанышууга мүмкүнчүлүк берет
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // Итератор биз бир нече жолу `peek` болсо дагы алдыга жылбайт
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Итератор бүткөндөн кийин `peek()` да бүтөт
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// Итераторду алга жылдырбастан next() маанисине өзгөрүлмө шилтеме берет.
    ///
    /// [`next`] сыяктуу эле, эгер бир мааниси бар болсо, ал `Some(T)` менен оролот.
    /// Бирок кайталоо бүткөн болсо, `None` кайтарылып берилет.
    ///
    /// `peek_mut()` шилтемени кайтарып бергендиктен жана көптөгөн кайталоочулар шилтемелердин үстүнөн кайталанышкандыктан, кайтып келген маани эки эселенген түшүнүксүз жагдай болушу мүмкүн.
    /// Бул таасирди төмөндөгү мисалдардан көрө аласыз.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // `peek()` сыяктуу эле, биз future ди итераторду илгерилетпей көрө алабыз.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // Итераторду карап чыгып, өзгөрүлмө шилтеменин артындагы маанини коюңуз.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // Итератор уланып жатканда биз койгон маани кайрадан пайда болот.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// Шарт туура болсо, ушул итератордун кийинки маанисин колдонуп, кайтарып бериңиз.
    /// Эгерде `func` ушул итератордун кийинки мааниси үчүн `true` берсе, аны колдонуп, кайтарып бериңиз.
    /// Болбосо, `None` кайтарыңыз.
    /// # Examples
    /// Эгер ал 0го барабар болсо, аны керектеңиз.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Итератордун биринчи пункту 0;аны керектөө.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // Кийинки кайтарылган нерсе азыр 1, демек `consume` `false` кайтарат.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` `expected` менен барабар болбосо, кийинки нерсенин маанисин сактайт.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// 10дон аз сандагы керектөө.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // Бардык сандарды 10дон аз керектөө
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // Кийинки кайтарылган маани 10 болот
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // Биз `self.next()` деп атагандыктан, биз `self.peeked` ти керектедик.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// Кийинки нерсени `expected` менен барабар болсо, керектеп жана кайтарып бериңиз.
    /// # Example
    /// Эгер ал 0го барабар болсо, аны керектеңиз.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Итератордун биринчи пункту 0;аны керектөө.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // Кийинки кайтарылган нерсе азыр 1, демек `consume` `false` кайтарат.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` `expected` менен барабар болбосо, кийинки нерсенин маанисин сактайт.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // КООПСУЗДУК: кооптуу функцияны ошол эле талаптарга ылайык кооптуу функцияга багыттоо
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}