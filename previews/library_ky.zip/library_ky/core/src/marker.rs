//! Негизги traits жана типтердин негизги касиеттерин чагылдырган типтер.
//!
//! Rust түрлөрүн ички касиеттери боюнча ар кандай пайдалуу жолдор менен классификациялоого болот.
//! Бул классификация traits катары берилген.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Жип чектери аркылуу өткөрүлүп бериле турган типтер.
///
/// Бул trait компилятор ылайыктуу деп тапканда автоматтык түрдө ишке ашырылат.
///
/// "Жөнөтүү" эмес типтеги мисал [`rc::Rc`][`Rc`] шилтеме эсептөө көрсөткүчү.
/// Эгерде эки жип бир эле шилтеме менен эсептелген маанини көрсөткөн [`Rc`] к-н клондоштурууга аракет кылса, анда бир эле учурда шилтеме санын жаңыртууга аракет жасалышы мүмкүн, бул [undefined behavior][ub], анткени [`Rc`] атомдук операцияларды колдонбойт.
///
/// Анын бөлөсү [`sync::Arc`][arc] атомдук операцияларды колдонот (бир аз ашыкча чыгымдарды талап кылат), демек, `Send`.
///
/// Көбүрөөк маалымат алуу үчүн [the Nomicon](../../nomicon/send-and-sync.html) караңыз.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Компиляция убагында белгилүү болгон туруктуу көлөмдөгү типтер.
///
/// Бардык типтеги параметрлердин `Sized` чектелген чеги бар.Эгерде бул туура эмес болсо, `?Sized` атайын синтаксисин колдонсо болот.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//ката: Өлчөмү [i32] үчүн иштетилген эмес
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Бир өзгөчөлүк-trait дин жашыруун `Self` түрү.
/// trait ачык эмес `Sized` байланышына ээ эмес, анткени бул [trait объектисине] туура келбейт, андыктан trait мүмкүн болгон бардык аткаруучулар менен иштеши керек, ошондуктан каалаган өлчөмдө болушу мүмкүн.
///
///
/// Rust сизге `Sized` ти trait менен байланыштырууга мүмкүндүк берсе дагы, сиз аны кийин trait объектисин түзүү үчүн пайдалана албайсыз:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // y: &dyn Bar= &Impl;//ката: trait `Bar` объектке айландырылбайт
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // мисалы, `[T]: !Default` ти баалоону талап кылган Default үчүн
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Динамикалык чоңдуктагы типке "unsized" боло турган түрлөрү.
///
/// Мисалы, `[i8; 2]` массивиндеги `Unsize<[i8]>` жана `Unsize<dyn fmt::Debug>` массивдери иштелип чыгат.
///
/// Бардык `Unsize` шаймандар автоматтык түрдө компилятор тарабынан камсыз кылынат.
///
/// `Unsize` үчүн жүзөгө ашырылат:
///
/// - `[T; N]` `Unsize<[T]>` болуп саналат
/// - `T` `T: Trait` болгондо `Unsize<dyn Trait>` болот
/// - `Foo<..., T, ...>` эгер `Unsize<Foo<..., U, ...>>` болсо:
///   - `T: Unsize<U>`
///   - Foo структура
///   - `Foo` акыркы талаасында гана `T` катышкан түрү бар
///   - `T` башка талаалардын түрүнө кирбейт
///   - `Bar<T>: Unsize<Bar<U>>`, эгер `Foo` акыркы талаасы `Bar<T>` тибине ээ болсо
///
/// `Unsize` [`ops::CoerceUnsized`] менен бирге "user-defined" контейнерлерине, мисалы, [`Rc`] динамикалык өлчөмдөгү түрлөрүн камтууга мүмкүнчүлүк берүү үчүн колдонулат.
/// Көбүрөөк маалымат алуу үчүн [DST coercion RFC][RFC982] жана [the nomicon entry on coercion][nomicon-coerce] караңыз.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Оюндун дал келүүсүндө колдонулган туруктуу үчүн trait талап кылынат.
///
/// `PartialEq` чыгарган ар кандай тип, ушул trait автоматтык түрдө жүзөгө ашырат,*анын тип параметрлери `Eq` аткаргандыгына карабастан*.
///
/// Эгерде `const` элементинде ушул trait ди ишке ашырбаган кандайдыр бир түр камтылса, анда ал (1.) түрү `PartialEq` ти ишке ашырбайт (демек, туруктуу коддун пайда болушун болжолдогон салыштыруу ыкмасын бербейт), же (2.) ал өзү ишке ашырат * *`PartialEq` версиясы (биз түзүмдүк-теңдик салыштыруусуна туура келбейт).
///
///
/// Жогорудагы эки сценарийдин экөөндө тең, мындай константаны үлгү дал келүүсүндө колдонуудан баш тартабыз.
///
/// Ошондой эле [structural match RFC][RFC1445] жана [issue 63438] караңыз, бул атрибутка негизделген дизайндан ушул trait ге көчүүгө түрткү берди.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Оюндун дал келүүсүндө колдонулган туруктуу үчүн trait талап кылынат.
///
/// `Eq` чыгарган ар кандай тип, ушул trait автоматтык түрдө жүзөгө ашырат,*анын тип параметрлери `Eq` аткаргандыгына карабастан*.
///
/// Бул биздин типтеги тутумдагы чектөөнүн айланасында иштөө үчүн хак.
///
/// # Background
///
/// Оюндун дал келүүсүндө колдонулган конструкциялардын түрлөрү `#[derive(PartialEq, Eq)]` атрибутуна ээ болушун каалайбыз.
///
/// Эң идеалдуу дүйнөдө, биз ал талапты `StructuralPartialEq` trait *жана*`Eq` trait экөө тең аткарылышын текшерүү менен текшере алмакпыз.
/// Бирок, сизде * `derive(PartialEq, Eq)` жасаган ADT'лер болушу мүмкүн жана биз компилятор кабыл алгыдай болушу мүмкүн, бирок константтын түрү `Eq` ти аткара албай калат.
///
/// Тактап айтканда, мындай иш:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Жогорудагы коддогу көйгөй, `Wrap<fn(&())>` `PartialEq` ти да, `Eq` ти да ишке ашырбайт, анткени "for a" fn(&'a _)` does not implement those traits.)
///
/// Демек, биз `StructuralPartialEq` жана `Eq` жөнөкөй текшерүүгө ишене албайбыз.
///
/// Ушунун тегерегинде иштөө үчүн, биз (`#[derive(PartialEq)]` жана `#[derive(Eq)]`) келип чыккан эки бөлүктүн ар бири сайган эки өзүнчө traits колдонобуз жана алардын экөө тең структуралык-дал келүүсүн текшерүүнүн алкагында бар экендигин текшеребиз.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Биттерди көчүрүп алуу менен алардын маанилери кайталана турган типтер.
///
/// Демейки шартта, өзгөрүлмө тутумдарда "жылдыруу семантикасы" бар.Башкача айтканда:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y` ке өттү, андыктан аны колдонууга болбойт
///
/// // println! ("{: ?}", x);//ката: жылдырылган маанини колдонуу
/// ```
///
/// Бирок, эгер түрү `Copy` ти ишке ашырса, анын ордуна "көчүрмө семантикасы" бар:
///
/// ```
/// // Биз `Copy` ишке ашырууга болот.
/// // `Clone` ошондой эле `Copy` супертрейти болгондуктан талап кылынат.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` `x` көчүрмөсү
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Ушул эки мисалда бир гана айырмачылык, сизге тапшырма берилгенден кийин `x` ке кирүүгө уруксат берилген-берилбестиги.
/// Капоттун астында, көчүрмө дагы, кыймылдаса дагы, эс тутумга бит көчүрүлүп калышы мүмкүн, бирок кээде аны оптималдаштырып коюшат.
///
/// ## `Copy` ти кантип ишке ашырсам болот?
///
/// `Copy` ти сиздин түрүңүзгө киргизүүнүн эки жолу бар.Эң жөнөкөйү-`derive` колдонуу:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Ошондой эле `Copy` жана `Clone` кол менен ишке ашыра аласыз:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Экөөнүн ортосунда кичине айырма бар: `derive` стратегиясы `Copy` түрүнүн параметрлерине байланыштуу болот, ал дайыма эле каалана бербейт.
///
/// ## `Copy` менен `Clone` ортосунда кандай айырма бар?
///
/// Көчүрмөлөр кыйыр түрдө пайда болот, мисалы, `y = x` тапшырмасынын бир бөлүгү катары.`Copy` жүрүм-туруму ашыкча жүктөлбөйт;бул ар дайым жөнөкөй акылдуу көчүрмө.
///
/// Клондоштуруу ачык иш-аракет, `x.clone()`.[`Clone`] ишке ашыруу баалуулуктарды коопсуз көчүрүп алуу үчүн зарыл болгон ар кандай типтеги жүрүм-турумду камсыз кыла алат.
/// Мисалы, [`Clone`] ти [`String`] үчүн жүзөгө ашырганда, үйүлгөн бурчтуу сап буферин көчүрүү керек.
/// [`String`] маанилеринин жөнөкөй биттик көчүрмөсү көрсөткүчтү көчүрүп алса, сызыктан эки эсе бош орунга чыгат.
/// Ушул себептен [`String`] [`Clone`], бирок `Copy` эмес.
///
/// [`Clone`] бул `Copy` супертрейти, ошондуктан `Copy` болгондордун бардыгы [`Clone`] ти ишке ашырышы керек.
/// Эгерде түрү `Copy` болсо, анда анын [`Clone`] жүзөгө ашырылышы `*self` гана кайтарышы керек (жогоруда келтирилген мисалды караңыз).
///
/// ## Менин түрүм качан `Copy` болушу мүмкүн?
///
/// Эгерде анын бардык компоненттери `Copy` ти ишке ашырса, бир түр `Copy` ти ишке ашыра алат.Мисалы, бул структура `Copy` болушу мүмкүн:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// А структурасы `Copy` болушу мүмкүн, ал эми [`i32`]-`Copy`, ошондуктан `Point` `Copy` болууга укуктуу.
/// Тескерисинче, карап көрөлү
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// `PointList` структурасы `Copy` ти ишке ашыра албайт, анткени [`Vec<T>`] `Copy` эмес.Эгер биз `Copy` программасын чыгарууга аракет кылсак, анда ката кетет:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Жалпы (`&T`) шилтемелери да `Copy` болуп саналат, андыктан `Copy`*эмес*`Copy` болгон `T` типтеги жалпы шилтемелерди кармаса дагы, бир түр `Copy` болушу мүмкүн.
/// `Copy` ти ишке ашыра турган төмөнкү структураны карап көрүңүз, анткени ал биздин жогорудагы "Copy" эмес `PointList` түрүнө *жалпы шилтеме* гана берет:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Качан * менин түрүм `Copy` боло албайт?
///
/// Айрым түрлөрүн коопсуз көчүрүп алуу мүмкүн эмес.Мисалы, `&mut T` көчүрмөсүн колдонсоңуз, өзгөрүлмө шилтеме жасалат.
/// [`String`] көчүрмөсү ["String`]" буферин башкаруу үчүн жоопкерчиликти кайталап, эки эсе акысыз болот.
///
/// Акыркы учурду жалпылап айтканда, [`Drop`] ти ишке ашырган ар кандай тип `Copy` болушу мүмкүн эмес, анткени ал өзүнүн [`size_of::<T>`] байтынан тышкары, айрым ресурстарды башкарат.
///
/// Эгерде сиз `Copy` ти "Copy" эмес маалыматтарды камтыган структурада же энумда колдонууга аракет кылсаңыз, анда [E0204] катасы пайда болот.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Качан * менин түрүм `Copy` болушу керек?
///
/// Жалпылап айтканда, _can_ түрү `Copy` ти ишке ашырса, анда ал керек.
/// Бирок `Copy` ти колдонуу сиздин типтеги коомдук APIдин бөлүгү экендигин унутпаңыз.
/// Эгерде future түрүндө "көчүрмө" болбой калышы мүмкүн болсо, анда API өзгөрүүсүн бузбоо үчүн, `Copy` ишке ашырылышын азыр таштап койсоңуз болот.
///
/// ## Кошумча аткаруучулар
///
/// [implementors listed below][impls] тышкары, төмөнкү түрлөрү `Copy` жүзөгө ашырат:
///
/// * Функциянын пункт түрлөрү (б.а., ар бир функция үчүн аныкталган түрлөрү)
/// * Функциянын көрсөткүчтөрүнүн түрлөрү (мис., `fn() -> i32`)
/// * Массив түрлөрү, бардык өлчөмдөр үчүн, эгерде объект түрү `Copy` үлгүсүн колдонсо (мисалы, `[i32; 123456]`)
/// * Tuple түрлөрү, эгерде ар бир компонент `Copy` ти ишке ашырса (мисалы, `()`, `(i32, bool)`)
/// * Жабуу түрлөрү, эгерде алар айлана-чөйрөдөн эч кандай мааниге ээ болбосо же алынган бардык ушул баалуулуктар `Copy` ти өздөштүрсө.
///   Белгилей кетчү нерсе, жалпы шилтеме менен алынган өзгөрүлмө ар дайым `Copy` (референт жок болсо дагы) колдонот, ал эми өзгөрүлмө шилтеме менен алынган өзгөрүлмө эч качан `Copy` болбойт.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Бул, өмүр бою канааттанбагандыктан, `Copy` колдонбогон түрдү көчүрүүгө мүмкүндүк берет (`A<'static>: Copy` жана `A<'_>: Clone` болгондо гана `A<'_>` көчүрөт).
// Бул өзгөчөлүк азырынча бар, анткени стандарттык китепканада мурунтан эле бар болгон бир нече `Copy` адистиги бар, жана учурда мындай жүрүм-турумду коопсуз жүргүзүүнүн эч кандай жолу жок.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// trait `Copy` имплинин түзүүчү макроэлектроника.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Жиптер арасында шилтемелерди бөлүшүү коопсуз болгон түрлөрү.
///
/// Бул trait компилятор ылайыктуу деп тапканда автоматтык түрдө ишке ашырылат.
///
/// Так аныктамасы: `T` [`Sync`], эгер `&T` [`Send`] болсо гана.
/// Башка сөз менен айтканда, `&T` шилтемелерди жиптер арасында өткөрүп жатканда [undefined behavior][ub] (маалымат жарыштарын кошо алганда) мүмкүнчүлүгү жок болсо.
///
/// Күткөндөй, [`u8`] жана [`f64`] сыяктуу алгачкы типтер [`Sync`], ошондой эле аларды камтыган жөнөкөй агрегат түрлөрү, мисалы, коробкалар, структуралар жана энумдар.
/// Негизги [`Sync`] типтеринин мисалдарына `&T` сыяктуу "immutable" түрлөрү жана жөнөкөй тукум куучулук өзгөрүлмө, мисалы, [`Box<T>`][box], [`Vec<T>`][vec] жана башка көпчүлүк коллекциялар кирет.
///
/// (Контейнери ["Шайкештирүү"] болушу үчүн жалпы параметрлер [`Sync`] болушу керек.)
///
/// Аныктаманын таң калыштуу натыйжасы, `&mut T` `Sync` (эгер `T` `Sync` болсо), бирок ал шайкештештирилбеген мутацияны камсыз кылгандай сезилет.
/// Айла кеткенде, жалпы маалымдаманын артындагы өзгөрүлмө шилтеме (башкача айтканда, `& &mut T`) `& &T` болгондой эле, окууга гана айланат.
/// Демек, маалымат жарышынын коркунучу жок.
///
/// `Sync` болбогон түрлөрү, "interior mutability" жипке кооптуу формада, мисалы [`Cell`][cell] жана [`RefCell`][refcell].
/// Бул типтер өзгөрүлбөс, жалпы маалымдама аркылуу да алардын мазмунунун мутациясына жол берет.
/// Мисалы, [`Cell<T>`][cell] боюнча `set` методу `&self` ти талап кылат, андыктан [`&Cell<T>`][cell] жалпы маалыматын гана талап кылат.
/// Метод эч кандай синхрондоштурууну жүргүзбөйт, андыктан [`Cell`][cell] `Sync` боло албайт.
///
/// "Sync" эмес типтеги дагы бир мисал-бул [`Rc`][rc] шилтеме эсептөө көрсөткүчү.
/// Кандайдыр бир [`&Rc<T>`][rc] маалыматын эске алганда, сиз атомдук эмес жол менен шилтеме эсептөөлөрүн өзгөртүп, жаңы [`Rc<T>`][rc] клонун жасай аласыз.
///
/// Ички жиптин коопсуз өзгөрүүсүнө муктаж болгон учурларда, Rust [atomic data types] менен камсыз кылат, ошондой эле [`sync::Mutex`][mutex] жана [`sync::RwLock`][rwlock] аркылуу ачык кулпулоону камсыз кылат.
/// Бул типтер ар кандай мутация маалымат жарыштарын жаратпасын камсыз кылат, демек, түрлөрү `Sync`.
/// Ошо сыяктуу эле, [`sync::Arc`][arc] жиптен корголгон [`Rc`][rc] аналогун камсыз кылат.
///
/// Ички өзгөрүлмө мүнөздөгү бардык типтер [`cell::UnsafeCell`][unsafecell] оромун value(s) тегерегинде колдонушу керек, ал жалпы маалымдама аркылуу мутацияланат.
/// Муну жасай албай калуу-[undefined behavior][ub].
/// Мисалы, [`transmute`][transmute]-ing `&T` ден `&mut T` ге чейин жараксыз.
///
/// `Sync` жөнүндө көбүрөөк маалымат алуу үчүн [the Nomicon][nomicon-send-and-sync] караңыз.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): бир жолу бетага `rustc_on_unimplemented` жерлерине ноталарды кошууга колдоо көрсөтүлсө жана жабуу талап чынжырчасынын каалаган жеринде экендигин текшерүү үчүн кеңейтилген болсо, аны (#48534) катары кеңейтүү керек:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Нөл өлчөмү, "act like" `T` ээси болгон нерселерди белгилөө үчүн колдонулат.
///
/// Сиздин түрүңүзгө `PhantomData<T>` талаасын кошсоңуз, анда компиляторго сиздин түрүңүз `T` тибиндеги маанини сактагандай иш-аракет кылат, ал чындыгында жок болсо дагы.
/// Бул маалымат айрым коопсуздук касиеттерин эсептөөдө колдонулат.
///
/// `PhantomData<T>` ти кантип колдонуу керектиги жөнүндө тереңирээк түшүндүрмө алуу үчүн [the Nomicon](../../nomicon/phantom-data.html) ти караңыз.
///
/// # Үрөй учурган эскертүү 👻👻👻
///
/// Экөөнүн тең үрөй учурган аттары болсо да, `PhantomData` жана "элес түрлөрү" бири-бирине байланыштуу, бирок бирдей эмес.Элес түрүндөгү параметр-бул жөн гана эч качан колдонулбаган типтеги параметр.
/// Rust де, бул көбүнчө компилятордун нааразычылыгын жаратат жана анын чечими-`PhantomData` жолу менен "dummy" колдонууну кошуу.
///
/// # Examples
///
/// ## Колдонулбаган өмүр бою параметрлер
///
/// Балким, `PhantomData` үчүн эң көп колдонулган учур, адатта, кээ бир кооптуу коддордун бир бөлүгү катары колдонулбаган өмүр бою параметрге ээ болгон структура болушу мүмкүн.
/// Мисалы, бул жерде `*const T` тибиндеги эки көрсөткүчү бар `Slice` структурасы, болжолдуу бир жерде массивге багытталган:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Негизги маалыматтар `'a` өмүр бою гана жарактуу, ошондуктан `Slice` `'a` ден ашпашы керек.
/// Бирок, бул ниет коддо көрсөтүлбөйт, анткени `'a` өмүр бою колдонулбайт жана андыктан ал кайсы маалыматтарга тиешелүү экени белгисиз.
/// Биз муну компиляторго `Slice` структурасында `&'a T` шилтемесин камтыган * сыяктуу иш-аракет кылышыбыз керек:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Бул өз кезегинде `T` аннотациясын талап кылат, бул `T` теги ар кандай шилтемелер `'a` өмүр бою жарактуу экендигин көрсөтөт.
///
/// `Slice` инициализациясын жүргүзүүдө сиз `phantom` талаасы үчүн `PhantomData` маанисин бересиз:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Колдонулбаган типтин параметрлери
///
/// Айрым учурларда, сизде структуранын кайсы түрү "tied" экендигин көрсөткөн колдонулбаган типтеги параметрлер бар, бирок ал түзүмдүн өзүндө табылбаса дагы.
/// Бул [FFI] менен пайда болгон бир мисал.
/// Чет элдик интерфейс ар кандай типтеги Rust маанисине кайрылуу үчүн `*mut ()` тибиндеги туткаларды колдонот.
/// Биз тутканы ороп турган `ExternalResource` структурасында элес түрү параметрин колдонуп Rust түрүнө көз салабыз.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Менчик укугу жана тамчы текшерүү
///
/// `PhantomData<T>` тибиндеги талааны кошуу сиздин тип `T` тибиндеги маалыматтарга ээ экендигин көрсөтөт.Бул өз кезегинде, сиздин типти түшүргөндө, ал `T` тибиндеги бир же бир нече мисалдарды түшүрүшү мүмкүн экендигин билдирет.
/// Бул Rust компиляторунун [drop check] анализине байланыштуу.
///
/// Эгерде сиздин структура `T` типтеги маалыматтарга *ээлик кылбаса, анда менчик укугун көрсөтпөө үчүн `PhantomData<&'a T>` (ideally) же `PhantomData<* const T>` сыяктуу (эгер өмүр бою колдонулбаса) шилтеме түрүн колдонгон оң.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Enum дискриминантынын түрүн көрсөтүү үчүн колдонулган компилятор-ички trait.
///
/// Бул trait автоматтык түрдө ар бир түрү үчүн ишке ашырылат жана [`mem::Discriminant`] эч кандай кепилдиктерди кошпойт.
/// `DiscriminantKind::Discriminant` жана `mem::Discriminant` ортосунда которуу **аныкталбаган жүрүм-турум**.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// `mem::Discriminant` талап кылган trait bounds канааттандырышы керек болгон дискриминанттын түрү.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Компилятордун ички trait түрү кандайдыр бир `UnsafeCell` ичине киргенин аныктоо үчүн колдонулат, бирок кыйыр эмес.
///
/// Бул, мисалы, мындай типтеги `static` окууга гана арналган статикалык эс тутумга же жазылуучу статикалык эс тутумга жайгаштырылышына таасир этет.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Тигилгенден кийин коопсуз жылдырыла турган түрлөрү.
///
/// Rust өзү кыймылсыз түрлөрү жөнүндө түшүнүккө ээ эмес жана кыймылдарды (мисалы, тапшырма же [`mem::replace`] аркылуу) ар дайым коопсуз деп эсептейт.
///
/// Анын ордуна [`Pin`][Pin] түрү түр тутуму аркылуу жылып кетпеши үчүн колдонулат.[`Pin<P<T>>`][Pin] оромосуна оролгон `P<T>` көрсөткүчтөрүн жылдырууга болбойт.
/// Пининг жөнүндө көбүрөөк маалымат алуу үчүн [`pin` module] документтерин караңыз.
///
/// `T` үчүн `Unpin` trait ди ишке ашыруу, X0XXти [`Pin<P<T>>`][Pin] тен [`mem::replace`] сыяктуу функциялар менен `T` ти жылдырууга мүмкүндүк берген типти бекитүү чектөөлөрүн алып салат.
///
///
/// `Unpin` бекитилген эмес маалыматтар үчүн эч кандай натыйжа жок.
/// Атап айтканда, [`mem::replace`] кубаныч менен `!Unpin` маалыматтарын жылдырат (ал `T: Unpin` болгондо гана эмес, каалаган `&mut T` үчүн иштейт).
/// Бирок, [`mem::replace`] ти [`Pin<P<T>>`][Pin] ичине оролгон маалыматтарга колдоно албайсыз, анткени `&mut T` үчүн керектүү нерселерди ала албайсыз жана *ушул* бул тутумдун иштешин шарттайт.
///
/// Ошентип, бул, мисалы, `Unpin` жүзөгө ашырган түрлөрү боюнча гана жасалышы мүмкүн:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // `mem::replace` номерине чалуу үчүн бизге өзгөрүлмө шилтеме керек.
/// // Мындай шилтемени (implicitly) аркылуу `Pin::deref_mut` аркылуу алсак болот, бирок `String` `Unpin` ти ишке ашыргандыктан гана мүмкүн болот.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Бул trait автоматтык түрдө дээрлик бардык түрлөрү үчүн ишке ашырылат.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// `Unpin` колдонбогон маркердин түрү.
///
/// Эгерде бир түрүндө `PhantomPinned` болсо, анда ал `Unpin` ни демейки шартта ишке ашырбайт.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Баштапкы түрлөрү үчүн `Copy` ишке ашыруу.
///
/// Rust де сүрөттөлбөй турган иш-чаралар `traits::SelectionContext::copy_clone_conditions()` те `rustc_trait_selection` те жүзөгө ашырылат.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Жалпы шилтемелерди көчүрүүгө болот, бирок өзгөрүлмө шилтемелер *мүмкүн эмес*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}