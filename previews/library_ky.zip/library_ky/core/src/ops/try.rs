/// `?` операторунун жүрүм-турумун өзгөчөлөштүрүү үчүн trait.
///
/// `Try` ти жүзөгө ашыруучу тип, аны success/failure дихотомиясы боюнча кароонун канондук ыкмасы бар.
/// Бул trait ийгиликтүү же ийгиликсиз маанилерди учурдагы нускадан чыгарууга жана ийгилик же ийгиликсиздиктен жаңы инстанцияны жаратууга мүмкүнчүлүк берет.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Ийгиликке жеткенде, бул маанинин түрү.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Ийгиликсиз деп эсептелгенде, бул маанинин түрү.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// "?" операторун колдонот.`Ok(t)` кайтып келиши, анын аткарылышы кадимкидей улана бериши керек дегенди билдирет, ал эми `?` жыйынтыгы `t` маанисин түзөт.
    /// `Err(e)` кайтып келиши, аткаруу branch ди `catch` ички аймагына алып барышы керек же функциясынан кайтып келиши керек дегенди билдирет.
    ///
    /// Эгерде `Err(e)` натыйжасы кайтарылса, анда `e` мааниси тиркелген алкактын кайтаруу түрүндө "wrapped" болот (ал өзү `Try` ишке ашырышы керек).
    ///
    /// Тактап айтканда, `X::from_error(From::from(e))` мааниси кайтарылып берилет, мында `X`-бул курчап турган функциянын кайтарым түрү.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Курамдык натыйжаны куруу үчүн ката маанисин ороп коюңуз.
    /// Мисалы, `Result::Err(x)` жана `Result::from_error(x)` барабар.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Курамдуу натыйжаны куруу үчүн OK маанисин ороп коюңуз.
    /// Мисалы, `Result::Ok(x)` жана `Result::from_ok(x)` барабар.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}