//! Ашыкча жүктөлгөн операторлор.
//!
//! Ушул traits ди ишке ашыруу айрым операторлорго ашыкча жүк жүктөөгө мүмкүндүк берет.
//!
//! Бул traits айрымдары prelude тарабынан импорттолгон, ошондуктан алар ар бир Rust программасында бар.traits колдогон операторлор гана ашыкча жүктөлүшү мүмкүн.
//! Мисалы, (`+`) кошуу оператору [`Add`] trait аркылуу ашыкча жүктөлүшү мүмкүн, бирок (`=`) дайындоо операторунун trait колдоосу жок болгондуктан, анын семантикасын ашыкча жүктөөнүн жолу жок.
//! Андан тышкары, бул модулда жаңы операторлорду түзүү механизмдери каралган эмес.
//! Ашыкча жүктөө же ыңгайлаштырылган операторлор талап кылынса, Rust синтаксисин кеңейтүү үчүн макростарды же компилятор плагиндерин карашыңыз керек.
//!
//! traits операторун ишке ашыруу алардын контексттеринде таң калыштуу болбошу керек, алардын кадимки маанилерин жана [operator precedence] маанисин эске алуу керек.
//! Мисалы, [`Mul`] ти ишке ашырууда, операциянын көбөйтүүгө окшоштугу болушу керек (жана ассоциативдик сыяктуу күтүлгөн касиеттери менен бөлүшүү).
//!
//! `&&` жана `||` операторлорунун кыска туташуусун, башкача айтканда, алар экинчи операндын натыйжага өбөлгө түзгөн учурда гана баалаарын эске алыңыз.Бул жүрүм-турум traits тарабынан аткарылбагандыктан, `&&` жана `||` ашыкча жүктөлгөн операторлор катары колдоого алынбайт.
//!
//! Операторлордун көпчүлүгү операнддарын мааниси боюнча кабыл алышат.Орнотулган түрлөрдү камтыган жалпы эмес контекстте, бул, адатта, көйгөй эмес.
//! Бирок, бул операторлорду жалпы коддо колдонуп, операторлордун аларды колдонушуна жол бербей, тескерисинче, баалуулуктарды кайрадан колдонуу керек болсо, бир аз көңүл бурууну талап кылат.Варианттардын бири-анда-санда [`clone`] колдонуу.
//! Дагы бир вариант-бул шилтемелер үчүн оператордун кошумча аткарылышын камсыз кылган типтерге таянуу.
//! Мисалы, колдонуучуну аныктаган `T` типтеги толуктоону колдоого алган `T` жана `&T` экөө тең traits [`Add<T>`][`Add`] жана [`Add<&T>`][`Add`] программаларын ишке ашырып, жалпы кодду керексиз клондоштурбай жазууга болот.
//!
//!
//! # Examples
//!
//! Бул мисал [`Add`] жана [`Sub`] ишке ашыруучу `Point` структурасын түзүп, андан кийин эки `Point`s кошууну жана чыгарууну көрсөтөт.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Мисал жүзөгө ашыруу үчүн ар бир trait үчүн документтерди караңыз.
//!
//! [`Fn`], [`FnMut`] жана [`FnOnce`] traits функциялары сыяктуу иштетиле турган түрлөрү боюнча жүзөгө ашырылат.[`Fn`] `&self`, [`FnMut`] `&mut self` жана [`FnOnce`] `self` талап кыларын эске алыңыз.
//! Алар нускада колдонула турган үч ыкмага туура келет: шилтеме боюнча шилтеме, чакыруу боюнча өзгөрүлмө шилтеме жана чакыруу боюнча маани.
//! Бул traits эң кеңири таралган колдонулушу-бул функцияны же жабууну аргумент катары кабыл алган жогорку деңгээлдеги функциялардын чеги катары иш алып баруу.
//!
//! Параметр катары [`Fn`] алуу:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Параметр катары [`FnMut`] алуу:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Параметр катары [`FnOnce`] алуу:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` анын алынган өзгөрмөлөрүн жалмайт, ошондуктан аны бир нече жолу иштетүүгө болбойт
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // `func()` ти кайра чакыруу аракети `func` үчүн `use of moved value` катасын ыргытып жиберет
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` мындан ары ушул учурда чакыруу мүмкүн эмес
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;