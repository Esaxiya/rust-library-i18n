/// Чалуу операторунун өзгөрүлбөс кабылдагычты кабыл алган версиясы.
///
/// `Fn` инстанцияларын мутация абалы жок кайталап аташса болот.
///
/// *Бул trait (`Fn`) менен [function pointers] (`fn`) ти чаташтырууга болбойт.*
///
/// `Fn` автоматтык түрдө ишке ашырылат, алар алынган өзгөрмөлөргө өзгөрүлбөс шилтемелерди гана алышат же эч нерсени камтышпайт, ошондой эле (safe) [function pointers] (айрым эскертүүлөр менен, алардын документтерин кененирээк билүү үчүн).
///
/// Андан тышкары, `Fn` ти жүзөгө ашырган `F` түрү үчүн `&F` да `Fn` ти ишке ашырат.
///
/// [`FnMut`] жана [`FnOnce`] экөө тең `Fn` супертрайттары болгондуктан, `Fn` тин ар кандай инстанциясы [`FnMut`] же [`FnOnce`] күтүлүп жаткан параметр катары колдонулушу мүмкүн.
///
/// Функцияга окшош типтин параметрин кабыл алгыңыз келгенде, аны кайта-кайта жана мутациясыз абалда чалуу керек болгондо (мисалы, аны бир мезгилде чакырганда) `Fn` ти чектелген катары колдонуңуз.
/// Эгер сизге мындай катуу талаптардын кереги жок болсо, анда [`FnMut`] же [`FnOnce`] чек араларын колдонуңуз.
///
/// Бул тема боюнча көбүрөөк маалымат алуу үчүн [chapter on closures in *The Rust Programming Language*][book] караңыз.
///
/// Ошондой эле `Fn` traits үчүн атайын синтаксис (мис
/// `Fn(usize, bool) -> usize`).Мунун техникалык деталдарына кызыккандар [the relevant section in the *Rustonomicon*][nomicon] ке кайрылышса болот.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Жабуу деп атоодо
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` параметрин колдонуу
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // Ошентип regex ошол `&str: !FnMut` ке ишене алат
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Чалуу операциясын жүргүзөт.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Өзгөрүлө турган кабыл алгычты кабыл алуучу оператордун версиясы.
///
/// `FnMut` үлгүлөрүн кайталап аташса болот жана абалынын мутациясы болушу мүмкүн.
///
/// `FnMut` тутуму өзгөрүлмө шилтемелерди, ошондой эле [`Fn`] жүзөгө ашырган бардык түрлөрүн, мисалы, (safe) [function pointers] (`FnMut` [`Fn`] супертрейти болгондуктан) өзгөрүлмө шилтемелерди алган жабуулар менен автоматтык түрдө ишке ашырылат.
/// Андан тышкары, `FnMut` ти жүзөгө ашырган `F` түрү үчүн `&mut F` да `FnMut` ти ишке ашырат.
///
/// [`FnOnce`] `FnMut` супертрейти болгондуктан, `FnMut` тин каалаган нускасын [`FnOnce`] күтүлгөн жерде колдонсо болот, ал эми [`Fn`] `FnMut` субтрейти болгондуктан, [`Fn`] тин каалаган нускасын `FnMut` күтүлгөн жерде колдонсо болот.
///
/// Функцияга окшош типтин параметрин кабыл алгыңыз келгенде жана аны мутацияны өзгөртүүгө мүмкүнчүлүк берип, кайра-кайра чалуу керек болгондо, `FnMut` ти чек катары колдонуңуз.
/// Эгер сиз параметрдин абалынын өзгөрүшүн каалабасаңыз, анда [`Fn`] абалын чектөө катарында колдонуңуз;эгер сизге бир нече жолу чалуунун кажети жок болсо, [`FnOnce`] колдонуңуз.
///
/// Бул тема боюнча көбүрөөк маалымат алуу үчүн [chapter on closures in *The Rust Programming Language*][book] караңыз.
///
/// Ошондой эле `Fn` traits үчүн атайын синтаксис (мис
/// `Fn(usize, bool) -> usize`).Мунун техникалык деталдарына кызыккандар [the relevant section in the *Rustonomicon*][nomicon] ке кайрылышса болот.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Өзгөрүлмө басып алууну жабуу деп атоо
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` параметрин колдонуу
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // Ошентип regex ошол `&str: !FnMut` ке ишене алат
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Чалуу операциясын жүргүзөт.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Чалуу операторунун кошумча кабыл алгычты кабыл алган версиясы.
///
/// `FnOnce` учурларын чакырууга болот, бирок бир нече жолу чалуу мүмкүн эмес.Ушундан улам, бир гана түрү `FnOnce` ти ишке ашыргандыгы белгилүү болсо, аны бир жолу гана атоого болот.
///
/// `FnOnce` тутуму өзгөрүлмө кубулуштарды колдонушу мүмкүн болгон жабуулар, ошондой эле [`FnMut`] ти жүзөгө ашырган бардык типтер, мисалы, (safe) [function pointers] (`FnOnce`-[`FnMut`] супертрейти болгондуктан) тарабынан автоматтык түрдө ишке ашырылат.
///
///
/// [`Fn`] жана [`FnMut`] экөө тең `FnOnce` субтреттери болгондуктан, [`Fn`] же [`FnMut`] бардык инстанцияларын `FnOnce` күтүлгөн жерде колдонсо болот.
///
/// Функцияга окшош типтин параметрин кабыл алгыңыз келгенде жана аны бир эле жолу чалуу керек болгондо, `FnOnce` ти чектелген катары колдонуңуз.
/// Эгер сиз параметрди бир нече жолу чакырышыңыз керек болсо, анда [`FnMut`] байланыштырылган катары колдонуңуз;эгер сизге абалдын мутациясы болбошу керек болсо, [`Fn`] колдонуңуз.
///
/// Бул тема боюнча көбүрөөк маалымат алуу үчүн [chapter on closures in *The Rust Programming Language*][book] караңыз.
///
/// Ошондой эле `Fn` traits үчүн атайын синтаксис (мис
/// `Fn(usize, bool) -> usize`).Мунун техникалык деталдарына кызыккандар [the relevant section in the *Rustonomicon*][nomicon] ке кайрылышса болот.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` параметрин колдонуу
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` анын алынган өзгөрмөлөрүн жалмайт, ошондуктан аны бир нече жолу иштетүүгө болбойт.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // `func()` ти кайра чакыруу аракети `func` үчүн `use of moved value` катасын ыргытып жиберет.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` мындан ары ушул учурда чакыруу мүмкүн эмес
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // Ошентип regex ошол `&str: !FnMut` ке ишене алат
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Чакыруу оператору колдонулгандан кийин кайтарылган түрү.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Чалуу операциясын жүргүзөт.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}