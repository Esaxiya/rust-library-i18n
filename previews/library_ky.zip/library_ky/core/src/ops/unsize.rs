use crate::marker::Unsize;

/// Trait, бул көрсөткүч же оролуучу пакет экендигин, анда пуинтте көлөмсүздүктү жасоого болот.
///
/// Көбүрөөк маалымат алуу үчүн [DST coercion RFC][dst-coerce] жана [the nomicon entry on coercion][nomicon-coerce] караңыз.
///
/// Орнотулган көрсөткүч түрлөрү үчүн `T` көрсөткүчтөрү `U` көрсөткүчтөрүн мажбурласа, эгер `T: Unsize<U>` жука көрсөткүчтөн май көрсөткүчүнө айланса.
///
/// Ыңгайлаштырылган түрлөрү үчүн, мажбурлоо `Foo<T>` тен `Foo<U>` ге мажбурлоо менен иштейт, эгерде `CoerceUnsized<Foo<U>> for Foo<T>` имплеваты бар болсо.
/// Эгерде `Foo<T>` де `T` катышкан фантомдаттык эмес бир гана талаа бар болсо, мындай маанини жазууга болот.
/// Эгер бул талаанын түрү `Bar<T>` болсо, анда `CoerceUnsized<Bar<U>> for Bar<T>` программасы болушу керек.
/// Мажбурлоо `Bar<T>` талаасын `Bar<U>` ге мажбурлоо жана `Foo<T>` тен калган талааларды `Foo<U>` түзүү үчүн толтуруу аркылуу иштейт.
/// Бул көрсөткүч талаасында натыйжалуу бурулуп, аны мажбурлайт.
///
/// Адатта, акылдуу көрсөткүчтөр үчүн сиз `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` ти ишке ашырасыз, ал эми `T` өзү менен байланышкан кошумча `?Sized`.
/// `T` жана `RefCell<T>` сыяктуу `T` түздөн-түз камтыган ором түрлөрү үчүн `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` ти түздөн-түз ишке ашыра аласыз.
///
/// Бул `Cell<Box<T>>` сыяктуу түрлөрдүн мажбурлоосу иштей берет.
///
/// [`Unsize`][unsize] көрсөткүчтөрдүн артында болсо, DSTге мажбурланышы мүмкүн болгон түрлөрүн белгилөө үчүн колдонулат.Ал автоматтык түрдө компилятор тарабынан ишке ашырылат.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut Т-> * мут У.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Бул ыкманын кабыл алгыч түрүнүн жөнөтүлүшүн текшерүү үчүн объект коопсуздугу үчүн колдонулат.
///
/// trait мисалын ишке ашыруу:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}