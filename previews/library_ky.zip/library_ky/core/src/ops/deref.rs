/// `*v` сыяктуу өзгөрүлбөс диференция операциялары үчүн колдонулат.
///
/// Х01X `*` оператору менен өзгөрүлбөс контекстте ачык-айкын тергөө амалдары үчүн колдонуудан тышкары, `Deref` көптөгөн шарттарда компилятор тарабынан жашыруун колдонулат.
/// Бул механизм ['`Deref` coercion'][more] деп аталат.
/// Өзгөрүлүүчү контекстте [`DerefMut`] колдонулат.
///
/// Акылдуу көрсөткүчтөр үчүн `Deref` программасын колдонуу алардын артындагы маалыматтарга жеткиликтүүлүктү жеңилдетет, ошондуктан алар `Deref` ти колдонушат.
/// Башка жагынан алганда, `Deref` жана [`DerefMut`] эрежелери акылдуу көрсөткүчтөрдү жайгаштыруу үчүн атайын иштелип чыккан.
/// Ушундан улам,**`Deref` чаташтырбоо үчүн акылдуу көрсөткүчтөр үчүн гана** ишке ашырылышы керек.
///
/// Ушундай эле себептерден улам **бул trait эч качан бузулбашы керек**.`Deref` түздөн-түз чакырылганда, ажыратуу учурунда ката кетирүү өтө түшүнүксүз болушу мүмкүн.
///
/// # `Deref` мажбурлоо жөнүндө көбүрөөк маалымат
///
/// Эгерде `T` `Deref<Target = U>` ти ишке ашырса, ал эми `x` бул `T` тибиндеги мааниге ээ болсо, анда:
///
/// * Өзгөрүлбөс контекстте `*x` (бул жерде `T` шилтеме да, чийки көрсөткүч да эмес) `* Deref::deref(&x)` ге барабар.
/// * `&T` түрүндөгү маанилер `&U` түрүндөгү маанилерге мажбурланат
/// * `T` `U` тибиндеги бардык (immutable) ыкмаларын жашыруун жүзөгө ашырат.
///
/// Көбүрөөк маалымат алуу үчүн, [the chapter in *The Rust Programming Language*][book], ошондой эле [the dereference operator][ref-deref-op], [method resolution] жана [type coercions] шилтемелер бөлүмдөрүнө баш багыңыз.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Структураны ажыратуу менен жеткиликтүү болгон бир талаа бар структура.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Кийинчерээк аныктоодон кийин пайда болгон түр.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Мааниси жок.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// `*v = 1;` сыяктуу өзгөрүлмө өзгөрүү операциялары үчүн колдонулат.
///
/// Х01X `*` оператору менен өзгөрүлмө шарттарда ачык-айкын тергөө амалдары үчүн колдонуудан тышкары, `DerefMut` көптөгөн шарттарда компилятор тарабынан да жашыруун колдонулат.
/// Бул механизм ['`Deref` coercion'][more] деп аталат.
/// Өзгөрүлбөс контекстте [`Deref`] колдонулат.
///
/// Акылдуу көрсөткүчтөр үчүн `DerefMut` киргизүү, алардын артындагы маалыматтардын мутациясын ыңгайлуу кылат, ошондуктан алар `DerefMut` ти колдонушат.
/// Башка жагынан алганда, [`Deref`] жана `DerefMut` эрежелери акылдуу көрсөткүчтөрдү жайгаштыруу үчүн атайын иштелип чыккан.
/// Ушундан улам,**`DerefMut` чаташпаш үчүн акылдуу көрсөткүчтөр** үчүн гана колдонулушу керек.
///
/// Ушундай эле себептерден улам **бул trait эч качан бузулбашы керек**.`DerefMut` түздөн-түз чакырылганда, ажыратуу учурунда ката кетирүү өтө түшүнүксүз болушу мүмкүн.
///
/// # `Deref` мажбурлоо жөнүндө көбүрөөк маалымат
///
/// Эгерде `T` `DerefMut<Target = U>` ти ишке ашырса, ал эми `x` бул `T` тибиндеги мааниге ээ болсо, анда:
///
/// * Өзгөрүлүүчү контекстте `*x` (бул жерде `T` шилтеме да, чийки көрсөткүч да эмес) `* DerefMut::deref_mut(&mut x)` ге барабар.
/// * `&mut T` түрүндөгү маанилер `&mut U` түрүндөгү маанилерге мажбурланат
/// * `T` `U` тибиндеги бардык (mutable) ыкмаларын жашыруун жүзөгө ашырат.
///
/// Көбүрөөк маалымат алуу үчүн, [the chapter in *The Rust Programming Language*][book], ошондой эле [the dereference operator][ref-deref-op], [method resolution] жана [type coercions] шилтемелер бөлүмдөрүнө баш багыңыз.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Структураны ажыратуу менен өзгөрүлө турган бир талаа бар структура.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Өзгөртүлгөн маанини жокко чыгарат.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// `arbitrary_self_types` өзгөчөлүгү жок структураны ыкма кабыл алгычы катары колдонсо болоорун көрсөтөт.
///
/// Бул stdlib көрсөткүчтөрү `Box<T>`, `Rc<T>`, `&T` жана `Pin<P>` сыяктуу жүзөгө ашырылат.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}