//! Буйрутма берүү жана салыштыруу үчүн функционалдуулук.
//!
//! Бул модуль баалуулуктарды иреттөө жана салыштыруу үчүн ар кандай шаймандарды камтыйт.Жыйынтыктап айтканда:
//!
//! * [`Eq`] жана [`PartialEq`]-бул traits, тиешелүүлүгүнө жараша баалуулуктардын ортосундагы толук жана жарым-жартылай теңчиликти аныктоого мүмкүндүк берет.
//! Аларды жүзөгө ашыруу `==` жана `!=` операторлорун ашыкча жүктөйт.
//! * [`Ord`] жана [`PartialOrd`]-бул traits, тиешелүүлүгүнө жараша баалуулуктардын ортосундагы толук жана жарым-жартылай заказдарды аныктоого мүмкүндүк берет.
//!
//! Аларды жүзөгө ашырууда `<`, `<=`, `>` жана `>=` операторлоруна ашыкча жүк түшөт.
//! * [`Ordering`] [`Ord`] жана [`PartialOrd`] негизги функциялары менен кайтарылган enum болуп саналат жана буйрутманы сүрөттөйт.
//! * [`Reverse`] буйрукту оңой эле артка кайтарууга мүмкүндүк берген түзүм.
//! * [`max`] жана [`min`]-бул [`Ord`] тен курулган жана эки чоңдуктун максимумун же минимумун табууга мүмкүндүк берген функциялар.
//!
//! Көбүрөөк маалымат алуу үчүн, тизмедеги ар бир нерсенин тиешелүү документтерин караңыз.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) болгон теңдикти салыштыруу үчүн Trait.
///
/// Бул trait толук эквиваленттик байланышы жок типтер үчүн жарым-жартылай теңчиликке мүмкүндүк берет.
/// Мисалы, өзгөрүлмө чекит сандарында `NaN != NaN`, өзгөрүлмө чекит түрлөрү `PartialEq` ишке ашырат, бирок [`trait@Eq`] эмес.
///
/// Формалдуу түрдө, теңдик болушу керек (бардык `a`, `b`, `c` типтеги `A`, `B`, `C` үчүн):
///
/// - **Симметриялык**: эгер `A: PartialEq<B>` жана `B: PartialEq<A>` болсо, анда **`a==b`` b==a`** билдирет;жана
///
/// - **Өткөөл**: эгер `A: PartialEq<B>` жана `B: PartialEq<C>` жана `A:
///   PartialEq<C>`, анда **` a==b`жана `b == c` a==c`** билдирет.
///
/// `B: PartialEq<A>` (symmetric) жана `A: PartialEq<C>` (transitive) имплимдери аргасыздан бар экендигин эске алыңыз, бирок бул талаптар алар бар болгондо колдонулат.
///
/// ## Derivable
///
/// Бул trait `#[derive]` менен колдонсо болот.Эгерде структуралар боюнча 'derive`болгондо, бардык талаалар бирдей болсо, эки мисал бирдей болот, эгер кандайдыр бир талаалар бирдей болбосо, анда бирдей болбойт.Enum'де`чыгарганда`, ар бир вариант өзүнө тең, ал эми башка варианттарга барабар эмес.
///
/// ## `PartialEq` ти кантип ишке ашырсам болот?
///
/// `PartialEq` гана [`eq`] ыкмасын ишке ашырууну талап кылат;[`ne`] демейки шартта ага карата аныкталат.[`ne`]*ар кандай кол менен жүзөгө ашырылышы*[`eq`] [`ne`] тин катуу тескери экендиги жөнүндө эрежени сакташы керек;башкача айтканда, эгер `a != b` болсо гана `!(a == b)`.
///
/// `PartialEq`, [`PartialOrd`] жана [`Ord`]*программалары бири-бири менен макулдашылышы керек*.Кээ бир traits чыгарып, башкаларын кол менен жүзөгө ашыруу менен аларды кокустан макул эместигине алып келүү оңой.
///
/// Эки китеп бир эле китеп деп эсептелген домендин мисалы, мисалы ISBN форматтары дал келген болсо дагы:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Кантип эки башка түрүн салыштырсам болот?
///
/// Сиз салыштырып көрө алган түрүңүз "PartialEq" түрүнүн параметрлери менен башкарылат.
/// Мисалы, мурунку кодубузду бир аз оңдойлу:
///
/// ```
/// // Туунду шаймандар<BookFormat>==<BookFormat>салыштыруу
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Ишке ашыруу<Book>==<BookFormat>салыштыруу
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Ишке ашыруу<BookFormat>==<Book>салыштыруу
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// `impl PartialEq for Book` ти `impl PartialEq<BookFormat> for Book` кылып өзгөртүү менен, "BookFormat" менен "Book`s" менен салыштырууга мүмкүнчүлүк беребиз.
///
/// Структуранын айрым талааларын эске албаган жогорудагыдай салыштыруу кооптуу болушу мүмкүн.Бул жарым-жартылай эквиваленттик мамилеге карата талаптарды ойлонбостон бузууга алып келиши мүмкүн.
/// Мисалы, эгер биз `BookFormat` ти `BookFormat` үчүн `BookFormat` ишке ашырууну сактап калсак жана `Book` үчүн `PartialEq<Book>` ишке киргизсек (же `#[derive]` аркылуу же биринчи мисалдан кол менен ишке ашыруу аркылуу), анда жыйынтык транзитивдүүлүктү бузат:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Бул ыкма `self` жана `other` маанилеринин барабар экендигин текшерет жана `==` тарабынан колдонулат.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Бул ыкма `!=` үчүн сыноолорду өткөрөт.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// trait `PartialEq` имплинин түзүүчү макроэлектроника.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) болгон теңдикти салыштыруу үчүн Trait.
///
/// Демек, `a == b` жана `a != b` катуу тескери болгонунан тышкары, теңдик (бардык `a`, `b` жана `c` үчүн) болушу керек:
///
/// - reflexive: `a == a`;
/// - симметриялуу: `a == b` `b == a` билдирет;жана
/// - өтмө: `a == b` жана `b == c` `a == c` билдирет.
///
/// Бул касиетти компилятор текшере албайт, демек `Eq` [`PartialEq`] дегенди билдирет жана ашыкча ыкмалары жок.
///
/// ## Derivable
///
/// Бул trait `#[derive]` менен колдонсо болот.
/// `Derive`d болгондо, `Eq` те ашыкча ыкмалар жок болгондуктан, бул компиляторго жарым-жартылай эквиваленттик мамиле эмес, эквиваленттик байланыш экендигин гана маалымдайт.
///
/// `derive` стратегиясында бардык талаалар `Eq` талап кылынарын эске алыңыз, бул дайыма эле каалана бербейт.
///
/// ## `Eq` ти кантип ишке ашырсам болот?
///
/// Эгерде сиз `derive` стратегиясын колдоно албасаңыз, анда сиздин түрүңүздө эч кандай ыкмалары жок `Eq` колдонулаарын көрсөтүңүз:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // бул ыкма бир гана түрдүн ар бир компоненти#[туунду] өзүн-өзү жүзөгө ашырат деп ырастоо үчүн#[deriving] тарабынан колдонулат, учурдагы чыгаруучу инфраструктура бул trait методун колдонбостон ушул ырастоону жасоо дээрлик мүмкүн эмес.
    //
    //
    // Бул эч качан кол менен ишке ашырылбашы керек.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// trait `Eq` имплинин түзүүчү макроэлектроника.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: бул структура#[derive] to тарабынан гана колдонулат
// түрдүн ар бир компоненти эквивалентти жүзөгө ашырат деп ырасташат.
//
// Бул структура эч качан колдонуучунун кодунда көрүнбөшү керек.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Ordering`-эки баалуулуктун салыштырылышынын натыйжасы.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Салыштырылган маани экинчисинен төмөн болгон буйрутма.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Салыштырылган маани экинчисине барабар болгон тартип.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Салыштырылган маани экинчисинен чоң болгон буйрутма.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Эгерде буйрутма `Equal` варианты болсо, `true` кайтарып берет.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Эгерде буйрутма `Equal` варианты болбосо, `true` кайтарып берет.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Эгерде буйрутма `Less` варианты болсо, `true` кайтарып берет.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Эгерде буйрутма `Greater` варианты болсо, `true` кайтарып берет.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Эгерде буйрутма `Less` же `Equal` варианты болсо, `true` кайтарып берет.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Эгерде буйрутма `Greater` же `Equal` варианты болсо, `true` кайтарып берет.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// `Ordering` ти кайтарып берет.
    ///
    /// * `Less` `Greater` болуп калат.
    /// * `Greater` `Less` болуп калат.
    /// * `Equal` `Equal` болуп калат.
    ///
    /// # Examples
    ///
    /// Негизги жүрүм-турум:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Бул ыкманы салыштырууну өзгөртүү үчүн колдонсо болот:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // массивди чоңунан кичинесине чейин иреттөө.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Эки буйрутманы чынжыр менен бириктирет.
    ///
    /// `Equal` болбогондо `self` кайтарып берет.Болбосо `other` кайтарып берет.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Берилген функция менен тартипти чынжырчалар.
    ///
    /// `Equal` болбогондо `self` кайтарып берет.
    /// Болбосо `f` чалып, натыйжаны кайтарып берет.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Тескери буйрутма берүүчү жардамчы структура.
///
/// Бул структура [`Vec::sort_by_key`] сыяктуу функцияларда колдонулуучу жардамчы болуп саналат жана ачкычтын бир бөлүгүн тескөө үчүн колдонсо болот.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// [total order](https://en.wikipedia.org/wiki/Total_order) түзүүчү типтер үчүн Trait.
///
/// Буйрутма жалпы буйрук болуп саналат, эгерде (бардык `a`, `b` жана `c` үчүн):
///
/// - жалпы жана асимметриялык: `a < b`, `a == b` же `a > b` тин бири туура;жана
/// - өткөөл, `a < b` жана `b < c` `a < c` билдирет.Ошол эле `==` жана `>` үчүн да болушу керек.
///
/// ## Derivable
///
/// Бул trait `#[derive]` менен колдонсо болот.
/// Структуралар боюнча "чыгарганда", ал структуранын мүчөлөрүнүн жогортон төмөн декларациялоо тартибинин негизинде [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) буйрутмасын чыгарат.
///
/// Энумдардан "чыгарганда", варианттар алардын жогорудан төмөн дискриминанттуу тартиби боюнча иреттелет.
///
/// ## Лексикографиялык салыштыруу
///
/// Лексикографиялык салыштыруу бул төмөнкү касиеттерге ээ операция:
///  - Эки ырааттуулук элемент менен салыштырылат.
///  - Биринчи шайкеш келбеген элемент лексикографиялык жактан кайсы тизменин экинчисинен аз же чоң экендигин аныктайт.
///  - Эгерде бир ырааттуулук экинчи префикс болсо, анда кыска тизмек лексикографиялык жактан экинчисине караганда азыраак болот.
///  - Эгерде эки ырааттуулуктун эквиваленттүү элементтери бар жана алардын узундугу бирдей болсо, анда тизмектер лексикографиялык жактан бирдей болот.
///  - Бош ырааттуулук лексикографиялык жактан бош эмес ырааттуулукка караганда азыраак.
///  - Эки бош тизмек лексикографиялык жактан бирдей.
///
/// ## `Ord` ти кантип ишке ашырсам болот?
///
/// `Ord` түрү [`PartialOrd`] жана [`Eq`] болушун талап кылат (бул [`PartialEq`] талап кылат).
///
/// Андан кийин [`cmp`] үчүн ишке ашырууну аныкташыңыз керек.Сиздин түрүңүздүн талааларында [`cmp`] колдонуу пайдалуу болушу мүмкүн.
///
/// [`PartialEq`], [`PartialOrd`] жана `Ord`*программалары бири-бири менен макулдашылышы керек*.
/// Башкача айтканда, бардык `a` жана `b` үчүн `a == b` жана `a == b` жана `Some(a.cmp(b)) == a.partial_cmp(b)` болсо гана.
/// Кээ бир traits чыгарып, башкаларын кол менен жүзөгө ашыруу менен аларды кокустан макул эместигине алып келүү оңой.
///
/// `id` жана `name` эске албай, адамдарды бою боюнча гана иргеп алгыңыз келген мисал:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Бул ыкма `self` менен `other` ортосунда [`Ordering`] берет.
    ///
    /// Шарт боюнча, `self.cmp(&other)` буйрукту `self <operator> other` сөзүнө туура келсе, `self <operator> other` сөзүнө туура келет.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Эки чоңдукту салыштырат жана кайтарат.
    ///
    /// Эгерде салыштыруу алардын барабар экендигин аныктаса, экинчи аргументти кайтарып берет.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Эки чоңдуктун минимумун салыштырат жана кайтарат.
    ///
    /// Эгерде салыштыруу алардын барабар экендигин аныктаса, биринчи аргументти кайтарып берет.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Белгилүү бир аралык менен чектөө.
    ///
    /// `self` `max` тен чоңураак болсо `max`, `self` `min` тен кичине болсо `min` берет.
    /// Болбосо, бул `self` кайтарып берет.
    ///
    /// # Panics
    ///
    /// Panics, эгер `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// trait `Ord` имплинин түзүүчү макроэлектроника.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait иреттөө үчүн салыштырууга боло турган маанилер үчүн.
///
/// Салыштыруу бардык `a`, `b` жана `c` үчүн канааттандырышы керек:
///
/// - ассиметрия: эгер `a < b` анда `!(a > b)`, ошондой эле `a > b` `!(a < b)` дегенди билдирет;жана
/// - өтмө: `a < b` жана `b < c` `a < c` билдирет.Ошол эле `==` жана `>` үчүн да болушу керек.
///
/// Бул талаптар trait симметриялуу жана транзиттик түрдө жүзөгө ашырылышы керектигин билдирет: эгер `T: PartialOrd<U>` жана `U: PartialOrd<V>` анда `U: PartialOrd<T>` жана `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Бул trait `#[derive]` менен колдонсо болот.Структуралар боюнча "чыгарганда", ал структуранын мүчөлөрүнүн жогортон төмөн декларациялоо тартибинин негизинде лексикографиялык иретке келтирет.
/// Энумдардан "чыгарганда", варианттар алардын жогорудан төмөн дискриминанттуу тартиби боюнча иреттелет.
///
/// ## `PartialOrd` ти кантип ишке ашырсам болот?
///
/// `PartialOrd` гана [`partial_cmp`] ыкмасын ишке ашырууну талап кылат, калгандары демейки аткаруулардан жаралат.
///
/// Бирок жалпы заказы жок түрлөрү боюнча башкаларын өзүнчө ишке ашыруу мүмкүн бойдон калууда.
/// Мисалы, өзгөрүлмө чекит сандары үчүн `NaN < 0 == false` жана `NaN >= 0 == false` (караңыз.
/// IEEE 754-2008 бөлүмү 5.11).
///
/// `PartialOrd` сиздин түрүңүз [`PartialEq`] болушун талап кылат.
///
/// [`PartialEq`], `PartialOrd` жана [`Ord`]*программалары бири-бири менен макулдашылышы керек*.
/// Кээ бир traits чыгарып, башкаларын кол менен жүзөгө ашыруу менен аларды кокустан макул эместигине алып келүү оңой.
///
/// Эгерде сиздин түрүңүз [`Ord`] болсо, анда [`cmp`] аркылуу [`partial_cmp`] ти ишке ашыра аласыз:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Ошондой эле, [`partial_cmp`] ти сиздин түрүңүздүн талааларында колдонуу пайдалуу болушу мүмкүн.
/// Сорттоо үчүн колдонула турган бирден-бир талаа болгон калкып чыккан `height` талаасы бар `Person` типтеринин мисалы:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Бул ыкма бар болсо, `self` жана `other` маанилери ортосунда буйрутманы кайтарып берет.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Салыштыруу мүмкүн эмес болгондо:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Бул ыкма (`self` жана `other` үчүн) караганда азыраак сынайт жана `<` оператору колдонот.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Бул ыкма (`self` жана `other` үчүн) аз же ага барабар тестирлөө жүргүзөт жана `<=` оператору колдонот.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Бул ыкма (`self` жана `other` үчүн) чоңдугун текшерет жана `>` оператору тарабынан колдонулат.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Бул ыкма (`self` жана `other` үчүн) чоң же барабар тестирлөө жана `>=` оператору тарабынан колдонулат.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// trait `PartialOrd` имплинин түзүүчү макроэлектроника.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Эки чоңдуктун минимумун салыштырат жана кайтарат.
///
/// Эгерде салыштыруу алардын барабар экендигин аныктаса, биринчи аргументти кайтарып берет.
///
/// Ички түрдө [`Ord::min`] үчүн лакап ат колдонулат.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Көрсөтүлгөн салыштыруу функциясына карата эки минимумдун минимумун кайтарат.
///
/// Эгерде салыштыруу алардын барабар экендигин аныктаса, биринчи аргументти кайтарып берет.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Көрсөтүлгөн функциядан минималдуу маанини берген элементти кайтарып берет.
///
/// Эгерде салыштыруу алардын барабар экендигин аныктаса, биринчи аргументти кайтарып берет.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Эки чоңдукту салыштырат жана кайтарат.
///
/// Эгерде салыштыруу алардын барабар экендигин аныктаса, экинчи аргументти кайтарып берет.
///
/// Ички түрдө [`Ord::max`] үчүн лакап ат колдонулат.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Көрсөтүлгөн салыштыруу функциясына карата эки чоңдуктун максимумун кайтарат.
///
/// Эгерде салыштыруу алардын барабар экендигин аныктаса, экинчи аргументти кайтарып берет.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Көрсөтүлгөн функциядан максималдуу маанини берген элементти кайтарып берет.
///
/// Эгерде салыштыруу алардын барабар экендигин аныктаса, экинчи аргументти кайтарып берет.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Примитивдүү типтер үчүн PartialEq, Eq, PartialOrd жана Ordну ишке ашыруу
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Бул жердеги буйрук оптималдуу жыйынды түзүү үчүн маанилүү.
                    // Көбүрөөк маалымат алуу үчүн <https://github.com/rust-lang/rust/issues/63758> караңыз.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // I8'ге куюп, айырманы Буйрутмага айландыруу оптималдуу жыйынды жаратат.
            //
            // Көбүрөөк маалымат алуу үчүн <https://github.com/rust-lang/rust/issues/66780> караңыз.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // КООПСУЗДУК: bool катары i8 0 же 1ди кайтарат, андыктан айырма башка нерсе болушу мүмкүн эмес
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &көрсөткүчтөр

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}