//! Libcore үчүн Panic колдоосу
//!
//! Негизги китепкана паникацияны аныктай албайт, бирок паника *жарыялаган*.
//! Бул libcore ичиндеги функцияларга panic уруксат берилген дегенди билдирет, бирок crate агымында пайдалуу болушу үчүн libcore колдонушу үчүн паникацияны аныкташы керек.
//! Паниканын учурдагы интерфейси:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Бул аныктама кандайдыр бир жалпы билдирүү менен дүрбөлөңгө түшүүгө мүмкүндүк берет, бирок `Box<Any>` маанисинде аткарылбай калат.
//! (`PanicInfo` жөн гана `&(dyn Any + Send)` камтыйт, ал үчүн биз "PanicInfo: : internal_constructor" деген жалган маанини толтурабыз.) Мунун себеби libcore бөлүштүрүүгө тыюу салынган.
//!
//!
//! Бул модуль паникадагы бир нече башка функцияларды камтыйт, бирок бул жөн гана компилятор үчүн керектүү тил элементтери.Бардык panics ушул бир функция аркылуу өткөрүлөт.
//! Чыныгы символ `#[panic_handler]` атрибуту аркылуу жарыяланат.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Эч кандай форматтоо колдонулбаганда, libcore компаниясынын `panic!` макросунун негизи.
#[cold]
// Чакыруу сайттарында мүмкүн болушунча коддун көбөйүп кетпеши үчүн, panic_immediate_abort болбосо, эч качан киргизбеңиз
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // толтуруу жана башка `Assert` MIR терминаторлору үчүн panic үчүн codegen керек
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Кошумча чыгымдарды азайтуу үчүн format_args! ("{}", Expr) ордуна Arguments::new_v1 колдонуңуз.
    // Format_args!макро стрдин Display trait колдонуп expr жазат, ал Formatter::pad чакырат, ал сапты кыскартууга жана толтурууга ылайыкташтырылышы керек (бул жерде эч ким колдонулбайт).
    //
    // Arguments::new_v1 ти колдонуу компиляторго Formatter::pad ти чыгуучу бинардык режимден чыгарып, бир нече килобайтты үнөмдөөгө мүмкүндүк берет.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // const-бааланган panics үчүн керек
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // OOB array/slice жеткиликтүүлүгүндө panic үчүн codegen керек
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Форматташтыруу учурунда libcore компаниясынын `panic!` макросун ишке ашыруу негизи колдонулат.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ЭСКЕРТҮҮ Бул функция эч качан FFI чегинен өтпөйт;бул `#[panic_handler]` функциясы чечилген Rust-Rust чалуусу.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // КООПСУЗДУК: `panic_impl` коопсуз Rust кодунда аныкталган жана ошентип чалууга болот.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` жана `assert_ne!` макросторунун ички функциясы
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}