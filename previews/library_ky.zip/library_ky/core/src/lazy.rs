//! Жалкоо баалуулуктар жана статикалык маалыматтардын бир жолку инициализациясы.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// Бир жолу гана жазыла турган уяча.
///
/// `RefCell` тен айырмаланып, `OnceCell` анын маанисине жалпы `&T` шилтемелерин гана берет.
/// `Cell` тен айырмаланып, `OnceCell` ага жетүү үчүн маанини көчүрүүнү же алмаштырууну талап кылбайт.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Инвариант: эң көп дегенде бир жолу жазылган.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Жаңы бош уячаны түзөт.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Негизги мааниге шилтеме алат.
    ///
    /// Эгерде уяча бош болсо, `None` берет.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // КООПСУЗДУК: "ички" инвариантка байланыштуу коопсуз
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Негизги мааниге өзгөрүлмө шилтеме алат.
    ///
    /// Эгерде уяча бош болсо, `None` берет.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // КООПСУЗДУК: Коопсуз, анткени биздин уникалдуу мүмкүнчүлүгүбүз бар
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Уячанын мазмунун `value` кылып орнотот.
    ///
    /// # Errors
    ///
    /// Бул ыкма уяча бош болсо `Ok(())`, ал эми толгон болсо `Err(value)` берет.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // КООПСУЗДУК: Коопсуз, анткени биз өзгөрүлө турган карыздарды ала албайбыз
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // КООПСУЗДУК: Бул жерде биз эч кандай жарышты орнотпойбуз
        // reentrancy/concurrency болушу мүмкүн, жана биз оюкчанын учурда `None` экендигин текшердик, андыктан бул жазуу "ички" инвариантын сактап турат.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Эгерде уяча бош болсо, аны `f` менен баштап, уячанын мазмунун алат.
    ///
    /// # Panics
    ///
    /// Эгер `f` panics болсо, panic чалган адамга жайылып, клетка инициализацияланбай калат.
    ///
    ///
    /// Клетканы `f` тен баштапкы абалга келтирүү ката.Мындай кылуу panic ге алып келет.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Эгерде уяча бош болсо, аны `f` менен баштап, уячанын мазмунун алат.
    /// Эгерде уяча бош болуп, `f` иштебей калса, ката кайтарылат.
    ///
    /// # Panics
    ///
    /// Эгер `f` panics болсо, panic чалган адамга жайылып, клетка инициализацияланбай калат.
    ///
    ///
    /// Клетканы `f` тен баштапкы абалга келтирүү ката.Мындай кылуу panic ге алып келет.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Рентеренттик инициализациянын *айрым* формалары UBге алып келиши мүмкүн экендигин эске алыңыз (`reentrant_init` тестин караңыз).
        // Бул `assert` ди алып салуу, `set/get` ти сактап калуу туура болмок деп эсептейм, бирок унчукпай эски наркты колдонгондон көрө, panic үчүн жакшы окшойт.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Оролгон маанини кайтарып, уячаны керектейт.
    ///
    /// Эгерде уяча бош болсо, `None` берет.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // `into_inner` `self` ти мааниси боюнча алгандыктан, компилятор ал карызга алынбагандыгын статикалык түрдө тастыктайт.
        // Ошентип, `Option<T>` көчүп кетүү коопсуз болот.
        self.inner.into_inner()
    }

    /// Бул `OnceCell` тин маанисин алып, аны кайрадан башталбаган абалга алып келет.
    ///
    /// Эч кандай натыйжа бербейт жана `OnceCell` инициализацияланбаса `None` берет.
    ///
    /// Коопсуздукка өзгөрүлмө шилтеме талап кылынат.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// Биринчи мүмкүнчүлүктө башталган маани.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   баштоого даяр
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Берилген инициалдаштыруу функциясы менен жаңы жалкоо маанини жаратат.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Бул жалкоо баалуулукту баалоону мажбурлайт жана натыйжага шилтеме берет.
    ///
    ///
    /// Бул `Deref` имплине барабар, бирок ачык-айкын.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// Баштапкы функциясы катары `Default` колдонуп, жаңы жалкоо маанисин жаратат.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}