use crate::future::Future;

/// `Future` ке айландыруу.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// future чыгарган бүтүм аяктаганда чыгарат.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Муну кайсы future түрүнө айландырып жатабыз?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Бир мааниден future түзөт.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}