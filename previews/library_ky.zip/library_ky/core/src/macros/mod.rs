#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Чалуучунун чыгарылышына жараша `$crate::panic::panic_2015` же `$crate::panic::panic_2021` ке чейин жайылат.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Эки сөздүн бири-бирине барабар экендигин тастыктайт ([`PartialEq`] колдонуп).
///
/// panic де, бул макроо, туюнтма сүрөттөлүштөрү менен туюнтмалардын маанилерин басып чыгарат.
///
///
/// [`assert!`] сыяктуу эле, бул макростун экинчи формасы бар, анда panic бажы билдирүүсү берилиши мүмкүн.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Төмөндө кайрадан төрөлгөндөр атайын жасалган.
                    // Аларсыз, карыз алуу үчүн стек уячасы маанилер салыштырылганга чейин эле башталат, бул байкалаарлык басаңдатууга алып келет.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Төмөндө кайрадан төрөлгөндөр атайын жасалган.
                    // Аларсыз, карыз алуу үчүн стек уячасы маанилер салыштырылганга чейин эле башталат, бул байкалаарлык басаңдатууга алып келет.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Эки туюнтма бири-бирине тең эмес экендигин ырастайт ([`PartialEq`] колдонуп).
///
/// panic де, бул макроо, туюнтма сүрөттөлүштөрү менен туюнтмалардын маанилерин басып чыгарат.
///
///
/// [`assert!`] сыяктуу эле, бул макростун экинчи формасы бар, анда panic бажы билдирүүсү берилиши мүмкүн.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Төмөндө кайрадан төрөлгөндөр атайын жасалган.
                    // Аларсыз, карыз алуу үчүн стек уячасы маанилер салыштырылганга чейин эле башталат, бул байкалаарлык басаңдатууга алып келет.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Төмөндө кайрадан төрөлгөндөр атайын жасалган.
                    // Аларсыз, карыз алуу үчүн стек уячасы маанилер салыштырылганга чейин эле башталат, бул байкалаарлык басаңдатууга алып келет.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Логикалык туюнтма иш учурунда `true` экендигин ырастайт.
///
/// Эгерде берилген сөз айкашын `true` чейин иштеп жатканда баалоо мүмкүн болбосо, бул [`panic!`] макросун чакырат.
///
/// [`assert!`] сыяктуу эле, бул макростун экинчи нускасы бар, анда panic бажы билдирүүсү берилиши мүмкүн.
///
/// # Uses
///
/// [`assert!`] тен айырмаланып, `debug_assert!` операторлору демейки шартта оптималдаштырылбаган түзүлүштөрдө гана иштетилет.
/// Х01X компиляторго өткөрүлүп берилмейинче, оптималдаштырылган түзүлүш `debug_assert!` операторлорун аткарбайт.
/// Бул `debug_assert!` чыгарууну курууда өтө кымбат, бирок иштеп чыгуу учурунда пайдалуу болушу мүмкүн болгон текшерүүлөр үчүн пайдалуу кылат.
/// `debug_assert!` кеңейтүүнүн натыйжасы ар дайым текшерилет.
///
/// Текшерилбеген ырастоо ыраатсыз абалда болгон программанын иштөөсүн улантууга мүмкүндүк берет, бул күтүлбөгөн кесепеттерге алып келиши мүмкүн, бирок бул коопсуз коддо гана болгондо, кооптуулукту киргизбейт.
///
/// Ырастоолордун аткаруу наркы жалпысынан өлчөнбөйт.
/// Ошентип [`assert!`] ти `debug_assert!` менен алмаштыруу профилдештирилгенден кийин гана күчөтүлөт, андан да маанилүүсү, коопсуз коддо гана!
///
/// # Examples
///
/// ```
/// // бул ырастоолор үчүн panic билдирүүсү берилген туюнтманын стрингделген мааниси болуп саналат.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // абдан жөнөкөй функция
/// debug_assert!(some_expensive_computation());
///
/// // Ыңгайлаштырылган билдирүү менен ырастоо
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Эки сөздүн бири-бирине барабар экендигин ырастайт.
///
/// panic де, бул макроо, туюнтма сүрөттөлүштөрү менен туюнтмалардын маанилерин басып чыгарат.
///
/// [`assert_eq!`] тен айырмаланып, `debug_assert_eq!` операторлору демейки боюнча оптималдаштырылбаган курулмаларда гана иштетилет.
/// Х01X компиляторго өткөрүлүп берилмейинче, оптималдаштырылган түзүлүш `debug_assert_eq!` операторлорун аткарбайт.
/// Бул `debug_assert_eq!` чыгарууну курууда өтө кымбат, бирок иштеп чыгуу учурунда пайдалуу болушу мүмкүн болгон текшерүүлөр үчүн пайдалуу кылат.
///
/// `debug_assert_eq!` кеңейтүүнүн натыйжасы ар дайым текшерилет.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Эки сөздүн бири-бирине тең эместигин ырастайт.
///
/// panic де, бул макроо, туюнтма сүрөттөлүштөрү менен туюнтмалардын маанилерин басып чыгарат.
///
/// [`assert_ne!`] тен айырмаланып, `debug_assert_ne!` операторлору демейки шартта оптималдаштырылбаган түзүлүштөрдө гана иштетилет.
/// Х01X компиляторго өткөрүлүп берилмейинче, оптималдаштырылган түзүлүш `debug_assert_ne!` операторлорун аткарбайт.
/// Бул `debug_assert_ne!` чыгарууну курууда өтө кымбат, бирок иштеп чыгуу учурунда пайдалуу болушу мүмкүн болгон текшерүүлөр үчүн пайдалуу кылат.
///
/// `debug_assert_ne!` кеңейтүүнүн натыйжасы ар дайым текшерилет.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Берилген туюнтманын берилген үлгүлөрдүн бирине дал келген-келбегендигин кайтарат.
///
/// `match` сөз айкашындагыдай эле, шаблонду милдеттүү түрдө `if` жана үлгү менен байланышкан ысымдарга ээ болгон күзөтчү билдирүүсү менен кошсо болот.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Жыйынтыкты оройт же анын катасын жайылтат.
///
/// `?` оператору `try!` ордуна алмаштырылды жана анын ордуна колдонулушу керек.
/// Мындан тышкары, `try` Rust 2018де сакталган сөз, андыктан сиз аны колдонушуңуз керек болсо, анда [raw-identifier syntax][ris] колдонушуңуз керек: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` берилген [`Result`] менен дал келет.`Ok` вариантында, туюнтма оролгон маанинин маанисине ээ болот.
///
/// `Err` вариантында, ал ички катаны калыбына келтирет.`try!` анда `From` колдонуп конверсияны жүзөгө ашырат.
/// Бул адистештирилген каталар менен жалпы каталардын ортосунда автоматтык түрдө конверсияны камсыз кылат.
/// Натыйжада ката дароо кайтарылып берилет.
///
/// Эрте кайтып келгендиктен, `try!` [`Result`] кайтаруучу функцияларда гана колдонулушу мүмкүн.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Тез артка кайтарылган Катачылыктардын артыкчылыктуу ыкмасы
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Каталарды тез кайтаруунун мурунку ыкмасы
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Бул барабар:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Форматталган маалыматтарды буферге жазат.
///
/// Бул макро 'writer', формат сабын жана аргументтердин тизмесин кабыл алат.
/// Аргументтер көрсөтүлгөн формат сабына ылайык форматталат жана жыйынтык жазуучуга берилет.
/// Жазуучу `write_fmt` ыкмасы менен кандайдыр бир мааниге ээ болушу мүмкүн;Адатта, бул [`fmt::Write`] же [`io::Write`] trait программаларын ишке ашыруудан келип чыгат.
/// Макро `write_fmt` ыкмасы кайтып келген нерсени кайтарат;адатта [`fmt::Result`] же [`io::Result`].
///
/// Формат сабы синтаксиси жөнүндө көбүрөөк маалымат алуу үчүн [`std::fmt`] ти караңыз.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Модуль `std::fmt::Write` жана `std::io::Write` экөөнү тең импорттой алат жана объектилерге `write!` чакыра алат, анткени объектилер адатта экөөнү тең ишке ашырбайт.
///
/// Бирок модуль traits квалификациялуу импорту керек, андыктан алардын аттары карама-каршы келбейт:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt колдонот
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt колдонот
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Бул макро `no_std` орнотууларында да колдонсо болот.
/// `no_std` орнотуусунда сиз компоненттердин деталдары үчүн жооптуусуз.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Форматталган дайындарды жаңы тилке тиркелип, буферге жазыңыз.
///
/// Бардык платформаларда жаңы линия (`\n`/`U+000A`) LINE FEED тамгасы (кошумча CARRIAGE RETURN (`\r`/`U+000D`) жок).
///
/// Көбүрөөк маалымат алуу үчүн, [`write!`] караңыз.Формат сабы синтаксиси жөнүндө маалымат алуу үчүн, [`std::fmt`] караңыз.
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Модуль `std::fmt::Write` жана `std::io::Write` экөөнү тең импорттой алат жана объектилерге `write!` чакыра алат, анткени объектилер адатта экөөнү тең ишке ашырбайт.
/// Бирок модуль traits квалификациялуу импорту керек, андыктан алардын аттары карама-каршы келбейт:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt колдонот
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt колдонот
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Жеткиликсиз кодду көрсөтөт.
///
/// Бул кээ бир код жеткиликсиз экендигин компилятор аныктай албаган учурда пайдалуу.Мисалы:
///
/// * Каруу-жарак шарттары менен куралдарды дал келтирүү.
/// * Динамикалык түрдө токтотулган циклдар.
/// * Динамикалык түрдө токтотулган итераторлор.
///
/// Эгер кодго жетүү мүмкүн эместиги аныкталса, анда [`panic!`] программасы токтоосуз токтотулат.
///
/// Бул макростун кооптуу аналогу-[`unreachable_unchecked`] функциясы, ал кодго жеткенде аныкталбаган жүрүм-турумга алып келет.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Бул ар дайым [`panic!`] болот.
///
/// # Examples
///
/// Дал келүү:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // эгерде комментарий берилсе, анда катаны түзүү
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3 кедей ишке ашыруунун бири
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// "not implemented" билдирүүсү менен дүрбөлөңгө түшүп, аткарылбаган кодду көрсөтөт.
///
/// Бул сиздин кодду терүүнү текшерүүгө мүмкүндүк берет, эгерде сиз trait прототипин түзүп же колдонуп жаткан болсоңуз, анда сиз бирөөнүн бардыгын колдонууну пландаштырбаган бир нече ыкманы талап кылсаңыз болот.
///
/// `unimplemented!` менен [`todo!`] ортосундагы айырмачылык, `todo!` функцияны кийинчерээк ишке ашыруу ниетин билдирип, билдирүү "not yet implemented" болсо, `unimplemented!` андай дооматтарды койбойт.
/// Анын билдирүүсү "not implemented".
/// Ошондой эле айрым IDE'лер "todo!" С деп белгилешет.
///
/// # Panics
///
/// Бул ар дайым [`panic!`] болот, анткени `unimplemented!` бул `panic!` үчүн стенография, бул туруктуу, конкреттүү билдирүү.
///
/// `panic!` сыяктуу эле, бул макроста дагы колдонуучунун баалуулуктарын көрсөтүү үчүн экинчи форма бар.
///
/// # Examples
///
/// Бизде trait `Foo` бар деп айт:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Биз 'MyStruct' үчүн `Foo` ишке ашырууну каалайбыз, бирок кандайдыр бир себептерден улам `bar()` функциясын ишке ашыруунун мааниси бар.
/// `baz()` жана `qux()` `Foo` ти ишке ашырууда дагы эле аныкталууга тийиш, бирок биз `unimplemented!` ти алардын аныктамаларында колдонуп, биздин коддун компиляциясын түзө алабыз.
///
/// Эгерде ишке ашпаган ыкмаларга жете турган болсок, анда дагы деле болсо программабыздын иштебей калышын каалайбыз.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz` менен `MyStruct` мааниси жок, андыктан бизде бул жерде эч кандай логика жок.
/////
///         // Бул "thread 'main' panicked at 'not implemented'" көрсөтөт.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Бул жерде бир нече логикабыз бар, аткарылбай калгандарга билдирүү кошо алабыз!биздин кемчиликти көрсөтүү.
///         // Бул төмөнкүнү көрсөтөт: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Бүтпөгөн кодду көрсөтөт.
///
/// Эгерде сиз прототип жасап жаткан болсоңуз жана жөн гана кодуңузду терип текшерүүнү кааласаңыз, анда пайдалуу болушу мүмкүн.
///
/// [`unimplemented!`] менен `todo!` ортосундагы айырмачылык, `todo!` функцияны кийинчерээк ишке ашыруу ниетин билдирип, билдирүү "not yet implemented" болсо, `unimplemented!` андай дооматтарды койбойт.
/// Анын билдирүүсү "not implemented".
/// Ошондой эле айрым IDE'лер "todo!" С деп белгилешет.
///
/// # Panics
///
/// Бул ар дайым [`panic!`] болот.
///
/// # Examples
///
/// Бул жерде кээ бир аткарылып жаткан коддун мисалы келтирилген.Бизде trait `Foo` бар:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Биз `Foo` ти бир түрүбүзгө киргизүүнү каалайбыз, бирок биринчи `bar()` үстүндө иштегибиз келет.Биздин кодду түзүү үчүн биз `baz()` ти ишке киргизишибиз керек, ошондуктан биз `todo!` ти колдоно алабыз:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // ишке ашыруу ушул жерде жүрөт
///     }
///
///     fn baz(&self) {
///         // азырынча baz() ти ишке ашыруу жөнүндө тынчсызданбайлы
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // биз baz() да колдонбойбуз, андыктан бул жакшы.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Камтылган макросттордун аныктамалары.
///
/// Көпчүлүк макро касиеттер (туруктуулук, көрүнөөчүлүк ж.б.) бул жердеги баштапкы коддон алынган, кеңейүү функцияларын кошпогондо, макро кириштерди натыйжага айландыруучу функциялар, ал функцияларды компилятор камсыз кылат.
///
///
pub(crate) mod builtin {

    /// Түзүлгөндө, берилген ката билдирүүсү менен компиляция иштебей калат.
    ///
    /// Бул макро crate шарттуу компиляция стратегиясын колдонуп, ката шарттарда жакшыраак ката билдирүүлөрүн бергенде колдонушу керек.
    ///
    /// Бул [`panic!`] тин компилятор деңгээлиндеги формасы, бирок *иштөө убагында эмес* компиляция учурунда ката кетирет.
    ///
    /// # Examples
    ///
    /// Мындай эки мисал макро жана `#[cfg]` чөйрөлөрү.
    ///
    /// Эгер макро туура эмес мааниге өтүп кетсе, анда компилятордун катасын жакшыраак чыгарыңыз.
    /// Акыркы branch жок болсо, компилятор дагы деле ката кетирет, бирок катанын билдирүүсүндө эки жарактуу маани айтылбайт.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Эгерде бир катар өзгөчөлүктөрдүн бири жеткиликтүү болбосо, компилятордун катасын чыгарыңыз.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Башка сап форматтоо макросторунун параметрлерин түзөт.
    ///
    /// Бул макро иштелип чыккан ар бир кошумча аргумент үчүн `{}` камтыган форматтоо сабын түзмө-түз алып.
    /// `format_args!` чыгарылышын сап катары чечмелөөгө мүмкүндүк берүүчү кошумча параметрлерди даярдайт жана аргументтерди бир типке каноникалык түргө келтирет.
    /// [`Display`] trait ишке ашырган ар кандай маани `format_args!` ке өткөрүлүп берилиши мүмкүн, ошондой эле [`Debug`] ишке ашырылышы `{:?}` форматташтырылган сапта берилиши мүмкүн.
    ///
    ///
    /// Бул макро [`fmt::Arguments`] типтеги маанини пайда кылат.Бул маани [`std::fmt`] алкагындагы макроско пайдалуу багыттоону жүргүзүү үчүн берилиши мүмкүн.
    /// Бардык башка форматтоо макростору (["формат!"], [`write!`], [`println!`], ж.б.) ушул аркылуу прокси кылынат.
    /// `format_args!`, анын макросторунан айырмаланып, үймөктөрдү бөлүүдөн сактайт.
    ///
    /// `format_args!` `Debug` жана `Display` контексттеринде кайтарып берген [`fmt::Arguments`] маанисин төмөндө көрсөтүлгөндөй колдонсоңуз болот.
    /// Мисал ошондой эле `Debug` жана `Display` форматтарынын бирдей экендигин көрсөтөт: `format_args!` интерполяцияланган формат сабы.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Көбүрөөк маалымат алуу үчүн [`std::fmt`] документтүүлүгүн караңыз.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// `format_args` менен бирдей, бирок аягында жаңы сапты кошот.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Компиляция учурунда айлана-чөйрөнүн өзгөрүлмөлүүсүн текшерет.
    ///
    /// Бул макроо `&'static str` тибиндеги туюнтманы түзүп, аталган чөйрөнүн өзгөрүлмө маанисине компиляция убагында кеңейет.
    ///
    ///
    /// Эгерде айлана-чөйрөнүн өзгөрмөсү аныкталбаса, анда компиляция катасы чыгарылат.
    /// Компиляция катасын кетирбөө үчүн, анын ордуна [`option_env!`] макросун колдонуңуз.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Экинчи параметр катары сапты өткөрүп, ката жөнүндө билдирүүнү настройкалай аласыз:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Эгерде `documentation` чөйрөсүнүн өзгөрмөсү аныкталбаса, анда төмөнкү ката пайда болот:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Компиляция учурунда айлана-чөйрөнүн өзгөрмөлүү вариантын текшерет.
    ///
    /// Эгерде аталган чөйрөнүн өзгөрмөсү компиляцияланган учурда бар болсо, анда ал `Option<&'static str>` түрүндөгү туюнтмага айланат, анын мааниси `Some` чөйрөнүн өзгөрүлмө маанисине барабар.
    /// Эгерде айлана-чөйрөнүн өзгөрмөсү жок болсо, анда ал `None` ке чейин кеңейет.
    /// Бул түр жөнүндө көбүрөөк маалымат алуу үчүн [`Option<T>`][Option] караңыз.
    ///
    /// Бул макросты колдонууда айлана-чөйрөнүн өзгөрүлмө-катышпагандыгына карабастан, убакыттын компиляциясы эч качан чыкпайт.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Идентификаторлорду бир идентификаторго бириктирет.
    ///
    /// Бул макро кандайдыр бир сандагы үтүр менен ажыратылган идентификаторлорду алат жана алардын бардыгын бириктирип, жаңы идентификатор болгон туюнтманы берет.
    /// Эске салсак, гигиена ушул макро жергиликтүү өзгөрүлмөлөрдү камтый албай турган абалга алып келет.
    /// Ошондой эле, жалпы эреже боюнча, макроэлементтерге, билдирүүдө же туюнтмада гана уруксат берилет.
    /// Демек, сиз бул макрости өзгөрүлүп турган нерселерге, функцияларга же модулдарга жана башка нерселерге шилтеме берүү үчүн колдонсоңуз болот, сиз аны менен жаңысын аныктай албайсыз.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (жаңы, кызыктуу, аты) { }//мындай жол менен колдонууга болбойт!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Литералдарды статикалык жип тилимине бириктирет.
    ///
    /// Бул макроэл ар кандай үтүр менен бөлүнгөн литалдарды алат жана `&'static str` типтеги туюнтманы берет, ал солдон оңго карай бириктирилген бардык литалдарды билдирет.
    ///
    ///
    /// Бүтүндөй жана калкып чыккан чекиттүү леталдарды бириктирүү максатында катаалдаштырылган.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ал чакырылган саптын номерин жайып көрсөтөт.
    ///
    /// [`column!`] жана [`file!`] менен, бул макростар иштеп чыгуучуларга булактын ичинде жайгашкан жери жөнүндө мүчүлүштүктөр жөнүндө маалымат берет.
    ///
    /// Кеңейтилген туюнтма `u32` түрүнө ээ жана 1 негизделген, ошондуктан ар бир файлдагы биринчи сап 1ге, экинчисине 2ге ж.б.у.с.
    /// Бул жалпы компиляторлордун же популярдуу редакторлордун ката билдирүүлөрүнө туура келет.
    /// Кайтарылган сап *сөзсүз түрдө*`line!` чакыруу сызыгынын өзү эмес, тескерисинче, `line!` макросунун чакыруусуна чейинки биринчи макро чакыруу.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Ал чакырылган тилкенин номерин жайып көрсөтөт.
    ///
    /// [`line!`] жана [`file!`] менен, бул макростар иштеп чыгуучуларга булактын ичинде жайгашкан жери жөнүндө мүчүлүштүктөрдү берүүчү маалыматтарды беришет.
    ///
    /// Кеңейтилген туюнтма `u32` түрүнө ээ жана 1 негизделген, ошондуктан ар бир саптагы биринчи тилке 1ге, экинчиси 2ге ж.б.у.с.
    /// Бул жалпы компиляторлордун же популярдуу редакторлордун ката билдирүүлөрүнө туура келет.
    /// Кайтарылган тилке *сөзсүз түрдө*`column!` чакыруу сызыгы эмес, тескерисинче `column!` макросунун чакыруусуна чейинки биринчи макро чакыруу.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Ал чакырылган файлдын аталышын кеңейтет.
    ///
    /// [`line!`] жана [`column!`] менен, бул макростар иштеп чыгуучуларга булактын ичинде жайгашкан жери жөнүндө мүчүлүштүктөр жөнүндө маалымат берет.
    ///
    /// Кеңейтилген экспрессте `&'static str` түрү бар, ал эми кайтарылган файл `file!` макросунун өзү эмес, тескерисинче `file!` макросунун чакыруусуна алып келген биринчи макро чакыруу болуп саналат.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Анын аргументтерин белгилейт.
    ///
    /// Бул макро `&'static str` тибиндеги туюнтма берет, бул макротко өткөн бардык tokens.
    /// Макро чакыруунун синтаксисине эч кандай чектөө коюлган эмес.
    ///
    /// tokens киргизүү кеңейтилген натыйжалары future өзгөрүшү мүмкүн экендигин эске алыңыз.Эгер сиз чыгарылган нерсеге таянсаңыз, этият болуңуз.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// UTF-8 коддолгон файлды сап катарында камтыйт.
    ///
    /// Файл учурдагы файлга салыштырмалуу жайгашкан (модулдарды табууга окшош).
    /// Берилген жол компиляция убагында платформага мүнөздүү жол менен чечмеленет.
    /// Мисалы, `\` арткы сызыгын камтыган Windows жолу бар чакыруу Unix те туура түзүлбөйт.
    ///
    ///
    /// Бул макро файлдын мазмунун түзгөн `&'static str` типтеги туюнтманы берет.
    ///
    /// # Examples
    ///
    /// Бир каталогдо төмөнкүдөй мазмундагы эки файл бар деп коёлу:
    ///
    /// 'spanish.in' файл:
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 'main.rs' файл:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' компиляцияланышы жана алынган экилик иштөө "adiós" басып чыгарат.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Файлды байт массивине шилтеме катары камтыйт.
    ///
    /// Файл учурдагы файлга салыштырмалуу жайгашкан (модулдарды табууга окшош).
    /// Берилген жол компиляция убагында платформага мүнөздүү жол менен чечмеленет.
    /// Мисалы, `\` арткы сызыгын камтыган Windows жолу бар чакыруу Unix те туура түзүлбөйт.
    ///
    ///
    /// Бул макро файлдын мазмунун түзгөн `&'static [u8; N]` типтеги туюнтманы берет.
    ///
    /// # Examples
    ///
    /// Бир каталогдо төмөнкүдөй мазмундагы эки файл бар деп коёлу:
    ///
    /// 'spanish.in' файл:
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 'main.rs' файл:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' компиляцияланышы жана алынган экилик иштөө "adiós" басып чыгарат.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Учурдагы модуль жолун чагылдырган сапка жайылат.
    ///
    /// Учурдагы модуль жолун crate root ге кайтып барган модулдардын иерархиясы деп эсептесе болот.
    /// Кайтарылган жолдун биринчи компоненти-учурда түзүлүп жаткан crate аталышы.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Түзүү убагында конфигурация желектеринин логикалык айкалыштарын баалайт.
    ///
    /// `#[cfg]` атрибутунан тышкары, бул макро конфигурация желектерин логикалык билдирүүнү баалоого мүмкүнчүлүк берет.
    /// Бул тез-тез кайталануучу код алып келет.
    ///
    /// Бул макроско берилген синтаксис [`cfg`] атрибуту менен бирдей синтаксис.
    ///
    /// `cfg!`, `#[cfg]` тен айырмаланып, эч кандай кодду алып салбайт жана жалаң гана туура же жалган деп баалайт.
    /// Мисалы, if/else туюнтмасындагы бардык блоктор `cfg!` кандай баа бергенине карабастан, шарт үчүн колдонулганда жарактуу болушу керек.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Файлды сөз айкашы же контекстке ылайык пункт катары талдайт.
    ///
    /// Файл учурдагы файлга салыштырмалуу жайгашкан (модулдарды табууга окшош).Берилген жол компиляция убагында платформага мүнөздүү жол менен чечмеленет.
    /// Мисалы, `\` арткы сызыгын камтыган Windows жолу бар чакыруу Unix те туура түзүлбөйт.
    ///
    /// Бул макрону колдонуу көп учурда туура эмес идея болуп саналат, анткени эгерде файл сөз айкашы катары талданган болсо, анда ал курчап турган кодго гигиеналык жактан жайгаштырылат.
    /// Натыйжада, учурдагы файлда бирдей аталыштагы өзгөрмөлөр же функциялар болсо, анда өзгөрүлмө же функциялар файл күткөндөн айырмаланып калышы мүмкүн.
    ///
    ///
    /// # Examples
    ///
    /// Бир каталогдо төмөнкүдөй мазмундагы эки файл бар деп коёлу:
    ///
    /// 'monkeys.in' файл:
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// 'main.rs' файл:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' компиляцияланышы жана алынган экилик иштөө "🙈🙊🙉🙈🙊🙉" басып чыгарат.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Логикалык туюнтма иш учурунда `true` экендигин ырастайт.
    ///
    /// Эгерде берилген сөз айкашын `true` чейин иштеп жатканда баалоо мүмкүн болбосо, бул [`panic!`] макросун чакырат.
    ///
    /// # Uses
    ///
    /// Ырастоолор мүчүлүштүктөрдү оңдоодо жана чыгарууда да текшерилет жана аларды өчүрүүгө болбойт.
    /// Демейки шартта чыгарылыштарда иштебеген ырастоолорду [`debug_assert!`] караңыз.
    ///
    /// Кооптуу код `assert!` ке таянып, иштөө убактысынын инварианттарын колдонушу мүмкүн, эгерде бузулган болсо, бул коопсуздукка алып келиши мүмкүн.
    ///
    /// `assert!` тин башка колдонулуш учурлары коопсуз коддогу иштөө убактысынын инварианттарын текшерүүнү жана колдонууну камтыйт (анын бузулушу кооптуулукка алып келбейт).
    ///
    ///
    /// # Ыңгайлаштырылган билдирүүлөр
    ///
    /// Бул макростун экинчи формасы бар, анда panic колдонуучусунун билдирүүсү форматтоо үчүн аргументтер менен же жок берилиши мүмкүн.
    /// Бул форманын синтаксиси үчүн [`std::fmt`] караңыз.
    /// Формат аргументи катары колдонулган сөз айкаштары аткарылбаса гана бааланат.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // бул ырастоолор үчүн panic билдирүүсү берилген туюнтманын стрингделген мааниси болуп саналат.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // абдан жөнөкөй функция
    ///
    /// assert!(some_computation());
    ///
    /// // Ыңгайлаштырылган билдирүү менен ырастоо
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Inline assembly.
    ///
    /// Колдонуу үчүн [unstable book] окуп.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM стилиндеги саптык монтаж.
    ///
    /// Колдонуу үчүн [unstable book] окуп.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Модуль деңгээлиндеги сап курама.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Басып чыгаруулар tokens ди стандарттык өндүрүшкө өткөрүп берди.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Башка макроолордо мүчүлүштүктөрдү оңдоо үчүн колдонулган издөө функциясын иштетет же өчүрөт.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Туунду макроолорду колдонуу үчүн колдонулган атрибуттуу макро.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Функцияга колдонулган атрибуттуу макро бирдик тестине айландыруу үчүн.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Функцияга колдонулган атрибуттуу макростор аны критерийлердин тестине айландырат.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` жана `#[bench]` макроолорун ишке ашыруу чоо-жайы.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Глобалдык бөлүштүрүүчү катары каттоодо статикада колдонулган атрибуттуу макро.
    ///
    /// Ошондой эле [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html) караңыз.
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Өткөн жол жеткиликтүү болсо, колдонулган нерсени сактап, башкача жол менен алып салат.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Колдонулган код фрагментиндеги бардык `#[cfg]` жана `#[cfg_attr]` атрибуттарын кеңейтет.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` компиляторунун туруксуз ишке ашыруу чоо-жайы, колдонбоңуз.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` компиляторунун туруксуз ишке ашыруу чоо-жайы, колдонбоңуз.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}