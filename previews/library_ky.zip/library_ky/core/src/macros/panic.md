Учурдагы жип Panics.

Бул программанын токтоосуз токтотулушун камсыз кылат жана программанын чалган адамына кайтарым байланышын берет.
`panic!` программа калыбына келтирилгис абалга жеткенде колдонулушу керек.

Бул макро коддордо жана тесттерде шарттарды ырастоонун мыкты жолу.
`panic!` [`Option`][ounwrap] жана [`Result`][runwrap] энумдарынын `unwrap` ыкмасы менен тыгыз байланышта.
Эки ишке тең [`None`] же [`Err`] варианттарына коюлганда `panic!` деп аталат.

`panic!()` ти колдонууда [`format!`] синтаксисинин жардамы менен курулган сап жүктөмүн көрсөтсөңүз болот.
Ошол пайдалуу жүк panic чалып жаткан Rust жипке сайганда, panic жипти толугу менен пайда кылганда колдонулат.

Демейки `std` hook жүрүм-туруму, б.а.
түздөн-түз panic чакырылгандан кийин иштей турган код, `panic!()` чалуусунун file/line/column маалыматы менен кошо `stderr` ке билдирүү жүктөмүн басып чыгаруу керек.

[`std::panic::set_hook()`] аркылуу panic hook жазуусун жокко чыгарсаңыз болот.
hook ичинде panic ге `&dyn Any + Send` катары кирүүгө болот, анда кадимки `panic!()` чакыруулары үчүн `&str` же `String` камтылган.
Башка типтеги мааниси бар panic ге [`panic_any`] колдонсо болот.

[`Result`] enum көп учурда `panic!` макросун колдонуудан көрө каталарды калыбына келтирүү үчүн жакшы чечим болот.
Бул макрости тышкы булактар сыяктуу туура эмес баалуулуктарды колдонуудан качуу үчүн колдонуу керек.
Ката менен иштөө жөнүндө толук маалымат [book] табылган.

Компиляция учурунда каталарды кетирүү үчүн [`compile_error!`] макросун караңыз.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Учурдагы ишке ашыруу

Эгер негизги panics жиптери болсо, анда ал сиздин бардык жиптериңизди токтотуп, программаңызды `101` коду менен аяктайт.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





