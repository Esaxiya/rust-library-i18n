//! Бул модуль `Any` trait ди ишке ашырат, бул иштөө убактысын чагылдыруу аркылуу ар кандай `'static` түрүн динамикалык терүүгө мүмкүндүк берет.
//!
//! `Any` өзү `TypeId` алуу үчүн колдонулушу мүмкүн жана trait объектиси катары колдонулганда дагы көптөгөн функциялары бар.
//! `&dyn Any` (карызга алынган trait объектиси) катары, ал `is` жана `downcast_ref` ыкмаларын колдонуп, камтылган маани берилген түргө ээ экендигин текшерип, тип катары ички мааниге шилтеме алат.
//! `&mut dyn Any` катары, ички мааниге карата өзгөрүлмө шилтеме алуу үчүн `downcast_mut` методу дагы бар.
//! `Box<dyn Any>` `Box<T>` ге которууга аракет кылган `downcast` ыкмасын кошот.
//! Толук маалымат алуу үчүн [`Box`] документтерин караңыз.
//!
//! `&dyn Any` баллдын конкреттүү типтеги экендигин текшерүү менен гана чектелип, trait түрүн колдонуп жаткандыгын текшерүү үчүн колдонулбай тургандыгын эске алыңыз.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Акылдуу көрсөткүчтөр жана `dyn Any`
//!
//! `Any` ти trait объектиси катары колдонууда, айрыкча `Box<dyn Any>` же `Arc<dyn Any>` сыяктуу типтерде бир нерсени эсиңизден чыгарбаңыз, `.type_id()` маанисине жөн эле trait объектисинин эмес,*контейнердин*`TypeId` түзүлөт.
//!
//! Акылдуу көрсөткүчтү `&dyn Any` ордуна айландырып, объектинин `TypeId` үлгүсүн кайтарып берүү менен, буга жол бербөөгө болот.
//! Мисалы:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Сиз муну каалашыңыз мүмкүн:
//! let actual_id = (&*boxed).type_id();
//! // ... караганда:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Функцияга өткөн маанини чыгарышыбыз керек болгон жагдайды карап көрөлү.
//! Debug шаймандарынын үстүнөн иштеп жаткандыгыбызды билебиз, бирок анын конкреттүү түрүн билбейбиз.Биз айрым түрлөрүнө өзгөчө мамиле жасоону каалайбыз: бул учурда алардын маанисине чейин String маанисинин узундугун басып чыгаруу.
//! Компиляция учурунда биздин баалуулуктардын конкреттүү түрүн билбейбиз, андыктан анын ордуна иштөө убактысынын чагылышын колдонушубуз керек.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Мүчүлүштүктөрдү оңдоону ишке ашырган ар кандай типтеги Logger функциясы.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Биздин баалуулукту `String` ке айландырууга аракет кылыңыз.
//!     // Эгер ийгиликтүү болсо, анда биз String`дин узундугун жана анын маанисин чыгаргыбыз келет.
//!     // Андай болбосо, ал башкача: жөн эле кооздоосуз басып чыгарыңыз.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Бул функция анын параметрин аны менен иштөө алдында чыгарууну каалайт.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... башка жумуштарды жаса
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Ар кандай trait
///////////////////////////////////////////////////////////////////////////////

/// Динамикалык терүүнү тууроочу trait.
///
/// Көпчүлүк түрлөрү `Any` ти ишке ашырат.Бирок, "статикалык эмес" шилтемени камтыган ар кандай түрлөрү жок.
/// Көбүрөөк маалымат алуу үчүн [module-level documentation][mod] караңыз.
///
/// [mod]: crate::any
// Бул trait кооптуу эмес, бирок биз анын кооптуу коддогу жалгыз имплдин `type_id` функциясынын өзгөчөлүктөрүнө таянабыз (мисалы, `downcast`).Адатта, бул көйгөй болмок, бирок `Any` тин бирден-бир мааниси жуурканды ишке ашыруу болгондуктан, башка эч кандай код `Any` ти аткара албайт.
//
// Биз бул trait кооптуу абалга келтире алмакпыз-бул бузулууга алып келбейт, анткени биз бардык ишке ашырылышын көзөмөлдөп жатабыз-бирок биз бул экөөнү тең чындыгында эле зарыл эмес деп эсептейбиз жана кооптуу traits жана кооптуу ыкмаларды айырмалоо жөнүндө колдонуучуларды чаташтырышы мүмкүн (б.а., `type_id` дагы деле чалып койсо болот, бирок биз документтештирүүдө ушундай көрсөтүүнү каалайбыз).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `self` `TypeId` алат.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Ар кандай trait объектилерине жайылтуу ыкмалары.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Мисалы, жипти бириктирүүнүн натыйжасы `unwrap` менен басылып чыгып, колдонула тургандыгына ынаныңыз.
// Диспетчер жаңыртуу менен иштесе, акыры, керек болбой калышы мүмкүн.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Эгерде кутуча түрү `T` менен бирдей болсо, `true` берет.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Бул функция орнотулган `TypeId` түрүн алыңыз.
        let t = TypeId::of::<T>();

        // trait объектисиндеги X001 түрүндөгү `TypeId` алыңыз.
        let concrete = self.type_id();

        // Экөө теңдикти "TypeId" менен салыштырыңыз.
        t == concrete
    }

    /// Эгерде кутучага `T` түрүндө болсо, же болбосо `None` түрүндө шилтеме берет.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // КООПСУЗДУК: туура түрүн көрсөтүп жаткандыгыбызды текшерип, ага ишенсек болот
            // эс тутумдун коопсуздугун текшерүү, анткени биз бардык түрлөрүн колдонуп, каалаганын ишке ашырдык;биздин имплибизге карама-каршы келген башка эч кандай имплиштер болушу мүмкүн эмес.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Эгерде `T` тибинде болсо, анда кутучадагы маанидеги айрым өзгөрүлмө шилтемелерди кайтарат, ал эми андай эмес болсо, `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // КООПСУЗДУК: туура түрүн көрсөтүп жаткандыгыбызды текшерип, ага ишенсек болот
            // эс тутумдун коопсуздугун текшерүү, анткени биз бардык түрлөрүн колдонуп, каалаганын ишке ашырдык;биздин имплибизге карама-каршы келген башка эч кандай имплиштер болушу мүмкүн эмес.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// `Any` түрүндө аныкталган ыкмага багыт.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` түрүндө аныкталган ыкмага багыт.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` түрүндө аныкталган ыкмага багыт.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// `Any` түрүндө аныкталган ыкмага багыт.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` түрүндө аныкталган ыкмага багыт.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` түрүндө аныкталган ыкмага багыт.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID жана анын методдору
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` түрү үчүн глобалдуу уникалдуу идентификаторду билдирет.
///
/// Ар бир `TypeId` тунук эмес объект болуп саналат, ал ичиндеги нерселерди текшерүүгө жол бербейт, бирок клондоштуруу, салыштыруу, басып чыгаруу жана көрсөтүү сыяктуу негизги операцияларга мүмкүндүк берет.
///
///
/// `TypeId` учурда `'static` ке таандык типтер үчүн гана жеткиликтүү, бирок бул чектөө future де алынып салынышы мүмкүн.
///
/// `TypeId` `Hash`, `PartialOrd` жана `Ord` колдонот, ал эми таштандылар жана буйрук Rust релиздеринде ар кандай болорун белгилей кетүү керек.
/// Кодуңуздун ичинде аларга ишенүүдөн сак болуңуз!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Бул жалпы функция орнотулган `TypeId` түрүн берет.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Түрдүн атын сап тилкеси катары кайтарат.
///
/// # Note
///
/// Бул диагностикалык колдонуу үчүн арналган.
/// Кайтарылган саптын так мазмуну жана форматы көрсөтүлгөн эмес, болгону түрдүн мыкты сүрөттөлүшү.
/// Мисалы, `type_name::<Option<String>>()` кайтып келе турган саптардын арасында `"Option<String>"` жана `"std::option::Option<std::string::String>"` бар.
///
///
/// Кайтарылган сап типтин уникалдуу идентификатору катары каралбашы керек, анткени бир нече түр бир эле типтеги аталышка шайкеш келиши мүмкүн.
/// Ошо сыяктуу эле, түрдүн бардык бөлүктөрү кайтарылган сапта пайда болушуна эч кандай кепилдик жок: мисалы, учурда жашоо мүнөздөмөлөрү киргизилген эмес.
/// Мындан тышкары, чыгарылыш компилятордун версияларынын ортосунда өзгөрүшү мүмкүн.
///
/// Учурдагы ишке компилятор диагностикасы жана debuginfo сыяктуу инфраструктура колдонулат, бирок буга кепилдик жок.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Көрсөтүлгөн маанинин түрүнүн аталышын сап тилкеси катары кайтарат.
/// Бул `type_name::<T>()` менен бирдей, бирок өзгөрмө түрү оңой менен табылбаган жерде колдонсо болот.
///
/// # Note
///
/// Бул диагностикалык колдонуу үчүн арналган.Саптын так мазмуну жана форматы көрсөтүлгөн эмес, болгону түрдүн мыкты сүрөттөлүшү.
/// Мисалы, `type_name_of_val::<Option<String>>(None)` `"Option<String>"` же `"std::option::Option<std::string::String>"` кайтарып бере алат, бирок `"foobar"` эмес.
///
/// Мындан тышкары, чыгарылыш компилятордун версияларынын ортосунда өзгөрүшү мүмкүн.
///
/// Бул функция trait объектилерин чечпейт, башкача айтканда `type_name_of_val(&7u32 as &dyn Debug)` `"dyn Debug"` кайтарып бериши мүмкүн, бирок `"u32"` эмес.
///
/// Типтин аталышы типтин уникалдуу идентификатору катары каралбашы керек;
/// бир нече түр бир эле аталышты бөлүшүшү мүмкүн.
///
/// Учурдагы ишке компилятор диагностикасы жана debuginfo сыяктуу инфраструктура колдонулат, бирок буга кепилдик жок.
///
/// # Examples
///
/// Демейки бүтүн жана калкыма түрлөрүн басып чыгарат.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}