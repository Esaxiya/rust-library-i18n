//! `str` үчүн Trait ишке ашыруу.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Кылдарды иретке келтирүүнү жүзөгө ашырат.
///
/// Саптар [lexicographically](Ord#lexicographical-comparison) байт мааниси боюнча иреттелген.
/// Бул код диаграммаларындагы ээлеген позицияларына жараша Юникод кодун буйрук кылат.
/// Бул сөзсүз түрдө "alphabetical" тартибине окшошпойт, ал тилге жана аймакка жараша өзгөрөт.
/// Саптарды маданий жактан кабыл алынган стандарттарга ылайык иреттөө үчүн `str` түрүнүн алкагынан тышкары жергиликтүү мүнөздүү маалыматтар талап кылынат.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Саптарга салыштыруу операцияларын жүргүзөт.
///
/// Саптар [lexicographically](Ord#lexicographical-comparison) байт баалуулуктары менен салыштырылат.
/// Бул код диаграммаларындагы ээлеген позицияларынын негизинде Юникод коду менен салыштырат.
/// Бул сөзсүз түрдө "alphabetical" тартибине окшошпойт, ал тилге жана аймакка жараша өзгөрөт.
/// Маданий жактан кабыл алынган стандарттарга ылайык саптарды салыштыруу үчүн, `str` түрүнүн алкагынан тышкары жергиликтүү мүнөздүү маалыматтар талап кылынат.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// `&self[..]` же `&mut self[..]` синтаксиси менен тилмелерди кесүүнү ишке ашырат.
///
/// Бүт саптын кесиндигин кайтарат, башкача айтканда, `&self` же `&mut self` берет."&Self [0 .." га барабар
/// len] `or`&mut mut [0 ..
/// len]`.
/// Башка индекстөө иш-аракеттеринен айырмаланып, бул эч качан panic болбойт.
///
/// Бул операция *O*(1).
///
/// 1.20.0 чейин, индекстөө иш-аракеттери дагы эле `Index` жана `IndexMut` түздөн-түз ишке ашыруу менен колдоого алынган.
///
/// `&self[0 .. len]` же `&mut self[0 .. len]` менен барабар.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// `&self[begin .. end]` же `&mut self[begin .. end]` синтаксиси менен тилмелерди кесүүнү ишке ашырат.
///
/// Берилген саптын бир кесимин байт диапазонунан кайтарып берет [`begin`, `end`).
///
/// Бул операция *O*(1).
///
/// 1.20.0 чейин, индекстөө иш-аракеттери дагы эле `Index` жана `IndexMut` түздөн-түз ишке ашыруу менен колдоого алынган.
///
/// # Panics
///
/// Panics, эгер `begin` же `end` символдун баштапкы байт жылышын көрсөтпөсө (`is_char_boundary` тарабынан аныкталгандай), эгер `begin > end` болсо же `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // булар panic болот:
/// // байт 2 `ö` ичинде:
/// // &s [2 ..3];
///
/// // байт 8 `老`&s ичинде жатат [1 ..
/// // 8];
///
/// // байт 100 саптын сыртында&s [3 ..]
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // КООПСУЗДУК: `start` жана `end` char чегинде экендигин текшерип,
            // жана биз коопсуз шилтеме аркылуу өтүп жатабыз, ошондуктан кайтарып берүү мааниси да бир болот.
            // Чаралардын чектерин дагы текшерип көрдүк, андыктан бул UTF-8 жарактуу.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // КООПСУЗДУК: `start` жана `end` char чегинде экендигин текшериңиз.
            // Көрсөткүч уникалдуу экендигин билебиз, анткени биз аны `slice` тен алганбыз.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // КООПСУЗДУК: чалган адам `self` `slice` чегинде экендигине кепилдик берет
        // бул `add` үчүн бардык шарттарды канааттандырат.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // КООПСУЗДУК: `get_unchecked` үчүн комментарийлерди караңыз.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary индекстин [0, .len()] болгонун текшерет, анткени NLL көйгөйүнөн улам `get` жогорудагыдай колдонулбайт
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // КООПСУЗДУК: `start` жана `end` char чегинде экендигин текшерип,
            // жана биз коопсуз шилтеме аркылуу өтүп жатабыз, ошондуктан кайтарып берүү мааниси да бир болот.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// `&self[.. end]` же `&mut self[.. end]` синтаксиси менен тилмелерди кесүүнү ишке ашырат.
///
/// Берилген саптын бир кесимин байт диапазонунан кайтарып берет [`0`, `end`).
/// `&self[0 .. end]` же `&mut self[0 .. end]` менен барабар.
///
/// Бул операция *O*(1).
///
/// 1.20.0 чейин, индекстөө иш-аракеттери дагы эле `Index` жана `IndexMut` түздөн-түз ишке ашыруу менен колдоого алынган.
///
/// # Panics
///
/// Эгерде Panics, эгер `end` символдун баштапкы байт жылышын көрсөтпөсө (`is_char_boundary` тарабынан аныкталгандай) же `end > len` болсо.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // КООПСУЗДУК: `end` char чегинде экендигин текшерип,
            // жана биз коопсуз шилтеме аркылуу өтүп жатабыз, ошондуктан кайтарып берүү мааниси да бир болот.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // КООПСУЗДУК: `end` char чегинде экендигин текшерип,
            // жана биз коопсуз шилтеме аркылуу өтүп жатабыз, ошондуктан кайтарып берүү мааниси да бир болот.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // КООПСУЗДУК: `end` char чегинде экендигин текшерип,
            // жана биз коопсуз шилтеме аркылуу өтүп жатабыз, ошондуктан кайтарып берүү мааниси да бир болот.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// `&self[begin ..]` же `&mut self[begin ..]` синтаксиси менен тилмелерди кесүүнү ишке ашырат.
///
/// Берилген саптын бир кесимин байт диапазонунан кайтарып берет [`begin`, `len`)."&Self" менен барабар [баштоо ..
/// len] `же`&mut self [баштоо ..
/// len]`.
///
/// Бул операция *O*(1).
///
/// 1.20.0 чейин, индекстөө иш-аракеттери дагы эле `Index` жана `IndexMut` түздөн-түз ишке ашыруу менен колдоого алынган.
///
/// # Panics
///
/// Эгерде Panics, эгер `begin` символдун баштапкы байт жылышын көрсөтпөсө (`is_char_boundary` тарабынан аныкталгандай) же `begin > len` болсо.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // КООПСУЗДУК: `start` char чегинде экендигин текшерип,
            // жана биз коопсуз шилтеме аркылуу өтүп жатабыз, ошондуктан кайтарып берүү мааниси да бир болот.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // КООПСУЗДУК: `start` char чегинде экендигин текшерип,
            // жана биз коопсуз шилтеме аркылуу өтүп жатабыз, ошондуктан кайтарып берүү мааниси да бир болот.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // КООПСУЗДУК: чалган адам `self` `slice` чегинде экендигине кепилдик берет
        // бул `add` үчүн бардык шарттарды канааттандырат.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // КООПСУЗДУК: `get_unchecked` менен бирдей.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // КООПСУЗДУК: `start` char чегинде экендигин текшерип,
            // жана биз коопсуз шилтеме аркылуу өтүп жатабыз, ошондуктан кайтарып берүү мааниси да бир болот.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// `&self[begin ..= end]` же `&mut self[begin ..= end]` синтаксиси менен тилмелерди кесүүнү ишке ашырат.
///
/// Берилген саптын кесиндисин [`begin`, `end`] байт диапазонунан кайтарат.`&self [begin .. end + 1]` же `&mut self[begin .. end + 1]` менен барабар, эгер `end` `usize` үчүн максималдуу мааниге ээ болбосо.
///
/// Бул операция *O*(1).
///
/// # Panics
///
/// Panics, эгер `begin` символдун баштапкы байт жылышын көрсөтпөсө (`is_char_boundary` тарабынан аныкталгандай), эгер `end` символдун аяктаган байт жылышын көрсөтпөсө (`end + 1` же баштапкы байт жылышы же `len` барабар), эгер `begin > end`, же `end >= len` болсо.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // КООПСУЗДУК: чалган адам `get_unchecked` үчүн коопсуздук келишимин сакташы керек.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // КООПСУЗДУК: чалган адам `get_unchecked_mut` үчүн коопсуздук келишимин сакташы керек.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// `&self[..= end]` же `&mut self[..= end]` синтаксиси менен тилмелерди кесүүнү ишке ашырат.
///
/// Берилген саптын кесиндисин [0, `end`] байт диапазонунан кайтарат.
/// `&self [0 .. end + 1]` үчүн барабар, эгер `end` `usize` үчүн максималдуу мааниге ээ болбосо.
///
/// Бул операция *O*(1).
///
/// # Panics
///
/// Эгерде Panics, эгер `end` символдун аяктаган байт жылышын көрсөтпөсө (`end + 1` же `is_char_boundary` тарабынан аныкталгандай, же `len` менен барабар байт жылышуу) же `end >= len` болсо.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // КООПСУЗДУК: чалган адам `get_unchecked` үчүн коопсуздук келишимин сакташы керек.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // КООПСУЗДУК: чалган адам `get_unchecked_mut` үчүн коопсуздук келишимин сакташы керек.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Саптагы маанини талдоо
///
/// `FromStr`нин [`from_str`] ыкмасы көбүнчө ['str`]' дин [`parse`] ыкмасы аркылуу жашыруун колдонулат.
/// Мисалдар үчүн ["талдоо"] документин караңыз.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` өмүр бою параметр жок, ошондуктан сиз өмүр бою параметр камтылбаган түрлөрүн гана талдай аласыз.
///
/// Башка сөз менен айтканда, `i32` ти `FromStr` менен талдай аласыз, бирок `&i32` ти эмес.
/// `i32` камтылган структураны талдай аласыз, бирок `&i32` камтылбайт.
///
/// # Examples
///
/// Мисалга `Point` типтеги `FromStr` программасынын негизги жүзөгө ашырылышы:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Байланышкан ката, анализден кайтарылса болот.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Ушул түрдөгү маанини кайтаруу үчүн `s` сабын талдайт.
    ///
    /// Эгерде талдоо ийгиликтүү болсо, анда [`Ok`] ичиндеги маанини кайтарыңыз, болбосо сап начар форматталганда, [`Err`] ичине мүнөздүү ката кайтат.
    /// Ката түрү trait колдонуу үчүн мүнөздүү.
    ///
    /// # Examples
    ///
    /// `FromStr` ти ишке ашыруучу [`i32`] менен негизги колдонуу:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// `bool` ти саптан талдаңыз.
    ///
    /// `Result<bool, ParseBoolError>` берет, анткени `s` анализделиши мүмкүн же жок болушу мүмкүн.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Эскертүү, көпчүлүк учурларда, `str` боюнча `.parse()` ыкмасы туура келет.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}