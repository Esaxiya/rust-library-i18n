//! utf8 ката түрүн аныктайт.

use crate::fmt;

/// [`u8`] ырааттуулугун сап катары чечмелөөгө аракет жасоодо пайда болгон каталар.
///
/// Ошентип, `from_utf8` функциясы жана [`String`] жана [`&str`] функцияларынын методдору ушул катаны колдонушат, мисалы.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Бул ката түрүнүн ыкмаларын үймө эс тутумун бөлбөстөн `String::from_utf8_lossy` окшош функционалды түзүү үчүн колдонсо болот:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Жарактуу UTF-8 текшерилген берилген саптагы индексти кайтарат.
    ///
    /// Бул `from_utf8(&input[..index])` `Ok(_)` кайтарып бере турган максималдуу индекс.
    ///
    ///
    /// # Examples
    ///
    /// Негизги колдонуу:
    ///
    /// ```
    /// use std::str;
    ///
    /// // кээ бир жараксыз байттар, vector де
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 Utf8Error кайтарат
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // экинчи байт бул жерде жараксыз
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Ката жөнүндө көбүрөөк маалымат берет:
    ///
    /// * `None`: киргизүү аягы күтүлбөгөн жерден жетти.
    ///   `self.valid_up_to()` кириш аягына чейин 1ден 3 байтка чейин.
    ///   Эгер байт агымы (мисалы, файл же тармак розеткасы) декодирование болуп жатса, анда UTF-8 байт ырааттуулугу бир нече бөлүктү камтыган жарактуу `char` болушу мүмкүн.
    ///
    ///
    /// * `Some(len)`: күтүлбөгөн байт туш болду.
    ///   Берилген узундук-`valid_up_to()` берген индекстен башталган жараксыз байт катарынын узундугу.
    ///   Декоддоо жоготуу менен чечилсе, ошол ырааттуулуктан кийин ([`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] салынгандан кийин) улантылышы керек.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// `bool` ти [`from_str`] колдонуп талдап жатканда ката кайтпай калды
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}