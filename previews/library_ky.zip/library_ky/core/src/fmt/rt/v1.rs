//! Бул ifmt тарабынан колдонулган ички модуль!иштөө убактысы.Бул структуралар форматтын саптарын алдын-ала компиляциялоо үчүн статикалык массивдерге чыгарылат.
//!
//! Бул аныктамалар алардын `ct` эквиваленттерине окшош, бирок статикалык түрдө бөлүштүрүлүшү жана иштөө убактысына бир аз оптималдаштырылышы менен айырмаланат.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Форматтоо директивасынын бир бөлүгү катары суралышы мүмкүн болгон тегиздөө.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Мазмун сол жакка тегизделиши керектигин көрсөтөт.
    Left,
    /// Мазмундун туура тегизделиши керектигин көрсөтүү.
    Right,
    /// Мазмундун ортосуна тегизделиши керектигин көрсөтөт.
    Center,
    /// Эч кандай тегиздөө талап кылынган жок.
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width) жана [precision](https://doc.rust-lang.org/std/fmt/#precision) спекификаторлору колдонушат.
#[derive(Copy, Clone)]
pub enum Count {
    /// Тамгалык номери менен көрсөтүлгөн, маанисин сактайт
    Is(usize),
    /// `$` жана `*` синтаксистери аркылуу көрсөтүлгөн, индексти `args` ге сактайт
    Param(usize),
    /// Көрсөтүлгөн эмес
    Implied,
}