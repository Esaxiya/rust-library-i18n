macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Бул бүтүн түр менен чагылдырыла турган эң кичине чоңдук.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// Бул бүтүн түрү менен чагылдырылышы мүмкүн болгон эң чоң мааниси.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// Бул бүтүн түрдүн бит өлчөмү.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Берилген негиздеги сап тилкесин бүтүн санга айландырат.
        ///
        /// Сап милдеттүү эмес `+` же `-` белгиси болушу керек, андан кийин сандар.
        /// Ак мейкиндиктин алдыңкы жана артта калуусу катаны билдирет.
        /// Цифралар-бул `radix` жараша, бул белгилердин кичи бөлүгү:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// Бул функция panics, эгерде `radix` 2 ден 36 га чейин эмес.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// `self` экилик чагылдырылышындагы бирлердин санын кайтарып берет.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// `self` экилик чагылдырылышындагы нөлдөрдүн санын кайтарып берет.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// `self` экилик чагылдырылышындагы алдыңкы нөлдөрдүн санын кайтарып берет.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// `self` экилик чагылдырылышындагы акыркы нөлдөрдүн санын кайтарат.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// `self` экилик өкүлчүлүгүндө алдыңкы орундардын санын кайтарат.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// `self` экилик чагылдырылышындагы акыркы адамдардын санын кайтарып берет.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// Алынган бүтүндүн аягына чейин кесилген биттерди ороп, биттерди белгиленген өлчөмдө `n` солго жылдырат.
        ///
        ///
        /// Сураныч, бул `<<` которуштуруу оператору менен бирдей иш эмес!
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// Кесилген биттерди пайда болгон сандын башына ороп, биттерди белгиленген өлчөмдө `n` оңго жылдырат.
        ///
        ///
        /// Сураныч, бул `>>` которуштуруу оператору менен бирдей иш эмес!
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// Бүтүн сандын байт иретин тескери бурат.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// m= n.swap_bytes() болсун;
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// Бүтүн сандагы биттердин ирээтин өзгөртөт.
        /// Эң аз мааниге ээ бит эң маанилүү битке, экинчи аз маанилүү бит экинчи эң маанилүү битке айланат ж.б.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// m= n.reverse_bits() болсун;
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// Бүткүл санды чоң эндиандан максаттуу максатка жетүү деңгээлине которот.
        ///
        /// Чоң эндиан боюнча, бул жокко эсе.Кичинекей байт менен алмаштырылган.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Бүткүл санды кичинекей эндиандан максаттуу максатка айлантуу.
        ///
        /// Кичинекей эми, бул жокко эсе.Чоң эндианда байттар алмаштырылат.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// `self` ти максаттуу деңгээлден чоң эндианга которот.
        ///
        /// Чоң эндиан боюнча, бул жокко эсе.Кичинекей байт менен алмаштырылган.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } else { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // же болбошу керекпи?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// `self` ти максаттуу деңгээлден кичине эндианга которот.
        ///
        /// Кичинекей эми, бул жокко эсе.Чоң эндианда байттар алмаштырылат.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } else { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Толук сан кошулду.
        /// Эгерде `self + rhs` эсептейт, ашып кетсе `None` кайтарып берет.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Белгиленбеген бүтүн сан.Ашуу мүмкүн эмес деп эсептесе, `self + rhs` эсептейт.
        /// Бул качан аныкталбаган жүрүм-турумга алып келет
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // КООПСУЗДУК: чалган адам `unchecked_add` үчүн коопсуздук келишимин сакташы керек.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Бүтүн санды алып салуу.
        /// Эгерде `self - rhs` эсептейт, ашып кетсе `None` кайтарып берет.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Белгиленбеген бүтүн санды алып салуу.Ашуу мүмкүн эмес деп эсептесе, `self - rhs` эсептейт.
        /// Бул качан аныкталбаган жүрүм-турумга алып келет
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // КООПСУЗДУК: чалган адам `unchecked_sub` үчүн коопсуздук келишимин сакташы керек.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Бүтүн санды көбөйтүү текшерилди.
        /// Эгерде `self * rhs` эсептейт, ашып кетсе `None` кайтарып берет.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Белгиленбеген бүтүн көбөйтүү.Ашуу мүмкүн эмес деп эсептесе, `self * rhs` эсептейт.
        /// Бул качан аныкталбаган жүрүм-турумга алып келет
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // КООПСУЗДУК: чалган адам `unchecked_mul` үчүн коопсуздук келишимин сакташы керек.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Белгиленген бүтүн бөлүү.
        /// `self / rhs` эсептейт, эгер `rhs == 0` же бөлүнүш ашып кетсе `None` кайтарып берет.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // КООПСУЗДУК: div нөлгө жана INT_MIN боюнча жогору текшерилген
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Евклиддик бөлүнүү.
        /// `self.div_euclid(rhs)` эсептейт, эгер `rhs == 0` же бөлүнүш ашып кетсе `None` кайтарып берет.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// Текшерилген бүтүн калдык.
        /// `self % rhs` эсептейт, эгер `rhs == 0` же бөлүнүш ашып кетсе `None` кайтарып берет.
        ///
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // КООПСУЗДУК: div нөлгө жана INT_MIN боюнча жогору текшерилген
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Текшерилген Евклид калдыгы.
        /// `self.rem_euclid(rhs)` эсептейт, эгер `rhs == 0` же бөлүнүш ашып кетсе `None` кайтарып берет.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Текшерилген жокко.
        /// `-self` эсептейт, `self == MIN` болсо `None` кайтарып берет.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Солго жылыш текшерилди.
        /// `self << rhs` эсептейт, эгер `rhs` `self` биттердин санынан чоң же ага барабар болсо, `None` кайтарып берет.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Оңго жылыш текшерилди.
        /// `self >> rhs` эсептейт, эгер `rhs` `self` биттердин санынан чоң же ага барабар болсо, `None` кайтарып берет.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Абсолюттук маани текшерилди.
        /// `self.abs()` эсептейт, `self == MIN` болсо `None` кайтарып берет.
        ///
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// Көрсөтүү деңгээли текшерилди.
        /// Эгерде `self.pow(exp)` эсептейт, ашып кетсе `None` кайтарып берет.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // exp!=0 болгондуктан, exp 1 болушу керек.
            // Экспоненттин акыркы битин өзүнчө караңыз, анткени андан кийин базаны квадраттап бөлүп алуу зарыл эмес жана ашыкча ташып кетиши мүмкүн.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Каныктыруучу бүтүн сан.
        /// Толтуруунун ордуна сандык чектерге каныккан `self + rhs` эсептейт.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Каныккан бүтүн санды азайтуу.
        /// Толтуруунун ордуна сандык чектерге каныккан `self - rhs` эсептейт.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Толтуруучу четке кагуу.
        /// `-self` ти эсептейт, эгер `self == MIN` ашып кетсе ордуна `MAX` кайтарып берет.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// Каныктыруучу абсолюттук маани.
        /// `self.abs()` ти эсептейт, эгер `self == MIN` ашып кетсе ордуна `MAX` кайтарып берет.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// Бүтүн санды көбөйтүү.
        /// Толтуруунун ордуна сандык чектерге каныккан `self * rhs` эсептейт.
        ///
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// Каныккан бүтүн көрсөткүч.
        /// Толтуруунун ордуна сандык чектерге каныккан `self.pow(exp)` эсептейт.
        ///
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// (modular) кошумчасын ороп жатат.
        /// `self + rhs` эсептейт, түрдүн чегинде айланып.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// (modular) алып салууну ороп.
        /// `self - rhs` эсептейт, түрдүн чегинде айланып.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// (modular) көбөйтүүнү ороо.
        /// `self * rhs` эсептейт, түрдүн чегинде айланып.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// (modular) бөлүмүн ороо.`self / rhs` эсептейт, түрдүн чегинде айланып.
        ///
        /// Мындай ороонун болушу мүмкүн болгон учур-бул `MIN / -1` ти кол коюлган типке бөлгөндө (бул жерде `MIN`-бул терс минималдуу мааниси);бул `-MIN` эквивалентине ээ, бул оң түрү, аны көрсөтүү үчүн өтө чоң.
        /// Мындай учурда, бул функция `MIN` өзү кайтарып берет.
        ///
        /// # Panics
        ///
        /// Эгер `rhs` 0 болсо, бул функция panic болот.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// Евклиддик бөлүнүүнү ороо.
        /// `self.div_euclid(rhs)` эсептейт, түрдүн чегинде айланып.
        ///
        /// Ороо `MIN / -1` форматында гана кол коюлган типте пайда болот (бул жерде `MIN` түр үчүн минус терс мааниге ээ).
        /// Бул `-MIN` эквивалентине ээ, ал оң мааниге ээ эмес, ал түрүндө көрсөтө албайт.
        /// Бул учурда, бул ыкма `MIN` өзү кайтарып берет.
        ///
        /// # Panics
        ///
        /// Эгер `rhs` 0 болсо, бул функция panic болот.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// (modular) калдыгын ороо.`self % rhs` эсептейт, түрдүн чегинде айланып.
        ///
        /// Мындай оролуу эч качан математикалык түрдө болбойт;ишке ашыруу артефакттары `x % y` `MIN / -1` үчүн кол коюлган түрү боюнча жараксыз кылат (бул жерде `MIN` терс минималдуу мааниси).
        ///
        /// Мындай учурда, бул функция `0` кайтарып берет.
        ///
        /// # Panics
        ///
        /// Эгер `rhs` 0 болсо, бул функция panic болот.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Евклид калдыктарын ороо.`self.rem_euclid(rhs)` эсептейт, түрдүн чегинде айланып.
        ///
        /// Ороо `MIN % -1` форматында гана кол коюлган типте пайда болот (бул жерде `MIN` түр үчүн минус терс мааниге ээ).
        /// Бул учурда, бул ыкма 0 кайтарат.
        ///
        /// # Panics
        ///
        /// Эгер `rhs` 0 болсо, бул функция panic болот.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// (modular) жокко чыгаруу.`-self` эсептейт, түрдүн чегинде айланып.
        ///
        /// Мындай ороонун болушу мүмкүн болгон учур-кол коюлган типтеги `MIN` ти жокко чыгарганда (бул жерде `MIN`-теринин минималдуу мааниси);бул түрүндө чагылдырууга мүмкүн болбогон оң мааниси.
        /// Мындай учурда, бул функция `MIN` өзү кайтарып берет.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic сиз жылышуу солго;`self << mask(rhs)` берет, мында `mask` кезектеги `rhs` битин алып салат, ал жылыштын түрдүн кеңдигинен ашып кетишине алып келет.
        ///
        /// Эскертүү, бул * солго бурулганга окшош эмес;LHSден жылдырылган биттер экинчи четине кайтарылбастан, оролуу солго RHS түрдүн диапазону менен чектелет.
        ///
        /// Алгачкы бүтүн сан түрлөрү [`rotate_left`](Self::rotate_left) функциясын ишке ашырышат, анын ордуна сиз каалаган нерсе болушу мүмкүн.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // КООПСУЗДУК: биттин өлчөмү менен маскалоо биздин жылышпагандыгыбызды камсыз кылат
            // чектен тышкары
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic акысыз жылышуу оңго;`self >> mask(rhs)` берет, мында `mask` кезектеги `rhs` битин алып салат, ал жылыштын түрдүн кеңдигинен ашып кетишине алып келет.
        ///
        /// Белгилей кетүүчү нерсе, бул *оңго бурулуу* менен бирдей эмес;LHS чегинен жылдырылган биттер экинчи четине кайтарылбастан, оролгон жылыш-оң RHS түрдүн диапазону менен чектелет.
        ///
        /// Алгачкы бүтүн сан түрлөрү [`rotate_right`](Self::rotate_right) функциясын ишке ашырышат, анын ордуна сиз каалаган нерсе болушу мүмкүн.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // КООПСУЗДУК: биттин өлчөмү менен маскалоо биздин жылышпагандыгыбызды камсыз кылат
            // чектен тышкары
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// (modular) абсолюттук маанисин ороо.`self.abs()` эсептейт, түрдүн чегинде айланып.
        ///
        /// Мындай оромдун пайда болушу мүмкүн болгон бирден-бир учур-бул тип үчүн терс минималдуу маанинин абсолюттук маанисин алганда;бул түрүндө чагылдырууга мүмкүн болбогон оң мааниси.
        /// Мындай учурда, бул функция `MIN` өзү кайтарып берет.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// `self` тин абсолюттук маанисин эч кандай оромосуз жана паникасыз эсептейт.
        ///
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// (modular) көрсөткүчүн ороо.
        /// `self.pow(exp)` эсептейт, түрдүн чегинде айланып.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // exp!=0 болгондуктан, exp 1 болушу керек.
            // Экспоненттин акыркы битин өзүнчө караңыз, анткени андан кийин базаны квадраттап бөлүп алуу зарыл эмес жана ашыкча ташып кетиши мүмкүн.
            //
            //
            acc.wrapping_mul(base)
        }

        /// `self` + `rhs` эсептейт
        ///
        /// Арифметикалык ашыкча таштоо болоорун көрсөткөн буль менен кошо кошумчанын кортежин кайтарып берет.
        /// Эгерде ашып кетсе, анда оролгон маани кайтарылып берилет.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self`, `rhs` эсептейт
        ///
        /// Арифметикалык ашыкча таштоо болобу же жокпу деген логикалык логону менен кошо азайтуунун кортежин кайтарат.
        /// Эгерде ашып кетсе, анда оролгон маани кайтарылып берилет.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` жана `rhs` көбөйтүүлөрүн эсептейт.
        ///
        /// Көбөйтүүнүн кортежин, ошондой эле арифметикалык ашып кетүү болобу же жокпу деген логикалык маани берет.
        /// Эгерде ашып кетсе, анда оролгон маани кайтарылып берилет.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, чындык));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` `rhs` ке бөлүнгөндө бөлүүчүнү эсептейт.
        ///
        /// Бөлүүчүнүн кортежин жана арифметикалык ашып кетүү болобу же болбогонун көрсөтөт.
        /// Эгерде ашып кетсе, анда өзү кайтарылат.
        ///
        /// # Panics
        ///
        /// Эгер `rhs` 0 болсо, бул функция panic болот.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// Евклиддик бөлүү `self.div_euclid(rhs)` бөлүгүн эсептейт.
        ///
        /// Бөлүүчүнүн кортежин жана арифметикалык ашып кетүү болобу же болбогонун көрсөтөт.
        /// Эгерде ашып кетсе, анда `self` кайтарылып берилет.
        ///
        /// # Panics
        ///
        /// Эгер `rhs` 0 болсо, бул функция panic болот.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// Калдыкты `self` `rhs` ке бөлгөндө эсептейт.
        ///
        /// Арифметикалык ашыкча таштоо болоорун көрсөткөн буль менен кошо бөлүнгөндөн кийин, калдыктын кортежин кайтарып берет.
        /// Эгерде ашып кетсе, 0 кайтарылат.
        ///
        /// # Panics
        ///
        /// Эгер `rhs` 0 болсо, бул функция panic болот.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// Толуп жаткан Евклид калдыгы.`self.rem_euclid(rhs)` эсептейт.
        ///
        /// Арифметикалык ашыкча таштоо болоорун көрсөткөн буль менен кошо бөлүнгөндөн кийин, калдыктын кортежин кайтарып берет.
        /// Эгерде ашып кетсе, 0 кайтарылат.
        ///
        /// # Panics
        ///
        /// Эгер `rhs` 0 болсо, бул функция panic болот.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// Минималдуу мааниге барабар болсо, өзүн-өзү жокко чыгарат.
        ///
        /// Толтуруу болгон-болбогондугун көрсөткөн логикалык версия менен кошо жокко чыгарылган версиянын кортежин кайтарат.
        /// Эгер `self` минималдуу мааниси болсо (мисалы, `i32` түрүндөгү баалуулуктар үчүн `i32::MIN`), анда минималдуу маани кайрадан кайтарылып, ашып кетсе `true` кайтарылып берилет.
        ///
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// `rhs` биттен калган өзүн-өзү жылдырат.
        ///
        /// Өзгөртүлгөн версиясынын кортежин логикалык кошулма менен которуу мааниси биттердин санынан чоң же барабар экендигин көрсөтөт.
        /// Эгерде жылыш мааниси өтө чоң болсо, анда (N-1) маскасы маскаланат, мында N-биттердин саны, жана андан кийин бул жылыш аткарылат.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, true));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Өзүн `rhs` бит менен жылдырат.
        ///
        /// Өзгөртүлгөн версиясынын кортежин логикалык кошулма менен которуу мааниси биттердин санынан чоң же барабар экендигин көрсөтөт.
        /// Эгерде жылыш мааниси өтө чоң болсо, анда (N-1) маскасы маскаланат, мында N-биттердин саны, жана андан кийин бул жылыш аткарылат.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, true));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// `self` тин абсолюттук маанисин эсептейт.
        ///
        /// Абсолюттук версиянын кортежин жана толуп кеткен-болбогонун көрсөткөн буль менен кошо кайтарат.
        /// Эгерде минималдуу маани
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// анда минималдуу маани кайрадан кайтарылат жана ашып кетсе, чыныгы кайтарылат.
        ///
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// Өзүн `exp` кубаттуулугуна көтөрүп, квадрат менен көрсөткүчтү колдонот.
        ///
        /// Толтуруу болгон-болбогонун көрсөткөн bool менен катар көрсөткүчтүн кортежин кайтарат.
        ///
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, true));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Толуп кеткен_mul натыйжаларын сактоо үчүн скретч мейкиндиги.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // exp!=0 болгондуктан, exp 1 болушу керек.
            // Экспоненттин акыркы битин өзүнчө караңыз, анткени андан кийин базаны квадраттап бөлүп алуу зарыл эмес жана ашыкча ташып кетиши мүмкүн.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// Өзүн `exp` кубаттуулугуна көтөрүп, квадрат менен көрсөткүчтү колдонот.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // exp!=0 болгондуктан, exp 1 болушу керек.
            // Экспоненттин акыркы битин өзүнчө караңыз, анткени андан кийин базаны квадраттап бөлүп алуу зарыл эмес жана ашыкча ташып кетиши мүмкүн.
            //
            //
            acc * base
        }

        /// Евклиддин `self` менен `rhs` бөлүү квоентин эсептейт.
        ///
        /// Бул `n` бүтүндөй `self = n * rhs + self.rem_euclid(rhs)`, `0 <= self.rem_euclid(rhs) < rhs` менен эсептейт.
        ///
        ///
        /// Башка сөз менен айтканда, жыйынтык `self / rhs` бүтүндөй `n` санына тегеректелет, мисалы `self >= n * rhs`.
        /// Эгер `self > 0` болсо, бул нөлгө карай тегеректөөгө барабар (Rust де демейки);
        /// эгер `self < 0` болсо, бул чексиздикке карай тегеректөөгө барабар +.
        ///
        /// # Panics
        ///
        /// Бул функция panic болот, эгер `rhs` 0 болсо же бөлүнүү ашып кетсе.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// b=4 болсун;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// `self (mod rhs)` тин эң аз терс эмес калдыгын эсептейт.
        ///
        /// Бул Евклидди бөлүштүрүү алгоритми боюнча жүргүзүлөт-`r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r` жана `0 <= r < abs(rhs)` берилген.
        ///
        ///
        /// # Panics
        ///
        /// Бул функция panic болот, эгер `rhs` 0 болсо же бөлүнүү ашып кетсе.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// b=4 болсун;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// `self` тин абсолюттук маанисин эсептейт.
        ///
        /// # Толуп-ташуу жүрүм-туруму
        ///
        /// Абсолюттук мааниси
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// катары көрсөтүлбөйт
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// жана аны эсептөө аракети ашып кетүүгө себеп болот.
        /// Демек, мүчүлүштүктөрдү оңдоо режиминдеги код panic ди иштетип, оптимизацияланган код кайтып келет
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// panic жок.
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // Жогорудагы#[сызык] алып салуунун ашыкча семантикасы биз кирген crate көз каранды экендигин билдирет.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// `self` белгисин көрсөткөн санды кайтарып берет.
        ///
        ///  - `0` эгер саны нөлгө барабар болсо
        ///  - `1` саны оң болсо
        ///  - `-1` эгер саны терс болсо
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// `self` оң болсо `true`, ал эми нөл же терс болсо `false` кайтарып берет.
        ///
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// Эгерде `self` терс болсо `true`, ал эми нөл же оң болсо `false` кайтарып берет.
        ///
        ///
        /// # Examples
        ///
        /// Негизги колдонуу:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// Бул бүтүн сандагы эс тутумду байт массиви катары чоң эндиан (network) байт иретинде кайтарыңыз.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Бул бүтүн сандагы эс тутумду байт массиви катары аз-азыраак байт иретинде кайтарыңыз.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Бул бүтүндүн эс тутумун байт катарында байт катарында кайтарыңыз.
        ///
        /// Максаттуу платформанын энеандыгы колдонулгандыктан, анын ордуна портативдик код [`to_be_bytes`] же [`to_le_bytes`] колдонушу керек.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     байт, эгерде cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } else {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // КООПСУЗДУК: const үнү, анткени бүтүн сандар жөнөкөй эски маалыматтардын типтери болгондуктан, биз ар дайым колдоно алабыз
        // аларды байт массивдерине өткөрүү
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // КООПСУЗДУК: бүтүн сандар-бул кадимки эски берилмелердин түрлөрү, ошондуктан аларды ар дайым өзгөртө алабыз
            // байт массивдери
            unsafe { mem::transmute(self) }
        }

        /// Бул бүтүндүн эс тутумун байт катарында байт катарында кайтарыңыз.
        ///
        ///
        /// [`to_ne_bytes`] мүмкүн болушунча буга караганда артыкчылык берилиши керек.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// байт= num.as_ne_bytes();
        /// assert_eq!(
        ///     байт, эгерде cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } else {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // КООПСУЗДУК: бүтүн сандар-бул кадимки эски берилмелердин түрлөрү, ошондуктан аларды ар дайым өзгөртө алабыз
            // байт массивдери
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Чоң эндиандагы байт массиви катары берилгенден бүтүн маанини түзүңүз.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto колдонуу;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * киргизүү=эс алуу;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Кичине эндиандагы байт массиви катары анын бүтүндүгүнүн маанисин түзүңүз.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto колдонуу;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * киргизүү=эс алуу;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Анын эс тутумунун түпнуска маанисинде байт массиви катары бүтүн санды түзүңүз.
        ///
        /// Максаттуу платформанын энеандыгы колдонулгандыктан, портативдик код ордуна [`from_be_bytes`] же [`from_le_bytes`] колдонууну каалайт.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } else {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto колдонуу;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * киргизүү=эс алуу;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // КООПСУЗДУК: const үнү, анткени бүтүн сандар жөнөкөй эски маалыматтардын типтери болгондуктан, биз ар дайым колдоно алабыз
        // аларга трансмут
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // КООПСУЗДУК: сандар жөнөкөй эски берилиштердин типтери, ошондуктан биз аларды ар дайым өзгөртө алабыз
            unsafe { mem::transmute(bytes) }
        }

        /// Жаңы код колдонууну туура көрүшү керек
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Ушул бүтүн түрү менен чагылдырылышы мүмкүн болгон эң кичине маанини берет.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// Жаңы код колдонууну туура көрүшү керек
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Ушул бүтүн түр менен көрсөтүлө турган эң чоң маанини кайтарып берет.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}