//! Интегралдык типтерге өткөрүүдө каталардын түрлөрү.

use crate::convert::Infallible;
use crate::fmt;

/// Текшерилген интегралдык типтеги конверсия болбой калса, ката түрү кайтарылды.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Жогорудагы `From<Infallible> for TryFromIntError` сыяктуу код `Infallible` `!` үчүн каймана ат болуп калганда, иштей берээрине ынануу үчүн эмес, дал келүү.
        //
        //
        match never {}
    }
}

/// Бүтүн санды талдоодо кайтарылып берилүүчү ката.
///
/// Бул ката [`i8::from_str_radix`] сыяктуу алгачкы бүтүн типтердеги `from_str_radix()` функциялары үчүн ката түрү катары колдонулат.
///
/// # Мүмкүн болгон себептер
///
/// Башка себептерден тышкары, `ParseIntError` саптагы боштуктун артында же артында болгондуктан, ыргытылышы мүмкүн, мисалы, стандарттык кириштен алынганда.
///
/// [`str::trim()`] ыкмасын колдонуу менен, талдоодон мурун боштук калбайт.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Бүтүн санды талдабай калууга алып келиши мүмкүн болгон каталардын ар кандай түрлөрүн сактоо үчүн Enum.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Талдоо мааниси бош.
    ///
    /// Башка себептерден тышкары, бул вариант бош сапты талдоо учурунда курулат.
    Empty,
    /// Анын контекстинде жараксыз цифраны камтыйт.
    ///
    /// Башка себептерден тышкары, бул вариант ASCII эмес чарты камтыган сапты талдоо учурунда курулат.
    ///
    /// Бул вариант ошондой эле `+` же `-` саптын арасына өз алдынча же сан ортосунда жайгаштырылганда курулат.
    ///
    ///
    InvalidDigit,
    /// Бүтүн сан өтө чоң, максаттуу бүтүн санда сактай албайсыз.
    PosOverflow,
    /// Бүтүн сан кичинекей болгондуктан, максаттуу бүтүн санда сакталбайт.
    NegOverflow,
    /// Наркы нөл болчу
    ///
    /// Бул вариант ноль маанисине ээ болгондо чыгарылат, ал нөлгө жатпаган типтер үчүн мыйзамсыз болот.
    ///
    Zero,
}

impl ParseIntError {
    /// Бүтүн санды талдоонун деталдуу себебин чыгарат.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}