//! Өтө чоң мааниге ээ болбогон битумдар үчүн пайдалуу функциялар.

// FIXME Бул модулдун аталышы бир аз өкүнүчтүү, анткени башка модулдар `core::num` импорт кылат.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Бардык биттерди `ones_place` тен анча маанилүү эмес деп кыскартуу салыштырмалуу катаны 0.5 ULPден азыраак, барабар же чоңураак кылабы же жокпу, текшерип көрүңүз.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Эгерде калган биттердин бардыгы нөлгө барабар болсо, анда бул= 0.5 ULP, болбосо> 0.5 Эгерде биттер жок болсо (half_bit==0), төмөндө келтирилгендер дагы барабар болуп саналат.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Ондук сандарды гана камтыган ASCII сабын `u64` форматына которот.
///
/// Толуп кеткен же жараксыз белгилерди текшербейт, андыктан чалган адам этият болбосо, натыйжасы жасалма жана panic болот (бирок `unsafe` болбойт).
/// Кошумча, бош саптар нөл катары эсептелет.
/// Бул функция бар, анткени
///
/// 1. `&[u8]` те `FromStr` колдонуп, `from_utf8_unchecked` талап кылынат, бул жаман жана
/// 2. `integral.parse()` жана `fractional.parse()` натыйжаларын бириктирүү бул бүтүндөй функцияга караганда кыйла татаал.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// ASCII цифралар сабын чоңдукка которот.
///
/// `from_str_unchecked` сыяктуу эле, бул функция сандарды жок кылуу үчүн талдоочуга таянат.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Бигнумду 64 бит бүтүн санга чыгарат.Саны өтө көп болсо Panics.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Биттин бир катар бөлүгүн бөлүп алат.

/// Индекс 0 эң аз мааниге ээ жана диапазон адаттагыдай эле жарым-жартылай ачык.
/// Panics, эгер кайтаруу түрүнө туура келбегенден көп бит чыгарууну суранса.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}