//! Форманын ондук сабын тастыктоо жана ажыроо:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Башка сөз менен айтканда, эки өзгөчөлүктү эске албаганда, калкып жүрүүчү чекиттүү синтаксис: Белги жок жана "inf" жана "NaN" менен иштөө жок.Буларды айдоочу (super::dec2flt) функциясы башкарат.
//!
//! Жарактуу киргизүүлөрдү таануу салыштырмалуу оңой болгонуна карабастан, бул модуль panic деген сансыз жараксыз вариацияларды четке кагышы керек жана башка модулдар өз кезегинде panic (же толуп кетпеши) таянган көптөгөн текшерүүлөрдү жүргүзүшү керек.
//!
//! Андан да жаманы, мунун бардыгы бир эле өтүүдө болот.
//! Ошентип, бир нерсени өзгөртүүдө этият болуңуз жана башка модулдар менен дагы бир жолу текшериңиз.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Ондук саптын кызыктуу бөлүктөрү.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Ондук көрсөткүч, 18ден аз ондук сандардан кем болбошу керек.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Киргизилген тилкенин жарактуу калкып жүрүүчү чекиттин номери экендигин текшерет жана эгерде анда интегралдык бөлүктү, бөлчөк бөлүктү жана көрсөткүчтү табыңыз.
/// Белгилер менен иштебейт.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // 'e' чейин цифралар жок
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Биз пункттан мурун же андан кийин жок дегенде бир цифраны талап кылабыз.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Бөлчөк бөлүктүн артынан калдыктар
            }
        }
        _ => Invalid, // Биринчи орундуу саптан кийин керексиз нерселерди издөө
    }
}

/// Биринчи цифралык эмес белгиге чейин ондук сандарды өчүрөт.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Көрсөтмөлөрдү бөлүп алуу жана каталарды текшерүү.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Экспоненттен кийин керексиз нерселерди издөө
    }
    if number.is_empty() {
        return Invalid; // Бош көрсөткүч
    }
    // Бул учурда, бизде, албетте, цифралардын жарактуу сабы бар.`i64` ке салуу өтө узун болушу мүмкүн, бирок эгер ал ушунчалык зор болсо, анда киргизүү, албетте, нөлгө же чексиздикке барабар.
    // Ондук цифралардын ар бир нөлү көрсөткүчтү +/-1 менен гана жөнгө салгандыктан, exp=10 ^ 18 болгондо, чектүү болууга алыстан алыстап кетүү үчүн, 17 экзабайт (!) нөлдү түзүшү керек.
    //
    // Бул так биз колдонушубуз керек болгон учур эмес.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}