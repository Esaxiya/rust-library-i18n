//! Позитивдүү IEEE 754 калкып өткөндө бир аз кыйналат.Терс сандар менен иштөө талап кылынбайт жана керек эмес.
//! Кадимки калкып чыккан чекит сандарынын мааниси (exp, exp) каноникалык чагылдырылышына ээ, мисалы, мааниси 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)), бул жерде N-биттердин саны).
//!
//! Subnormals бир аз башкача жана кызыктай, бирок ошол эле принцип колдонулат.
//!
//! Бирок бул жерде биз аларды (sig, k) f оң мааниси менен көрсөтөбүз, мисалы, мааниси f *
//! 2 <sup>e</sup> ."hidden bit" ачык жасоодон тышкары, бул көрсөткүчтү мантисса жылышы деп аталган нерсе өзгөртөт.
//!
//! Башка жол менен айтканда, адатта флоттор (1) деп жазылат, бирок бул жерде (2) деп жазылат:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Биз (1)**фракциялык чагылдыруу** жана (2)**интегралдык өкүлчүлүк** деп атайбыз.
//!
//! Бул модулдагы көптөгөн функциялар кадимки сандарды гана иштетет.Dec2flt эрежелери өтө кичинекей жана өтө чоң сандар үчүн универсалдуу туура жай жолду (Алгоритм М) консервативдүү жол менен жүргүзөт.
//! Бул алгоритмге субмормалдарды жана нөлдөрдү башкарган next_float() гана керек.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Жардамчы trait, `f32` жана `f64` үчүн негизинен бардык конверсиялык коддордун кайталанбашы үчүн.
///
/// Бул эмне үчүн зарыл экендигин ата-эне модулунун документтик комментарийинен караңыз.
///
/// **эч качан** эч качан ** башка түрлөрү үчүн колдонулбашы керек же dec2flt модулунан тышкары колдонулбашы керек.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// `to_bits` жана `from_bits` колдонгон түрү.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Чийки трансмутацияны бүтүн санга аткарат.
    fn to_bits(self) -> Self::Bits;

    /// Бүтүндөй сандан баштап чийки трансмутацияны жасайт.
    fn from_bits(v: Self::Bits) -> Self;

    /// Бул сан кирген категорияны кайтарып берет.
    fn classify(self) -> FpCategory;

    /// Мантисса, көрсөткүч жана белгини бүтүндөй сандар катары кайтарат.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Флоттун кодун чечмелейт.
    fn unpack(self) -> Unpacked;

    /// Так чагылдырылышы мүмкүн болгон кичинекей бүтүн сандан чыгарылат.
    /// Эгерде Panic бүтүн сандын берилиши мүмкүн эмес болсо, анда бул модулдагы башка код эч качан андай болбошу керек.
    fn from_int(x: u64) -> Self;

    /// Алдын ала эсептелген таблицадан 10 <sup>e</sup> маанисин алат.
    /// `e >= CEIL_LOG5_OF_MAX_SIG` үчүн Panics.
    fn short_fast_pow10(e: usize) -> Self;

    /// Аты эмне дейт.
    /// Ички сезимдерди жонглёрлоп, LLVM туруктуу бүктөлөт деп үмүттөнгөндөн кийин, кодду жазуу оңой.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Толуп же нөлгө чыгара албаган кириштердин ондук сандарына байланыштуу консервативдик байланыш
    /// subnormals.Балким, максималдуу нормалдуу маанинин ондук көрсөткүчү, демек, аталышы.
    const MAX_NORMAL_DIGITS: usize;

    /// Эң маанилүү ондук цифрасынын орун мааниси андан чоңураак болгондо, алардын саны чексиздикке чейин тегеректелет.
    ///
    const INF_CUTOFF: i64;

    /// Эң маанилүү ондук цифрасынын орун мааниси андан төмөн болгондо, анын саны нөлгө чейин тегеректелет.
    ///
    const ZERO_CUTOFF: i64;

    /// Экспоненттеги биттердин саны.
    const EXP_BITS: u8;

    /// Жашыруун битти камтыган * маанилүүдөгү биттердин саны.
    const SIG_BITS: u8;

    /// Жашырылган битти кошпогондо * маанилүүдөгү биттердин саны.
    const EXPLICIT_SIG_BITS: u8;

    /// Бөлчөк өкүлчүлүктөгү максималдуу юридикалык көрсөткүч.
    const MAX_EXP: i16;

    /// Субнормальдарды эске албаганда, фракциялык өкүлчүлүктөгү минималдуу юридикалык көрсөткүч.
    const MIN_EXP: i16;

    /// `MAX_EXP` интегралдык чагылдыруу үчүн, башкача айтканда, нөөмөттү колдонуу менен.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` коддолгон (б.а., жылышуу менен)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` интегралдык чагылдыруу үчүн, башкача айтканда, нөөмөттү колдонуу менен.
    const MIN_EXP_INT: i16;

    /// Интегралдык чагылдырууда максималдуу нормаланган мааниге ээ.
    const MAX_SIG: u64;

    /// Интегралдык чагылдырууда минималдуу нормалдаштырылган мааниге ээ.
    const MIN_SIG: u64;
}

// Негизинен #34344 үчүн чечүү жолу.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Мантисса, көрсөткүч жана белгини бүтүндөй сандар катары кайтарат.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Көрсөтүүчү жактуулук + мантисса жылышы
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe `as` бардык платформаларда туура тегеренеби же жокпу белгисиз.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Мантисса, көрсөткүч жана белгини бүтүндөй сандар катары кайтарат.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Көрсөтүүчү жактуулук + мантисса жылышы
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe `as` бардык платформаларда туура тегеренеби же жокпу белгисиз.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// `Fp` файлын эң жакынкы флот түрүнө которот.
/// Нормалдуу эмес натыйжаларга жооп бербейт.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 бит, ошондуктан xeнин мантисса жылышы 63кө барабар
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// 64 биттик маанини T::SIG_BITS битке чейин жуп-жупка чейин тегеректеңиз.
/// Көрсөтмөнүн ашып кетишине жол бербейт
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Мантиссанын жылышын жөндөңүз
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Нормалдашкан сандар үчүн `RawFloat::unpack()` тескери.
/// Panics, эгерде белгилер же көрсөткүч нормалдашкан сандар үчүн жараксыз болсо.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Жашырылган битти алып салыңыз
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Көрсөтүүчү жактуулук жана мантисса жылышы үчүн көрсөткүчтү жөндөңүз
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // 0 ("+") деңгээлинде бит белгисин калтырыңыз, биздин сандардын бардыгы оң
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Субнормалдуу куруу.0 мантиссасына жол берилет жана нөлдү курат.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Коддолгон көрсөткүч 0, белги бит 0, андыктан биз биттерди кайрадан чечмелешибиз керек.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Fp менен боёкту болжолдуу эсептөө.0.5 ULP ичинде жарым-жартылай тегеректелет.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // `start` индексине чейин биз бардык биттерди бөлүп алдык, башкача айтканда, биз `start` өлчөмүндө оңго жылдырдык, ошондуктан бул дагы бизге керек көрсөткүч.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Кесилген биттерге жараша (half-to-even) тегерек.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Аргументтен бир аз кичинекей чоң калкып чыккан чекиттин санын табат.
/// Нормаль, нөл же экспоненттик ылдый агымдарды иштетпейт.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Аргументтен чоңураак чоң калкып чыккан чекиттин санын табыңыз.
// Бул иш каныктырат, б.а., next_float(inf) ==inf.
// Бул модулдагы көпчүлүк коддордон айырмаланып, бул функция нөл, субнормаль жана чексиздиктерди иштетет.
// Бирок, башка бардык коддор сыяктуу эле, ал NaN жана терс сандар менен иштешпейт.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Бул чындык болуш үчүн өтө жакшы окшойт, бирок ал иштейт.
        // 0.0 нөлгө барабар сөз катары коддолгон.Субнормальдар 0х000м ... м, м-де-мантисса.
        // Атап айтканда, эң кичине субнормалдуу 0x0 ... 01, ал эми эң чоңу 0x000F ... F.
        // Эң кичинекей кадимки сан 0x0010 ... 0 болгондуктан, бул бурчтук корпус дагы иштейт.
        // Эгерде көбөйүү мантиссага ашып кетсе, анда көтөрүү бит көрсөткүчтү биз каалагандай көбөйтөт жана мантисса биттери нөлгө айланат.
        // Жашыруун биттик конвенция болгондуктан, бул да биз каалагандай!
        // Акыры, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}