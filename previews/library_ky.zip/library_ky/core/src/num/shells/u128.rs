//! 128 биттик кол коюлбаган бүтүн сан үчүн туруктуу.
//!
//! *[See also the `u128` primitive type][u128].*
//!
//! Жаңы код байланышкан туруктуу адамдарды примитивдик типте түздөн-түз колдонушу керек.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u128`"
)]

int_module! { u128, #[stable(feature = "i128", since="1.26.0")] }