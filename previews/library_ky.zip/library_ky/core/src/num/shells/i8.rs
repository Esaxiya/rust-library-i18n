//! 8-бит кол коюлган бүтүн сан үчүн туруктуу.
//!
//! *[See also the `i8` primitive type][i8].*
//!
//! Жаңы код байланышкан туруктуу адамдарды примитивдик типте түздөн-түз колдонушу керек.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i8`"
)]

int_module! { i8 }