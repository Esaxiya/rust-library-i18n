//! Калкыма чекиттин маанисин айрым бөлүктөргө жана ката диапазонуна чечмелейт.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Декоддолгон кол коюлбаган чектүү маани, мисалы:
///
/// - Түпнуска `mant * 2^exp` барабар.
///
/// - `(mant - minus)*2^exp` тен `(mant + plus)* 2^exp` ке чейинки ар кандай номер баштапкы мааниге чейин айланат.
/// `inclusive` `true` болгондо гана диапазон камтылат.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Масштабдуу мантисса.
    pub mant: u64,
    /// Төмөнкү ката диапазону.
    pub minus: u64,
    /// Жогорку ката диапазону.
    pub plus: u64,
    /// 2-базанын жалпы көрсөткүчү.
    pub exp: i16,
    /// Каталар диапазону кошулганда туура.
    ///
    /// IEEE 754те, бул баштапкы мантисса жуп болгондо туура болот.
    pub inclusive: bool,
}

/// Кол коюлбаган маани чечмеленди.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Оң же терс чексиздиктер.
    Infinite,
    /// Нөл, оң же терс.
    Zero,
    /// Андан ары декоддолгон талаалар менен чектелген сандар.
    Finite(Decoded),
}

/// "Decode`d" болушу мүмкүн калкыма чекит түрү.
pub trait DecodableFloat: RawFloat + Copy {
    /// Минималдуу оң нормалдаштырылган маани.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Берилген жылма чекит номеринен белгини (терс болгондо чыныгы) жана `FullDecoded` маанисин кайтарып берет.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // кошуналар: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode ар дайым көрсөткүчтү сактайт, ошондуктан мантисса субнормаль үчүн масштабдалат.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // кошуналар: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // бул жерде maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // кошуналар: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}