#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Компилятордун камтылган типтеринин макетинин структуралык аныктамаларын камтыйт.
//!
//! Алар түздөн-түз чийки өкүлчүлүктөрдү манипуляциялоо үчүн кооптуу коддогу трансмуттардын максаты катары колдонулушу мүмкүн.
//!
//!
//! Алардын аныктамасы ар дайым `rustc_middle::ty::layout` те аныкталган ABIге дал келиши керек.
//!

/// `&dyn SomeTrait` сыяктуу trait объектинин чагылдырылышы.
///
/// Бул структура `&dyn SomeTrait` жана `Box<dyn AnotherTrait>` сыяктуу типтерге ээ.
///
/// `TraitObject` макеттерге дал келиши кепилденген, бирок ал trait объектилеринин түрүнө кирбейт (мисалы, талааларга `&dyn SomeTrait` түздөн-түз кире албайт) жана ал планды көзөмөлдөбөйт (аныктаманы өзгөртүү `&dyn SomeTrait` схемасын өзгөртпөйт).
///
/// Ал кооптуу код менен гана иштелип чыккан, анткени төмөнкү деңгээлдеги детальдарды иштетүү керек.
///
/// Бардык trait объектилерине жалпылап кайрылуунун жолу жок, ошондуктан бул түрдөгү баалуулуктарды [`std::mem::transmute`][transmute] сыяктуу функциялар түзүүнүн бирден-бир жолу.
/// Ошо сыяктуу эле, `TraitObject` маанисинен чыныгы trait объектисин түзүүнүн бирден-бир жолу-`transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// trait объектисин туура келбеген типтер менен синтездөө-бул vtable маалымат көрсөткүчү көрсөткөн маанинин түрүнө дал келбесе, анда аныкталбаган жүрүм-турумга алып келиши мүмкүн.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // мисалы trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // компилятор trait объектисин жасасын
/// let object: &dyn Foo = &value;
///
/// // чийки өкүлчүлүгүн карап
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // маалымат көрсөткүчү-`value` дареги
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // `object` ден `i32` vtable колдонуудан этият болуп, башка `i32` көрсөтүп, жаңы объект куруу
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // ал `other_value` түздөн-түз trait объектисин кургандай эле иштеши керек
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}