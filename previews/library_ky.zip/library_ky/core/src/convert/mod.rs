//! Traits түрлөрү ортосундагы которуштуруу үчүн.
//!
//! Бул модулдагы traits бир түрдөн экинчи түргө өтүү мүмкүнчүлүгүн берет.
//! Ар бир trait ар башка максатты көздөйт:
//!
//! - [`AsRef`] trait ти арзан шилтеме менен шилтеме үчүн жүзөгө ашырыңыз
//! - [`AsMut`] trait ди арзан өзгөрүлмө-өзгөрүлмө конверсиялар үчүн жүзөгө ашырыңыз
//! - [`From`] trait маанини мааниге которууну керектөө үчүн ишке ашырыңыз
//! - Учурдагы crate ден тышкаркы түрлөргө мааниге которууну керектөө үчүн [`Into`] trait'ти ишке ашырыңыз
//! - [`TryFrom`] жана [`TryInto`] traits [`From`] жана [`Into`] сыяктуу иштешет, бирок конверсия болбой калышы мүмкүн.
//!
//! Бул модулдагы traits көбүнчө trait bounds катары жалпы функциялар үчүн колдонулат, мисалы, бир нече түрдөгү аргументтерге колдоо көрсөтүлөт.Мисалдар үчүн ар бир trait дин документтерин караңыз.
//!
//! Китепкананын автору катары сиз [`Into<U>`][`Into`] же [`TryInto<U>`][`TryInto`] эмес, [`From<T>`][`From`] же [`TryFrom<T>`][`TryFrom`] программаларын колдонууну артык көрүшүңүз керек, анткени [`From`] жана [`TryFrom`] ийкемдүүлүктү камсыз кылат жана [`Into`] же [`TryInto`] шаймандарын стандарттык китепканада жууркан жүзөгө ашыруунун аркасында акысыз сунуштайт.
//! Rust 1.41 чейин версияны багыттоодо, учурдагы crate тышкаркы түргө өткөндө, [`Into`] же [`TryInto`] түздөн-түз ишке ашырылышы мүмкүн.
//!
//! # Жалпы ишке ашыруу
//!
//! - [`AsRef`] жана ички түрү шилтеме болсо, [`AsMut`] авто-ажыратуу
//! - [`From`]`<U>үчүн T` [Into`] дегенди билдирет</u><T><U>U` үчүн</u>
//! - [`TryFrom`]`<U>үчүн T` [`TryInto`]"дегенди билдирет</u><T><U>U` үчүн</u>
//! - [`From`] жана [`Into`] рефлексивдүү, демек, бардык түрлөрү өзүлөрү `into` жана `from` өзү болот
//!
//! Колдонуу мисалдары үчүн ар бир trait караңыз.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Идентификация функциясы.
///
/// Бул функция жөнүндө эки нерсени белгилей кетүү керек:
///
/// - Бул ар дайым `|x| x` сыяктуу жабылууга барабар эмес, анткени жабуу `x` ны башка түргө түртүшү мүмкүн.
///
/// - Бул функцияга өткөн `x` киргизүүнү жылдырат.
///
/// Кирүүнү кайтарып бере турган функция иштөө кызыктай сезилгени менен, кызыктуу жерлери бар.
///
///
/// # Examples
///
/// Башка, кызыктуу функциялардын катарында эч нерсе жасабоо үчүн `identity` колдонуу:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Бирөөсүн кошуу кызыктуу функция деп коёлу.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// `identity` ти "do nothing" базалык иши катары шарттуу түрдө колдонуу:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Дагы кызыктуу нерселерди жасаңыз ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `Option<T>` итераторунун `Some` варианттарын сактоо үчүн `identity` колдонуу:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Шилтемеге шилтемени арзан которуу үчүн колдонулат.
///
/// Бул trait өзгөрүлмө шилтемелердин ортосунда конверттөө үчүн колдонулган [`AsMut`] ке окшош.
/// Эгерде сизге кымбат конверсия керек болсо, анда [`From`] түрүн `&T` менен ишке ашырганыңыз же колдонуучунун функциясын жазганыңыз оң.
///
/// `AsRef` [`Borrow`] сыяктуу эле кол тамгага ээ, бирок [`Borrow`] бир нече аспектилери боюнча айырмаланат:
///
/// - `AsRef` тен айырмаланып, [`Borrow`] кандайдыр бир `T` үчүн жууркан имплине ээ жана аны шилтеме же маанини кабыл алуу үчүн колдонсо болот.
/// - [`Borrow`] ошондой эле карызга алынган нарк үчүн [`Hash`], [`Eq`] жана [`Ord`] ээ болгон наркка барабар экендигин талап кылат.
/// Ушул себептен, сиз бир гана структуранын талаасын карызга алгыңыз келсе, `AsRef` программасын ишке ашыра аласыз, бирок [`Borrow`] эмес.
///
/// **Note: Бул trait бузулбашы керек **.Эгер конверсия ишке ашпай калса, анда [`Option<T>`] же [`Result<T, E>`] кайтаруучу атайын ыкманы колдонуңуз.
///
/// # Жалпы ишке ашыруу
///
/// - `AsRef` ички түрү шилтеме же өзгөрүлмө шилтеме болсо (мисалы:) `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds колдонуп, биз `T` көрсөтүлгөн түрүнө өтсө болот, ар кандай типтеги аргументтерди кабыл алабыз.
///
/// Мисалы: `AsRef<str>` ти кабыл алган жалпы функцияны түзүп, биз [`&str`] ге айландырыла турган бардык шилтемелерди аргумент катары кабыл алгыбыз келет.
/// [`String`] жана [`&str`] экөө тең `AsRef<str>` ти ишке ашыргандыктан, экөөнү тең киргизүү аргументи катары кабыл алабыз.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Конверсияны жүргүзөт.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Өзгөрүлө турган нерсени өзгөрүлмөгө арзан которууну жасоо үчүн колдонулат.
///
/// Бул trait [`AsRef`] окшош, бирок өзгөрүлмө шилтемелердин ортосунда конверттөө үчүн колдонулат.
/// Эгерде сизге кымбат конверсия керек болсо, анда [`From`] түрүн `&mut T` менен ишке ашырганыңыз же колдонуучунун функциясын жазганыңыз оң.
///
/// **Note: Бул trait бузулбашы керек **.Эгер конверсия ишке ашпай калса, анда [`Option<T>`] же [`Result<T, E>`] кайтаруучу атайын ыкманы колдонуңуз.
///
/// # Жалпы ишке ашыруу
///
/// - `AsMut` ички түрү өзгөрүлмө шилтеме болсо, авто-өчүрүүлөр (мисалы: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Жалпы функция үчүн `AsMut` ти trait bound катары колдонуп, биз `&mut T` түрүнө өткөрүлүп берилүүчү бардык өзгөрүлмө шилтемелерди кабыл алабыз.
/// [`Box<T>`] `AsMut<T>` ти ишке ашыргандыктан, `&mut u64` ке которула турган бардык аргументтерди алган `add_one` функциясын жаза алабыз.
/// [`Box<T>`] `AsMut<T>` ти ишке ашыргандыктан, `add_one` `&mut Box<u64>` тибиндеги аргументтерди да кабыл алат:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Конверсияны жүргүзөт.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Киргизилген наркты керектөөчү мааниге которуу.[`From`] карама-каршы.
///
/// [`Into`] ти колдонуудан качып, анын ордуна [`From`] ти ишке ашыруу керек.
/// [`From`] ти ишке киргизүү автоматтык түрдө стандарттык китепканада жуурканды ишке ашыруунун аркасында [`Into`] программасын ишке ашырат.
///
/// Жалпы функцияларда trait bounds көрсөтүүдө [`Into`] ти [`From`] ке караганда, [`Into`] ти гана колдонгон түрлөрдүн колдонулушун камсыз кылыңыз.
///
/// **Note: Бул trait бузулбашы керек **.Эгер конверсия ишке ашпай калса, [`TryInto`] колдонуңуз.
///
/// # Жалпы ишке ашыруу
///
/// - [`From`]"<T>анткени U` `Into<U> for T` ти билдирет
/// - [`Into`] рефлексивдүү, демек `Into<T> for T` ишке ашырылат
///
/// # [`Into`] ти Rust дин эски версияларында тышкы түрлөргө которуу үчүн ишке ашыруу
///
/// Rust 1.41 чейин, көздөгөн түрү учурдагы crate курамына кирбесе, анда сиз [`From`] түздөн-түз колдоно албайсыз.
/// Мисалы, ушул кодду алыңыз:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Бул тилдин эски версияларында түзүлбөй калат, анткени Rust дин жетим эрежелери бир аз катуураак болчу.
/// Муну айланып өтүү үчүн, [`Into`] ти түздөн-түз колдонсоңуз болот:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// [`Into`] бир [`From`] ишке ашырууну камсыз кылбайт деп түшүнүү маанилүү ([`From`] [`Into`] сыяктуу эле).
/// Ошондуктан, [`From`] ти колдонууга аракет кылып, [`From`] ишке ашпай калса, кайра [`Into`] ге түшүшүңүз керек.
///
/// # Examples
///
/// [`String`] ишке ашырат [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Жалпы функциянын көрсөтүлгөн `T` түрүнө өткөрүлө турган бардык аргументтерди кабыл алышын каалаш үчүн, биз trait bound [[Into`]"колдоно алабыз<T>".
///
/// Мисалы: `is_hello` функциясы [`Vec`]`<`[`u8`] `>` айландырыла турган бардык аргументтерди алат.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Конверсияны жүргүзөт.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Киргизилген наркты сарптап жатып, баалуулуктан мааниге которууну жасоо үчүн колдонулат.Бул [`Into`] өз ара.
///
/// Ар дайым `From` ти [`Into`] тен артык көрүшү керек, анткени `From` ти ишке ашыруу автоматтык түрдө стандарттык китепканада жуурканды ишке ашыруунун аркасында [`Into`] ишке ашат.
///
///
/// [`Into`] ти Rust 1.41 чейин нускасын бутага алганда жана учурдагы crate тышындагы түргө которгондо гана ишке ашырыңыз.
/// `From` Rust жетим эрежелеринен улам, ушул түрдөгү которууларды мурунку версияларда жасай алган жок.
/// Көбүрөөк маалымат алуу үчүн [`Into`] караңыз.
///
/// Жалпы функцияларга trait bounds көрсөтүүдө [`Into`] колдонгондон көрө `From` колдонгуңуз келет.
/// Ошентип, [`Into`] түздөн-түз жүзөгө ашырган түрлөрү, ошондой эле аргумент катары колдонсо болот.
///
/// `From` ката менен иштөөнү жүргүзүүдө да абдан пайдалуу.Иштей албаган функцияны курганда, кайтарым түрү көбүнчө `Result<T, E>` формасында болот.
/// `From` trait функциясы бир нече ката түрүн камтыган бир ката түрүн кайтарып берүү менен, ката менен иштөөнү жөнөкөйлөтөт.Көбүрөөк маалымат алуу үчүн "Examples" бөлүмүн жана [the book][book] ти караңыз.
///
/// **Note: Бул trait бузулбашы керек **.Эгер конверсия ишке ашпай калса, [`TryFrom`] колдонуңуз.
///
/// # Жалпы ишке ашыруу
///
/// - `From<T> for U` <U>T`үчүн</u> [`Into`]" билдирет
/// - `From` рефлексивдүү, демек `From<T> for T` ишке ашырылат
///
/// # Examples
///
/// [`String`] жүзөгө ашырат `From<&str>`:
///
/// `&str` тен Stringге конверсия төмөнкүдөй жасалат:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Ката менен иштөөнү жүргүзүүдө, `From` ти өзүнүн ката түрүнө ылайыкташтыруу пайдалуу.
/// Негизги ката түрлөрүн негизги ката түрүн камтыган өзүбүздүн колдонуучу ката түрүбүзгө өткөрүү менен, бирден-бир ката түрүн негизги себеби жөнүндө маалыматты жоготпой кайтарып алабыз.
/// '?' оператору `From` ишке киргизилгенде автоматтык түрдө камсыздалган `Into<CliError>::into` чалуу аркылуу автоматтык түрдө негизги ката түрүн биздин колдонуучунун ката түрүнө өткөрөт.
/// Андан кийин компилятор `Into` кандай колдонулушун колдонушу керектигин көрсөтөт.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Конверсияны жүргүзөт.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Кымбатка турбашы же болбошу мүмкүн болгон `self` ти керектеген конверсия аракети.
///
/// Китепкананын авторлору, адатта, бул trait программасын түздөн-түз ишке ашырбашы керек, бирок [`TryFrom`] trait программасын ишке ашырууну артык көрүшү керек, ал көбүрөөк ийкемдүүлүктү сунуш кылат жана `TryInto` эквиваленттүү программасын стандарттык китепканада жууркан жүзөгө ашыруунун аркасында бекер берет.
/// Бул тууралуу көбүрөөк маалымат алуу үчүн, [`Into`] үчүн документтерди караңыз.
///
/// # `TryInto` жүзөгө ашырылууда
///
/// Бул [`Into`] ти ишке ашыруу сыяктуу эле чектөөлөргө жана жүйөлөргө дуушар болот, толук маалыматты ошол жерден караңыз.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Түрү которууда ката кеткен учурда кайтарылды.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Конверсияны жүргүзөт.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Айрым шарттарда көзөмөлгө алынбай калышы мүмкүн болгон жөнөкөй жана коопсуз типтеги өзгөртүүлөр.Бул [`TryInto`] өз ара.
///
/// Бул кичине ийгиликтүү болуп калышы мүмкүн, бирок атайын иштетүүнү талап кылышы мүмкүн болгон түрүн өзгөртүп жатканда пайдалуу.
/// Мисалы, [`i64`] ти [`i32`] ке [`From`] trait колдонуп айландыруунун эч кандай жолу жок, анткени [`i64`] те [`i32`] көрсөтө албаган чоңдук камтылышы мүмкүн, андыктан конверсия маалыматты жоготуп коёт.
///
/// Бул [`i64`] ти [`i32`] ке кыскартуу жолу менен (негизинен [i64`] маанисине [`i32::MAX`] модулун берүү) же жөн гана [`i32::MAX`] кайтаруу жолу менен же башка ыкма менен чечилиши мүмкүн.
/// [`From`] trait мыкты конверсиялар үчүн арналган, андыктан `TryFrom` trait программистке типтеги конверсия качан начарлап кетиши мүмкүн экендигин жана аны кантип иштетүүнү чечкенге мүмкүнчүлүк берет.
///
/// # Жалпы ишке ашыруу
///
/// - `TryFrom<T> for U` <U>T`үчүн</u> [`TryInto`]" билдирет
/// - [`try_from`] рефлексивдүү, демек `TryFrom<T> for T` ишке ашат жана ишке ашпай калат-`T::try_from()` түрүн `T` маанисине чакыруу үчүн байланышкан `Error` түрү [`Infallible`].
/// [`!`] түрү турукташканда [`Infallible`] жана [`!`] барабар болот.
///
/// `TryFrom<T>` төмөнкүдөй ишке ашырылышы мүмкүн:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Сипатталгандай, [`i32`] "TryFrom <` [`i64`]">`ишке ашырат:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Үнсүз түрдө `big_number` ти кыскартат, фактыдан кийин кесилген жерди аныктоону жана аны иштетүүнү талап кылат.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Ката кайтат, анткени `big_number` `i32` ке сыйбай турганчалык чоң.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` кайтарып берет.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Түрү которууда ката кеткен учурда кайтарылды.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Конверсияны жүргүзөт.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// GENERIC IMPLS
////////////////////////////////////////////////////////////////////////////////

// Көтөрүп&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// &mut үстүнөн көтөргүчтөр катары
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): &/&mut үчүн жогоруда келтирилген имплдерди төмөнкүдөй жалпыга алмаштырыңыз:
// // Дерефти көтөргөндөй
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Өлчөмү> AsRef <U>for D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut &mut үстүнөн көтөрүлөт
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): &mut үчүн жогоруда айтылган имплени төмөнкүдөй жалпыга алмаштырыңыз:
// // AsMut DerefMut үстүнөн көтөрүлөт
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Өлчөмү> AsMut <U>for D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// From Into билдирет
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (жана демек Into) рефлексивдүү
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Туруктуулук жөнүндө эскертүү:** Бул имплм азырынча жок, бирок биз аны future ге кошуу үчүн "reserving space" болуп саналат.
/// Кеңири маалымат алуу үчүн [rust-lang/rust#64715][#64715] караңыз.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): анын ордуна принципиалдуу оңдоону жаса.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom TryInto дегенди билдирет
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Жаңылбас конверсиялар семантикалык жактан адам жашабаган ката тибиндеги жаңылыш которууларга барабар.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// БЕТОНДУК ИМПЛС
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// КАТА ЖОК КАТАЛАР ТҮРҮ
////////////////////////////////////////////////////////////////////////////////

/// Эч качан болбой турган каталар үчүн ката түрү.
///
/// Бул enumде эч кандай вариант жок болгондуктан, бул типтеги эч качан эч качан боло албайт.
/// Бул [`Result`] колдонгон жана ката түрүн параметрлеген жалпы API үчүн пайдалуу болушу мүмкүн, натыйжада ар дайым [`Ok`] болот.
///
/// Мисалы, [`TryFrom`] trait ([`Result`] ти кайтаруучу конверсия), тескерисинче [`Into`] ишке ашырылышы болгон бардык типтер үчүн жуурканды ишке ашырат.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future шайкештиги
///
/// Бул enum [the `!`“never”type][never] сыяктуу эле ролду ойнойт, бул Rust версиясында туруксуз.
/// `!` стабилдештирилгенде, биз ага `Infallible` псевдонимин жасоону пландап жатабыз:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... жана акыры `Infallible` эскирген.
///
/// Бирок `!` синтаксисин `!` толук кандуу тип катары стабилдештирүүдөн мурун колдонууга боло турган бир жагдай бар: функциянын кайтарым түрүндө.
/// Тактап айтканда, көрсөткүчтүн эки башка түрү боюнча ишке ашырылышы мүмкүн:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// `Infallible` enum болгондуктан, бул код жарактуу.
/// Бирок `Infallible` never type үчүн каймана ат болуп калганда, эки `impl` бири-бирине дал келе баштайт, демек, тилдин trait ырааттуулук эрежелери менен тыюу салынат.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}