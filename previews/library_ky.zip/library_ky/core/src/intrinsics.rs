//! Compiler intrinsics.
//!
//! Тийиштүү аныктамалар `compiler/rustc_codegen_llvm/src/intrinsic.rs` те.
//! Тиешелүү Const ишке ашыруу `compiler/rustc_mir/src/interpret/intrinsics.rs` болуп саналат
//!
//! # Const intrinsics
//!
//! Note: ички тыгыздыктын өзгөрүшүн тил тобу менен талкуулоо керек.
//! Буга конустун туруктуулугунун өзгөрүшү кирет.
//!
//! Компиляция убагында ички колдонууга жарамдуу болуш үчүн, <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> дан `compiler/rustc_mir/src/interpret/intrinsics.rs` чейин аткарууну көчүрүп, ички `#[rustc_const_unstable(feature = "foo", issue = "01234")]` кошуу керек.
//!
//!
//! Эгер ички `const fn` тен `rustc_const_stable` атрибуту менен колдонулушу керек болсо, анда ички атрибуту `rustc_const_stable` болушу керек.
//! Мындай өзгөрүүнү T-lang консультациясынсыз жасоого болбойт, анткени ал колдонуучу кодунда компилятордун колдоосу жок кайталана албаган бир өзгөчөлүктү тилге киргизет.
//!
//! # Volatiles
//!
//! Өзгөрүлмө интриниктер I/O эс тутумунда иштөөгө багытталган операцияларды камсыз кылат, аларды компилятор башка учуучу ички интриникалар боюнча иретке келтирбөөгө кепилдик берет.[[volatile]] боюнча LLVM документтерин караңыз.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Атомдук интриникалар бир нече мүмкүн болгон эс тутумдарын иреттөө менен, машиналык сөздөргө жалпы атомдук операцияларды камсыз кылат.Алар C++ 11 сыяктуу семантикага баш иет.[[atomics]] боюнча LLVM документтерин караңыз.
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Эстутумга буйрутма берүү боюнча тез жаңылануу:
//!
//! * Кулпуну алуу үчүн тоскоолдукка ээ болуңуз.Кийинки окуу жана жазуу тоскоолдуктан кийин ишке ашат.
//! * Бошотуу, кулпуну чыгаруу үчүн тоскоолдук.Мурунку окуу жана жазуу тоскоолдуктан мурун болот.
//! * Ырааттуу ырааттуу, ырааттуу ырааттуу иш-аракеттердин ирети менен жүзөгө ашырылышына кепилдик берилет.Бул атомдук типтер менен иштөөнүн стандарттуу режими жана Java `volatile` менен барабар.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Бул импорттор документтин ичиндеги шилтемелерди жөнөкөйлөтүү үчүн колдонулат
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // КООПСУЗДУК: `ptr::drop_in_place` караңыз
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, бул ички индикаторлор чийки көрсөткүчтөрдү алышат, анткени алар `&` же `&mut` үчүн жараксыз болгон башка эстутумду мутациялашат.
    //

    /// Учурдагы мааниси `old` мааниси менен бирдей болсо, маанини сактайт.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] түрлөрүндө `compare_exchange` методу аркылуу [`Ordering::SeqCst`] ти `success` жана `failure` параметрлери катары өткөрүп, жеткиликтүү.
    ///
    /// Мисалы, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Учурдагы мааниси `old` мааниси менен бирдей болсо, маанини сактайт.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] түрлөрүндө `compare_exchange` методу аркылуу [`Ordering::Acquire`] ти `success` жана `failure` параметрлери катары өткөрүп, жеткиликтүү.
    ///
    /// Мисалы, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Учурдагы мааниси `old` мааниси менен бирдей болсо, маанини сактайт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `compare_exchange` ыкмасы аркылуу [`Ordering::Release`] ти `success` жана [`Ordering::Relaxed`] ти `failure` параметрлери аркылуу өткөрүү мүмкүнчүлүгү бар.
    /// Мисалы, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Учурдагы мааниси `old` мааниси менен бирдей болсо, маанини сактайт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `compare_exchange` ыкмасы аркылуу [`Ordering::AcqRel`] ти `success` жана [`Ordering::Acquire`] ти `failure` параметрлери аркылуу өткөрүү мүмкүнчүлүгү бар.
    /// Мисалы, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Учурдагы мааниси `old` мааниси менен бирдей болсо, маанини сактайт.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] түрлөрүндө `compare_exchange` методу аркылуу [`Ordering::Relaxed`] ти `success` жана `failure` параметрлери катары өткөрүп, жеткиликтүү.
    ///
    /// Мисалы, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Учурдагы мааниси `old` мааниси менен бирдей болсо, маанини сактайт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `compare_exchange` ыкмасы аркылуу [`Ordering::SeqCst`] ти `success` жана [`Ordering::Relaxed`] ти `failure` параметрлери аркылуу өткөрүү мүмкүнчүлүгү бар.
    /// Мисалы, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Учурдагы мааниси `old` мааниси менен бирдей болсо, маанини сактайт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `compare_exchange` ыкмасы аркылуу [`Ordering::SeqCst`] ти `success` жана [`Ordering::Acquire`] ти `failure` параметрлери аркылуу өткөрүү мүмкүнчүлүгү бар.
    /// Мисалы, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Учурдагы мааниси `old` мааниси менен бирдей болсо, маанини сактайт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `compare_exchange` ыкмасы аркылуу [`Ordering::Acquire`] ти `success` жана [`Ordering::Relaxed`] ти `failure` параметрлери аркылуу өткөрүү мүмкүнчүлүгү бар.
    /// Мисалы, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Учурдагы мааниси `old` мааниси менен бирдей болсо, маанини сактайт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `compare_exchange` ыкмасы аркылуу [`Ordering::AcqRel`] ти `success` жана [`Ordering::Relaxed`] ти `failure` параметрлери аркылуу өткөрүү мүмкүнчүлүгү бар.
    /// Мисалы, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Учурдагы мааниси `old` мааниси менен бирдей болсо, маанини сактайт.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] түрлөрүндө `compare_exchange_weak` методу аркылуу [`Ordering::SeqCst`] ти `success` жана `failure` параметрлери катары өткөрүп, жеткиликтүү.
    ///
    /// Мисалы, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Учурдагы мааниси `old` мааниси менен бирдей болсо, маанини сактайт.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] түрлөрүндө `compare_exchange_weak` методу аркылуу [`Ordering::Acquire`] ти `success` жана `failure` параметрлери катары өткөрүп, жеткиликтүү.
    ///
    /// Мисалы, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Учурдагы мааниси `old` мааниси менен бирдей болсо, маанини сактайт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `compare_exchange_weak` ыкмасы аркылуу [`Ordering::Release`] ти `success` жана [`Ordering::Relaxed`] ти `failure` параметрлери аркылуу өткөрүү мүмкүнчүлүгү бар.
    /// Мисалы, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Учурдагы мааниси `old` мааниси менен бирдей болсо, маанини сактайт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `compare_exchange_weak` ыкмасы аркылуу [`Ordering::AcqRel`] ти `success` жана [`Ordering::Acquire`] ти `failure` параметрлери аркылуу өткөрүү мүмкүнчүлүгү бар.
    /// Мисалы, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Учурдагы мааниси `old` мааниси менен бирдей болсо, маанини сактайт.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] түрлөрүндө `compare_exchange_weak` методу аркылуу [`Ordering::Relaxed`] ти `success` жана `failure` параметрлери катары өткөрүп, жеткиликтүү.
    ///
    /// Мисалы, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Учурдагы мааниси `old` мааниси менен бирдей болсо, маанини сактайт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `compare_exchange_weak` ыкмасы аркылуу [`Ordering::SeqCst`] ти `success` жана [`Ordering::Relaxed`] ти `failure` параметрлери аркылуу өткөрүү мүмкүнчүлүгү бар.
    /// Мисалы, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Учурдагы мааниси `old` мааниси менен бирдей болсо, маанини сактайт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `compare_exchange_weak` ыкмасы аркылуу [`Ordering::SeqCst`] ти `success` жана [`Ordering::Acquire`] ти `failure` параметрлери аркылуу өткөрүү мүмкүнчүлүгү бар.
    /// Мисалы, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Учурдагы мааниси `old` мааниси менен бирдей болсо, маанини сактайт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `compare_exchange_weak` ыкмасы аркылуу [`Ordering::Acquire`] ти `success` жана [`Ordering::Relaxed`] ти `failure` параметрлери аркылуу өткөрүү мүмкүнчүлүгү бар.
    /// Мисалы, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Учурдагы мааниси `old` мааниси менен бирдей болсо, маанини сактайт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `compare_exchange_weak` ыкмасы аркылуу [`Ordering::AcqRel`] ти `success` жана [`Ordering::Relaxed`] ти `failure` параметрлери аркылуу өткөрүү мүмкүнчүлүгү бар.
    /// Мисалы, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Көрсөткүчтүн учурдагы маанисин жүктөйт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `load` ыкмасы аркылуу [`Ordering::SeqCst`] ти `order` катары өткөрүп, `load` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Көрсөткүчтүн учурдагы маанисин жүктөйт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `load` ыкмасы аркылуу [`Ordering::Acquire`] ти `order` катары өткөрүп, `load` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Көрсөткүчтүн учурдагы маанисин жүктөйт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `load` ыкмасы аркылуу [`Ordering::Relaxed`] ти `order` катары өткөрүп, `load` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Белгиленген эстутум жайгашкан жерди сактайт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `store` ыкмасы аркылуу [`Ordering::SeqCst`] ти `order` катары өткөрүп, `store` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Белгиленген эстутум жайгашкан жерди сактайт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `store` ыкмасы аркылуу [`Ordering::Release`] ти `order` катары өткөрүп, `store` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Белгиленген эстутум жайгашкан жерди сактайт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `store` ыкмасы аркылуу [`Ordering::Relaxed`] ти `order` катары өткөрүп, `store` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Эски маанини кайтарып, белгиленген эс тутумдагы маанини сактайт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `swap` ыкмасы аркылуу [`Ordering::SeqCst`] ти `order` катары өткөрүп, `swap` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Эски маанини кайтарып, белгиленген эс тутумдагы маанини сактайт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `swap` ыкмасы аркылуу [`Ordering::Acquire`] ти `order` катары өткөрүп, `swap` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Эски маанини кайтарып, белгиленген эс тутумдагы маанини сактайт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `swap` ыкмасы аркылуу [`Ordering::Release`] ти `order` катары өткөрүп, `swap` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Эски маанини кайтарып, белгиленген эс тутумдагы маанини сактайт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `swap` ыкмасы аркылуу [`Ordering::AcqRel`] ти `order` катары өткөрүп, `swap` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Эски маанини кайтарып, белгиленген эс тутумдагы маанини сактайт.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `swap` ыкмасы аркылуу [`Ordering::Relaxed`] ти `order` катары өткөрүп, `swap` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Мурунку маанини кайтарып, учурдагы мааниге кошулат.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_add` ыкмасы аркылуу [`Ordering::SeqCst`] ти `order` катары өткөрүп, `fetch_add` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Мурунку маанини кайтарып, учурдагы мааниге кошулат.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_add` ыкмасы аркылуу [`Ordering::Acquire`] ти `order` катары өткөрүп, `fetch_add` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Мурунку маанини кайтарып, учурдагы мааниге кошулат.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_add` ыкмасы аркылуу [`Ordering::Release`] ти `order` катары өткөрүп, `fetch_add` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Мурунку маанини кайтарып, учурдагы мааниге кошулат.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_add` ыкмасы аркылуу [`Ordering::AcqRel`] ти `order` катары өткөрүп, `fetch_add` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Мурунку маанини кайтарып, учурдагы мааниге кошулат.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_add` ыкмасы аркылуу [`Ordering::Relaxed`] ти `order` катары өткөрүп, `fetch_add` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Мурунку маанини кайтарып, учурдагы мааниден чыгарыңыз.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_sub` ыкмасы аркылуу [`Ordering::SeqCst`] ти `order` катары өткөрүп, `fetch_sub` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Мурунку маанини кайтарып, учурдагы мааниден чыгарыңыз.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_sub` ыкмасы аркылуу [`Ordering::Acquire`] ти `order` катары өткөрүп, `fetch_sub` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Мурунку маанини кайтарып, учурдагы мааниден чыгарыңыз.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_sub` ыкмасы аркылуу [`Ordering::Release`] ти `order` катары өткөрүп, `fetch_sub` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Мурунку маанини кайтарып, учурдагы мааниден чыгарыңыз.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_sub` ыкмасы аркылуу [`Ordering::AcqRel`] ти `order` катары өткөрүп, `fetch_sub` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Мурунку маанини кайтарып, учурдагы мааниден чыгарыңыз.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_sub` ыкмасы аркылуу [`Ordering::Relaxed`] ти `order` катары өткөрүп, `fetch_sub` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Учурдагы маани менен жана мурунку маанини кайтарып.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_and` ыкмасы аркылуу [`Ordering::SeqCst`] ти `order` катары өткөрүп, `fetch_and` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Учурдагы маани менен жана мурунку маанини кайтарып.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_and` ыкмасы аркылуу [`Ordering::Acquire`] ти `order` катары өткөрүп, `fetch_and` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Учурдагы маани менен жана мурунку маанини кайтарып.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_and` ыкмасы аркылуу [`Ordering::Release`] ти `order` катары өткөрүп, `fetch_and` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Учурдагы маани менен жана мурунку маанини кайтарып.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_and` ыкмасы аркылуу [`Ordering::AcqRel`] ти `order` катары өткөрүп, `fetch_and` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Учурдагы маани менен жана мурунку маанини кайтарып.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_and` ыкмасы аркылуу [`Ordering::Relaxed`] ти `order` катары өткөрүп, `fetch_and` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Мурунку маанини кайтарып, учурдагы маани менен биттик nand.
    ///
    /// Бул ички стабилдештирилген версиясы [`AtomicBool`] түрүндө `fetch_nand` методу аркылуу [`Ordering::SeqCst`] ти `order` катары өткөрүп, [`AtomicBool`] түрүндө жеткиликтүү.
    /// Мисалы, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Мурунку маанини кайтарып, учурдагы маани менен биттик nand.
    ///
    /// Бул ички стабилдештирилген версиясы [`AtomicBool`] түрүндө `fetch_nand` методу аркылуу [`Ordering::Acquire`] ти `order` катары өткөрүп, [`AtomicBool`] түрүндө жеткиликтүү.
    /// Мисалы, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Мурунку маанини кайтарып, учурдагы маани менен биттик nand.
    ///
    /// Бул ички стабилдештирилген версиясы [`AtomicBool`] түрүндө `fetch_nand` методу аркылуу [`Ordering::Release`] ти `order` катары өткөрүп, [`AtomicBool`] түрүндө жеткиликтүү.
    /// Мисалы, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Мурунку маанини кайтарып, учурдагы маани менен биттик nand.
    ///
    /// Бул ички стабилдештирилген версиясы [`AtomicBool`] түрүндө `fetch_nand` методу аркылуу [`Ordering::AcqRel`] ти `order` катары өткөрүп, [`AtomicBool`] түрүндө жеткиликтүү.
    /// Мисалы, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Мурунку маанини кайтарып, учурдагы маани менен биттик nand.
    ///
    /// Бул ички стабилдештирилген версиясы [`AtomicBool`] түрүндө `fetch_nand` методу аркылуу [`Ordering::Relaxed`] ти `order` катары өткөрүп, [`AtomicBool`] түрүндө жеткиликтүү.
    /// Мисалы, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Акырындык менен же учурдагы маани менен, мурунку маанини кайтарыңыз.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_or` ыкмасы аркылуу [`Ordering::SeqCst`] ти `order` катары өткөрүп, `fetch_or` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Акырындык менен же учурдагы маани менен, мурунку маанини кайтарыңыз.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_or` ыкмасы аркылуу [`Ordering::Acquire`] ти `order` катары өткөрүп, `fetch_or` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Акырындык менен же учурдагы маани менен, мурунку маанини кайтарыңыз.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_or` ыкмасы аркылуу [`Ordering::Release`] ти `order` катары өткөрүп, `fetch_or` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Акырындык менен же учурдагы маани менен, мурунку маанини кайтарыңыз.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_or` ыкмасы аркылуу [`Ordering::AcqRel`] ти `order` катары өткөрүп, `fetch_or` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Акырындык менен же учурдагы маани менен, мурунку маанини кайтарыңыз.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_or` ыкмасы аркылуу [`Ordering::Relaxed`] ти `order` катары өткөрүп, `fetch_or` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Мурунку маанини кайтарып, учурдагы маани менен биттик xor.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_xor` ыкмасы аркылуу [`Ordering::SeqCst`] ти `order` катары өткөрүп, `fetch_xor` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Мурунку маанини кайтарып, учурдагы маани менен биттик xor.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_xor` ыкмасы аркылуу [`Ordering::Acquire`] ти `order` катары өткөрүп, `fetch_xor` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Мурунку маанини кайтарып, учурдагы маани менен биттик xor.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_xor` ыкмасы аркылуу [`Ordering::Release`] ти `order` катары өткөрүп, `fetch_xor` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Мурунку маанини кайтарып, учурдагы маани менен биттик xor.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_xor` ыкмасы аркылуу [`Ordering::AcqRel`] ти `order` катары өткөрүп, `fetch_xor` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Мурунку маанини кайтарып, учурдагы маани менен биттик xor.
    ///
    /// Бул ички стабилдештирилген версиясы [`atomic`] түрлөрү боюнча `fetch_xor` ыкмасы аркылуу [`Ordering::Relaxed`] ти `order` катары өткөрүп, `fetch_xor` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Кол коюлган салыштыруу аркылуу учурдагы маани менен максимум.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] кол коюлган бүтүн сан түрүндө `fetch_max` ыкмасы аркылуу [`Ordering::SeqCst`] ти `order` катары өткөрүп, жеткиликтүү.
    /// Мисалы, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Кол коюлган салыштыруу аркылуу учурдагы маани менен максимум.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] кол коюлган бүтүн сан түрүндө `fetch_max` ыкмасы аркылуу [`Ordering::Acquire`] ти `order` катары өткөрүп, жеткиликтүү.
    /// Мисалы, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Кол коюлган салыштыруу аркылуу учурдагы маани менен максимум.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] кол коюлган бүтүн сан түрүндө `fetch_max` ыкмасы аркылуу [`Ordering::Release`] ти `order` катары өткөрүп, жеткиликтүү.
    /// Мисалы, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Кол коюлган салыштыруу аркылуу учурдагы маани менен максимум.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] кол коюлган бүтүн сан түрүндө `fetch_max` ыкмасы аркылуу [`Ordering::AcqRel`] ти `order` катары өткөрүп, жеткиликтүү.
    /// Мисалы, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Учурдагы маани менен максимум.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] кол коюлган бүтүн сан түрүндө `fetch_max` ыкмасы аркылуу [`Ordering::Relaxed`] ти `order` катары өткөрүп, жеткиликтүү.
    /// Мисалы, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Кол коюлган салыштыруу аркылуу учурдагы маани менен минимум.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] кол коюлган бүтүн сан түрүндө `fetch_min` ыкмасы аркылуу [`Ordering::SeqCst`] ти `order` катары өткөрүп, жеткиликтүү.
    /// Мисалы, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Кол коюлган салыштыруу аркылуу учурдагы маани менен минимум.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] кол коюлган бүтүн сан түрүндө `fetch_min` ыкмасы аркылуу [`Ordering::Acquire`] ти `order` катары өткөрүп, жеткиликтүү.
    /// Мисалы, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Кол коюлган салыштыруу аркылуу учурдагы маани менен минимум.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] кол коюлган бүтүн сан түрүндө `fetch_min` ыкмасы аркылуу [`Ordering::Release`] ти `order` катары өткөрүп, жеткиликтүү.
    /// Мисалы, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Кол коюлган салыштыруу аркылуу учурдагы маани менен минимум.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] кол коюлган бүтүн сан түрүндө `fetch_min` ыкмасы аркылуу [`Ordering::AcqRel`] ти `order` катары өткөрүп, жеткиликтүү.
    /// Мисалы, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Кол коюлган салыштыруу аркылуу учурдагы маани менен минимум.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] кол коюлган бүтүн сан түрүндө `fetch_min` ыкмасы аркылуу [`Ordering::Relaxed`] ти `order` катары өткөрүп, жеткиликтүү.
    /// Мисалы, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Кол коюлбаган салыштыруу аркылуу учурдагы маани менен минимум.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] белгисиз бүтүндөй сан түрлөрүндө `fetch_min` методу аркылуу [`Ordering::SeqCst`] ти `order` катары өткөрүп, жеткиликтүү.
    /// Мисалы, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Кол коюлбаган салыштыруу аркылуу учурдагы маани менен минимум.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] белгисиз бүтүндөй сан түрлөрүндө `fetch_min` методу аркылуу [`Ordering::Acquire`] ти `order` катары өткөрүп, жеткиликтүү.
    /// Мисалы, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Кол коюлбаган салыштыруу аркылуу учурдагы маани менен минимум.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] белгисиз бүтүндөй сан түрлөрүндө `fetch_min` методу аркылуу [`Ordering::Release`] ти `order` катары өткөрүп, жеткиликтүү.
    /// Мисалы, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Кол коюлбаган салыштыруу аркылуу учурдагы маани менен минимум.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] белгисиз бүтүндөй сан түрлөрүндө `fetch_min` методу аркылуу [`Ordering::AcqRel`] ти `order` катары өткөрүп, жеткиликтүү.
    /// Мисалы, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Кол коюлбаган салыштыруу аркылуу учурдагы маани менен минимум.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] белгисиз бүтүндөй сан түрлөрүндө `fetch_min` методу аркылуу [`Ordering::Relaxed`] ти `order` катары өткөрүп, жеткиликтүү.
    /// Мисалы, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Кол коюлбаган салыштыруу аркылуу учурдагы маани менен максимум.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] белгисиз бүтүндөй сан түрлөрүндө `fetch_max` методу аркылуу [`Ordering::SeqCst`] ти `order` катары өткөрүп, жеткиликтүү.
    /// Мисалы, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Кол коюлбаган салыштыруу аркылуу учурдагы маани менен максимум.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] белгисиз бүтүн сан түрлөрүндө `fetch_max` методу аркылуу [`Ordering::Acquire`] ти `order` катары өткөрүп, жеткиликтүү.
    /// Мисалы, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Кол коюлбаган салыштыруу аркылуу учурдагы маани менен максимум.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] белгисиз бүтүндөй сан түрлөрүндө `fetch_max` методу аркылуу [`Ordering::Release`] ти `order` катары өткөрүп, жеткиликтүү.
    /// Мисалы, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Кол коюлбаган салыштыруу аркылуу учурдагы маани менен максимум.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] белгисиз бүтүндөй сан түрлөрүндө `fetch_max` методу аркылуу [`Ordering::AcqRel`] ти `order` катары өткөрүп, жеткиликтүү.
    /// Мисалы, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Кол коюлбаган салыштыруу аркылуу учурдагы маани менен максимум.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`atomic`] белгисиз бүтүндөй сан түрлөрүндө `fetch_max` методу аркылуу [`Ordering::Relaxed`] ти `order` катары өткөрүп, жеткиликтүү.
    /// Мисалы, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ички `prefetch` коду жаратуучуга, эгерде колдоого алынса, алдын ала жүктөө көрсөтмөсүн киргизүүгө кеңеш берет;Болбосо, бул жокко эсе.
    /// Алдын ала жүктөө программанын жүрүм-турумуна эч кандай таасирин тийгизбейт, бирок анын иштөө мүнөздөмөсүн өзгөртө алат.
    ///
    /// `locality` аргументи туруктуу бүтүн сан болушу керек жана (0) тен баштап, локалдуулуктан (3) чейин, жергиликтүү деңгээлде кэште сакталып туруучу убактылуу локалдык көрсөткүч.
    ///
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Ички `prefetch` коду жаратуучуга, эгерде колдоого алынса, алдын ала жүктөө көрсөтмөсүн киргизүүгө кеңеш берет;Болбосо, бул жокко эсе.
    /// Алдын ала жүктөө программанын жүрүм-турумуна эч кандай таасирин тийгизбейт, бирок анын иштөө мүнөздөмөсүн өзгөртө алат.
    ///
    /// `locality` аргументи туруктуу бүтүн сан болушу керек жана (0) тен баштап, локалдуулуктан (3) чейин, жергиликтүү деңгээлде кэште сакталып туруучу убактылуу локалдык көрсөткүч.
    ///
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Ички `prefetch` коду жаратуучуга, эгерде колдоого алынса, алдын ала жүктөө көрсөтмөсүн киргизүүгө кеңеш берет;Болбосо, бул жокко эсе.
    /// Алдын ала жүктөө программанын жүрүм-турумуна эч кандай таасирин тийгизбейт, бирок анын иштөө мүнөздөмөсүн өзгөртө алат.
    ///
    /// `locality` аргументи туруктуу бүтүн сан болушу керек жана (0) тен баштап, локалдуулуктан (3) чейин, жергиликтүү деңгээлде кэште сакталып туруучу убактылуу локалдык көрсөткүч.
    ///
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Ички `prefetch` коду жаратуучуга, эгерде колдоого алынса, алдын ала жүктөө көрсөтмөсүн киргизүүгө кеңеш берет;Болбосо, бул жокко эсе.
    /// Алдын ала жүктөө программанын жүрүм-турумуна эч кандай таасирин тийгизбейт, бирок анын иштөө мүнөздөмөсүн өзгөртө алат.
    ///
    /// `locality` аргументи туруктуу бүтүн сан болушу керек жана (0) тен баштап, локалдуулуктан (3) чейин, жергиликтүү деңгээлде кэште сакталып туруучу убактылуу локалдык көрсөткүч.
    ///
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Атомдук тосмо.
    ///
    /// Бул ички түзүмдүн турукташтырылган версиясы [`atomic::fence`] форматында [`Ordering::SeqCst`] аркылуу `order` болуп саналат.
    ///
    ///
    pub fn atomic_fence();
    /// Атомдук тосмо.
    ///
    /// Бул ички түзүмдүн стабилдештирилген версиясы [`Ordering::Acquire`] ти `order` катары өткөрүп, [`atomic::fence`] форматында жеткиликтүү.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Атомдук тосмо.
    ///
    /// Бул ички түзүмдүн турукташтырылган версиясы [`atomic::fence`] форматында [`Ordering::Release`] аркылуу `order` болуп саналат.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Атомдук тосмо.
    ///
    /// Бул ички түзүмдүн турукташтырылган версиясы [`atomic::fence`] форматында [`Ordering::AcqRel`] аркылуу `order` болуп саналат.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Компиляторго гана арналган эс тутум.
    ///
    /// Эстутумга кирүү бул тосмо аркылуу эч качан компилятор тарабынан иреттелбейт, бирок ал үчүн эч кандай көрсөтмө чыкпайт.
    /// Бул бир эле жиптеги иш-аракеттерге, мисалы, сигнал иштетүүчүлөр менен өз ара аракеттенүү учурунда туура келет.
    ///
    /// Бул ички түзүмдүн турукташтырылган версиясы [`atomic::compiler_fence`] форматында [`Ordering::SeqCst`] аркылуу `order` болуп саналат.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Компиляторго гана арналган эс тутум.
    ///
    /// Эстутумга кирүү бул тосмо аркылуу эч качан компилятор тарабынан иреттелбейт, бирок ал үчүн эч кандай көрсөтмө чыкпайт.
    /// Бул бир эле жиптеги иш-аракеттерге, мисалы, сигнал иштетүүчүлөр менен өз ара аракеттенүү учурунда туура келет.
    ///
    /// Бул ички түзүмдүн турукташтырылган версиясы [`atomic::compiler_fence`] форматында [`Ordering::Acquire`] аркылуу `order` болуп саналат.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Компиляторго гана арналган эс тутум.
    ///
    /// Эстутумга кирүү бул тосмо аркылуу эч качан компилятор тарабынан иреттелбейт, бирок ал үчүн эч кандай көрсөтмө чыкпайт.
    /// Бул бир эле жиптеги иш-аракеттерге, мисалы, сигнал иштетүүчүлөр менен өз ара аракеттенүү учурунда туура келет.
    ///
    /// Бул ички түзүмдүн турукташтырылган версиясы [`atomic::compiler_fence`] форматында [`Ordering::Release`] аркылуу `order` болуп саналат.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Компиляторго гана арналган эс тутум.
    ///
    /// Эстутумга кирүү бул тосмо аркылуу эч качан компилятор тарабынан иреттелбейт, бирок ал үчүн эч кандай көрсөтмө чыкпайт.
    /// Бул бир эле жиптеги иш-аракеттерге, мисалы, сигнал иштетүүчүлөр менен өз ара аракеттенүү учурунда туура келет.
    ///
    /// Бул ички түзүмдүн турукташтырылган версиясы [`atomic::compiler_fence`] форматында [`Ordering::AcqRel`] аркылуу `order` болуп саналат.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Функцияга берилген атрибуттардан анын маанисин алган сыйкырдуу ички.
    ///
    /// Мисалы, dataflow муну статикалык ырастоолорду киргизүү үчүн колдонот, ошондо `rustc_peek(potentially_uninitialized)` чындыгында маалымат агымынын башкаруу агымынын ошол учурда башталбагандыгын эсептеп чыккандыгын эки жолу текшерет.
    ///
    ///
    /// Бул ички компилятордон тышкары колдонулбашы керек.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Процесстин аткарылышын токтотот.
    ///
    /// Бул иштин ыңгайлуу жана туруктуу версиясы [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Оптимизаторго коддогу ушул пункт жеткиликсиз экендигин билдирет жана мындан ары оптималдаштырууга мүмкүнчүлүк берет.
    ///
    /// NB, бул `unreachable!()` макросунан таптакыр айырмаланат: panics аткарылгандагы макростан айырмаланып, бул функция менен белгиленген кодго жетүү *аныкталбаган жүрүм-турум*.
    ///
    ///
    /// Бул ички турукташтырылган версиясы [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Оптизаторго шарттын ар дайым чын экендигин маалымдайт.
    /// Эгер шарт жалган болсо, жүрүм-турум аныкталбайт.
    ///
    /// Бул ички нерсе үчүн эч кандай код түзүлбөйт, бирок оптимизатор аны (жана анын абалын) ашуулардын ортосунда сактап калууга аракет кылат, бул курчап турган кодду оптималдаштырууга тоскоол болуп, иштөөнү төмөндөтөт.
    /// Эгерде инвариантты оптимизатор өз алдынча таап алса же кандайдыр бир олуттуу оптималдаштырууга мүмкүнчүлүк бербесе, анда аны колдонууга болбойт.
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// branch шарты чын болушу мүмкүн экендиги жөнүндө компиляторго ишара кылат.
    /// Ага өткөн маанини кайтарып берет.
    ///
    /// `if` билдирүүлөрүнөн башка ар кандай колдонуу, балким, натыйжа бербейт.
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// branch шарты жалган болушу мүмкүн деген компиляторго ишарат кылат.
    /// Ага өткөн маанини кайтарып берет.
    ///
    /// `if` билдирүүлөрүнөн башка ар кандай колдонуу, балким, натыйжа бербейт.
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Мүчүлүштүктөрдү оңдоочу түзмөк аркылуу текшерүү үчүн, токтоочу тузакты аткарат.
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    pub fn breakpoint();

    /// Түрдүн көлөмү байт менен.
    ///
    /// Тагыраак айтканда, бул бирдей типтеги ырааттуу элементтердин ортосундагы байттардын ордун толтуруу, анын ичинде тегиздөө пломбасы.
    ///
    ///
    /// Бул ички турукташтырылган версиясы [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Түрдүн минималдуу тегизделиши.
    ///
    /// Бул ички турукташтырылган версиясы [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Бир түрүнүн артыкчылыктуу тегиздөө.
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Шилтеменин мааниси байт менен.
    ///
    /// Бул ички турукташтырылган версиясы [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Шилтемеленген маанинин талаптагыдай тегизделиши.
    ///
    /// Бул ички турукташтырылган версиясы [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Түрдүн аталышын камтыган статикалык сап тилкесин алат.
    ///
    /// Бул ички турукташтырылган версиясы [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Көрсөтүлгөн типке глобалдуу уникалдуу идентификаторду алат.
    /// Бул функция кайсы crate чакырылганына карабастан, бир тип үчүн бирдей маанини берет.
    ///
    ///
    /// Бул ички турукташтырылган версиясы [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Эгерде `T` элинде жашабаса, анда эч качан аткарылбай турган кооптуу функциялардын сакчысы:
    /// Бул panic статикалык же эч нерсе кыла албайт.
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Эгерде `T` нөл баштоого уруксат бербесе, анда эч качан аткарылбай турган кооптуу функциялардын сакчысы: Бул panic статикалык же эч нерсе кыла албайт.
    ///
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    pub fn assert_zero_valid<T>();

    /// Эгерде `T` жараксыз бит үлгүлөрүнө ээ болсо, анда эч качан аткарылбай турган кооптуу функциялардын сакчысы: Бул panic статикалык же эч нерсе кылбайт.
    ///
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    pub fn assert_uninit_valid<T>();

    /// Статикалык `Location` ке кайда деп атагандыгын көрсөтөт.
    ///
    /// Анын ордуна [`core::panic::Location::caller`](crate::panic::Location::caller) колдонууну карап көрөлү.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Ачык желимди иштетпей эле, маанини масштабдан чыгарат.
    ///
    /// Бул [`mem::forget_unsized`] үчүн гана бар;кадимки `forget` ордуна `ManuallyDrop` колдонот.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Бир типтеги маанинин биттерин башка түр катары кайра чечмелейт.
    ///
    /// Эки түрдүн көлөмү бирдей болушу керек.
    /// Түп нускасы дагы, натыйжасы дагы [invalid value](../../nomicon/what-unsafe-does.html) болушу мүмкүн эмес.
    ///
    /// `transmute` семантикалык жактан бир түрдүн экинчисине жылышына эквиваленттүү.Биттерди баштапкы мааниден көздөгөн мааниге көчүрүп, түп нускасын унутат.
    /// Бул `transmute_copy` сыяктуу эле, капоттун астындагы Cдин `memcpy` эквивалентине ээ.
    ///
    /// `transmute` кошумча маанидеги операция болгондуктан,*которулган баалуулуктардын* тегизделиши кооптонууну жаратпайт.
    /// Башка функциялардагыдай эле, компилятор `T` менен `U` туура шайкеш келишин камсыз кылат.
    /// Бирок,*башка жакка бурулган* маанилерди которууда (мисалы, көрсөткүчтөр, шилтемелер, кутучалар ...), чалган адам көрсөтүлгөн бурулган маанилердин туура тегизделишин камсыз кылышы керек.
    ///
    /// `transmute` **укмуштай** кооптуу.Бул функция менен [undefined behavior][ub] пайда кылуунун көптөгөн жолдору бар.`transmute` абсолюттук акыркы чара болушу керек.
    ///
    /// [nomicon](../../nomicon/transmutes.html) кошумча документтерге ээ.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// `transmute` чындыгында пайдалуу болгон бир нече нерсе бар.
    ///
    /// Көрсөткүчтү функция көрсөткүчүнө айландыруу.Бул функция көрсөткүчтөрү жана маалымат көрсөткүчтөрүнүн көлөмү ар башка болгон машиналар үчүн * көчмө эмес.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Өмүрдү узартуу, же өзгөрүлбөс өмүрдү кыскартуу.Бул өнүккөн, өтө кооптуу Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Үмүт үзбөңүз: `transmute` тин көп колдонулушуна башка жолдор менен жетишүүгө болот.
    /// Төмөндө `transmute` тин кеңири таралган тиркемелери бар, аларды коопсуз конструкциялар менен алмаштырууга болот.
    ///
    /// Чийки bytes(`&[u8]`) ти `u32`, `f64` ж.б.га айландыруу:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // ордуна `u32::from_ne_bytes` колдонуңуз
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // же endianness көрсөтүү үчүн `u32::from_le_bytes` же `u32::from_be_bytes` колдонуңуз
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Көрсөткүчтү `usize` ке айландыруу:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Анын ордуна `as` экранын колдонуңуз
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// `*mut T` ти `&mut T` ке айландыруу:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Анын ордуна reborrow колдон
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T` ти `&mut U` ке айландыруу:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Эми, `as` жана reborrowing бириктирип, `as` `as` чынжырчасынын өткөөл эмес экендигин белгилеңиз
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str` ти `&[u8]` ке айландыруу:
    ///
    /// ```
    /// // муну жасоонун жакшы жолу эмес.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // `str::as_bytes` колдонсоңуз болот
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Же, эгер сиз сапты түзмө-түз көзөмөлдөсөңүз, анда жөн гана байт сабын колдонуңуз
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// `Vec<&T>` ти `Vec<Option<&T>>` ке айландыруу.
    ///
    /// Контейнердин ички түрүн өзгөртүү үчүн, камтылуучунун инварианттарынын бирин бузбаңыз.
    /// `Vec` үчүн, бул ички түрлөрдүн көлөмү *жана тегиздөө* дал келиши керек дегенди билдирет.
    /// Башка контейнерлер типтин өлчөмүнө, тегизделишине же ал тургай `TypeId` ке ишениши мүмкүн, мындай учурда трансмейнер контейнердин инварианттарын бузбастан таптакыр мүмкүн эмес.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // клондоштуруу vector, анткени аларды кийинчерээк кайра колдонобуз
    /// let v_clone = v_orig.clone();
    ///
    /// // Transmute колдонуу: бул `Vec` такталбаган дайындар схемасына таянат, бул жаман идея жана Аныкталбаган жүрүм-турумга алып келиши мүмкүн.
    /////
    /// // Бирок, ал көчүрмө эмес.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Бул сунушталган, коопсуз жол.
    /// // Ал толугу менен vector көчүрмөсүн жаңы массивге көчүрөт.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Бул "transmuting" жана `Vec` кооптуу ыкмасы, маалыматтардын жайгашуусуна ишенбестен.
    /// // Түзмө-түз `transmute` деп атоонун ордуна, биз көрсөткүчтү аткарууну аткарабыз, бирок баштапкы ички (`&i32`) түрүн жаңысына (`Option<&i32>`) кылып конвертациялоо жагынан алганда, бир эле эскертүү бар.
    /////
    /// // Жогоруда келтирилген маалыматтардан тышкары, [`from_raw_parts`] документтерине кайрылыңыз.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Муну vec_into_raw_parts стабилдештирилгенде жаңыртыңыз.
    ///     // Түпнуска vector ташталбагандыгын текшериңиз.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut` ишке ашыруу:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Мунун бир нече жолу бар жана төмөнкү (transmute) жолу менен бир нече көйгөйлөр бар.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // биринчи: трансмут түрү коопсуз эмес;анын бардыгын текшерген Т жана
    ///         // U көлөмү бирдей.
    ///         // Экинчиден, дал ушул жерде, бир эле эс тутумга багытталган эки өзгөрүлмө шилтеме бар.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Бул типтеги коопсуздук көйгөйлөрүнөн арылат;`&mut *` сизге `&mut T` же `* mut T` тен `&mut T` берет *.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // бирок, сизде дагы бир эс тутумга багытталган эки өзгөрүлмө шилтеме бар.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Стандарттуу китепкана муну кантип жасайт.
    /// // Ушундай нерсени жасаш керек болсо, бул эң жакшы ыкма
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Азыр бир эле эс тутумга багытталган үч өзгөрүлмө шилтеме бар.`slice`, ret.0 мааниси жана ret.1 мааниси.
    ///         // `slice` `let ptr = ...` кийин эч качан колдонулбайт, демек, аны "dead" катары кароого болот, демек, сизде эки өзгөрүлмө кесинди гана бар.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Бул ички констукту туруктуу кылат, ал эми бизде const fnде бир нече бажы коду бар
    // аны `const fn` ичинде колдонууга жол бербеген текшерүүлөр.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Эгер `T` катары берилген чыныгы түргө желим керек болсо, `true` кайтарып берет;`false` үчүн берилген чыныгы түр `Copy` ти ишке ашырса, `false` берет.
    ///
    ///
    /// Эгерде чыныгы түрү желим талап кылбаса же `Copy` шайманын колдонбосо, анда бул функциянын кайтарым мааниси аныкталбайт.
    ///
    /// Бул ички турукташтырылган версиясы [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Көрсөтүүдөн жылдырууну эсептейт.
    ///
    /// Бул бүтүн санга өтүп кетпөө үчүн ички нерсе катары колдонулат, анткени конверсия лакап маалыматты ыргытып жиберет.
    ///
    /// # Safety
    ///
    /// Баштапкы жана натыйжалуу көрсөткүч чектерде же бөлүнгөн объекттин аягынан бир байт өтүшү керек.
    /// Эгерде көрсөткүчтөрдүн бири чектен чыкса же арифметикалык толуп калса, анда кайтарылган маанини андан ары колдонуу аныкталбаган жүрүм-турумга алып келет.
    ///
    ///
    /// Бул ички турукташтырылган версиясы [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Көрсөтүүдөн жылдырууну эсептеп, оролушу мүмкүн.
    ///
    /// Бул бүтүн санга өтүүдөн качуу үчүн ички нерсе катары ишке ашырылат, анткени конверсия белгилүү бир оптималдаштырууга тоскоол болот.
    ///
    /// # Safety
    ///
    /// Ички `offset` ден айырмаланып, бул ички пайда болгон көрсөткүчтү бөлүнүп берилген объектинин аягына же бир байтка өткөнгө чектебейт жана ал экинин толуктоочу арифметикасы менен оролот.
    /// Жыйынтыгында эс тутумга жетүү үчүн колдонулган маани сөзсүз эле жарактуу эмес.
    ///
    /// Бул ички турукташтырылган версиясы [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Туура ички `llvm.memcpy.p0i8.0i8.*` эквиваленти, өлчөмү `count`*`size_of::<T>()` жана тегиздиги менен
    ///
    /// `min_align_of::<T>()`
    ///
    /// Учуучу параметр `true` деп коюлган, ошондуктан анын көлөмү нөлгө барабар болбосо, ал оптималдаштырылбайт.
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Тийиштүү `llvm.memmove.p0i8.0i8.*` ички өлчөмүнө барабар, көлөмү `count* size_of::<T>()` жана тегиздиги менен
    ///
    /// `min_align_of::<T>()`
    ///
    /// Учуучу параметр `true` деп коюлган, ошондуктан анын көлөмү нөлгө барабар болбосо, ал оптималдаштырылбайт.
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Тийиштүү ички `llvm.memset.p0i8.*` эквиваленти, `count* size_of::<T>()` өлчөмү жана `min_align_of::<T>()` тегиздиги менен.
    ///
    ///
    /// Учуучу параметр `true` деп коюлган, ошондуктан анын көлөмү нөлгө барабар болбосо, ал оптималдаштырылбайт.
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// `src` көрсөткүчүнөн учуучу жүктү аткарат.
    ///
    /// Бул ички турукташтырылган версиясы [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// `dst` көрсөткүчүнө чейин туруксуз дүкөндү аткарат.
    ///
    /// Бул ички турукташтырылган версиясы [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// `src` көрсөткүчүнөн учуучу жүктү аткарат Көрсөткүчтү тегиздөө талап кылынбайт.
    ///
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// `dst` көрсөткүчүнө чейин туруксуз дүкөндү аткарат.
    /// Көрсөткүчтү тегиздөө талап кылынбайт.
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// `f32` чарчы тамырын кайтарып берет
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// `f64` чарчы тамырын кайтарып берет
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// `f32` бүтүн кубаттуулукка көтөрөт.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// `f64` бүтүн кубаттуулукка көтөрөт.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// `f32` синусун кайтарат.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// `f64` синусун кайтарат.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// `f32` косинусун кайтарат.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// `f64` косинусун кайтарат.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// `f32` ти `f32` кубатына көтөрөт.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// `f64` ти `f64` кубатына көтөрөт.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// `f32` экспоненциалын кайтарат.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// `f64` экспоненциалын кайтарат.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// `f32` кубаттуулугуна көтөрүлгөн 2ди кайтарат.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// `f64` кубаттуулугуна көтөрүлгөн 2ди кайтарат.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// `f32` табигый логарифмин кайтарып берет.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// `f64` табигый логарифмин кайтарып берет.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// `f32` негизиндеги 10 логарифмди кайтарып берет.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// `f64` негизиндеги 10 логарифмди кайтарып берет.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// `f32` негизинин 2 логарифмин кайтарып берет.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// `f64` негизинин 2 логарифмин кайтарып берет.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// `f32` маанилери үчүн `a * b + c` берет.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// `f64` маанилери үчүн `a * b + c` берет.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// `f32` абсолюттук маанисин кайтарып берет.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// `f64` абсолюттук маанисин кайтарып берет.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Эки минималдуу `f32` маанисин кайтарып берет.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Эки минималдуу `f64` маанисин кайтарып берет.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Эң көп `f32` маанисин кайтарып берет.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Эң көп `f64` маанисин кайтарып берет.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// `f32` маанилери үчүн `y` ден `x` ге чейинки белгини көчүрөт.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// `f64` маанилери үчүн `y` ден `x` ге чейинки белгини көчүрөт.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Эң чоң бүтүндү `f32` тен кем же ага барабар кылып берет.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Эң чоң бүтүндү `f64` тен кем же ага барабар кылып берет.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// `f32` тен чоң же ага барабар кичинекей бүтүн сандарды кайтарып берет.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// `f64` тен чоң же ага барабар кичинекей бүтүн сандарды кайтарып берет.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// `f32` бүтүн бөлүгүн кайтарып берет.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// `f64` бүтүн бөлүгүн кайтарып берет.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// `f32` эң жакын бүтүн сандарды кайтарат.
    /// Эгерде аргумент бүтүн сан болбосо, так эмес калкып чыгуучу пунктту чыгарып салышы мүмкүн.
    pub fn rintf32(x: f32) -> f32;
    /// `f64` эң жакын бүтүн сандарды кайтарат.
    /// Эгерде аргумент бүтүн сан болбосо, так эмес калкып чыгуучу пунктту чыгарып салышы мүмкүн.
    pub fn rintf64(x: f64) -> f64;

    /// `f32` эң жакын бүтүн сандарды кайтарат.
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    pub fn nearbyintf32(x: f32) -> f32;
    /// `f64` эң жакын бүтүн сандарды кайтарат.
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    pub fn nearbyintf64(x: f64) -> f64;

    /// `f32` эң жакын бүтүн сандарды кайтарат.Жарым жолдогу учурларды нөлдөн айландырат.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// `f64` эң жакын бүтүн сандарды кайтарат.Жарым жолдогу учурларды нөлдөн айландырат.
    ///
    /// Бул ички турукташтырылган версиясы болуп саналат
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Алгебралык эрежелердин негизинде оптималдаштырууга мүмкүндүк берген калкыма кошумча.
    /// Кириштер чектелген деп божомолдошу мүмкүн.
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Алгебралык эрежелердин негизинде оптималдаштырууга мүмкүндүк берген калкып чыгуу.
    /// Кириштер чектелген деп божомолдошу мүмкүн.
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Алгебралык эрежелердин негизинде оптималдаштырууга мүмкүндүк берген калкып көбөйтүү.
    /// Кириштер чектелген деп божомолдошу мүмкүн.
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Алгебралык эрежелердин негизинде оптималдаштырууга мүмкүндүк берген флот бөлүмү.
    /// Кириштер чектелген деп божомолдошу мүмкүн.
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Алгебралык эрежелердин негизинде оптималдаштырууга мүмкүндүк берген калкып чыккан калдык.
    /// Кириштер чектелген деп божомолдошу мүмкүн.
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// LLVM's fptoui/fptosi менен конверттеңиз, ал чектен чыккан баалуулуктар үчүн undef кайтарышы мүмкүн
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// [`f32::to_int_unchecked`] жана [`f64::to_int_unchecked`] катары турукташтырылган.
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Бүтүндөй `T` түрүндө коюлган биттердин санын кайтарат
    ///
    /// Бул ички стабилдештирилген версиялары бүтүндөй примитивдерде `count_ones` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Бүтүндөй `T` түрүндөгү (zeroes) коюлбаган биттердин санын кайтарат.
    ///
    /// Бул ички стабилдештирилген версиялары бүтүндөй примитивдерде `leading_zeros` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `0` мааниси бар `x` `T` бит туурасын кайтарып берет.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// `ctlz` сыяктуу, бирок X0 `0` маанидеги `x` берилгенде `undef` кайтарып бергендиктен, кооптуу.
    ///
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Бүтүндөй `T` түрүндөгү (zeroes) коюлбай калган биттердин санын кайтарып берет.
    ///
    /// Бул ички стабилдештирилген версиялары бүтүндөй примитивдерде `trailing_zeros` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `0` мааниси бар `x` биттин `T` туурасын кайтарып берет:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// `cttz` сыяктуу, бирок X0 `0` маанидеги `x` берилгенде `undef` кайтарып бергендиктен, кооптуу.
    ///
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// `T` типтеги байттарды тескери бурат.
    ///
    /// Бул ички стабилдештирилген версиялары бүтүндөй примитивдерде `swap_bytes` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Бүтүндөй `T` түрүндөгү биттерди тескери бурат.
    ///
    /// Бул ички стабилдештирилген версиялары бүтүндөй примитивдерде `reverse_bits` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Текшерилген бүтүн санды кошууну аткарат.
    ///
    /// Бул ички стабилдештирилген версиялары бүтүндөй примитивдерде `overflowing_add` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Текшерилген бүтүн санды алып салууну аткарат
    ///
    /// Бул ички стабилдештирилген версиялары бүтүндөй примитивдерде `overflowing_sub` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Текшерилген бүтүн көбөйтүүнү жүргүзөт
    ///
    /// Бул ички стабилдештирилген версиялары бүтүндөй примитивдерде `overflowing_mul` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Так бөлүштүрүүнү жүргүзөт, натыйжада `x % y != 0` же `y == 0` же `x == T::MIN && y == -1` аныкталбаган жүрүм-турумга алып келет
    ///
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Текшерилбеген бөлүүнү жүргүзөт, натыйжада `y == 0` же `x == T::MIN && y == -1` аныкталбаган жүрүм-турумга алып келет
    ///
    ///
    /// Бул ички үчүн коопсуз оромдор `checked_div` ыкмасы аркылуу бүтүндөй примитивдерде болот.
    /// Мисалы,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// `y == 0` же `x == T::MIN && y == -1` болгондо аныкталбаган жүрүм-турумга алып келген, текшерилбеген бөлүнүүнүн калган бөлүгүн кайтарат
    ///
    ///
    /// Бул ички үчүн коопсуз оромдор `checked_rem` ыкмасы аркылуу бүтүндөй примитивдерде болот.
    /// Мисалы,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Текшерилбеген сол жакка жылдырууну аткарат, натыйжада `y < 0` же `y >= N` болгондо аныкталбаган жүрүм-турум пайда болот, бул жерде N биттердин Tдин туурасы.
    ///
    ///
    /// Бул ички үчүн коопсуз оромдор `checked_shl` ыкмасы аркылуу бүтүндөй примитивдерде болот.
    /// Мисалы,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Текшерилбеген оң жылышууну аткарат, натыйжада `y < 0` же `y >= N` болгондо аныкталбаган жүрүм-турум пайда болот, мында N биттердин T кеңдиги.
    ///
    ///
    /// Бул ички үчүн коопсуз оромдор `checked_shr` ыкмасы аркылуу бүтүндөй примитивдерде болот.
    /// Мисалы,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// `x + y > T::MAX` же `x + y < T::MIN` болгондо аныкталбаган жүрүм-турумга алып келип, текшерилбеген кошумчанын натыйжасын кайтарат.
    ///
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// `x - y > T::MAX` же `x - y < T::MIN` болгондо аныкталбаган жүрүм-турумга алып келген, текшерилбеген алып салуунун натыйжасын кайтарып берет.
    ///
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// `x *y > T::MAX` же `x* y < T::MIN` болгондо аныкталбаган жүрүм-турумга алып келген текшерилбеген көбөйтүүнүн натыйжасын кайтарып берет.
    ///
    ///
    /// Бул ички туруктуу аналогуна ээ эмес.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Солго айлантууну аткарат.
    ///
    /// Бул ички стабилдештирилген версиялары бүтүндөй примитивдерде `rotate_left` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Туура айландырат.
    ///
    /// Бул ички стабилдештирилген версиялары бүтүндөй примитивдерде `rotate_right` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// (A + b) mod 2 <sup>N</sup> кайтарат, мында N-биттердин Tдин туурасы.
    ///
    /// Бул ички стабилдештирилген версиялары бүтүндөй примитивдерде `wrapping_add` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// (A, b) mod 2 <sup>N</sup> кайтарат, мында N-биттердин Tдин туурасы.
    ///
    /// Бул ички стабилдештирилген версиялары бүтүндөй примитивдерде `wrapping_sub` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// (A * b) mod 2 <sup>N</sup> кайтарат, мында N-биттердин Tдин туурасы.
    ///
    /// Бул ички стабилдештирилген версиялары бүтүндөй примитивдерде `wrapping_mul` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Сандык чектерде каныккан `a + b` эсептейт.
    ///
    /// Бул ички стабилдештирилген версиялары бүтүндөй примитивдерде `saturating_add` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Сандык чектерде каныккан `a - b` эсептейт.
    ///
    /// Бул ички стабилдештирилген версиялары бүтүндөй примитивдерде `saturating_sub` ыкмасы аркылуу жеткиликтүү.
    /// Мисалы,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// 'v' варианты үчүн дискриминанттын маанисин кайтарып берет;
    /// эгер `T` дискриминанты жок болсо, `0` кайтарып берет.
    ///
    /// Бул ички турукташтырылган версиясы [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// `usize` форматына берилген `T` түрүндөгү варианттардын санын кайтарат;
    /// эгер `T` варианты жок болсо, `0` кайтарат.Жашабаган варианттар эсептелет.
    ///
    /// Бул ички мүнөздөмөнүн турукташтырылган версиясы [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust "try catch" конструкциясы, `try_fn` функция көрсөткүчүн `data` маалымат көрсөткүчү менен иштетет.
    ///
    /// Үчүнчү аргумент, эгер panic пайда болсо, аталган функция.
    /// Бул функция дайындар көрсөткүчүн жана көрсөткүчтү кармалган максаттуу өзгөчө объектине алып барат.
    ///
    /// Көбүрөөк маалымат алуу үчүн, компилятордун булагын жана std кармоонун ишке ашырылышын караңыз.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// LLVM боюнча `!nontemporal` дүкөнүн чыгарат (алардын документтерин караңыз).
    /// Балким, эч качан туруктуу болбойт.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Чоо-жайын билүү үчүн `<*const T>::offset_from` документтерин караңыз.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Чоо-жайын билүү үчүн `<*const T>::guaranteed_eq` документтерин караңыз.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Чоо-жайын билүү үчүн `<*const T>::guaranteed_ne` документтерин караңыз.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Компиляция убагында бөлүп берүү.Иштеп жатканда чалууга болбойт.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Айрым функциялар ушул модулда кокустан туруктуу болуп калгандыктан, ушул жерде аныкталган.
// <https://github.com/rust-lang/rust/issues/15702> караңыз.
// (`transmute` дагы ушул категорияга кирет, бирок `T` менен `U` бирдей өлчөмдө экендигин текшергендиктен, ороого болбойт.)
//

/// `ptr` `align_of::<T>()` карата туура шайкеш келтирилгенин текшерет.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// `count *size_of::<T>()` байтты `src` тен `dst` ке чейин көчүрөт.Булак жана көздөгөн жер* бири-бирине дал келбеши керек.
///
/// Эстутумдун кабатталып калышы мүмкүн болгон аймактары үчүн, анын ордуна [`copy`] колдонуңуз.
///
/// `copy_nonoverlapping` семантикалык жактан C's [`memcpy`] эквивалентине ээ, бирок аргумент тартиби алмаштырылган.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Төмөнкү шарттардын бири бузулса, жүрүм-турум аныкталбайт:
///
/// * `src` `count * size_of::<T>()` байтты окуу үчүн [valid] болушу керек.
///
/// * `dst` `count * size_of::<T>()` байтты жазуу үчүн [valid] болушу керек.
///
/// * `src` жана `dst` экөө тең туура шайкеш келтирилиши керек.
///
/// * Эсептөө аймагы `src` тен баштап, эсептөө өлчөмү менен башталат *
///   size_of: :<T>() `байт бирдей өлчөм менен `dst` тен башталган эс тутумунун аймагы менен * дал келбеши керек.
///
/// [`read`] сыяктуу эле, `copy_nonoverlapping` `T` [`Copy`] экендигине карабастан, `T` тин биттик көчүрмөсүн түзөт.
/// Эгерде `T` [`Copy`] болбосо, анда `*src` тен башталуучу региондогу жана `* dst` тен башталуучу региондогу *экөөнү тең* колдонуп [violate memory safety][read-ownership] кыла алат.
///
///
/// Натыйжалуу көчүрүлгөн көлөмдө деле ("count * size_of: :::)<T>()`) `0`, көрсөткүчтөр NULL болбошу керек жана туура шайкеш келтирилиши керек.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// [`Vec::append`] кол менен ишке ашырылат:
///
/// ```
/// use std::ptr;
///
/// /// `src` тин бардык элементтерин `dst` ке жылдырып, `src` ти бош калтырат.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // `dst` тин `src` тин бардыгын кармоо үчүн жетиштүү кубаттуулугун камсыз кылыңыз.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Эсепке чакыруу ар дайым коопсуз, анткени `Vec` эч качан `isize::MAX` байтты бөлбөйт.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Анын мазмунун түшүрбөй `src` кесүү.
///         // Биринчиден, panics төмөндөп кетсе, көйгөйгө кабылбоо үчүн, биз муну биринчи жасайбыз.
///         src.set_len(0);
///
///         // Эки аймак бири-бирине дал келе албайт, анткени өзгөрүлмө шилтемелер лакап ат эмес, жана эки башка vectors бир эле эс тутумга ээ боло албайт.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Эми `src` камтылганы жөнүндө `dst` ке кабарлаңыз.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Бул текшерүүлөрдү иштөө убагында гана жүргүзүңүз
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Кодегендин таасирин кичинекей кылуу үчүн паникага учурабаңыз.
        abort();
    }*/

    // КООПСУЗДУК: `copy_nonoverlapping` үчүн коопсуздук келишими болушу керек
    // чалган адам тарабынан колдоого алынган.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// `count * size_of::<T>()` байтты `src` тен `dst` ке чейин көчүрөт.Булагы менен көздөгөн жери дал келиши мүмкүн.
///
/// Эгер булак жана көздөгөн жер * эч качан бири-бирине дал келбесе, анын ордуна [`copy_nonoverlapping`] колдонсо болот.
///
/// `copy` семантикалык жактан C's [`memmove`] эквивалентине ээ, бирок аргумент тартиби алмаштырылган.
/// Көчүрүү, байттар `src` ден убактылуу массивге көчүрүлүп, андан кийин массивден `dst` ке көчүрүлгөндөй эле жүрөт.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Төмөнкү шарттардын бири бузулса, жүрүм-турум аныкталбайт:
///
/// * `src` `count * size_of::<T>()` байтты окуу үчүн [valid] болушу керек.
///
/// * `dst` `count * size_of::<T>()` байтты жазуу үчүн [valid] болушу керек.
///
/// * `src` жана `dst` экөө тең туура шайкеш келтирилиши керек.
///
/// [`read`] сыяктуу эле, `copy` `T` [`Copy`] экендигине карабастан, `T` тин биттик көчүрмөсүн түзөт.
/// Эгерде `T` [`Copy`] болбосо, анда `*src` тен башталуучу аймактын жана `* dst` тен башталуучу аймактын маанилери [violate memory safety][read-ownership] болот.
///
///
/// Натыйжалуу көчүрүлгөн көлөмдө деле ("count * size_of: :::)<T>()`) `0`, көрсөткүчтөр NULL болбошу керек жана туура шайкеш келтирилиши керек.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Кооптуу буферден натыйжалуу Rust vector түзүңүз:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` анын түрүнө жана нөлгө туура келбеши керек.
/// /// * `ptr` `T` тибиндеги `elts` чектеш элементтерин окуу үчүн жарактуу болушу керек.
/// /// * `T: Copy` болбосо, бул функцияны чакыргандан кийин ал элементтерди колдонууга болбойт.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // КООПСУЗДУК: Биздин алдын-ала шарт булактын тегизделишин жана жарактуу болушун камсыз кылат,
///     // жана `Vec::with_capacity` аларды жазуу үчүн колдоно турган мейкиндигибиз бар экендигин камсыз кылат.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // КООПСУЗДУК: Биз аны ушунчалык кубаттуулук менен эртерээк жаратканбыз,
///     // жана мурунку `copy` бул элементтерди башталды.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Бул текшерүүлөрдү иштөө убагында гана жүргүзүңүз
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Кодегендин таасирин кичинекей кылуу үчүн паникага учурабаңыз.
        abort();
    }*/

    // КООПСУЗДУК: `copy` үчүн коопсуздук келишимин чалган адам сакташы керек.
    unsafe { copy(src, dst, count) }
}

/// `count * size_of::<T>()` байт эс тутумун `dst` тен `val` ке чейин баштайт.
///
/// `write_bytes` Cдин [`memset`] сымал окшош, бирок `count * size_of::<T>()` байтты `val` кылып белгилейт.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Төмөнкү шарттардын бири бузулса, жүрүм-турум аныкталбайт:
///
/// * `dst` `count * size_of::<T>()` байтты жазуу үчүн [valid] болушу керек.
///
/// * `dst` туура тегизделиши керек.
///
/// Андан тышкары, чалган адам `count * size_of::<T>()` байттын эс тутумдун берилген аймагына жазылышы `T` маанисине ээ болушун камсыз кылышы керек.
/// Жараксыз `T` маанисин камтыган `T` катары терилген эс тутумун колдонуу аныкталбаган иш-аракет.
///
/// Натыйжалуу көчүрүлгөн көлөмдө деле ("count * size_of: :::)<T>()`) `0`, көрсөткүч NULL болбошу керек жана туура шайкеш келтирилиши керек.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Негизги колдонуу:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Жараксыз маанини түзүү:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Мурунку маанини нөл көрсөткүчү менен `Box<T>` үстүнө жазуу менен кетирет.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Бул учурда, `v` колдонуу же түшүрүү аныкталбаган жүрүм-турумга алып келет.
/// // drop(v); // ERROR
///
/// // Ал тургай, `v` "uses" аны агып, демек, аныкталбаган жүрүм-турум болуп саналат.
/// // mem::forget(v); // ERROR
///
/// // Чындыгында, `v` негизги макетинин инварианттарына ылайык жараксыз, андыктан ага *тийип жаткан* иш-аракет аныкталбаган иш-аракет.
/////
/// // v2 =v коёлу;//КАТА
///
/// unsafe {
///     // Келгиле, анын ордуна жарактуу маани берели
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Азыр куту жакшы
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // КООПСУЗДУК: `write_bytes` үчүн коопсуздук келишимин чалган адам сакташы керек.
    unsafe { write_bytes(dst, val, count) }
}