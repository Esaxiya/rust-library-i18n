use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Бул туруктуу жер аянты эмес, бирок LLVM азырынча анын мүмкүнчүлүктөрүн колдоно албаса дагы, алардын ортосунда `?` арзан сактоого жардам берет.
    //
    // (Тилекке каршы, Жыйынтык жана Опция бири-бирине дал келбейт, андыктан ControlFlow экөөнө тең дал келбейт.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}