//! DWARF коддолгон маалымат агымдарын талдоочу утилиталар.
//! <http://www.dwarfstd.org>, DWARF-4 стандартын, 7-бөлүм, "Data Representation" караңыз
//!

// Бул модулду азырынча x86_64-pc-windows-gnu гана колдонуп жатат, бирок биз регрессияны болтурбоо үчүн аны бардык жерде түзүп жатабыз.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // DWARF агымдары толгон, андыктан, мисалы, u32 сөзсүз түрдө 4 байттык чек ара боюнча тегизделбейт.
    // Бул катуу тегиздөө талаптары менен платформаларда көйгөйлөрдү жаратышы мүмкүн.
    // Берилген маалыматтарды "packed" структурасына ороп, биз backendке "misalignment-safe" кодун түзүүнү айтып жатабыз.
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128 жана SLEB128 коддору 7.6, "Variable Length Data" бөлүмүндө аныкталган.
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}