//! Miri үчүн panics оролуп жатат.
use alloc::boxed::Box;
use core::any::Any;

// Miri кыймылдаткычы биз үчүн ачуу аркылуу тараган пайдалуу жүктүн түрү.
// Көрсөткүч өлчөмүндө болушу керек.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Ачууну баштоо үчүн Miri тарабынан берилген extern функциясы.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // `miri_start_panic` ке өткөн пайдалуу жүк, төмөндөгү `cleanup` аргументи болот.
    // Ошентип, биз жөн гана бир жолу кутучасына, көлөмү бир нерсе алуу үчүн.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Негизги `Box` калыбына келтирүү.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}