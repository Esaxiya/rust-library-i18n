//! Windows SEH
//!
//! Windows де (учурда MSVCде гана), демейки өзгөчө кырдаалды иштетүү механизми-Structured Exception Handling (SEH).
//! Бул карликке негизделген өзгөчө иш алып баруудан (мисалы, башка unix платформаларын колдонгондон) айырмаланып турат, ошондуктан LLVM SEH үчүн кошумча колдоону талап кылат.
//!
//! Кыскача айтканда, бул жерде эмне болот:
//!
//! 1. `panic` функциясы стандарттык Windows функциясын `_CxxThrowException` деп атайт, C++ ыргытып жиберүү, айрыкча, бошоңдоо процесси башталат.
//! 2.
//! Компилятор түзгөн бардык конуучу аянттар `__CxxFrameHandler3` инсандык функциясын, CRT функциясын колдонушат, ал эми Windows теги ачуу коду стекдеги бардык тазалоо коддорун аткаруу үчүн ушул инсандык функцияны колдонот.
//!
//! 3. Бардык компилятор чыгарган `invoke` чалуулар `cleanuppad` LLVM көрсөтмөсү катары орнотулган конуучу аянтка ээ, бул тазалоо иштеринин башталгандыгын билдирет.
//! Тазалоо иштерин жүргүзүү үчүн инсан (CRTде аныкталган 2-кадамда) жооп берет.
//! 4. Акыры, X001 ички кодундагы "catch" коду (компилятор тарабынан түзүлгөн) аткарылат жана башкаруу Rust ге кайтып келиши керектигин көрсөтөт.
//! Бул, `catchswitch` плюс LL0M IR шарттарындагы `catchpad` көрсөтмөлөрү аркылуу ишке ашырылып, акырында `catchret` көрсөтмөлөрү менен программага кадимки башкарууну кайтаруу.
//!
//! gcc негизделген өзгөчө колдонуудан айрым айрым айырмачылыктар:
//!
//! * Rust колдонуучунун жеке функциясы жок, ал *ар дайым*`__CxxFrameHandler3`.Мындан тышкары, эч кандай кошумча чыпкалоо жүргүзүлбөйт, андыктан биз ыргытып жаткан нерсеге окшош болгон C++ өзгөчө учурларын кармайбыз.
//! Белгилей кетүүчү жагдай, Rust ичине өзгөчө кырдаалды киргизүү-бул баары бир аныкталбаган иш-аракет, ошондуктан бул жакшы болушу керек.
//! * Чек арадан өткөрүү үчүн айрым маалыматтар бар, атап айтканда `Box<dyn Any + Send>`.Эргежээл учурлардан тышкары, бул эки көрсөткүч өзгөчө кырдаалда өзүнө пайдалуу жүк катары сакталат.
//! MSVCде болсо, кошумча үймөктөрдү бөлүүнүн кажети жок, анткени чыпкалар функциялары аткарылып жатканда чалуулар стеги сакталат.
//! Демек, көрсөткүчтөр түздөн-түз `_CxxThrowException` ке өтүп, андан кийин `try` ички стек алкагына жазуу үчүн чыпка функциясында калыбына келтирилет.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Бул Опция болушу керек, анткени биз өзгөчө учурду шилтеме менен кармайбыз жана анын деструктору C++ иштөө убактысы менен аткарылат.
    // Кутучаны өзгөчө абалдан чыгарганда, анын деструктору Кутуну эки жолу түшүрбөй чуркап иштеши үчүн, өзгөчө абалды өзгөчө абалда калтырышыбыз керек.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Биринчиден, типтеги аныктамалардын бир тутамы.Бул жерде бир нече платформага байланыштуу кызыктай жагдайлар бар, жана LLVMден ачык эле көчүрүлүп алынган көп нерсе бар.Мунун максаты-`_CxxThrowException` чалуу аркылуу төмөндөгү `panic` функциясын ишке ашыруу.
//
// Бул функция эки аргументти алат.Биринчиси, биз өткөрүп жаткан маалыматтардын көрсөткүчү, бул учурда биздин trait объектибиз.Табуу оңой!Кийинки, бирок татаал.
// Бул `_ThrowInfo` структурасынын көрсөткүчү жана адатта жөн гана ыргытылып жаткан өзгөчө кырдаалды сүрөттөө үчүн арналган.
//
// Учурда [1] түрүнүн аныктамасы бир аз түктүү, ал эми негизги таң калыштуусу (жана интернеттеги макаладан айырмачылыгы) 32 биттеги көрсөткүчтөр көрсөткүчтөр, ал эми 64-биттеги көрсөткүчтөр 32 биттик жылыштар катары көрсөтүлгөн `__ImageBase` белгиси.
//
// Муну билдирүү үчүн төмөндөгү модулдардагы `ptr_t` жана `ptr!` макро колдонулат.
//
// Тип аныктамаларындагы лабиринт LLVM ушул түрдөгү иш-аракет үчүн эмнелерди бөлүп чыгаргандыгын тыкыр байкап турат.Мисалы, бул C++ кодун MSVCке түзсөңүз жана LLVM IR чыгарсаңыз:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      боштук foo() { rust_panic a = {0, 1};
//          ыргытуу а;}
//
// Негизинен ушул нерсени тууроого аракет кылып жатабыз.Төмөндөгү туруктуу маанилердин көпчүлүгү LLVMден көчүрүлүп алынган,
//
// Кандай болгон күндө дагы, бул структуралардын бардыгы ушундай эле ыкма менен курулган жана бул биз үчүн кандайдыр бир деңгээлде түшүнүктүү.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Бул жерде аты-жөнүн жок кылуу эрежелерин атайылап четке кагып жаткандыгыбызга көңүл буруңуз: биз C++ дан `struct rust_panic` жарыялоо менен Rust panics кармашын каалабайбыз.
//
//
// Өзгөртүүдө, түрдүн аталышы сабы `compiler/rustc_codegen_llvm/src/intrinsic.rs` те колдонулганга дал келгенин текшериңиз.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Бул жерде алдыңкы `\x01` байт, чындыгында, `_` символу менен префикстөө сыяктуу башка эч кандай манинг колдонбоо * үчүн LLVMге сыйкырдуу сигнал.
    //
    //
    // Бул символ C++ 'дин `std::type_info` тарабынан колдонгон vtable болуп саналат.
    // `std::type_info` типтеги объектилер, типтин дескрипторлору, ушул таблицанын көрсөткүчүнө ээ.
    // Түрдүн дескрипторлоруна жогоруда аныкталган жана төмөндө курган C++ EH структуралары шилтеме беришет.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Бул типтеги дескриптор өзгөчө учурларды киргизгенде гана колдонулат.
// Кармоо бөлүгүн, өзүнүн TypeDescriptor түзүүчү, intrinsic тарабынан башкарылат.
//
// Бул жакшы, анткени MSVC иштөө убактысы көрсөткүч теңдигине эмес, TypeDescriptors матчына дал келүү үчүн типтин аталышындагы сап салыштыруусун колдонот.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// C ++ коду өзгөчө кырдаалды колго алып, аны жайылтпастан таштоону чечсе, колдонулган деструктор.
// Try intrinsic кармоонун бөлүгү, өзгөчө объектинин биринчи сөзүн деструктор өткөрүп жиберип, 0 кылып коет.
//
// x86 Windows демейки "C" чакыруу конвенциясынын ордуна C++ мүчө функциялары үчүн "thiscall" чакыруу конвенциясын колдоноорун эске алыңыз.
//
// Exception_copy функциясы бул жерде бир аз өзгөчө: ал MSVC иштөө убактысы аркылуу try/catch блогунун астында иштейт жана биз чыгарган panic өзгөчө көчүрмөнүн натыйжасында колдонулат.
//
// Муну C++ иштөө убактысы колдонуп, биз std::exception_ptr менен өзгөчөлүктөрдү жаздырып алууну колдойбуз, анткени биз Boxту колдой албайбыз<dyn Any>клондоштурулган эмес.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException толугу менен ушул стек алкагында иштейт, андыктан `data` ти үймөктө өткөрүүнүн кажети жок.
    // Бул функцияга жөн гана стек көрсөткүчүн өткөрүп беребиз.
    //
    // ManuallyDrop бул жерде керек, анткени биз ачып жатканда өзгөчө кырдаалдын түшүп калышын каалабайбыз.
    // Анын ордуна, ал C++ иштөө убактысы аркылуу чакырылган exception_cleanup тарабынан алынып салынат.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Бул ... таң калыштуу көрүнүшү мүмкүн жана негиздүү.32-биттик MSVCде бул түзүмдүн ортосундагы көрсөткүчтөр дал ушул, көрсөткүчтөр.
    // 64-биттик MSVCде, бирок түзүмдөрдүн ортосундагы көрсөткүчтөр `__ImageBase` тен 32 биттик жылыштар катары көрсөтүлөт.
    //
    // Демек, 32 биттик MSVCде биз ушул көрсөткүчтөрдүн бардыгын жогорудагы "static`s" деп жарыялай алабыз.
    // 64-биттик MSVCде, көрсөткүчтөрдү алып таштоону статикада билдиришибиз керек, буга Rust жол бербейт, андыктан биз аны аткара албайбыз.
    //
    // Кийинки эң жакшы нерсе, бул структураларды иштеп жатканда толтуруу (паника "slow path" баары бир болуп жатат).
    // Ошентип, бул көрсөткүч талааларынын бардыгын 32 биттик бүтүн сандар катары чечмелеп, андан кийин ага тиешелүү маанини сактайбыз (panics окшош болушу мүмкүн).
    //
    // Техникалык түрдө иштөө убактысы бул талааларды атомдук эмес окушу мүмкүн, бирок теориялык жактан алар эч качан *туура эмес* маанини окушпайт, андыктан өтө жаман болбошу керек ...
    //
    // Кандай болгон күндө дагы, биз статикада көбүрөөк операцияларды билдирмейинче (биз эч качан жасай албайбыз), ушуга окшогон нерсени жасашыбыз керек.
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Бул жердеги NULL жүк, бул биз Xrx_rust_try аракетинен келип чыккандыгыбызды билдирет.
    // Бул Rust эмес чет өлкөлүк өзгөчө кырдаал кармалып калганда болот.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Муну компилятор талап кылат (мисалы, бул lang пункту), бирок аны эч качан компилятор чакырбайт, анткени __C_specific_handler же _except_handler3 ар дайым колдонулуп турган инсандык функция.
//
// Демек, бул жөн эле бойдон алдыруучу стуб.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}