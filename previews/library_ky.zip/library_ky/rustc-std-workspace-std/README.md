# `rustc-std-workspace-std` crate

`rustc-std-workspace-core` crate үчүн документтерди караңыз.