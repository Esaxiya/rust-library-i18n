`core::arch` - Rust негизги китепкана архитектурасына мүнөздүү ички
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` модулу архитектурага көз каранды интриниканы (мисалы, SIMD) ишке ашырат.

# Usage 

`core::arch` `libcore` бөлүгү катары жеткиликтүү жана ал `libstd` тарабынан экспорттолот.Ушул crate ге караганда `core::arch` же `std::arch` аркылуу колдонуңуз.
Туруксуз функциялар көбүнчө түнкү Rust де `feature(stdsimd)` аркылуу жеткиликтүү.

`core::arch` ти ушул crate аркылуу колдонуу үчүн түнкүсүн Rust талап кылынат жана ал тез-тез бузулуп кетиши мүмкүн.Ушул crate аркылуу колдонууну караштырган бирден-бир учурлар:

* эгер сиз `core::arch` ти өзүңүздөн кайра компиляциялашыңыз керек болсо, мисалы, `libcore`/`libstd` үчүн иштетилбеген максаттуу өзгөчөлүктөр иштетилген.
Note: эгерде сиз аны стандарттуу эмес максат үчүн кайрадан компиляциялашыңыз керек болсо, анда бул crate ордуна `xargo` колдонуп, `libcore`/`libstd` ти ылайыктуу кылып түзүңүз.
  
* туруксуз Rust өзгөчөлүктөрүнүн артында дагы жеткиликсиз болушу мүмкүн болгон айрым функцияларды колдонуу.Биз буларды минимумга жеткирүүгө аракет кылабыз.
Эгер сиз ушул функциялардын айрымдарын колдонушуңуз керек болсо, анда көйгөйдү ачыңыз, ошондо биз аларды түнкүсүн Rust де ачыкка чыгара алабыз жана сиз аларды ошол жерден колдоно аласыз.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` биринчи кезекте MIT лицензиясынын жана Apache Лицензиясынын (2.0 версиясы) шарттарында бөлүштүрүлөт, анын бөлүктөрү BSD сыяктуу ар кандай лицензиялар менен жабылат.

Көбүрөөк маалымат алуу үчүн LICENSE-APACHE жана LICENCE-MIT караңыз.

# Contribution

Эгерде сиз ачык эле башкача айтпасаңыз, анда Apache-2.0 лицензиясында аныкталгандай, сиз `core_arch` ке киргизүү үчүн атайылап тапшырган салым, эч кандай кошумча шарттарсыз, жогорудагыдай кош лицензиялуу болушат.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












