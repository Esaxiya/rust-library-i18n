use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Биздин `#[assert_instr]` аннотацияларыбызга бардык симд интриникалар кодгенин текшерүү үчүн жеткиликтүү деп айтуу үчүн колдонулат, анткени кээ бирлери `#[target_feature]` эквиваленти жок ашыкча `-Ctarget-feature=+unimplemented-simd128` артында турат.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}