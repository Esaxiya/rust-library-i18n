# Stdarch салымы

`stdarch` crate салымдарды кабыл алууга даяр!Алгач репозиторийди текшерип, тесттер сиз үчүн ийгиликтүү өткөнүн текшерип көрүңүз:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Эгерде `<your-target-arch>` бул `rustup` тарабынан колдонулган максаттуу үч эсе, мисалы `x86_x64-unknown-linux-gnu` (мурунку `nightly-` же ушул сыяктуу нерселерсиз).
Ошондой эле, бул кампага Rust түнкү каналы керек экендигин унутпаңыз!
Жогорудагы тесттер чындыгында `rustup default nightly` (жана `rustup default stable` кайтаруу үчүн) колдонгон орнотуу үчүн, түнкүсүн rust тутумуңуздун демейки болушун талап кылат.

Эгерде жогоруда көрсөтүлгөн кадамдардын бири иштебесе, [please let us know][new]!

Кийинчерээк сиз жардам берүү үчүн [find an issue][issues] аласыз, биз [`help wanted`][help] жана [`impl-period`][impl] тэгдери менен бир нечесин тандадык, алар өзгөчө жардамды колдонушу мүмкүн. 
Сизди [#40][vendor] баардык сатуучулардын ички белгилерин ишке ашыруу менен кызыктырышы мүмкүн.Бул чыгарылыштан эмнени баштоо керектиги жөнүндө жакшы көрсөтмөлөр бар!

Эгерде сизде жалпы суроолор болсо, [join us on gitter][gitter] ке кайрылыңыз жана сураңыз!Суроолоруңуз менен@BurntSushi же@alexcrichton пингин тартыңыз.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Stdarch intrinsics үчүн мисалдарды кантип жазууга болот

Берилген ички иштин талаптагыдай иштеши үчүн бир нече өзгөчөлүктөрдү иштетүү керек жана мисал `cargo test --doc` тарабынан иштетилиши керек, эгер бул функция CPU тарабынан колдоого алынса.

Натыйжада, `rustdoc` тарабынан иштелип чыккан демейки `fn main` иштебей калат (көпчүлүк учурларда).
Сиздин үлгүңүз күткөндөй иштешин камсыз кылуу үчүн төмөнкүлөрдү колдонмо катары колдонуп көрүңүз.

```rust
/// # // Мисалы cfg_target_feature керек, мисал гана
/// # // CPU функцияны колдогондо `cargo test --doc` тарабынан иштетилет
/// # #![feature(cfg_target_feature)]
/// # // Ички адамдын иштеши үчүн бизге target_feature керек
/// # #![feature(target_feature)]
/// #
/// # // rustdoc демейки боюнча `extern crate stdarch` колдонот, бирок бизге керек
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Чыныгы негизги функция
/// # fn main() {
/// #     // `<target feature>` колдоого алынган учурда гана аны иштетүү
/// #     эгер cfg_feature_enabled! ("<target feature>"){
/// #         // Максаттуу өзгөчөлүк болсо гана иштей турган `worker` функциясын түзүңүз
/// #         // колдоого алынат жана `target_feature` сиздин жумушчуңуз үчүн иштетилгенине ынаныңыз
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         кооптуу fn worker() {
/// // Өзүңүздүн мисалыңызды ушул жерге жазыңыз.Бул жерде өзгөчөлүктөрдүн өзгөчөлүктөрү иштейт!Жапайы!
///
/// #         }
///
/// #         кооптуу { worker(); }
/// #     }
/// # }
```

Эгерде жогорудагы синтаксистин айрымдары тааныш көрүнбөсө, [Rust Book] тин [Documentation as tests] бөлүмү `rustdoc` синтаксисин жакшы сүрөттөйт.
Адаттагыдай эле, [join us on gitter][gitter] менен байланышуудан тартынба жана бизден кандайдыр бир шылдыңга кабылган жокпу деп сурап, `stdarch` тин документтерин өркүндөтүүгө жардам бергениң үчүн рахмат!

# Альтернативдик тестирлөө көрсөтмөлөрү

Тесттерди өткөрүү үчүн, адатта, `ci/run.sh` колдонуу сунушталат.
Бирок бул сиз үчүн иштебей калышы мүмкүн, мисалы, Windows де болсоңуз.

Мындай учурда сиз `cargo +nightly test` жана `cargo +nightly test --release -p core_arch` иштетип, коддун жаралышын текшерип алсаңыз болот.
Бул үчүн түнкү шаймандар орнотулуп, `rustc` сиздин максаттуу үч эсе жана анын CPU жөнүндө билиши керектигин эске алыңыз.
Атап айтканда `TARGET` чөйрөсүнүн өзгөрмөсүн `ci/run.sh` үчүн орнотушуңуз керек.
Мындан тышкары, максаттуу өзгөчөлүктөрдү көрсөтүү үчүн `RUSTCFLAGS` (`C` керек) орнотушуңуз керек, мисалы `RUSTCFLAGS="-C -target-features=+avx2"`.
Эгер сиз "just" учурдагы процессорго каршы иштеп жатсаңыз, анда `-C -target-cpu=native` коё аласыз.

Ушул альтернативдик көрсөтмөлөрдү колдонуп жатканда, мисалы, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], деп эскертиңиз
Нускаманы жаратуу тесттери ийгиликсиз болуп калышы мүмкүн, себеби аларды бөлүп-жаргыч башкача атаган, мисалы
Ал `aesenc` көрсөтмөлөрүнүн ордуна `vaesenc` жасап чыгышы мүмкүн, бирок алар бирдей иштешет.
Ошондой эле, бул нускамада, адатта, аткарылгандан азыраак тестирлөөлөр жүргүзүлөт, андыктан акыры келип, сураганда, бул жерде камтылбаган тесттер үчүн кээ бир каталар кетиши мүмкүн деп таң калбаңыз.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






