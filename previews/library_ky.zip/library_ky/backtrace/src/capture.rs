use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Менчиктелген жана өзүн-өзү камтыган арткы тректи чагылдыруу.
///
/// Бул түзүм программанын ар кайсы учурларында арткы тректи тартуу үчүн колдонулуп, кийинчерээк ошол кездеги артта калган нерсени текшерүү үчүн колдонулат.
///
///
/// `Backtrace` анын `Debug` жүзөгө ашыруу аркылуу арткы тректердин сулуу басып чыгарылышын колдойт.
///
/// # Керектүү өзгөчөлүктөр
///
/// Бул функция `backtrace` crate `std` өзгөчөлүгүн иштетүүнү талап кылат, ал эми `std` функциясы демейки боюнча иштетилет.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Бул жерде кадрлар стектин жогорудан төмөн жагына чейин келтирилген
    frames: Vec<BacktraceFrame>,
    // `Backtrace::new` жана `backtrace::trace` сыяктуу алкактарды өткөрүп жиберип, артка чегинүүнүн чыныгы башталышы деп эсептеген индекс.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Арткы трек боюнча кадрдын тартылып алынган версиясы.
///
/// Бул түр `Backtrace::frames` тизмеси катары кайтарылып берилген жана артта калган артта калган стек алкагын чагылдырат.
///
/// # Керектүү өзгөчөлүктөр
///
/// Бул функция `backtrace` crate `std` өзгөчөлүгүн иштетүүнү талап кылат, ал эми `std` функциясы демейки боюнча иштетилет.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Арткы трек боюнча символдун тартылып алынган версиясы.
///
/// Бул түр `BacktraceFrame::symbols` тизмеси катары кайтарылып берилген жана артка чегинүү белгисинин метадайындарын билдирет.
///
/// # Керектүү өзгөчөлүктөр
///
/// Бул функция `backtrace` crate `std` өзгөчөлүгүн иштетүүнү талап кылат, ал эми `std` функциясы демейки боюнча иштетилет.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Бул функциянын чалитситинде арткы тректи тартып, таандык өкүлчүлүктү кайтарып берет.
    ///
    /// Бул функция Rust ичинде объект катары арткы тректи көрсөтүү үчүн пайдалуу.Бул кайтарылган маани жиптер аркылуу жөнөтүлүп, башка жерлерге басылып чыгарылышы мүмкүн жана анын мааниси толугу менен камтылган.
    ///
    /// Кээ бир платформаларда толук артка чегинүү жана аны чечүү өтө кымбатка турарын эске алыңыз.
    /// Эгерде сиздин колдонмоңуз үчүн чыгым өтө эле көп болсо, анын ордуна `Backtrace::new_unresolved()` колдонсоңуз болот, ал белгилерди чечүү кадамынан качат (ал адатта эң узак убакытты талап кылат) жана кийинкиге калтырууга мүмкүндүк берет.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Керектүү өзгөчөлүктөр
    ///
    /// Бул функция `backtrace` crate `std` өзгөчөлүгүн иштетүүнү талап кылат, ал эми `std` функциясы демейки боюнча иштетилет.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // алып салуу үчүн бул жерде алкак бар экенине ынануу керек
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// `new` ке окшош, анткени бул эч кандай белгилерди чечпейт, бул жөн гана арткы тректи даректердин тизмеси катары камтыйт.
    ///
    /// Кийинчерээк `resolve` функциясын чакырып, бул артка чегинүү белгилерин окула турган аталыштарга айландырууга болот.
    /// Бул функция иштейт, анткени чечүү процесси кээде бир топ убакытты алат, ал эми артка чегинүү сейрек басылып чыгышы мүмкүн.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // символ аттары жок
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // азыр символдордун аттары бар
    /// ```
    ///
    /// # Керектүү өзгөчөлүктөр
    ///
    /// Бул функция `backtrace` crate `std` өзгөчөлүгүн иштетүүнү талап кылат, ал эми `std` функциясы демейки боюнча иштетилет.
    ///
    ///
    ///
    #[inline(never)] // алып салуу үчүн бул жерде алкак бар экенине ынануу керек
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Ушул артка тартылган кадрларды кайтарып берет.
    ///
    /// Бул тилменин биринчи жазылышы, сыягы, `Backtrace::new` функциясы, ал эми акыркы кадр бул жиптин же негизги функциянын кантип башталгандыгы жөнүндө болушу мүмкүн.
    ///
    ///
    /// # Керектүү өзгөчөлүктөр
    ///
    /// Бул функция `backtrace` crate `std` өзгөчөлүгүн иштетүүнү талап кылат, ал эми `std` функциясы демейки боюнча иштетилет.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Эгерде бул артка чегинүү `new_unresolved` тен түзүлгөн болсо, анда бул функция арткы трекдеги бардык даректерди алардын символикалык аталыштарына жараша чечет.
    ///
    ///
    /// Эгерде бул артка чегинүү мурда чечилсе же `new` аркылуу түзүлгөн болсо, анда бул функция эч нерсе кылбайт.
    ///
    /// # Керектүү өзгөчөлүктөр
    ///
    /// Бул функция `backtrace` crate `std` өзгөчөлүгүн иштетүүнү талап кылат, ал эми `std` функциясы демейки боюнча иштетилет.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// `Frame::ip` сыяктуу
    ///
    /// # Керектүү өзгөчөлүктөр
    ///
    /// Бул функция `backtrace` crate `std` өзгөчөлүгүн иштетүүнү талап кылат, ал эми `std` функциясы демейки боюнча иштетилет.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// `Frame::symbol_address` сыяктуу
    ///
    /// # Керектүү өзгөчөлүктөр
    ///
    /// Бул функция `backtrace` crate `std` өзгөчөлүгүн иштетүүнү талап кылат, ал эми `std` функциясы демейки боюнча иштетилет.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// `Frame::module_base_address` сыяктуу
    ///
    /// # Керектүү өзгөчөлүктөр
    ///
    /// Бул функция `backtrace` crate `std` өзгөчөлүгүн иштетүүнү талап кылат, ал эми `std` функциясы демейки боюнча иштетилет.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Бул алкакка дал келген белгилердин тизмесин кайтарат.
    ///
    /// Адатта, бир кадрга бир гана символ бар, бирок кээде бир катар функциялар бир алкакка салынса, анда бир нече белгилер кайтарылып берилет.
    /// Тизмеде биринчи белгиси "innermost function", ал эми акыркы белгиси эң сырткы бөлүгү (акыркы чалуучу).
    ///
    /// Эгерде бул кадр чечиле элек артка чегинүүдөн келип чыкса, анда ал бош тизме менен кайтып келерин эске алыңыз.
    ///
    /// # Керектүү өзгөчөлүктөр
    ///
    /// Бул функция `backtrace` crate `std` өзгөчөлүгүн иштетүүнү талап кылат, ал эми `std` функциясы демейки боюнча иштетилет.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// `Symbol::name` сыяктуу
    ///
    /// # Керектүү өзгөчөлүктөр
    ///
    /// Бул функция `backtrace` crate `std` өзгөчөлүгүн иштетүүнү талап кылат, ал эми `std` функциясы демейки боюнча иштетилет.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// `Symbol::addr` сыяктуу
    ///
    /// # Керектүү өзгөчөлүктөр
    ///
    /// Бул функция `backtrace` crate `std` өзгөчөлүгүн иштетүүнү талап кылат, ал эми `std` функциясы демейки боюнча иштетилет.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// `Symbol::filename` сыяктуу
    ///
    /// # Керектүү өзгөчөлүктөр
    ///
    /// Бул функция `backtrace` crate `std` өзгөчөлүгүн иштетүүнү талап кылат, ал эми `std` функциясы демейки боюнча иштетилет.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// `Symbol::lineno` сыяктуу
    ///
    /// # Керектүү өзгөчөлүктөр
    ///
    /// Бул функция `backtrace` crate `std` өзгөчөлүгүн иштетүүнү талап кылат, ал эми `std` функциясы демейки боюнча иштетилет.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// `Symbol::colno` сыяктуу
    ///
    /// # Керектүү өзгөчөлүктөр
    ///
    /// Бул функция `backtrace` crate `std` өзгөчөлүгүн иштетүүнү талап кылат, ал эми `std` функциясы демейки боюнча иштетилет.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Жолдорду басып чыгарууда биз бар болсо, cwdди сыйрып алууга аракет кылабыз, антпесе биз жөн эле жолду басып чыгарабыз.
        // Биз муну кыска формат үчүн гана жасайбыз, анткени ал толуп калса, биз баарын басып чыгарууну каалайбыз.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}