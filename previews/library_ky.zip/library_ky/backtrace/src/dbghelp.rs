//! Xbxx dbghelp байланыштарын башкарууга жардам берүүчү модуль
//!
//! Windows боюнча Backtraces (жок дегенде MSVC үчүн) негизинен `dbghelp.dll` жана анын курамындагы ар кандай функциялар аркылуу иштейт.
//! Бул функциялар учурда `dbghelp.dll` ке статикалык түрдө шилтемелебестен *динамикалык* жүктөлүүдө.
//! Бул учурда стандарттуу китепкана тарабынан жүзөгө ашырылат (жана теория жүзүндө ал жерде талап кылынат), бирок китепкананын статикалык DLL көзкарандылыгын азайтууга көмөктөшүү керек, анткени арткы тректер адатта милдеттүү эмес.
//!
//! Айткандай эле, `dbghelp.dll` дээрлик ар дайым ийгиликтүү Windows жүктөлөт.
//!
//! Ушул колдоонун бардыгын динамикалык түрдө жүктөп жаткандыктан, `winapi` те чийки аныктамаларды колдоно албайбыз, тескерисинче, функция көрсөткүчүнүн түрлөрүн өзүбүз аныктап, ошону колдонушубуз керек.
//! Биз чындыгында winapi көчүрмөсүн алуу менен алектенүүнү каалабайбыз, ошондуктан бизде Cargo `verify-winapi` өзгөчөлүгү бар, ал бардык байлап койгучтар winapiдегиге дал келет жана бул функция CIде иштетилген.
//!
//! Акырында, `dbghelp.dll` үчүн DLL эч качан түшүрүлбөйт жана бул учурда атайылап жасалгандыгын белгилейсиз.
//! Биз глобалдык кэштей алабыз жана APIге чалуулар ортосунда колдонуп, кымбат loads/unloads тен алыс болобуз.
//! Эгерде бул детекторлордо көйгөй жаралса же ушул сыяктуу нерселер болсо, ал жерге келгенде көпүрөдөн өтө алабыз.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// `SymGetOptions` жана `SymSetOptions` тин айланасында winapi-де жок иштеңиз.
// Болбосо, бул winapi түрлөрүн эки жолу текшергенде гана колдонулат.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Азырынча winapiде аныктала элек
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Бул winapi-де аныкталган, бирок туура эмес (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Азырынча winapiде аныктала элек
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Бул макро `Dbghelp` түзүмүн аныктоо үчүн колдонулат, анын ичинде биз жүктөй турган бардык функционалдык көрсөткүчтөр бар.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll` үчүн жүктөлгөн DLL
            dll: HMODULE,

            // Биз колдоно турган ар бир функция үчүн ар бир функция көрсөткүчү
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Башында DLL жүктөлө элек
            dll: 0 as *mut _,
            // Initiall бардык функциялар динамикалык жүктөлүшү керек деп нөлгө коюлган.
            //
            $($name: 0,)*
        };

        // Ар бир функциянын түрү үчүн ыңгайлуулук typedef.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` ачуу аракеттери.
            /// Эгерде ал иштеп кетсе же `LoadLibraryW` иштебей калса, анда ката кетирилет.
            ///
            /// Panics, эгер китепкана мурунтан эле жүктөлсө.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Биз колдонууну каалаган ар бир ыкманын функциясы.
            // Чакырылганда, ал кэштелген функция көрсөткүчүн окуйт же жүктөйт жана жүктөлгөн маанини кайтарып берет.
            // Жүк ийгиликтүү болот деп ырасталат.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Dbghelp функцияларына шилтеме берүү үчүн тазалоо кулпуларын колдонуу үчүн ыңгайлуу прокси.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Ушул crate ден `dbghelp` API функцияларына жетүү үчүн бардык колдоону баштаңыз.
///
///
/// Белгилей кетүүчү нерсе, бул функция **коопсуз**, анын ички синхрондоштуруусу бар.
/// Ошондой эле, бул функцияны бир нече жолу рекурсивдүү деп атоого болот.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Биринчи кезекте бул функцияны синхрондоштурушубуз керек.Муну башка жиптерден бир учурда же бир жиптин ичинде рекурсивдүү деп атоого болот.
        // Буга караганда алда канча татаал экенине көңүл буруңуз, анткени бул жерде колдонуп жаткан `dbghelp`, * ошондой эле, ушул процессте `dbghelp` номерине чалгандардын бардыгы менен шайкештештирилиши керек.
        //
        // Адатта, `dbghelp` ке бир эле процессте анчалык көп чалуулар болбойт жана биз ага биз гана киребиз деп ишенсек болот.
        // Бирок биз тынчсызданышыбыз керек болгон эң негизги дагы бир колдонуучу бар, ал биз үчүн таң калыштуу нерсе, бирок стандарттуу китепканада.
        // Rust стандарттуу китепканасы арткы тректи колдоо үчүн ушул crate көз каранды жана бул crate crates.io те да бар.
        // Демек, эгер стандарттык китепкана panic арткы трегин басып чыгарып жатса, анда crates.io тен келип чыккан crate менен жарышып, сегоденттерди бузушу мүмкүн.
        //
        // Бул синхрондоштуруу көйгөйүн чечүүгө жардам берүү үчүн, биз бул жерде Windowsтун атайын айла-амалын колдонобуз (бул, акыры, синхрондоштурууга карата Windowsтун чектөөсү).
        // Биз бул чакырууну коргоо үчүн *сессия-жергиликтүү* деп аталган мутекс түзөбүз.
        // Бул жерде стандарттуу китепкана жана ушул crate бул жерде синхрондошуу үчүн Rust деңгээлиндеги APIлерди бөлүшүүнүн кажети жок, тескерисинче, бири-бири менен синхрондошуп жаткандыгын текшерүү үчүн көшөгө артында иштей алат.
        //
        // Ошентип, бул функцияны стандарттык китепкана аркылуу же crates.io аркылуу чакырганда, ошол эле мутекске ээ болуп жаткандыгына толук ишенсек болот.
        //
        // Демек, бул жерде биз биринчи кезекте атомдук `HANDLE` түзөбүз, бул Windows боюнча мутекс деп аталат.
        // Бул функцияны бөлүшкөн башка жиптер менен бир аз синхрондоштуруп, ушул иштин бир мисалында бир гана тутум жаратылышын камсыз кылабыз.
        // Дүйнөдө сакталып калгандан кийин тутка эч качан жабылбай тургандыгын эске алыңыз.
        //
        // Биз чындыгында кулпуну басып өткөндөн кийин, биз аны жөн гана сатып алабыз жана `Init` туткабыз биз аны тапшырып, акыры аны түшүрүүгө жооптуу болот.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Макул, балам!Эми баарыбыз коопсуз синхрондоштурулгандыктан, келгиле, бардыгын иштете баштайлы.
        // Биринчиден, бул процессте `dbghelp.dll` чындыгында жүктөлгөндүгүн камсыз кылышыбыз керек.
        // Статикалык көз карандылыкты болтурбоо үчүн биз муну динамикалуу жасайбыз.
        // Бул тарыхта таң калыштуу байланыштыруучу маселелердин үстүнөн иштөө үчүн жасалып келген жана экилик файлдарды бир аз портативдүү кылууга багытталган, анткени бул жөн гана оңдоочу утилита.
        //
        //
        // `dbghelp.dll` ачкандан кийин, андагы айрым инициализация функцияларын чакырышыбыз керек, бул төмөндө кененирээк.
        // Биз муну бир эле жолу жасайбыз, андыктан бүтүргөн-бүтө электигибизди көрсөткөн глобалдык буль бар.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // `SYMOPT_DEFERRED_LOADS` желегинин орнотулгандыгын текшериңиз, анткени бул жөнүндө MSVCдин өзүнүн документтерине ылайык: "This is the fastest, most efficient way to use the symbol handler.", андыктан жасайлы!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // MSVC менен символдорду чындыгында бапташтырыңыз.Бул ийгиликсиз болуп калышы мүмкүн экендигин эске алыңыз, бирок биз аны этибарга албай жатабыз.
        // Буга чейин техниканын бир тоннасы деле жок, бирок LLVM бул жерде кайтарым мааниин четке каккандай сезилет жана LLVMдеги тазалоочу китепканалардын бири коркунучтуу эскертүүнү басып чыгарат, эгерде бул ишке ашпай калса, бирок аны узак мөөнөттө эске албай койсо болот.
        //
        //
        // Бир нерсе, бул Rust үчүн көп пайда болот, бул стандарттык китепкана жана crates.io теги crate экөө тең `SymInitializeW` үчүн атаандашкысы келет.
        // Стандарттуу китепкана тарыхый жактан тазалоону көпчүлүк учурларда баштоону каалаган, бирок азыр бул crate колдонуп жаткандыктан, кимдир бирөө алгач инициалдаштырууга жетип, экинчиси ошол инициализацияны колго алат.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}