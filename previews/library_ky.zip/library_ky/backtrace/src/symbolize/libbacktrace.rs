//! Libbacktrace-де DWARF-талдоо кодун колдонгон символика стратегиясы.
//!
//! Libbacktrace C китепканасы, адатта, gcc менен бөлүштүрүлүп, арткы тректи жаратууну гана эмес (биз аны колдонбойбуз), ошондой эле арткы тректи символдоштуруп, сызылган кадрлар жана башка нерселер жөнүндө мүчүлүштүктөрдү оңдоочу маалыматтарды иштетүүнү колдойт.
//!
//!
//! Бул жерде ар кандай кооптонууларга байланыштуу салыштырмалуу татаал, бирок негизги идея:
//!
//! * Алгач `backtrace_syminfo` деп атайбыз.Эгер мүмкүн болсо, бул символикалык маалыматтарды динамикалык белгилер таблицасынан алат.
//! * Андан кийин биз `backtrace_pcinfo` деп атабыз.Эгер мүчүлүштүктөрдү оңдоочу таблицалар бар болсо, аларды талдайт жана сап алкактары, файл аттары, сап номерлери ж.б. жөнүндө маалыматты калыбына келтирүүгө мүмкүнчүлүк берет.
//!
//! Эргежээл үстөлдөрүн libbacktraceге кошуу боюнча көптөгөн амалкөйлүктөр бар, бирок бул дүйнөнүн акыры эмес жана төмөндө окуп жатканда жетиштүү түшүнүктүү болот.
//!
//! Бул MSVC эмес жана OSX платформалары үчүн демейки символиканын стратегиясы.Libstd да, бул OSX үчүн демейки стратегия.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Мүмкүн болсо, debuginfo дан келген `function` аталышын жактырыңыз жана, мисалы, сызык алкактары үчүн такыраак болушу мүмкүн.
                // Эгерде ал жок болсо, анда `symname` те көрсөтүлгөн символ таблицасынын атына кайтып барыңыз.
                //
                // Эске салсак, кээде `function` анча-мынча так сезилбейт, мисалы `std::panicking::try::do_call` дин `try<i32,closure>` катарында эмес.
                //
                // Эмне үчүн чындыгында түшүнүксүз, бирок жалпысынан `function` аталышы такыраак окшойт.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // азырынча эч нерсе кылба
}

/// `syminfo_cb` ге өткөн `data` көрсөткүчүнүн түрү
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Чакырыла баштаганда `backtrace_syminfo` бул кайра чалууну сураганда, биз `backtrace_pcinfo` номерине чалабыз.
    // `backtrace_pcinfo` функциясы мүчүлүштүктөрдү оңдоочу маалыматты карап чыгып, file/line маалыматын калыбына келтирүү сыяктуу нерселерди жасоого, ошондой эле сызылган кадрларды түзүүгө аракет кылат.
    // `backtrace_pcinfo` иштебей калышы мүмкүн экендигин же эгерде мүчүлүштүктөрдү оңдоо жөнүндө маалымат болбосо, анда көп нерсени жасай албастыгын эске алыңыз, андыктан биз `syminfo_cb` тен жок дегенде бир белгини чакырып, кайра чалабыз.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `pcinfo_cb` ге өткөн `data` көрсөткүчүнүн түрү
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Libbacktrace API мамлекет түзүүнү колдойт, бирок абалды жок кылууну колдобойт.
// Мен муну жеке мамлекет түзүлүп, андан кийин түбөлүк жашайм деген мааниде кабыл алам.
//
// Мен ушул абалды тазалаган at_exit() иштеткичти каттоодон өткөргүм келет, бирок libbacktrace буга мүмкүнчүлүк бербейт.
//
// Ушул чектөөлөр менен, бул функция биринчи жолу суралганда эсептелген статикалык кэштелген абалга ээ.
//
// Буттрекингдин бардыгы сериялык түрдө болоорун унутпаңыз (бир дүйнөлүк кулпу).
//
// Бул жерде синхрондоштуруунун жоктугу `resolve` тышкы синхрондоштурулган талаптан улам келип чыкканына көңүл буруңуз.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Libbacktraceдин threadsafe мүмкүнчүлүктөрүн колдонбоңуз, анткени биз аны ар дайым синхрондоштурулуп чакырабыз.
        //
        0,
        error_cb,
        ptr::null_mut(), // кошумча маалыматтар жок
    );

    return STATE;

    // Libbacktrace иштеши үчүн, учурдагы аткарылуучу файл үчүн DWARF мүчүлүштүктөрүн оңдоо маалыматын табуу керек.Адатта, муну бир катар механизмдер аркылуу жасайт, бирок алар менен чектелбестен:
    //
    // * /proc/self/exe колдоого алынган платформаларда
    // * Файлдын аталышы абал түзүүдө ачык түрдө берилген
    //
    // Libbacktrace китепканасы-C кодунун чоң бир бөлүгү.Бул, албетте, эс тутумдун коопсуздугунун мүчүлүштүктөрүн билдирет, айрыкча туура эмес түзүлгөн debuginfo менен иштөөдө.
    // Либстд тарыхый жактан булардын көпчүлүгүнө ээ болду.
    //
    // Эгер /proc/self/exe колдонулса, анда биз аларды libbacktrace "mostly correct" деп эсептесек, анда "attempted to be correct" карликтердеги мүчүлүштүктөрдү оңдоо маалыматтары менен таң калыштуу нерселерди жасабайт деп эсептебесек болот.
    //
    //
    // Эгерде биз файлдын атына өтсөк, анда кээ бир платформаларда (мисалы, BSDлерде) зыяндуу актер ошол жерге каалаган файлды жайгаштырышы мүмкүн.
    // Бул libbacktrace файлдын аталышы жөнүндө айта турган болсок, ал каалаган файлды колдонуп, segfaults алып келиши мүмкүн дегенди билдирет.
    // Эгерде биз libbacktrace эч нерсе айтпасак дагы, /proc/self/exe сыяктуу жолдорду колдобогон платформаларда эч нерсе кыла албайт!
    //
    // Файлдын атына өтпөө үчүн * колдон келишинче аракет кылганыбыз менен, /proc/self/exe ти такыр колдобогон платформаларда иштешибиз керек.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Идеалдуу түрдө биз `std::env::current_exe` колдоно тургандыгыбызды эске алыңыз, бирок бул жерде `std` талап кылынбайт.
            //
            // Учурдагы аткарылуучу жолду статикалык аймакка жүктөө үчүн `_NSGetExecutablePath` колдонуңуз (эгер ал өтө эле кичинекей болсо, андан баш тартасыз).
            //
            //
            // Бул жерде libbacktrace-ге бузулган аткарылуучу файлдарда өлбөйбүз деп олуттуу ишенип жаткандыгыбызды эске алыңыз, бирок бул албетте ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows файлдарды ачуу режими бар, ал ачылгандан кийин аны жок кылуу мүмкүн эмес.
            // Жалпысынан бул жерде биз эмне каалайбыз, анткени libbacktraceге өткөрүп бергенден кийин, биздин аткарылуучу программанын өзүбүздүн астыбыздан өзгөрүлбөшүн камсыз кылып, өзүм билемдик менен берилүүчү маалыматтарды libbacktraceге өткөрүп берүү мүмкүнчүлүгүн азайтамыз (туура эмес колдонулушу мүмкүн).
            //
            //
            // Бул жерде бир аз бийлеп, өзүбүздүн сүрөтүбүзгө кандайдыр бир кулпуну орнотууга аракет кылганыбызды эске алганда:
            //
            // * Учурдагы процесстин туткасын алыңыз, анын файлдын атын жүктөңүз.
            // * Файлдын атына файлды туура желектер менен ачыңыз.
            // * Учурдагы процесстин файл атын кайрадан жүктөп, анын бирдей экендигин текшерип алыңыз
            //
            // Эгерде ушунун бардыгы өтүп кетсе, анда биз теория жүзүндө биздин процесстин файлын ачканбыз жана ал өзгөрбөйт деп кепилдик беребиз.FWIW мунун бир тобу тарыхый түрдө libstd көчүрмөсүнөн алынган, ошондуктан бул болуп жаткан окуяны менин эң жакшы чечмелөөм.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Бул статикалык эстутумда жашайт, ошондуктан биз аны кайтарып бере алабыз ..
                static mut BUF: [i8; N] = [0; N];
                // ... жана бул убактылуу болгондуктан, стекте жашайт
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // Бул жерде атайылап `handle` агып жатат, анткени эгерде ал ачык болсо, бул файлдын аталышы биздин кулпуну сактап калышы керек.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Биз жок болгон кесимди кайтарып бергибиз келет, ошондуктан эгерде бардыгы толтурулган болсо жана ал жалпы узундукка барабар болсо, анда аны үзгүлтүккө теңейбиз.
                //
                //
                // Болбосо, ийгилик кайтып жатканда тилекке нул байт камтылгандыгын текшерип алыңыз.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // Учурда артта калган каталар килемдин астында шыпырылып жатат
    let state = init_state();
    if state.is_null() {
        return;
    }

    // `backtrace_syminfo` API'ге чалыңыз, ал (кодду окуп чыккандан кийин) `syminfo_cb` номерине так бир жолу чалышы керек (же ката кетсе керек).
    // Андан кийин биз `syminfo_cb` ичинде көбүрөөк иштейбиз.
    //
    // `syminfo` символдордун таблицасына кайрылып, экиликте мүчүлүштүктөрдү оңдоочу маалымат жок болсо дагы, символдордун аттарын табат, анткени биз муну жасайбыз.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}