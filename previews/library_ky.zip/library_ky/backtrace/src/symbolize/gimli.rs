//! crates.io те `gimli` crate колдонуп символиканы колдоо
//!
//! Бул Rust үчүн демейки символиканы ишке ашыруу.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'Статикалык өмүр-бул өзүн-өзү шилтеме берүүчү структураларды колдоонун жоктугун бузуп, жалган.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // "Статикалык жашоо мезгилине" айландырыңыз, анткени белгилер `map` жана `stash` насыяларын гана алышы керек жана биз аларды төмөндө сактап жатабыз.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Windows-ге жергиликтүү китепканаларды жүктөө үчүн, rust-lang/rust#71060 те ар кандай стратегияларды талкуулоону караңыз.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Учурда MinGW китепканалары ASLR (rust-lang/rust#16514) ти колдобойт, бирок DLLлер дагы деле дарек мейкиндигинде жайгаштырылышы мүмкүн.
            // Мүчүлүштүктөрдү оңдоо маалыматындагы даректердин бардыгы, эгер бул китепкана "image base" ке жүктөлсө, ал COFF файл башындагы талаа болуп саналат окшойт.
            // Debuginfo тизмеси ушул сыяктуу болгондуктан, биз символдордун таблицасын талдап, даректерин китепкана "image base" ке жүктөлгөндөй сактайбыз.
            //
            // Бирок китепкана "image base" те жүктөлбөшү мүмкүн.
            // (болжол менен ал жакка дагы бир нерсе жүктөлүшү мүмкүнбү?) Бул жерде `bias` талаасы ойной баштайт жана биз бул жерде `bias` маанисин билишибиз керек.Тилекке каршы, жүктөлгөн модулдан муну кантип алуу керек экендиги белгисиз.
            // Бизде эмне бар, бирок иш жүзүндө жүктөө дареги (`modBaseAddr`) болуп саналат.
            //
            // Азырынча биз бир аз коп болуп, файлды mmap кылып, файлдын аталышы жөнүндө маалыматты окуп, андан кийин mmapды түшүрүп жатабыз.Бул ысырапкорчулук, анткени биз mmapды кийинчерээк ачышыбыз мүмкүн, бирок азырынча жетиштүү деңгээлде иштеши керек.
            //
            // Бизде `image_base` (каалаган жүктөлгөн жери) жана `base_addr` (иш жүзүндө жүктөлгөн жер) болгондон кийин, биз `bias` (чыныгы менен каалаган ортосундагы айырма) толтура алабыз, андан кийин ар бир сегменттин көрсөтүлгөн дареги `image_base` болот, анткени файл ушундай дейт.
            //
            //
            // Азырынча, ELF/MachO тен айырмаланып, биз `modBaseSize` көлөмүн колдонуп, бир китепканага бир сегментти жасай алабыз.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS Mach-O файл форматын колдонот жана тиркеменин бир бөлүгү болгон жергиликтүү китепканалардын тизмесин жүктөө үчүн DYLD спецификалык APIs колдонот.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Бул китепкананын атын жүктөп алыңыз, ал аны кайда жүктөөгө болот.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Ушул китепкананын сүрөт башын жүктөп, бардык жүктөө командаларын талдоо үчүн `object` ке өткөрүп бериңиз, ошондо биз бул жерде катышкан бардык сегменттерди аныктай алабыз.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Сегменттер боюнча кайталап, биз тапкан сегменттер үчүн белгилүү аймактарды каттаңыз.
            // Кийинчерээк кайра иштетүү үчүн тексттик сегменттерди жазыңыз.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Бул китепкана үчүн "slide" ти аныктаңыз, ал эс тутум объектилеринин кайсы жерине жүктөлгөнүн аныктоо үчүн колдонулат.
            // Бул бир аз таң калыштуу эсептөө жана жапайы жаратылышта бир нече нерсени сынап көрүп, эмне жабышып калганын көрүүнүн натыйжасы.
            //
            // Жалпы идея, `bias` плюс сегменттин `stated_virtual_memory_address` чыныгы дарек мейкиндигинде сегмент жайгашкан жерде болот.
            // Биз таянган дагы бир нерсе, `bias` минусалдуу чыныгы дарек-бул символдордун таблицасынан жана debuginfoдон издөө индекси.
            //
            // Системалык жүктөлгөн китепканалар үчүн бул эсептөөлөр туура эмес экен.Ал эми жергиликтүү аткарылуучу файлдарда ал туура көрүнөт.
            // LLDB булагынан кандайдыр бир логиканы көтөрүп, нөлдүк өлчөмү менен 0-офсеттен жүктөлгөн биринчи `__TEXT` бөлүмү үчүн атайын кабыгы бар.
            // Бул кандай гана себеп болбосун, символдордун таблицасы китепкана үчүн vmaddr слайдына салыштырмалуу дегенди билдирет.
            // Эгерде ал *жок* болсо, анда символ таблицасы vmaddr слайдына салыштырмалуу жана сегменттин көрсөтүлгөн дареги.
            //
            // Бул кырдаалды жөндөө үчүн, эгерде нөлдү жылдырган тексттик бөлүктү таппасак, анда биринчи тексттик бөлүмдөрдүн көрсөтүлгөн дареги боюнча каталарды көбөйтүп, көрсөтүлгөн даректерди да ошол көлөмгө азайтабыз.
            //
            // Ошентип, символикалык таблица китепкананын бир жактуу эмес экендигине карата ар дайым пайда болот.
            // Бул символ үстөлү аркылуу символдоштуруу үчүн туура натыйжаларга ээ.
            //
            // Чынын айтсам, бул туура эмеспи же муну кантип көрсөтө турган дагы бир нерсе бар экенине толук көзүм жетпейт.
            // Азырынча бул (?) жетиштүү деңгээлде иштеп жаткандай сезилет жана зарылчылык келип чыкса, убакыттын өтүшү менен биз аны ар дайым өзгөртө алышыбыз керек.
            //
            // Кошумча маалымат алуу үчүн #318 караңыз
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Башка Unix (мис., Мис
        // Linux) платформалары ELFти объекттин файл форматы катары колдонушат жана адатта жергиликтүү китепканаларды жүктөө үчүн `dl_iterate_phdr` деп аталган API ишке ашырышат.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` жарактуу көрсөткүч болушу керек.
        // `vec` `std::Vec` үчүн жарактуу көрсөткүч болушу керек.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 мүчүлүштүктөрдү оңдоочу маалыматты колдобойт, бирок түзүм системасы мүчүлүштүктөр жөнүндө маалыматты `romfs:/debug_info.elf` жолуна жайгаштырат.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Калгандарынын бардыгы ELF колдонушу керек, бирок жергиликтүү китепканаларды жүктөөнү билбейт.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Жүктөлгөн баардык белгилүү китепканалар.
    libraries: Vec<Library>,

    /// Карталардагы кэш, биз анализделген карлик маалыматты сактайбыз.
    ///
    /// Бул тизме бардык көтөрүү убактысы үчүн туруктуу кубаттуулукка ээ, ал эч качан көбөйбөйт.
    /// Ар бир жуптун `usize` элементи-`usize::max_value()` учурдагы аткарылуучу орунду чагылдырган жогорудагы `libraries` индекси.
    ///
    /// `Mapping` тийиштүү талданган карлик маалымат.
    ///
    /// Эскерте кетсек, бул LRU кэши жана биз бул жерде даректерди символдоштуруп, нерселерди өзгөртөбүз.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Бул китепкананын сегменттери эс тутумга жүктөлөт жана алар кайда жүктөлөт.
    segments: Vec<LibrarySegment>,
    /// Бул китепкананын "bias", эреже катары, ал эс тутумга жүктөлөт.
    /// Бул маани сегмент жүктөлгөн виртуалдык эс тутумдун чыныгы дарегин алуу үчүн ар бир сегменттин көрсөтүлгөн дарегине кошулат.
    /// Кошумча, бул кынтык чыныгы виртуалдык эс-тутум даректеринен алынып, debuginfo жана символдор таблицасына индекстелет.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Объект файлындагы ушул сегменттин көрсөтүлгөн дареги.
    /// Бул жерде сегмент жүктөлгөн жерде эмес, бул дарек жана китепкананын `bias` камтылган дареги бар.
    ///
    stated_virtual_memory_address: usize,
    /// Эс тутумундагы сегменттин көлөмү.
    len: usize,
}

// кооптуу, анткени аны тышкы синхрондоштуруу талап кылынат
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // кооптуу, анткени аны тышкы синхрондоштуруу талап кылынат
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Мүчүлүштүктөрдү оңдоочу карта үчүн өтө кичинекей, жөнөкөй LRU кэши.
        //
        // Хит ылдамдыгы өтө жогору болушу керек, анткени кадимки стек көпчүлүк жалпы китепканалардын ортосунда өтпөйт.
        //
        // `addr2line::Context` структураларын түзүү абдан кымбат.
        // Анын наркы кийинки add X2X суроо-талаптары менен амортизацияланат деп күтүлүүдө, алар "addr2line: : Context`s" курууда жакшы ылдамдыктарга жетүү үчүн курулган структуралардан пайдаланышат.
        //
        // Эгерде бизде ушул кэш жок болсо, анда амортизация эч качан болбойт жана арткы тректи символдоштуруу ssssllllooooowwww болмок.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Биринчиден, бул `lib` те `addr` камтылган кандайдыр бир сегмент бар-жогун текшерүү (башка жерге которуу).Эгер бул текшерүү өтүп кетсе, анда төмөндө улантып, даректи которо алабыз.
                //
                // Ашыкча текшерүүлөргө жол бербөө үчүн `wrapping_add` колдонуп жаткандыгыбызга көңүл буруңуз.SVMA + ыкчам эсептөөсү ашып-ташып жатканы жапайы жаратылышта байкалган.
                // Бул бир аз таң калыштуу көрүнөт, бирок биз бул сегменттерди көрмөксөнгө салгандан башка эч нерсе кыла албайбыз, анткени алар космоско учуп кетишет.
                //
                // Бул алгач rust-lang/backtrace-rs#329-жылы пайда болгон.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Эми биз `lib` `addr` камтыгандыгын билгендиктен, айтылган виртуалдык эс тутумдун дарегин табуу үчүн бир жактуулук менен алмаштыра алабыз.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Инвариант: бул шарттуу мөөнөт аяктагандан кийин эрте кайтып келбейт
        // катадан, бул жолдун кэш жазуусу 0 индексинде.

        if let Some(idx) = idx {
            // Картада мурунтан эле кэште турганда, аны алдыга жылдырыңыз.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Картада жок болгондо, жаңы карта түзүп, аны кэштин алдына киргизиңиз жана эгер керек болсо, эски кэш жазуусун чыгарыңыз.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // `'static` өмүрүн өткөрүп жибербеңиз, анын көлөмү өзүбүзгө гана байланыштуу
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // `sym` менен `'static` тин иштөө мөөнөтүн узартыңыз, анткени бизде, тилекке каршы, талап кылынат, бирок бул шилтеме катары чыгып кала берет, андыктан ага эч кандай шилтеме ушул алкактан тышкары калбашы керек.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Акырында, бул файл үчүн кэштелген картага түшүңүз же жаңы картаны түзүңүз, жана бул дарек үчүн file/line/name ти табуу үчүн DWARF маалыматын бааңыз.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Бул символ үчүн кадр маалыматын таба алдык, жана "addr2line" алкагынын ичине бардык кумарлуу деталдары бар.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Мүчүлүштүктөрдү оңдоочу маалымат табылган жок, бирок биз аны элфтин аткарыла турган символикалык таблицасынан таптык.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}