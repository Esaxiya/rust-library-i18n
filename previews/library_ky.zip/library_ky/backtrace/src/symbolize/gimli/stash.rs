// азыр Linux те гана колдонулат, андыктан өлгөн кодду башка жерге уруксат бериңиз
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Байт буферлери үчүн жөнөкөй арена бөлүштүргүч.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Белгиленген өлчөмдөгү буферди бөлүп берет жана ага өзгөрүлмө шилтеме берет.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // КООПСУЗДУК: бул өзгөрүлмө түзүүчү бирден-бир функция
        // `self.buffers` шилтемеси.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // КООПСУЗДУК: биз эч качан `self.buffers` тен элементтерди алып салбайбыз, андыктан маалымдама
        // ар кандай буфердеги маалыматтарга `self` иштегенге чейин жашайт.
        &mut buffers[i]
    }
}