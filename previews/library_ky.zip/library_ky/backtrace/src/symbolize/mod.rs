use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Белги көрсөтүлгөн жабууга өтүп, даректи дарекке чечиңиз.
///
/// Бул функция берилген символдорду табуу үчүн жергиликтүү дарек таблицасы, символикалык динамикалык таблица же DWARF мүчүлүштүктөрдү оңдоо маалыматы (активдештирилген ишке ашырууга жараша) сыяктуу аймактарда издейт.
///
///
/// Резолюцияны ишке ашырууга мүмкүн болбосо, жабуу деп аталбашы мүмкүн, ошондой эле сызык менен жазылган функцияларда бир эмес, бир нече жолу чакырылышы мүмкүн.
///
/// Берилген символдор көрсөтүлгөн `addr` боюнча аткарууну билдирет, ошол дарек үчүн file/line түгөйлөрүн кайтарып берет (эгер бар болсо).
///
/// Эгерде сизде `Frame` бар болсо, анда анын ордуна `resolve_frame` функциясын колдонуу сунушталат.
///
/// # Керектүү өзгөчөлүктөр
///
/// Бул функция `backtrace` crate `std` өзгөчөлүгүн иштетүүнү талап кылат, ал эми `std` функциясы демейки боюнча иштетилет.
///
/// # Panics
///
/// Бул функция эч качан panic аракетин көрбөйт, бирок эгер `cb` panics менен камсыз кылса, анда кээ бир платформалар процессти токтотууга эки эселенген panic мажбурлайт.
/// Айрым платформалар C китепканасын колдонушат, ал чалууларды артка кайтара албай тургандыктан, `cb` тен дүрбөлөң түшүрсө болот.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // үстүңкү алкакты гана караңыз
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Белги көрсөтүлгөн жабууга өтүп, мурунку тартуу кадрды символго чечиңиз.
///
/// Бул фуксин `resolve` сыяктуу эле функцияны аткарат, болгону даректин ордуна аргумент катары `Frame` алат.
/// Бул айрым трактингдерди платформада жүзөгө ашырганда, символ боюнча так маалыматты же катардагы алкактар жөнүндө маалыматты камсыз кылууга мүмкүндүк берет.
///
/// Колдон келсе муну колдонуу сунушталат.
///
/// # Керектүү өзгөчөлүктөр
///
/// Бул функция `backtrace` crate `std` өзгөчөлүгүн иштетүүнү талап кылат, ал эми `std` функциясы демейки боюнча иштетилет.
///
/// # Panics
///
/// Бул функция эч качан panic аракетин көрбөйт, бирок эгер `cb` panics менен камсыз кылса, анда кээ бир платформалар процессти токтотууга эки эселенген panic мажбурлайт.
/// Айрым платформалар C китепканасын колдонушат, ал чалууларды артка кайтара албай тургандыктан, `cb` тен дүрбөлөң түшүрсө болот.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // үстүңкү алкакты гана караңыз
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Стек алкактарындагы IP баалуулуктар адатта (always?) көрсөтмөсү *чалуудан кийин* чыныгы стек изи болот.
// Муну символдоштуруу filename/line номеринин алдыда болушун шарттап, функциянын аягына жакындап калса, боштукка айланат.
//
// Бул, негизинен, бардык платформаларда боло бериши мүмкүн, ошондуктан биз ар дайым чечилген ipдин арасынан бирөөнү алып салабыз, аны кайтаруунун ордуна, мурунку чакыруу көрсөтмөсүнө.
//
//
// Идеалында биз муну кылбайт элек.
// Идеалында, биз `resolve` API'лерин чалгандардан -1 кол менен жасоону талап кылышат жана жайгашкан жери жөнүндө маалыматты *мурунку* көрсөтмөсү үчүн эмес, учурдагы үчүн.
// Идеалында, эгер биз чындыгында кийинки көрсөтмөнүн дареги же учурдагы болсо, анда биз `Frame` ачыкка чыкмак.
//
// Азырынча бул абдан жакшы орунду ээлейт, андыктан биз ар дайым бирөөнү кемитебиз.
// Керектөөчүлөр иштешин улантып, жакшы натыйжаларды алышы керек, ошондуктан биз жетиштүү деңгээлде болушубуз керек.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// `resolve` сыяктуу эле, кооптуу, анткени ал шайкештештирилбейт.
///
/// Бул функцияда синхрондоштуруу кепилдиги жок, бирок ушул crate `std` өзгөчөлүгү топтолбогондо иштей берет.
/// Көбүрөөк документтер жана мисалдар үчүн `resolve` функциясын караңыз.
///
/// # Panics
///
/// `cb` паникадагы эскертүүлөр жөнүндө `resolve` маалыматты караңыз.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// `resolve_frame` сыяктуу эле, кооптуу, анткени ал шайкештештирилбейт.
///
/// Бул функцияда синхрондоштуруу кепилдиги жок, бирок ушул crate `std` өзгөчөлүгү топтолбогондо иштей берет.
/// Көбүрөөк документтер жана мисалдар үчүн `resolve_frame` функциясын караңыз.
///
/// # Panics
///
/// `cb` паникадагы эскертүүлөр жөнүндө `resolve_frame` маалыматты караңыз.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Файлдагы символдун чечилишин билдирген trait.
///
/// Бул trait `backtrace::resolve` функциясына берилген жабылууга trait объектиси катары берилет жана анын артында кайсы ишке ашырылышы белгисиз болгондуктан, ал дээрлик жөнөтүлөт.
///
///
/// Символ функция жөнүндө контексттик маалымат бере алат, мисалы, аты, файлдын аты, саптын номери, так дарек ж.б.
/// Бардык маалыматтар символ менен ар дайым эле боло бербейт, ошондуктан бардык ыкмалар `Option` үлгүсүн берет.
///
///
pub struct Symbol {
    // TODO: бул өмүр бою `Symbol` чейин сакталышы керек,
    // бирок бул учурда чоң өзгөрүү.
    // Азырынча бул коопсуз, анткени `Symbol` бир гана жолу шилтеме менен берилет жана аны клондоштурууга болбойт.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Бул функциянын аталышын кайтарат.
    ///
    /// Кайтарылган структура белгинин аталышы жөнүндө ар кандай касиеттерге суроо берүү үчүн колдонулушу мүмкүн:
    ///
    ///
    /// * `Display` жүзөгө ашырылышы бузулган белгини басып чыгарат.
    /// * Символдун чийки `str` маанисине кирүүгө болот (эгер ал utf-8 жарактуу болсо).
    /// * Белги аталышы үчүн чийки байттарга кирүүгө болот.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Бул иштин баштапкы дарегин кайтарып берет.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Файлдын атын чийки кылып кайтарат.
    /// Бул негизинен `no_std` чөйрөсү үчүн пайдалуу.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Бул символ учурда аткарылып жаткан тилкенин номерин берет.
    ///
    /// Учурда gimli гана ушул жерде маанини берет, андан кийин гана `filename` `Some` кайтарып бергенде гана, демек, ушул сыяктуу эскертүүлөргө дуушар болот.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Бул белгинин учурда аткарылып жаткан жеринин катар номерин берет.
    ///
    /// Бул кайтарым маани, адатта, `filename` `Some` кайтарса, `Some` болот, демек, ушул сыяктуу эскертүүлөргө дуушар болот.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Бул функция аныкталган файлдын атын кайтарат.
    ///
    /// Бул учурда libbacktrace же gimli колдонулуп жатканда гана жеткиликтүү (мис., Мис
    /// unix экинчиси debuginfo менен түзүлгөндө).
    /// Эгерде бул эки шарт тең аткарылбаса, анда `None` кайтарылып берилет.
    ///
    /// # Керектүү өзгөчөлүктөр
    ///
    /// Бул функция `backtrace` crate `std` өзгөчөлүгүн иштетүүнү талап кылат, ал эми `std` функциясы демейки боюнча иштетилет.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Балким, C++ белгиси, эгерде Rust катары манголдук белгини талдоо ишке ашпай калса.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Өчүрүп алсаңыз, `cpp_demangle` функциясы эч кандай чыгымга учурабашы үчүн, ушул нөл өлчөмүн сактап коюңуз.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Белги аталышына оролуучу ором, демонгацияланган аталышка, чийки байттарга, чийки сапка ж.б.у.с. эргономикалык жардамчы берет.
///
// `cpp_demangle` функциясы иштетилбеген учурда, өлгөн кодго уруксат бериңиз.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Чийки негизги байттардын ичинен жаңы символдун аталышын жаратат.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Эгерде utf-8 символу туура болсо, (mangled) символдун аталышын `str` катары кайтарат.
    ///
    /// Эгер демангацияланган версиясын кааласаңыз, `Display` ишке ашырылышын колдонуңуз.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Чийки белгинин атын байттардын тизмеси катары кайтарат
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Эгерде бул чындыгында жарактан чыккан символ туура эмес болсо, анда аны басып чыгарышы мүмкүн, андыктан катаны сыртка жайылтпастан, аны аяр мамиле кылыңыз.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Даректерди символдоштуруу үчүн колдонулган кэш эс тутумун калыбына келтирүү аракети.
///
/// Бул ыкма, адатта, талданган DWARF маалыматын же ага окшош маалыматты камтыган глобалдык түрдө же жипке салынган глобалдык маалымат структураларын чыгарууга аракет кылат.
///
///
/// # Caveats
///
/// Бул функция ар дайым жеткиликтүү болсо дагы, көпчүлүк ишке ашырууда эч нерсе кыла албайт.
/// Dbghelp же libbacktrace сыяктуу китепканалар абалды бөлүштүрүүгө жана бөлүнгөн эс тутумду башкарууга мүмкүнчүлүк бербейт.
/// Азырынча бул crate `gimli-symbolize` өзгөчөлүгү бул функция кандайдыр бир таасир эте турган бирден-бир өзгөчөлүк.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}