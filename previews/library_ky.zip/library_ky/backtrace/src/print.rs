#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Арткы тректерге форматташтыруучу.
///
/// Бул түр арткы тректи өзү кайдан чыккандыгына карабастан басып чыгаруу үчүн колдонулушу мүмкүн.
/// Эгер сизде `Backtrace` түрү бар болсо, анда анын `Debug` жүзөгө ашырылышы буга чейин ушул форматты колдонот.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Биз басып чыгара турган стилдер
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Идеалдуу түрдө гана тиешелүү маалыматтарды камтыган терс артка чегинүүнү басып чыгарат
    Short,
    /// Бардык мүмкүн болгон маалыматтарды камтыган арткы тректи басып чыгарат
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Берилген `fmt` ке чыгууну жаза турган жаңы `BacktraceFmt` түзүңүз.
    ///
    /// `format` аргументи арткы трек басып чыгарылган стилди көзөмөлдөйт, ал эми `print_path` аргументи `BytesOrWideString` файл аталыштарын басып чыгаруу үчүн колдонулат.
    /// Бул түрдүн өзү файл аттарын басып чыгарбайт, бирок бул үчүн кайра чакыруу талап кылынат.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Басылып чыга турган артта калуучу трек үчүн преамбуланы басып чыгарат.
    ///
    /// Арткы тректер кийинчерээк толугу менен символикалуу болушу үчүн, бул айрым платформаларда талап кылынат, антпесе бул `BacktraceFmt` түзгөндөн кийин биринчи жолу чакырылган ыкма болушу керек.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Арткы трек чыгуусуна кадр кошот.
    ///
    /// Бул милдеттенме, чындыгында, кадрды басып чыгаруу үчүн колдонула турган `BacktraceFrameFmt` үлгүсүндөгү RAII нускасын кайтарып берет жана жок болгондо кадр эсептегичин көбөйтөт.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Артка чегинүүнү жыйынтыктайт.
    ///
    /// Бул учурда тыюу салынган, бирок future артка кайтуу форматтары менен шайкештиги үчүн кошулган.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Учурда future толуктоолоруна жол берүү үчүн ушул hook кошулган жок.
        Ok(())
    }
}

/// Артка чегинүүнүн бир эле кадрына форматтоочу.
///
/// Бул түр `BacktraceFmt::frame` функциясы тарабынан түзүлгөн.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Ушул кадр форматтагыч менен `BacktraceFrame` басып чыгарат.
    ///
    /// Бул `BacktraceFrame` ичиндеги бардык `BacktraceSymbol` нускаларын рекурсивдүү басып чыгарат.
    ///
    /// # Керектүү өзгөчөлүктөр
    ///
    /// Бул функция `backtrace` crate `std` өзгөчөлүгүн иштетүүнү талап кылат, ал эми `std` функциясы демейки боюнча иштетилет.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// `BacktraceSymbol` ти `BacktraceFrame` ичинде басып чыгарат.
    ///
    /// # Керектүү өзгөчөлүктөр
    ///
    /// Бул функция `backtrace` crate `std` өзгөчөлүгүн иштетүүнү талап кылат, ал эми `std` функциясы демейки боюнча иштетилет.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: бул биз эч нерсе басып бүтүрбөйбүз деген жакшы эмес
            // utf8 эмес файл аттары менен.
            // Бактыга жараша, дээрлик бардыгы utf8 болгондуктан, бул өтө жаман болбошу керек.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Адатта ушул crate чийки чалуулардын ичинен чийки изделген `Frame` жана `Symbol` басып чыгарат.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Арткы тректи чыгарууга чийки алкакты кошот.
    ///
    /// Бул ыкма, мурункусунан айырмаланып, ар кайсы жерден булак болуп калса, чийки аргументтерди колдонот.
    /// Эске салсак, бул бир кадр үчүн бир нече жолу аталышы мүмкүн.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Арткы тректи чыгарууга чийки алкакты, анын ичинде мамыча маалыматын кошот.
    ///
    /// Бул ыкма, мурункусундай эле, ар кайсы жерден булак болуп калса, чийки аргументтерди алат.
    /// Эске салсак, бул бир кадр үчүн бир нече жолу аталышы мүмкүн.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Фучия процесстин ичинде символдоштура албайт, андыктан кийинчерээк символдоштуруу үчүн колдонула турган атайын форматка ээ.
        // Бул жерге даректерди өзүбүздүн форматта басып чыгаруунун ордуна басып чыгарыңыз.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null" алкактарын басып чыгаруунун кажети жок, негизинен бул система артка чегинүү супер алыска байкоо салууга дилгир болгонун билдирет.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Sgx анклавындагы TCB өлчөмүн кичирейтүү үчүн, биз символдорду чечүү функциясын ишке ашырууну каалабайбыз.
        // Тескерисинче, биз даректин жылышын ушул жерге басып чыгара алабыз, кийинчерээк функцияны тууралоо үчүн картага түшүрсө болот.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Кадрдын индексин жана фреймдин кошумча көрсөтмө көрсөткүчүн басып чыгарыңыз.
        // Эгерде биз ушул алкактын биринчи символунан тышкары болсок, анда боштукту гана басып чыгарабыз.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Андан кийин толук маалыматты алуу үчүн, кошумча маалымат алуу үчүн альтернатива форматын колдонуп, символдун атын жазып чыгыңыз.
        // Бул жерде биз аты жок символдорду да колдонобуз,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Жана аягында, эгер алар бар болсо, filename/line номерин басып чыгарыңыз.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line символдун аталышы менен саптарга басылып, боштукту басып, өзүбүздүн оң жакка тегиздөөбүз.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Файлдын атын басып чыгарып, андан кийин саптын номерин басып чыгаруу үчүн, биздин ички чалууну өткөрүп бериңиз.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Эгерде бар болсо, мамычанын номерин кошуңуз.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Биз кадрдын биринчи белгисине гана маани беребиз
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}