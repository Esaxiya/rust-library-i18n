use core::ffi::c_void;
use core::fmt;

/// Стек изин эсептөө үчүн берилген активдүү алкактарды жабыкка өткөрүп, учурдагы чакыруу стегин текшерет.
///
/// Бул функция программанын стек издерин эсептөөдө ушул китепкананын жумушчу аты болуп саналат.Берилген жабуу `cb`, стекдеги ошол чалуу алкагы жөнүндө маалыматты чагылдырган `Frame` мисалдары келтирилген.
/// Жабуу жогорудан ылдый кармалган фреймдер менен берилет (акыркы функциялар биринчи).
///
/// Жабуунун кайтарым мааниси, арткы издин уланышы керектигинин белгиси.`false` кайтарым мааниси арткы тректи токтотуп, дароо кайтып келет.
///
/// `Frame` сатылып алынгандан кийин, `ip` (көрсөтмө көрсөткүчү) же символ дарегин `Symbol` аталышына жана/же файлдын атына/саптын номерине үйрөнүү үчүн, `backtrace::resolve` номерине чалгыңыз келиши мүмкүн.
///
///
/// Бул салыштырмалуу төмөн деңгээлдеги функция экендигин эске алыңыз, эгер сиз, мисалы, кийинчерээк текшериле турган арткы тректи тартып алгыңыз келсе, анда `Backtrace` түрү ылайыктуу болушу мүмкүн.
///
/// # Керектүү өзгөчөлүктөр
///
/// Бул функция `backtrace` crate `std` өзгөчөлүгүн иштетүүнү талап кылат, ал эми `std` функциясы демейки боюнча иштетилет.
///
/// # Panics
///
/// Бул функция эч качан panic аракетин көрбөйт, бирок эгер `cb` panics менен камсыз кылса, анда кээ бир платформалар процессти токтотууга эки эселенген panic мажбурлайт.
/// Айрым платформалар C китепканасын колдонушат, ал чалууларды артка кайтара албай тургандыктан, `cb` тен дүрбөлөң түшүрсө болот.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // артка чегинүүнү улантуу
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// `trace` сыяктуу эле, кооптуу, анткени ал шайкештештирилбейт.
///
/// Бул функцияда синхрондоштуруу кепилдиги жок, бирок ушул crate `std` өзгөчөлүгү топтолбогондо иштей берет.
/// Көбүрөөк документтер жана мисалдар үчүн `trace` функциясын караңыз.
///
/// # Panics
///
/// `cb` паникадагы эскертүүлөр жөнүндө `trace` маалыматты караңыз.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Артка чегинүүнүн бир алкагын чагылдырган trait ушул crate дин `trace` функциясына өттү.
///
/// Калька функциясынын жабылышы кадрлардан алынат жана кадр дээрлик жөнөтүлөт, анткени иштөө убактысы чейин ар дайым белгилүү боло бербейт.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Ушул алкактын учурдагы көрсөтмө көрсөткүчүн кайтарат.
    ///
    /// Бул кадимки кадрда аткарыла турган кезектеги көрсөтмө, бирок бардык эле ишке ашыруулар муну 100% тактык менен келтиришпейт (бирок жалпысынан ал жакын).
    ///
    ///
    /// Бул маанини `backtrace::resolve` ке өткөрүп, аны символ аталышына айландыруу сунушталат.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Ушул алкактын учурдагы стек көрсөткүчүн кайтарат.
    ///
    /// Бул кадр үчүн стек көрсөткүчүн backend калыбына келтире албаса, нөл көрсөткүчү кайтарылат.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Ушул функциянын алкагынын башталган символ дарегин кайтарып берет.
    ///
    /// Бул `ip` тарабынан кайтарылган көрсөтмө көрсөткүчүн функциянын башталышына артка кайтарып, ошол маанини кайтарып берет.
    ///
    /// Кээ бир учурларда, арткы функциялар `ip` функциясын жөн эле кайтарып берет.
    ///
    /// Кайтарылган маани кээде `backtrace::resolve` жогоруда келтирилген `ip` боюнча ишке ашпай калса колдонулушу мүмкүн.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Кадр таандык болгон модулдун негизги дарегин кайтарып берет.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Мири хост платформасынан артыкчылыктуу болушун камсыз кылуу үчүн, бул биринчи орунда турушу керек
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // dbghelp символикасында гана колдонулат
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}