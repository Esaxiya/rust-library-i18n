use backtrace::Backtrace;

// Бул тест символдун баштапкы дарегин билдирген кадрлар үчүн иштөөчү `symbol_address` функциясы бар платформаларда гана иштейт.
// Натыйжада, ал бир нече платформада гана иштетилген.
//
const ENABLED: bool = cfg!(all(
    // Windows чындыгында сыналган эмес, жана OSX жабык алкакты издөөнү колдобойт, андыктан аны өчүрүп салыңыз
    //
    target_os = "linux",
    // ARMде курчап турган функцияны табуу жөн гана ipдин өзүн кайтарып берет.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}