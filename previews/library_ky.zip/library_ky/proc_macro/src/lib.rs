//! Жаңы макростторду аныктоодо макро авторлорго колдоо көрсөтүү китепканасы.
//!
//! Стандарттык бөлүштүрүү менен камсыз кылынган бул китепкана процедуралык жактан аныкталган макро аныктамалардын интерфейстеринде керектелүүчү түрлөрдү камсыз кылат, мисалы, `#[proc_macro]` макро атрибуттары, `#[proc_macro_attribute]` макро атрибуттары жана колдонуучунун деривт атрибуттары##proc_macro_derive].
//!
//!
//! Көбүрөөк маалымат алуу үчүн [the book] караңыз.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Proc_macro учурдагы иштеп жаткан программага жеткиликтүү болгондугун аныктайт.
///
/// Proc_macro crate процессуалдык макроолорду ишке ашыруунун ичинде гана колдонулат.Ушул crate panic деги бардык функциялар, эгерде процесстик макроонун тышынан, мисалы, скрипт же блок тестинен же кадимки Rust бинарынан алынса.
///
/// Макро жана макро эмес учурларды колдоого арналган Rust китепканаларын эске алуу менен, `proc_macro::is_available()`, proc_macro API колдонууга керектүү инфраструктуранын азыркы учурда жеткиликтүү экендигин аныктоонун паникага жол бербейт.
/// Процедуралык макростун ичинен чакырылса, чыныгы, башка экиликтен жалган болсо, кайтарылат.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Ушул crate тарабынан берилген негизги түр, tokens абстрактуу агымын, же тагыраак айтканда, token дарактарынын ырааттуулугун билдирет.
/// Түрү ошол token дарактарынын үстүнөн кайталоо жана тескерисинче, бир катар token дарактарын бир агымга чогултуу үчүн интерфейстерди камсыз кылат.
///
///
/// Бул `#[proc_macro]`, `#[proc_macro_attribute]` жана `#[proc_macro_derive]` аныктамаларынын кириши жана чыгышы.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// `TokenStream::from_str` катасы кайтып келди.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// token дарагы жок бош `TokenStream` кайтарып берет.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Бул `TokenStream` бош экендигин текшерет.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Жипти tokens ге бөлүп, ошол tokens ди token агымына талдоо аракети.
/// Бир катар себептерден улам иштебей калышы мүмкүн, мисалы, эгерде тилде балансталбаган бөлгүчтөр же белгилер камтылса.
///
/// Талданган агымдагы бардык tokens `Span::call_site()` аралыгын алат.
///
/// NOTE: кээ бир каталар `LexError` кайтаруунун ордуна panics алып келиши мүмкүн.Бул каталарды кийинчерээк "LexError" кылып өзгөртүү укугубуз сакталат.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, көпүрө `to_string` ти гана камсыз кылат, анын негизинде `fmt::Display` ти ишке ашырат (экөөнүн ортосундагы кадимки мамиленин тескери жагы).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// token агымын жоготпостон кайра конверттелүүчү сап катары чыгарат, ошол эле token агымына (модулдук аралыгы) кошпогондо, `Delimiter::None` чектегичтери жана терс цифралык литералдары бар "TokenTree: : Group`" дан тышкары.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Мүчүлүштүктөрдү оңдоо үчүн token формасын басып чыгарат.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Жалгыз token дарагын камтыган token агымын түзөт.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Бир катар агымга бир катар token дарактарын чогултат.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// token агымдарындагы "flattening" операциясы, бир нече token агымынан бир агымга token дарактарын чогултат.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Оптималдаштырылган if/when ишке ашырууну колдонуңуз.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Итераторлор сыяктуу `TokenStream` типтеги коомдук ишке ашыруу чоо-жайы.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// "TokenStream" дин "TokenTree`дин" үстүнөн кайталоочу.
    /// Кайталоо "shallow", мисалы, кайталоочу бөлүнгөн топторго кайтпайт жана бүт топторду token дарактары катары кайтарат.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` өзүм билемдик менен tokens кабыл алат жана киргизүүнү сүрөттөгөн `TokenStream` ке чейин кеңейет.
/// Мисалы, `quote!(a + b)`, баа берилгенде, `TokenStream` `[Ident("a"), Punct('+', Alone), курган сөз айкашын чыгарат, Ident("b")]`.
///
///
/// Чыкпай коюу `$` менен жүргүзүлөт жана кийинки идентификаторду котировкаланбаган термин катары алуу менен иштейт.
/// `$` өзүнө цитата келтирүү үчүн `$$` колдонуңуз.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Макро кеңейтүү маалыматтары менен кошо булак кодунун региону.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Берилген `message` менен `self` аралыгында жаңы `Diagnostic` түзөт.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Макро аныктама сайтында чечилүүчү аралык.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Учурдагы процессуалдык макростун чакырылышы.
    /// Ушул аралыкта түзүлгөн идентификаторлор түздөн-түз макро чалуу болгон жерде жазылгандай чечилет (чалуу-сайттын гигиенасы) жана макро чалуу сайтындагы башка коддор аларга да кайрыла алышат.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// `macro_rules` гигиенасын чагылдырган, кээде макро аныктоо сайтында (жергиликтүү өзгөрмөлөр, этикеткалар, `$crate`), кээде макро чалуулар сайтында (калганынын бардыгы) чечилүүчү аралык.
    ///
    /// Аралык жайгашкан жер чакыруу-сайтынан алынды.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Ушул аралыкты камтыган баштапкы файл.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// Мурунку `self` макро экспансиясындагы tokens үчүн `Span`, эгерде ал бар болсо.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// `self` түзгөн баштапкы булак кодунун аралыгы.
    /// Эгерде бул `Span` башка макро жайылтуулардан түзүлбөсө, анда кайтарып берүү мааниси `*self` менен бирдей болот.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Бул аралыкта баштапкы файлда баштапкы line/column алат.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Бул аралыкта баштапкы файлда line/column аяктайт.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// `self` жана `other` камтыган жаңы аралыкты түзөт.
    ///
    /// Эгерде `self` жана `other` ар башка файлдардан болсо, `None` берет.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// `self` сыяктуу line/column маалыматы бар жаңы аралыкты жаратат, бирок `other` дегидей белгилерди чечет.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// `self` сыяктуу эле, бирок X002 X 02X маалыматы менен бирдей аталыштагы резолюция жүрүм-турумун түзгөн.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Алардын бирдей экендигин билүү үчүн аралыкка салыштырганда.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Бир аралыктагы баштапкы текстти кайтарып берет.
    /// Бул боштуктарды жана комментарийлерди камтыган баштапкы баштапкы кодду сактайт.
    /// Эгерде бул аралык чыныгы булак кодуна туура келсе гана натыйжа берет.
    ///
    /// Note: Макростун байкалган натыйжасы бул текстке эмес, tokens ге гана ишениши керек.
    ///
    /// Бул функциянын натыйжасы-диагностика үчүн гана колдонулган эң жакшы аракет.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Мүчүлүштүктөрдү оңдоо үчүн ыңгайлуу формада басып чыгарат.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// `Span` башталышын же аягын билдирген сызык-тилке жупу.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Аралыгы башталган же аяктаган баштапкы файлдагы 1 индекстелген сап (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Аралыгы (inclusive) башталган же аяктаган баштапкы файлдагы 0 индекстелген мамыча (UTF-8 белгилеринде).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Берилген `Span` тин баштапкы файлы.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Бул баштапкы файлга жол алат.
    ///
    /// ### Note
    /// Эгерде бул `SourceFile` менен байланышкан код аралык тышкы макрост тарабынан түзүлгөн болсо, анда ушул макро, бул файл тутумундагы иш жүзүндөгү жол болбошу мүмкүн.
    /// Текшерүү үчүн [`is_real`] колдонуңуз.
    ///
    /// Ошондой эле `is_real` `true` кайтарып берсе дагы, эгер `--remap-path-prefix` буйрук сабына өткөн болсо, анда берилген жол чындыгында жараксыз болуп калышы мүмкүн.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Сырткы макростун кеңейишинен келип чыкпаган бул баштапкы файл чыныгы баштапкы файл болсо, `true` берет.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Бул интеркраттык аралыктар ишке ашканга чейин жана бизде тышкы макростордо пайда болгон файлдардын чыныгы булагы болушу мүмкүн.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Жалгыз token же token дарактарынын бөлүнгөн ырааттуулугу (мисалы, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Каша бөлүүчүлөр менен курчалган token агымы.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Идентификатор.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Бир тыныш белгиси (`+`, `,`, `$` ж.б.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Сөзмө-сөз (`'a'`) символу, (`"hello"`) сабы, (`2.3`) саны ж.б.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Камтылган token же бөлүнгөн агымдын `span` ыкмасына өткөрүп берүү менен, ушул бактын аралыгын кайтарып берет.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Ушул token * үчүн гана аралыкты конфигурациялайт.
    ///
    /// Эгерде бул token `Group` болсо, анда бул ыкма ички tokens ар биринин аралыгын конфигурациялабайт, бул жөн гана ар бир варианттын `set_span` ыкмасына өткөрүп берет.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Мүчүлүштүктөрдү оңдоо үчүн token дарагын басып чыгарат.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Булардын ар бири алынган типтеги мүчүлүштүктөрдүн структурасында аты бар, андыктан кошумча кыйыр катмар менен убара болбоңуз
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, көпүрө `to_string` ти гана камсыз кылат, анын негизинде `fmt::Display` ти ишке ашырат (экөөнүн ортосундагы кадимки мамиленин тескери жагы).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// token дарагын X100X чектегичтеринен жана терс сандык литалисттерден турган "TokenTree: : Group`дорду кошпогондо, жоготпостон кайра эле ошол token дарагына (модулдук аралыгы) конверттелүүчү сап катары чыгарат.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Чектелген token агымы.
///
/// `Group` ичинде `TokenStream` камтылган, ал "Чектөөчү" менен курчалган.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// token дарактарынын ырааттуулугу кандайча бөлүнүп берилгендигин сүрөттөйт.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Мисалы, tokens тегерегинде "macro variable" `$var` келип чыгышы мүмкүн болгон жашыруун бөлүүчү.
    /// Оператордун артыкчылыктарын `$var * 3` сыяктуу `$var` `1 + 2` болгон учурларда сактоо маанилүү.
    /// Жашыруун бөлүүчүлөр token агымынын жип аркылуу айланып өтүшүндө аман калбашы мүмкүн.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Берилген бөлүү жана token агымы менен жаңы `Group` түзөт.
    ///
    /// Бул конструктор бул топтун аралыгын `Span::call_site()` кылып орнотот.
    /// Аралыгын өзгөртүү үчүн төмөндөгү `set_span` ыкмасын колдонсоңуз болот.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Ушул `Group` бөлүүчүнү кайтарат
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Ушул `Group` менен бөлүнгөн tokens `TokenStream` син кайтарат.
    ///
    /// Кайтарылган token агымында жогоруда кайтарылган бөлүүчү камтылбагандыгын эске алыңыз.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Ушул token агымынын бөлгүчтөрү үчүн `Group` бүтүндөй аралыгын кайтарып берет.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Ушул топтун ачылыш бөлгүчүн көрсөтүп, аралыкты кайтарат.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Ушул топтун чектөө бөлгүчүн көрсөтүп, аралыкты кайтарат.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Ушул "Топтун" бөлүүчүлөрүнүн аралыгын конфигурациялайт, бирок анын ички tokens эмес.
    ///
    /// Бул ыкма бул топ тарабынан жайылган бардык ички tokens аралыгын ** орнотпойт, тескерисинче, ал tokens бөлүүчүнүн гана `Group` деңгээлинде бөлүштүрөт.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, көпүрө `to_string` ти гана камсыз кылат, анын негизинде `fmt::Display` ти ишке ашырат (экөөнүн ортосундагы кадимки мамиленин тескери жагы).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Топту XSX чектегичтеринен турган "TokenTree: : Group`дорду кошпогондо, ошол эле топко (модулдук аралыгы) жоготпостон кайра конверттелүүчү сап катарында чыгарат.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct`-бул `+`, `-` же `#` сыяктуу бир тыныш белгиси.
///
/// `+=` сыяктуу көп символдуу операторлор `Punct` эки мисалы катары көрсөтүлүп, ар кандай `Spacing` формалары кайтарылды.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// `Punct` артынан дароо башка `Punct` же андан кийин дагы token же боштук болобу.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// мисалы, `+`-`+ =`, `+ident` же `+()` те `Alone`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// мисалы, `+`-`+=` же `'#` те `Joint`.
    /// Мындан тышкары, `'` бир цитата идентификаторлор менен кошулуп, `'ident` өмүрүн түзөт.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Берилген символдон жана аралыктан жаңы `Punct` түзөт.
    /// `ch` аргументи тил уруксат берген тыныш белгилери болушу керек, антпесе функция panic болот.
    ///
    /// Кайтарылган `Punct` демейки `Span::call_site()` аралыгы болот, аны төмөндөгү `set_span` ыкмасы менен дагы конфигурациялоого болот.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Бул тыныш белгилеринин маанисин `char` деп кайтарат.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Бул тыныш белгилеринин аралыгын кайтарып берет, анын token агымында дароо башка `Punct` келе тургандыгын, ошондуктан аларды (`Joint`) көп символдуу операторго бириктирип алышын же анын артынан башка token же боштук (`Alone`) орун алгандыгын, ошондуктан оператор сөзсүз түрдө аяктады.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Ушул тыныш белгилеринин аралыгын кайтарат.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Ушул тыныш белгилеринин аралыгын конфигурациялаңыз.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, көпүрө `to_string` ти гана камсыз кылат, анын негизинде `fmt::Display` ти ишке ашырат (экөөнүн ортосундагы кадимки мамиленин тескери жагы).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Тыныш белгилерин сап катарында басып чыгарат, ал ошол бойдон кайра жоготпостон конвертацияланат.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// (`ident`) идентификатор.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Берилген `string` жана көрсөтүлгөн `span` менен жаңы `Ident` түзөт.
    /// `string` аргументи тил тарабынан уруксат берилген анык идентификатор болушу керек (анын ичинде ачкыч сөздөр, мисалы `self` же `fn`).Болбосо, функция panic болот.
    ///
    /// `span`, учурда rustc де, ушул идентификатор үчүн гигиена маалыматын конфигурациялайт.
    ///
    /// Ушул убакка чейин `Span::call_site()` ачыктан-ачык "call-site" гигиенасына өтөт, демек, ушул аралыкта түзүлгөн идентификаторлор түздөн-түз макро чалуунун жайгашкан жеринде жазылгандай чечилет, ал эми макро чалуу сайтындагы башка код шилтеме бере алат. аларды да.
    ///
    ///
    /// Кийинчерээк `Span::def_site()` сыяктуу аралыктар "definition-site" гигиенасына өтүүгө мүмкүнчүлүк берет, демек, ушул аралыкта түзүлгөн идентификаторлор макро аныктаманын жайгашкан жеринде чечилет жана башка коддор макро чалуу сайтында аларга кайрыла алышпайт.
    ///
    /// Гигиенанын учурдагы маанилүүлүгүнө байланыштуу, бул конструктор, башка tokens ден айырмаланып, курулушта `Span` белгилерин талап кылат.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// `Ident::new` сыяктуу эле, бирок чийки (`r#ident`) идентификаторун жаратат.
    /// `string` аргументи тил тарабынан уруксат берилген анык идентификатор болушу мүмкүн (анын ичинде ачкыч сөздөр, мисалы `fn`).
    /// Жол сегменттеринде колдонула турган ачкыч сөздөр (мис., Мис.)
    /// `self`, `super`) колдоого алынбайт жана panic алып келет.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// [`to_string`](Self::to_string) тарабынан кайтарылган бардык сапты камтыган ушул `Ident` аралыкты кайтарып берет.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Ушул `Ident` тин узактыгын конфигурациялап, гигиеналык контекстин өзгөртө алат.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, көпүрө `to_string` ти гана камсыз кылат, анын негизинде `fmt::Display` ти ишке ашырат (экөөнүн ортосундагы кадимки мамиленин тескери жагы).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Идентификаторду ошол эле идентификаторго кайра жоготпостон кайра конверттелүүчү сап катарында басып чыгарат.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// (`"hello"`) сөзмө сап, (`b"hello"`) байт сабы, (`'a'`) символу, (`b'a'`) байт символу, бүтүн сан же суффикссиз же суффикссиз ("1`, `1u8`, `2.3`, `2.3f32`).
///
/// Булт литералдары `true` жана `false` бул жакка таандык эмес, алар "Ident`s".
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Көрсөтүлгөн маанидеги жаңы суффикстик бүтүндөй сандарды түзөт.
        ///
        /// Бул функция `1u32` сыяктуу бүтүн сандын пайда болушуна шарт түзөт, анда көрсөтүлгөн бүтүн сан token дин биринчи бөлүгү болуп саналат, ал эми интеграл аягында суффикске кошулат.
        /// Терс сандардан түзүлгөн литривалдар `TokenStream` же саптар аркылуу айланып өтүүдө жашабай, эки tokens (`-` жана позитивдик түзмө-түз) болуп бөлүнүшү мүмкүн.
        ///
        ///
        /// Ушул ыкма аркылуу түзүлгөн литорийлер `Span::call_site()` аралыгы бар, аны төмөндөгү `set_span` ыкмасы менен конфигурациялоого болот.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Көрсөтүлгөн маанидеги жаңы түзмө-түз бүтүн санды түзөт.
        ///
        /// Бул функция, `1` сыяктуу бүтүн санды түзөт, анда көрсөтүлгөн бүтүн сан token дин биринчи бөлүгү болуп саналат.
        /// Бул token де эч кандай суффикс көрсөтүлгөн эмес, демек `Literal::i8_unsuffixed(1)` сыяктуу чакыруулар `Literal::u32_unsuffixed(1)` ге барабар.
        /// Терс сандардан түзүлгөн критерийлер `TokenStream` же саптар аркылуу айланып өтпөй, эки tokens (`-` жана позитивдик түзмө-түз) болуп бөлүнүшү мүмкүн.
        ///
        ///
        /// Ушул ыкма аркылуу түзүлгөн литорийлер `Span::call_site()` аралыгы бар, аны төмөндөгү `set_span` ыкмасы менен конфигурациялоого болот.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Жаңы түзмө-түз сөзсүз сөзмө-сөз түзүлөт.
    ///
    /// Бул конструктор `Literal::i8_unsuffixed` сыяктуу, флоттун мааниси түздөн-түз token-ге чыгарылып, бирок эч кандай суффикс колдонулбагандыктан, аны кийинчерээк `f64` деп айтууга болот.
    ///
    /// Терс сандардан түзүлгөн критерийлер `TokenStream` же саптар аркылуу айланып өтпөй, эки tokens (`-` жана позитивдик түзмө-түз) болуп бөлүнүшү мүмкүн.
    ///
    /// # Panics
    ///
    /// Бул функция көрсөтүлгөн флоттун чектүү болушун талап кылат, мисалы, чексиздик же NaN болсо, бул функция panic болот.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Жаңы суффикстин сөзмө-сөз маанисин түзөт.
    ///
    /// Бул конструктор `1.0f32` сыяктуу сөзмө-сөз түзүп берет, анда көрсөтүлгөн маани token нин мурунку бөлүгү жана `f32` token суффикси болуп саналат.
    /// Бул token ар дайым компилятордо `f32` болушу мүмкүн.
    /// Терс сандардан түзүлгөн критерийлер `TokenStream` же саптар аркылуу айланып өтпөй, эки tokens (`-` жана позитивдик түзмө-түз) болуп бөлүнүшү мүмкүн.
    ///
    ///
    /// # Panics
    ///
    /// Бул функция көрсөтүлгөн флоттун чектүү болушун талап кылат, мисалы, чексиздик же NaN болсо, бул функция panic болот.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Жаңы түзмө-түз сөзсүз сөзмө-сөз түзүлөт.
    ///
    /// Бул конструктор `Literal::i8_unsuffixed` сыяктуу, флоттун мааниси түздөн-түз token-ге чыгарылып, бирок эч кандай суффикс колдонулбагандыктан, аны кийинчерээк `f64` деп айтууга болот.
    ///
    /// Терс сандардан түзүлгөн критерийлер `TokenStream` же саптар аркылуу айланып өтпөй, эки tokens (`-` жана позитивдик түзмө-түз) болуп бөлүнүшү мүмкүн.
    ///
    /// # Panics
    ///
    /// Бул функция көрсөтүлгөн флоттун чектүү болушун талап кылат, мисалы, чексиздик же NaN болсо, бул функция panic болот.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Жаңы суффикстин сөзмө-сөз маанисин түзөт.
    ///
    /// Бул конструктор `1.0f64` сыяктуу сөзмө-сөз түзүп берет, анда көрсөтүлгөн маани token нин мурунку бөлүгү жана `f64` token суффикси болуп саналат.
    /// Бул token ар дайым компилятордо `f64` болушу мүмкүн.
    /// Терс сандардан түзүлгөн критерийлер `TokenStream` же саптар аркылуу айланып өтпөй, эки tokens (`-` жана позитивдик түзмө-түз) болуп бөлүнүшү мүмкүн.
    ///
    ///
    /// # Panics
    ///
    /// Бул функция көрсөтүлгөн флоттун чектүү болушун талап кылат, мисалы, чексиздик же NaN болсо, бул функция panic болот.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// String literal.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Тамга сөзмө-сөз.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Байт тилкеси.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Ушул сөзмө-сөз камтылган аралыкты кайтарып берет.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Бул түзмө-түз байланышкан аралыкты конфигурациялайт.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// `range` диапазонунда булактуу байттарды гана камтыган `self.span()` топтому болгон `Span` берет.
    /// Болочок кесилген `self` чегинен тышкары болсо, `None` кайтарып берет.
    ///
    // FIXME(SergioBenitez): байт диапазону булактын UTF-8 чегинде башталып бүтөрүн текшериңиз.
    // Болбосо, баштапкы текст басылып чыкканда, panic башка жерде болушу мүмкүн.
    // FIXME(SergioBenitez): колдонуучунун `self.span()` чындыгында эмнени чагылдырганын билүүгө эч кандай мүмкүнчүлүк жок, ошондуктан бул ыкманы учурда сокур деп гана атоого болот.
    // Мисалы, 'c' белгиси үчүн `to_string()` "'\u{63}'" берет;колдонуучунун баштапкы текст 'c' экендигин же '\u{63}' экендигин билүүгө эч кандай мүмкүнчүлүк жок.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) `Option::cloned` окшош нерсе, бирок `Bound<&T>` үчүн.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, көпүрө `to_string` ти гана камсыз кылат, анын негизинде `fmt::Display` ти ишке ашырат (экөөнүн ортосундагы кадимки мамиленин тескери жагы).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Түзмөктү сап катары басат, ал жоготулбастан кайра ошол эле түзмө-түз конверттелиши керек (калкып жүрүүчү чекит тамгаларынын тегеректелишинен тышкары).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Айлана-чөйрөнүн өзгөрмөлөрүнө көз салуу.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Айлана чөйрөнүн өзгөрмөсүн чыгарып, көз карандылык жөнүндө маалыматты түзүү үчүн кошуңуз.
    /// Компиляторду аткарган Build системасы, компиляция учурунда өзгөрүлмөгө жеткендигин билип, ошол өзгөрмөнүн мааниси өзгөргөндө, аны кайра иштете алат.
    ///
    /// Мындан тышкары, көз карандылыкты көзөмөлдөө бул функция стандарттык китепкананын `env::var` эквивалентине барабар болушу керек, бирок аргумент UTF-8 болушу керек.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}