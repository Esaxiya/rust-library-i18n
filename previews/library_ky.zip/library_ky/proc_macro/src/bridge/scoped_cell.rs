//! `Cell` (scoped) экзистенциалдуу өмүрүнүн варианты.

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// Ламбда тиркемесин, өмүр бою жазыңыз.
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// Өмүр бою алып жаткан лямбда түрүн, башкача айтканда, `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) `&'a mut <T as ApplyL<'b>>::Out` менен алмаштырылган newtype FIXME(#52812) менен проекциялоонун чектөөлөрүн айланып иштөө
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// Эски маанини өзгөртө турган `f` иштеп жатканда `self` тен `replacement` ге чейин маанини коет.
    /// Эски маани `f` чыккандан кийин, panic тарабынан, анын ичинде `f` тарабынан жасалган өзгөртүүлөр менен калыбына келтирилет.
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// `f` дүрбөлөңгө түшсө дагы, клетканын ар дайым толуп турушун камсыз кылган оромчу (баштапкы абалы, каалоосу боюнча `f` менен өзгөртүлөт).
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// `f` иштеп жатканда `self` тен `value` ке чейин маанини коет.
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}