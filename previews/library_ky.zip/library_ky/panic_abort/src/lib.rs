//! Rust panics процесстерин токтотуу аркылуу ишке ашыруу
//!
//! Ачуу аркылуу ишке ашырууга салыштырганда, бул crate *алда канча* жөнөкөй!Айткандай эле, бул анчалык ар тараптуу эмес, бирок мына!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" каралып жаткан платформада тийиштүү абортко пайдалуу жүк жана шим.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // std::sys::abort_internal чалуу
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Windows процессоруна мүнөздүү __fastfail механизмин колдонуңуз.Windows 8 жана андан кийинки версияларда, бул процесстеги өзгөчө кырдаал иштеткичтерин иштетпестен, процессти токтоосуз токтотот.
            // Windows тин мурунку котормолорунда, бул көрсөтмөлөрдүн ырааттуулугу, процессти токтотуп, бирок бардык өзгөчө иштетүүчүлөрдү сөзсүз аттап өтпөстөн, кирүүнү бузуу катары каралат.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: бул libstd's `abort_internal` сыяктуу эле ишке ашыруу
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Бул ... бир аз таң калыштуу нерсе.Tl; dr;Бул туура шилтеме кылуу үчүн талап кылынат, төмөндө узак түшүндүрмө.
//
// Азыр биз жеткирип жаткан libcore/libstd экилик файлдарынын бардыгы `-C panic=unwind` менен түзүлгөн.Бул экилик файлдардын мүмкүн болушунча көп кырдаалга шайкеш келишин камсыз кылуу үчүн жасалды.
// Бирок компилятор `-C panic=unwind` менен түзүлгөн бардык функциялар үчүн "personality function" талап кылат.Бул инсандык функция `rust_eh_personality` символу менен коддолгон жана `eh_personality` lang пункту менен аныкталат.
//
// So...
// Эмне үчүн ошол тилке пунктун ушул жерден эле аныктап албайсыз?Жакшы суроо!panic иштөө убактысы бири-бирине байлангандыгы, чындыгында, алар компилятордун crate дүкөнүндөгү "sort of" экендиги менен айырмаланат, бирок чындыгында башка бирөө байланышпаса гана байланышат.
//
// Бул crate жана panic_unwind crate экөө тең компилятордун crate дүкөнүндө пайда болушу мүмкүн деген маанини туюнтат, эгер экөө тең `eh_personality` lang пунктун аныктаса, анда ката кетет.
//
// Муну чечүү үчүн, `eh_personality` аныкталат, эгерде panic иштөө убактысы бош убакытка туташтырылса, анда аны аныктоо талап кылынбайт (мыйзамдуу түрдө).
// Бирок, бул учурда, бул китепкана ушул белгини гана аныктайт, андыктан бир жерде жок дегенде кандайдыр бир инсандык мүнөз бар.
//
// Чындыгында бул символ libcore/libstd экилик тутумуна өтүү үчүн гана аныкталган, бирок аны эч качан атабоо керек, анткени биз иштебей турган убакытты байланыштырбайбыз.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // X86_64-pc-windows-gnu де биз өз кадрларыбызды колдонуп жатабыз, ал `ExceptionContinueSearch` ти кайтарып бериши керек, анткени биз бардык кадрларыбызды өткөрүп жатабыз.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Жогорудагыдай эле, учурда Emscriptenде гана колдонулган `eh_catch_typeinfo` lang пунктуна туура келет.
    //
    // panics өзгөчө учурларды жаратпагандыктан жана чет өлкөлүк өзгөчө учурлар UB болгондуктан, -C panic=токтотуу (бирок өзгөрүшү мүмкүн), catch_unwind чалууларында бул тип эч качан колдонулбайт.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Бул экөөнү биздин i686-pc-windows-gnu баштоочу объектилерибиз деп аташат, бирок алар эч нерсе кылуунун кажети жок, ошондуктан органдар ноп болуп саналат.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}