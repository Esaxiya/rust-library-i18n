#![feature(no_core)]
#![no_core]

// Бул crate эмне үчүн керектигин rustc-std-жумуш мейкиндиги өзөгүнөн караңыз.

// Liballoc ичинде бөлүү модулуна карама-каршы келбөө үчүн crate атын өзгөртүңүз.
extern crate alloc as foo;

pub use foo::*;