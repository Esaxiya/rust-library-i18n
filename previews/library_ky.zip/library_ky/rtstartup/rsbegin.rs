// rsbegin.o жана rsend.o деп аталган "compiler runtime startup objects" болуп саналат.
// Аларда компилятордун иштөө убактысын туура баштоо үчүн керектүү код бар.
//
// Аткарылуучу же dylib сүрөтү байланыштырылганда, колдонуучунун бардык коддору жана китепканалары ушул эки объект файлынын ортосунда "sandwiched" болот, андыктан rsbegin.o коду же маалыматтар сүрөттүн тиешелүү бөлүктөрүндө биринчи орунду ээлейт, ал эми rsend.o коду жана маалыматтары акыркы болуп калат.
// Бул эффект белгилерди бөлүмдүн башына же аягына жайгаштыруу үчүн, ошондой эле керектүү баш жана төмөнкү колонтитулдарды киргизүү үчүн колдонулушу мүмкүн.
//
// Эске салсак, иш жүзүндө модулдун кирүү чекити C иштөө убактысын баштоочу объектте жайгашкан (адатта `crtX.o` деп аталат), андан кийин башка иштөө убактысынын компоненттеринин инициализациялык чалууларын чакырат (дагы бир атайын сүрөт бөлүмү аркылуу катталган).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Стек алкагынын ачылышы жөнүндө маалымат бөлүмүнүн башталышын белгилейт
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Кардарлардын ички эсеп-кысап иштерин жүргүзүү үчүн бош орун.
    // Бул $ GCC/unwind-dw2-fde.h ичинде `struct object` деп аныкталат.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // registration/deregistration күндөлүк иш-аракеттерин ачуу.
    // Libpanic_unwind документтерин караңыз.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // модулду ишке киргизүү жөнүндө маалыматты каттаңыз
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // өчүрүү боюнча каттоодон чыгуу
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW спецификалык init/uninit регулярдуу каттоосу
    pub mod mingw_init {
        // MinGW стартап объектилери (crt0.o/dllcrt0.o) ишке киргизүү жана чыгуу боюнча .ctors жана .dtors бөлүмдөрүндө глобалдык конструкторлорду чакырат.
        // DLLлерде бул DLL жүктөлгөн жана түшүрүлгөн учурда жасалат.
        //
        // Байланыштыруучу бөлүмдөрдү иреттейт, бул биздин чалуулардын тизмектин аягында болушун камсыз кылат.
        // Конструкторлор тескери тартипте иштетилгендиктен, бул биздин кайра чалуулардын биринчи жана акыркы аткарылышын камсыз кылат.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C инициализациясынын чакырыктары
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C токтотуу боюнча чалуу
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}