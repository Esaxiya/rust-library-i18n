use crate::future::Future;

/// Tiontú ina `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// An t-aschur go mbeidh an future tháirgeadh críochnaithe.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Cén cineál future a bhfuilimid ag iompú air seo?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Cruthaíonn sé future ó luach.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}