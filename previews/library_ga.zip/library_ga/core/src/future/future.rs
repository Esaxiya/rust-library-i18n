#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Léiríonn future ríomh asincrónach.
///
/// Is luach é future nach bhféadfadh a bheith críochnaithe le ríomhaireacht go fóill.
/// Fágann "asynchronous value" den chineál seo gur féidir le snáithe leanúint ar aghaidh ag déanamh obair úsáideach agus é ag fanacht go mbeidh an luach ar fáil.
///
///
/// # An modh `poll`
///
/// An modh croí future, `poll`, iarrachtaí * * a réiteach ar an future isteach i luach deiridh.
/// Ní dhéanann an modh bac mura bhfuil an luach réidh.
/// Ina áit sin, tá sé beartaithe an tasc reatha a mhúscailt nuair is féidir tuilleadh dul chun cinn a dhéanamh trí `vótáil 'arís.
/// An `context` ar aghaidh chuig an modh `poll` féidir a chur ar fáil ar [`Waker`], a bhfuil a láimhseáil chun dúiseacht leis an tasc atá ann faoi láthair.
///
/// Agus tú ag úsáid a future, ní bheidh tú ag glaoch de ghnáth `poll` díreach, ach ina ionad sin `.await` an luach.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// An cineál luacha a tháirgtear nuair a bheidh sé críochnaithe.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Iarracht chun an future réiteach le luach deiridh, ag clárú an tasc atá ann faoi láthair le haghaidh wakeup mura bhfuil an luach ar fáil go fóill.
    ///
    /// # Luach tuairisceáin
    ///
    /// Seo tuairisceáin fheidhm:
    ///
    /// - [`Poll::Pending`] mura bhfuil an future réidh fós
    /// - [`Poll::Ready(val)`] leis an toradh `val` den future seo má chríochnaigh sé go rathúil.
    ///
    /// Nuair a bheidh future críochnaithe, níor cheart do chliaint `poll` a dhéanamh arís.
    ///
    /// Nuair nach bhfuil future réidh fós, filleann `poll` `Poll::Pending` agus stórálann sé clón den [`Waker`] a cóipeáladh ón [`Context`] reatha.
    /// Dúisítear an [`Waker`] seo a luaithe is féidir leis an future dul chun cinn a dhéanamh.
    /// Mar shampla, tá future ag fanacht le soicéad a bheith inléite go gcuirfeadh sé `.clone()` ar an [`Waker`] agus é a stóráil.
    /// Nuair a thagann comhartha in áit eile a thugann le fios go bhfuil an soicéad inléite, tugtar [`Waker::wake`] agus dúisítear tasc an soicéid future.
    /// Chomh luath agus a tasc a bheith woken suas, ba cheart é a iarracht a `poll` an future arís, a d'fhéadfadh nó nach féidir a tháirgeadh le luach deiridh.
    ///
    /// Ba cheart Tabhair faoi deara go bhfuil ar ghlaonna il `poll`, ach an [`Waker`] ón [`Context`] ar aghaidh chuig an glaoch is déanaí a sceidealú a fháil wakeup.
    ///
    /// # Saintréithe Runtime
    ///
    /// Tá Futures ina n-aonar *támh*;ní foláir iad a *gníomhach*`poll`ed dul chun cinn a dhéanamh, rud a chiallaíonn go bhfuil gach uair a bhfuil an tasc atá ann faoi láthair woken suas, ba chóir é gníomhach ath-`poll` feitheamh futures go bhfuil sé fós ar spéis leo.
    ///
    /// Ní thugtar feidhm `poll` arís agus arís eile i lúb daingean-ina ionad sin, níor cheart í a ghlaoch ach nuair a thugann an future le fios go bhfuil sí réidh le dul chun cinn a dhéanamh (trí ghlaoch ar `wake()`).
    /// Má tá tú eolach ar na córais chórais `poll(2)` nó `select(2)` ar Unix is fiú a thabhairt faoi deara nach mbíonn na fadhbanna céanna ag "all wakeups must poll all events" de ghnáth ag futures;tá siad níos cosúla le `epoll(4)`.
    ///
    /// Ba cheart cur i bhfeidhm `poll` gach iarracht a thabhairt ar ais go tapa, agus níor chóir bloc.Coscann filleadh go gasta snáitheanna nó lúb imeachta a chlogáil gan ghá.
    /// Má tá a fhios roimh am go bhféadfadh glao ar `poll` a bheith uafásach i gcónaí, ba cheart an obair a dhíluchtú chuig linn snámha snáithe (nó rud éigin cosúil leis) lena chinntiú gur féidir le `poll` filleadh go gasta.
    ///
    /// # Panics
    ///
    /// Nuair a bheidh future críochnaithe (`Ready` ar ais ó `poll`), má ghlaonn sé ar a mhodh `poll` arís féadfaidh panic, blocáil go deo, nó cineálacha eile fadhbanna a chruthú;an trait `Future` leagann aon cheanglais maidir le héifeachtaí glao sórt.
    /// Mar sin féin, mar nach bhfuil an modh `poll` marcáilte `unsafe`, rialacha is gnách Rust ar: Ní mór do glaonna a chur faoi deara iompar undefined (éilliú chuimhne, úsáid mhícheart feidhmeanna `unsafe`, nó a leithéid), is cuma cén stáit na future ar.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}