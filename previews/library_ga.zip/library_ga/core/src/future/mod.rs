#![stable(feature = "futures_api", since = "1.36.0")]

//! luachanna asynchronous.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Teastaíonn an cineál seo mar gheall ar:
///
/// a) Ní féidir le gineadóirí `for<'a, 'b> Generator<&'a mut Context<'b>>` a chur i bhfeidhm, mar sin caithfimid pointeoir amh a rith (féach <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Níl leideanna amh agus `NonNull` `Send` nó `Sync`, ionas go mbeadh a dhéanamh ar gach aon future non-Send/Sync chomh maith, agus ní dhéanaimid mian sin.
///
/// Déantar simpliú freisin leis Hir ísliú de `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Fill gineadóir i future.
///
/// Filleann an fheidhm seo `GenFuture` thíos, ach cuireann sí i bhfolach í in `impl Trait` chun teachtaireachtaí earráide níos fearr a thabhairt (`impl Future` seachas `GenFuture<[closure.....]>`).
///
// Tá sé seo `const` chun earráidí a sheachaint breise i ndiaidh a ghnóthú againn ó `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Táimid ag brath ar an bhfíric go bhfuil async/await futures dochorraithe d`fhonn iasachtaí féinmheastóireachta a chruthú sa ghineadóir bunúsach.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // SÁBHÁILTEACHT: Sábháilte mar táimid !Unpin + !Drop, agus tá sé seo ach teilgean réimse.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Lean an gineadóir, ag casadh an `&mut Context` ina pointeoir `NonNull` amh.
            // Déanfaidh an t-ísliú `.await` é sin a chaitheamh ar ais go `&mut Context` go sábháilte.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch a ráthú gur pointeoir bailí é `cx.0`
    // a chomhlíonann na ceanglais go léir maidir le tagairt shochorraithe.
    unsafe { &mut *cx.0.as_ptr().cast() }
}