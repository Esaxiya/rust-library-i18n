Panics an snáithe atá ann faoi láthair.

Ligeann sé seo do chlár deireadh a chur láithreach agus aiseolas a sholáthar do ghlaoiteoir an chláir.
`panic!` ba cheart é a úsáid nuair a shroicheann clár staid neamh-inghnóthaithe.

Tá an macra an bealach iontach é a coinníollacha dhearbhú i sampla cód agus i dtástálacha.
`panic!` Tá ceangailte go dlúth leis an modh `unwrap` na [`Option`][ounwrap] agus [`Result`][runwrap] enums araon.
An dá implementations glaoch `panic!` nuair a leagtar a [`None`] nó [`Err`] leaganacha.

Agus tú ag úsáid `panic!()` féidir leat a shonrú ar pálasta teaghrán, atá tógtha ag baint úsáide as an error [`format!`].
Úsáidtear an t-ualach pá sin agus an panic á instealladh isteach sa snáithe Rust atá ag glaoch, rud a fhágann go bhfuil an snáithe go panic go hiomlán.

Iompar an réamhshocraithe `std` hook, i.e.
an cód a ritheann díreach tar éis an panic agairt is é a phriontáil ar an pálasta teachtaireacht a `stderr` chomh maith leis an t-eolas file/line/column an glaoch `panic!()`.

Is féidir leat an panic hook a shárú trí [`std::panic::set_hook()`] a úsáid.
Taobh istigh den hook is féidir teacht ar panic mar `&dyn Any + Send`, ina bhfuil `&str` nó `String` le haghaidh cuireadh rialta `panic!()`.
Chun panic le luach chineál eile eile, is féidir [`panic_any`] a úsáid.

[`Result`] Is Áirithe minic a réiteach níos fearr chun teacht chucu féin ó earráidí ná úsáid a bhaint an macra `panic!`.
Ba cheart an macra seo a úsáid chun dul ar aghaidh ag úsáid luachanna míchearta, amhail ó fhoinsí seachtracha.
Tá faisnéis mhionsonraithe faoi láimhseáil earráidí le fáil sa [book].

Féach freisin an macra [`compile_error!`], chun earráidí a ardú le linn tiomsú.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Cur i bhfeidhm reatha

Má tá an phríomhshnáithe panics beidh sé deireadh ar fad do snáitheanna agus do deireadh clár le cód `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





