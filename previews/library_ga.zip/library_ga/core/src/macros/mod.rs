#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Leathnaíonn sé go `$crate::panic::panic_2015` nó `$crate::panic::panic_2021` ag brath ar eagrán an ghlaoiteora.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Dearbhaíonn sé go bhfuil dhá abairt cothrom lena chéile (ag úsáid [`PartialEq`]).
///
/// Ar panic, priontálfaidh an macra seo luachanna na nathanna lena n-uiríll dífhabhtaithe.
///
///
/// Cosúil [`assert!`], tá an dara foirm, i gcás inar féidir teachtaireacht panic saincheaptha a chur ar fáil an macra.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Is iad na reborrows thíos ghnó.
                    // Gan iad, tá an sliotán Stack don iasacht initialized fiú roimh na luachanna a chur i gcomparáid, as a dtiocfaidh síos mall faoi deara.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Is iad na reborrows thíos ghnó.
                    // Gan iad, tá an sliotán Stack don iasacht initialized fiú roimh na luachanna a chur i gcomparáid, as a dtiocfaidh síos mall faoi deara.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Dearbhaíonn nach ionann dhá abairt agus a chéile (ag úsáid [`PartialEq`]).
///
/// Ar panic, priontálfaidh an macra seo luachanna na nathanna lena n-uiríll dífhabhtaithe.
///
///
/// Cosúil [`assert!`], tá an dara foirm, i gcás inar féidir teachtaireacht panic saincheaptha a chur ar fáil an macra.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Is iad na reborrows thíos ghnó.
                    // Gan iad, tá an sliotán Stack don iasacht initialized fiú roimh na luachanna a chur i gcomparáid, as a dtiocfaidh síos mall faoi deara.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Is iad na reborrows thíos ghnó.
                    // Gan iad, tá an sliotán Stack don iasacht initialized fiú roimh na luachanna a chur i gcomparáid, as a dtiocfaidh síos mall faoi deara.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Dearbhaíonn gurb é `true` slonn boole ag am rith.
///
/// Beidh sé seo agairt an macra [`panic!`] más rud é nach féidir leis an abairt ar fáil a mheas go `true` ag runtime.
///
/// Cosúil le [`assert!`], tá an dara leagan ag an macra seo freisin, áit ar féidir teachtaireacht saincheaptha panic a sholáthar.
///
/// # Uses
///
/// Murab ionann agus [`assert!`], ráitis `debug_assert!` atá ar fáil ach i neamh Optamaithe Tógann réir réamhshocraithe.
/// Ní Beidh tógáil optamaithe Ráitis `debug_assert!` fhorghníomhú ach amháin má tá `-C debug-assertions` ar aghaidh chuig an Tiomsaitheoir.
/// Fágann sé sin go bhfuil `debug_assert!` úsáideach le haghaidh seiceálacha atá ró-chostasach a bheith i láthair i dtógáil scaoilte ach a d`fhéadfadh a bheith cabhrach le linn na forbartha.
/// Is é an toradh ar leathnú `debug_assert!` cineálcheadaithe sheiceáil i gcónaí.
///
/// Ceadaíonn dearbhú unchecked clár i riocht nach dtagann sé a choinneáil ar siúl, a d'fhéadfadh a iarmhairtí gan choinne, ach ní isteach unsafety chomh fada is a tharlaíonn sé seo ach amháin i cód sábháilte.
///
/// Ní féidir costas feidhmíochta na ndearbhuithe a thomhas i gcoitinne, áfach.
/// In ionad [`assert!`] le `debug_assert!` é dá bhrí sin ach spreagtar tar éis phróifíliú críochnúil, agus níos tábhachtaí fós, ach amháin i cód sábháilte!
///
/// # Examples
///
/// ```
/// // Is é an teachtaireacht panic do na dearbhuithe an luach stringified an abairt a tugadh.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // feidhm an-simplí
/// debug_assert!(some_expensive_computation());
///
/// // dearbhú le teachtaireacht saincheaptha
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Dearbhaíonn sé go bhfuil dhá nathanna cothrom lena chéile.
///
/// Ar panic, priontálfaidh an macra seo luachanna na nathanna lena n-uiríll dífhabhtaithe.
///
/// Murab ionann agus [`assert_eq!`], ráitis `debug_assert_eq!` atá ar fáil ach i neamh Optamaithe Tógann réir réamhshocraithe.
/// Ní Beidh tógáil optamaithe Ráitis `debug_assert_eq!` fhorghníomhú ach amháin má tá `-C debug-assertions` ar aghaidh chuig an Tiomsaitheoir.
/// Seo a dhéanann `debug_assert_eq!` úsáideach le haghaidh seiceálacha atá ró-chostasach a bheith i láthair in a thógáil scaoileadh ach d'fhéadfadh a bheith cabhrach le linn na forbartha.
///
/// Déantar seiceáil ar chineál an toradh ar leathnú `debug_assert_eq!` i gcónaí.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Dearbhaíonn nach bhfuil dhá léiriú comhionann lena chéile.
///
/// Ar panic, priontálfaidh an macra seo luachanna na nathanna lena n-uiríll dífhabhtaithe.
///
/// Murab ionann agus [`assert_ne!`], ní chumasaítear ráitis `debug_assert_ne!` ach i bhfoirgnimh neamh-optamaithe de réir réamhshocraithe.
/// Ní fhorghníomhóidh tógáil optamaithe ráitis `debug_assert_ne!` mura gcuirtear `-C debug-assertions` ar aghaidh chuig an tiomsaitheoir.
/// Seo a dhéanann `debug_assert_ne!` úsáideach le haghaidh seiceálacha atá ró-chostasach a bheith i láthair in a thógáil scaoileadh ach d'fhéadfadh a bheith cabhrach le linn na forbartha.
///
/// Is é an toradh ar leathnú `debug_assert_ne!` cineálcheadaithe sheiceáil i gcónaí.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Filleann sé an bhfuil an abairt a thugtar comhoiriúnach le haon cheann de na patrúin a tugadh.
///
/// Cosúil i léiriú `match`, is féidir an patrún a leanúint go roghnach ag `if` agus léiriú garda go mbeidh rochtain ainmneacha atá faoi cheangal ag an phatrún.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Déan toradh a réiteach nó a earráid a iomadú.
///
/// Cuireadh an t-oibreoir `?` leis in ionad `try!` agus ba cheart é a úsáid ina ionad.
/// Thairis sin, tá `try` focal in áirithe i Rust 2018, mar sin má ní mór duit é a úsáid, beidh ort a bhaint as an [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` comhoiriúnach leis an [`Result`] a tugadh.I gcás an leagan `Ok`, tá leis an abairt an luach an luach fillte.
///
/// I gcás an athraitheora `Err`, déanann sé an earráid istigh a aisghabháil.Ansin déanann `try!` tiontú ag úsáid `From`.
/// Soláthraíonn an comhshó uathoibríoch idir earráidí speisialaithe agus cinn níos ginearálta.
/// Ansin cuirtear an earráid a leanann as ar ais láithreach.
///
/// Mar gheall ar an tuairisceán go luath, is féidir `try!` a úsáid ach amháin i bhfeidhmeanna a filleadh [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // An modh is fearr Earráidí filleadh tapaidh
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // An modh roimhe seo chun Earráidí a chur ar ais go tapa
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Is ionann é seo agus:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Scríobhann sé sonraí formáidithe i maolán.
///
/// Glacann an macra seo le 'writer', sreang formáide, agus liosta argóintí.
/// Déanfar argóintí a fhormáidiú de réir na sreinge formáide sonraithe agus cuirfear an toradh ar aghaidh chuig an scríbhneoir.
/// Is féidir leis an scríbhneoir aon luach le modh `write_fmt`;go ginearálta Tagann sé seo as cur i bhfeidhm sin don [`fmt::Write`] nó an trait [`io::Write`].
/// Na tuairisceáin macra cuma cad iad na tuairisceáin modh `write_fmt`;[`fmt::Result`], nó [`io::Result`] de ghnáth.
///
/// Féach [`std::fmt`] chun tuilleadh faisnéise a fháil ar chomhréir na sreinge formáide.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Is féidir le modúl `std::fmt::Write` agus `std::io::Write` a iompórtáil agus `write!` a ghlaoch ar rudaí a chuireann ceachtar acu i bhfeidhm, toisc nach gnách go gcuireann rudaí an dá rud i bhfeidhm.
///
/// Mar sin féin, an modúl ní mór allmhairiú an traits cáilithe mar sin ní dhéanann a n-ainmneacha coimhlint:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // úsáideann fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // úsáideann io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Is féidir an macra seo a úsáid i socruithe `no_std` freisin.
/// I socrú `no_std` tá tú freagrach as sonraí cur chun feidhme na gcomhpháirteanna.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Scríobh sonraí formáidithe i maolán, agus líne nua i gceangal leo.
///
/// Ar gach ardán, is é an líne nua an carachtar LINE FEED (`\n`/`U+000A`) amháin (gan aon CARRIAGE RETURN (`\r`/`U+000D`) breise.
///
/// Le haghaidh tuilleadh eolais a fháil, féach [`write!`].Chun faisnéis a fháil faoi chomhréir na sreinge formáide, féach [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Is féidir le modúl `std::fmt::Write` agus `std::io::Write` a iompórtáil agus `write!` a ghlaoch ar rudaí a chuireann ceachtar acu i bhfeidhm, toisc nach gnách go gcuireann rudaí an dá rud i bhfeidhm.
/// Mar sin féin, an modúl ní mór allmhairiú an traits cáilithe mar sin ní dhéanann a n-ainmneacha coimhlint:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // úsáideann fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // úsáideann io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Léiríonn sé cód neamh-inúsáidte.
///
/// Tá sé seo úsáideach am ar bith nach féidir leis an tiomsaitheoir a chinneadh go bhfuil cód éigin neamh-inrochtana.Mar shampla:
///
/// * airm a bhfuil coinníollacha garda Match.
/// * Lúbanna a chríochnaíonn go dinimiciúil.
/// * Iterators a fhoirceannadh dinimiciúil.
///
/// Má chruthaíonn an cinneadh go bhfuil an cód unreachable mícheart, deireadh leis an gclár láithreach le [`panic!`].
///
/// Is é an mhacasamhail neamhshábháilte an macra fheidhm [`unreachable_unchecked`], a chur faoi deara iompar undefined má tá an cód bainte.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Beidh sé i gcónaí [`panic!`].
///
/// # Examples
///
/// Airm mheaitseála:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // Earráid thiomsú más dúirt amach
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // ar cheann de na implementations is boichte x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Léiríonn sé cód unimplemented trí panicking le teachtaireacht de "not implemented".
///
/// Ligeann sé seo do chód chun cineál-seic, atá úsáideach má tá tú ag prototyping nó trait go n-éilíonn modhanna éagsúla nach bhfuil tú plean ar úsáid a bhaint as go léir a chur i bhfeidhm.
///
/// Is é an difríocht idir `unimplemented!` agus [`todo!`] cé thugann `todo!` ar intinn a chur i bhfeidhm ar an fheidhmiúlacht níos déanaí agus tá an teachtaireacht "not yet implemented", a dhéanann `unimplemented!` aon éileamh den sórt sin.
/// Is é an teachtaireacht "not implemented".
/// Chomh maith leis sin marcálfaidh roinnt IDEanna `todo!`.
///
/// # Panics
///
/// Déanfaidh sé seo [`panic!`] i gcónaí toisc nach bhfuil `unimplemented!` ach gearr-lámh do `panic!` le teachtaireacht sheasta, shonrach.
///
/// Cosúil le `panic!`, tá an dara foirm ag an macra seo chun luachanna saincheaptha a thaispeáint.
///
/// # Examples
///
/// Abair go bhfuil trait `Foo` againn:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Is mian linn a `Foo` i bhfeidhm do 'MyStruct', ach ar chúis éigin a dhéanann sé ach ciall a sholáthar don fheidhm `bar()` a chur i bhfeidhm.
/// `baz()` agus beidh ort `qux()` fós le sainiú inár chun feidhme `Foo`, ach is féidir linn a úsáid `unimplemented!` ina gcuid sainmhínithe chun go mbeidh rochtain cód a chur le chéile.
///
/// Ba mhaith linn fós go stopfadh ár gclár má rithtear na modhanna neamhfheidhmithe.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Déanann sé aon chiall leis `baz` le `MyStruct`, ionas go mbeidh muid aon loighic anseo ar chor ar bith.
/////
///         // Taispeánfaidh sé seo "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Tá roinnt loighic anseo, is féidir linn a chur teachtaireacht chuig unimplemented!a chur ar taispeáint ar ár fhágáil ar lár.
///         // Beidh sé seo a thaispeáint: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Léiríonn sé cód neamhchríochnaithe.
///
/// aisiúil é seo má tá tú ag prototyping agus atá á lorg ach go bhfuil do typecheck cód.
///
/// Is é an difríocht idir [`unimplemented!`] agus `todo!` cé thugann `todo!` ar intinn a chur i bhfeidhm ar an fheidhmiúlacht níos déanaí agus tá an teachtaireacht "not yet implemented", a dhéanann `unimplemented!` aon éileamh den sórt sin.
/// Is é an teachtaireacht "not implemented".
/// Chomh maith leis sin marcálfaidh roinnt IDEanna `todo!`.
///
/// # Panics
///
/// Beidh sé i gcónaí [`panic!`].
///
/// # Examples
///
/// Seo sampla de roinnt cód idir lámha.Tá trait `Foo` againn:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Is mian linn a chur i bhfeidhm `Foo` ar cheann dár cineálacha, ach ba mhaith linn freisin a bheith ag obair ar díreach `bar()` dtús.Ionas go dtiomsóidh ár gcód, caithfimid `baz()` a chur i bhfeidhm, ionas gur féidir linn `todo!` a úsáid:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // Téann chun feidhme anseo
///     }
///
///     fn baz(&self) {
///         // ná bíodh imní orainn faoi baz() a chur i bhfeidhm anois
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // níl baz() á úsáid againn fiú, mar sin tá sé seo go maith.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Sainmhínithe ar macraí ionsuite.
///
/// An chuid is mó de na hairíonna macra (cobhsaíocht, infheictheacht, etc.) atá tógtha as an cód foinse anseo, le cé is moite de feidhmeanna leathnaithe ag athrú ionchur macra i aschur, na feidhmeanna sin ar fáil ag an tiomsaitheoir.
///
///
pub(crate) mod builtin {

    /// Cúiseanna tiomsaithe a theipeann leis an teachtaireacht earráide a tugadh nuair a bhíonn.
    ///
    /// Ba chóir an macra a úsáid nuair a úsáideann crate straitéis thiomsú coinníollach chun teachtaireachtaí earráide níos fearr a chur ar fáil do choinníollacha earráideach.
    ///
    /// Tá sé an fhoirm tiomsaitheoir-leibhéal de [`panic!`], ach astaíonn earráid le linn *thiomsú* in áit ar *runtime*.
    ///
    /// # Examples
    ///
    /// Tá dhá shampla den sórt sin Macraí agus timpeallachtaí `#[cfg]`.
    ///
    /// Earráid earráide tiomsaitheora níos fearr má ritear macra luachanna neamhbhailí.
    /// Gan an branch deiridh, bheadh an tiomsaitheoir scaoileann fós earráid, ach ní bheadh teachtaireacht an earráid a lua an dá luach bailí.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Earráid tiomsaitheora a scaoileadh mura bhfuil ceann de roinnt gnéithe ar fáil.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Tógann sé paraiméadair do na macraí formáidithe sreinge eile.
    ///
    /// Feidhmíonn an macra seo trí shreang liteartha formáidithe a thógáil ina bhfuil `{}` do gach argóint bhreise a ritear.
    /// `format_args!` ullmhaíonn sé na paraiméadair bhreise lena chinntiú gur féidir an t-aschur a léirmhíniú mar shreang agus canónaíonn sé na hargóintí in aon chineál amháin.
    /// Aon luach arna uirlisí féidir leis trait [`Display`] a chur ar aghaidh go dtí `format_args!`, mar is féidir aon chur i bhfeidhm [`Debug`] a chur ar aghaidh chuig `{:?}` laistigh den teaghrán formáidiú.
    ///
    ///
    /// Táirgeann an macra luach chineál [`fmt::Arguments`].Is féidir an luach seo a chur ar aghaidh chuig na macraí laistigh de [`std::fmt`] chun atreorú úsáideach a dhéanamh.
    /// Déantar gach macraí formáidithe eile ([`formáid!`], [`write!`], [`println!`], srl) a proxied tríd an gceann seo.
    /// `format_args!`, murab ionann agus a chuid Macraí díorthaithe, seachnaítear leis gcarn leithdháiltí.
    ///
    /// Is féidir leat úsáid an luach [`fmt::Arguments`] go bhfilleann `format_args!` in `Debug` agus `Display` comhthéacsanna mar atá le feiceáil thíos.
    /// Léiríonn an sampla chomh maith go `Debug` agus `Display` maith chuig an rud céanna: an teaghrán formáidithe interpolated in `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Le haghaidh tuilleadh eolais a fháil, féach ar an doiciméadú i [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Mar an gcéanna le `format_args`, ach cuireann sé líne nua sa deireadh.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Iniúchadh ar athróg timpeallachta ag am tiomsaithe.
    ///
    /// Beidh an macra a leathnú chun an luach na hathróige timpeallachta atá ainmnithe ag am tiomsaithe, torthaí a bhíonn orthu léiriú chineál `&'static str`.
    ///
    ///
    /// Mura bhfuil an athróg timpeallachta sainithe, ansin beidh earráid thiomsú a astú.
    /// Chun gan earráid tiomsaithe a astú, úsáid an macra [`option_env!`] ina ionad.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Is féidir leat a shaincheapadh ar an teachtaireacht earráide ag dul thar ar shraith mar an dara paraiméadar:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Mura bhfuil an athróg timpeallachta `documentation` sainithe, beidh tú an earráid seo a leanas:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Déanann sé iniúchadh roghnach ar athróg comhshaoil ag an am tiomsaithe.
    ///
    /// Má tá an athróg timpeallachta ainmnithe i láthair ag an am tiomsaithe, leathnóidh sé seo go slonn de chineál `Option<&'static str>` arb é a luach `Some` de luach an athróg chomhshaoil.
    /// Mura bhfuil an athróg timpeallachta reatha, ansin beidh sé seo a leathnú go dtí `None`.
    /// Féach [`Option<T>`][Option] chun tuilleadh faisnéise a fháil faoin gcineál seo.
    ///
    /// Ní Tá earráid am tiomsaithe astaítear iad ag úsáid an macra gan aird ar cibé an bhfuil an athróg timpeallachta reatha nó nach bhfuil.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates aitheantóirí isteach aitheantóir amháin.
    ///
    /// Cuireann an macra aon líon na aitheantóirí camóga-scartha, agus concatenates iad go léir i amháin, torthaí a bhíonn orthu léiriú is aitheantóir nua.
    /// Tabhair faoi deara go ndéanann sláinteachas sé ar dhóigh nach féidir an macra ghabháil athróga áitiúla.
    /// Ina theannta sin, mar riail ghinearálta, tá Macraí cheadú ach amháin i mír, ráiteas nó seasamh abairt.
    /// Ciallaíonn sé cé gur féidir leat úsáid a bhaint as an macra tagairt athróg, feidhmeanna atá ann cheana nó modúil srl, ní féidir leat a shainiú ceann nua leis.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // concat_idents fn! (nua, spraoi, ainm) { }//nach inúsáidte ar an mbealach seo!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates liteartha i slice sreangán statach.
    ///
    /// Cuireann an macra aon líon na litriúla camóga-scartha, torthaí a bhíonn orthu léiriú ar chineál `&'static str` a dhéanann ionadaíocht ar gach ceann de na litriúla concatenated chlé go deas.
    ///
    ///
    /// Déantar litreacha slánuimhir agus snámhphointí a shreangú d`fhonn a bheith comhthráthach.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Leathnaíonn leis an uimhir líne ar a raibh sé agairt.
    ///
    /// Le [`column!`] agus [`file!`], soláthraíonn na Macraí faisnéis debugging d'fhorbróirí mar gheall ar an suíomh laistigh den fhoinse.
    ///
    /// tá leis an abairt leathnaithe cineál `u32` agus tá sé 1-bhunaithe, mar sin an chéad líne i ngach sé measúnú comhad a 1, an dara go dtí 2, etc.
    /// Tagann sé seo le teachtaireachtaí earráide ag tiomsaitheoirí coiteann nó eagarthóirí tóir.
    /// Ní gá gurb é an líne a chuirtear ar ais * líne an agairt `line!` féin, ach an chéad macra-agairt roimh an macra `line!` a agairt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Leathnaíonn leis an uimhir colún ag ar agairt é.
    ///
    /// Le [`line!`] agus [`file!`], soláthraíonn na Macraí faisnéis debugging d'fhorbróirí mar gheall ar an suíomh laistigh den fhoinse.
    ///
    /// tá leis an abairt leathnaithe cineál `u32` agus tá sé 1-bhunaithe, mar sin an chéad cholún i ngach sé measúnú ag teacht go dtí 1, an dara go dtí 2, etc.
    /// Tagann sé seo le teachtaireachtaí earráide ag tiomsaitheoirí coiteann nó eagarthóirí tóir.
    /// Ní gá gurb é an colún a chuirtear ar ais * líne an agairt `column!` féin, ach an chéad macra-agairt roimh an macra `column!` a agairt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Leathnaíonn sé go dtí ainm an chomhaid inar agraíodh é.
    ///
    /// Le [`line!`] agus [`column!`], soláthraíonn na Macraí faisnéis debugging d'fhorbróirí mar gheall ar an suíomh laistigh den fhoinse.
    ///
    /// Tá cineál `&'static str` ag an slonn leathnaithe, agus ní agairt an macra `file!` féin atá sa chomhad ar ais, ach an chéad macra-agairt roimh an macra `file!` a agairt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringifies chuid argóintí.
    ///
    /// Tabharfaidh an macra seo léiriú de chineál `&'static str` arb é atá ann sreangú na tokens go léir a chuirtear ar aghaidh chuig an macra.
    /// Uimh srianta a chur ar an error an agairt macra féin.
    ///
    /// Tabhair faoi deara go bhféadfadh torthaí leathnaithe an ionchuir tokens athrú sa future.Ba cheart duit a bheith cúramach má tá tú ag brath ar an aschur.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Lena n-áirítear comhad ionchódaithe UTF-8 mar theaghrán.
    ///
    /// Tá an comhad suite i gcoibhneas leis an gcomhad reatha (cosúil leis an gcaoi a bhfaightear modúil).
    /// Tá an cosán ar fáil léiriú ar shlí a ardán-sonrach ag am tiomsaithe.
    /// Mar sin, mar shampla, ar agairt le cosán Windows ina backslashes `\` bheadh thiomsú i gceart ar Unix.
    ///
    ///
    /// Beidh an macra toradh léiriú chineál `&'static str` a bhfuil an ábhair an chomhaid.
    ///
    /// # Examples
    ///
    /// Glac leis go bhfuil dhá chomhad san eolaire céanna leis an ábhar seo a leanas:
    ///
    /// Comhad 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Comhad 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Déanfaidh 'main.rs' a thiomsú agus an dénártha mar thoradh air a phriontáil "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Lena n-áirítear comhad mar thagairt do raon beart.
    ///
    /// Tá an comhad suite i gcoibhneas leis an gcomhad reatha (cosúil leis an gcaoi a bhfaightear modúil).
    /// Tá an cosán ar fáil léiriú ar shlí a ardán-sonrach ag am tiomsaithe.
    /// Mar sin, mar shampla, ar agairt le cosán Windows ina backslashes `\` bheadh thiomsú i gceart ar Unix.
    ///
    ///
    /// Tabharfaidh an macra seo léiriú de chineál `&'static [u8; N]` arb é ábhar an chomhaid é.
    ///
    /// # Examples
    ///
    /// Glac leis go bhfuil dhá chomhad san eolaire céanna leis an ábhar seo a leanas:
    ///
    /// Comhad 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Comhad 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Déanfaidh 'main.rs' a thiomsú agus an dénártha mar thoradh air a phriontáil "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Leathnaíonn leis teaghrán a ionadaíonn an cosán modúl atá ann faoi láthair.
    ///
    /// Is féidir leis an cosán modúl atá ann faoi láthair a cumha mar an ordlathas na modúil a dtiocfaidh ar ais go dtí an root crate.
    /// Is é an chéad chomhpháirt den chosán a cuireadh ar ais ainm an crate atá á chur le chéile faoi láthair.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Déanann sé meastóireacht ar theaglaim boole de bhratacha cumraíochta ag am tiomsaithe.
    ///
    /// Chomh maith leis an aitreabúid `#[cfg]`, soláthraítear an macra seo chun meastóireacht slonn boole ar bhratacha cumraíochta a cheadú.
    /// Seo go minic mar thoradh go cód lú dhúbailt.
    ///
    /// Is í an chomhréir chéanna a thugtar don mhacra seo leis an aitreabúid [`cfg`].
    ///
    /// `cfg!`, murab ionann agus `#[cfg]`, ní bhaineann sé aon chód as agus ní mheasann sé ach fíor nó bréagach.
    /// Mar shampla, is gá go mbeadh gach bloc i slonn if/else bailí nuair a úsáidtear `cfg!` don riocht, is cuma cad atá `cfg!` á mheas.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Parses comhad mar léiriú nó mír de réir an chomhthéacs.
    ///
    /// Tá an comhad suite i gcoibhneas leis an gcomhad reatha (cosúil leis an gcaoi a bhfaightear modúil).Tá an cosán ar fáil léiriú ar shlí a ardán-sonrach ag am tiomsaithe.
    /// Mar sin, mar shampla, ar agairt le cosán Windows ina backslashes `\` bheadh thiomsú i gceart ar Unix.
    ///
    /// Ag baint úsáide as an macra is minic droch-smaoineamh, mar má tá an comhad pharsáil mar léiriú, tá sé ag dul chun é a chur sa chód máguaird unhygienically.
    /// D'fhéadfadh sé seo mar thoradh ar athróga nó feidhmeanna á difriúil ón méid an comhad súil leis má tá athróg nó feidhmeanna a bhfuil an t-ainm céanna sa chomhad atá ann faoi láthair.
    ///
    ///
    /// # Examples
    ///
    /// Glac leis go bhfuil dhá chomhad san eolaire céanna leis an ábhar seo a leanas:
    ///
    /// Comhad 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Comhad 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Ag tiomsú 'main.rs' agus a reáchtáil ar an dénártha mar thoradh air a phriontáil "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Dearbhaíonn gurb é `true` slonn boole ag am rith.
    ///
    /// Beidh sé seo agairt an macra [`panic!`] más rud é nach féidir leis an abairt ar fáil a mheas go `true` ag runtime.
    ///
    /// # Uses
    ///
    /// Déantar dearbhuithe a sheiceáil i gcónaí i dtógálacha dífhabhtaithe agus scaoilte, agus ní féidir iad a dhíchumasú.
    /// Féach [`debug_assert!`] le haghaidh dearbhuithe nach bhfuil cumasaithe i dtógálacha scaoilte de réir réamhshocraithe.
    ///
    /// Is féidir cód neamhshábháilte bheith ag brath ar `assert!` chun invariants reáchtáil-am sin, más rud é go bhféadfadh sháraigh mar thoradh ar chur i bhfeidhm unsafety.
    ///
    /// I measc na gcásanna úsáide eile de `assert!` tá ionróirí rith-ama a thástáil agus a fhorfheidhmiú i gcód sábháilte (ní féidir neamhshábháilteacht a bheith mar thoradh ar a sárú).
    ///
    ///
    /// # Teachtaireachtaí Saincheaptha
    ///
    /// Tá an dara foirm, i gcás inar féidir teachtaireacht panic saincheaptha a chur ar fáil le nó gan hargóintí ar son formáidiú an macra.
    /// Féach [`std::fmt`] le haghaidh comhréir don fhoirm seo.
    /// Beidh Léirithe úsáidtear mar argóintí bhformáid a mheas ach amháin má theipeann ar an dearbhú.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // Is é an teachtaireacht panic do na dearbhuithe an luach stringified an abairt a tugadh.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // feidhm an-simplí
    ///
    /// assert!(some_computation());
    ///
    /// // dearbhú le teachtaireacht saincheaptha
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Inlíne tionól.
    ///
    /// Léigh an [unstable book] don úsáid.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Tionól inlíne i stíl LLVM.
    ///
    /// Léigh an [unstable book] don úsáid.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Tionól inlíne ar leibhéal an mhodúil.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Priontaí ritheadh tokens isteach an t-aschur caighdeánach.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Cumasaíonn nó díchumasaíonn feidhmiúlacht rianaithe a úsáidtear chun macraí eile a dhífhabhtú.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Macra tréith a úsáidtear chun macraí díorthaithe a chur i bhfeidhm.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Macra tréith a chuirtear i bhfeidhm ar fheidhm chun tástáil aonaid a dhéanamh di.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Tréith macra bhfeidhm le feidhm a dul sé isteach ar thástáil tagarmharc.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// An mionsonraí cur chun feidhme an `#[test]` agus `#[bench]` Macraí.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Tréith macra chuirtear i bhfeidhm ar statach a chlárú mar Allocator domhanda.
    ///
    /// Féach freisin [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Gcoimeádann an mhír sé i bhfeidhm ar má tá an cosán a rith inrochtana, agus go mbainfidh sé ar shlí eile.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Leathnaíonn sé na tréithe `#[cfg]` agus `#[cfg_attr]` go léir sa blúire cód lena gcuirtear i bhfeidhm é.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Ná húsáid sonraí cur chun feidhme éagobhsaí an tiomsaitheora `rustc`.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Ná húsáid sonraí cur chun feidhme éagobhsaí an tiomsaitheora `rustc`.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}