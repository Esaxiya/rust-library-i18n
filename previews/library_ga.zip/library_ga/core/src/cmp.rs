//! Feidhmiúlacht ordú agus comparáide.
//!
//! Tá uirlisí éagsúla sa mhodúl seo chun luachanna a ordú agus a chur i gcomparáid.Go hachomair:
//!
//! * [`Eq`] agus tá [`PartialEq`] traits a ligfidh tú comhionannas iomlán nó pháirteach a shainiú idir luachanna, faoi seach.
//! Má chuirtear i bhfeidhm iad, déanann na hoibreoirí `==` agus `!=` iad a ró-ualach.
//! * [`Ord`] agus 0traits iad [`PartialOrd`] a ligeann duit orduithe iomlána agus páirteach a shainiú idir luachanna, faoi seach.
//!
//! iad a chur i bhfeidhm iomarca brú ar na hoibreoirí `<`, `<=`, `>`, agus `>=`.
//! * [`Ordering`] Is Áirithe ar ais ag na príomhfheidhmeanna [`Ord`] agus [`PartialOrd`], agus déantar cur síos ar a ordú.
//! * [`Reverse`] is struchtúr é a ligeann duit ordú a aisiompú go héasca.
//! * [`max`] agus tá [`min`] feidhmeanna a thógáil de thalamh na [`Ord`] agus deis a thabhairt duit a fháil ar an t-uasmhéid nó íosmhéid de dá luach.
//!
//! Le haghaidh tuilleadh sonraí, féach cáipéisíocht faoi seach gach earra ar an liosta.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait le haghaidh comparáidí comhionannais atá [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// Ceadaíonn an trait seo comhionannas páirteach, do chineálacha nach bhfuil gaol coibhéise iomlán acu.
/// Mar shampla, i líon snámhphointe `NaN != NaN`, mar sin cineálacha snámhphointe i bhfeidhm `PartialEq` ach ní [`trait@Eq`].
///
/// Go foirmiúil, ní mór an comhionannas a (do gach `a`, `b`, `c` den chineál `A`, `B`, `C`):
///
/// - **Siméadrach**: má tá `A: PartialEq<B>` agus `B: PartialEq<A>` ann, ansin tugann **`a==b` le tuiscint`b==a`**;agus
///
/// - **aistreacha**: más rud é `A: PartialEq<B>` agus `B: PartialEq<C>` agus `A:
///   PartialEq<C>`, Ansin **` tuiscint b`==agus `b == c` a==c`**.
///
/// Tabhair faoi deara nach bhfuil na impls `B: PartialEq<A>` (symmetric) agus `A: PartialEq<C>` (transitive) éigean a bheith ann, ach tá feidhm ag na riachtanais seo nuair a dhéanann siad ndé.
///
/// ## Derivable
///
/// Is féidir an trait seo a úsáid le `#[derive]`.Nuair a bhíonn tú díorthaithe ar struchtúir, tá dhá chás cothrom má tá na réimsí uile cothrom, agus mura bhfuil siad comhionann mura bhfuil aon réimsí cothrom.Nuair `derive`d ar enums, tá gach aon athraitheach ionann agus féin agus nach cothrom leis na leaganacha eile.
///
/// ## Conas is féidir liom a chur i bhfeidhm `PartialEq`?
///
/// `PartialEq` ní éilíonn sé ach an modh [`eq`] a chur i bhfeidhm;[`ne`] Sainmhínítear i dtéarmaí air de réir réamhshocraithe.Caithfidh aon chur chun feidhme láimhe de [`ne`] * an riail a urramú gur inbhéartach docht [`ne`] é [`eq`];is é sin, `!(a == b)` más gá agus más `a != b`.
///
/// Implementations de `PartialEq`, [`PartialOrd`], agus [`Ord`]*mór* aontú lena chéile.Is furasta iad a easaontú trí thimpiste trí chuid de na traits a dhíorthú agus cuid eile a chur i bhfeidhm de láimh.
///
/// Cur i bhfeidhm Sampla haghaidh réimse ina bhfuil dhá leabhar mheastar an leabhar céanna má tá a n-cluichí ISBN, fiú amháin más rud é go difriúil na formáidí:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Conas is féidir liom a chur i gcomparáid dhá chineál éagsúla?
///
/// Tá an cineál ar féidir leat comparáid a dhéanamh leis faoi rialú ag paraiméadar cineál `PartialEq`.
/// Mar shampla, déanaimis tweak a dhéanamh ar ár gcód roimhe seo beagán:
///
/// ```
/// // Na uirlisí a dhíorthú<BookFormat>==<BookFormat>comparáidí
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Cur i bhfeidhm<Book>==<BookFormat>comparáidí
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // a chur i bhfeidhm<BookFormat>==<Book>comparáidí
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Trí `impl PartialEq for Book` a athrú go `impl PartialEq<BookFormat> for Book`, ligimid do `BookFormat`s a chur i gcomparáid le`Book`s.
///
/// Is féidir le comparáid cosúil leis an gceann thuas, a dhéanann neamhaird ar roinnt réimsí den déanmhas, a bheith contúirteach.Is féidir é a thoradh go héasca chun sárú neamhbheartaithe na ceanglais maidir le gaol coibhéise páirteach.
/// Mar shampla, dá leanfaimis an cur chun feidhme thuas de `PartialEq<Book>` do `BookFormat` agus dá gcuirfí `PartialEq<Book>` i bhfeidhm le haghaidh `Book` (trí `#[derive]` nó tríd an gcur i bhfeidhm láimhe ón gcéad sampla) ansin sháródh an toradh an trasghníomhaíocht:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Déanann an modh seo tástálacha ar luachanna `self` agus `other` a bheith comhionann, agus úsáideann `==` é.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Tástálacha Sa chaoi seo is `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// macra Díorthaigh ghiniúint impl an `PartialEq` trait.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait le haghaidh comparáidí comhionannais atá [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// Ciallaíonn, go chomh maith le `a == b` agus `a != b` á inbhéartaigh siúd dian, ní mór an comhionannas a (do gach `a`, `b` agus `c`):
///
/// - reflexive: `a == a`;
/// - siméadracha: Ciallaíonn `a == b` `b == a`;agus
/// - aistritheach: tugann `a == b` agus `b == c` le tuiscint `a == c`.
///
/// Ní féidir an mhaoin a sheiceáil ag an Tiomsaitheoir, agus tuiscint dá bhrí `Eq` [`PartialEq`], agus nach bhfuil aon modhanna breise.
///
/// ## Derivable
///
/// Is féidir an trait seo a úsáid le `#[derive]`.
/// Nuair a dhíorthaítear, toisc nach bhfuil aon mhodhanna breise ag `Eq`, níl sé ach ag cur in iúl don tiomsaitheoir gur gaol coibhéise é seo seachas gaol coibhéise páirteach.
///
/// Tabhair faoi deara go n-éilíonn an straitéis `derive` bhfuil gach réimse `Eq`, nach bhfuil ag teastáil i gcónaí.
///
/// ## Conas is féidir liom `Eq` a chur i bhfeidhm?
///
/// Mura féidir leat a bhaint as an straitéis `derive`, a shonrú go bhfuil do uirlisí chineál `Eq`, nach bhfuil aon mhodhanna:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // ní úsáideann#[deriving] an modh seo ach chun a dhearbhú go gcuireann gach comhpháirt de chineál#[díorthú] i bhfeidhm, ciallaíonn an bonneagar díorthach reatha an dearbhú seo a dhéanamh gan modh a úsáid ar an trait seo beagnach dodhéanta.
    //
    //
    // Níor chóir é seo a chur chun feidhme de láimh.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Faigh macra a ghineann impl den trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: Tá an struct úsáidtear d'aon toisc le#[dhíorthú] go
// a dhearbhú go gcuireann gach comhpháirt de chineál Eq i bhfeidhm.
//
// Níor cheart go mbeadh an struchtúr seo le feiceáil riamh i gcód úsáideora.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Tá `Ordering` toradh comparáid idir dhá luach.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// An ordú sa chás go bhfuil luach i gcomparáid níos lú ná a chéile.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// An ordú sa chás go bhfuil luach i gcomparáid ionann agus ceann eile.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// An ordú sa chás go bhfuil luach i gcomparáid níos mó ná a chéile.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Tuairisceáin `true` más é an t-ordú an leagan `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Tuairisceáin `true` mura é an t-ordú an leagan `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Tuairisceáin `true` má tá an ordú an leagan `Less`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Tuairisceáin `true` má tá an ordú an leagan `Greater`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Tuairisceáin `true` más é an t-ordú an leagan `Less` nó `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Tuairisceáin `true` más é an t-ordú an leagan `Greater` nó `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Aisiompaíonn an `Ordering`.
    ///
    /// * `Less` thiocfaidh chun bheith `Greater`.
    /// * `Greater` thiocfaidh chun bheith `Less`.
    /// * `Equal` Thiocfaidh chun bheith `Equal`.
    ///
    /// # Examples
    ///
    /// Iompar bunúsach:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Is féidir an modh seo a úsáid chun comparáid a aisiompú:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // sórtáil an eagar ón gceann is mó go dtí an ceann is lú.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Slabhraí dhá ordú.
    ///
    /// Filleann `self` nuair nach `Equal` é.Seachas sin filleann `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Slabhraí an ordaithe leis an bhfeidhm a thugtar.
    ///
    /// Filleann `self` nuair nach `Equal` é.
    /// Seachas sin glaonna `f` agus tuairisceáin an toradh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Struchtúr cúntóra le haghaidh ordú droim ar ais.
///
/// Tá an struct ina cúntóir a bheidh le húsáid le feidhmeanna ar nós [`Vec::sort_by_key`] agus is féidir iad a úsáid chun a aisiompú mar chuid de eochair.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait do chineálacha a fhoirmiú [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// Is ordú iomlán ordú más ea (do gach `a`, `b` agus `c`):
///
/// - iomlán agus neamhshiméadrach: tá ceann amháin de `a < b`, `a == b` nó `a > b` fíor;agus
/// - aistreacha, `a < b` agus `b < c` tuiscint `a < c`.Ní mór an rud céanna a bheith ag `==` agus `>` araon.
///
/// ## Derivable
///
/// Is féidir an trait seo a úsáid le `#[derive]`.
/// Nuair a dhíorthaíonn sé struchtúir, soláthróidh sé ordú [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) bunaithe ar ordú dearbhaithe ó bhun go barr chomhaltaí an déanmhais.
///
/// Nuair `derive`d ar enums, leagan curtha in ord ag a n-barr-go-bun ord discriminant.
///
/// ## Comparáid foclóireachta
///
/// Is oibríocht í an chomparáid foclóireachta leis na hairíonna seo a leanas:
///  - Déantar comparáid idir dhá shraith gné ar eilimint.
///  - An chéad sainmhíníonn eilimint mismatching atá seicheamh lexicographically lú nó níos mó ná an ceann eile.
///  - Má tá seicheamh ar cheann réimír eile, is é an t-ord giorra lexicographically lú ná an ceann eile.
///  - Má tá dhá ord eilimintí choibhéiseacha agus go bhfuil siad an fad céanna, ansin tá na sraitheanna lexicographically comhionann.
///  - Tá seicheamh folamh níos lú ó thaobh foclóireachta de ná aon seicheamh neamhfholamh.
///  - Tá dhá shraith fholamh cothrom ó thaobh foclóireachta de.
///
/// ## Conas is féidir liom `Ord` a chur i bhfeidhm?
///
/// `Ord` éilíonn gur [`PartialOrd`] agus [`Eq`] an cineál freisin (a éilíonn [`PartialEq`]).
///
/// Ansin, ní mór duit a shainmhíniú chun feidhme do [`cmp`].Is féidir go mbeidh sé ina chuidiú a úsáid [`cmp`] ar réimsí do chineál ar.
///
/// Caithfidh cur chun feidhme [`PartialEq`], [`PartialOrd`], agus `Ord` * aontú lena chéile.
/// Is é sin, `a.cmp(b) == Ordering::Equal` más gá agus más `a == b` agus `Some(a.cmp(b)) == a.partial_cmp(b)` do gach `a` agus `b`.
/// Is furasta iad a easaontú trí thimpiste trí chuid de na traits a dhíorthú agus cuid eile a chur i bhfeidhm de láimh.
///
/// Seo sampla inar mian leat do dhaoine ag airde amháin, aird a thabhairt `id` agus `name` shórtáil:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Filleann an modh seo [`Ordering`] idir `self` agus `other`.
    ///
    /// De réir an ghnáis, tuairisceáin `self.cmp(&other)` an ordú a thagann leis an abairt `self <operator> other` más fíor.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Gcomparáid agus tuairisceáin an t-uasmhéid de dá luach.
    ///
    /// Seoltar an dara argóint ar ais má chinneann an chomparáid go bhfuil siad comhionann.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Déan comparáid idir agus luach ar a laghad dhá luach.
    ///
    /// Seoltar an chéad argóint ar ais má chinneann an chomparáid go bhfuil siad comhionann.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Cuir srian ar luach go dtí eatramh áirithe.
    ///
    /// Tuairisceáin `max` má tá `self` níos mó ná `max`, agus `min` má tá `self` níos lú ná `min`.
    /// Seachas sin filleann sé seo `self`.
    ///
    /// # Panics
    ///
    /// Panics más `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// macra Díorthaigh ghiniúint impl an `Ord` trait.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait le haghaidh luachanna is féidir a chur i gcomparáid le haghaidh ord sórtála.
///
/// Caithfidh an chomparáid gach `a`, `b` agus `c` a shásamh:
///
/// - neamhshiméadracht: más rud é `a < b` ansin `!(a > b)`, chomh maith le `a > b` bheir `!(a < b)`;agus
/// - trasghníomhaíocht: Tugann `a < b` agus `b < c` le tuiscint `a < c`.Ní mór an rud céanna a bheith ag `==` agus `>` araon.
///
/// Tabhair faoi deara go gciallaíonn na ceanglais nach mór don trait féin a chur i bhfeidhm go siméadrach agus transitively: más rud é `T: PartialOrd<U>` agus `U: PartialOrd<V>` ansin `U: PartialOrd<T>` agus `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Is féidir an trait seo a úsáid le `#[derive]`.Nuair a dhíorthaíonn sé struchtúir, soláthróidh sé ordú foclóireachta bunaithe ar ordú dearbhaithe ó bhun go barr chomhaltaí an déanmhais.
/// Nuair `derive`d ar enums, leagan curtha in ord ag a n-barr-go-bun ord discriminant.
///
/// ## Conas is féidir liom a chur i bhfeidhm `PartialOrd`?
///
/// `PartialOrd` éilíonn ach cur i bhfeidhm an modh [`partial_cmp`], leis na daoine eile a ghintear ó implementations réamhshocraithe.
///
/// Mar sin féin is féidir na cinn eile a chur i bhfeidhm ar leithligh do chineálacha nach bhfuil ord iomlán acu.
/// Mar shampla, maidir le huimhreacha snámhphointe, `NaN < 0 == false` agus `NaN >= 0 == false` (cf.
/// IEEE 754-2008 roinn 5.11).
///
/// `PartialOrd` éilíonn gurb é [`PartialEq`] do chineál.
///
/// Caithfidh cur chun feidhme [`PartialEq`], `PartialOrd`, agus [`Ord`] * aontú lena chéile.
/// Is furasta iad a easaontú trí thimpiste trí chuid de na traits a dhíorthú agus cuid eile a chur i bhfeidhm de láimh.
///
/// Más [`Ord`] do chineál, is féidir leat [`partial_cmp`] a chur i bhfeidhm trí [`cmp`] a úsáid:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Is féidir go mbeidh freisin sé ina chuidiú a úsáid [`partial_cmp`] ar réimsí do chineál ar.
/// Seo sampla de chineálacha `Person` a bhfuil réimse snámhphointe `height` acu agus sin an t-aon réimse atá le húsáid le haghaidh sórtála:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Filleann an modh seo ordú idir luachanna `self` agus `other` má tá ceann ann.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Nuair nach féidir comparáid a dhéanamh:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Tástálann an modh seo níos lú ná (do `self` agus `other`) agus úsáideann an t-oibreoir `<` é.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Seo tástálacha modh níos lú ná nó cothrom le (do `self` agus `other`) agus úsáideann an t-oibreoir `<=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Tástálacha níos mó ná an modh seo (do `self` agus `other`) agus úsáideann an t-oibreoir `>` é.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Tástálacha an modh seo níos mó ná nó cothrom le (do `self` agus `other`) agus úsáideann an t-oibreoir `>=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// macra Díorthaigh ghiniúint impl an `PartialOrd` trait.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Déan comparáid idir agus luach ar a laghad dhá luach.
///
/// Seoltar an chéad argóint ar ais má chinneann an chomparáid go bhfuil siad comhionann.
///
/// Úsáidtear ailias go [`Ord::min`] go hinmheánach.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Filleann sé ar a laghad dhá luach maidir leis an bhfeidhm chomórtais shonraithe.
///
/// Seoltar an chéad argóint ar ais má chinneann an chomparáid go bhfuil siad comhionann.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Tuairisceáin an eilimint a thugann an luach minimum ón bhfeidhm atá sonraithe.
///
/// Seoltar an chéad argóint ar ais má chinneann an chomparáid go bhfuil siad comhionann.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Gcomparáid agus tuairisceáin an t-uasmhéid de dá luach.
///
/// Seoltar an dara argóint ar ais má chinneann an chomparáid go bhfuil siad comhionann.
///
/// Úsáidtear ailias go [`Ord::max`] go hinmheánach.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Tuairisceáin an t-uasmhéid de dhá luach maidir leis an bhfeidhm comparáide sonraithe.
///
/// Seoltar an dara argóint ar ais má chinneann an chomparáid go bhfuil siad comhionann.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Filleann sé an eilimint a thugann an luach is mó ón bhfeidhm shonraithe.
///
/// Seoltar an dara argóint ar ais má chinneann an chomparáid go bhfuil siad comhionann.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// PartialEq, Eq, PartialOrd agus Ord a chur i bhfeidhm do chineálacha primitive
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Tá an t-ordú anseo tábhachtach chun tionól níos fearr a ghiniúint.
                    // Féach <https://github.com/rust-lang/rust/issues/63758> le haghaidh tuilleadh eolais.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Réitigh le i8 agus athrú ar an difríocht le Ordú ghineann níos fearr is féidir tionól.
            //
            // Féach <https://github.com/rust-lang/rust/issues/66780> le haghaidh tuilleadh eolais.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // SÁBHÁILTEACHT: bool de réir mar a fhilleann i8 0 nó 1, mar sin ní féidir an difríocht a bheith mar rud ar bith eile
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &leideanna

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}