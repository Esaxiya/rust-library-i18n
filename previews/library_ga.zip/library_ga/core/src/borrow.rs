//! Modúl chun oibriú le sonraí a fuarthas ar iasacht.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait chun sonraí a fháil ar iasacht.
///
/// I Rust, is gnách uiríll éagsúla de chineál a sholáthar do chásanna úsáide éagsúla.
/// Mar shampla, is féidir suíomh stórála agus bainistíocht ar luach a roghnú go sonrach de réir mar is iomchuí le haghaidh úsáide áirithe trí chineálacha pointeora mar [`Box<T>`] nó [`Rc<T>`].
/// Taobh amuigh de na cumhdaigh chineálacha seo is féidir a úsáid le haon chineál, soláthraíonn roinnt cineálacha gnéithe roghnacha a sholáthraíonn feidhmiúlacht a d`fhéadfadh a bheith costasach.
/// Is sampla le haghaidh cineáil sórt [`String`] rud a chuireann an cumas a leathnú ar shraith don [`str`] bunúsach.
/// Éilíonn sé seo faisnéis bhreise a choinneáil gan ghá le haghaidh sreang shimplí dhochorraithe.
///
/// Soláthraíonn na cineálacha rochtain ar na sonraí bunúsacha trí tagairtí don gcineál sonraí sin.Deirtear go bhfuil siad `ar iasacht mar` an cineál sin.
/// Mar shampla, is féidir le [`Box<T>`] a fháil ar iasacht mar `T` agus is féidir le [`String`] a fháil ar iasacht mar `str`.
///
/// Cuireann cineálacha in iúl gur féidir iad a fháil ar iasacht mar chineál éigin `T` trí `Borrow<T>` a chur i bhfeidhm, ag soláthar tagairt do `T` i modh [`borrow`] trait.Tá cineál saor in aisce le fáil ar iasacht mar chineálacha éagsúla.
/// Má mian léi a fháil ar iasacht mutably mar chineál-trína bhféadfar na sonraí bunúsacha a mhodhnú, is féidir é a chur i bhfeidhm chomh maith [`BorrowMut<T>`].
///
/// Thairis sin, nuair a implementations foráil maidir le breis traits, ní mór é a chur san áireamh cé acu ba chóir iad féin a iompar comhionann leo sin de chineál is bun mar thoradh ar ag gníomhú mar léiriú den chineál is bun.
/// Is gnách go n-úsáideann cód cineálach `Borrow<T>` nuair a bhíonn sé ag brath ar iompar comhionann na gcur chun feidhme breise trait seo.
/// Is dóigh go mbeidh na traits seo le feiceáil mar trait bounds breise.
///
/// Go háirithe caithfidh `Eq`, `Ord` agus `Hash` a bheith coibhéiseach le luachanna a fuarthas ar iasacht agus faoi úinéireacht: ba cheart go dtabharfadh `x.borrow() == y.borrow()` an toradh céanna le `x == y`.
///
/// Mura gá ach cód cineálach a bheith ag obair do gach cineál ar féidir leis tagairt a dhéanamh do chineál gaolmhar `T`, is minic gur fearr [`AsRef<T>`] a úsáid mar is féidir le níos mó cineálacha é a chur i bhfeidhm go sábháilte.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Mar bailithe sonraí, úinéireacht [`HashMap<K, V>`] dá eochair agus luachanna.Má tá an eochair ar na sonraí iarbhír fillte i ndáil le cineál bainistíochta de chineál éigin, ba cheart, mar sin féin, fós go bhféadfaí a chuardach le haghaidh luach ag baint úsáide as, is tagairt í an eochair ar na sonraí.
/// Mar shampla, má tá an eochair teaghrán, ansin é a stóráil ar dóigh leis an léarscáil hash mar [`String`], agus ba cheart go mbeifí in ann cuardach a dhéanamh ag baint úsáide as [`&str`][`str`].
/// Mar sin, ní mór do `insert` oibriú ar `String` agus ní mór do `get` a bheith in ann `&str` a úsáid.
///
/// Beagán simplithe, is cosúil leis seo na codanna ábhartha de `HashMap<K, V>`:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // réimsí fágtha ar lár
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Tá an léarscáil hash ar fad cineálach thar chineál eochair `K`.Toisc go stóráiltear na heochracha seo leis an léarscáil hash, caithfidh sonraí an eochair a bheith ag an gcineál seo.
/// Nuair a chuirtear péire eochairluacha isteach, tugtar `K` den sórt sin ar an léarscáil agus ní mór dó an buicéad hash ceart a fháil agus seiceáil an bhfuil an eochair i láthair cheana féin bunaithe ar an `K` sin.Éilíonn sé `K: Hash + Eq` dá bhrí sin.
///
/// Agus luach ar an léarscáil á chuardach, áfach, chaithfeadh sé go mbeadh luach faoi úinéireacht den sórt sin á chruthú i gcónaí chun tagairt do `K` a sholáthar mar an eochair chun cuardach a dhéanamh.
/// Maidir le heochracha sreinge, chiallódh sé seo gur gá luach `String` a chruthú díreach chun cásanna a chuardach nach bhfuil ach `str` ar fáil.
///
/// Ina áit sin, is é an modh `get` cineálach thar an gcineál sonraí príomhghnéithe atá mar bhunús, ar a dtugtar `Q` sa síniú modh thuasluaite.Deir sé go borrows `K` mar `Q` trí éileamh go `K: Borrow<Q>`.
/// De réir chomh maith á cheangal `Q: Hash + Eq`, comharthaí sé an riachtanas go mbeadh `K` agus `Q` implementations na `Hash` agus `Eq` traits a tháirgeann torthaí comhionanna.
///
/// Tá cur chun feidhme `get` ag brath go háirithe ar chur chun feidhme comhionann `Hash` trí bhuicéad hash na heochrach a chinneadh trí ghlaoch a chur ar `Hash::hash` ar luach `Q` cé gur chuir sé an eochair isteach bunaithe ar an luach hash arna ríomh ón luach `K`.
///
///
/// Mar thoradh air sin, briseann an léarscáil hash má tháirgeann `K` ag timfhilleadh luach `Q` hash difriúil ná `Q`.Mar shampla, samhlaigh go bhfuil cineál agat a fillteann sreang ach a dhéanann comparáid idir litreacha ASCII agus neamhaird á dhéanamh acu ar a gcás:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Mar is gá dá luach comhionann chun teacht ar luach hash céanna, ní mór cur chun feidhme `Hash` neamhshuim a dhéanamh de chás ASCII, freisin:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// An féidir le `CaseInsensitiveString` `Borrow<str>` a chur i bhfeidhm?Is féidir é a chur ar fáil cinnte tagairt do slice teaghrán trína teaghrán úinéireacht atá.
/// Ach toisc go bhfuil a chur i bhfeidhm `Hash` difriúil, iompraíonn sé go difriúil ó `str` agus dá bhrí sin ní mór dó, i ndáiríre, `Borrow<str>` a chur i bhfeidhm.
/// Más mian leis rochtain a thabhairt do dhaoine eile ar an `str` bunúsach, féadfaidh sé é sin a dhéanamh trí `AsRef<str>` nach bhfuil aon cheanglais bhreise air.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Faightear iasachtaí ar luach dosheachanta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// A trait do mutably sonraí a fháil ar iasacht.
///
/// Mar chompánach le [`Borrow<T>`] ceadaíonn an trait seo cineál a fháil ar iasacht mar chineál bunúsach trí thagairt inathraithe a sholáthar.
/// Féach [`Borrow<T>`] chun tuilleadh faisnéise a fháil ar iasachtaí mar chineál eile.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Faightear iasachtaí ar iasacht ó luach faoi úinéireacht.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}