//! Luachanna Lazy agus initialization aon-uaire de shonraí statacha.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// Cill nach féidir a scríobh ach uair amháin.
///
/// Murab ionann agus `RefCell`, tá `OnceCell` amháin Soláthraíonn roinnte tagairtí `&T` a luach.
/// Murab ionann agus `Cell`, ní éilíonn `OnceCell` an luach a chóipeáil nó a athsholáthar chun rochtain a fháil air.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Invariant: scríofa chuige uair amháin ar a mhéad.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Cruthaíonn cill folamh nua.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Faigheann tú an tagairt don bhunluach.
    ///
    /// Filleann `None` má tá an cill folamh.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // SÁBHÁILTEACHT: Sábháilte mar gheall ar ionradh `istigh '
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Faigheann an tagairt mutable don luach bunúsach.
    ///
    /// Filleann `None` má tá an cill folamh.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // SÁBHÁILTEACHT: Sábháilte toisc go bhfuil rochtain uathúil againn
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Socraigh an t-ábhar na cille go `value`.
    ///
    /// # Errors
    ///
    /// Filleann an modh seo `Ok(())` má bhí an cill folamh agus `Err(value)` má bhí sí lán.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // SÁBHÁILTEACHT: Sábháilte ós rud é nach féidir linn a bheith forluí iasacht mutable
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // SÁBHÁILTEACHT: Is é seo an áit ach amháin i gcás ina a leag muid an sliotán, gan aon rásaí
        // de bharr reentrancy/concurrency is féidir, agus rinneamar seiceáil gur `None` an sliotán faoi láthair, mar sin coinníonn an scríbhinn seo invariant an `istigh '.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Faigheann ábhar na cille, ag tosú le `f` má bhí an cill folamh.
    ///
    /// # Panics
    ///
    /// Más rud é `f` panics, tá an panic iomadaíodh go dtí an té atá ag glaoch, agus tá sé fós an chill uninitialized.
    ///
    ///
    /// Is botún é an cill a thosú go reentrantly ó `f`.Sin a dhéanamh torthaí i panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Faigheann ábhar na cille, ag tosú le `f` má bhí an cill folamh.
    /// Má bhí an cill folamh agus má theip ar `f`, tugtar earráid ar ais.
    ///
    /// # Panics
    ///
    /// Más rud é `f` panics, tá an panic iomadaíodh go dtí an té atá ag glaoch, agus tá sé fós an chill uninitialized.
    ///
    ///
    /// Is botún é an cill a thosú go reentrantly ó `f`.Sin a dhéanamh torthaí i panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Tabhair faoi deara go bhféadfadh UB a bheith mar thoradh ar *roinnt* cineálacha tosaithe tosaigh reentrant (féach tástáil `reentrant_init`).
        // Creidim nach mbeadh sé ach an `assert` seo a bhaint, agus `set/get` a choinneáil slán, ach is cosúil gur fearr do panic, seachas seanluach a úsáid go ciúin.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Caitheann na cille, ag filleadh ar an luach fillte.
    ///
    /// Filleann `None` má bhí an cill folamh.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // Mar a thógann `into_inner` `self` de réir luacha, fhíoraíonn an Tiomsaitheoir statically nach bhfuil sé a fuarthas ar iasacht faoi láthair.
        // Mar sin tá sé sábháilte bogadh amach `Option<T>`.
        self.inner.into_inner()
    }

    /// Tógann sé an luach as an `OnceCell` seo, agus é a aistriú ar ais go stát neamhbheartaithe.
    ///
    /// Níl aon éifeacht leis agus filleann sé `None` mura bhfuil an `OnceCell` tosaithe.
    ///
    /// Ráthaítear sábháilteacht trí thagairt inathraithe a éileamh.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// A luach atá initialized ar an gcéad rochtana.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   réidh tosaigh
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Cruthaíonn sé luach leisciúil nua leis an bhfeidhm tosaigh a thugtar.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Fórsaí an meastóireacht ar an luach leisciúil agus tuairisceáin is tagairt í don toradh.
    ///
    ///
    /// Is ionann an impl `Deref`, ach tá follasach.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// Cruthaíonn sé luach leisciúil nua ag baint úsáide as `Default` mar an fheidhm tosaigh.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}