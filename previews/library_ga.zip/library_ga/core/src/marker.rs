//! Primitive traits agus cineálacha dhéanann ionadaíocht airíonna bunúsacha de chineálacha.
//!
//! Is féidir le cineálacha Rust a rangú ar bhealaí úsáideacha éagsúla de réir a n-airíonna intreacha.
//! Na haicmithe ionadaíocht mar traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Cineálacha is féidir a aistriú thar theorainneacha snáithe.
///
/// Seo trait bhfeidhm go huathoibríoch nuair a chinneann an tiomsaitheoir is cuí.
///
/// Is sampla de chineál neamh-`Send` an tagairt-comhaireamh pointeoir [`rc::Rc`][`Rc`].
/// Má dhéanann dhá shnáithe iarracht clónáil [`Rc`] s a dhíríonn ar an luach comhaireamh tagartha céanna, d`fhéadfadh go ndéanfaidís iarracht an comhaireamh tagartha a nuashonrú ag an am céanna, is é sin [undefined behavior][ub] toisc nach n-úsáideann [`Rc`] oibríochtaí adamhacha.
///
/// dhéanann é a col ceathrar [`sync::Arc`][arc] húsáid cheann hoibríochtaí adamhach (thabhú éigin forchostas) agus dá bhrí sin `Send`.
///
/// Féach [the Nomicon](../../nomicon/send-and-sync.html) le haghaidh tuilleadh sonraí.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Cineálacha le méid tairiseach ar a dtugtar ag am tiomsaithe.
///
/// Tá gach paraiméadair chineál ar intuigthe cheangal de `Sized`.Is féidir leis an error speisialta `?Sized` a úsáid a bhaint faoi cheangal más rud é nach bhfuil sé cuí.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//Earráid: Níl Mheánmhéide i bhfeidhm le haghaidh [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Is í an eisceacht amháin an intuigthe `Self` cineál a trait.
/// Níl `Sized` intuigthe faoi cheangal ag trait toisc nach bhfuil sé seo ag luí le [réad trait] nuair is gá, de réir sainmhínithe, an trait oibriú leis na feidhmitheoirí uile is féidir, agus dá bhrí sin d`fhéadfadh sé a bheith ar aon mhéid.
///
///
/// Cé go mbeidh Rust iúl ceangal tú `Sized` chuig trait, ní bheidh tú in ann é a úsáid chun foirm a rud trait níos déanaí:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // ligean y: &dyn Bar= &Impl;//Earráid: an `Bar` trait ní féidir é a dhéanamh isteach i réad
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // le haghaidh Réamhshocraithe, mar shampla, a éilíonn go mbeidh `[T]: !Default` in-mheasúnaithe
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Cineálacha féidir a "unsized" le cineál dinimiciúil-iarrachtaí.
///
/// Mar shampla, cuireann an cineál eagar meánmhéide `[i8; 2]` `Unsize<[i8]>` agus `Unsize<dyn fmt::Debug>` i bhfeidhm.
///
/// Soláthraíonn an tiomsaitheoir gach cur chun feidhme de `Unsize` go huathoibríoch.
///
/// `Unsize` i bhfeidhm le haghaidh:
///
/// - `[T; N]` Is `Unsize<[T]>`
/// - `T` is `Unsize<dyn Trait>` nuair `T: Trait`
/// - `Foo<..., T, ...>` an bhfuil `Unsize<Foo<..., U, ...>>` más rud é:
///   - `T: Unsize<U>`
///   - Is foo a struct
///   - Níl ach an réimse deireanach de `Foo` ag a bhfuil cineál a bhaineann le `T`
///   - `T` nach cuid de chineál aon réimsí eile é
///   - `Bar<T>: Unsize<Bar<U>>`, má tá an réimse deireanach de `Foo` `Bar<T>` chineál
///
/// `Unsize` úsáidtear in éineacht le [`ops::CoerceUnsized`] chun ligean do choimeádáin "user-defined" mar [`Rc`] cineálacha de mhéid dinimiciúil a bheith iontu.
/// Féach ar an [DST coercion RFC][RFC982] agus [the nomicon entry on coercion][nomicon-coerce] le haghaidh tuilleadh sonraí.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Ag teastáil trait do tairisigh a úsáidtear i matches patrún.
///
/// Aon chineál go gcuireann Bunaítear `PartialEq` huathoibríoch seo trait,*is cuma* ar cibé an dá chineál-paraiméadair a chur i bhfeidhm `Eq`.
///
/// Má tá cineál éigin i mír `const` nach gcuireann an trait seo i bhfeidhm, ansin ní chuireann an cineál sin (1.) `PartialEq` i bhfeidhm (rud a chiallaíonn nach soláthróidh an tairiseach an modh comparáide sin, a nglacann giniúint cód leis go bhfuil sé ar fáil), nó (2.) a chuireann sé i bhfeidhm *a chuid féin* leagan de `PartialEq` (glacaimid leis nach gcomhlíonann comparáid struchtúrtha-chomhionannais).
///
///
/// I gceachtar den dá chás thuas, diúltaímid úsáid den sórt sin tairiseach i gcluiche patrún.
///
/// Féach freisin ar an [structural match RFC][RFC1445], agus [issue 63438] a Aistriú spreagtha ó dearadh tréith-bhunaithe leis an trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Ag teastáil trait do tairisigh a úsáidtear i matches patrún.
///
/// Aon chineál go gcuireann Bunaítear `Eq` huathoibríoch seo trait,*is cuma* cé acu a paraiméadair chineál a chur i bhfeidhm `Eq`.
///
/// Is hack é seo chun oibriú timpeall ar theorannú inár gcóras cineáil.
///
/// # Background
///
/// Is mian linn a cheangal go bhfuil na cineálacha consts úsáidtear i gcluichí patrún an tréith `#[derive(PartialEq, Eq)]`.
///
/// I saol níos fearr, d'fhéadfadh muid a seiceáil an ceanglas sin ag díreach sheiceáil go bhfuil an uirlisí chineál a tugadh dá an `StructuralPartialEq` trait *agus* an trait `Eq`.
/// Mar sin féin, is féidir leat ADTanna a bheith agat a dhéanann * `derive(PartialEq, Eq)`, agus a bheith ina chás gur mhaith linn go nglacfadh an tiomsaitheoir leis, ach fós féin ní mhainníonn cineál an tairiseach `Eq` a chur i bhfeidhm.
///
/// Eadhon, cás mar seo:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Is í an fhadhb sa chód thuas ná nach gcuireann `Wrap<fn(&())>` `PartialEq`, ná `Eq` i bhfeidhm, mar gheall ar `for <'a> fn(&'a _)` does not implement those traits.)
///
/// Dá bhrí sin, ní féidir linn brath ar sheiceáil naive do `StructuralPartialEq` agus `Eq` amháin.
///
/// Mar hack an obair thart ar an, úsáidimid beirt traits leith ghann ag gach ceann den dá dhíorthaigh (`#[derive(PartialEq)]` agus `#[derive(Eq)]`) agus seiceáil go bhfuil an dá cheann acu i láthair mar chuid den seiceáil struchtúrtha-chluiche.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Cineálacha ar féidir a luachanna a mhacasamhlú go simplí trí ghiotáin a chóipeáil.
///
/// De réir réamhshocraithe, tá ceangail athraitheach 'semantics gluaiseacht.'I bhfocail eile:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` tar éis bogadh `y` isteach, agus ní féidir sin a úsáid a
///
/// // println ("{: ?}", x)!;//earráid: luach bogtha a úsáid
/// ```
///
/// Mar sin féin, más rud é i ndáil le cineál uirlisí `Copy`, tá sé ina ionad sin 'semantics cóip':
///
/// ```
/// // Is féidir linn a dhíorthú chun feidhme `Copy`.
/// // `Clone` ag teastáil freisin, toisc gur supertrait de `Copy` atá ann.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` Is cóip de `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Tá sé tábhachtach a thabhairt faoi deara gurb é an t-aon difríocht sa dá shampla seo ná an bhfuil cead agat rochtain a fháil ar `x` tar éis an taisc.
/// Faoi na cochall, is féidir an dá cóip agus bogadh mar thoradh giotán á chóipeáil i gcuimhne, cé go bhfuil sé seo optamaithe uaireanta away.
///
/// ## Conas is féidir liom a chur i bhfeidhm `Copy`?
///
/// Tá dhá bhealach ann chun `Copy` a chur i bhfeidhm ar do chineál.Is é an ceann is simplí `derive` a úsáid:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Is féidir leat a chur i bhfeidhm freisin `Copy` agus `Clone` láimh:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Tá difríocht bheag idir an dá cheann: cuirfidh straitéis `derive` `Copy` faoi cheangal ar pharaiméadair chineáil, rud nach dteastaíonn i gcónaí.
///
/// ## Cad é an difríocht idir `Copy` agus `Clone`?
///
/// Cóipeanna a tharlóidh go hintuigthe, mar shampla mar chuid de thasc `y = x`.Níl an iompar de `Copy` overloadable;is cóip shimplí ciallmhar í i gcónaí.
///
/// Is chlónáil caingean follasach, `x.clone()`.Féadann cur i bhfeidhm [`Clone`] aon iompar a bhaineann go sonrach le cineál a sholáthar atá riachtanach chun luachanna a mhacasamhlú go sábháilte.
/// Mar shampla, ní mór cur chun feidhme [`Clone`] do [`String`] a chóipeáil an-go Léirigh teaghrán Maolán i gcarn.
/// Bheadh cóip bitwise simplí de luachanna [`String`] cóip ach an pointeoir, as a dtiocfaidh saor in aisce ar dúbailte síos ar an líne.
/// Ar an ábhar sin, tá [`String`] [`Clone`] ach ní `Copy`.
///
/// [`Clone`] is supertrait de `Copy` é, mar sin caithfidh gach rud atá `Copy` [`Clone`] a chur i bhfeidhm freisin.
/// Má tá cineál `Copy` ansin ní mór a chur i bhfeidhm [`Clone`] amháin a thabhairt ar ais `*self` (féach an sampla thuas).
///
/// ## Cathain is féidir mo chineál a bheith `Copy`?
///
/// Is féidir le cineál `Copy` a chur i bhfeidhm más rud é gach ceann dá chomhpháirteanna a chur i bhfeidhm `Copy`.Mar shampla, is féidir é seo struct a `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Is féidir le struct a `Copy`, agus tá [`i32`] `Copy`, dá bhrí sin, tá `Point` incháilithe le bheith `Copy`.
/// Gcodarsnacht leis sin, mheas
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Ní féidir leis an `PointList` struct i bhfeidhm `Copy`, toisc nach bhfuil [`Vec<T>`] `Copy`.Má tá muid a iarracht a dhíorthú i bhfeidhm `Copy`, beidh orainn a fháil earráid:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Tá tagairtí Roinnte (`&T`) freisin `Copy`, ionas gur féidir le cineál a `Copy`, fiú amháin nuair a seilbh sé tagairtí de chineálacha `T` go bhfuil *nach*`Copy` roinnte.
/// Smaoinigh ar an struct leanas, is féidir a chur i bhfeidhm `Copy`, toisc go bhfuil sé ach *tagairt roinnte* go dtí ár chineál neamh-`Copy` `PointList` ó thuas:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Nuair nach féidir * mo chineál a bheith `Copy`?
///
/// Ní féidir le roinnt cineálacha a chóipeáil go sábháilte.Mar shampla, chruthódh cóipeáil `&mut T` tagairt neamh-inathraithe ailiasach.
/// Dhéanfadh cóipeáil [`String`] an fhreagracht as an maolán [`Teaghrán]] a bhainistiú, rud a fhágfadh go mbeadh saor in aisce dúbailte.
///
/// Generalizing chás deiridh, ní féidir aon chineál cur chun feidhme [`Drop`] a `Copy`, mar tá sé acmhainn éigin a bhainistiú sa bhreis bytes a [`size_of::<T>`] féin.
///
/// Má dhéanann tú iarracht `Copy` a chur i bhfeidhm ar struchtúr nó ar enum ina bhfuil sonraí neamh-`Copy`, gheobhaidh tú an earráid [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Cathain *ar chóir* mo chineál a bheith `Copy`?
///
/// Go ginearálta, má do chineál _can_ a chur i bhfeidhm `Copy`, ba chóir dó.
/// Coinnigh i gcuimhne, áfach, go bhfuil a chur i bhfeidhm `Copy` mar chuid den API poiblí do chineál.
/// Más rud é go bhféadfadh an cineál a bheith neamh-`Copy` sa future, d'fhéadfadh sé a bheith ciallmhar an cur chun feidhme `Copy` a fhágáil ar lár anois, chun athrú briseadh API a sheachaint.
///
/// ## Feidhmitheoirí breise
///
/// Chomh maith leis an [implementors listed below][impls], na cineálacha seo a leanas a chur i bhfeidhm freisin `Copy`:
///
/// * Cineálacha míreanna feidhme (ie, na cineálacha ar leith atá sainithe do gach feidhm)
/// * Cineálacha Feidhm Pointeoir (m.sh., `fn() -> i32`)
/// * Cineálacha eagar, do gach méid, má chuireann an cineál earra `Copy` i bhfeidhm freisin (m.sh., `[i32; 123456]`)
/// * Cineálacha dúblacha, má chuireann gach comhpháirt `Copy` i bhfeidhm freisin (m.sh., `()`, `(i32, bool)`)
/// * Cineálacha Dúnta, má tá siad a ghabháil aon luach as an timpeallacht nó má luachanna a gabhadh sórt a chur i bhfeidhm `Copy` féin.
///   Tabhair faoi deara go bhfuil athróg a gabhadh faoi threoir roinnte a chur i bhfeidhm i gcónaí `Copy` (fiú amháin más rud é nach bhfuil an tagraí), agus athróga a gabhadh trí thagairt mutable riamh a chur i bhfeidhm `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Ligeann sé seo chóipeáil le cineál nach bhfuil a chuireann i bhfeidhm `Copy` agat mar gheall bounds feadh an tsaoil gan sásamh (chóipeáil `A<'_>` nuair ach `A<'static>: Copy` agus `A<'_>: Clone`).
// Tá an tréith anseo le haghaidh anois amháin toisc go bhfuil go leor le roinnt speisialtóireachtaí atá ann cheana maidir `Copy` atá ann cheana féin sa leabharlann caighdeánach, agus níl aon bhealach a bheith acu go sábháilte leis an iompar ceart anois.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// macra Díorthaigh ghiniúint impl an `Copy` trait.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Cineálacha a bhfuil sé sábháilte tagairtí dóibh a roinnt idir snáitheanna.
///
/// Seo trait bhfeidhm go huathoibríoch nuair a chinneann an tiomsaitheoir is cuí.
///
/// Is é an sainmhíniú beacht: Is le cineál `T` [`Sync`] más gá agus más é `&T` [`Send`].
/// Is é sin le rá, mura bhfuil aon fhéidearthacht ann [undefined behavior][ub] (rásaí sonraí san áireamh) agus tagairtí `&T` á rith idir snáitheanna.
///
/// Mar a bheifí ag súil, tá cineálacha primitive cosúil [`u8`] agus [`f64`] uile [`Sync`], agus mar sin tá cineálacha comhiomlán simplí ina bhfuil siad, ar nós tuples, structs agus enums.
/// I measc níos shamplaí de chineál bhunúsacha [`Sync`] Cineálacha "immutable" cosúil `&T`, agus iad siúd a bhfuil simplí oidhreacht mutability, ar nós [`Box<T>`][box], [`Vec<T>`][vec] agus an chuid is mó cineálacha bailiúcháin eile.
///
/// (Ní mór paraiméadair chineálacha a bheith [`Sync`] chun a gcoimeádán a bheith [`Sync`].)
///
/// Toradh beag iontais ar an sainmhíniú is ea gur `Sync` é `&mut T` (más `Sync` é `Sync`) cé gur cosúil go bhféadfadh sé sóchán neamhshioncronaithe a sholáthar.
/// Is é an cleas ná go mbeidh tagairt inathraithe taobh thiar de thagairt roinnte (is é sin, `& &mut T`) inléite amháin, amhail is gur `& &T` a bhí ann.
/// Mar sin, níl aon bhaol ann rás sonraí.
///
/// Cineálacha nach bhfuil `Sync` iad siúd a bhfuil "interior mutability" i bhfoirm neamh-snáithe-sábháilte, ar nós [`Cell`][cell] agus [`RefCell`][refcell].
/// Na cineálacha a cheadú le haghaidh claochlú a bhfuil iontu, fiú trí immutable, tagairt roinnte.
/// Mar shampla, glacann an modh `set` ar [`Cell<T>`][cell] `&self`, agus mar sin éilíonn sé ach tagairt roinnte [`&Cell<T>`][cell].
/// Na fheidhmíonn modh ar bith sioncrónaithe, dá bhrí sin ní féidir [`Cell`][cell] a `Sync`.
///
/// Sampla eile de chineál neamh-`Sync` is ea an pointeoir comhaireamh tagartha [`Rc`][rc].
/// Mar gheall ar aon tagairt [`&Rc<T>`][rc], is féidir leat a Clón [`Rc<T>`][rc] nua, lena modhnaítear an comhaireamh tagartha ar bhealach neamh-adamhach.
///
/// Maidir le cásanna nuair a dhéanann duine gá snáithe-sábháilte mutability istigh, cuireann Rust [atomic data types], chomh maith le Glasáil follasach via [`sync::Mutex`][mutex] agus [`sync::RwLock`][rwlock].
/// Cinntíonn na cineálacha seo nach féidir le haon sóchán rásaí sonraí a chur faoi deara, dá bhrí sin is iad na cineálacha `Sync`.
/// Mar an gcéanna, cuireann [`sync::Arc`][arc] analóg snáithe-sábháilte [`Rc`][rc].
///
/// Ní mór aon chineál a bhfuil mutability istigh a úsáid freisin an fillteán [`cell::UnsafeCell`][unsafecell] fud an value(s) is féidir a mutated trí thagairt roinnte.
/// Is Má theipeann ar seo a dhéanamh [undefined behavior][ub].
/// Mar shampla, [`transmute`][transmute]-áirítear ó `&T` go `&mut T` Is neamhbhailí.
///
/// Féach [the Nomicon][nomicon-send-and-sync] le haghaidh tuilleadh sonraí faoi `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): uair amháin tacaíocht a thabhairt nótaí a chur in tailte `rustc_on_unimplemented` i beta, agus tá sé leathnaithe chun seiceáil an bhfuil dúnadh áit ar bith sa slabhra cheanglas, shíneadh mar (#48534) ar nós:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Zero-iarrachtaí chineál a úsáidtear chun rudaí a "act like" siad féin `T` marcáil.
///
/// Nuair a chuirfear ar réimse `PhantomData<T>` do chineál Insíonn an Tiomsaitheoir agus feidhmeoidh sé do chineál amhail is dá mbeadh siopaí sé ina luach den chineál `T`, cé nach ndéanann sé i ndáiríre.
/// Úsáidtear an fhaisnéis nuair ríomh airíonna sábháilteachta áirithe.
///
/// Le míniú níos doimhne a fháil ar conas `PhantomData<T>` a úsáid, féach [the Nomicon](../../nomicon/phantom-data.html) le do thoil.
///
/// # Nóta ghastly 👻👻👻
///
/// Cé go bhfuil siad an dá ainmneacha scary, `PhantomData` agus 'cineálacha Phantom' a bhaineann, ach níorbh ionann.Is éard atá i bparaiméadar cineál phantóm ach paraiméadar cineáil nach n-úsáidtear riamh.
/// I Rust, is minic a bhíonn sé seo ina chúis leis an tiomsaitheoir gearán a dhéanamh, agus is é an réiteach ná úsáid "dummy" a chur leis trí `PhantomData`.
///
/// # Examples
///
/// ## Paraiméadair saoil neamhúsáidte
///
/// B`fhéidir gurb é an cás úsáide is coitianta le haghaidh `PhantomData` ná struchtúr a bhfuil paraiméadar saoil neamhúsáidte aige, go hiondúil mar chuid de roinnt cód neamhshábháilte.
/// Mar shampla, seo struchtúr `Slice` a bhfuil dhá threo de chineál `*const T` ann, agus is dócha go bhfuil sé dírithe ar eagar áit éigin:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Tá sé i gceist go bhfuil na sonraí bunúsacha bailí ach amháin do thréimhse `'a`, mar sin ba chóir `Slice` ní outlive `'a`.
/// Mar sin féin, ní chuirtear an rún seo in iúl sa chód, ós rud é nach n-úsáidtear an `'a` ar feadh an tsaoil agus mar sin níl sé soiléir cad iad na sonraí lena mbaineann sé.
/// Is féidir linn a cheartú seo trí insint an Tiomsaitheoir a bheith ag gníomhú *amhail is dá mba* atá an struct `Slice` tagairt `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Éilíonn sé seo freisin an nóta `T: 'a`, rud a léiríonn go bhfuil aon tagairtí in `T` bailí thar shaolré `'a`.
///
/// Agus `Slice` á thionscnamh agat ní sholáthraíonn tú ach an luach `PhantomData` don réimse `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Paraiméadair chineál nach úsáidtear
///
/// Tarlaíonn sé uaireanta go bhfuil tú paraiméadair de chineál nach bhfuil in úsáid a léiríonn cén cineál na sonraí is struct "tied" go, cé nach bhfuil na sonraí le fáil i ndáiríre sa struct féin.
/// Seo sampla nuair a thagann sé seo le [FFI].
/// Na húsáidí comhéadan eachtrach Láimhseálann den chineál `*mut ()` chun tagairt a dhéanamh luachanna Rust de chineálacha éagsúla.
/// rian muid an cineál Rust trí pharaiméadar de chineál phantom ar an struct `ExternalResource` a wraps a láimhseáil.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Úinéireacht agus an seic titim
///
/// Nuair a chuirtear réimse de chineál `PhantomData<T>` leis, tugtar le fios go bhfuil sonraí de chineál `T` ag do chineál.Tugann sé seo le tuiscint, ar a uain, go dtitfidh sé cás amháin nó níos mó den chineál `T` nuair a thitfear do chineál.
/// Tá an tionchar ar an tiomsaitheoir Rust anailís [drop check].
///
/// Más rud é nach bhfuil do struct i ndáiríre *féin* na sonraí den chineál `T`, tá sé níos fearr a úsáid le cineál tagartha, cosúil le `PhantomData<&'a T>` (ideally) nó `PhantomData<*const T>` (má tá feidhm ag aon ré feidhme), ionas nach úinéireacht a chur in iúl.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Tiomsaitheoir-inmheánach trait úsáidtear lena thaispeáint cén cineál discriminants Áirithe.
///
/// Cuirtear an trait seo i bhfeidhm go huathoibríoch do gach cineál agus ní chuireann sé aon ráthaíochtaí le [`mem::Discriminant`].
/// Is iompraíocht undefined ** ** a transmute idir `DiscriminantKind::Discriminant` agus `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// An cineál na discriminant, ní mór don bounds trait a shásamh a éilíonn `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Tiomsaitheoir-inmheánach trait fhonn a chinneadh an bhfuil cineál ar bith `UnsafeCell` hinmheánach, ach ní trí indirection.
///
/// Bíonn tionchar aige seo, mar shampla, ar cibé an gcuirtear `static` den chineál sin i gcuimhne statach inléite amháin nó i gcuimhne statach inscríofa.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Cineálacha is féidir a bhogadh go sábháilte tar éis a bheith pinned.
///
/// Rust féin nach bhfuil aon coincheap de chineálacha dochorraithe, agus go measann bogann (eg, trí shannadh nó [`mem::replace`]) a bheith i gcónaí sábháilte.
///
/// Is é an cineál [`Pin`][Pin] úsáid in áit chun bogann tríd an gcóras cineál chosc.Leideanna `P<T>` fillte sa [`Pin<P<T>>`][Pin] Ní féidir fillteán a bhogadh amach as.
/// Féach ar dhoiciméadú [`pin` module] le haghaidh tuilleadh eolais a fháil maidir le pinning.
///
/// Cur i bhfeidhm na trait `Unpin` don `T` ardaitheoirí an srianta ar pinning as an gcineál, a chuireann ar chumas ansin ag bogadh `T` as [`Pin<P<T>>`][Pin] le feidhmeanna ar nós [`mem::replace`].
///
///
/// `Unpin` níl aon iarmhairt ar chor ar bith ag sonraí neamh-phinn.
/// Go háirithe, [`mem::replace`] sona sásta bogann sonraí `!Unpin` (oibríonn sé le haghaidh aon `&mut T`, ní hamháin nuair `T: Unpin`).
/// Ní féidir leat [`mem::replace`] a úsáid, áfach, ar shonraí atá fillte taobh istigh de [`Pin<P<T>>`][Pin] toisc nach féidir leat an `&mut T` a theastaíonn uait chuige sin a fháil, agus *sin* an rud a fhágann go n-oibríonn an córas seo.
///
/// Mar sin ní féidir é seo a dhéanamh, mar shampla, ach ar chineálacha a chuireann `Unpin` i bhfeidhm:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Teastaíonn tagairt inathraithe uainn chun `mem::replace` a ghlaoch.
/// // Is féidir linn tagairt den sórt sin a fháil trí (implicitly) ag agairt `Pin::deref_mut`, ach ní féidir é sin a dhéanamh ach toisc go gcuireann `String` `Unpin` i bhfeidhm.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Seo trait bhfeidhm go huathoibríoch le haghaidh beagnach gach cineál.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Cineál marcóra nach gcuireann `Unpin` i bhfeidhm.
///
/// Má tá `PhantomPinned` i gcineál, ní chuirfidh sé `Unpin` i bhfeidhm de réir réamhshocraithe.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// `Copy` a chur i bhfeidhm do chineálacha primitive.
///
/// Implementations nach féidir a cur síos air i Rust i bhfeidhm i `traits::SelectionContext::copy_clone_conditions()` i `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Is féidir tagairtí roinnte a chóipeáil, ach ní féidir tagairtí inathraithe * a dhéanamh!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}