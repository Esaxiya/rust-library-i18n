#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// Ligeann `RawWaker` d`fheidhmitheoir seiceadóra tascanna [`Waker`] a chruthú a sholáthraíonn iompar saincheaptha dúisithe.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Is éard atá ann pointeoir sonraí agus [virtual function pointer table (vtable)][vtable] a shaincheapann iompar an `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// A pointeoir sonraí, is féidir a úsáid chun a stóráil na sonraí treallach mar a éilíonn an seiceadóir.
    /// D`fhéadfadh sé seo a bheith m.sh.
    /// pointeoir scriosta de chineál ar `Arc` a bhfuil baint aige leis an tasc.
    /// Cuirtear luach an réimse seo ar aghaidh chuig na feidhmeanna go léir atá mar chuid den inmharthana mar an chéad pharaiméadar.
    ///
    data: *const (),
    /// Tábla pointeoir feidhm fhíorúil a shaincheapann iompar an chaiteora seo.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Cruthaigh `RawWaker` nua ón pointeoir `data` fáil agus `vtable`.
    ///
    /// Is féidir leis an pointeoir `data` a úsáid chun a stóráil na sonraí treallach mar a éilíonn an seiceadóir.D`fhéadfadh sé seo a bheith m.sh.
    /// pointeoir scriosta de chineál ar `Arc` a bhfuil baint aige leis an tasc.
    /// Tabharfar luach an phointeora seo do gach feidhm atá mar chuid den `vtable` mar an chéad pharaiméadar.
    ///
    /// Saincheapann an `vtable` iompar `Waker` a chruthaítear ó `RawWaker`.
    /// I gcás gach oibríochta ar an `Waker`, tabharfar an fheidhm ghaolmhar sa `vtable` den `RawWaker` bunúsach.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Tábla pointeoir feidhm fhíorúil (vtable) a shonraíonn iompar [`RawWaker`].
///
/// Is é an pointeoir a aistrítear chuig na feidhmeanna go léir taobh istigh den vtable an pointeoir `data` ón réad [`RawWaker`] atá faoi iamh.
///
/// Níl sé i gceist ach na feidhmeanna taobh istigh den déanmhas seo a ghlaoch ar phointeoir `data` de réad [`RawWaker`] a tógadh i gceart ón taobh istigh de chur i bhfeidhm [`RawWaker`].
/// Má ghlaotar ar cheann de na feidhmeanna atá ann agus aon phointeoir `data` eile á úsáid, beidh iompar neamhshainithe ann.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Glaofar an fheidhm seo nuair a chlónálfar an [`RawWaker`], m.sh. nuair a chlónáiltear an [`Waker`] ina stóráiltear an [`RawWaker`].
    ///
    /// Caithfidh cur i bhfeidhm na feidhme seo na hacmhainní go léir a theastaíonn don chás breise seo de [`RawWaker`] agus tasc gaolmhar a choinneáil.
    /// Má ghlaotar `wake` ar an [`RawWaker`] mar thoradh air, ba cheart go dtiocfadh múscailt faoin tasc céanna a dhúisigh an [`RawWaker`] bunaidh.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Glaofar an fheidhm seo nuair a ghlaofar `wake` ar an [`Waker`].
    /// Caithfidh sé an tasc a bhaineann leis an [`RawWaker`] seo a mhúscailt.
    ///
    /// Caithfidh cur i bhfeidhm na feidhme seo a dhéanamh cinnte go scaoilfear saor aon acmhainní a bhfuil baint acu leis an gcás seo de [`RawWaker`] agus tasc gaolmhar.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Glaofar an fheidhm seo nuair a ghlaofar `wake_by_ref` ar an [`Waker`].
    /// Caithfidh sé an tasc a bhaineann leis an [`RawWaker`] seo a mhúscailt.
    ///
    /// Tá an fheidhm seo cosúil le `wake`, ach níor cheart di an pointeoir sonraí a sholáthraítear a ithe.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Glaoitear an fheidhm seo nuair a thittear [`RawWaker`].
    ///
    /// Caithfidh cur i bhfeidhm na feidhme seo a dhéanamh cinnte go scaoilfear saor aon acmhainní a bhfuil baint acu leis an gcás seo de [`RawWaker`] agus tasc gaolmhar.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Cruthaíonn sé `RawWakerVTable` nua ó na feidhmeanna `clone`, `wake`, `wake_by_ref`, agus `drop` a cuireadh ar fáil.
    ///
    /// # `clone`
    ///
    /// Glaofar an fheidhm seo nuair a chlónálfar an [`RawWaker`], m.sh. nuair a chlónáiltear an [`Waker`] ina stóráiltear an [`RawWaker`].
    ///
    /// Caithfidh cur i bhfeidhm na feidhme seo na hacmhainní go léir a theastaíonn don chás breise seo de [`RawWaker`] agus tasc gaolmhar a choinneáil.
    /// Má ghlaotar `wake` ar an [`RawWaker`] mar thoradh air, ba cheart go dtiocfadh múscailt faoin tasc céanna a dhúisigh an [`RawWaker`] bunaidh.
    ///
    /// # `wake`
    ///
    /// Glaofar an fheidhm seo nuair a ghlaofar `wake` ar an [`Waker`].
    /// Caithfidh sé an tasc a bhaineann leis an [`RawWaker`] seo a mhúscailt.
    ///
    /// Caithfidh cur i bhfeidhm na feidhme seo a dhéanamh cinnte go scaoilfear saor aon acmhainní a bhfuil baint acu leis an gcás seo de [`RawWaker`] agus tasc gaolmhar.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Glaofar an fheidhm seo nuair a ghlaofar `wake_by_ref` ar an [`Waker`].
    /// Caithfidh sé an tasc a bhaineann leis an [`RawWaker`] seo a mhúscailt.
    ///
    /// Tá an fheidhm seo cosúil le `wake`, ach níor cheart di an pointeoir sonraí a sholáthraítear a ithe.
    ///
    /// # `drop`
    ///
    /// Glaoitear an fheidhm seo nuair a thittear [`RawWaker`].
    ///
    /// Caithfidh cur i bhfeidhm na feidhme seo a dhéanamh cinnte go scaoilfear saor aon acmhainní a bhfuil baint acu leis an gcás seo de [`RawWaker`] agus tasc gaolmhar.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// An `Context` de thasc neamhshioncronach.
///
/// Faoi láthair, `Context` feidhmíonn sé ach amháin le rochtain a chur ar fáil ar `&Waker` féidir a úsáid a osclaíonn an tasc atá ann faoi láthair.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // A chinntiú táimid ag future-cruthúnas i gcoinne athruithe athraitheas ag forcing saolré a bheith athraitheach (Tá saoil argóint-phost contravariant cé go bhfuil saoil ais-phost inmhalartaithe).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Cruthaigh `Context` nua ó `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Filleann tagairt don `Waker` don tasc reatha.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// Is éard atá i `Waker` láimhseáil chun tasc a mhúscailt trí chur in iúl dá sheiceadóir go bhfuil sé réidh le rith.
///
/// Cuimsíonn an láimhseáil seo sampla [`RawWaker`], a shainmhíníonn an t-iompar múscailte a bhaineann go sonrach le seiceadóir.
///
///
/// Cuireann [`Clone`], [`Send`], agus [`Sync`] i bhfeidhm.
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Múscail an tasc a bhaineann leis an `Waker` seo.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Déantar an glao múscailte iarbhír a tharmligean trí ghlao feidhm fhíorúil chuig an gcur i bhfeidhm atá sainithe ag an seiceadóir.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Ná glaoigh `drop`-beidh an t-Waker a chaitheamh ag `wake`.
        crate::mem::forget(self);

        // SÁBHÁILTEACHT: Tá sé seo sábháilte mar is é `Waker::from_raw` an t-aon bhealach
        // chun `wake` agus `data` a thionscnamh á cheangal ar an úsáideoir a admháil go seasfar le conradh `RawWaker`.
        //
        unsafe { (wake)(data) };
    }

    /// Múscail an tasc a bhaineann leis an `Waker` seo gan an `Waker` a ithe.
    ///
    /// Tá sé seo cosúil leis `wake`, ach d'fhéadfadh a bheith beagán níos lú éifeachtach i gcás ina bhfuil `Waker` úinéireacht ar fáil.
    /// B`fhearr an modh seo ná `waker.clone().wake()` a ghlaoch.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Déantar an glao múscailte iarbhír a tharmligean trí ghlao feidhm fhíorúil chuig an gcur i bhfeidhm atá sainithe ag an seiceadóir.
        //

        // SÁBHÁILTEACHT: féach `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Tuairisceáin `true` má dhúisigh an `Waker` seo agus `Waker` eile an tasc céanna.
    ///
    /// Oibríonn an fheidhm seo ar bhonn na hiarrachta is fearr, agus d`fhéadfadh sí filleadh bréagach fiú nuair a mhúsclódh na`Waker 'an tasc céanna.
    /// Má fhilleann an fheidhm seo `true`, áfach, ráthaítear go ndúisíonn na `Waker 'an tasc céanna.
    ///
    /// Úsáidtear an fheidhm seo go príomha chun críocha optamaithe.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Cruthaíonn `Waker` nua ó [`RawWaker`].
    ///
    /// Ní dhéantar iompar an `Waker` a cuireadh ar ais a shainiú mura seasfar leis an gconradh a shainmhínítear i gcáipéisíocht [`RawWaker`] agus [`RawWakerVTable`].
    ///
    /// Dá bhrí sin tá an modh seo neamhshábháilte.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SÁBHÁILTEACHT: Tá sé seo sábháilte mar is é `Waker::from_raw` an t-aon bhealach
            // chun `clone` agus `data` a thionscnamh á cheangal ar an úsáideoir a admháil go seasfar le conradh [`RawWaker`].
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SÁBHÁILTEACHT: Tá sé seo sábháilte mar is é `Waker::from_raw` an t-aon bhealach
        // chun `drop` agus `data` a thionscnamh á cheangal ar an úsáideoir a admháil go seasfar le conradh `RawWaker`.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}