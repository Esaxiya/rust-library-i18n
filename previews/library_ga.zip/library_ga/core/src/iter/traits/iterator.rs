// neamhaird-slachtmhar-filelength Is éard atá sa chomhad seo go heisiach an sainmhíniú ar `Iterator`.
// Ní féidir linn a scoilt go isteach i gcomhaid il.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Comhéadan chun déileáil le iteoirí.
///
/// Is é seo an príomh-iterator trait.
/// Le haghaidh níos mó faoi an coincheap de Iterators gcoitinne, féach an [module-level documentation].
/// Go háirithe, b`fhéidir gur mhaith leat a fháil amach conas [implement `Iterator`][impl] a dhéanamh.
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// An cineál na n-eilimintí atá á athluaigh os a chionn.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Airleacain an iterator agus tuairisceáin an luach seo chugainn.
    ///
    /// Filleann [`None`] nuair a bhíonn an t-atriall críochnaithe.
    /// D`fhéadfadh sé go roghnódh feidhmiúcháin iteora aonair atriall a atosú, agus mar sin d`fhéadfadh sé nach dtosódh `next()` ag filleadh [`Some(Item)`] arís ag pointe éigin.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Filleann glao ar next() an chéad luach eile ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... agus ansin Ceann ar bith nuair a bheidh sé críochnaithe.
    /// assert_eq!(None, iter.next());
    ///
    /// // Is féidir níos mó glaonna nó nach féidir ar ais `None`.Anseo, beidh siad i gcónaí.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Tuairisceáin an bounds ar fhad eile den iterator.
    ///
    /// Go sonrach, tuairisceáin `size_hint()` tuple sa chás go bhfuil an chéad eilimint is ísle faoi cheangal, agus is é an dara gné an cheangal uachtair.
    ///
    /// Is é an dara leath den tuple atá ar ais ar [`Option`]`<`[`usize`] `>`.
    /// Ciallaíonn [`None`] anseo nach bhfuil aon cheangal uachtarach ar eolas, nó go bhfuil an teorainn uachtarach níos mó ná [`usize`].
    ///
    /// # Nótaí cur chun feidhme
    ///
    /// Ní chuirtear i bhfeidhm go mbíonn líon dearbhaithe eilimintí mar thoradh ar chur chun feidhme iteora.A Buggy Is féidir iterator teacht isteach níos lú ná an luach is ísle faoi cheangal nó níos mó ná an cheangal uachtair na n-eilimintí.
    ///
    /// `size_hint()` tá sé beartaithe go príomha go n-úsáidfear é le haghaidh barrfheabhsúcháin ar nós spás a chur in áirithe d`eilimintí an iteora, ach ní gá muinín a bheith agat astu eg seiceálacha teorainneacha i gcód neamhshábháilte a fhágáil ar lár.
    /// Níor cheart cur i bhfeidhm mícheart de `size_hint()` mar thoradh ar sáruithe sábháilteachta chuimhne.
    ///
    /// É sin ráite, ba cheart cur chun feidhme a chur ar fáil meastachán ceart, mar gheall ar shlí go mbeadh sé sárú ar prótacal na trait ar.
    ///
    /// Na tuairisceáin chun feidhme réamhshocraithe `(0,` [`None`]`)`atá ceart d'aon iterator.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Sampla níos casta:
    ///
    /// ```
    /// // Na huimhreacha cothroma ó nialas go deich.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // D`fhéadfaimis iteáil ó nialas go deich n-uaire.
    /// // A fhios agam nach mbeadh sé ar a cúig a bheith go díreach agus is féidir gan forghníomhaitheach filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Cuirimis cúig uimhir eile le chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // anois tá an dá bounds mhéadú cúig
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Ag filleadh `None` do cheangal uachtair:
    ///
    /// ```
    /// // níl aon cheangal uachtarach ag iteálaí gan teorainn agus an uasteorainn is ísle is féidir
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Caitheann an iterator, comhaireamh ar líon na atriallta agus a sheoladh ar ais.
    ///
    /// Glaofaidh [`next`] ar an modh seo arís agus arís eile go dtí go dtiocfar ar [`None`], ag filleadh an líon uaireanta a chonaic sé [`Some`].
    /// Tabhair faoi deara go bhfuil [`next`] a bheidh le glaoch ar a laghad uair, fiú mura gcomhlíonann an iterator bhfuil aon eilimintí.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Oibriú overflow
    ///
    /// Ní dhéantar aon chosaint ar an modh i gcoinne ró-shreafaí, agus mar sin déantar an toradh mícheart nó panics a chomhaireamh ar eilimintí de iterator le níos mó ná eilimintí [`usize::MAX`].
    ///
    /// Má tá dearbhuithe debug cumasaithe, tá panic ráthaithe.
    ///
    /// # Panics
    ///
    /// Seo fhéadfadh an fheidhm panic má tá níos mó ná gnéithe [`usize::MAX`] an iterator.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Caitheann an iterator, ag filleadh an rud is deireanaí.
    ///
    /// Beidh an modh seo meastóireacht iterator go dtí go bhfilleann sé [`None`].
    /// Agus sin a dhéanamh, go gcoinníonn sé súil a choinneáil ar an eilimint atá ann faoi láthair.
    /// Tar éis [`None`] a thabhairt ar ais, fillfidh `last()` an eilimint dheireanach a chonaic sé.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Cuireann eilimintí `n` an t-iteoir chun cinn.
    ///
    /// Beidh an modh seo skip go fonnmhar eilimintí `n` trí ghlaoch [`next`] suas go dtí amanna `n` dtí go [`None`] thiocfaidh chun cinn.
    ///
    /// `advance_by(n)` Cuirfear ar ais [`Ok(())`][Ok] má cinn an iterator go rathúil trí eilimintí `n`, nó [`Err(k)`][Err] má tá [`None`] bhíonn, i gcás ina bhfuil `k` an líon na n-eilimintí an iterator chun cinn trí roimh rith amach na n-eilimintí (ie
    /// fad an iterator).
    /// Tabhair faoi deara go bhfuil `k` i gcónaí níos lú ná `n`.
    ///
    /// Ní itheann glaoch `advance_by(0)` aon eilimintí agus filleann sé [`Ok(())`][Ok] i gcónaí.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // níor scipeáladh ach `&4`
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Tuairisceáin an `eilimint n`th den iterator.
    ///
    /// Cosúil le mórchuid na n-oibríochtaí innéacsaithe, tosaíonn an comhaireamh ó nialas, mar sin tugann `nth(0)` an chéad luach ar ais, `nth(1)` an dara ceann, agus mar sin de.
    ///
    /// Tabhair faoi deara go n-ídítear na heilimintí go léir roimhe seo, chomh maith leis an eilimint ar ais, ón atriall.
    /// Ciallaíonn sé sin go ndéanfar na heilimintí roimhe seo a scriosadh, agus freisin go dtabharfaidh eilimintí éagsúla ar ais `nth(0)` arís agus arís eile ar an atriall céanna.
    ///
    ///
    /// `nth()` seolfaidh sé [`None`] ar ais má tá `n` níos mó ná nó cothrom le fad an atreoraithe.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Ní Ag glaoch `nth()` amanna éagsúla athchasadh an iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Ag filleadh `None` má tá níos lú ná eilimintí `n + 1` ann:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Cruthaigh iterator ag tosú ag an bpointe céanna, ach stepping ag an méid a tugadh ar gach atriall.
    ///
    /// Nóta 1: Beidh an chéad ghné den iterator a chur ar ais i gcónaí, beag beann ar an chéim a tugadh.
    ///
    /// Nóta 2: Ní shocraítear an t-am a dtarraingítear eilimintí neamhaird.
    /// `StepBy` iompraíonn sé cosúil leis an seicheamh `next(), nth(step-1), nth(step-1),…`, ach tá sé saor in aisce é féin a iompar cosúil leis an seicheamh
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Cé acu ar bhealach a úsáidtear d'fhéadfadh athrú le haghaidh roinnt Iterators chun luas an.
    /// Beidh an dara bealach chun cinn an iterator níos luaithe agus d'fhéadfadh a ithe míreanna níos mó.
    ///
    /// `advance_n_and_return_first` is ionann é agus:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// panic an modh más é `0` an chéim a thugtar.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Glacann sé dhá iteoir agus cruthaíonn sé atreoraitheoir nua thar an dá cheann in ord.
    ///
    /// `chain()` Cuirfear ar ais ar iterator nua a iterate ar dtús níos mó ná luachanna ón gcéad iterator agus ansin thar luachanna ón dara iterator.
    ///
    /// Is é sin le rá, nascann sé dhá iteoir le chéile, i slabhra.🔗
    ///
    /// [`once`] a úsáidtear go coitianta chun luach amháin a chur in oiriúint isteach i slabhra de chineálacha eile atriall.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ós rud é an argóint go `chain()` Úsáideann [`IntoIterator`], is féidir linn a pas aon rud is féidir a thiontú isteach i [`Iterator`], ní hamháin [`Iterator`] féin.
    /// Mar shampla, cuireann slisní (`&[T]`) [`IntoIterator`] i bhfeidhm, agus mar sin is féidir iad a chur ar aghaidh go `chain()` go díreach:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Má oibríonn tú le Windows API, b`fhéidir gur mhaith leat [`OsStr`] a thiontú go `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zips up' dhá iterator in iterator amháin de péirí.
    ///
    /// `zip()` tuairisceáin a iterator nua a iterate thar dhá Iterators eile, ag filleadh tuple nuair a thagann an chéad eilimint ón gcéad iterator, agus a thagann an dara gné as an dara iterator.
    ///
    ///
    /// I bhfocail eile, zips sé dhá Iterators chéile, i gceann amháin.
    ///
    /// Má fhilleann ceachtar iteoir [`None`], fillfidh [`next`] ón iterator zipped [`None`].
    /// Má fhilleann an chéad iterator [`None`], `zip` bheidh gearr-chuaird agus `next` ní bheidh d'iarr sí ar an dara iterator.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ós rud é go n-úsáideann [`IntoIterator`] an argóint le `zip()`, is féidir linn rud ar bith is féidir a thiontú ina [`Iterator`] a rith, ní [`Iterator`] féin amháin.
    /// Mar shampla slices, (`&[T]`) bhfeidhm [`IntoIterator`], agus mar sin is féidir a chur ar aghaidh chuig `zip()` díreach:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` is minic a úsáidtear chun iteoir gan teorainn a zipáil go ceann teoranta.
    /// Oibríonn sé seo mar gheall ar an teoranta a bheidh iterator ar ais sa deireadh [`None`], dar críoch an zipper.Is féidir zipping le `(0..)` cuma a lán cosúil [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Cruthaigh iterator nua a chuireann cóip den `separator` idir mhíreanna in aice an iterator bunaidh.
    ///
    /// I gcás nach gcuireann `separator` [`Clone`] i bhfeidhm nó gur gá é a ríomh gach uair, bain úsáid as [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // An chéad eilimint ó `a`.
    /// assert_eq!(a.next(), Some(&100)); // An deighilteoir.
    /// assert_eq!(a.next(), Some(&1));   // An ghné eile ó `a`.
    /// assert_eq!(a.next(), Some(&100)); // An deighilteoir.
    /// assert_eq!(a.next(), Some(&2));   // An ghné dheireanach ó `a`.
    /// assert_eq!(a.next(), None);       // Is é an iterator críochnaithe.
    /// ```
    ///
    /// `intersperse` Is féidir a bheith an-úsáideach a bheith páirteach iterator ar nithe ag baint úsáide as gné choitianta:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Cruthaíonn sé iteálaí nua a chuireann mír a ghineann `separator` idir míreanna cóngaracha den atriall bunaidh.
    ///
    /// Glaofar an dúnadh díreach uair amháin gach uair a chuirtear mír idir dhá earra cóngaracha ón atriall bunúsach;
    /// sonrach, nach bhfuil an dúnadh ar a dtugtar má tá an táirgeacht iterator bunúsacha níos lú ná dhá mhír agus i ndiaidh na hítime seo caite thug.
    ///
    ///
    /// Má chuireann mír an iteora [`Clone`] i bhfeidhm, b`fhéidir go mbeadh sé níos éasca [`intersperse`] a úsáid.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // An chéad eilimint ó `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // An deighilteoir.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // An ghné eile ó `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // An deighilteoir.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // An ghné dheireanach ó `v`.
    /// assert_eq!(it.next(), None);               // Is é an iterator críochnaithe.
    /// ```
    ///
    /// `intersperse_with` is féidir a úsáid i gcásanna inar gá an deighilteoir a ríomh:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Faigheann an dúnadh a chomhthéacs ar iasacht chun mír a ghiniúint.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Glacann sé dúnadh agus cruthaítear atriall a iarrann an dúnadh sin ar gach eilimint.
    ///
    /// `map()` transforms iterator amháin isteach i gceann eile, trí mheán a cuid argóint:
    /// rud a chuireann [`FnMut`] i bhfeidhm.Táirgeann sé iteoir nua a iarrann an dúnadh seo ar gach eilimint den atriall bunaidh.
    ///
    /// Má tá tú go maith ag smaoineamh i gcineálacha, is féidir leat smaoineamh ar `map()` mar seo:
    /// Má tá iteoir agat a thugann eilimintí de chineál éigin `A` duit, agus gur mhaith leat atriall de chineál éigin `B` eile, is féidir leat `map()` a úsáid, ag dúnadh a thógann `A` agus a chuireann `B` ar ais.
    ///
    ///
    /// `map()` tá sé cosúil go coincheapúil le lúb [`for`].Mar sin féin, mar a bhfuil `map()` leisciúil, tá sé in úsáid is fearr nuair a bhíonn tú ag obair cheana féin le Iterators eile.
    /// Má tá lúb de shaghas éigin á dhéanamh agat le haghaidh fo-iarmhairt, meastar go bhfuil sé níos idiomaí [`for`] a úsáid ná `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Má tá tú ag déanamh de chineál éigin fho-iarsma, is fearr [`for`] go `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // nach é seo a:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // ní fhorghníomhóidh sé fiú, toisc go bhfuil sé leisciúil.Beidh Rust rabhadh duit faoi seo.
    ///
    /// // Ina áit sin, a úsáid le haghaidh:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Glaonna dúnadh ar gach gné de iterator.
    ///
    /// Is ionann é seo agus lúb [`for`] a úsáid ar an atriall, cé nach féidir `break` agus `continue` a dhúnadh.
    /// De ghnáth bíonn sé níos idiomaíí lúb `for` a úsáid, ach d`fhéadfadh go mbeadh `for_each` níos inléite agus earraí á bpróiseáil ag deireadh slabhraí iteora níos faide.
    ///
    /// I gcásanna áirithe d'fhéadfadh `for_each` freisin níos tapúla ná lúb, toisc go mbeidh sé a úsáid atriall inmheánach ar adapters nós `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// I gcás den sórt sampla beag, is féidir le lúb `for` bheith níos glaine, ach a d'fhéadfadh a bheith níos fearr `for_each` a choinneáil stíl feidhme le Iterators faide:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Cruthaigh iterator a bhaineann úsáid as dúnadh le cinntiú ar cheart gné a fuarthas.
    ///
    /// Mar gheall gné ní mór don dúnadh ar ais `true` nó `false`.An ais Beidh iterator toradh amháin na heilimintí a tuairisceáin an dúnadh fíor.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Toisc go dtarlaíonn an dúnadh ar aghaidh chuig `filter()` is tagairt í, agus tá go leor Iterators iterate thar tagairtí, seo mar thoradh a thabhairt ar chás, b'fhéidir mearbhall, áit a bhfuil an cineál dúnadh tagairt dúbailte:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // riachtanas dhá * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Is gnách úsáid a bhaint as dístruchtúrú ar an argóint chun ceann a scriosadh amach:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // araon&agus *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// nó an dá rud:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // dhá &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// de na sraitheanna seo.
    ///
    /// Tabhair faoi deara go bhfuil `iter.filter(f).next()` comhionann le `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Cruthaigh iterator go bhfuil an dá scagairí agus léarscáileanna.
    ///
    /// Ní thugann an t-atreoraitheoir ar ais ach na `luach 'a fhilleann an dúnadh soláthraithe `Some(value)` ina leith.
    ///
    /// `filter_map` Is féidir é a úsáid chun slabhraí de [`filter`] agus [`map`] níos gonta a dhéanamh.
    /// Taispeánann an sampla thíos conas is féidir `map().filter().map()` a ghiorrú go glao amháin go `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Seo an sampla céanna, ach le [`filter`] agus [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Cruthaigh iterator a thugann an líon atriall atá ann faoi láthair chomh maith leis an luach seo chugainn.
    ///
    /// Tugann an t-atreoraitheoir ar ais péirí `(i, val)`, áit arb é `i` an t-innéacs reatha atráchta agus is é `val` an luach a chuireann an t-atriallóir ar ais.
    ///
    ///
    /// `enumerate()` Coinníonn a áirítear mar a [`usize`].
    /// Más mian leat slánuimhir de mhéideanna éagsúla a chomhaireamh, soláthraíonn feidhm [`zip`] feidhmiúlacht chomhchosúil.
    ///
    /// # Oibriú overflow
    ///
    /// Dhéanann an modh ar bith aghaidh falsaithe overflows, agus mar sin enumerating níos mó ná gnéithe [`usize::MAX`] ceachtar cuireann an toradh mícheart nó panics.
    /// Má tá dearbhuithe debug cumasaithe, tá panic ráthaithe.
    ///
    /// # Panics
    ///
    /// An ais fhéadfadh iterator panic más rud é an t-innéacs le-bheith-ais bheadh thar maoil le [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Cruthaíonn sé iterator ar féidir leis [`peek`] a úsáid chun breathnú ar an gcéad eilimint eile den iterator gan í a ithe.
    ///
    /// Adds a modh [`peek`] chuig iterator.Féach ar a doiciméadú chun tuilleadh eolais a fháil.
    ///
    /// Tabhair faoi deara go bhfuil an t-atreoraitheoir bunúsach fós curtha chun cinn nuair a ghlaoitear [`peek`] den chéad uair: D`fhonn an chéad eilimint eile a aisghabháil, tugtar [`next`] ar an atriall bunúsach, mar sin aon fo-iarsmaí (ie
    ///
    /// rud ar bith eile seachas ag fáil an luach eile) den modh [`next`] tarlú.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ligeann dúinn a fheiceáil isteach sa future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // Is féidir linn a peek() amanna éagsúla, an ní bheidh iterator roimh ré
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // tar éis an iterator críochnaithe, is mar sin peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Cruthaítear iteoir a dhéanann eilimintí [`scipeáil '] bunaithe ar thuar.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` dúnann sé mar argóint.Glaofaidh sé an dúnadh seo ar gach eilimint den atreoraitheoir, agus tabharfaidh sé neamhaird ar eilimintí go dtí go bhfillfidh sé `false`.
    ///
    /// Tar éis `false` ais, tá `skip_while()`'s post os a chionn, agus an chuid eile de na heilimintí a thug.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Toisc go dtarlaíonn an dúnadh ar aghaidh chuig `skip_while()` is tagairt í, agus tá go leor Iterators iterate thar tagairtí, seo mar thoradh a thabhairt ar chás, b'fhéidir mearbhall, áit a bhfuil an cineál an argóint dúnta tagairt dúbailte:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // riachtanas dhá * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ag stopadh tar éis `false` tosaigh:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // cé go mbeadh sé seo a bheith bréagach, ó d'éirigh againn cheana féin bréagach, níl skip_while() úsáidtear ar bith níos mó
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Cruthaigh iterator go táirgeacht heilimintí atá bunaithe ar predicate.
    ///
    /// `take_while()` Bíonn dúnadh mar argóint.Beidh sé glaoch ar an dúnadh ar gach gné den iterator, agus eilimintí toradh cé go bhfilleann sé `true`.
    ///
    /// Tar éis `false` ais, tá `take_while()`'s post os a chionn, agus an chuid eile de na heilimintí Déantar neamhaird.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Toisc go dtarlaíonn an dúnadh ar aghaidh chuig `take_while()` is tagairt í, agus tá go leor Iterators iterate thar tagairtí, seo mar thoradh a thabhairt ar chás, b'fhéidir mearbhall, áit a bhfuil an cineál dúnadh tagairt dúbailte:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // riachtanas dhá * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ag stopadh tar éis `false` tosaigh:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Tá níos mó eilimintí againn atá níos lú ná nialas, ach ó fuair muid bréagach cheana féin, ní úsáidtear take_while() níos mó
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mar gheall ar riachtanais `take_while()` chun breathnú ar an luach d'fhonn a fheiceáil má ba chóir é a chur san áireamh nó nach ea, Tógann bheidh Iterators fheiceáil go bhfuil sé as oifig:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Níl an `3` ann a thuilleadh, toisc gur ídíodh é chun a fháil amach ar cheart don atriall stopadh, ach nár cuireadh ar ais san atriall é.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Cruthaíonn sé iterator a thugann eilimintí bunaithe ar thuar agus ar léarscáileanna.
    ///
    /// `map_while()` dúnann sé mar argóint.
    /// Beidh sé glaoch ar an dúnadh ar gach gné den iterator, agus eilimintí toradh cé go bhfilleann sé [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Seo an sampla céanna, ach le [`take_while`] agus [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stopadh tar éis [`None`] tosaigh:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Tá gnéithe níos fhéadfaí a oiriúnach i u32 (4, 5), ach tá `map_while` fhill `None` don `-3` (mar a d'fhill an `predicate` `None`) agus `collect` stadanna ar an gcéad `None` thiocfaidh chun cinn.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Mar gheall ar riachtanais `map_while()` chun breathnú ar an luach d'fhonn a fheiceáil má ba chóir é a chur san áireamh nó nach ea, Tógann bheidh Iterators fheiceáil go bhfuil sé as oifig:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Tá an `-3` thuilleadh ann, toisc go raibh sé arna gcaitheamh chun a fheiceáil má ba chóir an t-atriall stad, ach ní cuireadh ar ais isteach sa iterator.
    ///
    /// Tabhair faoi deara go murab ionann [`take_while`] bhfuil an iterator **Ní** comhleádh.
    /// Ní shonraítear freisin cad a fhilleann ar an atriall seo tar éis an chéad [`None`] a chur ar ais.
    /// Má theastaíonn iterator comhleádaithe uait, úsáid [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Cruthaigh iterator a skips an chéad chuid `n`.
    ///
    /// Tar éis dóibh sin caite, an chuid eile de na heilimintí a thug.
    /// In áit a bheith sáraitheach an modh seo go díreach, in ionad shárú an modh `nth`.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Cruthaíonn sé iterator a thugann a chéad eilimintí `n`.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` a úsáidtear go minic le iterator gan teorainn, chun é a dhéanamh Finite:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Má tá níos lú ná gnéithe `n` fáil, beidh `take` féin a theorannú an méid de na iterator bhunúsach:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// An adapter iterator cosúil leis [`fold`] go seilbh stáit inmheánach agus cuireann iterator nua.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` Bíonn dhá argóint: an luach tosaigh a síolta an stát inmheánach, agus a dúnadh le dhá argóintí, an chéad cheann a bheith ina tagairt mutable ar an stát inmheánach agus an dara gné iterator.
    ///
    /// Is féidir leis an dúnadh a shannadh don stát inmheánach a lua a roinnt idir na atriallta.
    ///
    /// Ar atriall, beidh an dúnadh i bhfeidhm maidir le gach gné den iterator agus an luach ar ais as dúnadh, an [`Option`], tá thug an iterator.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // gach atriall, beidh orainn a iolrú ar an stát ag an ngné
    ///     *state = *state * x;
    ///
    ///     // ansin, tabharfaimid faillí an stáit
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Cruthaigh iterator go n-oibríonn cosúil le léarscáil, ach flattens struchtúr neadaithe.
    ///
    /// Tá an t-adapter [`map`] an-úsáideach, ach sin amháin nuair a tháirgeann an argóint maidir le dúnadh luachanna.
    /// Má táirgeann sé iterator ina ionad sin, níl an ciseal breise de indirection.
    /// `flat_map()` Beidh a bhaint an ciseal breise ar a chuid féin.
    ///
    /// Is féidir leat smaoineamh ar `flat_map(f)` mar choibhéis séimeantach de [`map`] ping, agus ansin [`flatten`] áirítear mar atá i `map(f).flatten()`.
    ///
    /// Bealach eile chun smaoineamh ar `flat_map()`: [`map`] tuairisceáin dúnta'srud amháin do gach eilimint, agus tuairisceáin dúnadh `flat_map()`'s an iterator do gach eilimint.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() iterator ar ais
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Cruthaíonn sé iterator a dhéanann struchtúr neadaithe a leathadh.
    ///
    /// Tá sé seo úsáideach nuair a tá tú iterator de Iterators nó iterator de rudaí is féidir a iompú isteach i Iterators agus is mian leat a bhaint leibhéal amháin de indirection.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Mapáil agus ansin flattening:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() iterator ar ais
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Is féidir leat Athscríobh freisin i dtéarmaí [`flat_map()`], atá níos fearr sa chás seo ós rud é ar iompar aige hintinn níos soiléire:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() iterator ar ais
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Ní bhaineann flattening ach leibhéal neadaithe amháin ag an am:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Anseo feicimid nach ndéanann `flatten()` flatten "deep".
    /// Ina áit sin, ní bhaintear ach leibhéal amháin neadaithe.Is é sin, más rud é `flatten()` tú le sraith tríthoiseach, an toradh a bheidh dhéthoiseach agus ní aon-tríthoiseach.
    /// Chun a fháil ar struchtúr amháin-tríthoiseach, tá tú chun `flatten()` arís.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Cruthaíonn sé iterator a chríochnaíonn tar éis an chéad [`None`].
    ///
    /// I ndiaidh tuairisceáin an iterator [`None`], glaonna future nó nach féidir toradh [`Some(T)`] arís.
    /// `fuse()` oiriúntóir a oiriúnú, ag cinntiú go bhfillfidh [`None`] go deo tar éis [`None`] a thabhairt.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// // an iterator a mhalartach arna n-idir roinnt agus Ar bith
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // má tá sé fiú, Some(i32), eile Ar bith
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // is féidir linn ár n-iteoir a fheiceáil ag dul anonn'sanall
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // mar sin féin, aon uair amháin fuse againn uirthi ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // beidh sé ar ais i gcónaí `None` tar éis an chéad uair.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// An bhfuil rud éigin le gach gné de iterator, dul thar an luach ar.
    ///
    /// Agus iteoirí á n-úsáid agat, is minic a shlabhróidh tú roinnt acu le chéile.
    /// Cé atá ag obair ar chód den sórt, b'fhéidir gur mhaith leat a sheiceáil amach cad atá ag tarlú ag codanna éagsúla ar na bacáin.Chun é sin, cuir isteach glao a `inspect()`.
    ///
    /// Tá sé níos coitianta do `inspect()` a bheidh le húsáid mar uirlis debugging ná mar a bheith ann i do chód deiridh, ach d'fhéadfadh iarratais sé úsáideach i gcásanna áirithe nuair is gá earráidí a bheith logáilte isteach sula gcuirtear discarded.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // tá an t-ord iterator casta.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // a ligean ar chur ar roinnt glaonna inspect() chun imscrúdú cad atá ag tarlú
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Beidh sé seo a phriontáil:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// earráidí Logáil sula chaitheamh orthu:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Beidh sé seo a phriontáil:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Iasacht ar iterator, in ionad Tógann air.
    ///
    /// Tá sé seo úsáideach chun ligean a chur i bhfeidhm iterator adapters agus a choinneáil fós úinéireacht an iterator bunaidh.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // má dhéanaimid iarracht é a úsáid arís, ní oibreoidh sé.
    /// // Tugann an líne seo a leanas "earráid: úsáid a bhaint as luach ar athraíodh a ionad: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // a ligean ar iarracht sin arís
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // ina ionad sin, cuirimid .by_ref() isteach
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // anois tá sé seo ach fíneáil:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Athraíonn sé iteoir go bailiúchán.
    ///
    /// `collect()` in ann aon rud inathraithe a thógáil, agus é a iompú ina bhailiúchán ábhartha.
    /// Tá sé seo ar cheann de na modhanna níos cumhachtaí sa leabharlann caighdeánach, a úsáidtear i gcomhthéacsanna éagsúla.
    ///
    /// Is é an patrún is bunúsaí ina n-úsáidtear `collect()` ná bailiúchán amháin a iompú ina bhailiúchán eile.
    /// Ghlacann tú bailiúchán, glaoigh [`iter`] ar sé, a dhéanamh ar a bunch de claochluithe, agus ansin `collect()` ag an deireadh.
    ///
    /// `collect()` is féidir leo cásanna a chruthú freisin nach cineálacha tipiciúla iad.
    /// Mar shampla, is féidir [`String`] a thógáil ó [`char`] s, agus is féidir atriall de mhíreanna [`Result<T, E>`][`Result`] a bhailiú i `Result<Collection<T>, E>`.
    ///
    /// Féach ar na samplaí thíos le haghaidh tuilleadh.
    ///
    /// Toisc go bhfuil `collect()` chomh ginearálta, féadfaidh sé fadhbanna a chruthú le tátal cineáil.
    /// Dá bhrí sin, tá `collect()` ar cheann den bheagán uaireanta a fheicfidh tú an chomhréir ar a dtugtar an 'turbofish' go grámhar: `::<>`.
    /// Cuidíonn sé seo an t-algartam tátal a thuiscint go sonrach a bhfuil bailiúchán bhíonn tú ag iarraidh a bhailiú isteach.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Tabhair faoi deara go raibh an `: Vec<i32>` ag teastáil uainn ar thaobh na láimhe clé.Tá sé seo toisc go raibh muid ábalta a bhailiú isteach, mar shampla, a [`VecDeque<T>`] ina ionad:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Ag baint úsáide as an 'turbofish' ionad anótáil `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Toisc `collect()` cares ach thart ar cad tá tú ag bailiú isteach, is féidir leat a úsáid i gcónaí leid de chineál páirteach, `_`, leis an turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Ag baint úsáide as `collect()` chun [`String`] a dhéanamh:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Má tá tú liosta de na [`Toradh<T, E>`][`Result`] s, is féidir leat úsáid a bhaint as `collect()` a fheiceáil má theip aon cheann acu:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // tugann sé an chéad earráid dúinn
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // tugann sé liosta na bhfreagraí dúinn
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Itheann iteoir, ag cruthú dhá bhailiúchán uaidh.
    ///
    /// Is féidir leis an tuar a ritheadh chuig `partition()` `true`, nó `false` a thabhairt ar ais.
    /// `partition()` tuairisceáin péire, gach ceann de na heilimintí a d'fhill sí `true`, agus gach ceann de na heilimintí a d'fhill sí `false`.
    ///
    ///
    /// Féach freisin [`is_partitioned()`] agus [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Reorders na gnéithe den iterator *in-áit* de réir an phreideacáid tugadh, ar nós go bhfuil sin go léir arna bhfáil roimh an tuairisceán `true` dóibh siúd go léir go bhfuil ar ais `false`.
    ///
    /// Filleann sé líon na n-eilimintí `true` a fuarthas.
    ///
    /// Ní choinnítear ord coibhneasta na n-earraí deighilte.
    ///
    /// Féach freisin [`is_partitioned()`] agus [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Deighiltí in-idir evens agus odds
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: ar cheart dúinn a bheith buartha faoin gcomhaireamh ag cur thar maoil?An t-aon bhealach le níos mó ná
        // `usize::MAX` Is tagairtí mutable leis ZSTs, nach bhfuil úsáideach do dheighilt ...

        // Tá na dúnadh feidhmeanna "factory" ann genericity a sheachaint i `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Arís agus arís eile teacht ar an chéad `false` agus bhabhtáil sé leis an `true` seo caite.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Seiceálacha más rud é na gnéithe den iterator a dheighilt de réir an phreideacáid tugadh, ar nós go bhfuil sin go léir arna bhfáil roimh an tuairisceán `true` dóibh siúd go léir go bhfuil ar ais `false`.
    ///
    ///
    /// Féach freisin [`partition()`] agus [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Ceachtar na hítimí uile a thástáil `true`, nó stopann an chéad chlásal ag `false` agus seiceáil go mbíonn níos mó míreanna `true` ina dhiaidh sin.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// An modh iterator go bhfuil feidhm feidhm chomh fada agus tuairisceáin sé go rathúil, a tháirgeadh amháin, luach deiridh.
    ///
    /// `try_fold()` tógann sé dhá argóint: luach tosaigh, agus clabhsúr le dhá argóint: 'accumulator', agus eilimint.
    /// Filleann an dúnadh go rathúil, agus an luach ba cheart a bheith ag an taiscumar don chéad atriall eile, nó filleann sé ar mhainneachtain, le luach earráide a iomadaíodh ar ais chuig an té atá ag glaoch láithreach (short-circuiting).
    ///
    ///
    /// Is é an luach tosaigh an luach a bheidh an accumulator bheith ar an chéad ghlaoch.Má éiríonn leis an dúnadh a chur i bhfeidhm i gcoinne gach eilimint den atreoraitheoir, filleann `try_fold()` an carnán deiridh mar rath.
    ///
    /// Is Folding úsáideach uair a bheidh agat bailiúchán de rud éigin, agus ba mhaith liom a thabhairt ar aird a luach aonair as é.
    ///
    /// # Nóta d`Fheidhmitheoirí
    ///
    /// Tá roinnt de na modhanna (forward) eile implementations réamhshocraithe ó thaobh an gceann seo, mar sin déan iarracht a chur i bhfeidhm seo go sonrach más féidir é a dhéanamh rud éigin níos fearr ná an réamhshocraithe i bhfeidhm lúb `for`.
    ///
    /// Déan iarracht, go háirithe, an glao `try_fold()` seo a bheith agat ar na codanna inmheánacha óna bhfuil an t-iteoir seo comhdhéanta.
    /// Má theastaíonn glaonna iolracha, d`fhéadfadh go mbeadh an t-oibreoir `?` áisiúil chun luach an charntha a shlabhrú, ach bí ar an airdeall faoi aon ionróirí a chaithfear a sheasamh roimh na tuairisceáin luatha sin.
    /// Is é seo an modh `&mut self`, mar sin ní mór atriall a bheith resumable tar éis bualadh earráid anseo.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // an tsuim a sheiceáil ar gach ceann de na gnéithe de na eagar
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // overflows an tsuim nuair a chur leis an eilimint 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Toisc gur ghearrchiorcad é, tá na heilimintí eile fós ar fáil tríd an atriall.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Modh iteora a chuireann feidhm inchaite i bhfeidhm ar gach mír san iterator, ag stopadh ag an gcéad earráid agus ag cur na hearráide sin ar ais.
    ///
    ///
    /// Is féidir é seo a shíl freisin ar mar an fhoirm fallible na [`for_each()`] nó mar an leagan gan stát de [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Tá sé gearr-circuited, mar sin de na míreanna atá fágtha fós sa iterator:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Filltear gach eilimint i dtaiscumar trí oibríocht a chur i bhfeidhm, agus an toradh deiridh a thabhairt ar ais.
    ///
    /// `fold()` tógann sé dhá argóint: luach tosaigh, agus clabhsúr le dhá argóint: 'accumulator', agus eilimint.
    /// Filleann an dúnadh an luach gur chóir go mbeadh an t-accumulator don leagan eile.
    ///
    /// Is é an luach tosaigh an luach a bheidh an accumulator bheith ar an chéad ghlaoch.
    ///
    /// Tar éis an dúnadh seo a chur i bhfeidhm ar gach eilimint den iterator, cuireann `fold()` an carnán ar ais.
    ///
    /// Tá an oibríocht Uaireanta tugtar 'reduce' nó 'inject'.
    ///
    /// Is Folding úsáideach uair a bheidh agat bailiúchán de rud éigin, agus ba mhaith liom a thabhairt ar aird a luach aonair as é.
    ///
    /// Note: Ní fhéadfaidh `fold()`, agus modhanna comhchosúla a thrasnaíonn an t-iteoir iomlán, deireadh a chur le h-iteoirí gan teorainn, fiú ar traits a bhfuil toradh cinnte ina leith in am teoranta.
    ///
    /// Note: Is féidir [`reduce()`] a úsáid a bhaint as an chéad eilimint mar luach tosaigh, má tá an cineál accumulator agus cineál earra mar an gcéanna.
    ///
    /// # Nóta d`Fheidhmitheoirí
    ///
    /// Tá roinnt de na modhanna (forward) eile implementations réamhshocraithe ó thaobh an gceann seo, mar sin déan iarracht a chur i bhfeidhm seo go sonrach más féidir é a dhéanamh rud éigin níos fearr ná an réamhshocraithe i bhfeidhm lúb `for`.
    ///
    ///
    /// Déan iarracht, go háirithe, an glao `fold()` seo a bheith agat ar na codanna inmheánacha óna bhfuil an t-iteoir seo comhdhéanta.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // suim gach ceann de na gnéithe de na eagar
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// A ligean ar siúl tríd gach céim den atriall anseo:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Agus mar sin, ár dtoradh deiridh, `6`.
    ///
    /// Tá sé coitianta do dhaoine nach bhfuil in úsáid Iterators go leor a úsáid lúb `for` le liosta de na rudaí a thógáil suas le toradh.Is féidir leo siúd a iompú `fold()`s Aistriúcháin isteach:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // le haghaidh lúb:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // tá siad mar an gcéanna
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Laghdaíonn sé na heilimintí go ceann amháin, trí oibríocht laghdaithe a chur i bhfeidhm arís agus arís eile.
    ///
    /// Má tá an t-iteoir folamh, filleann [`None`];ar shlí eile ar ais, mar thoradh ar an laghdú.
    ///
    /// Maidir le Iterators le gné amháin ar a laghad, is é seo mar [`fold()`] an gcéanna leis an chéad ghné den iterator mar luach tosaigh, fillte gach gné dá éis sin isteach é.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Faigh an luach is mó:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Tástálacha má mheaitseálann gach eilimint den iteoir le tuar.
    ///
    /// `all()` Bíonn dúnadh go bhfilleann `true` nó `false`.Cuireann sé an dúnadh seo i bhfeidhm ar gach eilimint den atriall, agus má fhilleann siad uile `true`, déanann `all()` amhlaidh.
    /// Má aon cheann acu ar ais `false`, tuairisceáin sé `false`.
    ///
    /// `all()` Is gearr-circuiting;i bhfocail eile, beidh sé stop a phróiseáil a luaithe a fhaigheann sé ina `false`, ós rud é go cuma cad a tharlaíonn eile, beidh an toradh a bheith chomh maith `false`.
    ///
    ///
    /// Filleann An iterator folamh `true`.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Ag stopadh ag an gcéad `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // Is féidir linn a úsáid i gcónaí `iter`, mar go bhfuil gnéithe níos mó.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Tástálacha má oireann aon ghné den iterator preideacáid.
    ///
    /// `any()` dúnann sé a fhilleann `true` nó `false`.Cuireann sé an dúnadh seo i bhfeidhm ar gach eilimint den atriall, agus má fhilleann aon cheann acu `true`, déanann `any()` amhlaidh.
    /// Má fhilleann siad uile `false`, filleann sé `false`.
    ///
    /// `any()` tá ciorcad gearr;i bhfocail eile, stopfaidh sé de phróiseáil a luaithe a aimsíonn sé `true`, ós rud é is cuma cad a tharlóidh, is é `true` an toradh a bheidh air freisin.
    ///
    ///
    /// Filleann An iterator folamh `false`.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Ag stopadh ag an gcéad `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // Is féidir linn a úsáid i gcónaí `iter`, mar go bhfuil gnéithe níos mó.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Cuardach ar eilimint de iterator go sásaíonn preideacáid.
    ///
    /// `find()` Bíonn dúnadh go bhfilleann `true` nó `false`.
    /// Cuireann sé an dúnadh seo i bhfeidhm ar gach eilimint den atriall, agus má fhilleann aon cheann acu `true`, filleann `find()` [`Some(element)`].
    /// Má fhilleann siad uile `false`, filleann sé [`None`].
    ///
    /// `find()` tá ciorcad gearr;i bhfocail eile, beidh sé stop a phróiseáil a luaithe tuairisceáin an dúnadh `true`.
    ///
    /// Mar a thógann `find()` is tagairt í, agus tá go leor Iterators iterate thar tagairtí, seo mar thoradh a thabhairt ar chás, b'fhéidir, mearbhall sa chás go bhfuil an argóint tagairt dúbailte.
    ///
    /// Is féidir leat a fheiceáil na críche sin in samplaí thíos, le `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Ag stopadh ag an gcéad `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // Is féidir linn a úsáid i gcónaí `iter`, mar go bhfuil gnéithe níos mó.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Tabhair faoi deara go bhfuil `iter.find(f)` comhionann le `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Feidhmíonn sé maidir le heilimintí an iteora agus cuireann sé an chéad toradh nach bhfuil ann ar ais.
    ///
    ///
    /// `iter.find_map(f)` comhionann le `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Feidhmíonn sé maidir le heilimintí an iteora agus cuireann sé an chéad fhíor-thoradh nó an chéad earráid ar ais.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Cuardaigh le haghaidh ghné i iterator, ag filleadh ar a innéacs.
    ///
    /// `position()` Bíonn dúnadh go bhfilleann `true` nó `false`.
    /// Tá feidhm aige seo dúnadh do gach eilimint den iterator, agus má fhilleann duine amháin acu `true`, ansin ar ais `position()` [`Some(index)`].
    /// Má tá gach ceann acu ar ais `false`, tuairisceáin sé [`None`].
    ///
    /// `position()` Is gearr-circuiting;i bhfocail eile, beidh sé stop a phróiseáil chomh luath agus a mheasann sé ina `true`.
    ///
    /// # Oibriú overflow
    ///
    /// Ní dhéanann an modh aon chosaint ar ró-shreabhadh, mar sin má tá níos mó ná eilimintí neamh-mheaitseála [`usize::MAX`] ann, táirgeann sé an toradh mícheart nó panics.
    ///
    /// Má tá dearbhuithe debug cumasaithe, tá panic ráthaithe.
    ///
    /// # Panics
    ///
    /// D`fhéadfadh panic an fheidhm seo a bheith agat má tá níos mó ná eilimintí neamh-mheaitseála `usize::MAX` ag an iterator.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Ag stopadh ag an gcéad `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // Is féidir linn a úsáid i gcónaí `iter`, mar go bhfuil gnéithe níos mó.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Braitheann an t-innéacs a chuirtear ar ais ar staid an iteora
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Cuardaigh le haghaidh ghné i iterator ón gceart, ag filleadh ar a innéacs.
    ///
    /// `rposition()` Bíonn dúnadh go bhfilleann `true` nó `false`.
    /// Tá feidhm aige seo dúnadh do gach eilimint den iterator, dar tosach deireadh, agus má fhilleann duine amháin acu `true`, ansin ar ais `rposition()` [`Some(index)`].
    ///
    /// Má tá gach ceann acu ar ais `false`, tuairisceáin sé [`None`].
    ///
    /// `rposition()` Is gearr-circuiting;i bhfocail eile, beidh sé stop a phróiseáil chomh luath agus a mheasann sé ina `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Ag stopadh ag an gcéad `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // Is féidir linn a úsáid i gcónaí `iter`, mar go bhfuil gnéithe níos mó.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Níl gá le overflow seiceáil anseo, toisc go dtugann `ExactSizeIterator` go bhfuil líon na n-oireann gnéithe isteach i `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Filleann sé an eilimint uasta d'athraitheoir.
    ///
    /// Má tá roinnt gnéithe cothrom uasta, tá an rud is deireanaí ar ais.
    /// Má tá an iterator folamh, tá [`None`] ais.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Tuairisceáin an eilimint is lú de iterator.
    ///
    /// Má tá roinnt eilimintí chomh híseal agus is féidir, tugtar an chéad eilimint ar ais.
    /// Má tá an iterator folamh, tá [`None`] ais.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Filleann sé an eilimint a thugann an luach is mó ón bhfeidhm shonraithe.
    ///
    ///
    /// Má tá roinnt gnéithe cothrom uasta, tá an rud is deireanaí ar ais.
    /// Má tá an iterator folamh, tá [`None`] ais.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Tuairisceáin an eilimint a thugann an t-uasluach leis I ndáil le feidhm comparáide sonraithe.
    ///
    ///
    /// Má tá roinnt gnéithe cothrom uasta, tá an rud is deireanaí ar ais.
    /// Má tá an iterator folamh, tá [`None`] ais.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Tuairisceáin an eilimint a thugann an luach minimum ón bhfeidhm atá sonraithe.
    ///
    ///
    /// Má tá roinnt eilimintí chomh híseal agus is féidir, tugtar an chéad eilimint ar ais.
    /// Má tá an iterator folamh, tá [`None`] ais.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Filleann sé an eilimint a thugann an luach íosta i leith na feidhme comparáide sonraithe.
    ///
    ///
    /// Má tá roinnt eilimintí chomh híseal agus is féidir, tugtar an chéad eilimint ar ais.
    /// Má tá an iterator folamh, tá [`None`] ais.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Aisiompaíonn treo an iteora.
    ///
    /// De ghnáth, iterate Iterators ó chlé go deas.
    /// Tar éis `rev()` a úsáid, athróidh iteoir ó dheis go clé.
    ///
    /// Tá sé seo indéanta ach amháin má tá an iterator deiridh, mar sin oibríonn `rev()` amháin ar [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Tiontaíonn sé iteálaí péirí ina péire coimeádán.
    ///
    /// `unzip()` ídíonn iteoir iomlán péirí, ag táirgeadh dhá bhailiúchán: ceann ó eilimintí clé na mbeirteanna, agus ceann ó na heilimintí cearta.
    ///
    ///
    /// Is í an fheidhm seo, ar bhealach éigin, a mhalairt de [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Cruthaíonn sé iterator a chóipeáil a chuid eilimintí go léir.
    ///
    /// Tá sé seo úsáideach nuair a bhíonn atriall agat os cionn `&T`, ach teastaíonn iteoir os cionn `T` uait.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // cóipeáladh mar an gcéanna le .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Cruthaíonn sé iterator a [`clón`] gach ceann dá eilimintí.
    ///
    /// Tá sé seo úsáideach nuair a bhíonn atriall agat os cionn `&T`, ach teastaíonn iteoir os cionn `T` uait.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // Is clónáilte mar .map(|&x| x) an gcéanna, d'slánuimhreacha
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Athrá ar an iterator endlessly.
    ///
    /// In áit stopadh ag [`None`], tosóidh an t-atreoraitheoir arís ina dhiaidh sin, ón tús.Tar éis a ite arís, tosóidh sé ag an tús arís.Agus arís.
    /// Agus arís.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Suim na n-eilimintí de iterator.
    ///
    /// Glacann sé gach eilimint, cuireann le chéile iad, agus cuireann sé an toradh ar ais.
    ///
    /// Filleann iteoir folamh luach nialasach den chineál.
    ///
    /// # Panics
    ///
    /// Agus `sum()` á ghlaoch agus cineál slánuimhir primitive á thabhairt ar ais, déanfaidh an modh seo panic má chumasaítear an ró-shreabhadh ríofa agus na dearbhuithe dífhabhtaithe.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iterates thar an iterator iomlán, ag iolrú na n-eilimintí go léir
    ///
    /// Filleann iteoir folamh luach amháin den chineál.
    ///
    /// # Panics
    ///
    /// Agus `product()` á ghlaoch agus cineál slánuimhir primitive á thabhairt ar ais, beidh panic sa mhodh má chumasaítear an ró-shreabhadh ríofa agus na dearbhuithe dífhabhtaithe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) déantar comparáid idir eilimintí an [`Iterator`] seo agus gnéithe ceann eile.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) i gcomparáid na gnéithe de seo [`Iterator`] le cuntais eile i leith an bhfeidhm comparáide sonraithe.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) déantar comparáid idir eilimintí an [`Iterator`] seo agus gnéithe ceann eile.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) i gcomparáid na gnéithe de seo [`Iterator`] le cuntais eile i leith an bhfeidhm comparáide sonraithe.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Cinneann an bhfuil eilimintí an [`Iterator`] seo cothrom le heilimintí ceann eile.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Cinneann má tá na gnéithe den [`Iterator`] comhionann leo sin de eile i leith an bhfeidhm sonraithe an chomhionannais.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Cinneann an bhfuil eilimintí an [`Iterator`] seo neamhchothrom le heilimintí ceann eile.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Cinneann má tá na gnéithe den [`Iterator`] [lexicographically](Ord#lexicographical-comparison) níos lú ná iad siúd de eile.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Cinneann má tá na gnéithe den [`Iterator`] [lexicographically](Ord#lexicographical-comparison) lú nó cothrom le leis na cinn de ceann eile.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Cinneann má tá na gnéithe den [`Iterator`] [lexicographically](Ord#lexicographical-comparison) mó ná iad siúd de eile.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Cinneann má tá na gnéithe den [`Iterator`] [lexicographically](Ord#lexicographical-comparison) mó ná nó cothrom le leis na cinn de ceann eile.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Seiceálacha an bhfuil eilimintí an iteora seo curtha in eagar.
    ///
    /// Is é sin, i gcás gach eilimint `a` agus an eilimint `b` seo a leanas, ní mór `a <= b` a shealbhú.Má thugann an t-atreoraitheoir nialas nó eilimint amháin go díreach, tugtar `true` ar ais.
    ///
    /// Tabhair faoi deara, mura bhfuil `Self::Item` ach `PartialOrd`, ach nach `Ord` é, tugann an sainmhíniú thuas le tuiscint go bhfilleann an fheidhm seo `false` mura bhfuil dhá earra as a chéile inchomparáide.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Seiceálacha an ndéantar eilimintí an atreoraithe seo a shórtáil ag úsáid na feidhme comparáideora a thugtar.
    ///
    /// In ionad `PartialOrd::partial_cmp` a úsáid, úsáideann an fheidhm seo an fheidhm `compare` a thugtar chun ordú dhá ghné a chinneadh.
    /// Seachas sin, is ionann é agus [`is_sorted`];féach ar a dhoiciméadú chun tuilleadh faisnéise a fháil.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Seiceálacha an ndéantar eilimintí an atreoraithe seo a shórtáil ag úsáid na príomhfheidhm eastósctha a thugtar.
    ///
    /// In ionad na n-eilimintí an iterator a chur i gcomparáid go díreach, i gcomparáid fheidhm seo na heochracha na heilimintí, mar atá arna chinneadh ag `f`.
    /// Seachas sin, is ionann é agus [`is_sorted`];féach ar a dhoiciméadú chun tuilleadh faisnéise a fháil.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Féach [TrustedRandomAccess]
    // Is é an t-ainm neamhghnách a sheachaint imbhuailtí ainm i réiteach modh fheiceáil #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}