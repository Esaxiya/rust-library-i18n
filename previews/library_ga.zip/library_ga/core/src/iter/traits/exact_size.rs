/// Eagaróir a bhfuil a fhad cruinn ar eolas aige.
///
/// Níl a fhios ag a lán [`Iterator`] cé mhéad uair a atheagróidh siad, ach déanann cuid acu.
/// Má tá a fhios ag iteoir cé mhéad uair is féidir leis a athrá, is féidir go mbeadh sé úsáideach rochtain ar an bhfaisnéis sin a sholáthar.
/// Mar shampla, más mian leat athrá ar gcúl, tús maith is ea fios a bheith agat cá bhfuil an deireadh.
///
/// Agus `ExactSizeIterator` á chur i bhfeidhm, ní mór duit [`Iterator`] a chur i bhfeidhm freisin.
/// Agus é sin á dhéanamh, caithfidh cur i bhfeidhm [`Iterator::size_hint`]* * méid cruinn an atriallóra a thabhairt ar ais.
///
/// Tá an modh [`len`] a chur chun feidhme réamhshocraithe, mar sin ní ba chóir duit a chur i bhfeidhm de ghnáth é.
/// Ach d'fhéadfá a bheith in ann a chur i bhfeidhm níos mó ná performant an mhainneachtain a chur ar fáil, mar sin sáraitheach é sa chás seo a dhéanann ciall.
///
///
/// Tabhair faoi deara go bhfuil an trait tá trait sábháilte agus ní cosúil le *nach* agus *nach féidir* ráthú go bhfuil an fad ar ais i gceart.
/// Ciallaíonn sé sin `unsafe` cód Níor chóir ** ** ag brath ar an cruinneas [`Iterator::size_hint`].
/// Tugann an [`TrustedLen`](super::marker::TrustedLen) trait éagobhsaí agus neamhshábháilte an ráthaíocht bhreise seo.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// // fhios ag raon críochta go cruinn cé mhéad uair a bheidh sé iterate
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Sa [module-level docs], chuireamar [`Iterator`] i bhfeidhm, `Counter`.
/// Cuirimis `ExactSizeIterator` i bhfeidhm air freisin:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Is féidir linn an líon atriall atá fágtha a ríomh go héasca.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Agus anois is féidir linn é a úsáid!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Filleann sé fad cruinn an iteora.
    ///
    /// Na áirithíonn cur chun feidhme go mbeidh an t-iterator filleadh go díreach `len()` níos mó sa luach [`Some(T)`], sular fhill [`None`].
    ///
    /// Tá an modh seo a chur chun feidhme réamhshocraithe, mar sin ní ba chóir duit a chur i bhfeidhm de ghnáth go díreach.
    /// Mar sin féin, más féidir leat a chur ar fáil cur chun feidhme níos éifeachtaí, is féidir leat é sin a.
    /// Féach na docs [trait-level] mar shampla.
    ///
    /// Tá an fheidhm na ráthaíochtaí sábháilteachta céanna leis an fheidhm [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// // fhios ag raon críochta go cruinn cé mhéad uair a bheidh sé iterate
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Tá an dearbhú seo ró-chosantach, ach seiceann sé an t-invariant
        // ráthaithe ag an trait.
        // Má bhí seo trait rust-inmheánach, d'fhéadfadh muid a úsáid debug_assert !;assert_eq!seiceálfaidh sé gach feidhmchlár úsáideora Rust freisin.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Tuairisceáin `true` má tá an t-atreoraitheoir folamh.
    ///
    /// Tá an modh seo a chur chun feidhme réamhshocraithe ag baint úsáide as [`ExactSizeIterator::len()`], mar sin ní gá duit a chur i bhfeidhm féin.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}