use crate::ops::{ControlFlow, Try};

/// An iterator in ann gnéithe teacht isteach ón dá foircinn.
///
/// Rud go bhfuil cumas breise amháin thar rud éigin go uirlisí [`Iterator`] uirlisí `DoubleEndedIterator`: an cumas a ghlacadh chomh maith `Item`s ó chúl, chomh maith leis an tosaigh.
///
///
/// Tá sé tábhachtach a faoi deara go bhfuil an dá ar ais agus obair amach ar an réimse céanna, agus ní tras: Tá atriall níos mó ná a gcruinniú i lár.
///
/// Ar an gcaoi chéanna leis an bprótacal [`Iterator`], a luaithe a fhilleann `DoubleEndedIterator` [`None`] ó [`next_back()`], má ghlaotar air arís féadfaidh sé nó ní fhéadfaidh sé [`Some`] a thabhairt ar ais arís.
/// [`next()`] agus tá [`next_back()`] idirmhalartaithe chun na críche sin.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Bain agus tuairisceáin gné ó dheireadh an iterator.
    ///
    /// Tuairisceáin `None` nuair nach bhfuil níos mó eilimintí ann.
    ///
    /// Go bhfuil na docs [trait-level] tuilleadh sonraí.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Na heilimintí Fuarthas ag `modhanna DoubleEndedIterator` ar difriúil ó na cinn Fuarthas trí mhodhanna [`Iterator`] 's:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Cuireann eilimintí `n` an t-atreoraitheoir ar aghaidh.
    ///
    /// `advance_back_by` an leagan droim ar ais de [`advance_by`].Beidh an modh seo skip go fonnmhar eilimintí `n` tosú ó chúl trí ghlaoch [`next_back`] suas go dtí amanna `n` dtí go [`None`] thiocfaidh chun cinn.
    ///
    /// `advance_back_by(n)` Cuirfear ar ais [`Ok(())`] má cinn an iterator go rathúil trí eilimintí `n`, nó [`Err(k)`] má tá [`None`] bhíonn, i gcás ina bhfuil `k` an líon na n-eilimintí an iterator chun cinn trí roimh rith amach na n-eilimintí (ie
    /// fad an iterator).
    /// Tabhair faoi deara go bhfuil `k` i gcónaí níos lú ná `n`.
    ///
    /// Ní itheann glaoch `advance_back_by(0)` aon eilimintí agus filleann sé [`Ok(())`] i gcónaí.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // ach bhí ndearna `&3`
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Tuairisceáin an `eilimint n`th ó dheireadh an iterator.
    ///
    /// Go bunúsach is é seo an leagan droim ar ais de [`Iterator::nth()`].
    /// Cé mar chuid is mó oibríochtaí innéacsú, tosaíonn an comhaireamh ó náid, agus mar sin ar ais `nth_back(0)` an chéad luach ó dheireadh, `nth_back(1)` an dara, agus mar sin de.
    ///
    ///
    /// Tabhair faoi deara go mbeidh na heilimintí go léir idir deireadh agus an eilimint ais a chaitheamh, lena n-áirítear an eilimint ais.
    /// Ciallaíonn sé seo freisin go bhfillfidh eilimintí éagsúla ar `nth_back(0)` arís agus arís eile ar an iterator céanna.
    ///
    /// `nth_back()` seolfaidh sé [`None`] ar ais má tá `n` níos mó ná nó cothrom le fad an atreoraithe.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Ní Ag glaoch `nth_back()` amanna éagsúla athchasadh an iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Ag filleadh `None` má tá níos lú ná eilimintí `n + 1` ann:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Is é seo an leagan chúl [`Iterator::try_fold()`]: a thógann sé gnéithe ag tosú ó chúl an iterator.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Toisc gur ghearrchiorcad é, tá na heilimintí eile fós ar fáil tríd an atriall.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Modh iteora a laghdaíonn eilimintí an iteora go luach deiridh amháin, ag tosú ón gcúl.
    ///
    /// Is é seo an leagan chúl [`Iterator::fold()`]: a thógann sé gnéithe ag tosú ó chúl an iterator.
    ///
    /// `rfold()` tógann sé dhá argóint: luach tosaigh, agus clabhsúr le dhá argóint: 'accumulator', agus eilimint.
    /// Filleann an dúnadh an luach gur chóir go mbeadh an t-accumulator don leagan eile.
    ///
    /// Is é an luach tosaigh an luach a bheidh an accumulator bheith ar an chéad ghlaoch.
    ///
    /// Tar éis an dúnadh seo a chur i bhfeidhm ar gach eilimint den iterator, cuireann `rfold()` an carnán ar ais.
    ///
    /// Tá an oibríocht Uaireanta tugtar 'reduce' nó 'inject'.
    ///
    /// Is Folding úsáideach uair a bheidh agat bailiúchán de rud éigin, agus ba mhaith liom a thabhairt ar aird a luach aonair as é.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // suim eilimintí uile a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Tógann an sampla seo sreangán, ag tosú le luach tosaigh agus ag leanúint ar aghaidh le gach eilimint ón gcúl go dtí an tosaigh:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Cuardaigh eilimint d`athraitheoir ón gcúl a shásaíonn tuar.
    ///
    /// `rfind()` Bíonn dúnadh go bhfilleann `true` nó `false`.
    /// Tá feidhm aige seo dúnadh do gach eilimint den iterator, ag tosú ag an deireadh, agus má tá aon cheann acu ar ais chuig `true`, ansin ar ais `rfind()` [`Some(element)`].
    /// Má fhilleann siad uile `false`, filleann sé [`None`].
    ///
    /// `rfind()` tá ciorcad gearr;i bhfocail eile, beidh sé stop a phróiseáil a luaithe tuairisceáin an dúnadh `true`.
    ///
    /// Toisc go dtógann `rfind()` tagairt, agus go n-athraíonn go leor iteoirí tagairtí, bíonn staid a d`fhéadfadh a bheith mearbhall ina chúis gur tagairt dhúbailte í an argóint.
    ///
    /// Is féidir leat a fheiceáil na críche sin in samplaí thíos, le `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Ag stopadh ag an gcéad `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // Is féidir linn a úsáid i gcónaí `iter`, mar go bhfuil gnéithe níos mó.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}