/// Atriallóir a leanann de bheith ag tabhairt `None` i gcónaí nuair a bhíonn sé ídithe.
///
/// Ráthaítear an chéad ghlaoch eile ar iteoir comhleádaithe a chuir `None` ar ais uair amháin [`None`] a thabhairt ar ais arís.
/// Ba cheart an trait cur i bhfeidhm ag Iterators go féin a iompar ar an mbealach seo mar is féidir a bharrfheabhsú [`Iterator::fuse()`].
///
///
/// Note: Go ginearálta, ní ba chóir duit a úsáid `FusedIterator` i bounds cineálach más gá tú comhleádh iterator.
/// Ina áit sin, níor cheart duit ach [`Iterator::fuse()`] a ghlaoch ar an iterator.
/// Má tá an iterator comhleádh cheana, beidh an [`Fuse`] fillteán breise a bheith ina aon-op gan aon phionós feidhmíochta.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Eagaróir a thuairiscíonn fad cruinn ag úsáid size_hint.
///
/// Tuairiscíonn an t-iteoir leid méide nuair atá sé cruinn (tá an teorainn níos ísle cothrom leis an uasteorainn), nó is é [`None`] an teorainn uachtarach.
///
/// Ní mór gurb é [`None`] an teorainn uachtarach má tá fad iarbhír an iteora níos mó ná [`usize::MAX`].
/// Sa chás sin, ní mór gurb é [`usize::MAX`] an teorainn is ísle, agus [`Iterator::size_hint()`] de `(usize::MAX, None)` mar thoradh air.
///
/// Caithfidh an t-atreoraitheoir líon na n-eilimintí a thuairiscigh sé a thuairisciú nó a éagsúlú sula sroicheann sé an deireadh.
///
/// # Safety
///
/// Caithfear an trait a chur i bhfeidhm ach amháin nuair a bhíonn an conradh sheastar.
/// Ní mór do thomhaltóirí den trait iniúchadh [`Iterator::size_hint()`]’s cheangal uachtair.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Atreoraitheoir go mbeidh gné amháin ar a laghad tógtha óna [`SourceIter`] bunúsach nuair a bheidh earra á thabhairt aige.
///
/// Ag glaoch ar aon mhodh a chuireann an t-atreoraitheoir chun cinn, m.sh.
/// [`next()`] nó [`try_fold()`], ráthaíonn sé go bhfuil luach amháin ar a laghad de bhunfhoinse an iteora bogtha amach agus go bhféadfaí toradh an tslabhra iteora a chur isteach ina áit, ag glacadh leis go gceadaíonn srianta struchtúracha na foinse a leithéid a chur isteach.
///
/// Is é sin le rá, tugann an trait seo le fios gur féidir píblíne iteora a bhailiú ina háit.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}