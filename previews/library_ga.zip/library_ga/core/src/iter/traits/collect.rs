/// Comhshó ó [`Iterator`].
///
/// Trí chur i bhfeidhm `FromIterator` haghaidh cineáil, a shainiú tú conas a rachaidh sé a chruthú ó iterator.
/// Tá sé seo coitianta do chineálacha a chuireann síos bailiúchán de shaghas éigin.
///
/// [`FromIterator::from_iter()`] Is annamh a dtugtar go sainráite, agus a úsáidtear in áit trí modh [`Iterator::collect()`].
///
/// Féach cáipéisíocht [`Iterator::collect()`]'s le haghaidh tuilleadh samplaí.
///
/// Féach freisin: [`IntoIterator`].
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Ag baint úsáide as [`Iterator::collect()`] a úsáid hintuigthe `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// `FromIterator` a chur i bhfeidhm do do chineál:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Bailiúchán samplach, níl ansin ach fillteán thar Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Tugaimis roinnt modhanna dó ionas gur féidir linn ceann a chruthú agus rudaí a chur leis.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // agus cuirfimid FromIterator i bhfeidhm
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Anois is féidir linn iteoir nua a dhéanamh ...
/// let iter = (0..5).into_iter();
///
/// // ... agus MyCollection a dhéanamh as
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // saothair a bhailiú freisin!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Cruthaíonn luach ó iterator.
    ///
    /// Féach an [module-level documentation] le haghaidh tuilleadh.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Tiontú ina [`Iterator`].
///
/// Trí `IntoIterator` a chur i bhfeidhm do chineál, sainmhíníonn tú conas a athrófar é go iteoir.
/// Tá sé seo coitianta do chineálacha a chuireann síos bailiúchán de shaghas éigin.
///
/// Is é ceann tairbhe a chur i bhfeidhm `IntoIterator` go mbeidh do chineál [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Féach freisin: [`FromIterator`].
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Cur i bhfeidhm `IntoIterator` do do chineál:
///
/// ```
/// // Bailiúchán samplach, níl ansin ach fillteán thar Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Tugaimis roinnt modhanna dó ionas gur féidir linn ceann a chruthú agus rudaí a chur leis.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // agus cuirfimid IntoIterator i bhfeidhm
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Anois is féidir linn a dhéanamh ar bhailiúchán nua a ...
/// let mut c = MyCollection::new();
///
/// // ... cuir roinnt rudaí leis ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... agus ansin dul sé isteach i Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Tá sé coitianta a úsáid `IntoIterator` mar bound trait.Ligeann sé seo don chineál bailiúcháin ionchuir athrú, fad is atá sé fós ina atriallóir.
/// Is féidir le bounds breise a shonrú trí shrian ar
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// An cineál na n-eilimintí atá á athluaigh os a chionn.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Cén cineál iteora a bhfuilimid ag iompú air seo?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Cruthaíonn sé iterator ó luach.
    ///
    /// Féach an [module-level documentation] le haghaidh tuilleadh.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Leathnú bailiúchán leis an t-ábhar ar iterator.
///
/// tháirgeadh Iterators sraith de luachanna, agus is féidir bailiúchán a shíl freisin de mar shraith luachanna.
/// An trait `Extend` droichid an bhearna, ag ligean duit a leathnú bailiúchán trí lena n-áirítear an t-ábhar sin iterator.
/// Nuair a leathnú bailiúchán le eochair atá ann cheana féin, tá an iontráil sin cothrom le dáta nó, i gcás bailiúcháin a chuireann ar chumas dul isteach iolrach le heochracha comhionanna, go bhfuil iontráil a cuireadh isteach.
///
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// // Is féidir leat a leathnú Teaghrán le roinnt carachtair:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` a Chur i bhFeidhm:
///
/// ```
/// // Bailiúchán samplach, níl ansin ach fillteán thar Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Tugaimis roinnt modhanna dó ionas gur féidir linn ceann a chruthú agus rudaí a chur leis.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ós rud é MyCollection liosta i32s, táimid i bhfeidhm Síneadh i32
/// impl Extend<i32> for MyCollection {
///
///     // Tá sé seo beagán níos simplí leis an síniú cineál coincréite: is féidir linn glaoch ar shíneadh ar aon rud is féidir a iompú ina Iterator a thugann i32s dúinn.
///     // Toisc go dteastaíonn i32nna uainn chun MyCollection a chur isteach.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Tá cur i bhfeidhm an-simplí: lúb tríd an iterator, agus add() gach gné chun muid féin.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // déanaimis ár mbailiúchán a leathnú le trí uimhir eile
/// c.extend(vec![1, 2, 3]);
///
/// // chuireamar na heilimintí seo leis sa deireadh
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Leathnaíonn bailiúchán leis an t-ábhar ar iterator.
    ///
    /// Toisc gurb é seo an t-aon mhodh riachtanach don trait seo, tá níos mó sonraí sna docs [trait-level].
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// // Is féidir leat a leathnú Teaghrán le roinnt carachtair:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Leathnaíonn sé bailiúchán le gné amháin go díreach.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Cumas Cúlchistí i bailiúchán chun uimhir ar leith na n-eilimintí sa bhreis.
    ///
    /// Déanann an cur i bhfeidhm réamhshocraithe rud ar bith.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}