use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Tugann sé seo trait rochtain aistreacha le foinse-chéim i bpíblíne interator-adapter faoi na coinníollacha sin
/// * cuireann foinse an iterator `S` féin `SourceIter<Source = S>` i bhfeidhm
/// * tá cur chun feidhme tarmligthe an trait seo do gach oiriúntóir sa phíblíne idir an foinse agus tomhaltóir na píblíne.
///
/// Nuair is struchtúr iteora úinéireachta é an foinse (ar a dtugtar `IntoIter` go coitianta) ansin d`fhéadfadh sé seo a bheith úsáideach chun speisialtóireachtaí a dhéanamh ar chur chun feidhme [`FromIterator`] nó chun na heilimintí atá fágtha a aisghabháil tar éis do iteoir a bheith ídithe go páirteach.
///
///
/// Tabhair faoi deara nach bhfuil implementations bhfuil gá a rochtain ar an bhfoinse istigh-an chuid is mó de phíblíne a chur ar fáil.D`fhéadfadh oiriúntóir idirmheánach staidiúil cuid den phíblíne a mheas go fonnmhar agus a stóráil inmheánach a nochtadh mar fhoinse.
///
/// Tá an trait neamhshábháilte mar ní mór feidhmitheoirí airíonna sábháilteachta breise seasamh.
/// Féach [`as_inner`] le haghaidh sonraí.
///
/// # Examples
///
/// Foinse arna ídiú go páirteach a aisghabháil:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Céim foinse i bpíblíne iterator.
    type Source: Iterator;

    /// Faigh foinse píblíne iteora.
    ///
    /// # Safety
    ///
    /// Implementations úrfhíona ais an tagairt mutable céanna as a saoil, ach amháin má in ionad glaoiteoir.
    /// bhféadfar cuairteoirí in áit ach an tagairt nuair a stop siad atriall agus scaoil an bpíblíne iterator tar éis a bhaint an fhoinse.
    ///
    /// Ciallaíonn sé iterator Is féidir le adapters bheith ag brath ar an bhfoinse gan athrú le linn atriall ach ní féidir leo brath ar sé ina implementations Buail.
    ///
    /// Cur i bhfeidhm an modh seo scaradh adapters ciallaíonn rochtain príobháideacha amháin a bhfoinse agus is féidir brath ach amháin ar ráthaíochtaí a rinneadh bunaithe ar chineálacha modh glacadóir.
    /// Éilíonn an easpa rochtain shrianta freisin go gcaithfidh adapters seasamh leis an fhoinse ar API poiblí, fiú nuair a bhí siad rochtain ar a internals.
    ///
    /// Caithfidh glaoiteoirí ar a seal a bheith ag súil go mbeidh an foinse in aon stát atá ag teacht lena API poiblí ós rud é go bhfuil an rochtain chéanna ag na hoiriúnóirí atá ina suí idir í agus an fhoinse.
    /// Go háirithe d`fhéadfadh go mbeadh níos mó eilimintí ídithe ag cuibheoir ná mar is gá.
    ///
    /// Is é an sprioc foriomlán na ceanglais sin chun ligean don tomhaltóir ar úsáid phíblíne
    /// * is cuma cad fós san fhoinse tar éis atriall stopadh
    /// * an chuimhne nár úsáideadh trí iteoir íditheach a chur ar aghaidh
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// An adapter iterator mbíonn aschur chomh fada leis an bun táirgeann iterator luachanna `Result::Ok`.
///
///
/// Má aimsítear earráid, stadann an t-atreoraitheoir agus stóráiltear an earráid.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Déan an t-iteoir a thugtar a phróiseáil amhail is dá dtabharfadh sé `T` in ionad `Result<T, _>`.
/// Beidh aon earráidí stop a chur leis iterator inmheánach agus beidh an toradh iomlán a bheith earráid.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}