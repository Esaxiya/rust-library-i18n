//! Atriall seachtrach in-inúsáidte.
//!
//! Má tá tú fuair tú féin le bailiúchán de chineál éigin, agus a theastaíonn chun oibríocht ar na gnéithe de bhailiúcháin sin, beidh tú ag rith go tapa 'iterators' isteach.
//! Úsáidtear Iterators go mór i gcód idiomatach Rust, mar sin is fiú dul i dtaithí orthu.
//!
//! Sula ndéantar níos mó a mhíniú, déanaimis labhairt faoi struchtúr an mhodúil seo:
//!
//! # Organization
//!
//! Tá an modúl seo eagraithe den chuid is mó de réir cineáil:
//!
//! * [Traits] is iad seo an chuid lárnach: sainmhíníonn na traits seo an cineál iteoirí atá ann agus cad is féidir leat a dhéanamh leo.Is iad na modhanna seo traits fiú a chur roinnt ama staidéir breise isteach.
//! * [Functions] roinnt bealaí cabhracha a sholáthar chun roinnt iteoirí bunúsacha a chruthú.
//! * [Structs] is minic gurb iad na cineálacha tuairisceáin de na modhanna éagsúla ar traits an mhodúil seo.De ghnáth is mian leat breathnú ar an modh a chruthaíonn an `struct`, seachas an `struct` féin.
//! Le haghaidh tuilleadh sonraí faoi cén fáth, féach '[Iterator a Chur i bhFeidhm](#cur i bhfeidhm-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Sin é!Déanaimis tochailt i iteoirí.
//!
//! # Iterator
//!
//! Is é croí agus anam an mhodúil seo an [`Iterator`] trait.Breathnaíonn an croí [`Iterator`] mar seo:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Tá modh ag X iteoir, [`next`], a thugann [`Rogha`]`ar ais nuair a ghlaoitear air<Item>`.
//! [`next`] fillfidh [`Some(Item)`] chomh fada agus a bheidh eilimintí ann, agus nuair a bheidh siad uile ídithe, fillfidh siad `None` ar ais chun a thaispeáint go bhfuil an t-atriall críochnaithe.
//! Is féidir Iterators de rogha ag duine go n-atosóidh atriall, agus mar sin de ag glaoch [`next`] arís nó nach féidir a thosú sa deireadh ag filleadh [`Some(Item)`] arís ag pointe éigin (mar shampla, féach [`TryIter`]).
//!
//!
//! folaíonn [`Iterator`] 's sainmhíniú iomlán roinnt modhanna eile chomh maith, ach tá siad modhanna réamhshocraithe, a tógadh ar bharr [`next`], agus mar sin a fhaigheann tú iad saor in aisce.
//!
//! Tá Iterators freisin composable, agus tá sé coitianta go slabhra le chéile a dhéanamh foirmeacha níos casta na próiseála.Féach an chuid [Adapters](#adapters) thíos le haghaidh tuilleadh sonraí.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Na trí chineál atriall
//!
//! Tá trí mhodh choitianta ann ar féidir leo iteoirí a chruthú ó bhailiúchán:
//!
//! * `iter()`, a béim arís thar `&T`.
//! * `iter_mut()`, a béim arís thar `&mut T`.
//! * `into_iter()`, a athraíonn os cionn `T`.
//!
//! Is féidir rudaí éagsúla sa leabharlann caighdeánach amháin nó níos mó de na trí, i gcás inarb iomchuí a chur chun feidhme.
//!
//! # Iterator Feidhmithe
//!
//! Tá dhá chéim i gceist le h-iteoir féin a chruthú: `struct` a chruthú chun staid an iteora a shealbhú, agus ansin [`Iterator`] a chur i bhfeidhm don `struct` sin.
//! Sin é an fáth go bhfuil an oiread `struct`s sa mhodúl seo: tá ceann do gach iterator agus iterator adapter.
//!
//! A ligean ar a dhéanamh ar iterator ainmnithe `Counter` a chomhaireamh ó `1` go `5`:
//!
//! ```
//! // Gcéad dul síos, an struct:
//!
//! /// An iterator a chomhaireamh ó haon go cúig
//! struct Counter {
//!     count: usize,
//! }
//!
//! // ba mhaith linn ár n-count chun tús a chur ag ceann amháin, mar sin a ligean add a modh new() go cabhrú leat.
//! // Níl sé seo riachtanach go hiomlán, ach tá sé áisiúil.
//! // Tabhair faoi deara go bhfuil muid ag tosú `count` ag náid, beidh orainn a fheiceáil cén fáth i chun feidhme `next()`'s thíos.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Ansin, táimid i bhfeidhm `Iterator` dár `Counter`:
//!
//! impl Iterator for Counter {
//!     // beidh muid chomhaireamh le usize
//!     type Item = usize;
//!
//!     // next() an t-aon mhodh riachtanach
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Méadú ar ár gcomhaireamh.Sin é an fáth gur thosaíomar ag nialas.
//!         self.count += 1;
//!
//!         // Seiceáil a fheiceáil má tá muid comhaireamh críochnaithe nó nach bhfuil.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Agus anois is féidir linn é a úsáid!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Glaonn athchleachtach ar [`next`] a ghlaoch ar an mbealach seo.Rust Tá thógáil ar féidir a fhágáil gur ghá [`next`] ar do iterator, go dtí go sroicheann sé `None`.A ligean ar dul thar sin chugainn.
//!
//! Tabhair faoi deara freisin go soláthraíonn `Iterator` cur i bhfeidhm cheal modhanna ar nós `nth` agus `fold` a ghlaoch `next` hinmheánach.
//! Mar sin féin, is féidir freisin cur i bhfeidhm saincheaptha a scríobh ar mhodhanna mar `nth` agus `fold` más féidir le iteoir iad a ríomh ar bhealach níos éifeachtaí gan `next` a ghlaoch.
//!
//! # `for` lúba agus `IntoIterator`
//!
//! Is éard atá i gcomhréir lúb `for` Rust ná siúcra le haghaidh iteoirí.Seo sampla bunúsach de `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Déanfaidh sé seo na huimhreacha a haon trí chúig a phriontáil, gach ceann ar a líne féin.Ach tabharfaidh tú rud éigin faoi deara anseo: níor ghlaoigh muid rud ar bith ar ár vector riamh chun iteoir a tháirgeadh.Cad a thugann?
//!
//! Tá trait sa leabharlann chaighdeánach chun rud a thiontú ina atriall: [`IntoIterator`].
//! Seo trait Tá modh amháin, [`into_iter`], a athraíonn an rud a chur i bhfeidhm [`IntoIterator`] isteach iterator.
//! A ligean ar ghlacadh le breathnú ar an lúb `for` arís, agus cad a athraíonn an tiomsaitheoir i:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-siúcraí so do chur in:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Gcéad dul síos, tugaimid `into_iter()` ar an luach.Ansin, táimid ag a mheaitseáil ar an iterator go tuairisceáin, ag glaoch [`next`] arís agus go dtí go bhfeiceann muid `None`.
//! Ag an bpointe sin, ní mór dúinn `break` amach as an lúb, agus táimid iterating déanta.
//!
//! Níl ceann amháin beagán níos subtle anseo: tá an leabharlann caighdeánach i bhfeidhm suimiúil de [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! I bhfocail eile, gach [`Iterator`] a chur chun feidhme [`IntoIterator`], ag díreach ag filleadh féin.Ciallaíonn sé seo dhá rud:
//!
//! 1. Má tá [`Iterator`] á scríobh agat, is féidir leat é a úsáid le lúb `for`.
//! 2. Má tá bailiúchán á chruthú agat, trí [`IntoIterator`] a chur i bhfeidhm ligfidh sé do bhailiúchán a úsáid leis an lúb `for`.
//!
//! # Iterating trí thagairt
//!
//! Ós rud é go dtarlaíonn [`into_iter()`] `self` de réir luacha, ag baint úsáide as lúb `for` a iterate thar ídíonn bailiúcháin sin a bhailiú.Go minic, b`fhéidir gur mhaith leat athrá a dhéanamh ar bhailiúchán gan é a ithe.
//! A thairiscint go leor bailiúchán modhanna a chur ar fáil níos mó ná Iterators tagairtí, ar a dtugtar conventionally `iter()` agus `iter_mut()` faoi seach:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` fós faoi úinéireacht na feidhme seo.
//! ```
//!
//! Má sholáthraíonn cineál bailiúcháin `C` `iter()`, is gnách go gcuireann sé `IntoIterator` i bhfeidhm do `&C`, le cur chun feidhme nach nglaonn ach `iter()` air.
//! Mar an gcéanna, tá `C` bailiúchán a sholáthraíonn `iter_mut()` bhfeidhm go ginearálta `IntoIterator` do `&mut C` trí tharmligean `iter_mut()`.Cumasaíonn sé seo gearr-lámh áisiúil:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // céanna le `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // céanna le `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Cé go dtugann go leor bailiúcháin `iter()`, ní thairgeann gach ceann acu `iter_mut()`.
//! Mar shampla, d'fhéadfadh mutating na heochracha de [`HashSet<T>`] nó [`HashMap<K, V>`] a chur ar an mbailiúchán isteach i stát nach dtagann sé má hashes an eochair-athrú, mar sin a thairiscint na bailiúcháin amháin `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Is minic a thugtar 'oiriúnaitheoirí iteora' ar fheidhmeanna a thógann [`Iterator`] agus a thugann [`Iterator`] eile ar ais, mar gur cineál den 'adapter' iad
//! pattern'.
//!
//! I measc adapters iterator Common [`map`], [`take`], agus [`filter`].
//! Le haghaidh níos mó, féach ar a n-doiciméadú.
//!
//! Má tá oiriúntóir iteora panics ann, beidh an t-iteoir i riocht neamhshonraithe (ach slán ó chuimhne).
//! Seo stát ráthaithe freisin chun fanacht mar an gcéanna ar fud na leaganacha de Rust, mar sin ba chóir duit a sheachaint ag brath ar na luachanna cruinn ar ais ag iterator a panicked.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Tá Iterators (agus iterator [adapters](#adapters))* * leisciúil. Ciallaíonn sé sin a chruthú ach nach bhfuil iterator _do_ a lán iomlán. Ní dhéanfaidh aon ní a tharlaíonn i ndáiríre go dtí go ghlaonn tú [`next`].
//! Uaireanta is foinse mearbhaill é seo nuair a chruthaítear iteoir le haghaidh a fho-iarsmaí amháin.
//! Mar shampla, iarrann an modh [`map`] dúnadh ar gach eilimint a athraíonn sé:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Ní bheidh sé seo a phriontáil ar aon luachanna, mar chruthaíomar ach iterator, seachas úsáid a bhaint é.Tabharfaidh an tiomsaitheoir rabhadh dúinn faoin gcineál seo iompair:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Is é an bealach nathanna a scríobh [`map`] ar a fo-iarsmaí a úsáid lúb `for` nó cuir glaoch ar an modh [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Bealach coitianta eile chun iteoir a mheas is ea an modh [`collect`] a úsáid chun bailiúchán nua a tháirgeadh.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Ní gá go mbeadh earraí teoranta.Mar shampla, is iteoir gan teorainn é raon oscailte:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Is coitianta an t-adapter iterator [`take`] a úsáid chun iteoir gan teorainn a iompú ina cheann teoranta:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Beidh sé seo a phriontáil na huimhreacha `0` trí `4`, gach ceann ar a n-líne féin.
//!
//! Cuimhnigh nach féidir deireadh a chur le modhanna ar iteoirí gan teorainn, fiú iad siúd ar féidir toradh a chinneadh go matamaiticiúil in am teoranta.
//! Go sonrach, modhanna cosúil le [`min`], a sa bhrí ghinearálta a cheangal ar thrasnaíonn gach eilimint sa iterator, is dócha nach bhfuil a thabhairt ar ais go rathúil le haghaidh aon Iterators gan teorainn.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Ó níl!Lúb gan teorainn!
//! // `ones.min()` lúb gan teorainn, mar sin ní shroichfimid an pointe seo!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;