use crate::iter::{FusedIterator, TrustedLen};

/// Cruthaíonn sé iteálaí a ghineann luach go leisciúil uair amháin trí an dúnadh a chuirtear ar fáil a agairt.
///
/// Tá sé seo a úsáidtear go coitianta le gineadóir luach amháin i [`chain()`] de chineálacha eile atriall chur in oiriúint.
/// B`fhéidir go bhfuil iteoir agat a chlúdaíonn beagnach gach rud, ach tá cás speisialta breise ag teastáil uait.
/// B'fhéidir go bhfuil tú go feidhm a oibríonn ar Iterators, ach is gá duit ach a phróiseáil luach amháin.
///
/// Murab ionann agus [`once()`], ginfidh an fheidhm seo an luach ar iarratas.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// use std::iter;
///
/// // is é ceann an uimhir is uaigní
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // ach amháin, sin uile a fháil againn
/// assert_eq!(None, one.next());
/// ```
///
/// Shlabhrú mar aon le iterator eile.
/// Ligean le rá gur mhaith linn aithris a dhéanamh ar gach comhad den eolaire `.foo`, ach comhad cumraíochta freisin,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // ní mór dúinn a thiontú ó iterator de DirEntry-s ar iterator de PathBufs, agus mar sin úsáidimid léarscáil
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // anois, ár n-iterator ach le haghaidh ár n-comhad cumraíochta
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // slabhra an dá iteoir le chéile in aon iteálaí mór amháin
/// let files = dirs.chain(config);
///
/// // Beidh sé seo a thabhairt dúinn gach ceann de na comhaid i .foo chomh maith le .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// An iterator a toradh a fhaightear le gné amháin de chineál `A` trí chur i bhfeidhm an chlabhsúr dá bhforáiltear `F: FnOnce() -> A`.
///
///
/// Cruthaítear an `struct` seo leis an bhfeidhm [`once_with()`].
/// Féach a dhoiciméadú le haghaidh tuilleadh.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}