use crate::iter::{FusedIterator, TrustedLen};

/// Cruthaíonn sé iteálaí nua a dhéanann eilimintí de chineál `A` a athdhéanamh gan stad tríd an dúnadh a chuirtear ar fáil, an athsheoltóir, `F: FnMut() -> A`.
///
/// Iarrann an fheidhm `repeat_with()` an athsheoltóra arís agus arís eile.
///
/// Is minic a úsáidtear iteoirí gan teorainn mar `repeat_with()` le hoiriúnóirí mar [`Iterator::take()`], d`fhonn iad a dhéanamh teoranta.
///
/// Má tá an cineál eilimint an iterator de dhíth ort uirlisí [`Clone`], agus tá sé ceart go leor a choinneáil ar an eilimint foinse i gcuimhne, ba chóir duit a úsáid in ionad an fheidhm [`repeat()`].
///
///
/// Ní Tá iterator tháirgtear trí `repeat_with()` le [`DoubleEndedIterator`].
/// Má theastaíonn `repeat_with()` uait chun [`DoubleEndedIterator`] a chur ar ais, oscail eagrán GitHub le do thoil ag míniú do chás úsáide.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// use std::iter;
///
/// // déanaimis glacadh leis go bhfuil luach éigin againn de chineál nach `Clone` é nó nach dteastaíonn uainn a bheith i gcuimhne fós toisc go bhfuil sé daor:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // luach faoi leith go deo:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Ag baint úsáide as sóchán agus finideacha dul:
///
/// ```rust
/// use std::iter;
///
/// // Ón nialais go dtí an tríú cumhacht de dhá:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... agus anois táimid déanta
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Atreoraitheoir a dhéanann eilimintí de chineál `A` a athrá gan stad tríd an dúnadh `F: FnMut() -> A` a chuirtear ar fáil a chur i bhfeidhm.
///
///
/// Cruthaítear an `struct` seo leis an bhfeidhm [`repeat_with()`].
/// Féach a dhoiciméadú le haghaidh tuilleadh.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}