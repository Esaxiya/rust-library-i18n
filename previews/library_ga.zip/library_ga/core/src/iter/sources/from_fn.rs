use crate::fmt;

/// Cruthaítear iteoir nua ina nglaoitear an dúnadh `F: FnMut() -> Option<T>` ar gach atriall.
///
/// Ligeann sé seo iteoir saincheaptha a chruthú le hiompar ar bith gan an chomhréir níos briathartha a bhaineann le cineál tiomnaithe a chruthú agus an [`Iterator`] trait a chur i bhfeidhm dó.
///
/// Tabhair faoi deara nach ndéanann an t-atreoraitheoir `FromFn` toimhdí faoi iompar an dúnadh, agus dá bhrí sin ní chuireann sé [`FusedIterator`] i bhfeidhm go coimeádach, ná ní sháraíonn sé [`Iterator::size_hint()`] óna `(0, None)` réamhshocraithe.
///
///
/// Is féidir leis an dúnadh gabhálacha agus a thimpeallacht modhanna úrscothacha a rianú ar fud iterations.Ag brath ar an gcaoi a bhfuil an iterator úsáidtear, d'fhéadfadh go mbeadh ag sonrú an eochairfhocal [`move`] ar an dúnadh.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// A ligean ar ath-chur i bhfeidhm ar an iterator gcuntar ó [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Méadú ar ár gcomhaireamh.Sin é an fáth gur thosaíomar ag nialas.
///     count += 1;
///
///     // Seiceáil a fheiceáil má tá muid comhaireamh críochnaithe nó nach bhfuil.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Eagaróir ina nglaoitear an dúnadh `F: FnMut() -> Option<T>` ar gach atriall.
///
/// Seo `struct` Tá cruthaithe ag an bhfeidhm [`iter::from_fn()`].
/// Féach a dhoiciméadú le haghaidh tuilleadh.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}