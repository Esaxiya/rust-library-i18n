use crate::iter::{FusedIterator, TrustedLen};

/// Cruthaíonn sé iterator nua a dhéanann eilimint amháin a athrá gan stad.
///
/// Déanann feidhm `repeat()` luach amháin a athdhéanamh arís agus arís eile.
///
/// Is minic a úsáidtear iteoirí gan teorainn mar `repeat()` le hoiriúnóirí mar [`Iterator::take()`], d`fhonn iad a dhéanamh teoranta.
///
/// Mura gcuireann `Clone` cineál eilimint an iteora atá uait i bhfeidhm, nó mura dteastaíonn uait an eilimint arís agus arís eile a choinneáil i gcuimhne, is féidir leat an fheidhm [`repeat_with()`] a úsáid ina ionad.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// use std::iter;
///
/// // an uimhir a ceathair 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, fós ceithre
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Ag dul chun deiridh le [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // ba é an sampla deireanach sin an iomarca ceithre.Níl againn ach ceithre cheithre.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... agus anois táimid déanta
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Athraitheoir a dhéanann eilimint a athdhéanamh gan stad.
///
/// Seo `struct` Tá cruthaithe ag an bhfeidhm [`repeat()`].Féach a dhoiciméadú le haghaidh tuilleadh.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}