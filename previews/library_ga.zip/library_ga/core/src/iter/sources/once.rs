use crate::iter::{FusedIterator, TrustedLen};

/// Cruthaíonn sé iterator a thugann eilimint díreach uair amháin.
///
/// Úsáidtear é seo go coitianta chun luach amháin a oiriúnú i [`chain()`] de chineálacha eile atráchta.
/// B`fhéidir go bhfuil iteoir agat a chlúdaíonn beagnach gach rud, ach tá cás speisialta breise ag teastáil uait.
/// B'fhéidir go bhfuil tú go feidhm a oibríonn ar Iterators, ach is gá duit ach a phróiseáil luach amháin.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// use std::iter;
///
/// // is é ceann an uimhir is uaigní
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // ach amháin, sin uile a fháil againn
/// assert_eq!(None, one.next());
/// ```
///
/// Shlabhrú mar aon le iterator eile.
/// Ligean le rá gur mhaith linn aithris a dhéanamh ar gach comhad den eolaire `.foo`, ach comhad cumraíochta freisin,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // ní mór dúinn a thiontú ó iterator de DirEntry-s ar iterator de PathBufs, agus mar sin úsáidimid léarscáil
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // anois, ár n-iterator ach le haghaidh ár n-comhad cumraíochta
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // slabhra an dá iteoir le chéile in aon iteálaí mór amháin
/// let files = dirs.chain(config);
///
/// // Beidh sé seo a thabhairt dúinn gach ceann de na comhaid i .foo chomh maith le .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Atreoraitheoir a thugann eilimint díreach uair amháin.
///
/// Cruthaítear an `struct` seo leis an bhfeidhm [`once()`].Féach a dhoiciméadú le haghaidh tuilleadh.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}