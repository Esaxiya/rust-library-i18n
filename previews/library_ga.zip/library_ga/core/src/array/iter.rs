//! Sainmhíníonn an `IntoIter` úinéireacht iterator do arrays.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Atreoraitheoir [array] de réir luacha.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Is é seo an tsraith atá á athrá againn.
    ///
    /// Eilimintí le hinnéacs `i` i gcás nár tugadh `alive.start <= i < alive.end` go fóill agus is iontrálacha bailí eagar iad.
    /// Tá eilimintí le hinnéacsanna `i < alive.start` nó `i >= alive.end` tugtha cheana féin agus ní gá rochtain a fháil orthu níos mó!D`fhéadfadh na heilimintí marbha sin a bheith i riocht go hiomlán gan trácht!
    ///
    ///
    /// Mar sin is iad na hionróirí:
    /// - `data[alive]` Is beo (Tá ie gnéithe bailí)
    /// - `data[..alive.start]` agus tá `data[alive.end..]` marbh (ie na heilimintí a bhí léite cheana féin agus ní mór bheith i dteagmháil léi níos mó!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Na heilimintí in `data` nár tugadh go fóill.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Cruthaíonn sé iterator nua thar an `array` a thugtar.
    ///
    /// *Tabhair faoi deara*: d'fhéadfadh an modh seo a léig sa future, tar éis an [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Is é an cineál `value` ar `i32` anseo, in ionad `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SÁBHÁILTEACHT: Tá an t-aistriú anseo sábháilte i ndáiríre.Na docs de `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` ráthaítear go mbeidh an méid agus an t-ailíniú céanna aige
        // > mar `T`.
        //
        // Taispeánann na docs tras-aistrithe fiú ó shraith `MaybeUninit<T>` go sraith `T`.
        //
        //
        // Leis sin, initialization seo go ndeimhneoidh sé don invariants.

        // FIXME(LukasKalbertodt): úsáid iarbhír `mem::transmute` anseo, aon uair amháin-oibríonn sé le generics CONST:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Go dtí sin, is féidir linn `mem::transmute_copy` a úsáid chun cóip bitwise a chruthú mar chineál difriúil, ansin déan dearmad ar `array` ionas nach dtitfear é.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Tuairisceáin an slice immutable de na heilimintí go léir nár fuarthas go fóill.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SÁBHÁILTEACHT: Tá a fhios againn go ndéantar gach gné laistigh de `alive` a thúsú i gceart.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Filleann sé sliseog inathraithe de na heilimintí go léir nár tugadh go fóill.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SÁBHÁILTEACHT: Tá a fhios againn go ndéantar gach gné laistigh de `alive` a thúsú i gceart.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Faigh an t-innéacs seo chugainn ó thaobh tosaigh.
        //
        // Coinníonn méadú `alive.start` faoi 1 an t-invariant maidir le `alive`.
        // Mar gheall ar an athrú seo, áfach, ar feadh tamaill ghearr, ní `data[alive]` an crios beo níos mó, ach `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Léigh an eilimint ón eagar.
            // SÁBHÁILTEACHT: Is innéacs é `idx` i sean-réigiún "alive" an
            // eagar.Léamh an ghné seo ciallaíonn go bhfuil `data[idx]` mar marbh anois (ní gá ie dteagmháil).
            // Toisc gurbh é `idx` tús an chreasa bheo, tá an crios beo anois `data[alive]` arís, ag athbhunú gach ionradh.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Faigh an chéad innéacs eile ón gcúl.
        //
        // Laghdú `alive.end` faoi 1 Coinníonn an athraithe maidir le `alive`.
        // Mar sin féin, mar gheall ar an t-athrú, ar feadh tréimhse ghearr, ní `data[alive]` bhfuil an crios beo níos mó, ach `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Léigh an eilimint ón eagar.
            // SÁBHÁILTEACHT: Is innéacs é `idx` i sean-réigiún "alive" an
            // eagar.Léamh an ghné seo ciallaíonn go bhfuil `data[idx]` mar marbh anois (ní gá ie dteagmháil).
            // Toisc gurbh é `idx` deireadh an chrios beo, tá an crios beo anois `data[alive]` arís, ag athbhunú gach ionradh.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SÁBHÁILTEACHT: Tá sé seo sábháilte: `as_mut_slice` tuairisceáin díreach mar an fo-slice
        // eilimintí nár aistríodh amach go fóill agus atá fós le titim.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Ní bheidh sé ag cur thar maoil go deo mar gheall ar an invariant `live.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Tuairiscíonn an t-iteoir an fad ceart go deimhin.
// Is é líon na n-eilimintí "alive" (a thabharfar fós) fad an raoin `alive`.
// Tá an raon decremented ar fhad i gceachtar `next` nó `next_back`.
// Tá sé decremented i gcónaí ag 1 san modhanna, ach amháin má tá `Some(_)` ais.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Tabhair faoi deara, nach gá dúinn i ndáiríre a mheaitseáil leis an raon ceannann beo céanna, ionas gur féidir linn ach Clón isteach fhritháireamh 0 gan spleáchas don áit is `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Clónáil na heilimintí beo go léir.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Scríobh Clón isteach an eagar nua, thabhairt cothrom le dáta ansin a raon beo.
            // Más rud é chlónáil panics, beidh muid ag titim i gceart na míreanna roimhe seo.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Níl ach phriontáil na heilimintí nach raibh a ghineadh, go fóill: ní féidir linn teacht ar na heilimintí fuarthas níos mó.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}