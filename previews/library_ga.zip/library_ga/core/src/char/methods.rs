//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// An pointe is airde cód bailí is féidir le `char` bheith.
    ///
    /// Is [Unicode Scalar Value] é `char`, rud a chiallaíonn gur [Code Point] atá ann, ach cinn laistigh de raon áirithe amháin.
    /// `MAX` Is é an pointe cód bailí is airde atá bailí [Unicode Scalar Value].
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` Úsáidtear () in Unicode chun earráid díchódaithe a léiriú.
    ///
    /// Is féidir leis tarlú, mar shampla, nuair a thabhairt droch-déanta UTF-8 bytes go [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// An leagan de [Unicode](http://www.unicode.org/) a bhfuil na codanna Unicode de mhodhanna `char` agus `str` bunaithe air.
    ///
    /// Scaoiltear leaganacha nua de Unicode go rialta agus ina dhiaidh sin nuashonraítear gach modh sa leabharlann chaighdeánach ag brath ar Unicode.
    /// Dá bhrí sin athraíonn iompar roinnt modhanna `char` agus `str` agus luach an tairiseach seo le himeacht ama.
    /// Tá sé seo *Ní mheastar* a bheith ina athrú briseadh.
    ///
    /// Mínítear an scéim uimhrithe leaganacha in [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Cruthaigh iterator thar an UTF-16 ionchódaithe pointí cód i `iter`, ag filleadh surrogates unpaired mar `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Is féidir díchódóir caillteach a fháil tríd an gcarachtar athsholáthair a chur in ionad torthaí `Err`:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Athraíonn a `u32` chuig `char`.
    ///
    /// Tabhair faoi deara go bhfuil gach char`s`bailí [`u32`] s, agus is féidir a chaitheamh go ceann a bhfuil
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Mar sin féin, ní tá a mhalairt fíor: ní léir bailí [`u32`] s bailí char`s`.
    /// `from_u32()` seolfaidh sé `None` ar ais mura luach bailí do `char` an t-ionchur.
    ///
    /// Le haghaidh leagan neamhshábháilte den fheidhm seo a dhéanann neamhaird de na seiceálacha seo, féach [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Ag filleadh `None` nuair nach `char` bailí an t-ionchur:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Tiontaíonn sé `u32` go `char`, gan neamhaird a dhéanamh ar bhailíocht.
    ///
    /// Tabhair faoi deara go bhfuil gach char`s`bailí [`u32`] s, agus is féidir a chaitheamh go ceann a bhfuil
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Mar sin féin, ní tá a mhalairt fíor: ní léir bailí [`u32`] s bailí char`s`.
    /// `from_u32_unchecked()` Beidh bac leis, agus blindly caitheadh go `char`, b'fhéidir, a chruthú ceann neamhbhailí.
    ///
    ///
    /// # Safety
    ///
    /// Tá an fheidhm seo neamhshábháilte, toisc go bhféadfadh sí luachanna neamhbhailí `char` a thógáil.
    ///
    /// Ar leagan sábháilte fheidhm seo, féach ar an fheidhm [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // SÁBHÁILTEACHT: Ní mór an conradh sábháilteachta a sheas an té atá ag glaoch.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Athraíonn digit sa radix thabhairt do `char`.
    ///
    /// Uaireanta tugtar 'base' ar 'radix' anseo freisin.
    /// Léiríonn radix de dhá uimhir dénártha, a bunuimhir deich, deachúil, agus radix déag, hexadecimal, a thabhairt ar roinnt chomhluachanna.
    ///
    /// Tugtar tacaíocht do raidisí eadrána.
    ///
    /// `from_digit()` seolfaidh sé `None` ar ais mura dhigit é an t-ionchur sa raidiam a thugtar.
    ///
    /// # Panics
    ///
    /// Panics má thugtar gatha níos mó ná 36 dó.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Is dhigit aonair i mbonn 16 é deachúil 11
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Ag filleadh `None` nuair nach dhigit an t-ionchur:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Ag dul thar radix mór, ag cruthú panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Seiceálacha an bhfuil `char` ina dhigit sa raidiam a thugtar.
    ///
    /// Uaireanta tugtar 'base' ar 'radix' anseo freisin.
    /// Léiríonn radix de dhá uimhir dénártha, a bunuimhir deich, deachúil, agus radix déag, hexadecimal, a thabhairt ar roinnt chomhluachanna.
    ///
    /// Tugtar tacaíocht do raidisí eadrána.
    ///
    /// I gcomparáid le [`is_numeric()`], ní aithníonn an fheidhm seo ach na carachtair `0-9`, `a-z` agus `A-Z`.
    ///
    /// 'Digit' Is é an sainmhíniú a bheith ach na carachtair seo a leanas:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Chun tuiscint níos cuimsithí a fháil ar 'digit', féach [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics má thugtar gatha níos mó ná 36 dó.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Ag dul thar radix mór, ag cruthú panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Athraíonn a `char` chuig dhigit sa radix ar leith.
    ///
    /// Uaireanta tugtar 'base' ar 'radix' anseo freisin.
    /// Léiríonn radix de dhá uimhir dénártha, a bunuimhir deich, deachúil, agus radix déag, hexadecimal, a thabhairt ar roinnt chomhluachanna.
    ///
    /// Tugtar tacaíocht do raidisí eadrána.
    ///
    /// 'Digit' Is é an sainmhíniú a bheith ach na carachtair seo a leanas:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Tuairisceáin `None` mura ndéanann an `char` tagairt do dhigit sa radix tugtha.
    ///
    /// # Panics
    ///
    /// Panics má thugtar gatha níos mó ná 36 dó.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Dul thar a torthaí nach dhigit i teip:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Ag dul thar radix mór, ag cruthú panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // roinntear an cód anseo chun luas forghníomhaithe a fheabhsú i gcásanna ina bhfuil an `radix` seasmhach agus 10 nó níos lú
        //
        let val = if likely(radix <= 10) {
            // Mura dhigit é, cruthófar uimhir níos mó ná radix.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Tuairisceáin ar iterator a thuilleann an heicsidheachúlach Unicode éalú de chineál mar `char`s.
    ///
    /// Beidh sé seo éalú carachtair leis an error Rust an fhoirm `\u{NNNNNN}` ina bhfuil `NNNNNN` ionadaíocht hexadecimal.
    ///
    ///
    /// # Examples
    ///
    /// Mar iteoir:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ag baint úsáide as `println!` go díreach:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Tá an dá comhionann le:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Ag baint úsáide as `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // nó-áirítear 1 áirithíonn do c==0 na computes cód gur dhigit amháin chóir a chló agus (a bhfuil mar an gcéanna) seachnaítear an (31, 32) underflow
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // an t-innéacs na is fhigiúr suntasach heicsidheachúlach
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Tá leagan leathnaithe `escape_debug` go ceadanna optionally ag éalú Breisithe codepoints grapheme.
    /// Ligeann sé seo dúinn carachtair cosúil le marcanna nonspacing a fhormáidiú níos fearr nuair a bhíonn siad ag tús sreinge.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Tuairisceáin ar iterator a thuilleann an cód éalú litriúil de chineál mar `char`s.
    ///
    /// Éalóidh sé seo na carachtair atá cosúil le cur chun feidhme `Debug` de `str` nó `char`.
    ///
    ///
    /// # Examples
    ///
    /// Mar iteoir:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ag baint úsáide as `println!` go díreach:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Tá an dá comhionann le:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Ag baint úsáide as `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Tuairisceáin ar iterator a thuilleann an cód éalú litriúil de chineál mar `char`s.
    ///
    /// Is é an réamhshocrú roghnaithe le claonadh i dtreo litriúla atá dlíthiúil i réimse teangacha, lena n-áirítear C++ 11 agus teangacha C-teaghlaigh den chineál céanna a tháirgeadh.
    /// Is iad na rialacha cruinn:
    ///
    /// * Éalaítear Tab mar `\t`.
    /// * Éalaítear filleadh ar iompar mar `\r`.
    /// * Éalaítear beatha líne mar `\n`.
    /// * Éalaítear luachan aonair mar `\'`.
    /// * Éalaítear luachan dúbailte mar `\"`.
    /// * Éalaítear Backslash mar `\\`.
    /// * Ní éalaítear le carachtar ar bith sa raon `ASCII inphriontáilte` `0x20` .. `0x7e` go huile.
    /// * Tugtar éalaithe heicsidheachúlach Unicode do gach carachtar eile;féach [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Mar iteoir:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ag baint úsáide as `println!` go díreach:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Tá an dá comhionann le:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Ag baint úsáide as `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Filleann sé líon na mbeart a theastódh ón `char` seo dá ndéanfaí é a ionchódú i UTF-8.
    ///
    /// Bíonn an líon beart sin i gcónaí idir 1 agus 4, go huile.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Ráthaíonn Cineál `&str` go bhfuil a bhfuil ann UTF-8, agus mar sin is féidir linn a chur i gcomparáid le fad a thógfadh sé dá ionadaíocht gach uile phointe cód mar `char` vs sa `&str` féin:
    ///
    ///
    /// ```
    /// // mar chars
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // is féidir an dá cheann a léiriú mar thrí bheart
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // mar &str, tá an dá cheann seo ionchódaithe i UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // is féidir linn a fheiceáil go nglacann siad sé bytes iomlán ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... díreach cosúil leis an &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Tuairisceáin an líon na n-aonad cód 16-giotán rud é go gcaithfí `char` má ionchódaithe i UTF-16.
    ///
    ///
    /// Féach na cáipéisí le haghaidh [`len_utf8()`] chun tuilleadh míniú a fháil ar an gcoincheap seo.
    /// Is scáthán an fheidhm seo, ach do UTF-16 in ionad UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Ionchódaíonn sé an carachtar seo mar UTF-8 sa mhaolán beart a chuirtear ar fáil, agus ansin filleann sé foshraith an mhaoláin ina bhfuil an carachtar ionchódaithe.
    ///
    ///
    /// # Panics
    ///
    /// Panics mura bhfuil an maolán leor mór.
    /// Tá maolán ar fhad a ceathair mór go leor chun aon `char` a ionchódú.
    ///
    /// # Examples
    ///
    /// Sa dá de na samplaí, a thógann 'ß' dhá bytes go ionchódú.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Maolán go bhfuil ró-bheag:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // Ní `char` ar ionaid, agus mar sin tá sé seo bailí UTF-8: SÁBHÁILTEACHT.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Ionchódaíonn sé an carachtar seo mar UTF-16 sa mhaolán `u16` atá curtha ar fáil, agus ansin filleann sé foshraith an mhaoláin ina bhfuil an carachtar ionchódaithe.
    ///
    ///
    /// # Panics
    ///
    /// Panics mura bhfuil an maolán leor mór.
    /// Tá maolán ar fad 2 go leor mór a ionchódú aon `char`.
    ///
    /// # Examples
    ///
    /// Sa dá shampla seo, tógann '𝕊' dhá `u16` le hionchódú.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Maolán go bhfuil ró-bheag:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Tuairisceáin `true` má tá an mhaoin `Alphabetic` ag an `char` seo.
    ///
    /// `Alphabetic` Déantar cur síos i gCaibidil 4 (Carachtair Airíonna) den [Unicode Standard] agus a shonraítear sa [`DerivedCoreProperties.txt`] [Unicode Character Database][ucd].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // Is grá a lán rudaí, ach nach bhfuil sé aibítreach
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Tuairisceáin `true` má tá an mhaoin `Lowercase` ag an `char` seo.
    ///
    /// `Lowercase` Déantar cur síos i gCaibidil 4 (Carachtair Airíonna) den [Unicode Standard] agus a shonraítear sa [`DerivedCoreProperties.txt`] [Unicode Character Database][ucd].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Níl feidhm ag na scripteanna Síne éagsúla agus poncaíochta tá cás, agus mar sin de:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Tuairisceáin `true` má tá an `char` an maoin `Uppercase`.
    ///
    /// `Uppercase` Déantar cur síos i gCaibidil 4 (Carachtair Airíonna) den [Unicode Standard] agus a shonraítear sa [`DerivedCoreProperties.txt`] [Unicode Character Database][ucd].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Níl feidhm ag na scripteanna Síne éagsúla agus poncaíochta tá cás, agus mar sin de:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Tuairisceáin `true` má tá an `char` an maoin `White_Space`.
    ///
    /// `White_Space` sonraítear sa [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // spás neamhbhriste
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Tuairisceáin `true` más rud é seo go ndeimhneoidh sé `char` ceachtar [`is_alphabetic()`] nó [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Tuairisceáin `true` má tá an chatagóir ghinearálta le haghaidh cóid rialaithe ag an `char` seo.
    ///
    /// Déantar cur síos cóid rialaithe (pointí cód le catagóir ginearálta `Cc`) i gCaibidil 4 (Carachtair Airíonna) den [Unicode Standard] agus a shonraítear sa [`UnicodeData.txt`] [Unicode Character Database][ucd].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// // U + 009C, Terminator STRING
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Tuairisceáin `true` má tá an `char` an maoin `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` Déantar cur síos i [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] agus a shonraítear sa [`DerivedCoreProperties.txt`] [Unicode Character Database][ucd].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Tuairisceáin `true` má tá ceann de na catagóirí ginearálta uimhreacha ag an `char` seo.
    ///
    /// Sonraítear na catagóirí ginearálta d`uimhreacha (`Nd` do dhigit deachúil, `Nl` do charachtair uimhriúla cosúil le litir, agus `No` do charachtair uimhriúla eile) sa [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Tuairisceáin ar iterator a thuilleann an mapáil litreacha beaga an `char` mar aon ní amháin nó níos mó
    /// `char`s.
    ///
    /// Mura bhfuil mapáil litreacha beaga ag an `char` seo, táirgtear an `char` céanna don iterator.
    ///
    /// Má tá an `char` mapáil duine le duine litreacha beaga a thug an [`UnicodeData.txt`] [Unicode Character Database][ucd], an táirgeacht iterator sin `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Má éilíonn an `char` seo breithnithe speisialta (m.sh. il-char`s) tugann an t-atreoraitheoir na`char` (s) a thugann [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Fheidhmíonn an oibríocht ar léarscáiliú neamhchoinníollach gan oiriúint.Is é sin, tá an tiontú neamhspleách ar chomhthéacs agus ar theanga.
    ///
    /// Sa [Unicode Standard], Caibidil 4 (Airíonna Carachtair) Pléann mapáil cás go ginearálta agus i gCaibidil 3 (Conformance) Pléann an algartam réamhshocraithe maidir le comhshó cás.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Mar iteoir:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ag baint úsáide as `println!` go díreach:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Tá an dá comhionann le:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Ag baint úsáide as `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Uaireanta is é an toradh carachtar níos mó ná aon:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Tiontaíonn carachtair nach bhfuil uachtair agus litreacha beaga iontu féin.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Tuairisceáin ar iterator a thuilleann an mapáil chás uachtair an `char` mar aon ní amháin nó níos mó
    /// `char`s.
    ///
    /// Más rud é nach mbaineann sé seo `char` bhfuil mapáil chás uachtair, táirgeacht an iterator an `char` gcéanna.
    ///
    /// Má tá mapáil uachtair duine le duine ag an `char` seo a thugann an [Unicode Character Database][ucd] [`UnicodeData.txt`], táirgfidh an t-iteoir an `char` sin.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Má éilíonn an `char` seo breithnithe speisialta (m.sh. il-char`s) tugann an t-atreoraitheoir na`char` (s) a thugann [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Fheidhmíonn an oibríocht ar léarscáiliú neamhchoinníollach gan oiriúint.Is é sin, tá an tiontú neamhspleách ar chomhthéacs agus ar theanga.
    ///
    /// Sa [Unicode Standard], Caibidil 4 (Airíonna Carachtair) Pléann mapáil cás go ginearálta agus i gCaibidil 3 (Conformance) Pléann an algartam réamhshocraithe maidir le comhshó cás.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Mar iteoir:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ag baint úsáide as `println!` go díreach:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Tá an dá comhionann le:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Ag baint úsáide as `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Uaireanta is é an toradh carachtar níos mó ná aon:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Tiontaíonn carachtair nach bhfuil uachtair agus litreacha beaga iontu féin.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Nóta ar locale
    ///
    /// I Tuircis, tá comhionann 'i' sa Laidin cúig fhoirm seachas an dá cheann:
    ///
    /// * 'Dotless': I/ı, uaireanta scríofa ï
    /// * 'Dotted': İ/i
    ///
    /// Tabhair faoi deara go bhfuil an cás beag ponc 'i' mar an gcéanna leis an Laidin.Mar sin:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Braitheann luach `upper_i` anseo ar theanga an téacs: má tá muid in `en-US`, ba cheart gur `"I"` a bheadh ann, ach má táimid in `tr_TR`, ba cheart gur `"İ"` a bheadh ann.
    /// `to_uppercase()` ní a chur san áireamh, agus mar sin de:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// Tá ó theanga go teanga.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Seiceálacha má tá an luach laistigh den raon ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Déanann sé cóip den luach ina choibhéis cás uachtair ASCII.
    ///
    /// Déantar litreacha ASCII 'a' go 'z' a mhapáil go 'A' go 'Z', ach níl aon athrú ar litreacha neamh-ASCII.
    ///
    /// Chun an luach atá i bhfeidhm a shárú, úsáid [`make_ascii_uppercase()`].
    ///
    /// Chun carachtair ASCII a sheasamh i dteannta le carachtair nach carachtair ASCII iad, bain úsáid as [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Déanann sé cóip den luach ina choibhéis cás íochtair ASCII.
    ///
    /// ASCII litreacha 'A' go 'Z' mapáilte chuig 'a' go 'z', ach tá litreacha nach ASCII gan athrú.
    ///
    /// Chun an luach atá i bhfeidhm a ísliú, úsáid [`make_ascii_lowercase()`].
    ///
    /// Chun an cás íochtair carachtair ASCII sa bhreis ar carachtair neamh-ASCII, a úsáid [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Seiceálacha gur comhoiriúnú cás-neamhíogair ASCII iad dhá luach.
    ///
    /// Coibhéiseach le `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Athraíonn an cineál seo a ASCII cás uachtair coibhéiseach in-áit.
    ///
    /// Déantar litreacha ASCII 'a' go 'z' a mhapáil go 'A' go 'Z', ach níl aon athrú ar litreacha neamh-ASCII.
    ///
    /// Chun luach uachtarach nua a thabhairt ar ais gan an ceann atá ann a mhodhnú, úsáid [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Tiontaíonn sé an cineál seo go dtí a choibhéis cás íochtair ASCII atá i bhfeidhm.
    ///
    /// ASCII litreacha 'A' go 'Z' mapáilte chuig 'a' go 'z', ach tá litreacha nach ASCII gan athrú.
    ///
    /// Chun luach íslithe nua a thabhairt ar ais gan an ceann atá ann a mhodhnú, úsáid [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Seiceálacha má tá an luach ar carachtar ASCII aibítre:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', nó
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Seiceálacha má tá an luach ar ASCII chás uachtair carachtar:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Seiceálacha má tá an luach ar carachtar ASCII cás íochtair:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Seiceálacha an carachtar alfa-uimhriúil ASCII an luach:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', nó
    /// - U + 0061 'a' ..=U + 007A 'z', nó
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Seiceálacha más dhigit deachúil ASCII an luach:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Seiceálacha má tá an luach ar dhigit ASCII heicsidheachúlach:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', nó
    /// - U + 0041 'A' ..=U + 0046 'F', nó
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Seiceálacha má tá an luach ar carachtar ASCII poncaíocht:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, nó
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, nó
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, nó
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Seiceálacha má tá an luach ar carachtar ASCII grafach:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Seiceálacha má tá an luach ar carachtar ASCII spás bán:
    /// U + 0020 SPÁS, U + 0009 TÁB HORIZONTAL, U + 000A LINE FEED, FOIRM FOIRM U + 000C, nó ATHCHÓIRIÚ CARRIAGE U + 000D.
    ///
    /// Úsáideann Rust [definition of ASCII whitespace][infra-aw] WhatWG Infra Standard.Tá roinnt sainmhínithe eile in úsáid go forleathan.
    /// Mar shampla, cuimsíonn [the POSIX locale][pct] TAB VERTICAL U + 000B chomh maith leis na carachtair go léir thuas, ach-ón tsonraíocht chéanna- [measann an riail réamhshocraithe do "field splitting" sa Bourne shell][bfs]*amháin* SPÁS, TÁBLA HORIZONTAL, agus LÍNE FÉILE mar spás bán.
    ///
    ///
    /// Má tá tú ag scríobh clár a phróiseáil le formáid an chomhaid atá ann cheana féin, seiceáil cad é an fhormáid ar sainmhíniú spás bán roimh úsáid a bhaint an fheidhm seo.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Seiceálacha an carachtar rialaithe ASCII an luach:
    /// U + 0000 NUL ..=U + 001F SEPARATOR AONAD, nó U + 007F DELETE.
    /// Tabhair faoi deara gur carachtair rialaithe iad an chuid is mó de charachtair spáis bán ASCII, ach ní SPACE iad.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Ionchódaíonn sé luach amh u32 mar UTF-8 sa mhaolán beart a chuirtear ar fáil, agus ansin filleann sé foshraith an mhaoláin ina bhfuil an carachtar ionchódaithe.
///
///
/// Murab ionann agus `char::encode_utf8`, láimhseálann an modh seo códphointí sa raon ionaid.
/// (Ag cruthú `char` sa réimse ionaid UB.) Is é an toradh bailí [generalized UTF-8] ach ní bailí UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics mura bhfuil an maolán leor mór.
/// Tá maolán ar fhad a ceathair mór go leor chun aon `char` a ionchódú.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Stórálann luach u32 amh mar UTF-16 isteach sa `u16` Maolán fáil, agus ansin ar ais an t-subslice an mhaoláin ina bhfuil an carachtar ionchódaithe.
///
///
/// Murab ionann agus `char::encode_utf16`, Láimhseálann an modh seo freisin codepoints sa réimse ionaid.
/// (Is é UB a chruthaíonn `char` sa raon ionaid.)
///
/// # Panics
///
/// Panics mura bhfuil an maolán leor mór.
/// Tá maolán ar fad 2 go leor mór a ionchódú aon `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SÁBHÁILTEACHT: seiceálacha gach lámh an bhfuil dóthain píosaí a scríobh isteach
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // Titeann an BMP tríd
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Briseann plánaí forlíontacha ina ionaid.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}