//! APIs leithdháilte cuimhne

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Léiríonn an earráid `AllocError` an teip dhála d'fhéadfadh a bheith mar gheall ar ídiú acmhainní nó rud éigin cearr nuair a chéile na hargóintí ionchuir a thugtar leis an Allocator.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (Ní mór dúinn seo le haghaidh impl sruth de trait Earráid)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Is féidir le cur i bhfeidhm `Allocator` leithdháileadh, ag fás, Laghdaigh, agus GSSAPI bloic treallach na sonraí a thuairiscítear trí [`Layout`][].
///
/// `Allocator` tá sé deartha le cur i bhfeidhm ar ZSTanna, tagairtí, nó leideanna cliste toisc nach féidir leithdháilteoir mar `MyAlloc([u8; N])` a bhogadh, gan na leideanna a nuashonrú don chuimhne leithdháilte.
///
/// Murab ionann agus [`GlobalAlloc`][], ceadaítear leithdháiltí meánmhéide i `Allocator`.
/// Mura dtacaíonn leithdháilteoir bunúsach leis seo (cosúil le jemalloc) nó má thugann sé pointeoir null ar ais (mar shampla `libc::malloc`), caithfear é seo a ghabháil leis an gcur i bhfeidhm.
///
/// ### Cuimhne leithdháilte faoi láthair
///
/// Éilíonn cuid de na modhanna go leithdháilfear bloc cuimhne *faoi láthair* trí leithdháilteoir.Ciallaíonn sé sin:
///
/// * chuir [`allocate`], [`grow`], nó [`shrink`] an seoladh tosaigh don bhloc cuimhne sin ar ais roimhe seo, agus
///
/// * níor tugadh tuiscint ar an mbloc cuimhne ina dhiaidh sin, áit a ndéantar bloic a thuiscint go díreach trí iad a chur ar aghaidh go [`deallocate`] nó inar athraíodh iad trí iad a chur ar aghaidh chuig [`grow`] nó [`shrink`] a fhilleann `Ok`.
///
/// Má `grow` nó `shrink` ais `Err`, tá an pointeoir a rith bailí.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### fheistiú cuimhne
///
/// Éilíonn cuid de na modhanna go n-oirfeadh leagan amach * bloc cuimhne.
/// Is é atá i gceist le leagan amach do "fit" le bloc cuimhne (nó go coibhéiseach, le haghaidh bloc cuimhne go "fit" leagan amach) ná go gcaithfidh na coinníollacha seo a leanas a bheith:
///
/// * Caithfear an bloc a leithdháileadh leis an ailíniú céanna le [`layout.align()`], agus
///
/// * Ní mór don [`layout.size()`] fáil titim sa réimse `min ..= max`, más rud é:
///   - `min` is é méid an leagan amach is déanaí a úsáideadh chun an bloc a leithdháileadh, agus
///   - `max` is é an méid is déanaí iarbhír ar ais ó [`allocate`], [`grow`], nó [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Caithfidh bloic chuimhne a chuirtear ar ais ó leithdháilteoir cuimhne bhailí a dhíriú agus a mbailíocht a choinneáil go dtí go dtitfear an cás agus a chlóin go léir,
///
/// * chlónáil nó ag gluaiseacht an Allocator ní mór bloic cuimhne bhail má d'fhill ón Allocator.Caithfidh leithdháilteoir clónáilte é féin a iompar mar an leithdháilteoir céanna, agus
///
/// * féadfaidh aon pointeoir le bloc cuimhne atá [*currently allocated*] chur ar aghaidh chuig aon mhodh gnóthaithe eile an Allocator.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Iarrachtaí a leithdháileadh bloc de chuimhne.
    ///
    /// Nuair a éiríonn leis, seoltar [`NonNull<[u8]>`][NonNull] ar ais ag freastal ar ráthaíochtaí méide agus ailínithe `layout`.
    ///
    /// D`fhéadfadh go mbeadh méid níos mó ag an mbloc ar ais ná mar a shonraítear le `layout.size()`, agus d`fhéadfadh sé nach mbeadh a ábhar tosaithe.
    ///
    /// # Errors
    ///
    /// Tugann filleadh `Err` le fios go bhfuil ceachtar cuimhne ídithe nó nach gcomhlíonann `layout` méid an leithdháilteora nó srianta ailínithe.
    ///
    /// Implementations Spreagtar thabhairt ar ais `Err` ar ídiú chuimhne in ionad panicking nó tobscor, ach nach bhfuil sé seo riachtanas docht.
    /// (Go sonrach: is *dlíthiúil* chun an trait a chur i bhfeidhm ar bharr na craoibhe an leabharlann leithdháileadh dúchais mar bhonn leis aborts ar ídiú chuimhne.)
    ///
    /// Spreagtar cliaint ar mian leo ríomh a ghiorrú mar fhreagairt ar earráid leithdháilte feidhm [`handle_alloc_error`] a ghlaoch, seachas `panic!` nó a leithéid a agairt go díreach.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Iompraíonn sé cosúil le `allocate`, ach cinntíonn sé freisin go bhfuil an chuimhne a chuirtear ar ais nialas-tosaithe.
    ///
    /// # Errors
    ///
    /// Tugann filleadh `Err` le fios go bhfuil ceachtar cuimhne ídithe nó nach gcomhlíonann `layout` méid an leithdháilteora nó srianta ailínithe.
    ///
    /// Implementations Spreagtar thabhairt ar ais `Err` ar ídiú chuimhne in ionad panicking nó tobscor, ach nach bhfuil sé seo riachtanas docht.
    /// (Go sonrach: is *dlíthiúil* chun an trait a chur i bhfeidhm ar bharr na craoibhe an leabharlann leithdháileadh dúchais mar bhonn leis aborts ar ídiú chuimhne.)
    ///
    /// Spreagtar cliaint ar mian leo ríomh a ghiorrú mar fhreagairt ar earráid leithdháilte feidhm [`handle_alloc_error`] a ghlaoch, seachas `panic!` nó a leithéid a agairt go díreach.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SÁBHÁILTEACHT: `alloc` tuairisceáin bloc cuimhne bailí
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Déanann sé an chuimhne dá dtagraíonn `ptr` a dhí-leithdháileadh.
    ///
    /// # Safety
    ///
    /// * `ptr` caithfidh sé bloc cuimhne [*currently allocated*] a chur in iúl tríd an leithdháileadh seo, agus
    /// * `layout` ní mór [*fit*] an bloc cuimhne sin.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Iarrachtaí a leathnú an bloc chuimhne.
    ///
    /// Filleann [`NonNull<[u8]>`][NonNull] nua ina bhfuil pointeoir agus méid iarbhír na cuimhne leithdháilte.Tá an pointeoir oiriúnach chun sonraí a thuairiscíonn `new_layout` a choinneáil.
    /// Chuige sin, féadfaidh an t-Allocator an leithdháileadh tagartha ag `ptr` a leathnú a d'oirfeadh an leagan amach nua.
    ///
    /// Má fhilleann sé seo `Ok`, tá ansin úinéireacht an bhloic chuimhne tagartha ag `ptr` aistrithe chuig an Allocator.
    /// B`fhéidir gur saoradh an chuimhne nó nár scaoileadh saor í, agus ba cheart a mheas nach féidir í a úsáid mura n-aistríodh í ar ais chuig an té atá ag glaoch arís trí luach fillte an mhodha seo.
    ///
    /// Má fhilleann an modh seo `Err`, ansin níor aistríodh úinéireacht an bhloc cuimhne chuig an leithdháileadh seo, agus níl aon athrú ar ábhar an bhloc cuimhne.
    ///
    /// # Safety
    ///
    /// * `ptr` caithfidh sé bloc cuimhne [*currently allocated*] a chur in iúl tríd an leithdháileadh seo.
    /// * `old_layout` ní mór [*fit*] an bloc cuimhne sin (Ní gá go n-oirfeadh argóint `new_layout` dó.).
    /// * `new_layout.size()` Ní mór a bheith níos mó ná nó cothrom le `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Tuairisceáin `Err` más rud é nach bhfuil an leagan amach nua freastal ar an Allocator ar mhéid agus ailíniú shrianta an Allocator, nó má theipeann ar fás ar shlí eile.
    ///
    /// Implementations Spreagtar thabhairt ar ais `Err` ar ídiú chuimhne in ionad panicking nó tobscor, ach nach bhfuil sé seo riachtanas docht.
    /// (Go sonrach: is *dlíthiúil* chun an trait a chur i bhfeidhm ar bharr na craoibhe an leabharlann leithdháileadh dúchais mar bhonn leis aborts ar ídiú chuimhne.)
    ///
    /// Spreagtar cliaint ar mian leo ríomh a ghiorrú mar fhreagairt ar earráid leithdháilte feidhm [`handle_alloc_error`] a ghlaoch, seachas `panic!` nó a leithéid a agairt go díreach.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SÁBHÁILTEACHT: mar ní mór `new_layout.size()` bheith níos mó ná nó cothrom le
        // `old_layout.size()`, tá an leithdháileadh cuimhne sean agus nua bailí le haghaidh léamha agus scríobhann do bhearta `old_layout.size()`.
        // Chomh maith leis sin, toisc nár tuigeadh an sean-leithdháileadh fós, ní féidir leis forluí a dhéanamh ar `new_ptr`.
        // Dá bhrí sin, tá an glao ar `copy_nonoverlapping` sábháilte.
        // Caithfidh an té atá ag glaoch an conradh sábháilteachta do `dealloc` a sheasamh.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Iompraíonn sé cosúil le `grow`, ach cinntíonn sé freisin go socraítear an t-ábhar nua go nialas sula dtabharfar ar ais é.
    ///
    /// Beidh an t-ábhar seo a leanas sa bhloc cuimhne tar éis glao rathúil ar
    /// `grow_zeroed`:
    ///   * Caomhnaítear bearta `0..old_layout.size()` ón leithdháileadh bunaidh.
    ///   * Déanfar Bearta `old_layout.size()..old_size` a chaomhnú nó a neamhní, ag brath ar chur i bhfeidhm an leithdháilteora.
    ///   `old_size` tagraíonn sé do mhéid an bhloc cuimhne roimh an nglao `grow_zeroed`, a d`fhéadfadh a bheith níos mó ná an méid a iarradh ar dtús nuair a leithdháileadh é.
    ///   * Bytes `old_size..new_size` a zeroed.Tagraíonn `new_size` le méid an bhloic chuimhne ar ais ag an glaoch `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` caithfidh sé bloc cuimhne [*currently allocated*] a chur in iúl tríd an leithdháileadh seo.
    /// * `old_layout` ní mór [*fit*] an bloc cuimhne sin (Ní gá go n-oirfeadh argóint `new_layout` dó.).
    /// * `new_layout.size()` Ní mór a bheith níos mó ná nó cothrom le `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Tuairisceáin `Err` más rud é nach bhfuil an leagan amach nua freastal ar an Allocator ar mhéid agus ailíniú shrianta an Allocator, nó má theipeann ar fás ar shlí eile.
    ///
    /// Implementations Spreagtar thabhairt ar ais `Err` ar ídiú chuimhne in ionad panicking nó tobscor, ach nach bhfuil sé seo riachtanas docht.
    /// (Go sonrach: is *dlíthiúil* chun an trait a chur i bhfeidhm ar bharr na craoibhe an leabharlann leithdháileadh dúchais mar bhonn leis aborts ar ídiú chuimhne.)
    ///
    /// Spreagtar cliaint ar mian leo ríomh a ghiorrú mar fhreagairt ar earráid leithdháilte feidhm [`handle_alloc_error`] a ghlaoch, seachas `panic!` nó a leithéid a agairt go díreach.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SÁBHÁILTEACHT: mar ní mór `new_layout.size()` bheith níos mó ná nó cothrom le
        // `old_layout.size()`, tá an leithdháileadh cuimhne sean agus nua bailí le haghaidh léamha agus scríobhann do bhearta `old_layout.size()`.
        // Chomh maith leis sin, toisc nár tuigeadh an sean-leithdháileadh fós, ní féidir leis forluí a dhéanamh ar `new_ptr`.
        // Dá bhrí sin, tá an glao ar `copy_nonoverlapping` sábháilte.
        // Caithfidh an té atá ag glaoch an conradh sábháilteachta do `dealloc` a sheasamh.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Iarrachtaí chun Laghdaigh an bloc chuimhne.
    ///
    /// Filleann [`NonNull<[u8]>`][NonNull] nua ina bhfuil pointeoir agus méid iarbhír na cuimhne leithdháilte.Tá an pointeoir oiriúnach chun sonraí a thuairiscíonn `new_layout` a choinneáil.
    /// Chun é seo a bhaint amach, féadfaidh an leithdháilteoir an leithdháileadh dá dtagraítear ag `ptr` a chrapadh chun an leagan amach nua a oiriúnú.
    ///
    /// Má fhilleann sé seo `Ok`, tá ansin úinéireacht an bhloic chuimhne tagartha ag `ptr` aistrithe chuig an Allocator.
    /// B`fhéidir gur saoradh an chuimhne nó nár scaoileadh saor í, agus ba cheart a mheas nach féidir í a úsáid mura n-aistríodh í ar ais chuig an té atá ag glaoch arís trí luach fillte an mhodha seo.
    ///
    /// Má fhilleann an modh seo `Err`, ansin níor aistríodh úinéireacht an bhloc cuimhne chuig an leithdháileadh seo, agus níl aon athrú ar ábhar an bhloc cuimhne.
    ///
    /// # Safety
    ///
    /// * `ptr` caithfidh sé bloc cuimhne [*currently allocated*] a chur in iúl tríd an leithdháileadh seo.
    /// * `old_layout` ní mór [*fit*] an bloc cuimhne sin (Ní gá go n-oirfeadh argóint `new_layout` dó.).
    /// * `new_layout.size()` caithfidh sé a bheith níos lú ná nó cothrom le `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Tuairisceáin `Err` más rud é nach bhfuil an leagan amach nua freastal ar an Allocator ar mhéid agus ailíniú shrianta an Allocator, nó má theipeann ar crapadh ar shlí eile.
    ///
    /// Implementations Spreagtar thabhairt ar ais `Err` ar ídiú chuimhne in ionad panicking nó tobscor, ach nach bhfuil sé seo riachtanas docht.
    /// (Go sonrach: is *dlíthiúil* chun an trait a chur i bhfeidhm ar bharr na craoibhe an leabharlann leithdháileadh dúchais mar bhonn leis aborts ar ídiú chuimhne.)
    ///
    /// Spreagtar cliaint ar mian leo ríomh a ghiorrú mar fhreagairt ar earráid leithdháilte feidhm [`handle_alloc_error`] a ghlaoch, seachas `panic!` nó a leithéid a agairt go díreach.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SÁBHÁILTEACHT: mar ní mór `new_layout.size()` a bheith níos ísle ná nó cothrom le
        // `old_layout.size()`, tá an leithdháileadh cuimhne sean agus nua bailí le haghaidh léamha agus scríobhann do bhearta `new_layout.size()`.
        // Chomh maith leis sin, toisc nár tuigeadh an sean-leithdháileadh fós, ní féidir leis forluí a dhéanamh ar `new_ptr`.
        // Dá bhrí sin, tá an glao ar `copy_nonoverlapping` sábháilte.
        // Caithfidh an té atá ag glaoch an conradh sábháilteachta do `dealloc` a sheasamh.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Cruthaigh adapter "by reference" don chás seo de `Allocator`.
    ///
    /// An adapter ar ais i bhfeidhm chomh maith `Allocator` agus beidh a fháil ar iasacht go simplí seo.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta a sheasamh
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta a sheasamh
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta a sheasamh
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta a sheasamh
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}