use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Leithdháilteoir cuimhne is féidir a chlárú mar réamhshocrú na leabharlainne caighdeánach tríd an aitreabúid `#[global_allocator]`.
///
/// Éilíonn cuid de na modhanna go leithdháilfear bloc cuimhne *faoi láthair* trí leithdháilteoir.Ciallaíonn sé sin:
///
/// * tugadh an seoladh tosaigh don bhloc cuimhne sin ar ais roimhe seo le glao roimhe seo ar mhodh leithdháilte mar `alloc`, agus
///
/// * níor tugadh tuiscint ar an mbloc cuimhne ina dhiaidh sin, áit a ndéantar bloic a thuiscint trí iad a chur ar aghaidh chuig modh tuisceana mar `dealloc` nó trína gcur ar aghaidh chuig modh ath-leithdháilte a thugann pointeoir neamh-null ar ais.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// Is `unsafe` trait é an `GlobalAlloc` trait ar roinnt cúiseanna, agus ní mór do lucht feidhmithe a chinntiú go gcloíonn siad leis na conarthaí seo:
///
/// * Is iompar neamhshainithe é má scaoiltear leithdháileadh domhanda.Féadfar an srian seo a ardú sa future, ach faoi láthair d`fhéadfadh panic ó aon cheann de na feidhmeanna seo a bheith ina chúis le neamhshábháilteacht cuimhne.
///
/// * `Layout` Ní mór do cheisteanna agus ríomhaireachtaí go ginearálta a bheith ceart.Tá cead ag glaoiteoirí an trait seo brath ar na conarthaí atá sainithe ar gach modh, agus ní mór do lucht feidhmithe a chinntiú go bhfanfaidh conarthaí den sórt sin fíor.
///
/// * B`fhéidir nach mbeidh tú ag brath ar leithdháiltí a bheith ag tarlú i ndáiríre, fiú má tá leithdháiltí sainiúla carn san fhoinse.
/// Féadfaidh an optimizer leithdháiltí neamhúsáidte a bhrath ar féidir leis deireadh a chur leo go hiomlán nó bogadh go dtí an chruach agus mar sin gan an leithdháilteoir a agairt riamh.
/// Féadfaidh an optimizer glacadh leis go bhfuil an leithdháileadh infallible, mar sin d`fhéadfadh cód a bhíodh ag teip mar gheall ar theipeanna leithdháilteora oibriú go tobann anois toisc gur oibrigh an optimizer timpeall ar an ngá le leithdháileadh.
/// Go bunúsach, is é an sampla cód seo a leanas lochtach, is cuma an Ceadaíonn do Allocator saincheaptha comhaireamh cé mhéad leithdháiltí a tharla.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Tabhair faoi deara nach bhfuil na optimizations atá luaite thuas ar an leas iomlán a bhaint amháin is féidir a chur i bhfeidhm.De ghnáth ní fhéadfaidh tú a bheith ag brath ar leithdháiltí carn a dhéanamh más féidir iad a bhaint gan iompraíocht cláir a athrú.
///   Ní cuid d`iompar an chláir cibé an dtarlaíonn leithdháiltí nó nach ea, fiú dá bhféadfaí é a bhrath trí leithdháilteoir a rianaíonn leithdháiltí trí phriontáil nó fo-iarsmaí a bheith acu ar bhealach eile.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Leithdháileadh cuimhne mar a thuairiscíonn an `layout` tugtha.
    ///
    /// Cuireann pointeoir ar ais chuig cuimhne nua-leithdháilte, nó null chun teip leithdháilte a léiriú.
    ///
    /// # Safety
    ///
    /// Tá an fheidhm seo neamhshábháilte toisc go bhféadfadh iompar neamhshainithe a bheith mar thoradh mura gcinntíonn an té atá ag glaoch go bhfuil méid neamh-nialas ag `layout`.
    ///
    /// (D`fhéadfadh go gcuirfeadh fotheidil síneadh teorainneacha níos sainiúla ar iompar, m.sh. seoladh sentinel nó pointeoir null a ráthú mar fhreagairt ar iarratas ar leithdháileadh méid nialas.)
    ///
    /// Féadfar an bloc cuimhne leithdháilte a thionscnamh.
    ///
    /// # Errors
    ///
    /// Ag filleadh ar pointeoir null fios go bhfuil ceachtar chuimhne ídithe nó nach bhfuil `layout` freastal ar mhéid nó ailíniú srianta seo Allocator ar.
    ///
    /// Spreagtar cur chun feidhme chun filleadh ar ídiú cuimhne seachas ginmhilleadh, ach ní riachtanas docht é seo.
    /// (Go sonrach: is *dlíthiúil* chun an trait a chur i bhfeidhm ar bharr na craoibhe an leabharlann leithdháileadh dúchais mar bhonn leis aborts ar ídiú chuimhne.)
    ///
    /// Spreagtar cliaint ar mian leo ríomh a ghiorrú mar fhreagairt ar earráid leithdháilte feidhm [`handle_alloc_error`] a ghlaoch, seachas `panic!` nó a leithéid a agairt go díreach.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Déan an bloc cuimhne ag an pointeoir `ptr` tugtha leis an `layout` tugtha.
    ///
    /// # Safety
    ///
    /// Tá an fheidhm neamhshábháilte toisc nach féidir iompar undefined thoradh mura gcomhlíonann an té atá ag glaoch a chinntiú gach ceann díobh seo a leanas:
    ///
    ///
    /// * `ptr` caithfidh sé bloc cuimhne a leithdháileadh tríd an leithdháileadh seo a chur in iúl faoi láthair,
    ///
    /// * `layout` caithfidh gurb é an leagan amach céanna é a úsáideadh chun an bloc cuimhne sin a leithdháileadh.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Behaves cosúil `alloc`, ach freisin áirithíonn go gcomhlíontar cainníochtaí atá leagtha go náid sula dtugtar ar ais.
    ///
    /// # Safety
    ///
    /// Tá an fheidhm neamhshábháilte ar na cúiseanna céanna go bhfuil `alloc`.
    /// Ach tá an bloc a leithdháileadh de chuimhne ráthaithe a thúsú.
    ///
    /// # Errors
    ///
    /// Ag filleadh ar pointeoir null fios go bhfuil ceachtar chuimhne ídithe nó nach bhfuil `layout` freastal ar mhéid nó ailíniú srianta Allocator ar, díreach mar atá in `alloc`.
    ///
    /// Spreagtar cliaint ar mian leo ríomh a ghiorrú mar fhreagairt ar earráid leithdháilte feidhm [`handle_alloc_error`] a ghlaoch, seachas `panic!` nó a leithéid a agairt go díreach.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SÁBHÁILTEACHT: Ní mór an conradh sábháilteachta do `alloc` a sheas an té atá ag glaoch.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SÁBHÁILTEACHT: de réir mar a d`éirigh leis an leithdháileadh, tháinig an réigiún ó `ptr`
            // méid atá `size` ráthaithe a bheith bailí ar feadh scríobhann.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Laghdaigh nó fás bloc cuimhne go dtí an `new_size` a thugtar.
    /// Cuirtear síos ar an bloc ag an pointeoir `ptr` áirithe agus `layout`.
    ///
    /// Más rud é seo tuairisceáin pointeoir neamh-null, tá ansin úinéireacht an bhloic chuimhne tagartha ag `ptr` aistrithe chuig an Allocator.
    /// Féadfaidh an chuimhne nó nach féidir a bheith deallocated, agus ba chóir smaoineamh unusable (mura rud é, ar ndóigh aistríodh ar ais go dtí an té atá ag glaoch arís tríd an luach ar ais an modh seo).
    /// Leithdháiltear an bloc cuimhne nua le `layout`, ach nuashonraítear an `size` go `new_size`.
    /// Ba cheart an leagan amach nua seo a úsáid agus an bloc cuimhne nua le `dealloc` á thuiscint.
    /// Ráthaítear go mbeidh na luachanna céanna ag an raon `0..min(layout.size(), new_size) `den bhloc cuimhne nua leis an mbloc bunaidh.
    ///
    /// Má Modh seo tuairisceáin null, nach bhfuil úinéireacht sin an bhloic chuimhne d'aistriú chun an Allocator, agus tá an t-ábhar an bhloic chuimhne gan athrú.
    ///
    /// # Safety
    ///
    /// Tá an fheidhm neamhshábháilte toisc nach féidir iompar undefined thoradh mura gcomhlíonann an té atá ag glaoch a chinntiú gach ceann díobh seo a leanas:
    ///
    /// * `ptr` caithfear é a leithdháileadh tríd an leithdháileadh seo faoi láthair,
    ///
    /// * `layout` caithfidh gurb é an leagan amach céanna é a úsáideadh chun an bloc cuimhne sin a leithdháileadh,
    ///
    /// * `new_size` Ní mór a bheith níos mó ná náid.
    ///
    /// * `new_size`, nuair chothromú suas go dtí don iolraí is gaire de `layout.align()`, ní mór ní thar maoil (ie, an luach chothromú a bheith níos lú ná `usize::MAX`).
    ///
    /// (D`fhéadfadh go gcuirfeadh fotheidil síneadh teorainneacha níos sainiúla ar iompar, m.sh. seoladh sentinel nó pointeoir null a ráthú mar fhreagairt ar iarratas ar leithdháileadh méid nialas.)
    ///
    /// # Errors
    ///
    /// Tuairisceáin margadh saothair más rud é nach bhfuil an leagan amach nua le chéile ar an méid agus ailíniú shrianta an Allocator, nó má theipeann ar athdháileadh ar shlí eile.
    ///
    /// Implementations Spreagtar null maidir ídiú chuimhne a thabhairt ar ais in áit panicking nó tobscor, ach nach bhfuil sé seo riachtanas docht.
    /// (Go sonrach: is *dlíthiúil* chun an trait a chur i bhfeidhm ar bharr na craoibhe an leabharlann leithdháileadh dúchais mar bhonn leis aborts ar ídiú chuimhne.)
    ///
    /// Cliaint ar mian leo a thobscor ríomh mar fhreagra ar earráid athdháileadh a spreagadh chun glaoch ar an fheidhm [`handle_alloc_error`], in ionad agairt go díreach `panic!` nó a leithéid.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch a chinntiú nach sáraíonn an `new_size`.
        // `layout.align()` a thagann ó `Layout` agus tá sé a ráthú mar sin a bheith bailí.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SÁBHÁILTEACHT: ní mór don té atá ag glaoch go bhfuil `new_layout` níos mó ná nialas.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SÁBHÁILTEACHT: Ní féidir leis an bloc leithdháileadh cheana forluí ar an bloc nua-leithdháilte.
            // Caithfidh an té atá ag glaoch an conradh sábháilteachta do `dealloc` a sheasamh.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}