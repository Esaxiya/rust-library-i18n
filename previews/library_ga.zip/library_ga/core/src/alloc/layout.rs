use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Cé go bhfuil an fheidhm seo a úsáidtear san áit chéanna agus d'fhéadfaí a chur i bhfeidhm a inlined, na hiarrachtaí roimhe seo a dhéanamh dhéanfar amhlaidh rustc níos moille:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Leagan amach bloc cuimhne.
///
/// Déanann sampla de `Layout` cur síos ar leagan amach áirithe cuimhne.
/// Tógann tú `Layout` suas mar ionchur le tabhairt do leithdháilteoir.
///
/// Tá méid gaolmhar agus ailíniú cumhacht-dhá ag gach leagan amach.
///
/// (Tabhair faoi deara go bhfuil leaganacha amach *Níl* ag teastáil go bhfuil neamh-náid méid, cé go n-éilíonn `GlobalAlloc` go gcomhlíonfar gach iarratas cuimhne a bheith neamh-náid i méid.
/// Ní mór té atá ag glaoch a chinntiú oiread go gcomhlíontar coinníollacha mar seo, údaróidh allocators úsáid ar leith le riachtanais looser, nó bain úsáid as an `Allocator` comhéadan níos boige.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // méid an bhloc cuimhne iarrtha, arna thomhas i mbearta.
    size_: usize,

    // ailíniú an bhloc iarrtha de chuimhne, arna dtomhas i mbearta.
    // cinnteoimid gur cumhacht de bheirt é seo i gcónaí, toisc go n-éilíonn APIanna cosúil le `posix_memalign` é agus is srian réasúnta é a fhorchur ar thógálaithe Leagan Amach.
    //
    //
    // (Mar sin féin, ní éilímid go analógach `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Tógann `Layout` ó `size` agus `align` ar leith, nó seoltar `LayoutError` ar ais mura gcomhlíontar aon cheann de na coinníollacha seo a leanas:
    ///
    /// * `align` níor chóir go mbeadh sé nialas,
    ///
    /// * `align` Ní mór a bheith ina cumhacht de dhá,
    ///
    /// * `size`, nuair chothromú suas go dtí don iolraí is gaire de `align`, ní mór ní thar maoil (ie, an luach chothromú a bheith níos lú ná nó cothrom le `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (tugann cumhacht a dó le tuiscint ailíniú!=0.)

        // Is é méid cruinn:
        //   size_rounded_up=(méid + ailíniú, 1)&! (ailíniú, 1);
        //
        // Tá a fhios againn ó thuas go bhfuil ailíniú!=0.
        // Mura sáraíonn an breiseán (ailíniú, 1), ansin beidh slánú breá.
        //
        // Os a choinne sin, ní bhainfidh&-mharcáil le! (Ailíniú, 1) ach giotáin íseal-ordú.
        // Mar sin má tharlaíonn ró-shreabhadh leis an tsuim, ní féidir leis an&-mask a dhóthain a dhealú chun an ró-shreabhadh sin a chealú.
        //
        //
        // Tugann thuas le tuiscint go bhfuil seiceáil le haghaidh ró-shreabhadh suimithe riachtanach agus leordhóthanach.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SÁBHÁILTEACHT: bhí na coinníollacha le haghaidh `from_size_align_unchecked`
        // seiceáil thuas.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Cruthaíonn leagan amach, ag seachaint gach seic.
    ///
    /// # Safety
    ///
    /// Tá an fheidhm seo neamhshábháilte toisc nach bhfíoraíonn sí na réamhchoinníollacha ó [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch a chinntiú go bhfuil `align` níos mó ná nialas.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// An íosmhéid i mbearta le haghaidh bloc cuimhne den leagan amach seo.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// An t-ailíniú beart is lú le haghaidh bloc cuimhne den leagan amach seo.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Constructs a `Layout` oiriúnach do ghabháltas le luach de chineál `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SÁBHÁILTEACHT: ráthaíonn Rust an t-ailíniú mar chumhacht dhá agus
        // ráthaítear go n-oirfidh an teaglama méid + ailínithe inár spás seoltaí.
        // Mar thoradh air sin bain úsáid as an tógálaí neamhsheiceáilte anseo chun cód nach bhfuil panics a chur isteach mura bhfuil sé optamaithe go maith.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Táirgeann sé leagan amach ag cur síos ar thaifead a d`fhéadfaí a úsáid chun struchtúr tacaíochta a leithdháileadh do `T` (a d`fhéadfadh a bheith ina trait nó cineál neamhshábháilte eile cosúil le slisne).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SÁBHÁILTEACHT: Tá réasúnaíocht féach i `new` ar cén fáth seo an leagan neamhshábháilte
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Táirgeann sé leagan amach ag cur síos ar thaifead a d`fhéadfaí a úsáid chun struchtúr tacaíochta a leithdháileadh do `T` (a d`fhéadfadh a bheith ina trait nó cineál neamhshábháilte eile cosúil le slisne).
    ///
    /// # Safety
    ///
    /// Ní féidir an fheidhm seo a ghlaoch ach amháin má tá na coinníollacha seo a leanas ann:
    ///
    /// - Má tá `T` `Sized`, tá an fheidhm seo sábháilte chun glaoch i gcónaí.
    /// - Má tá an eireaball unsized na `T`:
    ///     - a [slice], ansin ní mór an fad an eireaball slice a bheith ina slánuimhir intialized, agus an méid de na *(fad dinimiciúil eireaball + statically meánmhéide réimír) luach* ar fad Ní mór oiriúnach i `isize`.
    ///     - a [trait object], ansin ní mór an chuid vtable den pointeoir pointe go dtí vtable bailí maidir le cineál `T` fuair ag coersion unsizing, agus an méid de na *luach* ar fad (eireaball dinimiciúil fad + statically meánmhéide réimír) Ní mór oiriúnach i `isize`.
    ///
    ///     - (unstable) [extern type], ansin tá an fheidhm seo sábháilte a ghlaoch i gcónaí, ach féadfaidh sí panic nó an luach mícheart a thabhairt ar ais ar bhealach eile, mar nach eol leagan amach an chineáil sheachtraigh.
    ///     Seo an t-iompar céanna le [`Layout::for_value`] ar thagairt d`eireaball den chineál seachtrach.
    ///     - a mhalairt, tá sé coimeádach nach bhfuil cead chun glaoch fheidhm seo.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SÁBHÁILTEACHT: pas againn ar feadh an réamhriachtanais de na feidhmeanna don té atá ag glaoch
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SÁBHÁILTEACHT: Tá réasúnaíocht féach i `new` ar cén fáth seo an leagan neamhshábháilte
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Cruthaíonn sé `NonNull` atá ag crochadh, ach atá ailínithe go maith don Leagan Amach seo.
    ///
    /// Tabhair faoi deara go bhféadfadh pointeoir bailí a bheith i luach an phointeora, rud a chiallaíonn nár cheart é seo a úsáid mar luach sentinel "not yet initialized".
    /// Ní mór do chineálacha a leithdháileann leisciúil an tosach feidhme a rianú ar bhealach éigin eile.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SÁBHÁILTEACHT: Tá ailínigh ráthaithe a bheith neamh-náid
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Cruthaíonn sé leagan amach a chuireann síos ar an taifead ar féidir luach a bheith aige ar an leagan amach céanna le `self`, ach atá ailínithe le hailíniú `align` (arna thomhas i mbeart).
    ///
    ///
    /// Má chomhlíonann `self` an t-ailíniú forordaithe cheana féin, ansin seoltar `self` ar ais.
    ///
    /// Tabhair faoi deara nach gcuireann an modh seo aon stuáil leis an méid foriomlán, is cuma an bhfuil ailíniú difriúil ag an leagan amach ar ais.
    /// I bhfocail eile, má tá `K` méid 16, `K.align_to(32)` beidh *fós méid 16*.
    ///
    /// Earráid ar ais má sháraíonn an teaglaim de `self.size()` agus an `align` tugtha na coinníollacha atá liostaithe in [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Tuairisceáin an méid stuáil ní mór dúinn a chur isteach i ndiaidh `self` lena chinntiú go mbeidh an seoladh seo a leanas a shásamh `align` (arna dtomhas i bytes).
    ///
    /// m.sh., má tá `self.size()` 9, ansin filleann `self.padding_needed_for(4)` 3, toisc gurb é sin an líon íosta beart de stuáil a theastaíonn chun seoladh 4-ailínithe a fháil (ag glacadh leis go dtosaíonn an bloc cuimhne comhfhreagrach ag seoladh 4-ailínithe).
    ///
    ///
    /// Tá an luach ar ais na feidhme seo aon bhrí mura bhfuil `align` cumhacht-de-dhá.
    ///
    /// Tabhair faoi deara go n-éilíonn fóntais an luacha ar ais go mbeidh `align` níos lú ná nó cothrom le hailíniú an seoladh tosaigh don bhloc cuimhne leithdháilte iomlán.Bealach amháin chun an srian seo a shásamh is ea `align <= self.align()` a chinntiú.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Is é luach cruinn:
        //   len_rounded_up=(+ ailíniú LEN, 1) agus (ailíniú, 1)!;
        // agus ansin cuirimid an difríocht stuála ar ais: `len_rounded_up - len`.
        //
        // Úsáidimid uimhríocht mhodúlach ar fud:
        //
        // 1. ráthaítear go mbeidh ailíniú> 0, mar sin ailínigh, tá 1 bailí i gcónaí.
        //
        // 2.
        // `len + align - 1` is féidir é a chur thar maoil le `align - 1` ar a mhéad, agus mar sin cinnteoidh an&-mask le `!(align - 1)` gur 001 a bheidh ann féin i gcás ró-shreafa.
        //
        //    Mar sin táirgtear an stuáil ar ais, nuair a chuirtear le `len` é, 0, a shásaíonn an t-ailíniú `align` go fánach.
        //
        // (Ar ndóigh, iarrachtaí chun bloic de chuimhne a bhfuil a méid agus thar maoil stuála ar an modh thuasluaite a leithdháileadh go gcuirfidís Tá Allocator chun toradh earráid ar aon nós.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Cruthaíonn sé leagan amach trí mhéid an leagan amach seo a shlánú suas go dtí iolraí ailíniú an leagan amach.
    ///
    ///
    /// Is ionann é seo agus toradh `padding_needed_for` a chur le méid reatha an leagan amach.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Ní féidir leis seo cur thar maoil.Ag lua ón invariant of Layout:
        // > `size`, nuair a dhéantar é a shlánú suas go dtí an iolraí is gaire de `align`,
        // > Ní mór nach thar maoil (ie, an luach chothromú a bheith níos lú ná
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Cruthaigh leagan amach cur síos ar an taifead le haghaidh cásanna `n` na `self`, le méid oiriúnach de stuáil idir gach lena chinntiú go bhfuil gach ásc mar gheall ar a mhéid a iarradh agus ailíniú.
    /// Nuair a éiríonn leis, filleann `(k, offs)` áit arb é `k` leagan amach an eagair agus is é `offs` an fad idir tús gach eilimint san eagar.
    ///
    /// Ar ró-shreabhadh uimhríochta, filleann `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Ní féidir leis seo cur thar maoil.Ag lua ón invariant of Layout:
        // > `size`, nuair a dhéantar é a shlánú suas go dtí an iolraí is gaire de `align`,
        // > Ní mór nach thar maoil (ie, an luach chothromú a bheith níos lú ná
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SÁBHÁILTEACHT: self.align ar eolas cheana féin a bheith bailí agus alloc_size bhí
        // padded cheana.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Cruthaigh leagan amach cur síos ar an taifead don `self` dhiaidh `next`, lena n-áirítear aon stuáil gá lena chinntiú go mbeidh `next` a ailíniú i gceart, ach *ní stuáil trailing*.
    ///
    /// D'fhonn a mheaitseáil C ionadaíocht Leagan `repr(C)`, ba cheart duit glaoch `pad_to_align` tar éis leathnú an leagan amach le gach réimse.
    /// (Níl aon bhealach ann chun leagan amach réamhshocraithe ionadaíochta Rust `repr(Rust)`, as it is unspecified.) a mheaitseáil
    ///
    /// Tabhair faoi deara gurb é ailíniú an leagan amach a thiocfaidh as sin uasmhéid `self` agus `next`, d`fhonn ailíniú an dá chuid a chinntiú.
    ///
    /// Tuairisceáin `Ok((k, offset))`, áit a bhfuil `k` mar leagan amach ar an taifead comhtháthaithe agus gurb é `offset` an áit choibhneasta, i mbearta, ó thús an `next` atá leabaithe sa taifead comhtháthaithe (ag glacadh leis go dtosaíonn an taifead féin ag fritháireamh 0).
    ///
    ///
    /// Ar ró-shreabhadh uimhríochta, filleann `LayoutError`.
    ///
    /// # Examples
    ///
    /// Chun an leagan amach struchtúr `#[repr(C)]` agus na fritháirimh na réimsí ó leagan amach laistigh dá réimsí ':
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Cuimhnigh bailchríoch a chur le `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // Tástáil n-oibríonn sé
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Cruthaíonn sé leagan amach a chuireann síos ar an taifead do chásanna `n` de `self`, gan aon stuáil idir gach cás.
    ///
    /// Tabhair faoi deara go bhfuil, murab ionann agus `repeat`, `repeat_packed` ní ráthaíocht go mbeidh na cásanna arís agus arís eile de `self` a chur ar chomhréim i gceart, fiú amháin má tá cás ar leith de `self` ailínithe i gceart.
    /// Is é sin le rá, má úsáidtear an leagan amach a chuir `repeat_packed` ar ais chun eagar a leithdháileadh, ní ráthaítear go mbeidh na heilimintí go léir san eagar ailínithe i gceart.
    ///
    /// Ar ró-shreabhadh uimhríochta, filleann `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Cruthaigh leagan amach cur síos ar an taifead don `self` dhiaidh `next` gan aon stuáil breise idir an dá.
    /// Ós rud é nach gcuirtear aon stuáil isteach, ní bhaineann ailíniú `next` le hábhar, agus ní ionchorpraítear é *ar chor ar bith* sa leagan amach a leanann as.
    ///
    ///
    /// Ar ró-shreabhadh uimhríochta, filleann `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Cruthaíonn sé leagan amach ag cur síos ar an taifead le haghaidh `[T; n]`.
    ///
    /// Ar ró-shreabhadh uimhríochta, filleann `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Ní shásaíonn na paraiméadair a thugtar do `Layout::from_size_align` nó do thógálaí `Layout` éigin eile a srianta doiciméadaithe.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (Ní mór dúinn seo le haghaidh impl sruth de trait Earráid)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}