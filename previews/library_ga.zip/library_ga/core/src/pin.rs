//! Cineálacha a chuireann sonraí i láthair na huaire i gcuimhne.
//!
//! Is fiú uaireanta go bhfuil rudaí a ráthaítear gan a bhogadh, sa chiall nach a socrúchán i gcuimhne a athrú, agus gur féidir brath dá bhrí sin ar.
//! Sampla den scoth de chás den sórt sin is ea struchtúir féinmheastóireachta a thógáil, mar go gcuirfidh réad a bhfuil leideanna air féin a chur ó bhail, rud a d`fhéadfadh iompar neamhshainithe a chur faoi deara.
//!
//! Ar leibhéal ard, cinntíonn [`Pin<P>`] go bhfuil suíomh cobhsaí sa chuimhne ag pointe aon phointeora `P`, rud a chiallaíonn nach féidir é a bhogadh go háit eile agus nach féidir a chuimhne a thuiscint go dtí go dtitfidh sé.Deirimid go bhfuil an pointee "pinned".Éiríonn rudaí níos caolchúisí agus iad ag plé cineálacha a chomhcheanglaíonn pinned le sonraí neamh-phinn;[see below](#projections-and-structural-pinning) le haghaidh tuilleadh sonraí.
//!
//! De réir réamhshocraithe, tá gach cineál i Rust sochorraithe.
//! Ligeann Rust gach cineál seach-luach a rith, agus ceadaíonn cineálacha pointeoir cliste coitianta mar [`Box<T>`] agus `&mut T` na luachanna atá iontu a athsholáthar agus a bhogadh: is féidir leat bogadh amach as [`Box<T>`], nó is féidir leat [`mem::swap`] a úsáid.
//! [`Pin<P>`] fillteann pointeoir cineál `P`, mar sin [`Pin`]`<`[`Box`] `<T>>`feidhmíonn sé cosúil le rialta
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>>`Faigheann thit, mar sin a dhéanamh a bhfuil ann, agus faigheann an chuimhne
//!
//! deallocated.Ar an gcaoi chéanna, tá [`Pin`]`<&mut T>`cosúil le `&mut T`.Mar sin féin, ní ligeann [`Pin<P>`] do chliaint [`Box<T>`] nó `&mut T` a fháil chun sonraí pinnáilte, rud a thugann le tuiscint nach féidir leat oibríochtaí mar [`mem::swap`] a úsáid:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` Ní mór `&mut T`, ach ní féidir linn é a fháil.
//!     // Táimid i bhfostú, ní féidir linn ábhar na dtagairtí seo a mhalartú.
//!     // D`fhéadfaimis `Pin::get_unchecked_mut` a úsáid, ach tá sé sin neamhshábháilte ar chúis:
//!     // níl cead againn é a úsáid chun rudaí a bhogadh amach as an `Pin`.
//! }
//! ```
//!
//! Is fiú a rá arís eile nach n-athraíonn [`Pin<P>`]*an fhíric go measann tiomsaitheoir Rust gach cineál a bheith sochorraithe.[`mem::swap`] fós inghlaoite d'aon `T`.Ina áit sin, cuireann [`Pin<P>`] cosc ar luachanna* áirithe * (a dtugann leideanna fillte i [`Pin<P>`] aird orthu) a bhogadh trína dhéanamh dodhéanta modhanna a éilíonn `&mut T` a ghlaoch orthu (cosúil le [`mem::swap`]).
//!
//! [`Pin<P>`] is féidir é a úsáid chun aon chineál pointeoir `P` a fhilleadh, agus dá bhrí sin idirghníomhaíonn sé le [`Deref`] agus [`DerefMut`].[`Pin<P>`] inar chóir `P: Deref` a mheas mar "`P`-style pointer" go `P::Target` pinnáilte-mar sin, [`Pin`]`<`[`Box`] `<T>>`is pointeoir faoi úinéireacht `T` pinnáilte, agus [`Pin`] `<` [`Rc`]`<T>>`Is pointeoir comhaireamh tagartha é do `T` pinn.
//! Ar mhaithe le cruinneas, tá [`Pin<P>`] ag brath ar chur chun feidhme [`Deref`] agus [`DerefMut`] gan bogadh amach as a bparaiméadar `self`, agus gan pointeoir a thabhairt ar ais go sonraí pinnáilte riamh nuair a ghlaotar orthu ar phointeoir pinnáilte.
//!
//! # `Unpin`
//!
//! Bíonn go leor cineálacha sochorraithe i gcónaí, fiú nuair a bhíonn siad pinn, toisc nach bhfuil siad ag brath ar sheoladh cobhsaí a bheith acu.Cuimsíonn sé seo na cineálacha bunúsacha go léir (cosúil le [`bool`], [`i32`], agus tagairtí) chomh maith le cineálacha nach bhfuil iontu ach na cineálacha seo.Cineálacha nach bhfuil cúram faoi pinning a chur i bhfeidhm ar an [`Unpin`] auto-trait, a chealú an éifeacht [`Pin<P>`].
//! Mar `T: Unpin`, [`Pin`]`<`[`Box`] `<T>Feidhmíonn`` agus [`Box<T>`] go comhionann, mar a dhéanann [`Pin`]`<&mut T>`agus `&mut T`.
//!
//! Tabhair faoi deara nach mbíonn tionchar ag feannadh agus [`Unpin`] ach ar an gcineál pointeáilte `P::Target`, ní ar an gcineál pointeoir `P` féin a fillte i [`Pin<P>`].Mar shampla, cibé an bhfuil [`Box<T>`] ag X056 nó nach bhfuil, níl aon éifeacht aige ar iompar [`Pin`]`<`[`Box`] `<T>>`(anseo, is é `T` an cineál pointeáilte).
//!
//! # Sampla: struchtúr féinmheastóireachta
//!
//! Sula théann muid isteach tuilleadh sonraí a mhíniú na ráthaíochtaí agus roghanna a bhaineann le `Pin<T>`, muid ag plé roinnt samplaí d'conas a d'fhéadfaí é a úsáid.
//! Thig leat [skip to where the theoretical discussion continues](#drop-guarantee) a fháil.
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Is struchtúr féinmheastóireachta é seo toisc go ndíríonn an réimse slice ar an réimse sonraí.
//! // Ní féidir linn an tiomsaitheoir a chur ar an eolas faoi sin le gnáth-thagairt, toisc nach féidir an patrún seo a thuairisciú leis na gnáthrialacha iasachta.
//! //
//! // Ina áit sin bainimid úsáid as pointeoir amh, cé gur eol nach bhfuil sé ar neamhní, mar is eol dúinn go bhfuil sé dírithe ar an tsreang.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Chun a chinntiú nach mbogann na sonraí nuair a fhilleann an fheidhm, cuirimid iad sa gcarn ina bhfanfaidh siad ar feadh shaolré an ruda, agus an t-aon bhealach chun rochtain a fháil air ná trí phointeoir dó.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // ní chruthaímid an pointeoir ach nuair a bheidh na sonraí i bhfeidhm nó mura mbeidh sé bogtha cheana féin sular thosaigh muid fiú
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // Tá a fhios againn go bhfuil sé seo sábháilte toisc nach bhfuil a mhodhnú ar réimse bogadh an struct ar fad
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Ba cheart don pointeoir pointe go dtí an suíomh ceart, a fhad is nach bhfuil an struct ar athraíodh a ionad.
//! //
//! // Idir an dá linn, tá muid saor chun bogadh an pointeoir timpeall.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Ós rud é nach gcuireann ár gcineál Unpin i bhfeidhm, ní dhéanfaidh sé seo a thiomsú:
//! // lig mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Sampla: liosta ionrach dúblach-nasctha
//!
//! I liosta ionrach dúblach-nasctha, ní leithdháileann an bailiúchán an chuimhne do na heilimintí féin i ndáiríre.
//! Tá an leithdháileadh á rialú ag na cliaint, agus is féidir le heilimintí maireachtáil ar fhráma cruachta a mhaireann níos giorra ná mar a dhéanann an bailiúchán.
//!
//! Chun é a dhéanamh an obair seo, tá gach gné leideanna chun a réamhtheachtaí agus comharba ar an liosta.Ní féidir eilimintí a chur leis ach nuair a bhíonn siad pinnáilte, toisc go gcuirfeadh bogadh na n-eilimintí timpeall na leideanna ó bhailíocht.Thairis sin, cuirfidh cur i bhfeidhm [`Drop`] eilimint liosta nasctha le leideanna a réamhtheachtaí agus a chomharba chun é féin a bhaint den liosta.
//!
//! Go ríthábhachtach, ní mór dúinn a bheith in ann brath ar [`drop`] a ghlaoch.Dá bhféadfaí gné a deallocated nó ó bhail ar shlí eile gan glaoch [`drop`], bheadh na leideanna isteach ann as a eilimintí comharsanacha bheith neamhbhailí, rud a bhriseadh an struchtúr sonraí.
//!
//! Dá bhrí sin, tagann pinning chomh maith le [`drop`] ráthaíocht-related.
//!
//! # `Drop` guarantee
//!
//! Is é cuspóir na feannadh a bheith in ann brath ar shocrúchán roinnt sonraí sa chuimhne.
//! Chun an obair seo a dhéanamh, ní amháin na sonraí a bhogadh;Tá srian freisin ar thuiscintocating, repurposing, nó neamhbhailí ar shlí eile an chuimhne a úsáidtear chun na sonraí a stóráil.
//! I ndáiríre, i gcás sonraí pinn, caithfidh tú an t-invariant a choinneáil nach mbeidh *a chuimhne neamhbhailí nó athphróiseáilte ón nóiméad a pinntear é go dtí nuair a ghlaoitear [`drop`]*.Ach aon uair amháin tuairisceáin [`drop`] nó panics, is féidir leis an chuimhne a athúsáid.
//!
//! Is féidir cuimhne a bheith "invalidated" trí thuiscintocation, ach freisin trí [`None`] a chur in ionad [`Some(v)`], nó [`Vec::set_len`] a ghlaoch go "kill" roinnt eilimintí de vector.Is féidir é a athchur trí [`ptr::write`] a úsáid chun é a fhorscríobh gan glaoch ar an destructor ar dtús.Ní cheadaítear aon chuid de seo le haghaidh sonraí pinn gan glaoch ar [`drop`].
//!
//! Is é seo go díreach an cineál ráthaíochta nach mór don liosta nasctha ionsáite ón gcuid roimhe seo feidhmiú i gceart.
//!
//! Tabhair faoi deara nach gciallaíonn *an ráthaíocht seo* nach sceitheann cuimhne!Tá sé fós go hiomlán ceart go leor riamh chun glaoch [`drop`] ar eilimint pinned (m.sh., is féidir leat glaoch i gcónaí [`mem::forget`] ar [`Pin`]`<`[`Box`] `<T>>`).Sa sampla den liosta atá nasctha go dúbailte, ní fhanfadh an eilimint sin ar an liosta.Ní féidir leat an stóráil *a shaoradh nó a athúsáid, áfach, gan glaoch ar [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Má úsáideann do chineál feannadh (mar shampla an dá shampla thuas), caithfidh tú a bheith cúramach agus [`Drop`] á chur i bhfeidhm.Bíonn an fheidhm [`drop`] `&mut self`, ach tá sé seo ar a dtugtar *, fiú má bhí do chineál pinned roimhe*!Tá sé ionann is dá dtabharfaí [`Pin::get_unchecked_mut`] ar an tiomsaitheoir go huathoibríoch.
//!
//! Ní fhéadfaidh sé seo a bheith ina chúis le fadhb i gcód sábháilte riamh toisc go dteastaíonn cód neamhshábháilte chun cineál a bhraitheann ar fheannadh a chur i bhfeidhm, ach bíodh a fhios agat go gcinnfidh tú úsáid a bhaint as feannadh i do chineál (mar shampla trí oibríocht éigin a chur i bhfeidhm ar [`Pin`]`<&Self>`no [`Pin`] `<&mut Féin>`) tá iarmhairtí do chur i bhfeidhm [`Drop`] chomh maith: an bhféadfaí gné de do chineál a bheith pinned, ní mór duit a chóireáil [`Drop`] mar cur intuigthe [`Pin`]`<&mut féin>`.
//!
//!
//! Mar shampla, d'fhéadfá `Drop` a chur i bhfeidhm mar seo a leanas:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` ceart go leor mar tá a fhios againn nach n-úsáidtear an luach seo arís i ndiaidh dó a bheith tite.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Téann an cód titim iarbhír anseo.
//!         }
//!     }
//! }
//! ```
//!
//! Tá an cineál ba cheart a bheith ag [`drop`] * ag feidhm `inner_drop`, mar sin déanann sé seo cinnte nach n-úsáideann tú `self`/`this` de thaisme ar bhealach atá i gcoimhlint le feannadh.
//!
//! Thairis sin, más `#[repr(packed)]` an cineál atá agat, bogfaidh an tiomsaitheoir réimsí timpeall go huathoibríoch le go mbeidh sé in ann iad a scaoileadh.D`fhéadfadh sé é sin a dhéanamh fiú i gcás réimsí a tharlaíonn a bheith ailínithe go leordhóthanach.Mar thoradh air sin, ní féidir leat feannadh le cineál `#[repr(packed)]` a úsáid.
//!
//! # Réamh-mheastacháin agus Feannadh Struchtúrtha
//!
//! Nuair a bhíonn tú ag obair le struchtúir phinn, éiríonn an cheist faoi conas is féidir rochtain a fháil ar réimsí an déanmhais sin ar mhodh nach dtógann ach [`Pin`]`<&mut Struct>`.
//! Is é an cur chuige is gnách modhanna cúntóra a scríobh (*réamh-mheastacháin* mar a thugtar orthu) a iompaíonn [`Pin`]`<&mut Struct>`ina thagairt don réimse, ach cén cineál ba cheart a bheith ag an tagairt sin?An é [`Pin`]`<&mut Field>`nó `&mut Field`?
//! Ardaítear an cheist chéanna leis na réimsí de `enum`, agus cineálacha container/wrapper freisin nuair san áireamh, eg [`Vec<T>`], [`Box<T>`], nó [`RefCell<T>`].
//! (Baineann an cheist seo le tagairtí inathraithe agus roinnte, ní úsáidimid ach an cás is coitianta de thagairtí inathraithe anseo le haghaidh léirithe.)
//!
//! Tarlaíonn sé gur faoi údar an struchtúir sonraí atá sé cinneadh a dhéanamh an iompaíonn an teilgean pinn do réimse áirithe [`Pin`]`<&mut Struct>`ina [`Pin`] `<&mut Field>` nó `&mut Field`.Tá roinnt srianta ann, áfach, agus is é an srian is tábhachtaí ná *comhsheasmhacht*:
//! is féidir le gach réimse a *ceachtar* réamh-mheasta le tagairt pinned,*nó* Tá pinning a bhaint mar chuid den réamh-mheastachán.
//! Má dhéantar an dá rud don réimse céanna, is dócha go mbeidh sé sin mífholláin!
//!
//! Mar údar ar struchtúr sonraí is féidir leat cinneadh a dhéanamh maidir le gach réimse cibé acu "propagates" a phiocadh sa réimse seo nó nach bhfuil.
//! Tugtar "structural" ar phionnaí a iomadaíonn freisin, toisc go leanann sé struchtúr an chineáil.
//! Sna fo-ailt seo a leanas, déanaimid cur síos ar na breithnithe a chaithfear a dhéanamh do cheachtar den dá rogha.
//!
//! ## Níl feannadh * struchtúrtha do `field`
//!
//! B`fhéidir go bhfuil an chuma air go bhfuil sé frith-iomasach go mb`fhéidir nach bhfuil réimse struchtúir phinn pinnáilte, ach sin an rogha is éasca i ndáiríre: mura gcruthaítear [`Pin`]`<&mut Field>`riamh, ní féidir aon rud a dhéanamh mícheart!Mar sin, má chinneann tú nach bhfuil feannadh struchtúrtha ag réimse éigin, níl le déanamh agat ach a chinntiú nach gcruthóidh tú tagairt pinnáilte don réimse sin riamh.
//!
//! D`fhéadfadh go mbeadh modh teilgean ag páirceanna gan feannadh struchtúrach a thiontaíonn [`Pin`]` <&mut Struct> `ina `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Tá sé seo ceart go leor toisc go bhfuil `field` riamh measfar pinned.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Féadfaidh tú `impl Unpin for Struct`*a dhéanamh fiú mura*[`Unpin`] an cineál `field`.Níl an rud a cheapann an cineál sin faoi fheannadh ábhartha nuair nach gcruthaítear aon [`Pin`]`<&mut Field>`riamh.
//!
//! ## Tá feannadh * struchtúrtha do `field`
//!
//! Is é an rogha eile ná cinneadh a dhéanamh gurb é feannadh "structural" do `field`, rud a chiallaíonn má tá an struchtúr pinnáilte ansin is amhlaidh atá an réimse.
//!
//! Ligeann sé seo teilgean a scríobh a chruthaíonn [`Pin`]`<&mut Field>`, agus mar sin le feiceáil go bhfuil an réimse pinned:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Tá sé seo ceart go leor toisc go bhfuil `field` pinned nuair a bhíonn `self`.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Mar sin féin, tá cúpla riachtanas breise ag baint le feannadh struchtúrach:
//!
//! 1. Ní mór gur [`Unpin`] an déanmhas má tá na réimsí struchtúracha uile [`Unpin`].Is é seo an réamhshocrú, ach is trait sábháilte é [`Unpin`], mar sin mar údar an déanmhais tá sé de fhreagracht ort *ní* rud mar `impl<T> Unpin for Struct<T>` a chur leis.
//! (Tabhair faoi deara go dteastaíonn cód neamhshábháilte chun oibríocht teilgean a chur leis, mar sin ní bhriseann an fhíric go bhfuil [`Unpin`] sábháilte trait an prionsabal nach gá duit a bheith buartha faoi aon cheann de seo má úsáideann tú `neamhshábháilte`.)
//! 2. Ní féidir le scriosóir an déanmhais réimsí struchtúracha a bhogadh amach óna argóint.Is é seo an pointe cruinn Ardaíodh go sa [previous section][drop-impl]: `drop` Bíonn `&mut self`, ach d'fhéadfadh an t-struct (agus dá réir sin laistigh dá réimsí) a bheith pinned roimh.
//!     Caithfidh tú a ráthú nach mbogann tú réimse taobh istigh de do chur i bhfeidhm [`Drop`].
//!     Go háirithe, mar a míníodh cheana, ciallaíonn sé seo nach mór nach é do struchtúr * a bheith `#[repr(packed)]`.
//!     Féach alt sin conas a scríobh [`drop`] ar bhealach gur féidir leis an tiomsaitheoir cabhrú leat nach bhfuil briseadh de thaisme pinning.
//! 3. Caithfidh tú a chinntiú go seasann tú leis an [`Drop` guarantee][drop-guarantee]:
//!     a luaithe a bhíonn do struchtúr pinned, ní dhéantar an chuimhne ina bhfuil an t-ábhar a fhrithscríobh ná a thuiscint gan scrios a dhéanamh ar scriosóirí an ábhair.
//!     Is féidir é seo a bheith casta, mar a chonacthas ag [`VecDeque<T>`]: Is féidir leis an destructor an [`VecDeque<T>`] theipeann chun glaoch [`drop`] ar gach gné má tá ceann de na scriostóirí panics.Sáraíonn sé seo ráthaíocht [`Drop`], toisc go bhféadfadh sé go n-éireofaí le heilimintí gan a ndícheallóir a ghlaoch.(Níl aon réamh-mheastacháin feannadh ag [`VecDeque<T>`], mar sin ní bhíonn sé seo ina chúis le míshuaimhneas.)
//! 4. Ní mór duit gan aon oibríochtaí eile a thairiscint a d`fhéadfadh go n-aistreofaí sonraí as na réimsí struchtúracha nuair a bheidh do chineál pinn.Mar shampla, má tá [`Option<T>`] sa struchtúr agus go bhfuil oibríocht cosúil le`tóg` le cineál `fn(Pin<&mut Struct<T>>) -> Option<T>` ann, is féidir an oibríocht sin a úsáid chun `T` a bhogadh amach as `Struct<T>` pinnáilte-rud a chiallaíonn nach féidir feannadh a bheith struchtúrtha don réimse a choinníonn seo sonraí.
//!
//!     Mar sampla níos casta de shonraí ag bogadh amach de chineál pinned, a shamhlú dá mbeadh [`RefCell<T>`] modh `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Ansin d`fhéadfaimis na rudaí seo a leanas a dhéanamh:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Tá sé seo tubaisteach, ciallaíonn sé gur féidir linn ábhar an [`RefCell<T>`] (ag úsáid `RefCell::get_pin_mut`) a phionáil ar dtús agus ansin an t-ábhar sin a bhogadh ag baint úsáide as an tagairt inathraithe a fuaireamar níos déanaí.
//!
//! ## Examples
//!
//! Le haghaidh cineál cosúil le [`Vec<T>`], idir féidearthachtaí (pinning struchtúrtha nó nach ea) ciall a bhaint as.
//! D'fhéadfaí [`Vec<T>`] le pinning struchtúrach ann le modhanna `get_pin`/`get_pin_mut` a fháil tagairtí heilimintí pinned.Mar sin féin, ní fhéadfadh sé *ligean*[`pop`][Vec::pop] a ghlaoch ar [`Vec<T>`] pinnáilte toisc go mbogfadh sé sin an t-ábhar (pinned ó thaobh struchtúir de)!Ní fhéadfadh sé [`push`][Vec::push] a cheadú, a d`fhéadfadh ath-leithdháileadh a dhéanamh agus dá bhrí sin an t-ábhar a bhogadh.
//!
//! A [`Vec<T>`] gan pinning struchtúrtha D'fhéadfadh `impl<T> Unpin for Vec<T>`, mar gheall ar an t-ábhar go bhfuil riamh pinned agus tá an [`Vec<T>`] féin breá le á n-aistriú chomh maith.
//! Ag an bpointe sin níl aon éifeacht ag feannadh ar an vector ar chor ar bith.
//!
//! Sa leabharlann caighdeánach, go ginearálta nach bhfuil cineálacha pointeoir pinning struchtúrtha, agus dá bhrí sin nach bhfuil siad ar fáil réamh-mheastacháin pinning.Sin é an fáth go bhfuil `Box<T>: Unpin` ag gach `T`.
//! Tá sé ciallmhar é seo a dhéanamh do chineálacha pointeora, toisc nach mbogann an `Box<T>` an `T` a bhogadh i ndáiríre: is féidir an [`Box<T>`] a aistriú go saor (aka `Unpin`) fiú mura bhfuil an `T`.Déanta na fírinne, fiú [`Pin`]`<`[`Box`] `<T>Tá>`agus [`Pin`] `<&mut T>` i gcónaí [`Unpin`] féin, ar an gcúis chéanna: tá a n-ábhar (an `T`) pinnáilte, ach is féidir na leideanna féin a bhogadh gan na sonraí pinn a bhogadh.
//! Maidir le [`Box<T>`] agus [`Pin`]`<`[`Box`] `<T>>`, Cibé an bhfuil an t-ábhar atá pinned go hiomlán neamhspleách ar cibé an bhfuil an pointeoir pinned, rud a chiallaíonn pinning * bhfuil struchtúrtha.
//!
//! Agus comhcheanglóir [`Future`] á chur i bhfeidhm, de ghnáth beidh feannadh struchtúrtha de dhíth ort don futures neadaithe, mar is gá duit tagairtí pinnáilte a fháil dóibh chun [`poll`] a ghlaoch.
//! Ach má tá aon sonraí eile nach gá a phinnáil i do chomhcheanglóir, féadfaidh tú na réimsí sin a dhéanamh neamhstruchtúrtha agus dá bhrí sin rochtain a fháil orthu go saor le tagairt inathraithe fiú nuair nach bhfuil agat ach [`Pin`]`<&mut Self>`(mar sin mar atá i do chur chun feidhme [`poll`] féin).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Pointeoir pinned.
///
/// Is é seo an wrapper ar fud chineál an pointeoir a dhéanann sin pointeoir "pin" a luach i bhfeidhm, cosc a chur le luach tagairt ag an pointeoir ó á n-aistriú ach amháin má chuireann sé [`Unpin`].
///
///
/// *Féach ar dhoiciméadú [`pin` module] le haghaidh míniú ar pinning.*
///
/// [`pin` module]: self
///
// Note: cruthaíonn an díorthach `Clone` thíos míshuaimhneas mar is féidir é a chur i bhfeidhm
// `Clone` le haghaidh tagairtí mutable.
// Féach <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> le haghaidh tuilleadh sonraí.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Ní dhíorthaítear na cur chun feidhme seo a leanas d`fhonn saincheisteanna stóinseachta a sheachaint.
// `&self.pointer` níor cheart go mbeadh rochtain ag cur chun feidhme trait neamhiontaofa.
//
// Féach <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> le haghaidh tuilleadh sonraí.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Tóg `Pin<P>` nua timpeall pointeoir ar roinnt sonraí de chineál a chuireann [`Unpin`] i bhfeidhm.
    ///
    /// Murab ionann agus `Pin::new_unchecked`, tá an modh sábháilte mar dereferences an pointeoir `P` le cineál [`Unpin`], a chealú na ráthaíochtaí pinning.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SÁBHÁILTEACHT: is é `Unpin` an luach a luaitear, agus mar sin níl aon cheanglais air
        // timpeall feannadh.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Unwraps seo `Pin<P>` filleadh ar an pointeoir bunúsacha.
    ///
    /// Éilíonn sé seo gurb é [`Unpin`] na sonraí taobh istigh den `Pin` seo ionas gur féidir linn neamhaird a dhéanamh ar na invariants feannadh agus iad á n-imfhilleadh.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Tóg `Pin<P>` nua timpeall ar thagairt do roinnt sonraí de chineál a d`fhéadfadh nó nach bhféadfadh `Unpin` a chur i bhfeidhm.
    ///
    /// Má dhéantar iarmhéideanna `pointer` ar chineál `Unpin`, ba cheart `Pin::new` a úsáid ina ionad.
    ///
    /// # Safety
    ///
    /// Tá an tógálaí seo neamhshábháilte toisc nach féidir linn a ráthú go bhfuil na sonraí a dtugann `pointer` aird orthu pinned, rud a chiallaíonn nach mbogfar na sonraí nó go mbeidh a stóráil neamhbhailí go dtí go dtitfear iad.
    /// Más rud é nach bhfuil an `Pin<P>` tógtha ráthú go bhfuil na sonraí pointí `P` chun é pinned, go bhfuil sárú an chonartha API agus d'fhéadfadh mar thoradh ar iompar undefined in oibríochtaí (safe) níos déanaí.
    ///
    /// Trí úsáid a bhaint as an modh seo, tá promise á dhéanamh agat faoi chur chun feidhme `P::Deref` agus `P::DerefMut`, má tá siad ann.
    /// Níos tábhachtaí fós, ní mór dóibh gan bogadh amach as a gcuid argóintí `self`: Glaoidh `Pin::as_mut` agus `Pin::as_ref` ar `DerefMut::deref_mut` agus `Deref::deref`*ar an pointeoir pinned* agus beidh siad ag súil go seasfaidh na modhanna seo leis na hionróirí feannadh.
    /// Thairis sin, trí ghlaoch ar an modh seo déanann tú promise nach mbogfar as na tagairtí `P` tagartha dó arís;go háirithe, níor cheart go mbeadh sé indéanta `&mut P::Target` a fháil agus ansin bogadh amach as an tagairt sin (ag úsáid, mar shampla [`mem::swap`]).
    ///
    ///
    /// Mar shampla, tá sé neamhshábháilte glaoch ar `Pin::new_unchecked` ar `&'a mut T`, cé go bhfuil tú in ann é a phionáil ar feadh an tsaoil `'a` áirithe, níl aon smacht agat ar an gcoinnítear pinn é nuair a thagann deireadh le `'a`:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Ba cheart go gciallódh sé seo nach féidir leis an bpointe `a` bogadh arís.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // An seoladh ar `a` athrú go `b` ar sliotán chairn, mar sin `a` fuair athraíodh a ionad cé go bhfuil muid ag pinned cheana é!Táimid tar éis an conradh feannadh API a shárú.
    /////
    /// }
    /// ```
    ///
    /// A luach, aon uair amháin pinned mór, fanacht pinned go deo (ach amháin a uirlisí de chineál `Unpin`).
    ///
    /// Ar an gcaoi chéanna, tá sé contúirteach `Pin::new_unchecked` a ghlaoch ar `Rc<T>` toisc go bhféadfadh ailiasanna a bheith leis na sonraí céanna nach bhfuil faoi réir na srianta feannadh:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Ba cheart go gciallódh sé seo nach féidir leis an bpointe bogadh arís.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Anois, más é `x` an t-aon tagairt amháin, tá tagairt inathraithe againn do shonraí a phionnaíomar thuas, a d`fhéadfaimis a úsáid chun iad a bhogadh mar a chonaiceamar sa sampla roimhe seo.
    ///     // Táimid tar éis sháraigh an conradh API pinning.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Faigheann tú tagairt roinnte pinned ón pointeoir pinned seo.
    ///
    /// Is modh cineálach é seo le dul ó `&Pin<Pointer<T>>` go `Pin<&T>`.
    /// Tá sé sábháilte mar, mar chuid de chonradh `Pin::new_unchecked`, ní féidir leis an bpointe bogadh tar éis `Pin<Pointer<T>>` a chruthú.
    ///
    /// "Malicious" implementations de `Pointer::Deref` a rialaigh an gcéanna amach leis an gconradh `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SÁBHÁILTEACHT: féach an cháipéisíocht ar an bhfeidhm seo
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Unwraps seo `Pin<P>` filleadh ar an pointeoir bunúsacha.
    ///
    /// # Safety
    ///
    /// Tá an fheidhm seo neamhshábháilte.Ní mór duit a ráthú go leanfaidh tú de bheith ag caitheamh leis an pointeoir `P` mar phinn tar éis duit an fheidhm seo a ghlaoch, ionas gur féidir na hionróirí ar an gcineál `Pin` a sheasamh.
    /// Mura ndéanfaidh an cód ag baint úsáide as an `P` mar thoradh air a chothabháil na invariants pinning go bhfuil sárú ar an gconradh API agus d'fhéadfadh mar thoradh ar iompar undefined in oibríochtaí (safe) níos déanaí.
    ///
    ///
    /// Más [`Unpin`] na sonraí bunúsacha, ba cheart [`Pin::into_inner`] a úsáid ina ionad.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Faigheann tú tagairt inathraithe pinned ón pointeoir pinned seo.
    ///
    /// Is modh cineálach é seo le dul ó `&mut Pin<Pointer<T>>` go `Pin<&mut T>`.
    /// Tá sé sábháilte mar, mar chuid de chonradh `Pin::new_unchecked`, ní féidir leis an bpointe bogadh tar éis `Pin<Pointer<T>>` a chruthú.
    ///
    /// "Malicious" Mar an gcéanna, cuirtear conradh `Pin::new_unchecked` i bhfeidhm mar gheall ar chur chun feidhme `Pointer::DerefMut`.
    ///
    /// Tá an modh seo úsáideach nuair a dhéanamh glaonna il le feidhmeanna a ithe an cineál pinned.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // Déan rud éigin
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` ídíonn `self`, mar sin déan an `Pin<&mut Self>` a atheagrú trí `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SÁBHÁILTEACHT: féach an cháipéisíocht ar an bhfeidhm seo
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Sannaithe luach nua do chuimhne ar chúl an tagairt pinned.
    ///
    /// Seo overwrites sonraí pinned, ach go bhfuil ceart go leor: Faigheann a destructor siúl sula overwritten, mar sin níl aon pinning ráthaíocht atá violated.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Tógann biorán nua tríd an luach istigh a mhapáil.
    ///
    /// Mar shampla, más rud é go raibh tú a fháil ar `Pin` de réimse de rud éigin, d'fhéadfá a úsáid chun rochtain a fháil ar réimse sin a fháil i líne amháin de chód.
    /// Mar sin féin, tá roinnt gotchas leis na "pinning projections" seo;
    /// féach cáipéisíocht [`pin` module] le haghaidh tuilleadh sonraí ar an ábhar sin.
    ///
    /// # Safety
    ///
    /// Tá an fheidhm seo neamhshábháilte.
    /// Caithfidh tú a ráthú nach mbogfaidh na sonraí a fhillfidh tú chomh fada agus nach mbogfaidh luach na hargóna (mar shampla, toisc go bhfuil siad ar cheann de na réimsí den luach sin), agus freisin nach mbogann tú as an argóint a fhaigheann tú an fheidhm istigh.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SÁBHÁILTEACHT: caithfidh an conradh sábháilteachta do `new_unchecked` a bheith
        // sheas an té atá ag glaoch leis.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Faigheann tagairt arna gcionroinnt ar bioráin.
    ///
    /// Tá sé seo sábháilte toisc nach bhfuil sé indéanta a bhogadh amach as tagairt roinnte.
    /// Féadfaidh sé cosúil cosúil go bhfuil ceist anseo le mutability istigh: go deimhin, is * * is féidir a bhogadh ar `T` as `&RefCell<T>`.
    /// Ní fadhb í seo, áfach, fad nach bhfuil `Pin<&T>` ann freisin a dhíríonn ar na sonraí céanna, agus ní ligeann `RefCell<T>` duit tagairt pinnáilte a chruthú dá bhfuil ann.
    ///
    /// Féach an plé ar ["pinning projections"] le haghaidh tuilleadh sonraí.
    ///
    /// Note: Cuireann `Pin` `Deref` i bhfeidhm ar an sprioc freisin, ar féidir a úsáid chun an luach istigh a rochtain.
    /// Mar sin féin, ní sholáthraíonn `Deref` ach tagairt a mhaireann chomh fada le hiasacht an `Pin`, ní le saolré an `Pin` féin.
    /// Ligeann an modh seo an `Pin` a iompú ina thagairt a bhfuil an saolré céanna aige agus an `Pin` bunaidh.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Tiontaíonn sé an `Pin<&mut T>` seo ina `Pin<&T>` leis an saolré céanna.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Faigheann tagairt inathraithe do na sonraí taobh istigh den `Pin` seo.
    ///
    /// Éilíonn sé seo gurb é `Unpin` na sonraí taobh istigh den `Pin` seo.
    ///
    /// Note: `Pin` i bhfeidhm freisin `DerefMut` ar na sonraí, is féidir a úsáid chun rochtain ar an luach istigh.
    /// Mar sin féin, ní sholáthraíonn `DerefMut` ach tagairt a mhaireann chomh fada le hiasacht an `Pin`, ní le saolré an `Pin` féin.
    ///
    /// Ligeann an modh seo an `Pin` a iompú ina thagairt a bhfuil an saolré céanna aige agus an `Pin` bunaidh.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Faigheann tagairt inathraithe do na sonraí taobh istigh den `Pin` seo.
    ///
    /// # Safety
    ///
    /// Tá an fheidhm seo neamhshábháilte.
    /// Ní mór duit a ráthú nach mbogfaidh tú na sonraí go deo as an tagairt inathraithe a gheobhaidh tú nuair a ghlaonn tú an fheidhm seo, ionas gur féidir seasamh leis na invariants ar an gcineál `Pin`.
    ///
    ///
    /// Más `Unpin` na sonraí bunúsacha, ba cheart `Pin::get_mut` a úsáid ina ionad.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Tóg biorán nua tríd an luach istigh a mhapáil.
    ///
    /// Mar shampla, más rud é go raibh tú a fháil ar `Pin` de réimse de rud éigin, d'fhéadfá a úsáid chun rochtain a fháil ar réimse sin a fháil i líne amháin de chód.
    /// Mar sin féin, tá roinnt gotchas leis na "pinning projections" seo;
    /// féach cáipéisíocht [`pin` module] le haghaidh tuilleadh sonraí ar an ábhar sin.
    ///
    /// # Safety
    ///
    /// Tá an fheidhm seo neamhshábháilte.
    /// Caithfidh tú a ráthú nach mbogfaidh na sonraí a fhillfidh tú chomh fada agus nach mbogfaidh luach na hargóna (mar shampla, toisc go bhfuil siad ar cheann de na réimsí den luach sin), agus freisin nach mbogann tú as an argóint a fhaigheann tú an fheidhm istigh.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SÁBHÁILTEACHT: Tá an té atá ag glaoch freagrach as nach bhfuil ag gluaiseacht ar an
        // Is mór amach as an tagairt.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SÁBHÁILTEACHT: toisc go ráthaítear nach mbeidh luach `this` ann
        // bogtha amach, tá an glao seo go `new_unchecked` sábháilte.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Faigh tagairt phinn ó thagairt statach.
    ///
    /// Tá sé seo sábháilte, toisc go bhfaightear `T` ar iasacht ar feadh shaolré `'static`, nach gcríochnaíonn choíche.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SÁBHÁILTEACHT: Ráthaíonn an 'iasacht statach nach mbeidh na sonraí
        // moved/invalidated go dtí go dtitfidh sé (rud nach bhfuil riamh).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Faigh tagairt in-aistrithe pinned ó thagairt statach mutable.
    ///
    /// Tá sé seo sábháilte, toisc go bhfaightear `T` ar iasacht ar feadh shaolré `'static`, nach gcríochnaíonn choíche.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SÁBHÁILTEACHT: Ráthaíonn an 'iasacht statach nach mbeidh na sonraí
        // moved/invalidated go dtí go dtitfidh sé (rud nach bhfuil riamh).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: ciallaíonn sé seo go bhfuil aon impl de `CoerceUnsized` a cheadaíonn comhéigniú ó
// tá cineál a chuireann `Deref<Target=impl !Unpin>` i bhfeidhm ar chineál a chuireann `Deref<Target=Unpin>` as a riocht.
// Is dócha go mbeadh aon impl den sórt sin míchuí ar chúiseanna eile, áfach, mar sin ní mór dúinn a bheith cúramach gan ligean do impls den sórt sin teacht i dtír i std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}