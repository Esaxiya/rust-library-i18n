//! Intreacha tiomsaitheora.
//!
//! Tá na sainmhínithe comhfhreagracha in `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Is iad na implementations CONST comhfhreagrach i `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intricsics
//!
//! Note: ba chóir aon athruithe ar an constness na intrinsics a phlé leis an bhfoireann teanga.
//! Áirítear leis seo athruithe ar chobhsaíocht an seasmhachta.
//!
//! D'fhonn a dhéanamh ar inúsáidte intreach ag thiomsú-am, riachtanais amháin a chóipeáil chun feidhme ó <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> go `compiler/rustc_mir/src/interpret/intrinsics.rs` agus `#[rustc_const_unstable(feature = "foo", issue = "01234")]` chur leis an intreach.
//!
//!
//! Má tá an bunúsach ceaptha a bheidh le húsáid ó `const fn` le tréith `rustc_const_stable`, ní mór don intreach ar tréith a `rustc_const_stable`, freisin.
//! Níor cheart athrú den sórt sin a dhéanamh gan comhairliúchán T-lang, toisc go dtógann sé gné isteach sa teanga nach féidir a mhacasamhlú i gcód úsáideora gan tacaíocht tiomsaitheora.
//!
//! # Volatiles
//!
//! Soláthraíonn na intreacha luaineachta oibríochtaí a bhfuil sé mar aidhm acu gníomhú ar chuimhne I/O, a ráthaítear nach n-athainmneoidh an tiomsaitheoir iad ar fud intreacha luaineachta eile.Féach cáipéisíocht LLVM ar [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Soláthraíonn an intrinsics adamhach oibríochtaí adamhacha coitianta ar mheaisínfhocail, agus tá iliomad orduithe cuimhne féideartha ann.Géilleann siad do na séimeantaicí céanna le C++ 11.Féach cáipéisíocht LLVM ar [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! A athnuachana gasta ar ordú cuimhne:
//!
//! * Faigh, bacainn ar ghlas a fháil.Tarlaíonn léamha agus scríbhinní ina dhiaidh sin tar éis an bhacainn.
//! * Scaoileadh, bacainn ar ghlas a scaoileadh.Tarlaíonn léamh agus scríobh roimh an mbacainn.
//! * Ráthaítear go dtarlóidh oibríochtaí atá comhsheasmhach go seicheamhach, comhsheasmhach go seicheamhach in ord.Is é seo an modh caighdeánach do bheith ag obair le cineálacha adamhach agus is ionann `volatile` Java ar.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Úsáidtear na hallmhairí seo chun naisc laistigh de doc a shimpliú
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SÁBHÁILTEACHT: féach `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, a chur ar na intrinsics leideanna amh toisc mutate siad chuimhne aliased, nach bhfuil bailí ar feadh ceachtar `&` nó `&mut`.
    //

    /// Stórálann sé luach má tá an luach reatha mar an gcéanna leis an luach `old`.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `compare_exchange` trí [`Ordering::SeqCst`] a rith mar pharaiméadair `success` agus `failure` araon.
    ///
    /// Mar shampla, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stórálann sé luach má tá an luach reatha mar an gcéanna leis an luach `old`.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `compare_exchange` trí [`Ordering::Acquire`] a rith mar pharaiméadair `success` agus `failure` araon.
    ///
    /// Mar shampla, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stórálann sé luach má tá an luach reatha mar an gcéanna leis an luach `old`.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `compare_exchange` trí [`Ordering::Release`] a rith mar an `success` agus [`Ordering::Relaxed`] mar pharaiméadair `failure`.
    /// Mar shampla, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stórálann sé luach má tá an luach reatha mar an gcéanna leis an luach `old`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `compare_exchange` ag rith [`Ordering::AcqRel`] mar `success` agus [`Ordering::Acquire`] mar na paraiméadair `failure`.
    /// Mar shampla, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stórálann sé luach má tá an luach reatha mar an gcéanna leis an luach `old`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `compare_exchange` ag rith [`Ordering::Relaxed`] mar na paraiméadair `success` agus `failure` araon.
    ///
    /// Mar shampla, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stórálann sé luach má tá an luach reatha mar an gcéanna leis an luach `old`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `compare_exchange` ag rith [`Ordering::SeqCst`] mar `success` agus [`Ordering::Relaxed`] mar na paraiméadair `failure`.
    /// Mar shampla, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stórálann sé luach má tá an luach reatha mar an gcéanna leis an luach `old`.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `compare_exchange` trí [`Ordering::SeqCst`] a rith mar an `success` agus [`Ordering::Acquire`] mar pharaiméadair `failure`.
    /// Mar shampla, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stórálann sé luach má tá an luach reatha mar an gcéanna leis an luach `old`.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `compare_exchange` trí [`Ordering::Acquire`] a rith mar an `success` agus [`Ordering::Relaxed`] mar pharaiméadair `failure`.
    /// Mar shampla, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stórálann sé luach má tá an luach reatha mar an gcéanna leis an luach `old`.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `compare_exchange` trí [`Ordering::AcqRel`] a rith mar an `success` agus [`Ordering::Relaxed`] mar pharaiméadair `failure`.
    /// Mar shampla, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Stórálann sé luach má tá an luach reatha mar an gcéanna leis an luach `old`.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `compare_exchange_weak` trí [`Ordering::SeqCst`] a rith mar pharaiméadair `success` agus `failure` araon.
    ///
    /// Mar shampla, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stórálann sé luach má tá an luach reatha mar an gcéanna leis an luach `old`.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `compare_exchange_weak` trí [`Ordering::Acquire`] a rith mar pharaiméadair `success` agus `failure` araon.
    ///
    /// Mar shampla, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stórálann sé luach má tá an luach reatha mar an gcéanna leis an luach `old`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `compare_exchange_weak` ag rith [`Ordering::Release`] mar `success` agus [`Ordering::Relaxed`] mar na paraiméadair `failure`.
    /// Mar shampla, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stórálann sé luach má tá an luach reatha mar an gcéanna leis an luach `old`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `compare_exchange_weak` ag rith [`Ordering::AcqRel`] mar `success` agus [`Ordering::Acquire`] mar na paraiméadair `failure`.
    /// Mar shampla, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stórálann sé luach má tá an luach reatha mar an gcéanna leis an luach `old`.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `compare_exchange_weak` trí [`Ordering::Relaxed`] a rith mar pharaiméadair `success` agus `failure` araon.
    ///
    /// Mar shampla, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stórálann sé luach má tá an luach reatha mar an gcéanna leis an luach `old`.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `compare_exchange_weak` trí [`Ordering::SeqCst`] a rith mar an `success` agus [`Ordering::Relaxed`] mar pharaiméadair `failure`.
    /// Mar shampla, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stórálann sé luach má tá an luach reatha mar an gcéanna leis an luach `old`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `compare_exchange_weak` ag rith [`Ordering::SeqCst`] mar `success` agus [`Ordering::Acquire`] mar na paraiméadair `failure`.
    /// Mar shampla, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stórálann sé luach má tá an luach reatha mar an gcéanna leis an luach `old`.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `compare_exchange_weak` trí [`Ordering::Acquire`] a rith mar an `success` agus [`Ordering::Relaxed`] mar pharaiméadair `failure`.
    /// Mar shampla, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Stórálann sé luach má tá an luach reatha mar an gcéanna leis an luach `old`.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `compare_exchange_weak` trí [`Ordering::AcqRel`] a rith mar an `success` agus [`Ordering::Relaxed`] mar pharaiméadair `failure`.
    /// Mar shampla, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Luchtaíonn sé luach reatha an phointeora.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `load` ag rith [`Ordering::SeqCst`] mar an `order`.
    /// Mar shampla, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Luchtaíonn sé luach reatha an phointeora.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `load` ag rith [`Ordering::Acquire`] mar an `order`.
    /// Mar shampla, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Luchtaíonn sé luach reatha an phointeora.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `load` trí [`Ordering::Relaxed`] a rith mar an `order`.
    /// Mar shampla, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Stórálann sé an luach ag an suíomh cuimhne sonraithe.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `store` ag rith [`Ordering::SeqCst`] mar an `order`.
    /// Mar shampla, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Stórálann sé an luach ag an suíomh cuimhne sonraithe.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `store` ag rith [`Ordering::Release`] mar an `order`.
    /// Mar shampla, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Stórálann sé an luach ag an suíomh cuimhne sonraithe.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `store` ag rith [`Ordering::Relaxed`] mar an `order`.
    /// Mar shampla, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Siopaí an luach ag an suíomh chuimhne sonraithe, ag filleadh ar an luach d'aois.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `swap` ag rith [`Ordering::SeqCst`] mar an `order`.
    /// Mar shampla, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Siopaí an luach ag an suíomh chuimhne sonraithe, ag filleadh ar an luach d'aois.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `swap` trí [`Ordering::Acquire`] a rith mar an `order`.
    /// Mar shampla, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Siopaí an luach ag an suíomh chuimhne sonraithe, ag filleadh ar an luach d'aois.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `swap` trí [`Ordering::Release`] a rith mar an `order`.
    /// Mar shampla, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Siopaí an luach ag an suíomh chuimhne sonraithe, ag filleadh ar an luach d'aois.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `swap` ag rith [`Ordering::AcqRel`] mar an `order`.
    /// Mar shampla, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Siopaí an luach ag an suíomh chuimhne sonraithe, ag filleadh ar an luach d'aois.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `swap` ag rith [`Ordering::Relaxed`] mar an `order`.
    /// Mar shampla, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Cuireann sé leis an luach reatha, ag filleadh an luacha roimhe seo.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_add` ag rith [`Ordering::SeqCst`] mar an `order`.
    /// Mar shampla, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Cuireann sé leis an luach reatha, ag filleadh an luacha roimhe seo.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_add` trí [`Ordering::Acquire`] a rith mar an `order`.
    /// Mar shampla, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Cuireann sé leis an luach reatha, ag filleadh an luacha roimhe seo.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_add` ag rith [`Ordering::Release`] mar an `order`.
    /// Mar shampla, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Cuireann sé leis an luach reatha, ag filleadh an luacha roimhe seo.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_add` ag rith [`Ordering::AcqRel`] mar an `order`.
    /// Mar shampla, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Cuireann sé leis an luach reatha, ag filleadh an luacha roimhe seo.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_add` ag rith [`Ordering::Relaxed`] mar an `order`.
    /// Mar shampla, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Dealaigh ón luach reatha, ag filleadh an luacha roimhe seo.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_sub` trí [`Ordering::SeqCst`] a rith mar an `order`.
    /// Mar shampla, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dealaigh ón luach reatha, ag filleadh an luacha roimhe seo.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_sub` trí [`Ordering::Acquire`] a rith mar an `order`.
    /// Mar shampla, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dealaigh ón luach reatha, ag filleadh an luacha roimhe seo.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_sub` ag rith [`Ordering::Release`] mar an `order`.
    /// Mar shampla, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dealaigh ón luach reatha, ag filleadh an luacha roimhe seo.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_sub` trí [`Ordering::AcqRel`] a rith mar an `order`.
    /// Mar shampla, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dealaigh ón luach reatha, ag filleadh an luacha roimhe seo.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_sub` trí [`Ordering::Relaxed`] a rith mar an `order`.
    /// Mar shampla, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise agus leis an luach reatha, ag filleadh an luach roimhe seo.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_and` ag rith [`Ordering::SeqCst`] mar an `order`.
    /// Mar shampla, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise agus leis an luach reatha, ag filleadh an luach roimhe seo.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_and` ag rith [`Ordering::Acquire`] mar an `order`.
    /// Mar shampla, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise agus leis an luach reatha, ag filleadh an luach roimhe seo.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_and` ag rith [`Ordering::Release`] mar an `order`.
    /// Mar shampla, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise agus leis an luach reatha, ag filleadh an luach roimhe seo.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_and` ag rith [`Ordering::AcqRel`] mar an `order`.
    /// Mar shampla, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise agus leis an luach reatha, ag filleadh an luach roimhe seo.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_and` ag rith [`Ordering::Relaxed`] mar an `order`.
    /// Mar shampla, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Filleann NAND bitwise leis an luach atá ann faoi láthair, ag filleadh ar an luach roimhe.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar an gcineál [`AtomicBool`] tríd an modh `fetch_nand` ag rith [`Ordering::SeqCst`] mar an `order`.
    /// Mar shampla, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Filleann NAND bitwise leis an luach atá ann faoi láthair, ag filleadh ar an luach roimhe.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar an gcineál [`AtomicBool`] tríd an modh `fetch_nand` trí [`Ordering::Acquire`] a rith mar an `order`.
    /// Mar shampla, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Filleann NAND bitwise leis an luach atá ann faoi láthair, ag filleadh ar an luach roimhe.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar an gcineál [`AtomicBool`] tríd an modh `fetch_nand` trí [`Ordering::Release`] a rith mar an `order`.
    /// Mar shampla, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Filleann NAND bitwise leis an luach atá ann faoi láthair, ag filleadh ar an luach roimhe.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar an gcineál [`AtomicBool`] tríd an modh `fetch_nand` trí [`Ordering::AcqRel`] a rith mar an `order`.
    /// Mar shampla, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Filleann NAND bitwise leis an luach atá ann faoi láthair, ag filleadh ar an luach roimhe.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar an gcineál [`AtomicBool`] tríd an modh `fetch_nand` trí [`Ordering::Relaxed`] a rith mar an `order`.
    /// Mar shampla, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nó leis an luach atá ann faoi láthair, ag filleadh ar an luach roimhe.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_or` trí [`Ordering::SeqCst`] a rith mar an `order`.
    /// Mar shampla, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nó leis an luach atá ann faoi láthair, ag filleadh ar an luach roimhe.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_or` trí [`Ordering::Acquire`] a rith mar an `order`.
    /// Mar shampla, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nó leis an luach atá ann faoi láthair, ag filleadh ar an luach roimhe.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_or` ag rith [`Ordering::Release`] mar an `order`.
    /// Mar shampla, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nó leis an luach atá ann faoi láthair, ag filleadh ar an luach roimhe.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_or` ag rith [`Ordering::AcqRel`] mar an `order`.
    /// Mar shampla, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nó leis an luach atá ann faoi láthair, ag filleadh ar an luach roimhe.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_or` ag rith [`Ordering::Relaxed`] mar an `order`.
    /// Mar shampla, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// XOR bitwise leis an luach atá ann faoi láthair, ag filleadh ar an luach roimhe.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_xor` trí [`Ordering::SeqCst`] a rith mar an `order`.
    /// Mar shampla, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// XOR bitwise leis an luach atá ann faoi láthair, ag filleadh ar an luach roimhe.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_xor` ag rith [`Ordering::Acquire`] mar an `order`.
    /// Mar shampla, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// XOR bitwise leis an luach atá ann faoi láthair, ag filleadh ar an luach roimhe.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_xor` trí [`Ordering::Release`] a rith mar an `order`.
    /// Mar shampla, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// XOR bitwise leis an luach atá ann faoi láthair, ag filleadh ar an luach roimhe.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_xor` ag rith [`Ordering::AcqRel`] mar an `order`.
    /// Mar shampla, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// XOR bitwise leis an luach atá ann faoi láthair, ag filleadh ar an luach roimhe.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha [`atomic`] tríd an modh `fetch_xor` trí [`Ordering::Relaxed`] a rith mar an `order`.
    /// Mar shampla, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Uasmhéid leis an luach reatha ag baint úsáide as comparáid shínithe.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha slánuimhir sínithe [`atomic`] tríd an modh `fetch_max` trí [`Ordering::SeqCst`] a rith mar an `order`.
    /// Mar shampla, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uasmhéid leis an luach reatha ag baint úsáide as comparáid shínithe.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar an [`atomic`] sínithe slánuimhir cineálacha tríd an modh `fetch_max` ag rith [`Ordering::Acquire`] mar an `order`.
    /// Mar shampla, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uasmhéid leis an luach reatha ag baint úsáide as comparáid shínithe.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar an [`atomic`] sínithe slánuimhir cineálacha tríd an modh `fetch_max` ag rith [`Ordering::Release`] mar an `order`.
    /// Mar shampla, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uasmhéid leis an luach reatha ag baint úsáide as comparáid shínithe.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha slánuimhir sínithe [`atomic`] tríd an modh `fetch_max` trí [`Ordering::AcqRel`] a rith mar an `order`.
    /// Mar shampla, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uasmhéid leis an luach reatha.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar an [`atomic`] sínithe slánuimhir cineálacha tríd an modh `fetch_max` ag rith [`Ordering::Relaxed`] mar an `order`.
    /// Mar shampla, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Íosmhéid leis an luach reatha ag úsáid comparáide sínithe.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha slánuimhir sínithe [`atomic`] tríd an modh `fetch_min` trí [`Ordering::SeqCst`] a rith mar an `order`.
    /// Mar shampla, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Íosmhéid leis an luach reatha ag úsáid comparáide sínithe.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar an [`atomic`] sínithe slánuimhir cineálacha tríd an modh `fetch_min` ag rith [`Ordering::Acquire`] mar an `order`.
    /// Mar shampla, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Íosmhéid leis an luach reatha ag úsáid comparáide sínithe.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha slánuimhir sínithe [`atomic`] tríd an modh `fetch_min` trí [`Ordering::Release`] a rith mar an `order`.
    /// Mar shampla, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Íosmhéid leis an luach reatha ag úsáid comparáide sínithe.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha slánuimhir sínithe [`atomic`] tríd an modh `fetch_min` trí [`Ordering::AcqRel`] a rith mar an `order`.
    /// Mar shampla, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Íosmhéid leis an luach reatha ag úsáid comparáide sínithe.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha slánuimhir sínithe [`atomic`] tríd an modh `fetch_min` trí [`Ordering::Relaxed`] a rith mar an `order`.
    /// Mar shampla, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Íosta leis an luach atá ann faoi láthair ag baint úsáide as comparáid gan síniú.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha slánuimhir neamhshínithe [`atomic`] tríd an modh `fetch_min` trí [`Ordering::SeqCst`] a rith mar an `order`.
    /// Mar shampla, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Íosta leis an luach atá ann faoi láthair ag baint úsáide as comparáid gan síniú.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha slánuimhir neamhshínithe [`atomic`] tríd an modh `fetch_min` trí [`Ordering::Acquire`] a rith mar an `order`.
    /// Mar shampla, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Íosta leis an luach atá ann faoi láthair ag baint úsáide as comparáid gan síniú.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha slánuimhir neamhshínithe [`atomic`] tríd an modh `fetch_min` trí [`Ordering::Release`] a rith mar an `order`.
    /// Mar shampla, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Íosta leis an luach atá ann faoi láthair ag baint úsáide as comparáid gan síniú.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha slánuimhreacha [`atomic`] gan síniú tríd an modh `fetch_min` ag rith [`Ordering::AcqRel`] mar an `order`.
    /// Mar shampla, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Íosta leis an luach atá ann faoi láthair ag baint úsáide as comparáid gan síniú.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha slánuimhreacha [`atomic`] gan síniú tríd an modh `fetch_min` ag rith [`Ordering::Relaxed`] mar an `order`.
    /// Mar shampla, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Uasmhéid leis an luach atá ann faoi láthair ag baint úsáide as comparáid gan síniú.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha slánuimhreacha [`atomic`] gan síniú tríd an modh `fetch_max` ag rith [`Ordering::SeqCst`] mar an `order`.
    /// Mar shampla, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uasmhéid leis an luach atá ann faoi láthair ag baint úsáide as comparáid gan síniú.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha slánuimhreacha [`atomic`] gan síniú tríd an modh `fetch_max` ag rith [`Ordering::Acquire`] mar an `order`.
    /// Mar shampla, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uasmhéid leis an luach atá ann faoi láthair ag baint úsáide as comparáid gan síniú.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha slánuimhir neamhshínithe [`atomic`] tríd an modh `fetch_max` trí [`Ordering::Release`] a rith mar an `order`.
    /// Mar shampla, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uasmhéid leis an luach atá ann faoi láthair ag baint úsáide as comparáid gan síniú.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil ar na cineálacha slánuimhreacha [`atomic`] gan síniú tríd an modh `fetch_max` ag rith [`Ordering::AcqRel`] mar an `order`.
    /// Mar shampla, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uasmhéid leis an luach atá ann faoi láthair ag baint úsáide as comparáid gan síniú.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil ar na cineálacha slánuimhir neamhshínithe [`atomic`] tríd an modh `fetch_max` trí [`Ordering::Relaxed`] a rith mar an `order`.
    /// Mar shampla, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Is é an bunúsach `prefetch` leid leis an gineadóir cód a chur isteach teagasc prefetch má tá tacaíocht;murach sin, is no-op é.
    /// Níl aon éifeacht ag réamhtheachtaí ar iompar an chláir ach is féidir leo a shaintréithe feidhmíochta a athrú.
    ///
    /// Ní mór slánuimhir leanúnach a bheith san argóint `locality` agus is sonraitheoir ceantair ama í ó (0), gan aon cheantar, go (3), coimeád an-áitiúil sa taisce.
    ///
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Is é an bunúsach `prefetch` leid leis an gineadóir cód a chur isteach teagasc prefetch má tá tacaíocht;murach sin, is no-op é.
    /// Níl aon éifeacht ag réamhtheachtaí ar iompar an chláir ach is féidir leo a shaintréithe feidhmíochta a athrú.
    ///
    /// Ní mór slánuimhir leanúnach a bheith san argóint `locality` agus is sonraitheoir ceantair ama í ó (0), gan aon cheantar, go (3), coimeád an-áitiúil sa taisce.
    ///
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Is é an bunúsach `prefetch` leid leis an gineadóir cód a chur isteach teagasc prefetch má tá tacaíocht;murach sin, is no-op é.
    /// Níl aon éifeacht ag réamhtheachtaí ar iompar an chláir ach is féidir leo a shaintréithe feidhmíochta a athrú.
    ///
    /// Ní mór slánuimhir leanúnach a bheith san argóint `locality` agus is sonraitheoir ceantair ama í ó (0), gan aon cheantar, go (3), coimeád an-áitiúil sa taisce.
    ///
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Is é an bunúsach `prefetch` leid leis an gineadóir cód a chur isteach teagasc prefetch má tá tacaíocht;murach sin, is no-op é.
    /// Níl aon éifeacht ag réamhtheachtaí ar iompar an chláir ach is féidir leo a shaintréithe feidhmíochta a athrú.
    ///
    /// Ní mór slánuimhir leanúnach a bheith san argóint `locality` agus is sonraitheoir ceantair ama í ó (0), gan aon cheantar, go (3), coimeád an-áitiúil sa taisce.
    ///
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Fál adamhach.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil i [`atomic::fence`] ag dul thar [`Ordering::SeqCst`] mar an `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Fál adamhach.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil i [`atomic::fence`] ag dul thar [`Ordering::Acquire`] mar an `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Fál adamhach.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil i [`atomic::fence`] trí [`Ordering::Release`] a rith mar an `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Fál adamhach.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil i [`atomic::fence`] ag dul thar [`Ordering::AcqRel`] mar an `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Bacainn cuimhne tiomsaitheora amháin.
    ///
    /// Ní dhéanfaidh an tiomsaitheoir rochtain ar chuimhne a athainmniú riamh thar an mbacainn seo, ach ní astaítear aon treoracha ina leith.
    /// Tá sé seo oiriúnach le haghaidh oibríochtaí ar an snáithe céanna d'fhéadfadh a bheith preempted, ar nós nuair a idirghníomhú le láimhseálaithe comhartha.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil i [`atomic::compiler_fence`] ag dul thar [`Ordering::SeqCst`] mar an `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Bacainn cuimhne tiomsaitheora amháin.
    ///
    /// Ní dhéanfaidh an tiomsaitheoir rochtain ar chuimhne a athainmniú riamh thar an mbacainn seo, ach ní astaítear aon treoracha ina leith.
    /// Tá sé seo oiriúnach le haghaidh oibríochtaí ar an snáithe céanna d'fhéadfadh a bheith preempted, ar nós nuair a idirghníomhú le láimhseálaithe comhartha.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil i [`atomic::compiler_fence`] ag dul thar [`Ordering::Acquire`] mar an `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Bacainn cuimhne tiomsaitheora amháin.
    ///
    /// Ní dhéanfaidh an tiomsaitheoir rochtain ar chuimhne a athainmniú riamh thar an mbacainn seo, ach ní astaítear aon treoracha ina leith.
    /// Tá sé seo oiriúnach le haghaidh oibríochtaí ar an snáithe céanna d'fhéadfadh a bheith preempted, ar nós nuair a idirghníomhú le láimhseálaithe comhartha.
    ///
    /// Tá an leagan cobhsaithe den intreach seo ar fáil i [`atomic::compiler_fence`] trí [`Ordering::Release`] a rith mar an `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Bacainn cuimhne tiomsaitheora amháin.
    ///
    /// Ní dhéanfaidh an tiomsaitheoir rochtain ar chuimhne a athainmniú riamh thar an mbacainn seo, ach ní astaítear aon treoracha ina leith.
    /// Tá sé seo oiriúnach le haghaidh oibríochtaí ar an snáithe céanna d'fhéadfadh a bheith preempted, ar nós nuair a idirghníomhú le láimhseálaithe comhartha.
    ///
    /// Is é an leagan chobhsaithe den bunúsach ar fáil i [`atomic::compiler_fence`] ag dul thar [`Ordering::AcqRel`] mar an `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Draíocht intreach a fhaigheann a bhrí ó thréithe atá ceangailte leis an bhfeidhm.
    ///
    /// Mar shampla, dataflow húsáidí seo a instealladh dearbhuithe statach ionas go `rustc_peek(potentially_uninitialized)` mbeadh i ndáiríre cinnte de go dataflow raibh go deimhin ríomh go bhfuil sé uninitialized ag an bpointe sin sa sreabhadh rialaithe.
    ///
    ///
    /// Níor cheart an intreach seo a úsáid lasmuigh den tiomsaitheoir.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Laghdaíonn sé cur i bhfeidhm an phróisis.
    ///
    /// Tá éasca le húsáid agus cobhsaí Leagan níos mó den oibríocht [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Cuireann sé in iúl don optimizer nach bhfuil an pointe seo sa chód inrochtana, rud a chumasaíonn barrfheabhsúcháin eile.
    ///
    /// NB, tá sé seo an-difriúil ón macra `unreachable!()`: Murab ionann agus an macra, a panics nuair a dhéantar é, is é *iompar neamhshainithe* cód atá marcáilte leis an bhfeidhm seo a bhaint amach.
    ///
    ///
    /// Is é an leagan chobhsaithe den bunúsach [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Cuireann sé in iúl don optimizer go bhfuil riocht fíor i gcónaí.
    /// Má tá an coinníoll bréagach, tá an t-iompar undefined.
    ///
    /// Ní ghintear aon chód don intreach seo, ach déanfaidh an optimizer iarracht é a chaomhnú (agus a riocht) idir pasanna, a d`fhéadfadh cur isteach ar bharrfheabhsú an chóid máguaird agus feidhmíocht a laghdú.
    /// Níor cheart é a úsáid más féidir leis an athraitheach a fuair sé amach ag an optimizer ar a chuid féin, nó más rud é nach ndéanann sé ar chumas aon optimizations suntasacha.
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Leideanna don tiomsaitheoir gur dóigh go mbeidh riocht branch fíor.
    /// Tuairisceáin an luach aghaidh chuige.
    ///
    /// Beidh aon úsáid eile seachas a bhfuil ráitis `if` dócha go mbeadh tionchar.
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Leideanna don Tiomsaitheoir gur dócha a bheith bréagach riocht branch.
    /// Tuairisceáin an luach aghaidh chuige.
    ///
    /// Beidh aon úsáid eile seachas a bhfuil ráitis `if` dócha go mbeadh tionchar.
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Fhorghníomhú gaiste brisphointe, lena n-iniúchadh ag dífhabhtóir.
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    pub fn breakpoint();

    /// Méid an chineáil i mbeart.
    ///
    /// Go sonrach, is é seo an fritháireamh i mbeart idir earraí comhleanúnacha den chineál céanna, lena n-áirítear stuáil ailínithe.
    ///
    ///
    /// Is é an leagan chobhsaithe den bunúsach [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// An t-ailíniú íosta de chineál.
    ///
    /// Is é [`core::mem::align_of`](crate::mem::align_of) an leagan cobhsaithe den intreach seo.
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// An ailíniú fearr de chineál.
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Méid an luacha tagartha i mbeart.
    ///
    /// Is é [`mem::size_of_val`] an leagan cobhsaithe den intreach seo.
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Ailíniú riachtanach den luach tagartha.
    ///
    /// Is é [`core::mem::align_of_val`](crate::mem::align_of_val) an leagan cobhsaithe den intreach seo.
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Faigheann slice teaghrán statach ina mbeidh ainm i ndáil le cineál.
    ///
    /// Is é an leagan chobhsaithe den bunúsach [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Faigheann aitheantóir atá uathúil go domhanda don chineál sonraithe.
    /// Fillfidh an fheidhm seo an luach céanna ar chineál beag beann ar cibé crate a agraíodh é.
    ///
    ///
    /// Is é [`core::any::TypeId::of`](crate::any::TypeId::of) an leagan cobhsaithe den intreach seo.
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Garda le haghaidh feidhmeanna neamhshábháilte nach féidir a fhorghníomhú riamh má tá `T` neamháitrithe:
    /// Déanfaidh sé seo panic go statach, nó ní dhéanfaidh sé tada.
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Garda le haghaidh feidhmeanna neamhshábháilte nach féidir a chur i gcrích riamh mura gceadaíonn `T` tosaithe nialasacha: Déanfaidh sé seo panic go statach, nó ní dhéanfaidh sé tada.
    ///
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    pub fn assert_zero_valid<T>();

    /// A garda d'fheidhmeanna sábháilte nach féidir a fhorghníomhú riamh má tá `T` chairt giotán neamhbhailí: Seo Beidh statically ceachtar panic, nó an bhfuil rud ar bith.
    ///
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    pub fn assert_uninit_valid<T>();

    /// Faigheann aon tagairt d'statach `Location` ag léiriú áit a raibh sé ar a dtugtar.
    ///
    /// Smaoinigh ar úsáid a bhaint as [`core::panic::Location::caller`](crate::panic::Location::caller) ina ionad.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Bog le luach as raon feidhme gan rith gliú titim.
    ///
    /// Tá sé seo ann do [`mem::forget_unsized`] amháin;gnáth `forget` Úsáideann `ManuallyDrop` ina ionad.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Athscríobh na giotáin de luach de chineál amháin mar chineál eile.
    ///
    /// Ní mór an dá chineál den mhéid chéanna.
    /// Ní fhéadfaidh an bunaidh, ná an toradh mar a bheidh ina [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` is ionann é go séimeantach agus bogadh de chineál amháin go cineál eile.Tá sé cóipeanna na giotán ón luach fhoinse isteach sa luach scríbe, dearmad ansin an bunaidh.
    /// Is ionann é agus C's `memcpy` faoin gcochall, díreach cosúil le `transmute_copy`.
    ///
    /// Toisc gur oibríocht seachluacha é `transmute`, ní ábhar imní é ailíniú na *luachanna aistrithe iad féin*.
    /// Mar aon le haon fheidhm eile, cinntíonn an tiomsaitheoir cheana féin go bhfuil `T` agus `U` ailínithe i gceart.
    /// Mar sin féin, agus luachanna á dtarchur ag *pointeáil in áiteanna eile*(mar leideanna, tagairtí, boscaí…), caithfidh an té atá ag glaoch ailíniú ceart na luachanna pointeáilte a chinntiú.
    ///
    /// `transmute` Is **thar** neamhshábháilte.Tá go leor bealaí ann chun [undefined behavior][ub] a chur faoi deara leis an bhfeidhm seo.Ba cheart gurb é `transmute` an rogha dheireanach iomlán.
    ///
    /// An [nomicon](../../nomicon/transmutes.html) Tá doiciméid bhreise.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Tá cúpla rud a bhfuil `transmute` an-úsáideach dóibh.
    ///
    /// Casadh ar pointeoir isteach i pointeoir feidhm.Níl sé seo * iniompartha do mheaisíní ina bhfuil méideanna difriúla ag leideanna feidhm agus leideanna sonraí.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// A leathnú ar feadh an tsaoil, nó ghiorrú ar feadh an tsaoil athraithe.Tá sé seo chun cinn, an-neamhshábháilte Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Ná ní éadóchas: Is féidir go leor úsáidí de `transmute` a bhaint amach trí mhodhanna eile.
    /// Thíos tá iarratais coitianta `transmute` ar féidir a chur in ionad le constructs níos sábháilte.
    ///
    /// Ag casadh bytes(`&[u8]`) amh go `u32`, `f64`, etc .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // úsáid `u32::from_ne_bytes` ina ionad
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // nó bain úsáid as `u32::from_le_bytes` nó `u32::from_be_bytes` a shonrú ar an endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Ag pointeoir a iompú ina `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Úsáid teilgthe `as` ina ionad
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// `*mut T` a iompú ina `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Bain úsáid as reborrow ina áit
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Casadh an `&mut T` isteach `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Anois, a chur le chéile `as` agus reborrowing, faoi deara nach bhfuil an shlabhrú na `as` `as` aistreacha
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str` a iompú ina `&[u8]`:
    ///
    /// ```
    /// // ní bealach maith é seo chun é seo a dhéanamh.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // D`fhéadfá `str::as_bytes` a úsáid
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Nó, ná húsáid ach sreang beart, má tá smacht agat ar an sreangán liteartha
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// `Vec<&T>` a iompú ina `Vec<Option<&T>>`.
    ///
    /// Chun transmute an cineál istigh de an t-ábhar coimeádán, ní mór duit a dhéanamh cinnte go nach sáraíonn aon cheann de invariants an coimeádán ar.
    /// Maidir le `Vec`, ciallaíonn sé seo go gcaithfidh méid *agus ailíniú* na gcineálacha istigh a mheaitseáil.
    /// D`fhéadfadh coimeádáin eile a bheith ag brath ar mhéid an chineáil, an ailínithe, nó fiú an `TypeId`, agus sa chás sin ní bheifí in ann traschur a dhéanamh ar chor ar bith gan sárú a dhéanamh ar ionróirí an choimeádáin.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // Clón an vector mar go mbeidh muid a athúsáid orthu ina dhiaidh sin
    /// let v_clone = v_orig.clone();
    ///
    /// // Transmute a úsáid: braitheann sé seo ar leagan amach sonraí neamhshonraithe `Vec`, ar droch-smaoineamh é agus a d`fhéadfadh a bheith ina chúis le hIompar Neamhshainithe.
    /////
    /// // Mar sin féin, tá sé aon-cóip.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Seo an bealach sábháilte a mholtar.
    /// // chuireann sé a chóipeáil an vector fad, áfach, i sraith nua.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Is é seo an bealach ceart neamhshábháilte gan aon chóip de "transmuting" a `Vec`, gan a bheith ag brath ar leagan amach na sonraí.
    /// // In ionad `transmute` a ghlaoch go litriúil, déanaimid teilgean pointeora, ach maidir leis an gcineál istigh bunaidh (`&i32`) a thiontú go ceann nua (`Option<&i32>`), tá na caveat céanna ar fad aige seo.
    /////
    /// // Chomh maith leis an bhfaisnéis a chuirtear ar fáil thuas, téigh i gcomhairle leis an doiciméadacht [`from_raw_parts`] freisin.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Nuashonrú seo nuair atá vec_into_raw_parts chobhsaithe.
    ///     // A chinntiú an bunaidh nach bhfuil vector thit.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Cur Chun Feidhme `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Tá bealaí éagsúla chun é seo a, agus tá fadhbanna éagsúla leis an mbealach (transmute) leanas.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // chéad: Níl transmute cineál sábháilte;is é a dhéanann sé go léir ná go ndéanann T agus
    ///         // Tá U den mhéid céanna.
    ///         // Sa dara háit, ar dheis anseo, tá dhá thagairt dhochreidte agat a dhíríonn ar an gcuimhne chéanna.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Faigheann sé seo réidh leis na fadhbanna sábháilteachta chineál;Ní thabharfaidh `&mut *`* ach *`&mut T` duit ó `&mut T` nó `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // áfach, tá dhá thagairt inathraithe agat atá dírithe ar an gcuimhne chéanna.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Tá sé seo conas a dhéanann an leabharlann caighdeánach é.
    /// // Is é seo an modh is fearr, más gá duit rud mar seo a dhéanamh
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Anois tá trí thagairt inathraithe aige atá dírithe ar an gcuimhne chéanna.`slice`, an ret.0 rvalue, agus an rvalue ret.1.
    ///         // `slice` Tá riamh a úsáidtear i ndiaidh `let ptr = ...`, agus mar sin ar féidir le duine a chóireáil sé mar "dead", agus dá bhrí sin, tá tú ach dhá slisní mutable fíor.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Cé go ndéanann sé seo an const intreach seasmhach, tá roinnt cód saincheaptha againn i const fn
    // seiceálacha a choisceann a úsáid laistigh de `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Tuairisceáin `true` má tá gliú titim ag teastáil ón gcineál iarbhír a thugtar mar `T`;tuairisceáin `false` má chuireann an cineál iarbhír a chuirtear ar fáil do `T` `Copy` i bhfeidhm.
    ///
    ///
    /// Mura n-éilíonn an cineál iarbhír gliú titim ná `Copy` a chur i bhfeidhm, ansin tá luach tuairisceáin na feidhme seo neamhshonraithe.
    ///
    /// Is é [`mem::needs_drop`](crate::mem::needs_drop) an leagan cobhsaithe den intreach seo.
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Ríomhann an fritháireamh ó pointeoir.
    ///
    /// Tá sé seo i bhfeidhm mar intreach a sheachaint athrú chuig agus ó slánuimhir, ós rud é go mbeadh an comhshó caith amach eolas aliasing.
    ///
    /// # Safety
    ///
    /// Caithfidh an pointeoir tosaigh agus an pointeoir dá bharr a bheith i dteorainneacha nó i mbeart amháin tar éis dheireadh réad leithdháilte.
    /// Má tá ceachtar pointeoir lasmuigh de theorainneacha nó má tharlaíonn ró-shreabhadh uimhríochta ansin beidh iompar neamhshainithe mar thoradh ar aon úsáid bhreise a bhaint as an luach ar ais.
    ///
    ///
    /// Is é an leagan chobhsaithe den bunúsach [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Ríomhtar an fritháireamh ó phointeoir, a d`fhéadfadh a bheith fillte.
    ///
    /// Tá sé seo i bhfeidhm mar intreach a sheachaint athrú chuig agus ó slánuimhir, ós rud é inhibits an chomhshó optimizations áirithe.
    ///
    /// # Safety
    ///
    /// Murab ionann agus an intreach `offset`, ní chuireann an intreach seo srian ar an bpointeoir a leanann as pointeáil isteach nó beart amháin anuas ar dheireadh réad leithdháilte, agus fillteann sé le huimhríocht chomhlánaithe dhá.
    /// Níl an luach a leanann bailí a bheidh le húsáid chun cuimhne i ndáiríre gá.
    ///
    /// Is é an leagan chobhsaithe den bunúsach [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Coibhéiseach leis an cuí `llvm.memcpy.p0i8.0i8.*` intreach, le méid de `count`*`size_of::<T>()` agus ailíniú
    ///
    /// `min_align_of::<T>()`
    ///
    /// Tá an paraiméadar so-ghalaithe leagtha chun `true`, mar sin ní bheidh sé a uasmhéadú amach ach amháin má tá méid is ionann agus nialas.
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Coibhéiseach leis an intreach iomchuí `llvm.memmove.p0i8.0i8.*`, le méid `count* size_of::<T>()` agus ailíniú de
    ///
    /// `min_align_of::<T>()`
    ///
    /// Tá an paraiméadar so-ghalaithe leagtha chun `true`, mar sin ní bheidh sé a uasmhéadú amach ach amháin má tá méid is ionann agus nialas.
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Coibhéiseach leis an cuí `llvm.memset.p0i8.*` intreach, le méid de `count* size_of::<T>()` agus ailíniú `min_align_of::<T>()`.
    ///
    ///
    /// Tá an paraiméadar so-ghalaithe leagtha chun `true`, mar sin ní bheidh sé a uasmhéadú amach ach amháin má tá méid is ionann agus nialas.
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Fheidhmíonn ualach luaineach ón pointeoir `src`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Déanann sé stór so-ghalaithe don phointeoir `dst`.
    ///
    /// Is é [`core::ptr::write_volatile`](crate::ptr::write_volatile) an leagan cobhsaithe den intreach seo.
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Feidhmíonn ualach luaineach ón pointeoir `src` Ní gá an pointeoir a ailíniú.
    ///
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Déanann sé stór so-ghalaithe don phointeoir `dst`.
    /// Níl an pointeoir a cheanglaítear a ailíniú.
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Filleann sé fréamh cearnach `f32`
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Filleann sé fréamh cearnach `f64`
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Ardaíonn an `f32` le cumhacht slánuimhir.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Ardaíonn sé `f64` do chumhacht slánuimhir.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Filleann sé sine `f32`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Filleann sé sine `f64`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Filleann sé cosine `f32`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Tuairisceáin an Comhshíneas an `f64`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Ardaíonn sé `f32` go cumhacht `f32`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Ardaíonn an `f64` chuig cumhacht `f64`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Filleann sé easpónantúil `f32`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Filleann sé easpónantúil `f64`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Tuairisceáin 2 ardaithe go dtí faoi urláimh `f32`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Tuairisceáin 2 a ardaíodh chun cumhacht `f64`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Tuairisceáin an logarithm nádúrtha de `f32`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Tuairisceáin an logarithm nádúrtha de `f64`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Tuairisceáin an bonn 10 logarithm de `f32`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Tuairisceáin an bonn 10 logarithm de `f64`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Filleann sé logarithm bonn 2 de `f32`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Tuairisceáin an bonn 2 logarithm de `f64`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Tuairisceáin `a * b + c` do luachanna `f32`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Tuairisceáin `a * b + c` do luachanna `f64`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Filleann sé luach absalóideach `f32`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Tuairisceáin luach absalóideach an `f64`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Tuairisceáin an t-íosmhéid de dá luach `f32`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Filleann sé ar a laghad dhá luach `f64`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Filleann sé dhá luach `f32` ar a mhéad.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Filleann sé dhá luach `f64` ar a mhéad.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Cóipeáil an comhartha ó `y` go `x` do luachanna `f32`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Cóipeáil an comhartha ó `y` go `x` le haghaidh luachanna `f64`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Filleann sé an tslánuimhir is mó atá níos lú ná nó cothrom le `f32`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Tuairisceáin an ceann is mó slánuimhir níos lú ná nó cothrom le an `f64`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Filleann sé an tslánuimhir is lú ar mó é ná `f32` nó cothrom leis.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Tuairisceáin mó tslánuimhir is lú ná nó cothrom le an `f64`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Filleann sé an chuid slánuimhir de `f32`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Filleann sé an chuid slánuimhir de `f64`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Tuairisceáin an tslánuimhir is gaire go dtí `f32`.
    /// Féadfaidh sé eisceacht snámhphointe neamhghníomhach a ardú mura slánuimhir í an argóint.
    pub fn rintf32(x: f32) -> f32;
    /// Filleann an slánuimhir is gaire do `f64`.
    /// Féadfaidh sé eisceacht snámhphointe neamhghníomhach a ardú mura slánuimhir í an argóint.
    pub fn rintf64(x: f64) -> f64;

    /// Tuairisceáin an tslánuimhir is gaire go dtí `f32`.
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Filleann an slánuimhir is gaire do `f64`.
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Tuairisceáin an tslánuimhir is gaire go dtí `f32`.Babhtaí cásanna leath bealaigh ar shiúl ó nialas.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Filleann an slánuimhir is gaire do `f64`.Babhtaí cásanna leath bealaigh ar shiúl ó nialas.
    ///
    /// Is é an leagan chobhsaithe den bunúsach
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Snámhphointe theannta sin ligeann optimizations bunaithe ar rialacha ailgéabracha.
    /// Féadfaidh sé glacadh leis go bhfuil ionchuir teoranta.
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Snámhphointe dealú a ligeann optimizations bunaithe ar rialacha ailgéabracha.
    /// Féadfaidh sé glacadh leis go bhfuil ionchuir teoranta.
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Iolrú snámhphointe a cheadaíonn barrfheabhsúcháin bunaithe ar rialacha ailgéabracha.
    /// Féadfaidh sé glacadh leis go bhfuil ionchuir teoranta.
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Rannán snámhphointe a cheadaíonn barrfheabhsúcháin bunaithe ar rialacha ailgéabracha.
    /// Féadfaidh sé glacadh leis go bhfuil ionchuir teoranta.
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Snámhphointe eile a ligeann optimizations bunaithe ar rialacha ailgéabracha.
    /// Féadfaidh sé glacadh leis go bhfuil ionchuir teoranta.
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Tiontaigh le fptoui/fptosi LLVM ar, d'fhéadfadh a filleadh undef do luachanna as raon
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Cobhsaithe mar [`f32::to_int_unchecked`] agus [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Filleann sé líon na ngiotán atá socraithe i gcineál slánuimhir `T`
    ///
    /// Tá na leaganacha cobhsaithe den intreach seo ar fáil ar na primitive slánuimhir tríd an modh `count_ones`.
    /// Mar shampla,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Tuairisceáin líon na tosaigh giotán unset (zeroes) i chineál slánuimhir `T`.
    ///
    /// Is iad na leaganacha cobhsaithe den bunúsach ar fáil ar na primitives slánuimhir tríd an modh `leading_zeros`.
    /// Mar shampla,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// Fillfidh `x` le luach `0` ar leithead giotán `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Cosúil `ctlz`, ach seach-sábháilte ag filleadh sé `undef` nuair a tugadh an `x` le luach `0`.
    ///
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Filleann sé líon na ngiotán neamhshonraithe trailing (zeroes) i gcineál slánuimhir `T`.
    ///
    /// Tá na leaganacha cobhsaithe den intreach seo ar fáil ar na primitive slánuimhir tríd an modh `trailing_zeros`.
    /// Mar shampla,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// Fillfidh `x` le luach `0` leithead giotán `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Cosúil `cttz`, ach seach-sábháilte ag filleadh sé `undef` nuair a tugadh an `x` le luach `0`.
    ///
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Déanann sé na bearta a aisiompú i gcineál slánuimhir `T`.
    ///
    /// Is iad na leaganacha cobhsaithe den bunúsach ar fáil ar na primitives slánuimhir tríd an modh `swap_bytes`.
    /// Mar shampla,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Déanann sé na giotáin a aisiompú i gcineál slánuimhir `T`.
    ///
    /// Tá na leaganacha cobhsaithe den intreach seo ar fáil ar na primitive slánuimhir tríd an modh `reverse_bits`.
    /// Mar shampla,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Déanann sé suimiú slánuimhir seiceáilte.
    ///
    /// Tá na leaganacha cobhsaithe den intreach seo ar fáil ar na primitive slánuimhir tríd an modh `overflowing_add`.
    /// Mar shampla,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Déanann dealú slánuimhir seiceáilte
    ///
    /// Is iad na leaganacha cobhsaithe den bunúsach ar fáil ar na primitives slánuimhir tríd an modh `overflowing_sub`.
    /// Mar shampla,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Déanann iolrú slánuimhir seiceáilte
    ///
    /// Is iad na leaganacha cobhsaithe den bunúsach ar fáil ar na primitives slánuimhir tríd an modh `overflowing_mul`.
    /// Mar shampla,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Fheidhmíonn a bheith roinnte beacht, a eascraíonn i iompar undefined ina `x % y != 0` nó `y == 0` nó `x == T::MIN && y == -1`
    ///
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Déanann sé rannán neamhsheiceáilte, agus iompraíocht neamhshainithe mar thoradh air i gcás `y == 0` nó `x == T::MIN && y == -1`
    ///
    ///
    /// Tá cumhdaigh Sábháilte don bhunúsach ar fáil ar na primitives slánuimhir tríd an modh `checked_div`.
    /// Mar shampla,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Filleann sé an chuid eile de roinn neamhsheiceáilte, agus iompraíocht neamhshainithe mar thoradh air nuair a dhéantar `y == 0` nó `x == T::MIN && y == -1`
    ///
    ///
    /// Tá cumhdaigh Sábháilte don bhunúsach ar fáil ar na primitives slánuimhir tríd an modh `checked_rem`.
    /// Mar shampla,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Fheidhmíonn mbeidh aistriú chlé unchecked, a eascraíonn i iompar undefined nuair `y < 0` nó `y >= N`, áit arb ionann N leithead T i giotán.
    ///
    ///
    /// Tá cumhdaigh shábháilte don intreach seo ar fáil ar na primitive slánuimhir tríd an modh `checked_shl`.
    /// Mar shampla,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Fheidhmíonn mbeidh aistriú ceart unchecked, a eascraíonn i iompar undefined nuair `y < 0` nó `y >= N`, áit arb ionann N leithead T i giotán.
    ///
    ///
    /// Tá cumhdaigh shábháilte don intreach seo ar fáil ar na primitive slánuimhir tríd an modh `checked_shr`.
    /// Mar shampla,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Tuairisceáin an toradh ábhar a chur leis unchecked, a eascraíonn i iompar undefined nuair `x + y > T::MAX` nó `x + y < T::MIN`.
    ///
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Tuairisceáin thoradh ar dealaithe unchecked, a eascraíonn i iompar undefined nuair `x - y > T::MAX` nó `x - y < T::MIN`.
    ///
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Tugann sé toradh iolraithe neamhsheiceáilte ar ais, agus iompraíocht neamhshainithe mar thoradh air nuair a dhéantar `x *y > T::MAX` nó `x* y < T::MIN`.
    ///
    ///
    /// Níl a mhacasamhail chobhsaí ag an intreach seo.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Rothlaíonn rothlú ar chlé.
    ///
    /// Tá na leaganacha cobhsaithe den intreach seo ar fáil ar na primitive slánuimhir tríd an modh `rotate_left`.
    /// Mar shampla,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Rothlaíonn ceart rothlú.
    ///
    /// Tá na leaganacha cobhsaithe den intreach seo ar fáil ar na primitive slánuimhir tríd an modh `rotate_right`.
    /// Mar shampla,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Tuairisceáin (a + b) mod 2 <sup>N,</sup> áit arb ionann N leithead T i giotán.
    ///
    /// Tá na leaganacha cobhsaithe den intreach seo ar fáil ar na primitive slánuimhir tríd an modh `wrapping_add`.
    /// Mar shampla,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Tuairisceáin (a, b) mod 2 <sup>N,</sup> áit arb ionann N leithead T i giotán.
    ///
    /// Tá na leaganacha cobhsaithe den intreach seo ar fáil ar na primitive slánuimhir tríd an modh `wrapping_sub`.
    /// Mar shampla,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Tuairisceáin (a b *) mod 2 <sup>N,</sup> áit arb ionann N leithead T i giotán.
    ///
    /// Is iad na leaganacha cobhsaithe den bunúsach ar fáil ar na primitives slánuimhir tríd an modh `wrapping_mul`.
    /// Mar shampla,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Ríomhann `a + b`, saturating ar bounds uimhriúil.
    ///
    /// Is iad na leaganacha cobhsaithe den bunúsach ar fáil ar na primitives slánuimhir tríd an modh `saturating_add`.
    /// Mar shampla,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Computes `a - b`, sáithithe ag teorainneacha uimhriúla.
    ///
    /// Tá na leaganacha cobhsaithe den intreach seo ar fáil ar na primitive slánuimhir tríd an modh `saturating_sub`.
    /// Mar shampla,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Filleann sé luach an idirdhealaitheora don athraitheach in 'v';
    /// má tá `T` aon discriminant tuairisceáin, `0`.
    ///
    /// Is é an leagan chobhsaithe den bunúsach [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Tuairisceáin líon na leaganacha den chineál `T` caitheadh le `usize`;
    /// mura bhfuil aon leaganacha ag `T`, filleann `0`.Áireofar malairtí neamháitrithe.
    ///
    /// Is é an leagan a-bheith-chobhsaithe an bunúsach [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// "try catch" thógáil Rust ar a agraíonn an fheidhm pointeoir `try_fn` leis an pointeoir sonraí `data`.
    ///
    /// Is í an tríú argóint feidhm ar a dtugtar má tharlaíonn panic.
    /// Tógann an fheidhm seo an pointeoir sonraí agus pointeoir chuig an réad eisceachtúil a bhaineann go sonrach le spriocanna a gabhadh.
    ///
    /// Le haghaidh tuilleadh faisnéise féach foinse an tiomsaitheora chomh maith le cur i bhfeidhm gabhála std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Astaíonn siopa `!nontemporal` réir LLVM (féach gcuid docs).
    /// Ní bheidh Is dócha a bheith cobhsaí.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Féach doiciméadú na `<*const T>::offset_from` le haghaidh sonraí.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Féach cáipéisíocht `<*const T>::guaranteed_eq` le haghaidh sonraí.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Féach doiciméadú na `<*const T>::guaranteed_ne` le haghaidh sonraí.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Leithdháileadh ag am tiomsú.Níor chóir a dtugtar ag runtime.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Tá roinnt feidhmeanna a shainmhíniú anseo toisc go bhfuair rinne siad thaisme ar fáil sa mhodúl seo ar seasmhach.
// Féach <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` dtagann chomh maith sa chatagóir seo, ach ní féidir é a fillte mar gheall ar an seic go bhfuil `T` agus `U` an méid céanna.)
//

/// Seiceálacha an bhfuil `ptr` ailínithe i gceart maidir le `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Cóipeanna `count *size_of::<T>()` bytes ó `src` go `dst`.Caithfidh an foinse agus an ceann scríbe* ní * forluí.
///
/// I gcás réigiún cuimhne a d'fhéadfadh forluí a dhéanamh, úsáid [`copy`] ina ionad.
///
/// `copy_nonoverlapping` tá sé comhionann go séimeantach le C's [`memcpy`], ach leis an ordú argóinte a mhalartú.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Tá Oibriú undefined más ann de na coinníollacha seo a leanas atáid:
///
/// * `src` ní mór gur [valid] é le haghaidh léamha beart `count * size_of::<T>()`.
///
/// * `dst` ní mór [valid] a bheith ann le haghaidh scríbhinní beart `count * size_of::<T>()`.
///
/// * Ní mór `src` agus `dst` araon a ailíniú i gceart.
///
/// * Thart ar chuimhne ag tosú ag `src` le méid de `chomhaireamh *
///   size_of: :<T>() Ní mór `bytes * forluí le réigiún na cuimhne ag tosú ag `dst` leis an méid céanna.
///
/// Cosúil [`read`], cruthaíonn `copy_nonoverlapping` cóip bitwise de `T`, is cuma cibé an bhfuil `T` [`Copy`].
/// Mura bhfuil `T` [`Copy`], ag baint úsáide as an dá * * na luachanna sa réigiún ag tosú ag `*src` agus an réigiún ag tosú ag `* dst` féidir [violate memory safety][read-ownership].
///
///
/// Tabhair faoi deara go fiú má tá an méid a chóipeáil go héifeachtach (`count * size_of: :<T>()`) Is `0`, ní mór na leideanna a bheith neamh-NULL agus ailínithe i gceart.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// [`Vec::append`] a chur i bhfeidhm de láimh:
///
/// ```
/// use std::ptr;
///
/// /// Téigh go léir na gnéithe den `src` `dst` isteach, ag fágáil `src` folamh.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // A chinntiú go bhfuil go leor cumais ag `dst` chun `src` ar fad a shealbhú.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Tá an glao chun fritháireamh sábháilte i gcónaí toisc nach leithdháilfidh `Vec` níos mó ná bearta `isize::MAX` go deo.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Theascadh `src` gan dropping a bhfuil ann.
///         // Déanaimid é seo ar dtús, chun fadhbanna a sheachaint sa chás rud éigin a thuilleadh síos panics.
///         src.set_len(0);
///
///         // Ní féidir leis an dá réigiún forluí a dhéanamh toisc nach bhfuil ailias ag tagairtí do-athraithe, agus ní féidir an chuimhne chéanna a bheith ag dhá vectors éagsúla.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Cuir in iúl do `dst` go bhfuil ábhar `src` aige anois.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: A dhéanamh ar na seiceálacha ach amháin ag am a reáchtáil
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Gan panicking a choinneáil ar thionchar codegen lú.
        abort();
    }*/

    // SÁBHÁILTEACHT: Ní mór an conradh sábháilteachta do `copy_nonoverlapping` a
    // sheas an té atá ag glaoch leis.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Cóipeanna de bhearta `count * size_of::<T>()` ó `src` go `dst`.Is féidir leis an fhoinse agus an ceann scríbe forluí.
///
/// Mura ndéanfaidh an foinse agus an ceann scríbe forluí riamh *, is féidir [`copy_nonoverlapping`] a úsáid ina ionad.
///
/// `copy` tá sé comhionann go séimeantach le C's [`memmove`], ach leis an ordú argóinte a mhalartú.
/// Bíonn Cóipeála siúl aige fé is dá chóipeáil an bytes ó `src` le sraith sealadach agus ansin a chóipeáil ó na eagar go `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Tá Oibriú undefined más ann de na coinníollacha seo a leanas atáid:
///
/// * `src` ní mór gur [valid] é le haghaidh léamha beart `count * size_of::<T>()`.
///
/// * `dst` ní mór [valid] a bheith ann le haghaidh scríbhinní beart `count * size_of::<T>()`.
///
/// * Ní mór `src` agus `dst` araon a ailíniú i gceart.
///
/// Cosúil [`read`], cruthaíonn `copy` cóip bitwise de `T`, is cuma cibé an bhfuil `T` [`Copy`].
/// Murab é `T` [`Copy`], is féidir [violate memory safety][read-ownership] a úsáid trí na luachanna sa réigiún ag tosú ag `*src` agus sa réigiún ag tosú ag `* dst`.
///
///
/// Tabhair faoi deara go fiú má tá an méid a chóipeáil go héifeachtach (`count * size_of: :<T>()`) Is `0`, ní mór na leideanna a bheith neamh-NULL agus ailínithe i gceart.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Héifeachtach chruthú vector Rust ó Maolán neamhshábháilte:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` a ailíniú i gceart dá chineál agus neamh-nialas.
/// /// * `ptr` caithfidh siad a bheith bailí le haghaidh léamha ar eilimintí tadhlacha `elts` de chineál `T`.
/// /// * Ní gá na heilimintí sin a úsáid tar éis an fheidhm seo a ghlaoch mura `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SÁBHÁILTEACHT: Cinntíonn ár réamhchoinníoll go bhfuil an foinse ailínithe agus bailí,
///     // agus cinntíonn `Vec::with_capacity` go bhfuil spás inúsáidte againn chun iad a scríobh.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SÁBHÁILTEACHT: Chruthaíomar é leis an gcumas seo i bhfad níos luaithe,
///     // agus tá na heilimintí seo tosaithe ag an `copy` roimhe seo.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: A dhéanamh ar na seiceálacha ach amháin ag am a reáchtáil
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Gan panicking a choinneáil ar thionchar codegen lú.
        abort();
    }*/

    // SÁBHÁILTEACHT: Ní mór an conradh sábháilteachta do `copy` a sheas an té atá ag glaoch.
    unsafe { copy(src, dst, count) }
}

/// Socraíonn `count * size_of::<T>()` beart cuimhne ag tosú ag `dst` go `val`.
///
/// `write_bytes` cosúil le C's [`memset`], ach leagann sé bearta `count * size_of::<T>()` go `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Tá Oibriú undefined más ann de na coinníollacha seo a leanas atáid:
///
/// * `dst` ní mór [valid] a bheith ann le haghaidh scríbhinní beart `count * size_of::<T>()`.
///
/// * `dst` Ní mór a chur ar chomhréim i gceart.
///
/// Ina theannta sin, ní mór don té atá ag glaoch a chinntiú go mbeidh luach bailí `T` mar thoradh ar scríobh `count * size_of::<T>()` beart chuig an réigiún áirithe cuimhne.
/// Is iompar neamhshainithe é réigiún cuimhne a chlóscríobh mar `T` ina bhfuil luach neamhbhailí `T`.
///
/// Tabhair faoi deara go fiú má tá an méid a chóipeáil go héifeachtach (`count * size_of: :<T>()`) is `0` é, caithfidh an pointeoir a bheith neamh-NULL agus ailínithe i gceart.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Luach neamhbhailí a chruthú:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Scaoileann an luach a bhí ann roimhe seo trí fhorscríobh an `Box<T>` le pointeoir null.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Ag an bpointe seo, ag baint úsáide as nó dropping torthaí `v` in iompar neamhshainithe.
/// // drop(v); // ERROR
///
/// // Fiú amháin leaking `v` "uses" é, agus tá sé dá bhrí sin iompar neamhshainithe.
/// // mem::forget(v); // ERROR
///
/// // Déanta na fírinne, tá `v` neamhbhailí de réir invariants leagan amach an chineáil bhunúsaigh, mar sin is iompar neamhshainithe aon oibríocht * a bhaineann léi.
/////
/// // ligean v2 =v=//ERROR
///
/// unsafe {
///     // Lig dúinn luach bailí a chur isteach ina ionad
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Anois tá an bosca go breá
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `write_bytes` a sheasamh.
    unsafe { write_bytes(dst, val, count) }
}