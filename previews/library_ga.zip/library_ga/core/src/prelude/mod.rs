//! An libcore prelude
//!
//! Tá an modúl seo beartaithe d`úsáideoirí libcore nach nascann le libstd freisin.
//! Tá an modúl seo allmhairithe de réir réamhshocraithe nuair a `#![no_std]` úsáidtear sa tslí chéanna leis an leabharlann caighdeánach ar prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Leagan 2015 den chroí-prelude.
///
/// Féach ar an [module-level documentation](self) ar feadh níos mó.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// An 2018 leagan den chroí prelude.
///
/// Féach ar an [module-level documentation](self) ar feadh níos mó.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Leagan 2021 den chroí-prelude.
///
/// Féach ar an [module-level documentation](self) ar feadh níos mó.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Cuir rudaí níos mó.
}