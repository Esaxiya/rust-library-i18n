#![stable(feature = "core_hint", since = "1.27.0")]

//! Leideanna chun tiomsaitheoir a théann i bhfeidhm an gcaoi ar chóir cód a astú ná uasmhéadú.
//! D'fhéadfadh Leideanna a am tiomsaithe nó runtime.

use crate::intrinsics;

/// Cuireann sé in iúl don tiomsaitheoir nach bhfuil an pointe seo sa chód inrochtana, rud a fhágann gur féidir barrfheabhsúcháin a dhéanamh.
///
/// # Safety
///
/// A bhaint amach an fheidhm seo go hiomlán *iompar neamhshainithe*(UB).Go háirithe, glacann an tiomsaitheoir riamh go mór do gach UB tharlóidh, agus dá bhrí sin beidh deireadh gach brainse go bhaint amach ar ghlao chuig `unreachable_unchecked()`.
///
/// Cosúil le gach cás de UB, má casadh an toimhde amach a bheith mícheart, is é sin, is é an glao `unreachable_unchecked()` ndáiríre reachable i measc gach sreabhadh rialaithe is féidir, beidh an tiomsaitheoir i bhfeidhm an straitéis leas iomlán a bhaint mícheart, agus d'fhéadfadh sé uaireanta fiú truaillithe cód seemingly unrelated, is cúis go bhfuil sé deacair go-dífhabhtaigh fadhbanna.
///
///
/// Ná húsáid an fheidhm seo ach nuair is féidir leat a chruthú nach nglaofaidh an cód air go deo.
/// Seachas sin, smaoinigh ar an macra [`unreachable!`] a úsáid, nach gceadaíonn barrfheabhsú ach a dhéanfaidh panic nuair a fhorghníomhófar é.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` dearfach i gcónaí (ní nialas), mar sin ní fhillfidh `checked_div` `None` go deo.
/////
///     // Dá bhrí sin, is é an branch eile unreachable.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SÁBHÁILTEACHT: caithfidh an conradh sábháilteachta do `intrinsics::unreachable`
    // a sheas an té atá ag glaoch.
    unsafe { intrinsics::unreachable() }
}

/// Scaoileann sé treoir mheaisín chun comhartha a thabhairt don phróiseálaí go bhfuil sé ag rith i lúb-lúb gnóthach-fanacht ("glasáil spin").
///
/// Nuair a fhaigheann sé an comhartha lúb-lúb is féidir leis an bpróiseálaí a iompar a bharrfheabhsú trí, mar shampla, cumhacht a shábháil nó snáitheanna hyper a athrú.
///
/// Tá an fheidhm difriúil ó [`thread::yield_now`] a Déanann díreach leis an gcóras ar sceidealóir, ach nach bhfuil `spin_loop` idirghníomhú leis an gcóras oibriúcháin.
///
/// Tá cás úsáid go coitianta le haghaidh `spin_loop` coinníollacha cur chun teorantach sníomh dóchasach i lúb CAS i primitives sioncrónaithe.
/// Chun fadhbanna a sheachaint cosúil le inbhéartú tosaíochta, moltar go láidir go bhfuil an lúb casadh fhoirceannadh tar éis méid teoranta de iterations agus cuirtear syscall blocála chuí.
///
///
/// **Nóta**: Ar ardáin nach dtacaíonn le leideanna lúb casadh a fháil ní dhéanann an fheidhm seo aon rud ar chor ar bith.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // A luach adamhach roinnte go mbeidh snáitheanna úsáid a chomhordú
/// let live = Arc::new(AtomicBool::new(false));
///
/// // I snáithe cúlra socróimid an luach sa deireadh
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Déan roinnt oibre, ansin déan an luach beo
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Ar ais ar ár snáithe atá ann faoi láthair, fanacht againn le haghaidh an luach a bheith leagtha
/// while !live.load(Ordering::Acquire) {
///     // Is é an lúb casadh leid leis an LAP go bhfuil muid ag fanacht, ach is dócha nach bhfuil ar feadh an-fhada
/////
///     hint::spin_loop();
/// }
///
/// // Tá an luach socraithe anois
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SÁBHÁILTEACHT: cinntíonn an attr `cfg` nach ndéanaimid é seo ach ar spriocanna x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SÁBHÁILTEACHT: na áirithíonn attr `cfg` bhfuil muid fhorghníomhú ach seo ar spriocanna x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SÁBHÁILTEACHT: na áirithíonn attr `cfg` bhfuil muid fhorghníomhú ach seo ar spriocanna aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SÁBHÁILTEACHT: cinntíonn an attr `cfg` nach ndéanaimid é seo ach ar spriocanna lámh
            // le tacaíocht don ghné v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Feidhm aitheantais a thugann *__ leideanna __* don tiomsaitheoir a bheith an-dóchasach faoin méid a d`fhéadfadh `black_box` a dhéanamh.
///
/// Murab ionann agus [`std::convert::identity`], tá tiomsaitheoir Rust spreagadh chun glacadh leis gur féidir `black_box` úsáid `dummy` dhóigh ar bith bailí féidir go bhfuil Rust cód cead gan iompar undefined a thabhairt isteach sa chód glaoch.
///
/// Déanann an maoin `black_box` úsáideach do scríobh cód i nach bhfuil optimizations áirithe atá ag teastáil, mar shampla tagarmharcanna.
///
/// Tabhair faoi deara, áfach, nach soláthraítear `black_box` ach (agus nach féidir é a sholáthar ach) ar bhonn "best-effort".Féadfaidh an méid is féidir leis bac a chur ar dhóchas a bheith éagsúil ag brath ar an ardán agus ar an gcód cód-gen a úsáidtear.
/// Ní féidir le cláir brath ar `black_box` ar mhaithe le *cruinneas* ar bhealach ar bith.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Ní mór dúinn "use" an argóint a dhéanamh ar bhealach éigin nach féidir le LLVM cur isteach air, agus de ghnáth maidir le spriocanna a thacaíonn leis is féidir linn tionól inlíne a ghiaráil chun é seo a dhéanamh.
    // Is é an léirmhíniú atá ag LLVM ar thionól inlíne ná gur bosca dubh é, bhuel.
    // Ní hé seo an cur i bhfeidhm is mó mar is dócha go ndéanann sé níos mó ná mar a theastaíonn uainn a dhí-mhacasamhlú, ach go dtí seo tá sé maith go leor.
    //
    //

    #[cfg(not(miri))] // Níl anseo ach leid, mar sin is breá gan bacadh le Miri.
    // SÁBHÁILTEACHT: is no-op an tionól inlíne.
    unsafe {
        // FIXME: Ní féidir úsáid a bhaint `asm!` toisc nach dtacaíonn sé le MIPS agus ailtireachtaí eile.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}