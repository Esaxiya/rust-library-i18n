// Cur chun feidhme bunaidh tógtha ó rust-memchr.
// Cóipcheart 2015 Andrew Gallant, bluss agus Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Úsáid truncation.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Tuairisceáin `true` má tá aon bheart nialasach in `x`.
///
/// Ó *Matters Computational*, J. Arndt:
///
/// "Is é an smaoineamh ceann a dhealú ó gach ceann de na bearta agus ansin bearta a lorg ina bhfuil an iasacht iomadaithe an bealach ar fad go dtí na cinn is suntasaí
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Tuairisceáin an chéad innéacs a thagann leis an `x` beart i `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Conair thapa do shlisníní beaga
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Scanadh ar luach beart amháin trí dhá fhocal `usize` a léamh ag an am.
    //
    // Roinn `text` i dtrí chuid
    // - an chuid tosaigh gan síniú, roimh an gcéad seoladh ailínithe focal i dtéacs
    // - comhlacht, scanadh faoi 2 focal ag an am
    // - an chuid dheireanach atá fágtha, <2 mhéid focal

    // cuardach suas le teorainn ailínithe
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // cuardaigh corp an téacs
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SÁBHÁILTEACHT: ráthaíonn réamhaisnéis an ama achar 2 * usize_bytes ar a laghad
        // idir an fritháireamh agus deireadh an tslis.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // briseadh má tá beart meaitseála ann
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Faigh an beart tar éis an phointe a stop an lúb coirp.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Tuairisceáin an t-innéacs seo caite a thagann leis an `x` beart i `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Scanadh ar luach beart amháin trí dhá fhocal `usize` a léamh ag an am.
    //
    // Roinn `text` i dtrí chuid:
    // - eireaball neamhshainithe, tar éis an seoladh focal ailínithe deireanach i dtéacs,
    // - corp, scanta le 2 fhocal ag an am,
    // - na chéad bhearta atá fágtha, <2 mhéid focal.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Tugaimid ach a fháil ar an fad an réimír agus iarmhír.
        // Sa lár déanaimid dhá phíosa a phróiseáil ag an am céanna.
        // SÁBHÁILTEACHT: tá sé sábháilte `[u8]` a aistriú go `[usize]` ach amháin difríochtaí méide a láimhseáiltear le `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Cuardaigh corp an téacs, déan cinnte nach dtrasnóimid min_aligned_offset.
    // déantar an fritháireamh a ailíniú i gcónaí, mar sin is leor tástáil a dhéanamh ar `>` agus seachnaíonn sé an ró-shreabhadh a d`fhéadfadh a bheith ann.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SÁBHÁILTEACHT: tosaíonn an fritháireamh ag len, suffix.len(), fad is atá sé níos mó ná
        // min_aligned_offset (prefix.len()) is é an fad atá fágtha 2 * chunk_bytes ar a laghad.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Briseadh má tá beart meaitseála ann.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Faigh an beart roimh an bpointe ar stop an lúb coirp.
    text[..offset].iter().rposition(|elt| *elt == x)
}