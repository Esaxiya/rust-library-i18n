//! Macraí a úsáideann Iterators de slice.

// Inlining dhéanann is_empty agus LEN difríocht feidhmíochta mhór
macro_rules! is_empty {
    // An bealach a ndéanaimid fad atreoraithe ZST a ionchódú, oibríonn sé seo do ZST agus neamh-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Chun fáil réidh le roinnt seiceálacha faoi theorainneacha (féach `position`), ríomhtar an fad ar bhealach beagáinín gan choinne.
// (Tástáilte ag `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // táimid úsáidtear uaireanta laistigh de bhloc neamhshábháilte

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Baineann an _cannot_ seo úsáid as `unchecked_sub` toisc go mbímid ag brath ar fhilleadh chun fad na n-iteoirí slice fada ZST a léiriú.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Tá a fhios againn gur féidir le `start <= end`, mar sin, níos fearr a dhéanamh ná `offset_from`, a chaithfidh déileáil le síniú.
            // De réir bratacha cuí a shocrú anseo is féidir linn a rá LLVM seo, rud a chabhraíonn sé a bhaint seiceálacha bounds.
            // SÁBHÁILTEACHT: De réir an chineáil invariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Trí insint do LLVM freisin go bhfuil na leideanna scartha le iolraí cruinn den mhéid cineáil, féadann sé `len() == 0` a bharrfheabhsú go `start == end` in ionad `(end - start) < size`.
            //
            // SÁBHÁILTEACHT: De réir an chineáil invariantach, ailínítear na leideanna ionas go mbeidh an
            //         Ní mór fad idir iad a bheith ina iolraí de mhéid pointee
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// An sainmhíniú a fhorbairt ar na `Iter` agus `IterMut` Iterators
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Filleann sé an chéad eilimint agus bogann sé tús an iteora ar aghaidh faoi 1.
        // Feabhsaíonn sé feidhmíocht go mór i gcomparáid le feidhm líneáilte.
        // Níor chóir go mbeadh an t-iteoir folamh.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Filleann sé an eilimint dheireanach agus bogann sé deireadh an iteora ar gcúl faoi 1.
        // Feabhsaíonn sé feidhmíocht go mór i gcomparáid le feidhm líneáilte.
        // Níor chóir go mbeadh an t-iteoir folamh.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Laghdaíonn sé an t-iteoir nuair is ZST é T, trí dheireadh an atriall a bhogadh ar gcúl le `n`.
        // `n` gan a bheith níos mó ná `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Feidhm Helper chun slice a chruthú ón iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SÁBHÁILTEACHT: Bhí an t-iterator cruthaíodh ó slice le pointeoir
                // `self.ptr` agus fad `len!(self)`.
                // Ráthaíonn sé seo go gcomhlíontar na réamhriachtanais go léir le haghaidh `from_raw_parts`.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Feidhm Helper le gluaiseacht an tús an iterator aghaidh trí eilimintí `offset`, ag filleadh ar an tús d'aois.
            //
            // Neamhshábháilte toisc nár chóir go mbeadh an fritháireamh níos mó ná `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SÁBHÁILTEACHT: ráthaíonn an té atá ag glaoch nach sáraíonn `offset` `self.len()`,
                    // mar sin tá an pointeoir nua seo taobh istigh de `self` agus mar sin ráthaítear go mbeidh sé neamhní.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Feidhm Helper chun bogadh deireadh na gcúl iterator trí eilimintí `offset`, ag filleadh ar an deireadh nua.
            //
            // Neamhshábháilte toisc nár chóir go mbeadh an fritháireamh níos mó ná `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SÁBHÁILTEACHT: ráthaíonn an té atá ag glaoch nach sáraíonn `offset` `self.len()`,
                    // a ráthaítear nach sáraíonn sé `isize`.
                    // Chomh maith leis sin, tá an pointeoir mar thoradh air faoi theorainneacha `slice`, a chomhlíonann na ceanglais eile maidir le `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // gur féidir a bhaint le slices, ach seachnaítear seo seiceálacha bounds

                // SÁBHÁILTEACHT: Tá glaonna `assume` sábháilte ó phointe tosaigh slice
                // caithfidh siad a bheith neamhní, agus caithfidh pointeoir deiridh neamh-null a bheith ag slisní os cionn neamh-ZSTanna.
                // Tá an glao ar `next_unchecked!` sábháilte ós rud é go ndéanaimid seiceáil an bhfuil an t-iteoir folamh ar dtús.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Tá an t-iteoir seo folamh anois.
                    if mem::size_of::<T>() == 0 {
                        // Ní mór dúinn é a dhéanamh ar an mbealach seo mar b`fhéidir nach mbeidh `ptr` riamh 0, ach d`fhéadfadh `end` a bheith (mar gheall ar fhilleadh).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SÁBHÁILTEACHT: Ní féidir deireadh a bheith 0 mura bhfuil T ZST toisc nach bhfuil PTR 0 agus deireadh>=PTR
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SÁBHÁILTEACHT: Táimid faoi theorainneacha.Déanann `post_inc_start` an rud ceart fiú amháin i gcás ZSTanna.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Sáraíonn muid an cur i bhfeidhm réamhshocraithe, a úsáideann `try_fold`, toisc go ngineann an cur chun feidhme simplí seo níos lú LLVM IR agus go bhfuil sé níos tapa a thiomsú.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Sáraíonn muid an cur i bhfeidhm réamhshocraithe, a úsáideann `try_fold`, toisc go ngineann an cur chun feidhme simplí seo níos lú LLVM IR agus go bhfuil sé níos tapa a thiomsú.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Sáraíonn muid an cur i bhfeidhm réamhshocraithe, a úsáideann `try_fold`, toisc go ngineann an cur chun feidhme simplí seo níos lú LLVM IR agus go bhfuil sé níos tapa a thiomsú.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Sáraíonn muid an cur i bhfeidhm réamhshocraithe, a úsáideann `try_fold`, toisc go ngineann an cur chun feidhme simplí seo níos lú LLVM IR agus go bhfuil sé níos tapa a thiomsú.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Sáraíonn muid an cur i bhfeidhm réamhshocraithe, a úsáideann `try_fold`, toisc go ngineann an cur chun feidhme simplí seo níos lú LLVM IR agus go bhfuil sé níos tapa a thiomsú.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Sáraíonn muid an cur i bhfeidhm réamhshocraithe, a úsáideann `try_fold`, toisc go ngineann an cur chun feidhme simplí seo níos lú LLVM IR agus go bhfuil sé níos tapa a thiomsú.
            // Chomh maith leis sin, seachnaíonn an `assume` seiceáil faoi theorainneacha.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SÁBHÁILTEACHT: ráthaítear go mbeidh muid faoi theorainneacha ag an lúb invariant:
                        // nuair a fhilleann `i >= n`, `self.next()` `None` agus briseann an lúb.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Sáraíonn muid an cur i bhfeidhm réamhshocraithe, a úsáideann `try_fold`, toisc go ngineann an cur chun feidhme simplí seo níos lú LLVM IR agus go bhfuil sé níos tapa a thiomsú.
            // Chomh maith leis sin, seachnaíonn an `assume` seiceáil faoi theorainneacha.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SÁBHÁILTEACHT: Caithfidh `i` a bheith níos ísle ná `n` ó thosaíonn sé ag `n`
                        // agus níl sé ach ag laghdú.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch a ráthú go bhfuil `i` faoi theorainneacha
                // an slice bunúsach, mar sin ní féidir le `i` `isize` a ró-shreabhadh, agus ráthaítear go dtagraíonn na tagairtí a chuirtear ar ais d`eilimint den slice agus mar sin ráthaítear go bhfuil siad bailí.
                //
                // Tabhair faoi deara freisin go ráthaíonn an té atá ag glaoch nach nglaofar riamh leis an innéacs céanna arís, agus nach nglaofar ar aon mhodhanna eile a thabharfaidh rochtain ar an bhfolús seo, mar sin tá sé bailí go mbeidh an tagairt ar ais inathraithe i gcás
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // gur féidir a bhaint le slices, ach seachnaítear seo seiceálacha bounds

                // SÁBHÁILTEACHT: Tá glaonna `assume` sábháilte ós rud é go gcaithfidh pointeoir tosaigh slice a bheith neamhní,
                // agus caithfidh pointeoir deiridh neamh-null a bheith ag slisní os cionn ZSTanna.
                // Tá an glao ar `next_back_unchecked!` sábháilte ós rud é go ndéanaimid seiceáil an bhfuil an t-iteoir folamh ar dtús.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Tá an t-iteoir seo folamh anois.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SÁBHÁILTEACHT: Táimid faoi theorainneacha.Déanann `pre_dec_end` an rud ceart fiú amháin i gcás ZSTanna.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}