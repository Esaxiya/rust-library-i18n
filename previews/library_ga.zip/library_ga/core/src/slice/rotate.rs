// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Rothlaíonn sé an raon `[mid-left, mid+right)` sa chaoi is gurb í an eilimint ag `mid` an chéad eilimint.Equivalently rotates, an raon heilimintí `left` leis na heilimintí taobh clé nó `right` leis an gceart.
///
/// # Safety
///
/// Caithfidh an raon sonraithe a bheith bailí don léitheoireacht agus don scríbhneoireacht.
///
/// # Algorithm
///
/// Úsáidtear algartam 1 le haghaidh luachanna beaga `left + right` nó le haghaidh `T` mór.
/// Bogtar na heilimintí isteach ina suíomhanna deiridh ceann ag an am ag tosú ag `mid - left` agus ag dul ar aghaidh le céimeanna `right` modulo `left + right`, sa chaoi nach dteastaíonn ach sealadach amháin.
/// Faoi dheireadh, sroicheann muid ar ais ag `mid - left`.
/// Mar sin féin, mura bhfuil `gcd(left + right, right)` 1, chuaigh na céimeanna thuas thar eilimintí.
/// Mar shampla:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Ar ámharaí an tsaoil, tá líon na n-eilimintí scipeáilte idir eilimintí críochnaithe cothrom i gcónaí, ionas gur féidir linn ár suíomh tosaigh a fhritháireamh agus níos mó babhtaí a dhéanamh (is é an `gcd(left + right, right)` value) líon iomlán na mbabhta.
///
/// Is é an toradh deiridh ná go ndéantar gach gné a thabhairt chun críche uair amháin agus uair amháin.
///
/// Úsáidtear algartam 2 má tá `left + right` mór ach go bhfuil `min(left, right)` beag go leor le feistiú ar mhaolán cruachta.
/// Na heilimintí `min(left, right)` a chóipeáil isteach ar an Maolán, tá `memmove` i bhfeidhm ar na cinn eile, agus na cinn ar an maolán ar athraíodh a ionad ar ais isteach sa pholl ar an taobh eile den nuair a tháinig siad.
///
/// Halgartaim is féidir a vectorized outperform an méid sin thuas é nuair a thagann `left + right` leor mór.
/// Is féidir algartam 1 a veicteoiriú trí go leor babhtaí a smideadh agus a dhéanamh ag an am céanna, ach níl an iomarca babhtaí ann ar an meán go dtí go mbíonn `left + right` ollmhór, agus bíonn an cás is measa de bhabhta amháin ann i gcónaí.
/// Ina áit sin, úsáideann algartam 3 babhtáil arís agus arís eile ar eilimintí `min(left, right)` go dtí go bhfágtar fadhb rothlaithe níos lú.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// nuair a dhéantar `left < right` déantar an babhtáil ón taobh clé ina ionad.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. is féidir go dteipfidh ar na halgartaim thíos mura ndéantar na cásanna seo a sheiceáil
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algartam 1 Tugann micrea-chomharthaí le fios gur fearr an meánfheidhmíocht le haghaidh aistrithe randamacha an bealach ar fad go dtí thart ar `left + right == 32`, ach tá feidhmíocht an cháis is measa cothrom le timpeall 16.
            // Roghnaíodh 24 mar thalamh lár.
            // Má tá an méid `T` níos mó ná 4 `usize`s, outperforms an algartam freisin halgartaim eile.
            //
            //
            let x = unsafe { mid.sub(left) };
            // ag tosú ar an gcéad bhabhta
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` is féidir iad a fháil roimh ré trí `gcd(left + right, right)` a ríomh, ach is gasta lúb amháin a dhéanamh a ríomhann an gcd mar fho-iarmhairt, agus an chuid eile den smután á dhéanamh ansin
            //
            //
            let mut gcd = right;
            // nochtann tagarmharcanna go bhfuil sé níos tapa temporaries a mhalartú tríd an mbealach in ionad sealadach amháin a léamh uair amháin, cóipeáil ar gcúl, agus ansin an sealadach sin a scríobh ag an deireadh.
            // B`fhéidir go bhfuil sé seo toisc nach n-úsáideann ach malartú nó athsholáthar tempora ach seoladh cuimhne amháin sa lúb in ionad a bheith ag teastáil chun dhá cheann a bhainistiú.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // in ionad `i` a mhéadú agus ansin seiceáil an bhfuil sé lasmuigh de na teorainneacha, déanaimid seiceáil an rachaidh `i` lasmuigh de na teorainneacha ar an gcéad incrimint eile.
                // Seo cosc ar aon timfhilleadh ar threo nó `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // deireadh an chéad bhabhta
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // caithfidh an coinníollach seo a bheith anseo más `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // críochnaigh an smután le níos mó babhtaí
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ní cineál meánmhéide é, mar sin tá sé ceart go leor a roinnt de réir a mhéid.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algartam 2 Is é an `[T; 0]` anseo a chinntiú go bhfuil sé seo ailínithe go cuí do T.
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algartam 3 Tá bealach malartach ann le babhtáil lena mbaineann a fháil amach cá mbeadh an babhtáil deireanach den algartam seo, agus babhtáil ag baint úsáide as an smután deireanach sin in ionad smután cóngarach mar atá an algartam seo a mhalartú, ach tá an bealach seo níos gasta fós.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algartam 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}