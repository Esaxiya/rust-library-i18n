//! Feidhmeanna saor in aisce chun `&[T]` agus `&mut [T]` a chruthú.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Foirmeacha a slice ó pointeoir agus fad.
///
/// Is í argóint `len` líon na n-eilimintí **, ní líon na mbeart.
///
/// # Safety
///
/// Tá Oibriú undefined más ann de na coinníollacha seo a leanas atáid:
///
/// * `data` caithfidh sé a bheith [valid] le haghaidh léamha le haghaidh `len * mem::size_of::<T>()` go leor beart, agus caithfear é a ailíniú i gceart.Ciallaíonn sé seo go háirithe:
///
///     * Ní mór raon cuimhne iomlán an tslis seo a bheith laistigh d`ábhar leithdháilte amháin!
///       Ní féidir le slisní réise a dhéanamh ar fud earraí iolracha leithdháilte.Féach [below](#incorrect-usage) le haghaidh sampla go mícheart gan é seo a chur san áireamh.
///     * `data` caithfidh siad a bheith neamhní agus ailínithe fiú le haghaidh slisní faid nialasacha.
///     Cúis amháin leis seo ná go bhféadfadh barrfheabhsú leagan amach enum a bheith ag brath ar thagairtí (lena n-áirítear slisní ar aon fhaid) a bheith ailínithe agus neamh-null chun iad a idirdhealú ó shonraí eile.
///     Is féidir leat pointeoir a fháil atá inúsáidte mar `data` le haghaidh slisní faid nialasacha ag úsáid [`NonNull::dangling()`].
///
/// * `data` caithfidh siad tagairt do luachanna `len` comhleanúnacha i gceart de chineál `T`.
///
/// * Níor cheart an chuimhne dá dtagraítear ag an slice ar ais a threáitearú ar feadh shaolré `'a`, ach amháin taobh istigh de `UnsafeCell`.
///
/// * Ní mór nach mbeidh méid iomlán `len * mem::size_of::<T>()` an slice níos mó ná `isize::MAX`.
///   Féach ar dhoiciméadú shábháilteacht [`pointer::offset`].
///
/// # Caveat
///
/// Faightear saolré an tsleachta ar ais óna úsáid.
/// Chun mí-úsáid thimpiste a chosc, moltar an saolré a cheangal le cibé foinse foinse atá sábháilte sa chomhthéacs, mar shampla trí fheidhm chúntóra a sholáthar a thógann saolré luach óstach don slice, nó trí anótáil shoiléir.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // slice a léiriú d`eilimint amháin
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### úsáid mícheart
///
/// Is í an fheidhm `join_slices` leanas **lochtach** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Cinntíonn an dearbhú thuas go bhfuil `fst` agus `snd` tadhlach le chéile, ach d`fhéadfadh go mbeadh siad fós laistigh de _different allocated objects_, agus sa chás sin is iompar neamhshainithe é an slice seo a chruthú.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` agus rudaí leithdháilte difriúla iad `b` ...
///     let a = 42;
///     let b = 27;
///     // ... a fhéadfar a leagan amach mar chuimhneamh mar sin féin: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `from_raw_parts` a sheasamh.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Feidhmíonn sé an fheidhmiúlacht chéanna le [`from_raw_parts`], ach amháin go gcuirtear slice inathraithe ar ais.
///
/// # Safety
///
/// Tá Oibriú undefined más ann de na coinníollacha seo a leanas atáid:
///
/// * `data` caithfidh [valid] a bheith ann le go leor beart agus léamh do `len * mem::size_of::<T>()`, agus caithfear é a ailíniú i gceart.Ciallaíonn sé seo go háirithe:
///
///     * Ní mór raon cuimhne iomlán an tslis seo a bheith laistigh d`ábhar leithdháilte amháin!
///       Ní féidir le Slices span fud na rudaí a leithdháileadh il.
///     * `data` caithfidh siad a bheith neamhní agus ailínithe fiú le haghaidh slisní faid nialasacha.
///     Cúis amháin leis seo ná go bhféadfadh barrfheabhsú leagan amach enum a bheith ag brath ar thagairtí (lena n-áirítear slisní ar aon fhaid) a bheith ailínithe agus neamh-null chun iad a idirdhealú ó shonraí eile.
///
///     Is féidir leat pointeoir a fháil atá inúsáidte mar `data` le haghaidh slisní faid nialasacha ag úsáid [`NonNull::dangling()`].
///
/// * `data` caithfidh siad tagairt do luachanna `len` comhleanúnacha i gceart de chineál `T`.
///
/// * Ní féidir rochtain a fháil ar an gcuimhne dá dtagraítear ag an slice ar ais trí aon phointeoir eile (nach bhfuil díorthaithe ón luach toraidh) ar feadh shaolré `'a`.
///   Tá cosc ar rochtain a léamh agus a scríobh.
///
/// * Ní mór nach mbeidh méid iomlán `len * mem::size_of::<T>()` an slice níos mó ná `isize::MAX`.
///   Féach ar dhoiciméadú shábháilteacht [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `from_raw_parts_mut` a sheasamh.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Tiontaíonn sé tagairt do T i slice de fhad 1 (gan cóipeáil).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Tiontaíonn sé tagairt do T i slice de fhad 1 (gan cóipeáil).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}