// ignore-tidy-filelength

//! bainistíocht Slice agus ionramháil.
//!
//! Le haghaidh tuilleadh sonraí a fháil féach [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// cur i bhfeidhm memchr Pure rust, tógtha ó rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Tá an fheidhm seo poiblí ach toisc nach bhfuil aon bhealach eile ann le heapsort tástála aonaid.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Filleann sé líon na n-eilimintí sa slice.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SÁBHÁILTEACHT: fuaim seasmhach toisc go n-aistrímid amach an réimse faid mar usize (ní foláir dó a bheith)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SÁBHÁILTEACHT: tá sé seo sábháilte toisc go bhfuil an leagan amach céanna ag `&[T]` agus `FatPtr<T>`.
            // Ní féidir ach le `std` an ráthaíocht seo a dhéanamh.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Ionadaigh le `crate::ptr::metadata(self)` nuair is é sin CONST-cobhsaí.
            // Mar gheall ar an scríbhinn seo is botún "Const-stable functions can only call other const-stable functions" é seo.
            //

            // SÁBHÁILTEACHT: Tá sé sábháilte rochtain a fháil ar an luach ón aontas `PtrRepr` ó * const T.
            // agus PtrComponents<T>tá an leagan amach chuimhne chéanna.
            // Ní féidir ach le std an ráthaíocht seo a dhéanamh.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Tuairisceáin `true` má tá an slice fad de 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Filleann sé an chéad eilimint den slice, nó `None` má tá sé folamh.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Tugann pointeoir inathraithe ar ais don chéad eilimint den slice, nó `None` má tá sé folamh.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Tuairisceáin an chéad agus an chuid eile de na gnéithe den slice, nó an `None` má tá sé folamh.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Tuairisceáin an chéad agus an chuid eile de na gnéithe den slice, nó an `None` má tá sé folamh.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Filleann sé an chuid dheireanach agus an chuid eile go léir d`eilimintí an tslis, nó `None` má tá sé folamh.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Filleann sé an chuid dheireanach agus an chuid eile go léir d`eilimintí an tslis, nó `None` má tá sé folamh.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Tuairisceáin an ghné dheireanach den slice, nó an `None` má tá sé folamh.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Tugann pointeoir inathraithe ar ais don mhír dheiridh sa slice.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Tagairt ar eilimint nó ar fholús a chur ar ais ag brath ar an gcineál innéacs.
    ///
    /// - Má thugtar post duit, seol tagairt don eilimint ag an suíomh sin nó `None` ar ais má tá sí lasmuigh de theorainneacha.
    ///
    /// - Má thugtar raon dó, seolfaidh sé an fhoshraith a fhreagraíonn don raon sin, nó `None` más as teorainneacha é.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Tuairisceáin tagairt mutable do eilimint nó subslice ag brath ar an gcineál innéacs (féach [`get`]) nó `None` más an t-innéacs as bounds.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Tuairisceáin tagairt d'eilimint nó subslice, gan bounds seiceáil a dhéanamh.
    ///
    /// I gcás ina rogha malartach sábháilte fheiceáil [`get`].
    ///
    /// # Safety
    ///
    /// Ag glaoch ar an modh seo le innéacs lasmuigh d'bounds é *[iompar undefined]* fiú má tá an tagairt mar thoradh air nach n-úsáidtear.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SÁBHÁILTEACHT: an té atá ag glaoch Ní mór seasamh le an chuid is mó de na gceanglas sábháilteachta do `get_unchecked`;
        // tá an slice neamh-inchúlghairthe toisc gur tagairt shábháilte é `self`.
        // Tá an pointeoir ar ais sábháilte toisc go gcaithfidh impls `SliceIndex` a ráthú go bhfuil sé.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Tuairisceáin tagairt mutable do eilimint nó subslice, gan bounds seiceáil a dhéanamh.
    ///
    /// Le haghaidh rogha sábháilte eile féach [`get_mut`].
    ///
    /// # Safety
    ///
    /// Ag glaoch ar an modh seo le innéacs lasmuigh d'bounds é *[iompar undefined]* fiú má tá an tagairt mar thoradh air nach n-úsáidtear.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SÁBHÁILTEACHT: an té atá ag glaoch ní mór seasamh leis na ceanglais sábháilteachta do `get_unchecked_mut`;
        // tá an slice neamh-inchúlghairthe toisc gur tagairt shábháilte é `self`.
        // Tá an pointeoir ar ais sábháilte toisc go gcaithfidh impls `SliceIndex` a ráthú go bhfuil sé.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Tugann pointeoir amh ar ais do mhaolán an tslis.
    ///
    /// Caithfidh an té atá ag glaoch a chinntiú go sáraíonn an slice an pointeoir a fhilleann an fheidhm seo, nó go ndíreoidh sé ar truflais sa deireadh.
    ///
    /// Ní mór don té atá ag glaoch a chinntiú freisin go bhfuil an chuimhne na pointí (non-transitively) pointeoir riamh scríofa go (ach amháin taobh istigh `UnsafeCell`) ag baint úsáide as an pointeoir nó aon pointeoir a dhíorthaítear ó sé.
    /// Más gá duit a mutate an ábhar ar an slice, bain úsáid as [`as_mut_ptr`].
    ///
    /// Lena modhnaítear an coimeádán tagairt ag an slice a chur faoi deara ar a Maolán le hath-leithroinnt, rud a dhéanamh freisin ar aon leideanna chun neamhbhailí é.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Tugann sé pointeoir neamhshábháilte neamhshábháilte ar ais do mhaolán an tslis.
    ///
    /// Caithfidh an té atá ag glaoch a chinntiú go sáraíonn an slice an pointeoir a fhilleann an fheidhm seo, nó go ndíreoidh sé ar truflais sa deireadh.
    ///
    /// Lena modhnaítear an coimeádán tagairt ag an slice a chur faoi deara ar a Maolán le hath-leithroinnt, rud a dhéanamh freisin ar aon leideanna chun neamhbhailí é.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Tuairisceáin an dá threo amh chuimsíonn an slice.
    ///
    /// Tá an raon ar ais leath-oscailte, a ciallaíonn go *na pointí pointeoir deiridh i ndiaidh a haon* an ghné dheireanach den slice.
    /// Ar an mbealach seo, léirítear slice folamh le dhá phointe chomhionanna, agus is ionann an difríocht idir an dá threo agus méid an tslis.
    ///
    /// Féach [`as_ptr`] do rabhaidh ar úsáid a bhaint na leideanna.Teastaíonn rabhadh breise ón bpointeoir deiridh, mar ní dhíríonn sé ar ghné bhailí sa slice.
    ///
    /// Tá an fheidhm seo úsáideach chun idirghníomhú le comhéadain eachtracha a úsáideann dhá threo chun tagairt a dhéanamh do raon eilimintí sa chuimhne, mar atá coitianta i C++ .
    ///
    ///
    /// Is féidir é a freisin úsáideach a seiceáil má thagraíonn pointeoir le heilimint do gné den slice:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SÁBHÁILTEACHT: Tá an `add` anseo sábháilte, mar gheall ar:
        //
        //   - Tá an dá threo mar chuid den réad céanna, toisc go bhfuil pointeáil díreach thart ar an réad comhaireamh freisin.
        //
        //   - Ní bhíonn méid na slice riamh níos mó ná bearta isize::MAX, mar a nótáiltear anseo:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Níl aon fhilleadh timpeall i gceist, mar ní fillteann slisní thart ar dheireadh an spáis seoltaí.
        //
        // Féach cáipéisíocht pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Filleann sé an dá phointe neamhshábháilte neamhshábháilte a chuimsíonn an slice.
    ///
    /// Tá an raon ar ais leath-oscailte, a ciallaíonn go *na pointí pointeoir deiridh i ndiaidh a haon* an ghné dheireanach den slice.
    /// Ar an mbealach seo, léirítear slice folamh le dhá phointe chomhionanna, agus is ionann an difríocht idir an dá threo agus méid an tslis.
    ///
    /// Féach [`as_mut_ptr`] do rabhaidh ar úsáid a bhaint na leideanna.
    /// Teastaíonn rabhadh breise ón bpointeoir deiridh, mar ní dhíríonn sé ar ghné bhailí sa slice.
    ///
    /// Tá an fheidhm seo úsáideach chun idirghníomhú le comhéadain eachtracha a úsáideann dhá threo chun tagairt a dhéanamh do raon eilimintí sa chuimhne, mar atá coitianta i C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // SÁBHÁILTEACHT: Féach as_ptr_range() thuas ar an bhfáth go bhfuil `add` anseo sábháilte.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Babhtáil dhá ghné sa slice.
    ///
    /// # Arguments
    ///
    /// * a, Innéacs na chéad eiliminte
    /// * b, An t-innéacs ar an dara heilimint
    ///
    /// # Panics
    ///
    /// Panics má tá `a` nó `b` as teorainneacha.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Ní féidir dhá iasacht inathraithe a ghlacadh ó vector amháin, mar sin bain úsáid as leideanna amha.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SÁBHÁILTEACHT: `pa` agus `pb` Cruthaíodh ó tagairtí sábháilte mutable agus tagairt
        // le heilimintí sa slice agus mar sin ráthaítear go mbeidh siad bailí agus ailínithe.
        // Tabhair faoi deara go ndéantar rochtain ar na heilimintí taobh thiar de `a` agus `b` a sheiceáil agus go mbeidh panic ann nuair a bheidh sé lasmuigh de theorainneacha.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Aisiompaíonn ord na n-eilimintí sa slice, i bhfeidhm.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // I gcás cineálacha an-bheag, gach léann an bpearsa aonair sa cosán gnáth feidhmíonn siad go dona.
        // Is féidir linn níos fearr a dhéanamh, má thugtar load/store neamhshainithe éifeachtach, trí smután níos mó a luchtú agus clár a aisiompú.
        //

        // Go hidéalach, dhéanfadh LLVM é seo dúinn, mar is eol dó níos fearr ná mar a dhéanaimid an bhfuil léamha neamhshainithe éifeachtach (ós rud é go n-athraíonn sé sin idir leaganacha éagsúla ARM, mar shampla) agus cad é an méid smután is fearr a bheadh ann.
        // Ar an drochuair, ó LLVM 4.0 (2017-05) ní dhéanann sé ach an lúb a rolladh amach, mar sin caithfimid é seo a dhéanamh muid féin.
        // (Hipitéis: tá an droim ar ais trioblóideach toisc gur féidir na taobhanna a ailíniú ar bhealach difriúil-beidh, nuair a bhíonn an fad corr-mar sin níl aon bhealach ann réamh-agus iar-astaí a astú chun SIMD lán-ailínithe a úsáid sa lár.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Úsáid an llvm.bswap intreach chun u8anna a aisiompú in úsáid
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // SÁBHÁILTEACHT: Tá roinnt rudaí le seiceáil anseo:
                //
                // - Tabhair faoi deara go bhfuil `chunk` 4 nó 8 mar gheall ar an seiceáil cfg thuas.Dá bhrí sin tá `chunk - 1` dearfach.
                // - Is innéacsú le innéacs `i` fíneáil mar na ráthaíochtaí seic lúb
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Tá innéacsú le hinnéacs `ln - i - chunk = ln - (i + chunk)` go maith:
                //   - `i + chunk > 0` fíor fánach.
                //   - Ráthaíonn an seiceáil lúb:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, dá bhrí sin ní sháraíonn an dealú.
                // - Is iad na glaonna `read_unaligned` agus `write_unaligned` fíneáil:
                //   - `pa` pointí le hinnéacs `i` áit a bhfuil `i < ln / 2 - (chunk - 1)` (féach thuas) agus `pb` ag pointeáil le hinnéacs `ln - i - chunk`, mar sin tá an dá cheann ar a laghad `chunk` go leor beart ar shiúl ó dheireadh `self`.
                //
                //   - Tá aon chuimhne tosaigh bailí `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Úsáid rothlú-le-16 chun u16anna a aisiompú i u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SÁBHÁILTEACHT: Is féidir u32 neamhshainithe a léamh ó `i` más `i + 1 < ln` é
                // (agus `i < ln` ar ndóigh), toisc go bhfuil gach eilimint 2 bheart agus táimid ag léamh 4.
                //
                // `i + chunk - 1 < ln / 2` # agus riocht
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Ós rud é go bhfuil sé níos lú ná an fad arna roinnt ar 2, ansin caithfidh sé a bheith in bounds.
                //
                // Ciallaíonn sé seo freisin go n-urramaítear an coinníoll `0 < i + chunk <= ln` i gcónaí, ag cinntiú gur féidir an pointeoir `pb` a úsáid go sábháilte.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SÁBHÁILTEACHT: Tá `i` níos lú ná leath fhad an tslis mar sin
            // tá rochtain ar `i` agus `ln - i - 1` sábháilte (tosaíonn `i` ag 0 agus ní rachaidh sé níos faide ná `ln / 2 - 1`).
            // Is iad na leideanna mar thoradh air `pa` agus `pb` bailí dá bhrí sin agus ailíniú, agus is féidir iad a léamh ó agus scríofa go.
            //
            //
            unsafe {
                // Babhtáil neamhshábháilte chun na teorainneacha a sheachaint seiceáil i mbabhtáil shábháilte.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Seoltar atriall thar an slice.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Seoltar atriall ar ais a cheadaíonn gach luach a mhodhnú.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Tuairisceáin an iterator os cionn gach windows tadhlach de fhad `size`.
    /// An forluí windows.
    /// Má tá an slice níos giorra ná `size`, ní fhilleann an t-iteoir aon luachanna.
    ///
    /// # Panics
    ///
    /// Panics más 000 `size`.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Má tá an slice níos giorra ná `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Seoltar atriall thar eilimintí `chunk_size` den slice ag an am, ag tosú ag tús an tslis.
    ///
    /// Is slisní iad na smutáin agus ní dhéanann siad forluí.Mura roinneann `chunk_size` fad an tslis, ansin ní bheidh fad `chunk_size` ag an smután deireanach.
    ///
    /// Féach [`chunks_exact`] le haghaidh leagan eile den atriallóir seo a fhilleann giotaí d`eilimintí `chunk_size` díreach i gcónaí, agus [`rchunks`] don iterator céanna ach a thosaíonn ag deireadh an tslis.
    ///
    ///
    /// # Panics
    ///
    /// Is Panics más rud é `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Seoltar atriall thar eilimintí `chunk_size` den slice ag an am, ag tosú ag tús an tslis.
    ///
    /// Is slisní inathraithe iad na smutáin, agus ní dhéanann siad forluí.Mura roinneann `chunk_size` fad an tslis, ansin ní bheidh fad `chunk_size` ag an smután deireanach.
    ///
    /// Féach [`chunks_exact_mut`] le haghaidh leagan eile den atriallóir seo a fhilleann giotaí d`eilimintí `chunk_size` díreach i gcónaí, agus [`rchunks_mut`] don iterator céanna ach a thosaíonn ag deireadh an tslis.
    ///
    ///
    /// # Panics
    ///
    /// Is Panics más rud é `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Seoltar atriall thar eilimintí `chunk_size` den slice ag an am, ag tosú ag tús an tslis.
    ///
    /// Is slisní iad na smutáin agus ní dhéanann siad forluí.
    /// Más rud é nach ndéanann `chunk_size` roinnt ar fad an slice, ansin beidh an t-suas caite le heilimintí `chunk_size-1` a fhágáil ar lár agus is féidir a aisghabháil ó fheidhm `remainder` an iterator.
    ///
    ///
    /// De bharr gach smután bhfuil go díreach eilimintí `chunk_size`, is féidir leis an tiomsaitheoir bhaint as go minic ar an cód mar thoradh air níos fearr ná i gcás [`chunks`].
    ///
    /// Féach [`chunks`] feadh a mhalairt de an iterator go tuairisceáin freisin an chuid eile mar smután níos lú, agus [`rchunks_exact`] don iterator céanna ach ag tosú ag deireadh na slice.
    ///
    /// # Panics
    ///
    /// Is Panics más rud é `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Seoltar atriall thar eilimintí `chunk_size` den slice ag an am, ag tosú ag tús an tslis.
    ///
    /// Is slisní inathraithe iad na smutáin, agus ní dhéanann siad forluí.
    /// Mura roinneann `chunk_size` fad an tslis, fágfar an ceann deireanach suas go dtí na heilimintí `chunk_size-1` ar lár agus is féidir iad a aisghabháil ó fheidhm `into_remainder` an iterator.
    ///
    ///
    /// De bharr go bhfuil eilimintí `chunk_size` díreach ag gach smután, is minic gur féidir leis an tiomsaitheoir an cód a leanann é a bharrfheabhsú níos fearr ná i gcás [`chunks_mut`].
    ///
    /// Féach [`chunks_mut`] feadh a mhalairt de an iterator go tuairisceáin freisin an chuid eile mar smután níos lú, agus [`rchunks_exact_mut`] don iterator céanna ach ag tosú ag deireadh na slice.
    ///
    /// # Panics
    ///
    /// Is Panics más rud é `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Roinntear an slice i slice de eagair eiliminte `N`, ag glacadh leis nach bhfuil fuílleach ann.
    ///
    ///
    /// # Safety
    ///
    /// Is féidir é seo a dtugtar ach amháin nuair
    /// - Roinntear an slice go díreach i smutáin eilimint `N` (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SÁBHÁILTEACHT: smután 1-eilimint riamh eile
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // Is é an fad slice (6) iolraí de 3: SAFETY
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Bheadh siad seo míshuaimhneach:
    /// // ligean smután: &[[_;5]]= slice.as_chunks_unchecked()//Ní iolraí de 5 smután an fad slice:&[[_;0]] riamh smután= slice.as_chunks_unchecked()//Zero-fhad cheadú
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // Is é ár réamhchoinníoll go díreach cad atá ag teastáil a thabhairt ar an: SAFETY
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SÁBHÁILTEACHT: Chaith muid slice d`eilimintí `new_len * N` isteach
        // slice de go leor smután eilimintí `N` `new_len`.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Roinntear an slice i slice de eagair eiliminte `N`, ag tosú ag tús an tslis, agus slice fuíll le faid atá níos lú ná `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics má tá `N` 0. Beidh an seic fháil athrú is dócha go earráid am tiomsaithe sula bhfaigheann an modh chobhsaithe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SÁBHÁILTEACHT: Phreabamar go nialas cheana féin, agus chinntíomar an tógáil
        // gur iolraí de N. fad an fholús.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Roinntear an slice isteach i slice de `N` arrays-eilimint, ag tosú ag deireadh na slice, agus slice eile le fad go docht níos lú ná `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics má tá `N` 0. Beidh an seic fháil athrú is dócha go earráid am tiomsaithe sula bhfaigheann an modh chobhsaithe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SÁBHÁILTEACHT: Phreabamar go nialas cheana féin, agus chinntíomar an tógáil
        // gur iolraí de N. fad an fholús.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Seoltar atriall thar eilimintí `N` den slice ag an am, ag tosú ag tús an tslis.
    ///
    /// Is iad na smután tagairtí eagar agus nach forluí.
    /// Mura roinneann `N` fad an tslis, fágfar an ceann deireanach suas go dtí na heilimintí `N-1` ar lár agus is féidir iad a aisghabháil ó fheidhm `remainder` an iterator.
    ///
    ///
    /// Is é an modh seo an coibhéis cineálach const de [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics má tá `N` 0. Beidh an seic fháil athrú is dócha go earráid am tiomsaithe sula bhfaigheann an modh chobhsaithe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Roinntear an slice i slice de eagair eiliminte `N`, ag glacadh leis nach bhfuil fuílleach ann.
    ///
    ///
    /// # Safety
    ///
    /// Is féidir é seo a dtugtar ach amháin nuair
    /// - Roinntear an slice go díreach i smutáin eilimint `N` (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SÁBHÁILTEACHT: smután 1-eilimint riamh eile
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // Is é an fad slice (6) iolraí de 3: SAFETY
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Bheadh siad seo míshuaimhneach:
    /// // lig smutáin: &[[_;5]]= slice.as_chunks_unchecked_mut()//Ní iolraí de 5 smután an fad slice:&[[_;0]]= slice.as_chunks_unchecked_mut()//Ní cheadaítear smideadh nialais riamh
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // Is é ár réamhchoinníoll go díreach cad atá ag teastáil a thabhairt ar an: SAFETY
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SÁBHÁILTEACHT: Chaith muid slice d`eilimintí `new_len * N` isteach
        // slice de go leor smután eilimintí `N` `new_len`.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Roinntear an slice i slice de eagair eiliminte `N`, ag tosú ag tús an tslis, agus slice fuíll le faid atá níos lú ná `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics má tá `N` 0. Beidh an seic fháil athrú is dócha go earráid am tiomsaithe sula bhfaigheann an modh chobhsaithe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SÁBHÁILTEACHT: Phreabamar go nialas cheana féin, agus chinntíomar an tógáil
        // gur iolraí de N. fad an fholús.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Roinntear an slice isteach i slice de `N` arrays-eilimint, ag tosú ag deireadh na slice, agus slice eile le fad go docht níos lú ná `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics má tá `N` 0. Beidh an seic fháil athrú is dócha go earráid am tiomsaithe sula bhfaigheann an modh chobhsaithe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SÁBHÁILTEACHT: Phreabamar go nialas cheana féin, agus chinntíomar an tógáil
        // gur iolraí de N. fad an fholús.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Seoltar atriall thar eilimintí `N` den slice ag an am, ag tosú ag tús an tslis.
    ///
    /// Is iad na smután tagairtí eagar mutable agus nach forluí.
    /// Mura roinneann `N` fad an tslis, fágfar an ceann deireanach suas go dtí na heilimintí `N-1` ar lár agus is féidir iad a aisghabháil ó fheidhm `into_remainder` an iterator.
    ///
    ///
    /// Is é an modh seo an coibhéis cineálach const de [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics má tá `N` 0. Beidh an seic fháil athrú is dócha go earráid am tiomsaithe sula bhfaigheann an modh chobhsaithe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Seoltar atriall ar ais thar eilimintí forluiteacha windows de `N` de shlis, ag tosú ag tús an tslis.
    ///
    ///
    /// Is é seo an coibhéis cineálach const de [`windows`].
    ///
    /// Má tá `N` níos mó ná méid na slice, ní fhillfidh sé aon windows.
    ///
    /// # Panics
    ///
    /// Is Panics más rud é `N` 0.
    /// Is dócha go n-athrófar an seiceáil seo go dtí earráid ama a thiomsú sula ndéanfar an modh seo a chobhsú.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Seoltar atriall thar eilimintí `chunk_size` den slice ag an am, ag tosú ag deireadh an tslis.
    ///
    /// Is slisní iad na smutáin agus ní dhéanann siad forluí.Mura roinneann `chunk_size` fad an tslis, ansin ní bheidh fad `chunk_size` ag an smután deireanach.
    ///
    /// Féach [`rchunks_exact`] le haghaidh leagan eile den atriallóir seo a fhilleann giotaí d`eilimintí `chunk_size` díreach i gcónaí, agus [`chunks`] don iterator céanna ach a thosaíonn ag tús an tslis.
    ///
    ///
    /// # Panics
    ///
    /// Is Panics más rud é `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Seoltar atriall thar eilimintí `chunk_size` den slice ag an am, ag tosú ag deireadh an tslis.
    ///
    /// Is slisní inathraithe iad na smutáin, agus ní dhéanann siad forluí.Mura roinneann `chunk_size` fad an tslis, ansin ní bheidh fad `chunk_size` ag an smután deireanach.
    ///
    /// Féach [`rchunks_exact_mut`] le haghaidh leagan eile den atriallóir seo a fhilleann giotaí d`eilimintí `chunk_size` díreach i gcónaí, agus [`chunks_mut`] don iterator céanna ach a thosaíonn ag tús an tslis.
    ///
    ///
    /// # Panics
    ///
    /// Is Panics más rud é `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Seoltar atriall thar eilimintí `chunk_size` den slice ag an am, ag tosú ag deireadh an tslis.
    ///
    /// Is slisní iad na smutáin agus ní dhéanann siad forluí.
    /// Más rud é nach ndéanann `chunk_size` roinnt ar fad an slice, ansin beidh an t-suas caite le heilimintí `chunk_size-1` a fhágáil ar lár agus is féidir a aisghabháil ó fheidhm `remainder` an iterator.
    ///
    /// De bharr gach smután bhfuil go díreach eilimintí `chunk_size`, is féidir leis an tiomsaitheoir bhaint as go minic ar an cód mar thoradh air níos fearr ná i gcás [`chunks`].
    ///
    /// Féach [`rchunks`] le haghaidh leagan eile den atriallóir seo a fhilleann an fuílleach mar smután níos lú, agus [`chunks_exact`] don atriall céanna ach a thosaíonn ag tús an tslis.
    ///
    ///
    /// # Panics
    ///
    /// Is Panics más rud é `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Seoltar atriall thar eilimintí `chunk_size` den slice ag an am, ag tosú ag deireadh an tslis.
    ///
    /// Is slisní inathraithe iad na smutáin, agus ní dhéanann siad forluí.
    /// Mura roinneann `chunk_size` fad an tslis, fágfar an ceann deireanach suas go dtí na heilimintí `chunk_size-1` ar lár agus is féidir iad a aisghabháil ó fheidhm `into_remainder` an iterator.
    ///
    /// De bharr go bhfuil eilimintí `chunk_size` díreach ag gach smután, is minic gur féidir leis an tiomsaitheoir an cód a leanann é a bharrfheabhsú níos fearr ná i gcás [`chunks_mut`].
    ///
    /// Féach [`rchunks_mut`] feadh a mhalairt de an iterator go tuairisceáin freisin an chuid eile mar smután níos lú, agus [`chunks_exact_mut`] don iterator céanna ach ag tosú ag tús an slice.
    ///
    ///
    /// # Panics
    ///
    /// Is Panics más rud é `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Tuairisceáin an iterator thar an slice a tháirgeadh ritheann neamh-forluí na n-eilimintí ag baint úsáide as an phreideacáid iad a dheighilt.
    ///
    /// Glaoitear an predicate ar dhá ghné ag leanúint orthu féin, ciallaíonn sé go dtugtar an predicate ar `slice[0]` agus `slice[1]` ansin ar `slice[1]` agus `slice[2]` agus mar sin de.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Is féidir an modh seo a úsáid chun na foshraitheanna sórtáilte a bhaint:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Seoltar atriall ar ais thar an slice a tháirgeann ritheann neamh-fhorluiteacha eiliminte ag baint úsáide as an tuar chun iad a dheighilt.
    ///
    /// Glaoitear an predicate ar dhá ghné ag leanúint orthu féin, ciallaíonn sé go dtugtar an predicate ar `slice[0]` agus `slice[1]` ansin ar `slice[1]` agus `slice[2]` agus mar sin de.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Is féidir an modh seo a úsáid chun na foshraitheanna sórtáilte a bhaint:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Roinn slice amháin ina dhá leath ag innéacs.
    ///
    /// Sa chéad cheann beidh na hinnéacsanna go léir ó `[0, mid)` (gan an t-innéacs `mid` féin a áireamh) agus beidh na hinnéacsanna uile ó `[mid, len)` sa dara ceann (gan an t-innéacs `len` féin a áireamh).
    ///
    ///
    /// # Panics
    ///
    /// Panics más `mid > len` é.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SÁBHÁILTEACHT: Tá `[ptr; mid]` agus `[mid; len]` taobh istigh de `self`, atá
        // comhlíonann sé riachtanais `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Roinn slice amháin inathraithe ina dhá leath ag innéacs.
    ///
    /// Sa chéad cheann beidh na hinnéacsanna go léir ó `[0, mid)` (gan an t-innéacs `mid` féin a áireamh) agus beidh na hinnéacsanna uile ó `[mid, len)` sa dara ceann (gan an t-innéacs `len` féin a áireamh).
    ///
    ///
    /// # Panics
    ///
    /// Panics más `mid > len` é.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SÁBHÁILTEACHT: Tá `[ptr; mid]` agus `[mid; len]` taobh istigh de `self`, atá
        // comhlíonann sé riachtanais `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Roinneann slice amháin ina dhá ag innéacs, gan déanamh bounds sheiceáil.
    ///
    /// Sa chéad cheann beidh na hinnéacsanna go léir ó `[0, mid)` (gan an t-innéacs `mid` féin a áireamh) agus beidh na hinnéacsanna uile ó `[mid, len)` sa dara ceann (gan an t-innéacs `len` féin a áireamh).
    ///
    ///
    /// Le haghaidh rogha sábháilte eile féach [`split_at`].
    ///
    /// # Safety
    ///
    /// Is é *[iompar neamhshainithe]* an modh seo a ghlaoch le hinnéacs lasmuigh de theorainneacha fiú mura n-úsáidtear an tagairt dá bharr.Caithfidh an glaoiteoir a chinntiú go bhfuil `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SÁBHÁILTEACHT: Caithfidh an glaoiteoir an `0 <= mid <= self.len()` sin a sheiceáil
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Roinn slice inathraithe amháin ina dhá leath ag innéacs, gan seiceáil faoi theorainneacha.
    ///
    /// Sa chéad cheann beidh na hinnéacsanna go léir ó `[0, mid)` (gan an t-innéacs `mid` féin a áireamh) agus beidh na hinnéacsanna uile ó `[mid, len)` sa dara ceann (gan an t-innéacs `len` féin a áireamh).
    ///
    ///
    /// Le haghaidh rogha sábháilte eile féach [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Is é *[iompar neamhshainithe]* an modh seo a ghlaoch le hinnéacs lasmuigh de theorainneacha fiú mura n-úsáidtear an tagairt dá bharr.Caithfidh an glaoiteoir a chinntiú go bhfuil `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SÁBHÁILTEACHT: Caithfidh an glaoiteoir an `0 <= mid <= self.len()` sin a sheiceáil.
        //
        // `[ptr; mid]` é agus nach bhfuil `[mid; len]` forluí, mar sin ar ais tagairt mutable fíneáil.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Seoltar atriall thar foshraitheanna atá scartha le heilimintí a mheaitseálann `pred`.
    /// Níl an eilimint mheaitseáilte le fáil sna foshraitheanna.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Má mheaitseáiltear an chéad eilimint, is í slice folamh an chéad earra a chuirfidh an t-atriallóir ar ais.
    /// Mar an gcéanna, má tá an t-ghné dheireanach den slice mheaitseáil, beidh an slice folamh a bheith ar an rud deireanach ar ais ag an iterator:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Má tá dhá ghné mheaitseáilte cóngarach go díreach, beidh slice folamh i láthair eatarthu:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Tuairisceáin ar iterator thar subslices mutable scartha le heilimintí a mheaitseáil `pred`.
    /// Níl an eilimint mheaitseáilte le fáil sna foshraitheanna.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Seoltar atriall thar foshraitheanna atá scartha le heilimintí a mheaitseálann `pred`.
    /// Is é an ghné mheaitseáil atá sa deireadh an subslice roimhe mar terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Má mheaitseáiltear an eilimint dheireanach den slice, measfar gurb í an eilimint sin foirceannadh an tslis roimhe seo.
    ///
    /// Beidh an slice an rud deireanach ar ais ag an iterator.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Tuairisceáin ar iterator thar subslices mutable scartha le heilimintí a mheaitseáil `pred`.
    /// Tá an eilimint mheaitseáilte le fáil san fho-alt roimhe seo mar fhoirceannadh.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Seoltar atriall thar foshraitheanna scartha le heilimintí a mheaitseálann `pred`, ag tosú ag deireadh an tslis agus ag obair ar gcúl.
    /// Níl an eilimint mheaitseáilte le fáil sna foshraitheanna.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mar is amhlaidh le `split()`, má dhéantar an chéad eilimint nó an eilimint dheiridh a mheaitseáil, is é slice folamh an chéad earra (nó an ceann deireanach) a chuir an t-atriallóir ar ais.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Tuairisceáin ar iterator thar subslices mutable scartha le heilimintí a mheaitseáil `pred`, ag tosú ag deireadh na slice agus ar gcúl oibre.
    /// Níl an eilimint mheaitseáilte le fáil sna foshraitheanna.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Seoltar atriall thar foshraitheanna atá scartha le heilimintí a mheaitseálann `pred`, teoranta do fhilleadh ar fhormhór na míreanna `n`.
    /// Níl an eilimint mheaitseáilte le fáil sna foshraitheanna.
    ///
    /// Beidh an chuid eile den slice san eilimint dheireanach a cuireadh ar ais, más ann dó.
    ///
    /// # Examples
    ///
    /// Priontáil an scoilt slice uair amháin de réir uimhreacha atá inroinnte le 3 (ie, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Seoltar atriall thar foshraitheanna atá scartha le heilimintí a mheaitseálann `pred`, teoranta do fhilleadh ar fhormhór na míreanna `n`.
    /// Níl an eilimint mheaitseáilte le fáil sna foshraitheanna.
    ///
    /// Beidh an chuid eile den slice san eilimint dheireanach a cuireadh ar ais, más ann dó.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Tuairisceáin ar iterator thar subslices scartha le heilimintí a mheaitseáil `pred` teoranta do filleadh ar a mhéad míreanna `n`.
    /// Tosaíonn sé seo ag deireadh an tslis agus oibríonn sé ar gcúl.
    /// Níl an eilimint mheaitseáilte le fáil sna foshraitheanna.
    ///
    /// Beidh an chuid eile den slice san eilimint dheireanach a cuireadh ar ais, más ann dó.
    ///
    /// # Examples
    ///
    /// Priontáil an scoilt slice uair amháin, ag tosú ón deireadh, de réir uimhreacha atá inroinnte le 3 (ie, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Tuairisceáin ar iterator thar subslices scartha le heilimintí a mheaitseáil `pred` teoranta do filleadh ar a mhéad míreanna `n`.
    /// Tosaíonn sé seo ag deireadh an tslis agus oibríonn sé ar gcúl.
    /// Níl an eilimint mheaitseáilte le fáil sna foshraitheanna.
    ///
    /// Beidh an chuid eile den slice san eilimint dheireanach a cuireadh ar ais, más ann dó.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Tuairisceáin `true` má tá eilimint sa luach a thugtar sa slice.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Más rud é nach bhfuil tú ag `&T`, ach amháin an `&U` sórt sin `T: Borrow<U>` (eg
    /// `Teaghrán: Iasacht<str>`), Is féidir leat úsáid `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // slice de `String`
    /// assert!(v.iter().any(|e| e == "hello")); // cuardaigh le `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Filleann `true` más réimír den slice é `needle`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// I gcónaí ar ais `true` má tá `needle` an slice folamh:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Filleann `true` más iarmhír den slice é `needle`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// I gcónaí ar ais `true` má tá `needle` an slice folamh:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Seoltar fotheideal ar ais agus baintear an réimír.
    ///
    /// Má thosaíonn an slice le `prefix`, filleann sé an foshraith tar éis an réimír, fillte i `Some`.
    /// Má tá `prefix` folamh, ní gá ach an slice bunaidh a chur ar ais.
    ///
    /// Mura dtosaíonn an slice le `prefix`, filleann `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Beidh gá leis an bhfeidhm seo a athscríobh má éiríonn SlicePattern níos sofaisticiúla.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Filleann sé foshraith agus an iarmhír bainte.
    ///
    /// Má chríochnaíonn slice le `suffix` tuairisceáin, an subslice roimh an iarmhír, fillte i `Some`.
    /// Má tá `suffix` folamh, ní gá ach an slice bunaidh a chur ar ais.
    ///
    /// Mura gcríochnaíonn an slice le `suffix`, filleann `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Beidh gá leis an bhfeidhm seo a athscríobh má éiríonn SlicePattern níos sofaisticiúla.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Déanann dénártha cuardach ar an slice sórtáilte seo le haghaidh eilimint ar leith.
    ///
    /// Má aimsítear an luach tugtar ar ais [`Result::Ok`], ina bhfuil innéacs na heiliminte meaitseála.
    /// Má tá cluichí iomadúla ann, d`fhéadfaí ceann ar bith de na cluichí a thabhairt ar ais.
    /// Mura bhfaightear an luach tugtar ar ais [`Result::Err`], ina bhfuil an t-innéacs inar féidir eilimint meaitseála a chur isteach agus ord sórtáilte á chothabháil.
    ///
    ///
    /// Féach freisin [`binary_search_by`], [`binary_search_by_key`], agus [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Breathnaíonn sé sraith de cheithre ghné.
    /// Cuirtear an chéad le fáil, le seasamh chinneadh uathúil;ní fhaightear an dara agus an tríú ceann;d`fhéadfadh an ceathrú seasamh ar bith in `[1, 4]` a mheaitseáil.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Más mian leat mír a chur isteach i vector sórtáilte, agus ord sórtála á chothabháil agat:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// cuardaigh dénártha curtha in eagar an slice le feidhm comparadóir.
    ///
    /// Ba cheart go gcuirfeadh feidhm an chomparadóra ordú i bhfeidhm atá comhsheasmhach le hord sórtála na slice bunúsaí, ag filleadh cód ordaithe a thugann le fios an é `Less`, `Equal` nó `Greater` an argóint atá ag teastáil.
    ///
    ///
    /// Má aimsítear an luach tugtar ar ais [`Result::Ok`], ina bhfuil innéacs na heiliminte meaitseála.Má tá cluichí iomadúla ann, d`fhéadfaí ceann ar bith de na cluichí a thabhairt ar ais.
    /// Mura bhfaightear an luach tugtar ar ais [`Result::Err`], ina bhfuil an t-innéacs inar féidir eilimint meaitseála a chur isteach agus ord sórtáilte á chothabháil.
    ///
    /// Féach freisin [`binary_search`], [`binary_search_by_key`], agus [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Breathnaíonn sé sraith de cheithre ghné.Faightear an chéad cheann, le seasamh uathúil cinnte;ní fhaightear an dara agus an tríú ceann;D'fhéadfadh an ceathrú comhoiriúnach le haon phost i `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // SÁBHÁILTEACHT: déantar na glaonna a dhéanamh sábháilte ag na hionróirí seo a leanas:
            // - `mid >= 0`
            // - `mid < size`: Tá `mid` teoranta ag `[left; right)` faoi cheangal.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Is é an fáth go n-úsáideann muid sreabhadh rialaithe if/else seachas comhoiriúnú ná toisc go ndéanann oibríochtaí comparáide athordú ar mheaitseáil, atá íogair go foirfe.
            //
            // Tá sé seo x86 asm haghaidh u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Déanann dénártha cuardach ar an slice sórtáilte seo le príomhfheidhm eastósctha.
    ///
    /// Glactar leis go ndéantar an slice a shórtáil de réir na heochrach, mar shampla le [`sort_by_key`] ag baint úsáide as an bhfeidhm eastósctha eochair chéanna.
    ///
    /// Má aimsítear an luach tugtar ar ais [`Result::Ok`], ina bhfuil innéacs na heiliminte meaitseála.
    /// Má tá cluichí iomadúla ann, d`fhéadfaí ceann ar bith de na cluichí a thabhairt ar ais.
    /// Mura bhfaightear an luach tugtar ar ais [`Result::Err`], ina bhfuil an t-innéacs inar féidir eilimint meaitseála a chur isteach agus ord sórtáilte á chothabháil.
    ///
    ///
    /// Féach freisin [`binary_search`], [`binary_search_by`], agus [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Breathnaíonn sé sraith de cheithre ghné i slice de phéirí arna sórtáil de réir a dara heilimintí.
    /// Cuirtear an chéad le fáil, le seasamh chinneadh uathúil;ní fhaightear an dara agus an tríú ceann;d`fhéadfadh an ceathrú seasamh ar bith in `[1, 4]` a mheaitseáil.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Ceadaítear Lint rustdoc::broken_intra_doc_links toisc go bhfuil `slice::sort_by_key` i crate `alloc`, agus mar sin níl sé ann fós agus `core` á thógáil.
    //
    // naisc le crate le sruth: #74481.Ós rud é nach ndéantar ach primitive a dhoiciméadú i libstd (#73423), ní bhíonn naisc bhriste ann go praiticiúil dá bharr.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Sórtáil an slice, ach ní fhéadfaidh sé ord na n-eilimintí comhionanna a chaomhnú.
    ///
    /// Tá an cineál seo éagobhsaí (ie, féadfaidh sé eilimintí comhionanna a athordú), i bhfeidhm (ie, ní leithdháileann sé), agus *O*(*n*\*log(* n*)) sa chás is measa.
    ///
    /// # Cur i bhfeidhm reatha
    ///
    /// Tá an algartam reatha bunaithe ar [pattern-defeating quicksort][pdqsort] le Orson Peters, a chomhcheanglaíonn an cás mear tapa de quicksort randamach leis an gcás is measa go tapa de heapsort, agus am líneach á bhaint amach ar shlisní le patrúin áirithe.
    /// Úsáideann sé roinnt randomization a sheachaint cásanna degenerate, ach le seed seasta chun iompar deterministic a chur ar fáil i gcónaí.
    ///
    /// Is gnách go mbíonn sé níos gasta ná sórtáil chobhsaí, ach amháin i gcúpla cás speisialta, m.sh., nuair a bhíonn roinnt sraitheanna sórtáilte comhtháthaithe sa slice.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Sórtáil an slice le feidhm chomparáideach, ach ní fhéadfaidh sé ord na n-eilimintí comhionanna a chaomhnú.
    ///
    /// Tá an cineál seo éagobhsaí (ie, féadfaidh sé eilimintí comhionanna a athordú), i bhfeidhm (ie, ní leithdháileann sé), agus *O*(*n*\*log(* n*)) sa chás is measa.
    ///
    /// Caithfidh feidhm an chomparadóra ordú iomlán a shainiú do na heilimintí sa slice.Mura bhfuil an t-ordú iomlán, tá ord na n-eilimintí neamhshonraithe.Is ordú iomlán ordú más ea (do gach `a`, `b` agus `c`):
    ///
    /// * iomlán agus antisymmetric: Tá sé ceann de na `a < b`, `a == b` nó `a > b` fíor, agus
    /// * aistreacha, `a < b` agus `b < c` tuiscint `a < c`.Ní mór an rud céanna a bheith ag `==` agus `>` araon.
    ///
    /// Mar shampla, cé nach bhfuil [`f64`] a chur i bhfeidhm [`Ord`] gheall `NaN != NaN`, is féidir linn a úsáid `partial_cmp` mar ár fheidhm saghas nuair a fhios againn an slice níl a `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Cur i bhfeidhm reatha
    ///
    /// Tá an algartam reatha bunaithe ar [pattern-defeating quicksort][pdqsort] le Orson Peters, a chomhcheanglaíonn an cás mear tapa de quicksort randamach leis an gcás is measa go tapa de heapsort, agus am líneach á bhaint amach ar shlisní le patrúin áirithe.
    /// Úsáideann sé roinnt randomization a sheachaint cásanna degenerate, ach le seed seasta chun iompar deterministic a chur ar fáil i gcónaí.
    ///
    /// Is gnách go mbíonn sé níos gasta ná sórtáil chobhsaí, ach amháin i gcúpla cás speisialta, m.sh., nuair a bhíonn roinnt sraitheanna sórtáilte comhtháthaithe sa slice.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // sórtáil droim ar ais
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Sórtálfar an slice le feidhm eastóscadh eochair, ach ní féidir an t-ordú na n-eilimintí comhionann a chaomhnú.
    ///
    /// Tá an cineál seo éagobhsaí (ie, féadfaidh sé eilimintí comhionanna a athordú), i bhfeidhm (ie, ní leithdháileann sé), agus *O*(m\* * n *\* log(*n*)) sa chás is measa, áit a bhfuil an phríomhfheidhm *O*(*m*).
    ///
    /// # Cur i bhfeidhm reatha
    ///
    /// Tá an algartam reatha bunaithe ar [pattern-defeating quicksort][pdqsort] le Orson Peters, a chomhcheanglaíonn an cás mear tapa de quicksort randamach leis an gcás is measa go tapa de heapsort, agus am líneach á bhaint amach ar shlisní le patrúin áirithe.
    /// Úsáideann sé roinnt randomization a sheachaint cásanna degenerate, ach le seed seasta chun iompar deterministic a chur ar fáil i gcónaí.
    ///
    /// Mar gheall ar a phríomhstraitéis glaonna, is dóigh go mbeidh [`sort_unstable_by_key`](#method.sort_unstable_by_key) níos moille ná [`sort_by_cached_key`](#method.sort_by_cached_key) i gcásanna ina bhfuil an phríomhfheidhm daor.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Déan an slice a athordú ionas go mbeidh an eilimint ag `index` ag a suíomh sórtáilte deiridh.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Déan an slice a athordú le feidhm chomparáideach ionas go mbeidh an eilimint ag `index` ag a suíomh sórtáilte deiridh.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Déan an slice a athordú le príomhfheidhm eastósctha ionas go mbeidh an eilimint ag `index` ag a suíomh sórtáilte deiridh.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Déan an slice a athordú ionas go mbeidh an eilimint ag `index` ag a suíomh sórtáilte deiridh.
    ///
    /// Tá an mhaoin bhreise ag an athordú seo go mbeidh aon luach ag seasamh `i < index` níos lú ná nó cothrom le haon luach ag suíomh `j > index`.
    /// Ina theannta sin, tá an t-athordú seo éagobhsaí (ie
    /// féadfar deireadh a chur le haon líon eilimintí comhionanna ag seasamh `index`), in áit (ie
    /// ní leithdháileann sé), agus *O*(*n*) an cás is measa.
    /// Tugtar "kth element" ar an bhfeidhm seo freisin i leabharlanna eile.
    /// Filleann sé triplet de na luachanna seo a leanas: gach eilimint níos lú ná an ceann ag an innéacs tugtha, an luach ag an innéacs tugtha, agus gach eilimint níos mó ná an ceann ag an innéacs tugtha.
    ///
    ///
    /// # Cur i bhfeidhm reatha
    ///
    /// Tá an algartam reatha bunaithe ar an gcuid mear-roghnaithe den algartam quicksort céanna a úsáidtear le haghaidh [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics nuair `index >= len()`, rud a chiallaíonn go mbíonn sé i gcónaí panics ar shlisníní folmha.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Faigh an t-airmheán
    /// v.select_nth_unstable(2);
    ///
    /// // Ní ráthaítear dúinn ach go mbeidh an slice ar cheann de na rudaí seo a leanas, bunaithe ar an mbealach a dhéanaimid sórtáil faoin innéacs sonraithe.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Déan an slice a athordú le feidhm chomparáideach ionas go mbeidh an eilimint ag `index` ag a suíomh sórtáilte deiridh.
    ///
    /// Tá an mhaoin bhreise ag an athordú seo go mbeidh aon luach ag seasamh `i < index` níos lú ná nó cothrom le haon luach ag suíomh `j > index` agus an fheidhm chomparáideach á úsáid.
    /// Ina theannta sin, tá an t-athordú seo éagobhsaí (ie d`fhéadfadh go mbeadh líon ar bith d`eilimintí comhionanna ag seasamh `index`), in áit (ie nach leithdháileann), agus *O*(*n*) sa chás is measa.
    /// Tugtar "kth element" ar an bhfeidhm seo i leabharlanna eile freisin.
    /// Seolann sé triplet de na luachanna seo a leanas ar ais: gach eilimint níos lú ná an ceann ag an innéacs tugtha, an luach ag an innéacs tugtha, agus gach eilimint níos mó ná an ceann ag an innéacs tugtha, ag úsáid na feidhme comparáideora a sholáthraítear.
    ///
    ///
    /// # Cur i bhfeidhm reatha
    ///
    /// Tá an algartam reatha bunaithe ar an gcuid mear-roghnaithe den algartam quicksort céanna a úsáidtear le haghaidh [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics nuair `index >= len()`, rud a chiallaíonn go mbíonn sé i gcónaí panics ar shlisníní folmha.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Faigh an t-airmheán aige fé is dá curtha in eagar an slice in ord íslitheach.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Ní ráthaítear dúinn ach go mbeidh an slice ar cheann de na rudaí seo a leanas, bunaithe ar an mbealach a dhéanaimid sórtáil faoin innéacs sonraithe.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Déan an slice a athordú le príomhfheidhm eastósctha ionas go mbeidh an eilimint ag `index` ag a suíomh sórtáilte deiridh.
    ///
    /// Tá an mhaoin bhreise ag an athordú seo go mbeidh aon luach ag seasamh `i < index` níos lú ná nó cothrom le haon luach ag suíomh `j > index` agus an phríomhfheidhm eastósctha á úsáid.
    /// Ina theannta sin, tá an t-athordú seo éagobhsaí (ie d`fhéadfadh go mbeadh líon ar bith d`eilimintí comhionanna ag seasamh `index`), in áit (ie nach leithdháileann), agus *O*(*n*) sa chás is measa.
    /// Tugtar "kth element" ar an bhfeidhm seo i leabharlanna eile freisin.
    /// Seolann sé triplet de na luachanna seo a leanas ar ais: gach eilimint níos lú ná an ceann ag an innéacs tugtha, an luach ag an innéacs tugtha, agus gach eilimint níos mó ná an ceann ag an innéacs tugtha, agus an phríomhfheidhm eastósctha curtha ar fáil á úsáid.
    ///
    ///
    /// # Cur i bhfeidhm reatha
    ///
    /// Tá an algartam reatha bunaithe ar an gcuid mear-roghnaithe den algartam quicksort céanna a úsáidtear le haghaidh [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics nuair `index >= len()`, rud a chiallaíonn go mbíonn sé i gcónaí panics ar shlisníní folmha.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Fill an t-airmheán amhail is dá ndéanfaí an eagar a shórtáil de réir luach absalóideach.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Ní ráthaítear dúinn ach go mbeidh an slice ar cheann de na rudaí seo a leanas, bunaithe ar an mbealach a dhéanaimid sórtáil faoin innéacs sonraithe.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Bog gach eilimint arís agus arís eile i ndiaidh a chéile go dtí deireadh an slice de réir an chur i bhfeidhm [`PartialEq`] trait.
    ///
    ///
    /// Tuairisceáin dhá slisní.Tá aon eilimintí arís agus arís eile i ndiaidh a chéile ar an gcéad.
    /// Sa dara ceann tá na dúblacha uile in aon ord sonraithe.
    ///
    /// Má dhéantar an slice a shórtáil, níl aon dúbailtí sa chéad slice ar ais.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Téigh ar fad ach an chéad na n-eilimintí i ndiaidh a chéile go dtí deireadh an slice shásamh maidir le comhionannais arna thabhairt.
    ///
    /// Tuairisceáin dhá slisní.Tá aon eilimintí arís agus arís eile i ndiaidh a chéile ar an gcéad.
    /// Sa dara ceann tá na dúblacha uile in aon ord sonraithe.
    ///
    /// Gabhann feidhm `same_bucket` tagairtí do dhá ghné ón slice agus caithfidh sí a chinneadh an bhfuil na heilimintí i gcomparáid lena chéile.
    /// Na heilimintí ar aghaidh in ord eile ón n-ord sa slice, mar sin má tuairisceáin `same_bucket(a, b)` `true`, tá `a` ar athraíodh a ionad ag an deireadh an slice.
    ///
    ///
    /// Má dhéantar an slice a shórtáil, níl aon dúbailtí sa chéad slice ar ais.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Cé go bhfuil tagairt shochorraithe againn do `self`, ní féidir linn athruithe *treallach* a dhéanamh.D'fhéadfadh na glaonna `same_bucket` panic, mar sin ní mór dúinn a chinntiú go bhfuil an t-slice i stát bailí i gcónaí.
        //
        // Is é an bealach a láimhseáilimid é seo ná babhtálacha a úsáid;déanaimid aithris ar na heilimintí go léir, ag malartú de réir mar a théann muid ar aghaidh ionas go mbeidh na heilimintí is mian linn a choinneáil ag an deireadh, agus go bhfuil na gnéithe ar mhaith linn diúltú dóibh sa chúl.
        // Is féidir linn an slice a scoilt ansin.
        // Tá an oibríocht seo fós `O(n)`.
        //
        // Sampla: Tús a chur againn sa stát seo, áit a seasann `r` "seo chugainn
        // léigh "agus is ionann `w` agus" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Ag comparáid self[r] leis an duine féin [w-1], ní dúblach é seo, mar sin babhtálaimid self[r] agus self[w] (gan éifeacht mar r==w) agus ansin incrimint r agus w araon, rud a fhágann:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Comparáid a dhéanamh self[r] in aghaidh féin [w-1], tá an luach a dhúbailt, agus mar sin incrimint muid ag `r` ach saoire gach rud eile gan athrú:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Ag comparáid self[r] leis an duine féin [w-1], ní dúblach é seo, mar sin babhtáil self[r] agus self[w] agus roimh ré r agus w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Ní dúblach, athuair:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Dúblach, advance r. End de shlis.Scoilt ag w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SÁBHÁILTEACHT: ráthaíonn coinníoll `while` `next_read` agus `next_write`
        // níos lú ná `len`, mar sin tá siad taobh istigh de `self`.
        // `prev_ptr_write` pointí le heilimint amháin roimh `ptr_write`, ach tosaíonn `next_write` ag 1, mar sin ní bhíonn `prev_ptr_write` riamh níos lú ná 0 agus tá sé taobh istigh den slice.
        // Comhlíonann sé seo na ceanglais maidir le dí-chomhdháil `ptr_read`, `prev_ptr_write` agus `ptr_write`, agus chun `ptr.add(next_read)`, `ptr.add(next_write - 1)` agus `prev_ptr_write.offset(1)` a úsáid.
        //
        //
        // `next_write` Tá incrimintithe freisin ar a mhéad uair sa lúb ar a mhéad a chiallaíonn aon eilimint Is ndearna nuair a d'fhéadfadh gá é a mhalartú.
        //
        // `ptr_read` agus ní dhíríonn `prev_ptr_write` ar an eilimint chéanna riamh.Teastaíonn sé seo chun go mbeidh `&mut *ptr_read`, `&mut* prev_ptr_write` sábháilte.
        // Is é an míniú simplí go bhfuil `next_read >= next_write` fíor i gcónaí, dá bhrí sin tá `next_read > next_write - 1` freisin.
        //
        //
        //
        //
        //
        unsafe {
            // Seachain seiceálacha faoi theorainneacha trí leideanna amha a úsáid.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Bogann sé gach ceann ach an chéad cheann de na heilimintí as a chéile go dtí deireadh na slice a réitíonn go dtí an eochair chéanna.
    ///
    ///
    /// Tuairisceáin dhá slisní.Tá aon eilimintí arís agus arís eile i ndiaidh a chéile ar an gcéad.
    /// Sa dara ceann tá na dúblacha uile in aon ord sonraithe.
    ///
    /// Má dhéantar an slice a shórtáil, níl aon dúbailtí sa chéad slice ar ais.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Rothlaíonn sé an slice i bhfeidhm sa chaoi is go mbogann na chéad eilimintí `mid` den slice go dtí an deireadh agus go mbogann na heilimintí `self.len() - mid` deireanacha chun tosaigh.
    /// Tar éis glaoch `rotate_left`, an eilimint roimhe sin ar innéacs `mid` a bheith ar an chéad eilimint sa slice.
    ///
    /// # Panics
    ///
    /// Beidh an fheidhm seo panic má tá `mid` níos mó ná fad an tslis.Tabhair faoi deara go ndéanann `mid == self.len()` _not_ panic agus gur rothlú aon-op é.
    ///
    /// # Complexity
    ///
    /// Glac líneach (in am `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Rothlach a rothlú:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SÁBHÁILTEACHT: Tá an raon `[p.add(mid) - mid, p.add(mid) + k)` fánach
        // bailí don léitheoireacht agus don scríbhneoireacht, mar a éilíonn `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Rothlaíonn sé an slice i bhfeidhm sa chaoi is go mbogann na chéad eilimintí `self.len() - k` den slice go dtí an deireadh agus go mbogann na heilimintí `k` deireanacha chun tosaigh.
    /// Tar éis `rotate_right` a ghlaoch, beidh an eilimint roimhe seo ag innéacs `self.len() - k` ar an gcéad eilimint sa slice.
    ///
    /// # Panics
    ///
    /// Beidh an fheidhm seo panic má tá `k` níos mó ná fad an tslis.Tabhair faoi deara go ndéanann `k == self.len()` _not_ panic agus is rothlú no-op.
    ///
    /// # Complexity
    ///
    /// Glac líneach (in am `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Rothlaigh foshraith:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SÁBHÁILTEACHT: Tá an raon `[p.add(mid) - mid, p.add(mid) + k)` fánach
        // bailí don léitheoireacht agus don scríbhneoireacht, mar a éilíonn `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Líonann `self` le heilimintí trí chlónáil `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Líonann `self` le heilimintí ar ais trí dhúnadh a ghlaoch arís agus arís eile.
    ///
    /// Úsáideann an modh seo dúnadh chun luachanna nua a chruthú.Más fearr leat [`Clone`] luach ar leith, úsáid [`fill`].
    /// Más mian leat an [`Default`] trait a úsáid chun luachanna a ghiniúint, is féidir leat [`Default::default`] a rith mar an argóint.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Cóipeanna na heilimintí ó `src` `self` isteach.
    ///
    /// Caithfidh fad `src` a bheith mar an gcéanna le `self`.
    ///
    /// Má chuireann `T` `Copy` i bhfeidhm, is féidir go mbeadh sé níos gníomhaí [`copy_from_slice`] a úsáid.
    ///
    /// # Panics
    ///
    /// Beidh an fheidhm panic má tá an dá slisní faid éagsúla.
    ///
    /// # Examples
    ///
    /// Clónáil dhá ghné ó shlis isteach i gceann eile:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Toisc go gcaithfidh na slisní a bheith den fhad céanna, slisnímid an slice foinse ó cheithre ghné go dtí dhá ghné.
    /// // Sé Beidh panic mura féidir linn a dhéanamh.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Forfheidhmíonn Rust nach féidir ach tagairt inathraithe amháin a bheith ann gan aon tagairtí dochorraithe do phíosa áirithe sonraí faoi raon feidhme áirithe.
    /// Mar gheall air seo, má dhéantar iarracht `clone_from_slice` a úsáid ar shlis amháin, teipfear ar thiomsú:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Chun an obair thart ar an, is féidir linn a úsáid [`split_at_mut`] a chruthú dhá leith fho-slices ó slice:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Cóipeanna gach gné ó `src` `self` isteach, ag baint úsáide as memcpy.
    ///
    /// Caithfidh fad `src` a bheith mar an gcéanna le `self`.
    ///
    /// Mura gcuireann `T` `Copy` i bhfeidhm, úsáid [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Beidh an fheidhm panic má tá an dá slisní faid éagsúla.
    ///
    /// # Examples
    ///
    /// Cóipeáil dhá ghné as slice isteach i gceann eile:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Toisc go gcaithfidh na slisní a bheith den fhad céanna, slisnímid an slice foinse ó cheithre ghné go dtí dhá ghné.
    /// // Sé Beidh panic mura féidir linn a dhéanamh.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Forfheidhmíonn Rust nach féidir ach tagairt inathraithe amháin a bheith ann gan aon tagairtí dochorraithe do phíosa áirithe sonraí faoi raon feidhme áirithe.
    /// Mar gheall air seo, má dhéantar iarracht `copy_from_slice` a úsáid ar shlis amháin, teipfear ar thiomsú:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Chun an obair thart ar an, is féidir linn a úsáid [`split_at_mut`] a chruthú dhá leith fho-slices ó slice:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Cuireadh cosán cód panic i bhfeidhm fuar chun gan an láithreán glaonna a bhláthú.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SÁBHÁILTEACHT: Is `self` bailí le haghaidh eilimintí `self.len()` de réir sainmhínithe, agus bhí sé `src`
        // seiceáil go bhfuil an fad céanna acu.
        // Ní féidir forluí a dhéanamh ar na slisní toisc go bhfuil tagairtí inathraithe eisiach.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Cóipeáil eilimintí ó chuid amháin den slice go dtí cuid eile de féin, ag baint úsáide as meabhrán.
    ///
    /// `src` an bhfuil an raon laistigh de `self` le cóipeáil uaidh.
    /// `dest` is é innéacs tosaigh an raoin laistigh de `self` le cóipeáil dó, a mbeidh an fad céanna aige le `src`.
    /// Is féidir leis an dá raonta forluí.
    /// Caithfidh foircinn an dá raon a bheith níos lú ná nó cothrom le `self.len()`.
    ///
    /// # Panics
    ///
    /// Seo an fheidhm Beidh panic más mó ceachtar raon deireadh an slice, nó má tá deireadh `src` roimh thús.
    ///
    ///
    /// # Examples
    ///
    /// Cóipeáil ceithre bheart laistigh de shlisne:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SÁBHÁILTEACHT: rinneadh na coinníollacha go léir le haghaidh `ptr::copy` a sheiceáil thuas,
        // mar tá siúd do `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Babhtáil gach eilimint in `self` leo siúd in `other`.
    ///
    /// Caithfidh fad `other` a bheith mar an gcéanna le `self`.
    ///
    /// # Panics
    ///
    /// Beidh an fheidhm panic má tá an dá slisní faid éagsúla.
    ///
    /// # Example
    ///
    /// Swapping dhá ghné ar fud slices:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Cuireann Rust i bhfeidhm nach féidir ach tagairt dhochreidte amháin a bheith ann do phíosa áirithe sonraí faoi raon feidhme áirithe.
    ///
    /// Mar gheall air seo, má dhéantar iarracht `swap_with_slice` a úsáid ar shlis amháin, teipfear ar thiomsú:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Chun oibriú timpeall air seo, is féidir linn [`split_at_mut`] a úsáid chun dhá fho-shlisní inathraithe ar leith a chruthú as slice:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SÁBHÁILTEACHT: Is `self` bailí le haghaidh eilimintí `self.len()` de réir sainmhínithe, agus bhí sé `src`
        // seiceáil go bhfuil an fad céanna acu.
        // Ní féidir forluí a dhéanamh ar na slisní toisc go bhfuil tagairtí inathraithe eisiach.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Feidhm chun faid an slice lár agus an tralaí a ríomh do `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Is é an rud a dhéanfaimid faoi `rest` ná a fháil amach cén iolra de `U`s is féidir linn a chur sa líon is ísle de`T`s.
        //
        // Agus cé mhéad `T`s a theastaíonn uainn le haghaidh gach "multiple" den sórt sin.
        //
        // Smaoinigh mar shampla T=u8 U=u16.Ansin is féidir linn 1 U a chur in 2 Ts.Simplí.
        // Anois, smaoinigh mar shampla ar chás ina bhfuil size_of: :<T>=16, size_of::<U>=24.</u>
        // Is féidir linn 2 Linn a chur in áit gach 3 Ts sa slice `rest`.
        // Beagán níos casta.
        //
        // Is í an fhoirmle chun é seo a ríomh:
        //
        // Linn= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Leathnaithe agus simplithe:
        //
        // Linn=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Ar ámharaí an tsaoil toisc go ndéantar meastóireacht leanúnach air seo go léir ... níl tábhacht le feidhmíocht anseo!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // algartam atriallach stein Ba cheart dúinn an `const fn` seo a dhéanamh fós (agus dul ar ais chuig algartam athchúrsach má dhéanaimid é) toisc go mbraitheann muid ar llvm chun é seo go léir a dhéanamh ... bhuel, cuireann sé míchompord orm.
            //
            //

            // SÁBHÁILTEACHT: Seiceáiltear gur luachanna neamh-nialasacha iad `a` agus `b`.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // bain gach toisc de 2 ó b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SÁBHÁILTEACHT: Seiceáiltear go bhfuil `b` neamh-nialasach.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Agus an t-eolas seo againn, is féidir linn a fháil cé mhéad `U` is féidir linn a fheistiú!
        let us_len = self.len() / ts * us;
        // Agus cé mhéad `T` a bheidh sa slice trailing!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Transmute an slice le slice de chineál eile, ag cinntiú ailíniú de na cineálacha a chothabháil.
    ///
    /// Roinntear an modh seo an slisne i dtrí slisn ar leith: réimír, slice lár ailínithe i gceart de chineál nua, agus an slice iarmhír.
    /// D`fhéadfadh go ndéanfadh an modh an slice lár an fad is mó is féidir do chineál áirithe agus slice ionchuir, ach níor cheart go mbeadh feidhmíocht d`algartam ag brath air sin, ní ar a chruinneas.
    ///
    /// Tá sé ceadaithe na sonraí ionchuir uile a thabhairt ar ais mar an réimír nó an iarmhír slice.
    ///
    /// Níl aon aidhm ag an modh seo nuair a bhíonn eilimint ionchuir `T` nó eilimint aschuir `U` de mhéid nialas agus fillfidh sé an slice bunaidh gan aon rud a scoilt.
    ///
    /// # Safety
    ///
    /// Go bunúsach is `transmute` an modh seo maidir leis na heilimintí sa lárshliotán a chuirtear ar ais, agus mar sin tá feidhm ag na gnáth-caveat go léir a bhaineann le `transmute::<T, U>` anseo freisin.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Tabhair faoi deara go ndéanfar meastóireacht leanúnach ar fhormhór na feidhme seo,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // láimhseáil ZSTanna go speisialta, is é sin-ná láimhseáil iad ar chor ar bith.
            return (self, &[], &[]);
        }

        // Ar dtús, faigh amach cén pointe a roinnimid idir an chéad agus an dara slice.
        // Éasca le ptr.align_offset.
        let ptr = self.as_ptr();
        // SÁBHÁILTEACHT: Féach an modh `align_to_mut` le haghaidh na tráchtaireachta sábháilteachta mionsonraithe.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SÁBHÁILTEACHT: anois tá `rest` ailínithe cinnte, mar sin tá `from_raw_parts` thíos ceart go leor,
            // ós rud é go ráthaíonn an té atá ag glaoch gur féidir linn `T` a aistriú go `U` go sábháilte.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Transmute an slice le slice de chineál eile, ag cinntiú ailíniú de na cineálacha a chothabháil.
    ///
    /// Roinntear an modh seo an slisne i dtrí slisn ar leith: réimír, slice lár ailínithe i gceart de chineál nua, agus an slice iarmhír.
    /// D`fhéadfadh go ndéanfadh an modh an slice lár an fad is mó is féidir do chineál áirithe agus slice ionchuir, ach níor cheart go mbeadh feidhmíocht d`algartam ag brath air sin, ní ar a chruinneas.
    ///
    /// Tá sé ceadaithe na sonraí ionchuir uile a thabhairt ar ais mar an réimír nó an iarmhír slice.
    ///
    /// Níl aon aidhm ag an modh seo nuair a bhíonn eilimint ionchuir `T` nó eilimint aschuir `U` de mhéid nialas agus fillfidh sé an slice bunaidh gan aon rud a scoilt.
    ///
    /// # Safety
    ///
    /// Go bunúsach is `transmute` an modh seo maidir leis na heilimintí sa lárshliotán a chuirtear ar ais, agus mar sin tá feidhm ag na gnáth-caveat go léir a bhaineann le `transmute::<T, U>` anseo freisin.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Tabhair faoi deara go ndéanfar meastóireacht leanúnach ar fhormhór na feidhme seo,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // láimhseáil ZSTanna go speisialta, is é sin-ná láimhseáil iad ar chor ar bith.
            return (self, &mut [], &mut []);
        }

        // Ar dtús, faigh amach cén pointe a roinnimid idir an chéad agus an dara slice.
        // Éasca le ptr.align_offset.
        let ptr = self.as_ptr();
        // SÁBHÁILTEACHT: Táimid ag cinntiú anseo go n-úsáidfimid leideanna ailínithe le haghaidh U don
        // an chuid eile den mhodh.Déantar é seo trí phointeoir a rith chuig&[T] le hailíniú dírithe ar U.
        // `crate::ptr::align_offset` a dtugtar le pointeoir ailínithe i gceart agus bailí `ptr` (a thagann sé ó thagairt do `self`) agus le méid a bhfuil cumhacht de dhá (ós rud é a thagann sé as an alignement do U), a shásamh a srianta sábháilteachta.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Ní féidir linn `rest` a úsáid arís ina dhiaidh seo, chuirfeadh sé a ailias `mut_ptr` ó bhail!SÁBHÁILTEACHT: féach tráchtanna le haghaidh `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Seiceálacha an bhfuil na heilimintí den slice seo curtha in eagar.
    ///
    /// Is é sin, i gcás gach eilimint `a` agus an eilimint `b` seo a leanas, ní mór `a <= b` a shealbhú.Má thugann an slice toradh go díreach nialas nó eilimint amháin, tugtar `true` ar ais.
    ///
    /// Tabhair faoi deara, mura bhfuil `Self::Item` ach `PartialOrd`, ach nach `Ord` é, tugann an sainmhíniú thuas le tuiscint go bhfilleann an fheidhm seo `false` mura bhfuil dhá earra as a chéile inchomparáide.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Seiceálacha an ndéantar eilimintí an tslis seo a shórtáil ag úsáid na feidhme comparáideora a thugtar.
    ///
    /// In ionad `PartialOrd::partial_cmp` a úsáid, úsáideann an fheidhm seo an fheidhm `compare` a thugtar chun ordú dhá ghné a chinneadh.
    /// Seachas sin, is ionann é agus [`is_sorted`];féach ar a dhoiciméadú chun tuilleadh faisnéise a fháil.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Seiceálacha más rud é na gnéithe den slice atá curtha in eagar ag baint úsáide as an fheidhm eastóscadh eochair.
    ///
    /// In ionad na n-eilimintí an slice ar i gcomparáid go díreach, i gcomparáid fheidhm seo na heochracha na heilimintí, mar atá arna chinneadh ag `f`.
    /// Seachas sin, is ionann é agus [`is_sorted`];féach ar a dhoiciméadú chun tuilleadh faisnéise a fháil.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Tuairisceáin an t-innéacs an pointe críochdheighilte i gcomhréir leis an phreideacáid tugadh (an t-innéacs na chéad eilimint den dara laindéal).
    ///
    /// Glactar leis go ndéantar an slice a dheighilt de réir an tuar a tugadh.
    /// Ciallaíonn sé seo go bhfuil na heilimintí go léir a bhfuil na tuairisceáin réamh-mheasta fíor ina leith ag tús an tslis agus go bhfuil na heilimintí go léir a bhfuil na tuairisceáin réamh-mheasta bréagach ina leith ag an deireadh.
    ///
    /// Mar shampla, tá [7, 15, 3, 5, 4, 12, 6] deighilte faoin predicate x% 2!=0 (tá na huimhreacha corr ag an tús, iad uile fiú ag an deireadh).
    ///
    /// Mura bhfuil an slice dheighilt, is é an toradh ar ais neamhshonraithe agus ciall, fheidhmíonn an modh ar chineál an chuardaigh dénártha.
    ///
    /// Féach freisin [`binary_search`], [`binary_search_by`], agus [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SÁBHÁILTEACHT: Nuair a bheidh `left < right`, `left <= mid < right`.
            // Dá bhrí sin méadaíonn `left` i gcónaí agus laghdaíonn `right` i gcónaí, agus roghnaítear ceachtar acu.Sa dá chás tá `left <= right` sásta.Dá bhrí sin, más rud é `left < right` in aon chéim, tá `left <= right` deimhin leis sa chéad chéim eile.
            //
            // Dá bhrí sin, chomh fada agus is `left != right`, tá `0 <= left < right <= len` sásta agus má chás seo tá `0 <= mid < len` sásta freisin.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Caithfimid iad a sleamhnú go sainráite ar an fhad céanna
        // chun é a dhéanamh níos éasca don optimizer deireadh a chur le seiceáil.
        // Ach ós rud é nach féidir brath air tá speisialtóireacht shoiléir againn freisin do T: Cóipeáil.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Cruthaíonn slice folamh.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Cruthaíonn sé slice folamh mutable.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Patrúin i slisní, faoi láthair, nach n-úsáideann ach `strip_prefix` agus `strip_suffix`.
/// Ag pointe future, tá súil againn `core::str::Pattern` a ghinearálú (atá tráth na scríbhneoireachta teoranta do `str`) go slisní, agus ansin cuirfear an trait seo ina áit nó cuirfear deireadh leis.
///
pub trait SlicePattern {
    /// Cineál eilimint an tslis atá á mheaitseáil.
    type Item;

    /// Faoi láthair, tá slice de dhíth ar thomhaltóirí `SlicePattern`.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}