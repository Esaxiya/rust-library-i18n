//! Oibríochtaí ar ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Seiceálacha an bhfuil gach beart sa slice seo laistigh de raon ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Seiceálacha gur cluiche cás-neamhíogair ASCII iad dhá shlisní.
    ///
    /// Mar an gcéanna le `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, ach gan temporaries a leithdháileadh agus a chóipeáil.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Tiontaíonn sé an slice seo go dtí a choibhéis cás uachtair ASCII atá i bhfeidhm.
    ///
    /// Déantar litreacha ASCII 'a' go 'z' a mhapáil go 'A' go 'Z', ach níl aon athrú ar litreacha neamh-ASCII.
    ///
    /// Chun luach uachtarach nua a thabhairt ar ais gan an ceann atá ann a mhodhnú, úsáid [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Tiontaíonn sé an slice seo go dtí a choibhéis cás íochtair ASCII atá i bhfeidhm.
    ///
    /// ASCII litreacha 'A' go 'Z' mapáilte chuig 'a' go 'z', ach tá litreacha nach ASCII gan athrú.
    ///
    /// Chun luach íslithe nua a thabhairt ar ais gan an ceann atá ann a mhodhnú, úsáid [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Tuairisceáin `true` má tá aon bheart sa fhocal `v` nonascii (>=128).
/// Snarfed ó `../str/mod.rs`, a dhéanann rud cosúil leis maidir le bailíochtú utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Tástáil optamaithe ASCII a úsáidfidh oibríochtaí usize-ag-an-am in ionad oibríochtaí beart ag an am (nuair is féidir).
///
/// Tá an algartam a úsáidimid anseo simplí go leor.Má tá `s` ró-ghearr, ní dhéanaimid ach gach beart a sheiceáil agus a dhéanamh leis.Seachas sin:
///
/// - Léigh an chéad fhocal le hualach neamhshainithe.
/// - Ailínigh an pointeoir, léigh focail ina dhiaidh sin go dtí deireadh le hualaí ailínithe.
/// - Léigh an `usize` deireanach ó `s` le hualach neamhshainithe.
///
/// Má tháirgeann aon cheann de na hualaí seo rud a bhfilleann `contains_nonascii` (above) fíor air, ansin tá a fhios againn go bhfuil an freagra bréagach.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Mura bhfaighimis rud ar bith ón gcur i bhfeidhm focal-ag-an-am, titim ar ais go lúb scálaithe.
    //
    // Déanaimid é seo freisin maidir le hailtireachtaí i gcás nach bhfuil ailíniú leordhóthanach ag `size_of::<usize>()` le haghaidh `usize`, toisc gur cás aisteach edge é.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Léimid an chéad fhocal gan síniú i gcónaí, rud a chiallaíonn go bhfuil `align_offset`
    // 0, ba mhaith linn an luach céanna a léamh arís don léamh ailínithe.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SÁBHÁILTEACHT: Fíoraímid `len < USIZE_SIZE` thuas.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Rinneamar é seo a sheiceáil thuas, rud beag intuigthe.
    // Tabhair faoi deara go bhfuil `offset_to_aligned` ceachtar `align_offset` nó `USIZE_SIZE`, iad araon de a sheiceáil go sainráite thuas.
    //
    debug_assert!(offset_to_aligned <= len);

    // SÁBHÁILTEACHT: is é word_ptr an ptr usize (ailínithe i gceart) a úsáidimid chun an
    // smután lár an slice.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` is é an t-innéacs beart de `word_ptr`, a úsáidtear le haghaidh seiceálacha deiridh lúb.
    let mut byte_pos = offset_to_aligned;

    // Paranoia seic faoi ailíniú, ós rud é tá muid ar tí a dhéanamh a bunch de ualaí unaligned.
    // Go praiticiúil ba cheart go mbeadh sé dodhéanta fabht a chosc i `align_offset` áfach.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Léigh focail ina dhiaidh sin go dtí go mbeidh an focal deireanach ailínithe, gan an focal ailínithe deireanach leis féin a dhéanamh le seiceáil eireaball níos déanaí, lena chinntiú go bhfuil eireaball i gcónaí mar `usize` amháin go branch `byte_pos == len` breise.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Seiceáil sanity go bhfuil an léamh faoi theorainneacha
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Agus go gcoinníonn ár mbonn tuisceana faoi `byte_pos`.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SÁBHÁILTEACHT: Tá a fhios againn go `word_ptr` ailínithe i gceart (mar gheall ar
        // `align_offset`), agus tá a fhios againn go bhfuil go leor beart againn idir `word_ptr` agus an deireadh
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SÁBHÁILTEACHT: Tá a fhios againn go bhfuil `byte_pos <= len - USIZE_SIZE`, rud a chiallaíonn go
        // tar éis an `add` seo, beidh `word_ptr` uair amháin ar a mhéad.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Seiceáil sláintíochta lena chinntiú nach bhfuil ach `usize` amháin fágtha.
    // Ba cheart é seo a ráthú ag ár riocht lúb.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SÁBHÁILTEACHT: Tá sé seo ag brath ar `len >= USIZE_SIZE`, a dhéanaimid a sheiceáil ag an tús.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}