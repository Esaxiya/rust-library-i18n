//! Sórtáil slice
//!
//! Tá algartam sórtála sa mhodúl seo bunaithe ar quicksort a dhéanann patrún Orson Peters, a foilsíodh ag: <https://github.com/orlp/pdqsort>
//!
//!
//! Tá sórtáil éagobhsaí comhoiriúnach le libcore toisc nach leithdháileann sé cuimhne, murab ionann agus ár gcur i bhfeidhm sórtála cobhsaí.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Nuair a thit siad, cóipeanna ó `src` isteach i `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SÁBHÁILTEACHT: Seo rang cúntóirí.
        //          Féach leat an úsáid a bhaineann sé as cruinneas.
        //          Eadhon, ní mór a bheith cinnte nach ndéanann `src` agus `dst` forluí mar a éilíonn `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Athraíonn an chéad eilimint ar dheis go dtí go dtagann sí ar eilimint níos mó nó cothrom.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SÁBHÁILTEACHT: Na hoibríochtaí neamhshábháilte i gceist thíos innéacsú gan seic cheangal (`get_unchecked` agus `get_unchecked_mut`)
    // agus cuimhne (`ptr::copy_nonoverlapping`) a chóipeáil.
    //
    // a.Innéacsú:
    //  1. Sheiceáil muid an méid de na eagar go>=2.
    //  2. Is léir an innéacsú go mbeidh muid ag déanamh i gcónaí idir {0 <= index < len} ar a mhéad.
    //
    // b.Cóipeáil cuimhne
    //  1. Táimid ag fáil leideanna maidir le tagairtí a ráthaítear a bheith bailí.
    //  2. Ní féidir leo forluí a dhéanamh toisc go bhfaighimid leideanna maidir le hinnéacsanna difríochta na slice.
    //     Eadhon, `i` agus `i-1`.
    //  3. Má tá an slice ailínithe i gceart, na heilimintí ailínithe i gceart.
    //     Tá sé de fhreagracht ar an nglaoiteoir a chinntiú go bhfuil an slice ailínithe i gceart.
    //
    // Féach na tráchtanna thíos chun tuilleadh sonraí a fháil.
    unsafe {
        // Má tá an chéad dá ghné as ord ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Léigh an chéad eilimint in athróg arna leithdháileadh ar chairn.
            // Má dhéantar oibríocht chomórtais seo a leanas panics, scaoilfear `hole` agus scríobhfaidh sé an eilimint go huathoibríoch ar ais sa slice.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Bog eilimint `i`-ú áit amháin ar chlé, agus mar sin aistrigh an poll ar dheis.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` titeann sé agus dá bhrí sin cóipeálann `tmp` isteach sa pholl atá fágtha i `v`.
        }
    }
}

/// Shifts an ghné dheireanach ar an taobh clé go dtí go encounters sé ina ghné níos lú nó cothrom.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SÁBHÁILTEACHT: Na hoibríochtaí neamhshábháilte i gceist thíos innéacsú gan seic cheangal (`get_unchecked` agus `get_unchecked_mut`)
    // agus cuimhne (`ptr::copy_nonoverlapping`) a chóipeáil.
    //
    // a.Innéacsú:
    //  1. Rinneamar méid an eagair a sheiceáil go>=2.
    //  2. Is léir an innéacsú go mbeidh muid ag déanamh i gcónaí idir `0 <= index < len-1` ar a mhéad.
    //
    // b.Cóipeáil cuimhne
    //  1. Táimid ag fáil leideanna maidir le tagairtí a ráthaítear a bheith bailí.
    //  2. Ní féidir leo forluí a dhéanamh toisc go bhfaighimid leideanna maidir le hinnéacsanna difríochta na slice.
    //     Eadhon, `i` agus `i+1`.
    //  3. Má tá an slice ailínithe i gceart, na heilimintí ailínithe i gceart.
    //     Tá sé de fhreagracht ar an nglaoiteoir a chinntiú go bhfuil an slice ailínithe i gceart.
    //
    // Féach na tráchtanna thíos chun tuilleadh sonraí a fháil.
    unsafe {
        // Má tá an dá ghné dheireanacha as ord ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Léigh an eilimint dheireanach in athróg arna leithdháileadh ar chairn.
            // Má dhéantar oibríocht chomórtais seo a leanas panics, scaoilfear `hole` agus scríobhfaidh sé an eilimint go huathoibríoch ar ais sa slice.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Bog eilimint `i`-ú áit amháin ar dheis, agus mar sin aistrigh an poll ar chlé.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` titeann sé agus dá bhrí sin cóipeálann `tmp` isteach sa pholl atá fágtha i `v`.
        }
    }
}

/// Déan slisne a shórtáil go páirteach trí roinnt eilimintí as ord a aistriú timpeall.
///
/// Tuairisceáin `true` má tá an slice curtha in eagar ag an deireadh.Is í an fheidhm seo *O*(*n*) an cás is measa.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Uaslíon na mbeirteanna as ord in aice láimhe a aistreofar.
    const MAX_STEPS: usize = 5;
    // Má tá an slice níos giorra ná seo, ná aistrigh aon eilimintí.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SÁBHÁILTEACHT: Rinne muid cheana go sainráite ar an seiceáil cheangal leis `i < len`.
        // Gach é ár innéacsú dhiaidh ach amháin sa réimse `0 <= index < len`
        unsafe {
            // Faigh an chéad péire eile d`eilimintí as ord in aice láimhe.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // An bhfuil muid déanta?
        if i == len {
            return true;
        }

        // Ná eilimintí ar arrays gearr athrú, tá sin ar chostas feidhmíochta.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Babhtáil an péire eilimintí aimsithe.Cuireann sé seo iad in ord ceart.
        v.swap(i - 1, i);

        // Aistrigh an eilimint níos lú ar chlé.
        shift_tail(&mut v[..i], is_less);
        // Aistrigh an ghné is mó ar dheis.
        shift_head(&mut v[i..], is_less);
    }

    // Níor éirigh linn an slice a shórtáil sa líon teoranta céimeanna.
    false
}

/// Sórtáil slice ag baint úsáide as sórtáil isteach, arb é *O*(*n*^ 2) an cás is measa.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Sórtáil `v` ag baint úsáide as heapsort, a ráthaíonn *O*(*n*\*log(* n*)) an cás is measa.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Urramaíonn an gcarn dénártha an athraithe `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Páistí `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Roghnaigh an leanbh is mó.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Stop má choinníonn an t-invariant ag `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Babhtáil `node` leis an leanbh is mó, bogadh amháin síos céim, agus leanúint ar aghaidh criathrú.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Tóg an gcarn in am líneach.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop eilimintí uasta ón gcarn.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Deighiltí `v` ina n-eilimintí níos lú ná `pivot`, agus eilimintí níos mó ná nó cothrom le `pivot` ina dhiaidh sin.
///
///
/// Tuairisceáin an líon na n-eilimintí níos lú ná `pivot`.
///
/// Déantar deighilt bloc-ar-bhloc d`fhonn costas oibríochtaí brainseach a íoslaghdú.
/// Is é an smaoineamh i láthair sa pháipéar [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Líon na n-eilimintí i mbloc tipiciúil.
    const BLOCK: usize = 128;

    // Déanann an algartam deighilte na céimeanna seo a leanas a athdhéanamh go dtí go mbeidh sé críochnaithe:
    //
    // 1. Rianaigh bloc ón taobh clé chun eilimintí níos mó ná nó cothrom leis an mhaighdeog a aithint.
    // 2. Rianaigh bloc ón taobh dheis chun eilimintí níos lú ná an mhaighdeog a aithint.
    // 3. Déan na heilimintí sainaitheanta a mhalartú idir an taobh clé agus an taobh deas.
    //
    // Coinnímid na hathróga seo a leanas le haghaidh bloc eilimintí:
    //
    // 1. `block` - Líon na n-eilimintí sa bhloc.
    // 2. `start` - Tosaigh pointeoir isteach sa tsraith `offsets`.
    // 3. `end` - Deireadh pointeoir isteach sa tsraith `offsets`.
    // 4. `fritháireamh, Innéacsanna eilimintí as ord laistigh den bhloc.

    // An bloc reatha ar an taobh clé (ó `l` go `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // An bloc atá ann faoi láthair ar an taobh deas (ó `r.sub(block_r)` to `r`).
    // SÁBHÁILTEACHT: Luann na cáipéisí le haghaidh .add() go sonrach go bhfuil `vec.as_ptr().add(vec.len())` sábháilte i gcónaí`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Nuair a fhaighimid VLAnna, déan iarracht sraith amháin de fhad `min(v.len(), 2 * BLOCK) a chruthú `in áit
    // ná dhá eagar de mhéid seasta ar fhad `BLOCK`.D`fhéadfadh go mbeadh VLAnna níos éifeachtaí ó thaobh taisce de.

    // Tuairisceáin an líon na n-eilimintí idir leideanna `l` (inclusive) agus `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Táimid ag déanamh deighilt bloc-ar-bhloc nuair a bhíonn `l` agus `r` an-dlúth.
        // Ansin a dhéanann muid roinnt obair paiste-suas chun a dheighilt na gnéithe eile i idir.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Líon na n-eilimintí atá fágtha (gan comparáid a dhéanamh leis an pivot fós).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Coigeartaigh méideanna bloc ionas go bhfuil an bloc ar chlé agus ar dheis ní forluí, ach a fháil go foirfe ailínithe leis an bhearna fad atá fágtha a chlúdach.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Rianaigh eilimintí `block_l` ón taobh clé.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SÁBHÁILTEACHT: Baineann úsáid na `offset` leis na hoibríochtaí neamhshábháilteachta thíos.
                //         De réir na gcoinníollacha a éilíonn an fheidhm, déanaimid iad a shásamh mar gheall ar:
                //         1. `offsets_l` déantar leithdháileadh ar chairn, agus mar sin meastar gur réad leithdháilte ar leithligh é.
                //         2. Filleann an fheidhm `is_less` `bool`.
                //            Ní bheidh Réitigh ar `bool` thar maoil `isize`.
                //         3. Táimid tar éis a ráthú go mbeidh `block_l` mar `<= BLOCK`.
                //            Plus, bhí `end_l` ar dtús báire go dtí an pointeoir tús na `offsets_` do dearbhuíodh ar an chairn.
                //            Dá bhrí sin, tá a fhios againn go bhfuil fiú i gcás is measa (gach invocations de `is_less` Filleann bréagach) beidh muid ach amháin ar a mhéad 1 beart pas a fháil sa deireadh.
                //        Oibriú neamhshábháilteachta eile anseo is ea dí-chomhdháil `elem`.
                //        Mar sin féin, ba é `elem` an pointeoir tosaigh ar an slice atá bailí i gcónaí.
                unsafe {
                    // Comparáid gan brainse.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // riandúile `block_r` ó thaobh na láimhe deise.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SÁBHÁILTEACHT: Baineann úsáid na `offset` leis na hoibríochtaí neamhshábháilteachta thíos.
                //         De réir na gcoinníollacha a éilíonn an fheidhm, déanaimid iad a shásamh mar gheall ar:
                //         1. `offsets_r` déantar leithdháileadh ar chairn, agus mar sin meastar gur réad leithdháilte ar leithligh é.
                //         2. Filleann an fheidhm `is_less` `bool`.
                //            Ní bheidh Réitigh ar `bool` thar maoil `isize`.
                //         3. Táimid tar éis a ráthaítear go mbeidh `block_r` a `<= BLOCK`.
                //            Ina theannta sin, socraíodh `end_r` i dtosach go pointeoir tosaigh `offsets_` a dearbhaíodh ar an gcruach.
                //            Mar sin, tá a fhios againn, fiú amháin sa chás is measa (gach cuireadh de thuairisceáin `is_less` fíor) nach mbeidh muid ach 1 bheart ar a mhéad pas a fháil sa deireadh.
                //        Oibriú neamhshábháilteachta eile anseo is ea dí-chomhdháil `elem`.
                //        Mar sin féin, bhí `elem` dtús `1 *sizeof(T)` thar an deireadh agus decrement muid ag dó le `1* sizeof(T)` roimh rochtain a fháil air.
                //        Ina theannta sin, dearbhaíodh go raibh `block_r` níos lú ná `BLOCK` agus dá bhrí sin beidh `elem` ag tagairt do thús an tsleachta ar a mhéad.
                unsafe {
                    // Comparáid gan brainse.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Líon na n-eilimintí as ord le babhtáil idir an taobh clé agus an taobh deas.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // In ionad péire amháin a mhalartú ag an am, tá sé níos éifeachtaí sárú timthriallach a dhéanamh.
            // Ní hionann é seo agus babhtáil, ach táirgeann sé toradh comhchosúil ag úsáid níos lú oibríochtaí cuimhne.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Bhí ar athraíodh a ionad ar gach gné taobh amuigh den ord sa bhloc chlé.Bog go dtí an chéad bhloc eile.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Bogadh na heilimintí go léir as ord sa bhloc ceart.Bog go dtí an bloc roimhe seo.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Níl fágtha anois ach bloc amháin ar a laghad (bíodh sé ar chlé nó ar dheis) le heilimintí as ord nach mór a bhogadh.
    // Is féidir na heilimintí atá fágtha a aistriú go dtí an deireadh laistigh dá mbloc.
    //

    if start_l < end_l {
        // Tá an bloc ar chlé fós.
        // Bog na heilimintí atá as ord atá fágtha ar an taobh thall.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Tá an bloc ceart fós ann.
        // Bog na heilimintí atá as ord atá fágtha ar an taobh clé.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Ní dhéanfaidh aon ní eile a dhéanamh, táimid ag déanamh.
        width(v.as_mut_ptr(), l)
    }
}

/// Deighiltí `v` ina n-eilimintí níos lú ná `v[pivot]`, agus eilimintí níos mó ná nó cothrom le `v[pivot]` ina dhiaidh sin.
///
///
/// Filleann tuple de:
///
/// 1. Líon na n-eilimintí níos lú ná `v[pivot]`.
/// 2. Fíor má roinneadh `v` cheana féin.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Cuir an pivot ag tús slice.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Léigh an pivot in athróg arna leithdháileadh ar chruach le haghaidh éifeachtúlachta.
        // Más oibríocht chomórtais seo a leanas panics, scríobhfar an pivot ar ais go huathoibríoch isteach sa slice.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Faigh an chéad péire na n-eilimintí lasmuigh den ordú.
        let mut l = 0;
        let mut r = v.len();

        // SÁBHÁILTEACHT: An unsafety thíos i gceist innéacsú eagar.
        // Don chéad cheann: Déanaimid na teorainneacha a sheiceáil anseo cheana le `l < r`.
        // Don dara ceann: Tá `l == 0` agus `r == v.len()` againn i dtosach agus rinneamar seiceáil ar an `l < r` sin ag gach oibríocht innéacsaithe.
        //                     Ón áit seo tá a fhios againn go gcaithfidh `r` a bheith `r == l` ar a laghad a léiríodh a bheith bailí ón gcéad cheann.
        unsafe {
            // Faigh an chéad níos eilimint ná nó cothrom le mhaighdeog.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Faigh an eilimint dheireanach níos lú ná an mhaighdeog.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` téann sé as a raon feidhme agus scríobhann sé an pivot (ar athróg leithdháilte cruachta é) ar ais sa slice ina raibh sé ar dtús.
        // Tá an chéim seo ríthábhachtach chun sábháilteacht a chinntiú!
        //
    };

    // Cuir an mhaighdeog idir an dá Deighiltí.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Deighiltí `v` ina n-eilimintí atá cothrom le `v[pivot]` agus eilimintí níos mó ná `v[pivot]` ina dhiaidh sin.
///
/// Filleann sé líon na n-eilimintí atá cothrom leis an pivot.
/// Glactar leis nach bhfuil eilimintí níos lú ná an pivot i `v`.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Cuir an pivot ag tús slice.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Léigh an pivot in athróg arna leithdháileadh ar chruach le haghaidh éifeachtúlachta.
    // Más oibríocht chomórtais seo a leanas panics, scríobhfar an pivot ar ais go huathoibríoch isteach sa slice.
    // SÁBHÁILTEACHT: Is é an pointeoir anseo bailí toisc go bhfuil sé a fhaightear ó aon tagairt d'slice.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Anois deighilt an slice.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SÁBHÁILTEACHT: An unsafety thíos i gceist innéacsú eagar.
        // Don chéad cheann: Déanaimid na teorainneacha a sheiceáil anseo cheana le `l < r`.
        // Don dara ceann: Tá `l == 0` agus `r == v.len()` againn i dtosach agus rinneamar seiceáil ar an `l < r` sin ag gach oibríocht innéacsaithe.
        //                     Ón áit seo tá a fhios againn go gcaithfidh `r` a bheith `r == l` ar a laghad a léiríodh a bheith bailí ón gcéad cheann.
        unsafe {
            // Faigh an chéad eilimint níos mó ná an mhaighdeog.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Faigh an eilimint dheireanach atá cothrom leis an mhaighdeog.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // An bhfuil muid déanta?
            if l >= r {
                break;
            }

            // Babhtáil an péire aimsithe eilimintí as ord.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Fuaireamar eilimintí `l` cothrom leis an pivot.Cuir 1 go áireamh chun mhaighdeog féin.
    l + 1

    // `_pivot_guard` téann sé as a raon feidhme agus scríobhann sé an pivot (ar athróg leithdháilte cruachta é) ar ais sa slice ina raibh sé ar dtús.
    // Tá an chéim seo ríthábhachtach chun sábháilteacht a chinntiú!
}

/// Scatters roinnt eilimintí ar fud in iarracht chun patrúin a d'fhéadfadh bheith ina chúis landairí imbalanced in quicksort bhriseadh.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Gineadóir uimhreacha pseudorandom ón bpáipéar "Xorshift RNGs" le George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Tóg modulo uimhreacha randamacha an uimhir seo.
        // Oireann an uimhir le `usize` toisc nach bhfuil `len` níos mó ná `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Beidh roinnt iarrthóirí pivot in aice láimhe an innéacs seo.Déanaimis iad a randamú.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Cruthaigh moduló uimhir randamach `len`.
            // D`fhonn oibríochtaí costasacha a sheachaint, áfach, glacaimid cumhacht de dhá mhodh ar dtús, agus ansin laghdaímid faoi `len` go dtí go n-oireann sé don raon `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` ráthaítear go mbeidh sé níos lú ná `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Roghnaíonn sé pivot in `v` agus cuireann sé an t-innéacs agus `true` ar ais más dóigh go bhfuil an slice curtha in eagar cheana féin.
///
/// D`fhéadfaí eilimintí in `v` a atheagrú sa phróiseas.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Fad íosta chun an modh airmheán-airmheán a roghnú.
    // Úsáideann slisní níos giorra an modh meánach trí-simplí.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Uaslíon babhtálacha is féidir a dhéanamh san fheidhm seo.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Trí innéacsanna a bhfuilimid chun pivot a roghnú ina leith.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Áireamh líon iomlán na mbabhtálacha atáimid ar tí a dhéanamh agus innéacsanna á sórtáil.
    let mut swaps = 0;

    if len >= 8 {
        // Babhtáil innéacsanna ionas go mbeidh `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Babhtáil innéacsanna ionas go mbeidh `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Aimsíonn sé airmheán `v[a - 1], v[a], v[a + 1]` agus stórálann sé an t-innéacs i `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Faigh airmheáin i gcomharsanachtaí `a`, `b`, agus `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Faigh an t-airmheán i measc `a`, `b`, agus `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Rinneadh an líon uasta babhtálacha.
        // Tá gach seans ann go bhfuil an slice ag ísliú nó ag dul síos den chuid is mó, mar sin is dócha go gcuideoidh aisiompú lena sórtáil níos gasta.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Sórtáil `v` go hathchúrsach.
///
/// Má bhí réamhtheachtaí ag an slice sa tsraith bhunaidh, sonraítear é mar `pred`.
///
/// `limit` líon na n Deighiltí imbalanced cheadaítear sula athrú chuig `heapsort`.
/// Má tá sé náid, beidh an fheidhm seo ag aistriú láithreach chuig heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Slices de suas le fad an fháil curtha in eagar ag baint úsáide as sort leanas a chur isteach.
    const MAX_INSERTION: usize = 20;

    // Fíor má bhí an deighilt dheireanach cothrom go réasúnta.
    let mut was_balanced = true;
    // Fíor más rud é nach raibh an t-partitioning seo caite heilimintí Suaitheadh (bhí an slice dheighilt cheana).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Déantar slisní an-ghearr a shórtáil trí úsáid a bhaint as sórtáil isteach.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Má bhí an iomarca roghanna olc pivot rinneadh, ach thagann ar ais go dtí heapsort chun ráthaíocht `O(n * log(n))` is measa ar chás.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Má bhí an deighilt dheireanach neamhchothromaithe, déan iarracht patrúin a bhriseadh sa slice trí roinnt eilimintí a shuí timpeall.
        // Tá súil againn go roghnóimid pivot níos fearr an uair seo.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Roghnaigh mhaighdeog agus iarracht guessing cibé an bhfuil an slice curtha in eagar cheana.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Dá mbeadh an partitioning deiridh cothrom decently agus ní raibh heilimintí Suaitheadh, agus más rud é predicts roghnú pivot an slice is dócha curtha in eagar cheana féin ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Déan iarracht roinnt eilimintí as ord a aithint agus iad a aistriú go suíomhanna cearta.
            // Má chríochnaíonn an slice á sórtáil go hiomlán, déantar muid.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Má tá an pivot roghnaithe cothrom leis an réamhtheachtaí, ansin is í an eilimint is lú sa slice.
        // Dheighilt an slice i eilimintí cothrom le agus eilimintí níos mó ná an mhaighdeog.
        // Is gnách go mbuailtear an cás seo nuair a bhíonn go leor eilimintí dúblacha sa slice.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Lean ar aghaidh ag sórtáil eilimintí níos mó ná an mhaighdeog.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Deighilt an slice.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Roinn an slice i `left`, `pivot`, agus `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Recurse isteach ar an taobh níos giorra ach amháin chun go n-íoslaghdófar an líon iomlán na nglaonna Athchúrsach agus a ithe níos lú spáis chairn.
        // Ansin lean ar aghaidh leis an taobh is faide (tá sé seo cosúil le hathchúrsáil eireaball).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Sórtáil `v` ag baint úsáide as quicksort a chosnaíonn patrún, arb é *O*(*n*\*log(* n*)) an cás is measa.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Sórtáil Níl iompar brí ar chineálacha náid-iarrachtaí.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Cuir teorainn le líon na ndeighiltí neamhchothromaithe go `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Maidir le slisní chomh fada leis seo is dócha go mbeidh sé níos tapa iad a shórtáil.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Roghnaigh pivot
        let (pivot, _) = choose_pivot(v, is_less);

        // Má tá an pivot roghnaithe cothrom leis an réamhtheachtaí, ansin is í an eilimint is lú sa slice.
        // Dheighilt an slice i eilimintí cothrom le agus eilimintí níos mó ná an mhaighdeog.
        // Is gnách go mbuailtear an cás seo nuair a bhíonn go leor eilimintí dúblacha sa slice.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Má táimid tar éis ár n-innéacs a rith, tá muid go maith.
                if mid > index {
                    return;
                }

                // Seachas sin, lean ar aghaidh ag sórtáil eilimintí níos mó ná an mhaighdeog.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Roinn an slice i `left`, `pivot`, agus `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Más innéacs lár==, táimid déanta, ós rud é gur ráthaigh partition() go bhfuil na heilimintí go léir tar éis lár níos mó ná nó cothrom le lár.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Níl aon iompar brí ag an sórtáil ar chineálacha meánmhéide.Ná déan Faic.
    } else if index == v.len() - 1 {
        // Faigh uasghné agus cuir í sa suíomh deireanach den eagar.
        // Táimid saor chun úsáid `unwrap()` anseo mar tá a fhios againn nach mór v folamh.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Faigh mionghné agus cuir í sa chéad áit den eagar.
        // Táimid saor chun úsáid `unwrap()` anseo mar tá a fhios againn nach mór v folamh.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}