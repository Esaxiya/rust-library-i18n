use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// A wrapper go tiomsaitheoir bac ó glaoch go huathoibríoch `destructor T` ar.
/// Tá an wrapper 0 chostas.
///
/// `ManuallyDrop<T>` faoi réir na optamaithe leagan amach céanna le `T`.
/// Dá bhrí sin, tá sé *aon éifeacht* ar na boinn tuisceana a dhéanann an Tiomsaitheoir mar gheall ar a bhfuil ann.
/// Mar shampla, is iompar neamhshainithe é `ManuallyDrop<&mut T>` a thionscnamh le [`mem::zeroed`].
/// Más gá duit sonraí neamhbheartaithe a láimhseáil, bain úsáid as [`MaybeUninit<T>`] ina ionad.
///
/// Tabhair faoi deara go bhfuil rochtain ar an luach taobh istigh de `ManuallyDrop<T>` sábháilte.
/// Ciallaíonn sé seo nár cheart `ManuallyDrop<T>` a bhfuil a ábhar tite a nochtadh trí API sábháilte poiblí.
/// Dá réir sin, tá `ManuallyDrop::drop` neamhshábháilte.
///
/// # `ManuallyDrop` agus ord titim.
///
/// Rust Tá [drop order] dea-shainithe de luachanna.
/// Chun a chinntiú go scaoiltear réimsí nó muintir na háite in ord ar leith, déan na dearbhuithe a athordú sa chaoi is gurb é an t-ordú intuigthe titim an ceann ceart.
///
/// Is féidir `ManuallyDrop` a úsáid chun an t-ordú titim a rialú, ach teastaíonn cód neamhshábháilte uaidh seo agus is deacair é a dhéanamh i gceart i láthair an scaoilte.
///
///
/// Mar shampla, más mian leat a chinntiú go dtitfear réimse ar leith i ndiaidh a chéile, déan é an réimse deireanach de struchtúr:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` a thitfear tar éis `children`.
///     // Rust ráthaíochtaí go bhfuil réimsí thit san ord dearbhaithe.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Wrap le luach a thit de láimh.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Is féidir leat oibriú go sábháilte fós ar an luach
    /// assert_eq!(*x, "Hello");
    /// // Ach ní rithfear `Drop` anseo
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Sleachta an luach ón gcoimeádán `ManuallyDrop`.
    ///
    /// Ligeann sé seo an luach a ísliú arís.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Titeann sé seo an `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Tógann sé an luach ón gcoimeádán `ManuallyDrop<T>` amach.
    ///
    /// Tá an modh seo i gceist go príomha chun bogadh amach luachanna i titim.
    /// In ionad a úsáid [`ManuallyDrop::drop`] le titim de láimh ar an luach, is féidir leat úsáid a bhaint as an modh seo a chur ar an luach agus a úsáid atá ag teastáil go, áfach.
    ///
    /// Nuair is féidir, b`fhearr [`into_inner`][`ManuallyDrop::into_inner`] a úsáid ina ionad, rud a choisceann ábhar an `ManuallyDrop<T>` a mhacasamhlú.
    ///
    ///
    /// # Safety
    ///
    /// Seo an fheidhm bogann semantically amach an luach atá gan a thuilleadh úsáide a chosc, ag fágáil an staid an coimeádán gan athrú.
    /// Is ortsa atá an fhreagracht a chinntiú nach bhfuil sé seo `ManuallyDrop` úsáidtear arís.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SÁBHÁILTEACHT: táimid ag léamh ó thagairt, atá ráthaithe
        // a bheith bailí le haghaidh léamha.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Láimh titeann an luach atá.Sé seo go díreach comhionann le glaoch [`ptr::drop_in_place`] le pointeoir chuig an luach atá.
    /// Dá réir sin, ach amháin má tá an luach atá ar struct pacáilte, an destructor a dtugtar i-bhfeidhm gan gluaiseacht an luach, agus dá bhrí sin is féidir iad a úsáid chun titim go sábháilte sonraí [pinned].
    ///
    /// Má tá tú ag úinéireacht an luach, is féidir leat é a úsáid [`ManuallyDrop::into_inner`] ina ionad.
    ///
    /// # Safety
    ///
    /// Ritheann an fheidhm an destructor an luach atá.
    /// Seachas na hathruithe a rinne an destructor féin, tá an chuimhne ar chlé gan athrú, agus mar sin chomh fada agus go bhfuil an Tiomsaitheoir i gceist i seilbh fós le beagán-patrún a bheidh bailí chineál `T`.
    ///
    ///
    /// Mar sin féin, níor cheart an luach "zombie" seo a bheith nochtaithe do chód sábháilte, agus níor cheart an fheidhm seo a ghlaoch níos mó ná uair amháin.
    /// Chun úsáid a luach tar éis tá sé fágtha ar lar, nó buail isteach ar luach amanna éagsúla, is féidir a chur faoi deara Oibriú Neamhshainithe (ag brath ar an méid a dhéanann `drop`).
    /// Tá sé seo cosc de ghnáth ag an gcóras cineál, ach ní mór d'úsáideoirí de `ManuallyDrop` seasamh na ráthaíochtaí gan chúnamh ón tiomsaitheoir.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SÁBHÁILTEACHT: tá muid ag dropping an luach léirigh tagairt mutable
        // a ráthaítear a bheith bailí le haghaidh scríbhinní.
        // Is faoin té atá ag glaoch ar an a chinntiú nach bhfuil `slot` thit arís.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}