use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// A Cineál wrapper a thógáil cásanna uninitialized de `T`.
///
/// # Tionscnamh invariant
///
/// Glacann an tiomsaitheoir, go ginearálta, leis go gcuirtear athróg i dtosach i gceart de réir riachtanais chineál an athróg.Mar shampla, ní mór athróg de chineál tagartha a ailíniú agus neamh-NULL.
/// Is invariant é seo nach mór a sheasamh *i gcónaí*, fiú amháin i gcód neamhshábháilte.
/// Mar thoradh air sin, bíonn [undefined behavior][ub] meandarach mar thoradh ar athróg de chineál tagartha a chuireann tús le nialas, is cuma má úsáidtear an tagairt sin riamh chun rochtain a fháil ar chuimhne:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // iompar neamhshainithe!⚠️
/// // An cód coibhéiseacha `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // iompar neamhshainithe!⚠️
/// ```
///
/// Baineann an tiomsaitheoir leas as seo le haghaidh barrfheabhsúcháin éagsúla, mar shampla seiceálacha rith-ama a dhíothú agus leagan amach `enum` a bharrfheabhsú.
///
/// Mar an gcéanna, d'fhéadfadh cuimhne go hiomlán uninitialized mbeadh aon ábhar, agus ní mór a bheith i gcónaí `bool` `true` nó `false`.Dá réir sin, is iompar neamhshainithe é `bool` neamhbheartaithe a chruthú:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // iompar neamhshainithe!⚠️
/// // An cód coibhéiseacha `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // iompar neamhshainithe!⚠️
/// ```
///
/// Thairis sin, tá cuimhne neamhbheartaithe speisialta sa mhéid is nach bhfuil luach seasta aici ("fixed" a chiallaíonn "it won't change without being written to").Is féidir torthaí difriúla a thabhairt má léitear an beart céanna neamhbheartaithe arís agus arís eile.
/// Seo a dhéanann undefined sé iompar a bheith acu sonraí uninitialized i athróg fiú má tá sin athróg cineál slánuimhir, is féidir a shealbhú ar shlí eile ar aon phatrún giotán *seasta*:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // iompar neamhshainithe!⚠️
/// // An cód coibhéiseach le `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // iompar neamhshainithe!⚠️
/// ```
/// (Tabhair faoi deara nach bhfuil na rialacha maidir le slánuimhreacha neamhbheartaithe tugtha chun críche go fóill, ach go dtí go mbeidh siad, moltar iad a sheachaint.)
///
/// Ar a bharr sin, cuimhnigh go bhfuil an chuid is mó cineálacha invariants breise thar á meas ach initialized ag an leibhéal cineál.
/// Mar shampla, tá [`Vec<T>`] 1`-initialized mheas initialized (faoi chur chun feidhme atá ann faoi láthair ní athraíonn sé seo ionann ráthaíocht cobhsaí) toisc go bhfuil an ceanglas ach a fhios ag an Tiomsaitheoir mar gheall air go gcaithfidh an pointeoir sonraí a bheith neamh-null.
/// Ag cruthú den sórt sin a `Vec<T>` Ní faoi deara *iompar undefined láithreach*, ach beidh faoi deara iompar undefined leis an chuid is mó oibríochtaí sábháilte (lena n-áirítear dropping é).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` cuireann sé ar chumas cód neamhshábháilte déileáil le sonraí neamhbheartaithe.
/// Is comhartha é don tiomsaitheoir a thugann le tuiscint go mb`fhéidir nach *tosaigh* na sonraí anseo:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Cruthaigh tagairt uninitialized go follasach.
/// // Tá a fhios ag an tiomsaitheoir go bhféadfadh sonraí taobh istigh de `MaybeUninit<T>` a bheith neamhbhailí, agus dá bhrí sin ní UB iad seo:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Socraigh sé le luach bailí.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Bhaint as na sonraí initialized-an *cheadaítear ach amháin tar éis*`x` initializing i gceart!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Ansin tá a fhios ag an tiomsaitheoir gan aon bhoinn tuisceana nó barrfheabhsúcháin mícheart a dhéanamh ar an gcód seo.
///
/// Is féidir leat smaoineamh ar `MaybeUninit<T>` a bheith ina beagán cosúil `Option<T>` ach gan aon cheann de na rianú reáchtáil-am agus gan aon cheann de na seiceálacha sábháilteachta.
///
/// ## out-pointers
///
/// Is féidir leat úsáid a bhaint `MaybeUninit<T>` a chur i bhfeidhm "out-pointers": in ionad na sonraí ag filleadh ó fheidhm, pas é pointeoir chuig roinnt cuimhne (uninitialized) a chur ar an toradh isteach.
/// aisiúil é seo nuair a bheidh sé tábhachtach don té atá ag glaoch go dtí rialú conas an chuimhne is é an toradh a stóráil i Faigheann leithdháilte, agus is mian leat a sheachaint bogann gan ghá.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` Ní titim an t-ábhar d'aois, rud atá tábhachtach.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Anois tá a fhios againn `v` atá initialized!Cinntíonn sé seo freisin go dtiteann an vector i gceart.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Tionscnamh eagar-ar-eilimint a thionscnamh
///
/// `MaybeUninit<T>` Is féidir é a úsáid chun thúsú le réimse mór eilimint-trí-eilimint:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Cruthaigh sraith neamhbheartaithe de `MaybeUninit`.
///     // Tá an `assume_init` sábháilte mar is é an cineál atá á mhaíomh againn a bheith tosaithe anseo ná dornán de `MaybeUninit`, nach gá iad a thionscnamh.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Ní dhéanann titim `MaybeUninit` aon rud.
///     // Mar sin ní cúis leis an seanluach neamhbheartaithe a thitim má úsáidtear sannadh pointeoir amh in ionad `ptr::write`.
/////
///     // Chomh maith leis sin má tá panic linn an lúb, ní mór dúinn a sceitheadh chuimhne, ach níl aon cheist sábháilteachta chuimhne.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Déantar gach rud a thúsú.
///     // Transmute an eagar ar an gcineál initialized.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Is féidir leat oibriú freisin le eagair atá tosaithe go páirteach, a d`fhéadfaí a fháil i mbunachair sonraí ar leibhéal íseal.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Cruthaigh sraith neamhbheartaithe de `MaybeUninit`.
/// // Tá an `assume_init` sábháilte mar is é an cineál atá á mhaíomh againn a bheith tosaithe anseo ná dornán de `MaybeUninit`, nach gá iad a thionscnamh.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Comhairigh líon na n-eilimintí againn sannadh.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // I gcás gach earra san eagar, scaoil má leithdháilimid é.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Initializing a struct réimse-ar-réimse
///
/// Is féidir leat úsáid a bhaint `MaybeUninit<T>`, agus an macra [`std::ptr::addr_of_mut`], a thúsú réimse structs trí réimse:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Initializing an réimse `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Initializing an réimse `list` Má tá panic anseo, ansin an `String` sna sceitheadh réimse `name`.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Déantar na réimsí uile a thúsú, mar sin tugaimid `assume_init` chun Foo tosaigh a fháil.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` ráthaithe a bheith ar an méid céanna, ailíniú, agus ABI mar `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Ach cuimhnigh go ndéanfaí cineál *ina* nach bhfuil `MaybeUninit<T>` gá an leagan amach céanna;Ní chuireann Rust in ráthaíocht ghinearálta go bhfuil na réimsí a `Foo<T>` t-ordú céanna mar `Foo<U>` fiú má tá `T` agus `U` an méid céanna agus ailíniú.
///
/// Ina theannta sin, toisc go bhfuil aon luach giotán bailí do `MaybeUninit<T>` ní féidir leis an tiomsaitheoir barrfheabhsúcháin non-zero/niche-filling a chur i bhfeidhm, a bhféadfadh méid níos mó a bheith mar thoradh air:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Má tá `T` FFI-sábháilte, is é sin ansin `MaybeUninit<T>`.
///
/// Cé go bhfuil `MaybeUninit` `#[repr(transparent)]` (ag léiriú go ráthaíonn sé an méid céanna, ailíniú, agus ABI mar `T`), a dhéanann an * bhfuil athrú ar aon cheann de na caveats roimhe.
/// `Option<T>` agus d`fhéadfadh go mbeadh méideanna difriúla fós ag `Option<MaybeUninit<T>>`, agus féadfar cineálacha ina bhfuil réimse de chineál `T` a leagan amach (agus a mhéideanna) ar bhealach difriúil ná dá mba `MaybeUninit<T>` an réimse sin.
/// `MaybeUninit` is cineál ceardchumainn é, agus tá `#[repr(transparent)]` ar cheardchumainn éagobhsaí (féach [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Le himeacht aimsire, d`fhéadfadh ráthaíochtaí beachta `#[repr(transparent)]` ar cheardchumainn teacht chun cinn, agus féadfaidh `MaybeUninit` fanacht `#[repr(transparent)]` nó ní fhéadfaidh sé fanacht.
/// É sin ráite, beidh `MaybeUninit<T>`* * i gcónaí ráthaíocht go bhfuil sé an méid céanna, ailíniú, agus ABI mar `T`;tá sé ach gurb é an bealach `MaybeUninit` uirlisí gur féidir ráthaíocht cinn.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// ítim Lang ionas gur féidir linn a wrap cineálacha eile ann.Tá sé seo úsáideach do ghineadóirí.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Gan glaoch `T::clone()`, ní féidir a fhios againn má táimid initialized go leor do sin.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Cruthaigh `MaybeUninit<T>` nua initialized leis an luach a tugadh.
    /// Tá sé sábháilte [`assume_init`] a ghlaoch ar luach fillte na feidhme seo.
    ///
    /// Tabhair faoi deara go ní bheidh dropping `MaybeUninit<T>` glaoch `cód titim T` ar.
    /// Is ortsa atá an fhreagracht a chinntiú `T` Faigheann thit má fuair sé initialized.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Cruthaíonn sé `MaybeUninit<T>` nua i stát neamhbheartaithe.
    ///
    /// Tabhair faoi deara go ní bheidh dropping `MaybeUninit<T>` glaoch `cód titim T` ar.
    /// Is ortsa atá an fhreagracht a chinntiú `T` Faigheann thit má fuair sé initialized.
    ///
    /// Féach an [type-level documentation][MaybeUninit] le haghaidh roinnt samplaí.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Cruthaigh sraith nua de na míreanna `MaybeUninit<T>`, i riocht uninitialized.
    ///
    /// Note: i leagan future Rust fhéadfadh an modh seo a bheith gan ghá nuair a cheadaíonn error eagar liteartha [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// D'fhéadfadh an sampla a úsáid thíos ansin `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Tuairisceáin a (b'fhéidir níos lú) slice sonraí a léadh i ndáiríre
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SÁBHÁILTEACHT: An uninitialized Is `[MaybeUninit<_>; LEN]` bailí.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Cruthaigh `MaybeUninit<T>` nua i riocht uninitialized, leis an chuimhne á líonadh le bytes `0`.Braitheann sé ar cé acu `T` a dhéanann cheana féin le haghaidh initialization cuí.
    ///
    /// Mar shampla, tá `MaybeUninit<usize>::zeroed()` initialized, ach nach bhfuil `MaybeUninit<&'static i32>::zeroed()` toisc nach caithfear teistiméireachtaí a fháil null.
    ///
    /// Tabhair faoi deara go ní bheidh dropping `MaybeUninit<T>` glaoch `cód titim T` ar.
    /// Is ortsa atá an fhreagracht a chinntiú `T` Faigheann thit má fuair sé initialized.
    ///
    /// # Example
    ///
    /// Úsáid cheart na feidhme seo: déan struchtúr le nialas a thionscnamh, áit ar féidir le gach réimse den déanmhas an patrún giotán 0 a choinneáil mar luach bailí.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// * * Úsáid mhícheart na feidhme sin: glaoch `x.zeroed().assume_init()` nuair nach bhfuil `0` bailí giotán-patrún do chineál:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Taobh istigh de péire, a chruthú dúinn `NotZero` nach bhfuil discriminant bailí.
    /// // Tá an iompar neamhshainithe.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SÁBHÁILTEACHT: Pointí `u.as_mut_ptr()` leis an gcuimhne leithdháilte.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Socraíonn sé luach an `MaybeUninit<T>`.
    /// Overwrites seo aon luach roimhe seo gan dropping air, mar sin a bheith cúramach gan a úsáid faoi dhó mura mian leat a skip ag rith ar an destructor.
    ///
    /// Mar áis duit, tugann sé seo tagairt inathraithe freisin d`ábhar `self` (atá tosaithe go sábháilte anois).
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SÁBHÁILTEACHT: initialized muid ach an luach.
        unsafe { self.assume_init_mut() }
    }

    /// Faigheann pointeoir ar an luach atá ann.
    /// Is Léitheoireachta ón pointeoir nó ag casadh sé isteach tagairt iompar undefined ach amháin má tá an `MaybeUninit<T>` initialized.
    /// Scríobh chuig gcuimhne go bhfuil an pointeoir pointí (non-transitively) chun iompar undefined (ach amháin taobh istigh `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// úsáid i gceart an modh seo:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Cruthaigh tagairt isteach sa `MaybeUninit<T>`.Tá sé seo ceart go leor mar gheall gur thosaíomar é.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// * * Úsáid mhícheart ar an modh seo:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Tá tagairt cruthaithe againn do vector neamhbheartaithe!Is iompar neamhshainithe é seo.⚠️
    /// ```
    ///
    /// (Fógra nach bhfuil na rialacha ar fud tagairtí sonraí uninitialized chun críche go fóill, ach go dtí go bhfuil siad, tá sé inmholta chun iad a sheachaint.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` agus tá `ManuallyDrop` araon `repr(transparent)` ionas gur féidir linn a chaith an pointeoir.
        self as *const _ as *const T
    }

    /// Faigheann pointeoir mutable don luach atá.
    /// Is Léitheoireachta ón pointeoir nó ag casadh sé isteach tagairt iompar undefined ach amháin má tá an `MaybeUninit<T>` initialized.
    ///
    /// # Examples
    ///
    /// úsáid i gceart an modh seo:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Cruthaigh tagairt isteach sa `MaybeUninit<Vec<u32>>`.
    /// // Tá sé seo ceart go leor mar gheall gur thosaíomar é.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// * * Úsáid mhícheart ar an modh seo:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Tá tagairt cruthaithe againn do vector neamhbheartaithe!Is iompar neamhshainithe é seo.⚠️
    /// ```
    ///
    /// (Fógra nach bhfuil na rialacha ar fud tagairtí sonraí uninitialized chun críche go fóill, ach go dtí go bhfuil siad, tá sé inmholta chun iad a sheachaint.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` agus tá `ManuallyDrop` araon `repr(transparent)` ionas gur féidir linn a chaith an pointeoir.
        self as *mut _ as *mut T
    }

    /// Sleachta an luach ón gcoimeádán `MaybeUninit<T>`.Tá sé seo slí iontach chun a chinntiú go mbeidh na sonraí a fháil thit, toisc go bhfuil an `T` mar thoradh air faoi réir láimhseáil titim is gnách.
    ///
    /// # Safety
    ///
    /// Is faoin té atá ag glaoch a ráthú go bhfuil an `MaybeUninit<T>` i riocht tosaigh i ndáiríre.Má ghlaotar air seo nuair nach bhfuil an t-ábhar tosaithe go hiomlán fós is cúis le hiompar neamhshainithe láithreach.
    /// Tá tuilleadh faisnéise sa [type-level documentation][inv] faoin invariant tosaigh seo.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Ar a bharr sin, cuimhnigh go bhfuil an chuid is mó cineálacha invariants breise thar á meas ach initialized ag an leibhéal cineál.
    /// Mar shampla, tá [`Vec<T>`] 1`-initialized mheas initialized (faoi chur chun feidhme atá ann faoi láthair ní athraíonn sé seo ionann ráthaíocht cobhsaí) toisc go bhfuil an ceanglas ach a fhios ag an Tiomsaitheoir mar gheall air go gcaithfidh an pointeoir sonraí a bheith neamh-null.
    ///
    /// Ag cruthú den sórt sin a `Vec<T>` Ní faoi deara *iompar undefined láithreach*, ach beidh faoi deara iompar undefined leis an chuid is mó oibríochtaí sábháilte (lena n-áirítear dropping é).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// úsáid i gceart an modh seo:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// * * Úsáid mhícheart ar an modh seo:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` Ní raibh initialized go fóill, agus mar sin an líne dheireanach ba chúis iompar neamhshainithe.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch a ráthú go bhfuil `self` tosaithe.
        // Ciallaíonn sé seo freisin go gcaithfidh `self` a bheith ina leagan `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Léann an luach ón gcoimeádán `MaybeUninit<T>`.Tá an `T` mar thoradh air faoi réir láimhseáil titim is gnách.
    ///
    /// Aon uair is féidir, is fearr a bhaint as [`assume_init`] ina ionad sin, a cosc dúbláil ábhar na `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Is faoin té atá ag glaoch ar an a ráthú go bhfuil an `MaybeUninit<T>` i ndáiríre i riocht initialized.Ag glaoch ar seo nuair nach bhfuil an t-ábhar fós initialized go hiomlán cúiseanna iompraíochta neamhshainithe.
    /// Tá tuilleadh faisnéise sa [type-level documentation][inv] faoin invariant tosaigh seo.
    ///
    /// Thairis sin, fágann sé seo cóip de na sonraí céanna taobh thiar den `MaybeUninit<T>`.
    /// Nuair a bheidh ag baint úsáide as cóipeanna iolraí de na sonraí (trí ghlaoch `assume_init_read` amanna éagsúla, nó an chéad glaoch `assume_init_read` agus ansin [`assume_init`]), tá sé d'fhreagracht a chinntiú go bhféadfar na sonraí a dhúbailt go deimhin.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// úsáid i gceart an modh seo:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` is `Copy` é, mar sin b`fhéidir go léifidh muid arís agus arís eile.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Tá sé ceart go leor luach `None` a dhúbailt, mar sin b`fhéidir go léifidh muid arís agus arís eile.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// * * Úsáid mhícheart ar an modh seo:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Chruthaíomar anois dhá chóip den vector céanna, rud a d`fhág go raibh ⚠️ saor ó dhúbailte nuair a scaoiltear an bheirt acu!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch a ráthú go bhfuil `self` tosaithe.
        // Tá léamh ó `self.as_ptr()` sábháilte ós rud é gur cheart `self` a thosú.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Drops an luach atá ar bun.
    ///
    /// Má tá úinéireacht agat ar an `MaybeUninit`, is féidir leat [`assume_init`] a úsáid ina ionad.
    ///
    /// # Safety
    ///
    /// Is faoin té atá ag glaoch ar an a ráthú go bhfuil an `MaybeUninit<T>` i ndáiríre i riocht initialized.Ag glaoch ar seo nuair nach bhfuil an t-ábhar fós initialized go hiomlán cúiseanna iompraíochta neamhshainithe.
    ///
    /// Ar a bharr sin, ní mór gach ionradh breise den chineál `T` a shásamh, toisc go bhféadfadh cur chun feidhme `Drop` `T` (nó a chomhaltaí) brath air seo.
    /// Mar shampla, tá [`Vec<T>`] 1`-initialized mheas initialized (faoi chur chun feidhme atá ann faoi láthair ní athraíonn sé seo ionann ráthaíocht cobhsaí) toisc go bhfuil an ceanglas ach a fhios ag an Tiomsaitheoir mar gheall air go gcaithfidh an pointeoir sonraí a bheith neamh-null.
    ///
    /// Beidh dropping sórt `Vec<T>` chur faoi deara, áfach, iompar neamhshainithe.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SÁBHÁILTEACHT: an ráthaíocht mór té atá ag glaoch go `self` initialized agus
        // sásaíonn gach ionradh `T`.
        // Tá sé sábháilte an luach a chur i bhfeidhm más amhlaidh.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Faigheann tagairt roinnte don luach atá.
    ///
    /// aisiúil é seo nuair is mian linn a rochtain a fháil ar `MaybeUninit` atá initialized ach nach bhfuil úinéireacht na `MaybeUninit` (cosc ar úsáid `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Ag glaoch ar seo nuair nach bhfuil an t-ábhar fós initialized go hiomlán cúiseanna iompraíochta undefined: tá sé de dhualgas ar an té atá ag glaoch a ráthaíocht a thabhairt go bhfuil an `MaybeUninit<T>` i ndáiríre i riocht initialized.
    ///
    ///
    /// # Examples
    ///
    /// ### úsáid i gceart an modh seo:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Cuir tús le `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Anois go bhfuil ár n-`MaybeUninit<_>` eol é a thúsú, tá sé ceart go leor chun tagairt roinnte a chruthú dó:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SÁBHÁILTEACHT: Cuireadh tús le `x`.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### Úsáid mhícheart * an mhodha seo:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Tá tagairt cruthaithe againn do vector neamhbheartaithe!Is iompar neamhshainithe é seo.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Thúsú an `MaybeUninit` ag baint úsáide as `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Tagairt do `Cell<bool>` uninitialized: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch a ráthú go bhfuil `self` tosaithe.
        // Ciallaíonn sé seo freisin go gcaithfidh `self` a bheith ina leagan `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Faigheann tagairt (unique) mutable don luach atá.
    ///
    /// aisiúil é seo nuair is mian linn a rochtain a fháil ar `MaybeUninit` atá initialized ach nach bhfuil úinéireacht na `MaybeUninit` (cosc ar úsáid `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Ag glaoch ar seo nuair nach bhfuil an t-ábhar fós initialized go hiomlán cúiseanna iompraíochta undefined: tá sé de dhualgas ar an té atá ag glaoch a ráthaíocht a thabhairt go bhfuil an `MaybeUninit<T>` i ndáiríre i riocht initialized.
    /// Mar shampla, ní féidir `.assume_init_mut()` a úsáid chun thúsú le `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### úsáid i gceart an modh seo:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Initializes *go léir* na bytes an mhaoláin ionchuir.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Túsaigh `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Anois tá a fhios againn go bhfuil `buf` tosaithe, ionas go bhféadfaimis `.assume_init()` a dhéanamh air.
    /// // Féin, d'fhéadfadh úsáid a bhaint as `.assume_init()` spreagadh `memcpy` de na 2,048 bytes.
    /// // Go dhearbhú go bhfuil ár n-maoláin túsaithe i gan chóipeáil air, ní mór dúinn a uasghrádú an `&mut MaybeUninit<[u8; 2048]>` le `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // SÁBHÁILTEACHT: `buf` Tá initialized.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Anois is féidir linn `buf` a úsáid mar ghnáth-shlisne:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### Úsáid mhícheart * an mhodha seo:
    ///
    /// Ní féidir leat úsáid a bhaint as `.assume_init_mut()` a thúsú le luach:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Tá tagairt (mutable) cruthaithe againn do `bool` neamhbheartaithe!
    ///     // Tá an iompar neamhshainithe.⚠️
    /// }
    /// ```
    ///
    /// Mar shampla, ní féidir leat [`Read`] isteach maolán uninitialized:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) tagairt do chuimhne neamhbheartaithe!
    ///                             // Tá an iompar neamhshainithe.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Ní féidir leat rochtain dhíreach allamuigh a úsáid ach chun tús a chur de réir a chéile de réir a chéile:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) tagairt do chuimhne neamhbheartaithe!
    ///                  // Tá an iompar neamhshainithe.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) tagairt do chuimhne neamhbheartaithe!
    ///                  // Tá an iompar neamhshainithe.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Táimid ag brath faoi láthair ar an méid sin thuas a bheith mícheart, is é sin, ní mór dúinn tagairtí sonraí uninitialized (eg, i `libcore/fmt/float.rs`).
    // Ba cheart dúinn cinneadh críochnaitheach faoi na rialacha roimh chobhsú.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch a ráthú go bhfuil `self` tosaithe.
        // Ciallaíonn sé seo freisin go gcaithfidh `self` a bheith ina leagan `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Sleachta na luachanna ó sraith de coimeádáin `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Is faoin té atá ag glaoch a ráthú go bhfuil gach gné den eagar i riocht tosaigh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SÁBHÁILTEACHT: Anois sábháilte agus muid ag cur tús le gach gné
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Ráthaíonn té atá ag glaoch go bhfuil gach dúil na eagar initialized
        // * `MaybeUninit<T>` agus ráthaítear go mbeidh an leagan amach céanna ag T
        // * Ní thiteann MayUnint, mar sin níl aon saortha dúbailte Agus dá bhrí sin tá an tiontú sábháilte
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Má ghlactar leis go ndéantar na heilimintí go léir a thúsú, faigh slisne dóibh.
    ///
    /// # Safety
    ///
    /// Is faoin té atá ag glaoch a ráthú go bhfuil na heilimintí `MaybeUninit<T>` i riocht tosaigh i ndáiríre.
    ///
    /// Má ghlaotar air seo nuair nach bhfuil an t-ábhar tosaithe go hiomlán fós is cúis le hiompar neamhshainithe.
    ///
    /// Féach [`assume_init_ref`] le haghaidh tuilleadh sonraí agus samplaí.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SÁBHÁILTEACHT: tá sé sábháilte slisne a chaitheamh ar `*const [T]` ós rud é go ráthaíonn an té atá ag glaoch go bhfuil
        // `slice` tosaítear é, agus ráthaítear go mbeidh an leagan amach céanna ag XMebeUninit` le `T`.
        // Is é an pointeoir a fhaightear bailí toisc tagraíonn sé do chuimhne ar úinéireacht ag `slice` a bhfuil tagairt agus dá bhrí sin ráthaithe a bheith bailí ar feadh léann.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Má ghlactar leis go ndéantar na heilimintí go léir a thúsú, faigh slice inathraithe dóibh.
    ///
    /// # Safety
    ///
    /// Is faoin té atá ag glaoch a ráthú go bhfuil na heilimintí `MaybeUninit<T>` i riocht tosaigh i ndáiríre.
    ///
    /// Má ghlaotar air seo nuair nach bhfuil an t-ábhar tosaithe go hiomlán fós is cúis le hiompar neamhshainithe.
    ///
    /// Féach [`assume_init_mut`] le haghaidh tuilleadh sonraí agus samplaí.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SÁBHÁILTEACHT: cosúil le nótaí sábháilteachta do `slice_get_ref`, ach tá a
        // tagairt inathraithe a ráthaítear freisin a bheith bailí le haghaidh scríbhinní.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Faigheann pointeoir chuig an chéad ghné den eagar.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Faigheann pointeoir mutable leis an chéad eilimint an eagar.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Cóipeanna na heilimintí ó `src` go `this`, ag filleadh tagairt mutable leis an ábhar initalized anois de `this`.
    ///
    /// Mura gcuireann `T` `Copy` i bhfeidhm, úsáid [`write_slice_cloned`]
    ///
    /// Tá sé seo cosúil leis [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Beidh an fheidhm panic má tá an dá slisní faid éagsúla.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SÁBHÁILTEACHT: ní mór dúinn chóipeáil díreach na gnéithe uile de Len sa acmhainn bhreise
    /// // Is iad an chéad chuid src.len() den vec bailí anois.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SÁBHÁILTEACHT: &[T] agus&[MaybeUninit<T>] Den leagan amach céanna
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SÁBHÁILTEACHT: Cóipeáladh eilimintí bailí díreach isteach i `this` agus mar sin tá sé beo
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Clónáil na heilimintí ó `src` go `this`, ag filleadh tagairt dhochloíte d`ábhar `this` atá anois neamhbheo.
    /// Ní thitfear aon eilimintí a bhí cheana féin beo.
    ///
    /// Má chuireann `T` `Copy` i bhfeidhm, úsáid [`write_slice`]
    ///
    /// Tá sé seo cosúil le [`slice::clone_from_slice`] ach ní scaoilfidh sé na heilimintí atá ann cheana.
    ///
    /// # Panics
    ///
    /// Beidh panic ag an bhfeidhm seo má tá faid éagsúla ag an dá shlisne, nó má chuirtear `Clone` panics i bhfeidhm.
    ///
    /// Má tá panic ann, scaoilfear na heilimintí atá clónáilte cheana féin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SÁBHÁILTEACHT: táimid díreach tar éis gach gné de len a chlónáil isteach sa toilleadh spártha
    /// // Is iad an chéad chuid src.len() den vec bailí anois.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // murab ionann agus copy_from_slice ní ghlaonn sé seo clone_from_slice ar an slice seo toisc nach gcuireann `MaybeUninit<T: Clone>` Clón i bhfeidhm.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SÁBHÁILTEACHT: ní bheidh ach rudaí tosaigh sa slice amh seo
                // sin an fáth, tá sé cead a scaoil sé.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Caithfimid iad a sleamhnú go sainráite ar an fhad céanna
        // do bounds sheiceáil chuí chun bheith elided, agus beidh an t-optimizer ghiniúint memcpy do chásanna simplí (mar shampla T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // tá garda ag teastáil a d`fhéadfadh b/c panic tarlú le linn clón
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SÁBHÁILTEACHT: eilimintí bailí a bheith scríofa go díreach `this` isteach mar sin tá sé initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}