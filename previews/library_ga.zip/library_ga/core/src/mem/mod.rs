//! Feidhmeanna bunúsacha chun déileáil le cuimhne.
//!
//! Tá feidhmeanna sa mhodúl seo chun méid agus ailíniú cineálacha a cheistiú, cuimhne a thosú agus a ionramháil.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Glacann sé úinéireacht agus "forgets" faoin luach **gan a scriosóir a rith**.
///
/// Aon acmhainní bhainistíonn an luach, mar shampla cuimhne gcarn nó láimhseáil comhad a bheidh, linger go deo i riocht unreachable.Mar sin féin, ní chuireann sé ráthaíocht go mbeidh leideanna a ghabhann leis an chuimhne de bheith bailí.
///
/// * Más mian leat cuimhne a sceitheadh, féach [`Box::leak`].
/// * Más mian leat a fháil pointeoir amh leis an chuimhne, féach [`Box::into_raw`].
/// * Más mian leat luach a dhiúscairt i gceart, ag rith a scriosóra, féach [`mem::drop`].
///
/// # Safety
///
/// `forget` nach bhfuil marcáilte mar `unsafe`, toisc nach n-áirítear ráthaíochtaí sábháilteachta Rust ráthaíocht go rithfidh scriosóirí i gcónaí.
/// Mar shampla, is féidir le clár a chruthú timthriall tagartha ag baint úsáide as [`Rc`][rc], nó cuir glaoch ar [`process::exit`][exit] a scoir gan scriostóirí rith.
/// Dá bhrí sin, ní athraíonn ráthaíochtaí sábháilteachta Rust go bunúsach má cheadaítear `mem::forget` ó chód sábháilte.
///
/// É sin ráite, is iondúil nach inmhianaithe acmhainní a sceitheadh mar chuimhne nó rudaí I/O.
/// Tagann an gá ar bun i roinnt cásanna a úsáid speisialaithe do ITF nó cód neamhshábháilte, ach fiú amháin ansin, tá [`ManuallyDrop`] go tipiciúil.
///
/// Toisc go gceadaítear dearmad a dhéanamh ar luach, caithfidh aon chód `unsafe` a scríobhann tú an fhéidearthacht seo a cheadú.Ní féidir leat luach a thabhairt ar ais agus a bheith ag súil go rithfidh an té atá ag glaoch scriosóir an luacha.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Is é an úsáid shábháilte Canonical de `mem::forget` a dhéanamh dul timpeall ar luach ar destructor gcur chun feidhme ag an trait `Drop`.Mar shampla, beidh sé seo sceitheadh le `File`, ie
/// éileamh ar ais ar an spás a ghlac an athróg ach ní dhúnadh ar an acmhainn córas féin:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Tá sé seo úsáideach nuair a aistríodh úinéireacht na hacmhainne bunúsaí roimhe seo go cód lasmuigh de Rust, mar shampla tríd an tuairiscitheoir comhaid amh a tharchur chuig cód C.
///
/// # Gaol le `ManuallyDrop`
///
/// Cé gur féidir `mem::forget` a úsáid freisin chun aistriú Cuimhne * * úinéireacht, tá sin a dhéanamh earráid-seans maith.
/// [`ManuallyDrop`] ba chóir a úsáid ina ionad.Smaoinigh, mar shampla, ar an gcód seo:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Tóg `String` ag úsáid ábhar `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // sceitheadh `v` toisc go bhfuil a chuimhne á bhainistiú anois ag `s`
/// mem::forget(v);  // ERROR, tá v neamhbhailí agus ní féidir a chur ar aghaidh le feidhm
/// assert_eq!(s, "Az");
/// // `s` tite go hintuigthe agus a chuimhne intuigthe.
/// ```
///
/// Tá dhá shaincheist leis an sampla thuas:
///
/// * Dá cód níos mó a leanas idir an tógáil `String` agus an agairt `mem::forget()`, a panic laistigh mbeadh sé ina chúis le haghaidh saor in aisce dúbailte toisc go bhfuil an chuimhne chéanna láimhseáil ag `v` agus `s` araon.
/// * Tar éis glaoch ar `v.as_mut_ptr()` agus úinéireacht na sonraí a tharchur chuig `s`, tá luach `v` neamhbhailí.
/// Fiú nuair a bhogtar luach díreach chuig `mem::forget` (nach ndéanfaidh iniúchadh air), bíonn ceanglais dhiana ag roinnt cineálacha ar a luachanna a fhágann go bhfuil siad neamhbhailí agus iad ag crochadh nó nach bhfuil siad faoi úinéireacht a thuilleadh.
/// Is éard atá i luachanna neamhbhailí a úsáid ar bhealach ar bith, lena n-áirítear iad a chur ar aghaidh chuig feidhmeanna nó iad a thabhairt ar ais, iompar neamhshainithe agus féadfaidh sé na toimhdí a dhéanann an tiomsaitheoir a bhriseadh.
///
/// Seachnaíonn aistriú go `ManuallyDrop` an dá eagrán:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Sula ndéanaimid `v` a dhíchumadh ina chodanna amha, déan cinnte nach dtitfidh sé!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Anois disassemble `v`.Na hoibríochtaí féidir panic, ionas gur féidir a bheith ann sceitheadh.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Ar deireadh, a thógáil `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` tite go hintuigthe agus a chuimhne intuigthe.
/// ```
///
/// `ManuallyDrop` cuireann sé cosc láidir ar shaor-dhúbailte toisc go ndíchumasaímid an scriosóir `v` sula ndéanann muid aon rud eile.
/// `mem::forget()` ní cheadaíonn sé seo toisc go n-úsáideann sé a argóint, ag cur iallach orainn glaoch uirthi ach amháin tar éis aon rud a theastaíonn uainn a bhaint as `v`.
/// Fiú dá dtabharfaí panic isteach idir `ManuallyDrop` a thógáil agus an tsreang a thógáil (rud nach féidir a tharlú sa chód mar a thaispeántar), sceitheadh a bheadh ann agus ní saor ó dhúbailt.
/// Is é sin le rá, creimíonn `ManuallyDrop` ar thaobh an sceitheadh in ionad dul amú ar thaobh an titim (dúbailte-).
///
/// Chomh maith leis sin, cuireann `ManuallyDrop` cosc orainn "touch" `v` a dhéanamh tar éis dúinn an úinéireacht a aistriú go `s`-seachnaítear an chéim dheiridh de idirghníomhú le `v` chun é a dhiúscairt gan a scriosóir a rith.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Cosúil le [`forget`], ach glacann sé le luachanna neamhshraithe freisin.
///
/// Níl sa fheidhm seo ach shim a bheartaítear a bhaint nuair a chobhsaítear an ghné `unsized_locals`.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Tuairisceáin an méid de chineál ar bytes.
///
/// Go sonrach, is é seo an fritháireamh i mbeart idir eilimintí comhleanúnacha in eagar leis an gcineál earra sin lena n-áirítear stuáil ailínithe.
///
/// Mar sin, maidir le haon chineál `T` agus fad `n`, tá méid `n * size_of::<T>()` ag `[T; n]`.
///
/// Go ginearálta, níl méid an chineáil seasmhach ar fud na dtiomsú, ach tá cineálacha ar leith cosúil le primitive.
///
/// Tugann an tábla seo a leanas an méid le haghaidh primitive.
///
/// Cineál |size_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Ina theannta sin, tá an méid céanna ag `usize` agus `isize`.
///
/// Tá an méid céanna ag na cineálacha `*const T`, `&T`, `Box<T>`, `Option<&T>`, agus `Option<Box<T>>`.
/// Má tá `T` Sized, tá an méid céanna le `usize` ag na cineálacha sin go léir.
///
/// Ní athraíonn inathraitheacht pointeora a mhéid.Dá bhrí sin, tá an méid céanna ag `&T` agus `&mut T`.
/// Mar an gcéanna le haghaidh `*const T` agus `* mut T`.
///
/// # Méid na míreanna `#[repr(C)]`
///
/// Tá leagan amach sainithe ag an ionadaíocht `C` d`earraí.
/// Leis an leagan amach seo, tá méid na n-earraí seasmhach freisin fad is atá méid cobhsaí ag gach réimse.
///
/// ## Méid na Struchtúr
///
/// Maidir le `structs`, socraítear an méid leis an algartam seo a leanas.
///
/// I gcás gach réimse sa déanmhas a ordaítear le hordú dearbhaithe:
///
/// 1. Cuir méid na páirce leis.
/// 2. Déan an méid reatha a shlánú go dtí an iolraí is gaire de [alignment] an chéad réimse eile.
///
/// Ar deireadh, thart ar an méid de na struct don iolraí is gaire de chuid [alignment].
/// Is gnách gurb é ailíniú an déanmhais an t-ailíniú is mó dá réimsí uile;is féidir é seo a athrú trí `repr(align(N))` a úsáid.
///
/// Murab ionann agus `C`, ní náid structs meánmhéide chothromú suas go dtí beart amháin i méid.
///
/// ## Méid Enums
///
/// Tá an méid céanna ag einsímí nach n-iompraíonn aon sonraí seachas an t-idirdhealaitheoir le enums C ar an ardán a dtiomsaítear dóibh é.
///
/// ## Méid na gComhar
///
/// Is é méid aontais méid a réimse is mó.
///
/// Murab ionann agus `C`, ní dhéantar ceardchumainn nialasacha a shlánú suas le beart amháin i méid.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Roinnt primitive
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // roinnt arrays
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Comhionannas méid pointeora
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Ag baint úsáide as `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Is é 1 méid an chéad réimse, mar sin cuir 1 leis an méid.Is é an méid 1.
/// // Is é an ailíniú an dara réimse 2, mar sin cuir 1 leis an méid do stuáil.Is é 2 an méid.
/// // Is é 2 mhéid an dara réimse, mar sin cuir 2 leis an méid.Is Size 4.
/// // Is é an ailíniú an tríú réimse 1, mar sin cuir 0 le méid do stuáil.Is é 4 an méid.
/// // Is é 1 méid an tríú réimse, mar sin cuir 1 leis an méid.Is é 5 an méid.
/// // Ar deireadh, is é an t-ailíniú an struct 2 (toisc go bhfuil an t-ailíniú mó i measc na réimsí 2), agus mar sin cuir 1 leis an méid do stuáil.
/// // Is é 6 an méid.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Leanann struchtúir dhúbailte na rialacha céanna.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Tabhair faoi deara gur féidir leis athordú na réimsí níos ísle ar an méid.
/// // Is féidir linn an dá bheart stuála a bhaint trí `third` a chur roimh `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Is é méid an Aontais an méid de na réimse is mó.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Filleann sé méid an luacha pointeáilte go bearta.
///
/// De ghnáth bíonn sé seo mar an gcéanna le `size_of::<T>()`.
/// Mar sin féin, nuair nach bhfuil *méid statach ar eolas ag `T`*, m.sh. slice [`[T]`][slice] nó [trait object], ansin is féidir `size_of_val` a úsáid chun an méid atá ar eolas go dinimiciúil a fháil.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SÁBHÁILTEACHT: Is tagairt é `val`, mar sin is pointeoir amh bailí é
    unsafe { intrinsics::size_of_val(val) }
}

/// Filleann sé méid an luacha pointeáilte go bearta.
///
/// De ghnáth bíonn sé seo mar an gcéanna le `size_of::<T>()`.Mar sin féin, nuair nach bhfuil *méid ar a dtugtar go statach ag `T`*, m.sh. slice [`[T]`][slice] nó [trait object], ansin is féidir `size_of_val_raw` a úsáid chun an méid atá ar eolas go dinimiciúil a fháil.
///
/// # Safety
///
/// Ní féidir an fheidhm seo a ghlaoch ach amháin má tá na coinníollacha seo a leanas ann:
///
/// - Má tá `T` `Sized`, tá an fheidhm seo sábháilte chun glaoch i gcónaí.
/// - Má tá an eireaball unsized na `T`:
///     - [slice], ansin caithfidh fad an eireaball slice a bheith ina shlánuimhir tosaigh, agus caithfidh méid an *luach iomláin*(fad eireaball dinimiciúil + réimír meánmhéide) a bheith oiriúnach i `isize`.
///     - [trait object], ansin caithfidh an chuid inmharthana den phointeoir pointeáil a dhéanamh ar inbhailí bailí a fuair comhéigean neamhshábháilte, agus caithfidh méid an *luach iomláin*(fad eireaball dinimiciúil + réimír de mhéid statach) a bheith oiriúnach i `isize`.
///
///     - (unstable) [extern type], ansin tá an fheidhm seo sábháilte a ghlaoch i gcónaí, ach féadfaidh sí panic nó an luach mícheart a thabhairt ar ais ar bhealach eile, mar nach eol leagan amach an chineáil sheachtraigh.
///     Seo an t-iompar céanna le [`size_of_val`] maidir le tagairt do chineál le heireaball den chineál seachtrach.
///     - a mhalairt, tá sé coimeádach nach bhfuil cead chun glaoch fheidhm seo.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SÁBHÁILTEACHT: ní mór don té atá ag glaoch a chur ar fáil ar pointeoir amh bailí
    unsafe { intrinsics::size_of_val(val) }
}

/// Filleann sé an t-ailíniú riachtanach de chineál [ABI].
///
/// Ní mór do gach tagairt do luach den chineál `T` ina iolraí ar an uimhir.
///
/// Is é seo an ailíniú a úsáidtear le haghaidh réimsí struct.D`fhéadfadh sé a bheith níos lú ná an t-ailíniú roghnaithe.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Filleann sé an t-ailíniú íosta iarrtha [ABI] de chineál an luacha a dtugann `val` aird air.
///
/// Ní mór do gach tagairt do luach den chineál `T` ina iolraí ar an uimhir.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SÁBHÁILTEACHT: Is Val is tagairt í, agus mar sin tá sé ina pointeoir amh bailí
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Filleann sé an t-ailíniú riachtanach de chineál [ABI].
///
/// Ní mór do gach tagairt do luach den chineál `T` ina iolraí ar an uimhir.
///
/// Is é seo an ailíniú a úsáidtear le haghaidh réimsí struct.D`fhéadfadh sé a bheith níos lú ná an t-ailíniú roghnaithe.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Filleann sé an t-ailíniú íosta iarrtha [ABI] de chineál an luacha a dtugann `val` aird air.
///
/// Ní mór do gach tagairt do luach den chineál `T` ina iolraí ar an uimhir.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SÁBHÁILTEACHT: Is Val is tagairt í, agus mar sin tá sé ina pointeoir amh bailí
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Filleann sé an t-ailíniú íosta iarrtha [ABI] de chineál an luacha a dtugann `val` aird air.
///
/// Ní mór do gach tagairt do luach den chineál `T` ina iolraí ar an uimhir.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Ní féidir an fheidhm seo a ghlaoch ach amháin má tá na coinníollacha seo a leanas ann:
///
/// - Má tá `T` `Sized`, tá an fheidhm seo sábháilte chun glaoch i gcónaí.
/// - Má tá an eireaball unsized na `T`:
///     - [slice], ansin caithfidh fad an eireaball slice a bheith ina shlánuimhir tosaigh, agus caithfidh méid an *luach iomláin*(fad eireaball dinimiciúil + réimír meánmhéide) a bheith oiriúnach i `isize`.
///     - [trait object], ansin caithfidh an chuid inmharthana den phointeoir pointeáil a dhéanamh ar inbhailí bailí a fuair comhéigean neamhshábháilte, agus caithfidh méid an *luach iomláin*(fad eireaball dinimiciúil + réimír de mhéid statach) a bheith oiriúnach i `isize`.
///
///     - (unstable) [extern type], ansin tá an fheidhm seo sábháilte a ghlaoch i gcónaí, ach féadfaidh sí panic nó an luach mícheart a thabhairt ar ais ar bhealach eile, mar nach eol leagan amach an chineáil sheachtraigh.
///     Seo an t-iompar céanna le [`align_of_val`] maidir le tagairt do chineál le heireaball de chineál seachtrach.
///     - a mhalairt, tá sé coimeádach nach bhfuil cead chun glaoch fheidhm seo.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SÁBHÁILTEACHT: ní mór don té atá ag glaoch a chur ar fáil ar pointeoir amh bailí
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Tuairisceáin `true` más rud é luachanna chineál nithe `T` dropping.
///
/// Tá sé seo amháin ina leid leas iomlán a bhaint, agus a chur chun feidhme go coimeádach:
/// d'fhéadfadh sé ar ais `true` do chineálacha nach bhfuil gá i ndáiríre a thit.
/// Dá bhrí sin bheadh cur i bhfeidhm bailí na feidhme seo i gcónaí ag filleadh `true` i gcónaí.Mar sin féin má fhilleann an fheidhm seo `false` i ndáiríre, ansin is féidir leat a bheith cinnte nach bhfuil aon fo-éifeacht ag titim `T`.
///
/// Ba cheart go gcuirfeadh feidhmiú leibhéal íseal rudaí cosúil le bailiúcháin, a gcaithfidh a gcuid sonraí a ligean de láimh, an fheidhm seo a úsáid chun iarracht a dhéanamh a n-ábhar go léir a ligean anuas nuair a dhéantar iad a scriosadh.
///
/// Ní fhéadfadh sé seo a dhéanamh Tógann difríocht i scaoileadh (i gcás ina lúb nach bhfuil aon fo-iarsmaí atá bhrath go héasca agus caite amach) go minic Tógann, ach tá bua mór do dífhabhtaithe.
///
/// Tabhair faoi deara go ndéanann [`drop_in_place`] an seiceáil seo cheana féin, mar sin más féidir d`ualach oibre a laghdú go líon beag glaonna [`drop_in_place`], ní gá é seo a úsáid.
/// Tabhair faoi deara go háirithe gur féidir leat slice [`drop_in_place`] a dhéanamh, agus déanfaidh sé sin seiceáil riachtanais_drop amháin ar na luachanna go léir.
///
/// Dá bhrí sin níl ach `drop_in_place(&mut self[..])` ag cineálacha mar Vec gan `needs_drop` a úsáid go sainráite.
/// Ar an láimh eile, caithfidh cineálacha mar [`HashMap`] luachanna a ísliú ceann ag an am agus ba cheart dóibh an API seo a úsáid.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Seo sampla den chaoi a bhféadfadh bailiúchán úsáid a bhaint as `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // titim na sonraí
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Filleann sé luach an chineáil `T` arna léiriú ag an bpatrún uile-nialasach.
///
/// Ciallaíonn sé seo, mar shampla, nach gá go bhfuil an beart beartáin in `(u8, u16)` nialasach.
///
/// Níl aon ráthaíocht ann go léiríonn patrún beart uile-nialasach luach bailí de chineál éigin `T`.
/// Mar shampla, nach bhfuil an uile-náid beart-phatrún le luach bailí do chineálacha tagartha (`&T`, `&mut T`) agus feidhmeanna threo.
/// [undefined behavior][ub] a úsáid ar chineálacha den sórt sin is cúis le [undefined behavior][ub] láithreach toisc go measann [the Rust compiler assumes][inv] go bhfuil luach bailí in athróg i gcónaí.
///
///
/// Tá sé seo an éifeacht chéanna [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Bíonn sé úsáideach do FFI uaireanta, ach de ghnáth ba cheart é a sheachaint.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Úsáid cheart na feidhme seo: slánuimhir le nialas a thionscnamh.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// Úsáid mhícheart * na feidhme seo: tagairt a thosú le nialas.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Iompar neamhshainithe!
/// let _y: fn() = unsafe { mem::zeroed() }; // Agus arís!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch a ráthú go bhfuil luach uile-nialasach bailí do `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Seachróid gnáth seiceálacha cuimhne-initialization Rust trí ligean a tháirgeadh luach den chineál `T`, ag déanamh rud ar bith ar chor ar bith.
///
/// **Ní mholtar an fheidhm seo.** Úsáid [`MaybeUninit<T>`] ina ionad.
///
/// Is é an chúis deprecation nach féidir leis an fheidhm seo a úsáid go bunúsach i gceart: tá sé an éifeacht chéanna [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Mar a mhíníonn an [`assume_init` documentation][assume_init], [the Rust compiler assumes][inv] go bhfuil na luachanna túsaithe i gceart.
/// Mar thoradh air sin, ag glaoch m.sh.
/// `mem::uninitialized::<bool>()` is cúis le hiompar láithreach neamhshainithe chun `bool` a thabhairt ar ais nach cinnte gur `true` nó `false` é.
/// Tá cuimhne níos measa, fíor-dhílisithe cosúil leis an rud a chuirtear ar ais anseo speisialta sa mhéid is go bhfuil a fhios ag an tiomsaitheoir nach bhfuil luach seasta aige.
/// Seo a dhéanann undefined sé iompar a bheith acu sonraí uninitialized i athróg fiú má tá sin athróg cineál slánuimhir.
/// (Tabhair faoi deara nach bhfuil na rialacha maidir le slánuimhreacha neamhbheartaithe tugtha chun críche go fóill, ach go dtí go mbeidh siad, moltar iad a sheachaint.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SÁBHÁILTEACHT: ní mór don té atá ag glaoch a ráthú go bhfuil luach aonadach bailí do `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Babhtáil na luachanna ag dhá shuíomh inathraithe, gan ceachtar acu a dhí-ainmniú.
///
/// * Más mian leat babhtáil le luach réamhshocraithe nó caocha, féach [`take`].
/// * Más mian leat chun babhtáil le luach rith, ag filleadh ar an luach d'aois, féach [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SÁBHÁILTEACHT: cruthaíodh na leideanna amha ó thagairtí sábháilte inathraithe a shásaíonn na
    // srianta a bheith ar `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Cuirtear luach réamhshocraithe `T` in ionad `dest`, ag filleadh an luach `dest` roimhe seo.
///
/// * Más mian leat a chur in ionad na luachanna de dhá athróg, féach [`swap`].
/// * Más mian leat luach rite a chur ina ionad in ionad an luach réamhshocraithe, féach [`replace`].
///
/// # Examples
///
/// Sampla simplí:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` ceadaíonn sé úinéireacht a ghlacadh ar réimse struchtúrtha trí luach "empty" a chur ina ionad.
/// Gan `take` féidir leat a rith i saincheisteanna mar seo:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Tabhair faoi deara nach gá go gcuireann `T` [`Clone`] i bhfeidhm, mar sin ní féidir leis fiú `self.buf` a chlónáil agus a athshocrú.
/// Ach is féidir `take` a úsáid chun bunluach `self.buf` a dhealú ó `self`, rud a fhágann gur féidir é a thabhairt ar ais:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Bog `src` isteach sa `dest` tagartha, ag filleadh an luach `dest` roimhe seo.
///
/// Ní thittear ceachtar luach.
///
/// * Más mian leat a chur in ionad na luachanna de dhá athróg, féach [`swap`].
/// * Más mian leat luach réamhshocraithe a chur ina ionad, féach [`take`].
///
/// # Examples
///
/// Sampla simplí:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` Ceadaíonn tomhaltas de réimse struct trí in áit é le luach eile.
/// Gan `replace` is féidir leat saincheisteanna mar seo a rith:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Tabhair faoi deara nach gá go gcuireann `T` [`Clone`] i bhfeidhm, mar sin ní féidir linn clónáil a dhéanamh ar `self.buf[i]` fiú chun an t-aistriú a sheachaint.
/// Ach is féidir `replace` a úsáid chun disassociate an luach bunaidh ag an innéacs ó `self`, rud a ligeann sé a chur ar ais:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SÁBHÁILTEACHT: Léimid ó `dest` ach scríobhaimid `src` isteach go díreach ina dhiaidh sin,
    // den sórt sin nach bhfuil an luach d'aois dhúbailt.
    // Ní scaoiltear aon rud agus ní féidir aon rud anseo panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Diúscairt luach.
///
/// Déanann sé é sin trí chur chun feidhme [`Drop`][drop] na hargóna a ghlaoch.
///
/// dhéanann sé seo go héifeachtach rud ar bith do chineálacha a chuireann i bhfeidhm `Copy`, eg
/// integers.
/// Cóipeáiltear luachanna den sórt sin agus aistrítear _then_ isteach san fheidhm, mar sin maireann an luach tar éis an ghlao feidhme seo.
///
///
/// Níl draíocht ag baint leis an bhfeidhm seo;sainmhínítear go litriúil é mar
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Toisc go bhfuil `_x` bhog isteach sa fheidhm, tá sé thit go huathoibríoch os comhair na tuairisceáin feidhme.
///
/// [drop]: Drop
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // scaoil an vector go sainráite
/// ```
///
/// Ós rud é go forfheidhmiú [`RefCell`] na rialacha ar iasacht ag runtime, is féidir `drop` scaoileadh iasacht [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // éirí as an iasacht inmharthana ar an sliotán seo
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Níl aon tionchar ag `drop` ar shlánuimhreacha agus ar chineálacha eile a chuireann [`Copy`] i bhfeidhm.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // Tá cóip de `x` ar athraíodh a ionad agus thit
/// drop(y); // Tá cóip de `y` ar athraíodh a ionad agus thit
///
/// println!("x: {}, y: {}", x, y.0); // fós ar fáil
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Ateangaíonn `src` mar chineál `&U`, agus ansin léann `src` gan an luach atá ann a bhogadh.
///
/// Glacfaidh an fheidhm seo go neamhshábháilte go bhfuil an pointeoir `src` bailí do bhearta [`size_of::<U>`][size_of] trí `&T` a aistriú go `&U` agus ansin an `&U` a léamh (ach amháin go ndéantar é seo ar bhealach atá ceart fiú nuair a dhéanann `&U` riachtanais ailínithe níos déine ná `&T`).
/// Beidh sé freisin a chruthú unsafely cóip den luach atá seachas é a bhogadh amach as an `src`.
///
/// Ní botún ama tiomsaithe é má tá méideanna difriúla ag `T` agus `U`, ach moltar go mór an fheidhm seo a agairt ach sa chás go bhfuil an méid céanna ag `T` agus `U`.Triggers an fheidhm [undefined behavior][ub] má tá `U` níos mó ná `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Cóipeáil na sonraí ó 'foo_array' agus déileálfar leo mar 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Mionathraigh na sonraí cóipeáilte
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Níor chóir an t-ábhar de 'foo_array' tar éis athrú
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Má tá riachtanas ailínithe níos airde ag U, ní fhéadfaidh src a bheith ailínithe go hoiriúnach.
    if align_of::<U>() > align_of::<T>() {
        // SÁBHÁILTEACHT: Is tagairt é `src` a ráthaítear a bheith bailí le haghaidh léamha.
        // Ní mór don ghlaoiteoir a ráthú go bhfuil an t-aistriú iarbhír sábháilte.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SÁBHÁILTEACHT: Is tagairt é `src` a ráthaítear a bheith bailí le haghaidh léamha.
        // Sheiceáil muid ach go raibh `src as *const U` ailínithe i gceart.
        // Ní mór don ghlaoiteoir a ráthú go bhfuil an t-aistriú iarbhír sábháilte.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Cineál teimhneach a léiríonn idirdhealaitheoir enum.
///
/// Féach ar an bhfeidhm [`discriminant`] sa mhodúl seo le haghaidh tuilleadh eolais.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Ní féidir na implementations trait a dhíorthú toisc nach bhfuil muid ag iarraidh ar aon bounds ar T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Filleann sé luach a shainaithníonn an leagan enum in `v` go uathúil.
///
/// Mura bhfuil `T` an Áirithe, ag iarraidh an fheidhm seo ní bheidh mar thoradh ar iompar undefined, ach tá an luach ar ais neamhshonraithe.
///
///
/// # Stability
///
/// Is féidir leis an discriminant de athraitheach Áirithe a athrú má thagann athrú ar an sainmhíniú Áirithe.
/// Ní athróidh idirdhealaitheoir de roinnt athraitheach idir tiomsúcháin leis an tiomsaitheoir céanna.
///
/// # Examples
///
/// Is féidir é seo a úsáid chun comparáid a dhéanamh idir einsímí a iompraíonn sonraí, agus neamhaird á déanamh ar na sonraí iarbhír:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Filleann sé líon na n-athróg sa chineál enum `T`.
///
/// Mura bhfuil `T` an Áirithe, ag iarraidh an fheidhm seo ní bheidh mar thoradh ar iompar undefined, ach tá an luach ar ais neamhshonraithe.
/// Mar an gcéanna, más enum é `T` le níos mó malairtí ná `usize::MAX` tá an luach toraidh neamhshonraithe.
/// Áireofar malairtí neamháitrithe.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}