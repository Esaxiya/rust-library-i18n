//! An `Clone` trait do chineálacha nach féidir a 'chóipeáil go hintuigthe'.
//!
//! I Rust, tá "implicitly copyable" i roinnt cineálacha simplí agus nuair a shannann tú iad nó má éiríonn leat iad mar argóintí, gheobhaidh an glacadóir cóip, rud a fhágfaidh go mbeidh an luach bunaidh i bhfeidhm.
//! Ní éilíonn leithdháileadh na gcineálacha seo cóipeáil agus níl bailchríochnaitheoirí orthu (ie, níl boscaí faoi úinéireacht iontu nó níl [`Drop`] á gcur i bhfeidhm acu), mar sin measann an tiomsaitheoir go bhfuil siad saor agus sábháilte a chóipeáil.
//!
//! Maidir le cineálacha eile ní mór cóipeanna a dhéanamh go sainráite, de réir an ghnáis a chur i bhfeidhm an trait [`Clone`] agus ag glaoch ar an modh [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Mar shampla úsáid Basic:
//!
//! ```
//! let s = String::new(); // Cuireann cineál teaghráin Clón i bhfeidhm
//! let copy = s.clone(); // ionas gur féidir linn a Clón é
//! ```
//!
//! Chun an Clón trait a chur i bhfeidhm go héasca, is féidir leat `#[derive(Clone)]` a úsáid freisin.Sampla:
//!
//! ```
//! #[derive(Clone)] // cuirimid an Clón trait le Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // agus anois is féidir linn a Clón é!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// A comhchoiteanna trait haghaidh an cumas a dhúbailt go sainráite rud.
///
/// Éagsúil ó [`Copy`] sa mhéid is go [`Copy`] bhfuil intuigthe agus thar a bheith saor, cé go bhfuil `Clone` follasach i gcónaí agus féadfaidh sé nó nach féidir a bheith costasach.
/// Chun na saintréithe i bhfeidhm, ní Rust ligfidh tú chun reimplement [`Copy`], ach is féidir leat reimplement `Clone` agus a reáchtáil cód treallach.
///
/// Ós rud é go bhfuil `Clone` níos ginearálta ná [`Copy`], is féidir leat rud ar bith a dhéanamh go huathoibríoch [`Copy`] a bheith `Clone` freisin.
///
/// ## Derivable
///
/// Is féidir an trait seo a úsáid le `#[derive]` más `Clone` na réimsí uile.Glaonn [`clone`] ar chur i bhfeidhm `díorthaithe [`Clone`] ar gach réimse.
///
/// [`clone`]: Clone::clone
///
/// Le haghaidh struct cineálach, cuireann `#[derive]` `Clone` coinníollach trí cheangal `Clone` ar pharaiméadair cineálacha.
///
/// ```
/// // `derive` úirlisí Chlónála don Léitheoireacht<T>nuair a bhíonn T Clón.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Conas is féidir liom `Clone` a chur i bhfeidhm?
///
/// Ba cheart go mbeadh cur i bhfeidhm fánach de `Clone` ag cineálacha atá [`Copy`].Níos foirmiúla:
/// más rud é `T: Copy`, `x: T`, agus `y: &T`, ansin tá `let x = y.clone();` comhionann le `let x = *y;`.
/// Ba chóir go mbeadh implementations Lámhleabhar a bheith cúramach chun seasamh leis an athraithe;áfach, níor cheart go mbeadh cód neamhshábháilte ag brath air chun sábháilteacht cuimhne a chinntiú.
///
/// Sampla is ea struchtúr cineálach a bhfuil pointeoir feidhme aige.Sa chás seo, ní féidir cur chun feidhme `Clone` a dhíorthú, ach is féidir é a chur i bhfeidhm mar:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Feidhmitheoirí breise
///
/// Chomh maith leis an [implementors listed below][impls], na cineálacha seo a leanas a chur i bhfeidhm freisin `Clone`:
///
/// * Cineálacha míreanna feidhme (ie, na cineálacha ar leith atá sainithe do gach feidhm)
/// * Cineálacha Feidhm Pointeoir (m.sh., `fn() -> i32`)
/// * Cineálacha eagar, do gach méid, má chuireann an cineál earra `Clone` i bhfeidhm freisin (m.sh., `[i32; 123456]`)
/// * Cineálacha dúblacha, má chuireann gach comhpháirt `Clone` i bhfeidhm freisin (m.sh., `()`, `(i32, bool)`)
/// * Cineálacha dúnta, mura bhfaigheann siad luach ar bith ón gcomhshaol nó má chuireann na luachanna gabhála sin `Clone` i bhfeidhm iad féin.
///   Tabhair faoi deara go gcuireann `Clone` athróga a ghabhtar trí thagairt roinnte i bhfeidhm i gcónaí (fiú mura ndéanann an moltóir é), cé nach gcuireann athróga a ghabhtar trí thagairt inathraithe `Clone` i bhfeidhm riamh.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Tuairisceáin cóip den luach.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str cuireann Clón i bhfeidhm
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Déanann sé cóip-sannadh ó `source`.
    ///
    /// `a.clone_from(&b)` is ionann `a = b.clone()` i feidhmiúlacht, ach is féidir a shárú a athúsáid acmhainní `a` leithdháiltí neamhriachtanach a sheachaint.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Faigh macra a ghineann impl den trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): na structs a úsáidtear d'aon toisc le#[dhíorthú] a dhearbhú go i ngach ball ar uirlisí chineál Chlónála nó Cóip.
//
//
// Níor chóir na structs feiceáil i cód úsáideora.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Clone` a chur i bhfeidhm do chineálacha primitive.
///
/// Implementations nach féidir a cur síos air i Rust i bhfeidhm i `traits::SelectionContext::copy_clone_conditions()` i `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Is féidir le tagairtí roinnte a clónáilte, ach tagairtí mutable *Is féidir nach*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Is féidir le tagairtí roinnte a clónáilte, ach tagairtí mutable *Is féidir nach*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}