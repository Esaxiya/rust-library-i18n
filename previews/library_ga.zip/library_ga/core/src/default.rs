//! An trait `Default` do chineálacha bhféadfadh luachanna réamhshocraithe brí.

#![stable(feature = "rust1", since = "1.0.0")]

/// A trait le haghaidh a thabhairt ar chineál luach réamhshocraithe úsáideach.
///
/// Uaireanta, ba mhaith leat a thagann ar ais go dtí an luach réamhshocraithe chineál éigin, agus nach cúram go háirithe a bhfuil sé.
/// Tagann sé seo suas go minic le `struct`s a shainiú sraith de roghanna:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// Conas is féidir linn roinnt luachanna réamhshocraithe a shainiú?Is féidir leat `Default` a úsáid:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// Anois, gheobhaidh tú gach ceann de na luachanna réamhshocraithe.Rust bhfeidhm `Default` do chineálacha primitives éagsúla.
///
/// Más mian leat rogha áirithe a shárú, ach na mainneachtainí eile a choinneáil fós:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// Is féidir é seo trait a úsáid le `#[derive]` más rud é gach ceann de na réimsí den chineál a chur i bhfeidhm `Default`.
/// Nuair `derive`d, beidh sé úsáid as an luach réamhshocraithe le haghaidh cineál gach réimse ar.
///
/// ## Conas is féidir liom `Default` a chur i bhfeidhm?
///
/// Sholáthar cur chun feidhme maidir leis an modh `default()` go tuairisceáin an luach do chineál ba chóir a bheith ar an réamhshocraithe:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// Filleann an "default value" ar chineál.
    ///
    /// Is minic gurb iad luachanna réamhshocraithe luach tosaigh de chineál éigin, luach aitheantais, nó aon rud eile a d`fhéadfadh ciall a bhaint as mar réamhshocrú.
    ///
    ///
    /// # Examples
    ///
    /// Ag baint úsáide as-tógtha i luachanna réamhshocraithe:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// Ag déanamh do chuid féin:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// Fill ar ais ar an luach réamhshocraithe i ndáil le cineál de réir an trait `Default`.
///
/// Is é an cineál a thabhairt ar ais tátal a bhaint as comhthéacs;tá sé seo comhionann le `Default::default()` ach is giorra é a chlóscríobh.
///
/// Mar shampla:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// Faigh macra a ghineann impl den trait `Default`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }