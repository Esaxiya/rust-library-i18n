//! uirlisí modúl seo an trait `Any`, a chuireann ar chumas clóscríobh dinimiciúil de chineál ar bith `'static` trí mhachnamh runtime.
//!
//! `Any` is féidir é féin a úsáid chun `TypeId` a fháil, agus tá níos mó gnéithe aige nuair a úsáidtear é mar réad trait.
//! Mar `&dyn Any` (réad trait a fuarthas ar iasacht), tá na modhanna `is` agus `downcast_ref` aige, chun a thástáil an bhfuil an luach atá ann de chineál ar leith, agus tagairt a fháil don luach istigh mar chineál.
//! Mar `&mut dyn Any`, tá an modh `downcast_mut` ann freisin, chun tagairt inathraithe a fháil don luach istigh.
//! `Box<dyn Any>` Cuireann an modh `downcast`, a iarrachtaí chun a thiontú go le `Box<T>`.
//! Féach cáipéisíocht [`Box`] chun na sonraí iomlána a fháil.
//!
//! Tabhair faoi deara go bhfuil `&dyn Any` teoranta do thástáil an bhfuil luach de chineál coincréite sonraithe, agus nach féidir é a úsáid chun a thástáil an gcuireann trait cineál i bhfeidhm.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Leideanna cliste agus `dyn Any`
//!
//! Píosa amháin iompair a choinneáil i gcuimhne nuair a úsáid `Any` mar rud trait, go háirithe le cineálacha nós `Box<dyn Any>` nó `Arc<dyn Any>` é, go simplí mbeidh ag iarraidh `.type_id()` ar an luach ar aird an `TypeId` an choimeádáin * *, nach bhfuil an trait réad bunúsacha.
//!
//! Is féidir é seo a sheachaint tríd an pointeoir cliste a thiontú ina `&dyn Any` ina ionad, rud a thabharfaidh `TypeId` an réada ar ais.
//! Mar shampla:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Is dóichí go mbeidh sé seo uait:
//! let actual_id = (&*boxed).type_id();
//! // ... ná sin:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Smaoinigh ar chás inar mian linn luach a chuirtear ar aghaidh chuig feidhm a logáil amach.
//! Tá a fhios againn an luach atá á oibriú againn ar Debug a chur i bhfeidhm, ach níl a fhios againn cén cineál coincréite atá ann.Ba mhaith linn cóireáil speisialta a thabhairt do chineálacha áirithe: sa chás seo fad na luachanna Teaghrán a phriontáil amach roimh a luach.
//! Níl a fhios againn an cineál nithiúil dár luach ag an am tiomsaithe, mar sin caithfimid machnamh rith-ama a úsáid ina ionad.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Feidhm logálaí d`aon chineál a chuireann Debug i bhfeidhm.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Déan iarracht ár luach a thiontú go `String`.
//!     // Má éiríonn linn, ba mhaith linn fad an Teaghráin a aschur chomh maith lena luach.
//!     // Mura bhfuil, tá sé ina chineál éagsúla: ach a phriontáil amach unadorned.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Ba mhaith leis an bhfeidhm seo a pharaiméadar a logáil amach sula ndéanann sí obair leis.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... déan roinnt oibre eile
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Aon trait
///////////////////////////////////////////////////////////////////////////////

/// trait chun clóscríobh dinimiciúil a aithris.
///
/// An chuid is mó cineálacha a chur chun feidhme `Any`.Mar sin féin, ní dhéanann aon chineál ina bhfuil tagairt neamh-``statach`.
/// Féach an [module-level documentation][mod] le haghaidh tuilleadh sonraí.
///
/// [mod]: crate::any
// Níl an trait seo neamhshábháilte, cé go mbímid ag brath ar shainiúlachtaí a fheidhm `type_id` aonair impl i gcód neamhshábháilte (m.sh., `downcast`).De ghnáth, bheadh a bheith ina fhadhb, ach toisc go bhfuil an t-impl ach de `Any` feidhme blaincéad, ní féidir aon chód eile `Any` a chur i bhfeidhm.
//
// D`fhéadfaimis an trait seo a dhéanamh neamhshábháilte go dóchúil-ní bheadh sé ina chúis le briseadh, ós rud é go ndéanaimid rialú ar na cur chun feidhme go léir-ach roghnaímid gan é sin a dhéanamh nach bhfuil riachtanach i ndáiríre agus d`fhéadfaimis úsáideoirí a chur ar an eolas faoi idirdhealú traits neamhshábháilte agus modhanna neamhshábháilte (ie, Bheadh sé sábháilte glaoch ar `type_id` fós, ach is dócha go mbeimis ag iarraidh é sin a chur in iúl sa doiciméadacht).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Faigheann an `TypeId` de `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Modhanna Síneadh le haghaidh aon rudaí trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// A chinntiú go bhfuil an thoradh ar mar shampla, is féidir dul isteach i snáithe a phriontáil agus mar sin úsáidtear le `unwrap`.
// Bealtaine sa deireadh a thuilleadh a bheith ag teastáil má oibríonn seolta le upcasting.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Tuairisceáin `true` má tá an cineál bosca mar an gcéanna le `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Faigh `TypeId` den chineál a gcuirtear an fheidhm seo ar an toirt leis.
        let t = TypeId::of::<T>();

        // Faigh `TypeId` den chineál i réad trait (`self`).
        let concrete = self.type_id();

        // Déan comparáid idir an dá `TypeId 'ar chomhionannas.
        t == concrete
    }

    /// Filleann sé tagairt éigin don luach i mboscaí más de chineál `T`, nó `None` é mura bhfuil.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SÁBHÁILTEACHT: seiceáil díreach an bhfuil muid ag díriú ar an gcineál ceart, agus an féidir linn brath air
            // an seiceáil sin ar shábháilteacht cuimhne toisc go bhfuil aon cheann do gach cineál curtha i bhfeidhm againn;ní féidir aon impls eile a bheith ann mar go mbeadh siad ag teacht salach ar ár impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Tuairisceáin éigin tagairt mutable don luach boxed má tá sé den chineál `T`, nó `None` mura bhfuil sé.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SÁBHÁILTEACHT: seiceáil díreach an bhfuil muid ag díriú ar an gcineál ceart, agus an féidir linn brath air
            // an seiceáil sin ar shábháilteacht cuimhne toisc go bhfuil aon cheann do gach cineál curtha i bhfeidhm againn;ní féidir aon impls eile a bheith ann mar go mbeadh siad ag teacht salach ar ár impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Ar aghaidh chuig an modh atá sainithe ar an gcineál `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Ar aghaidh chuig an modh atá sainithe ar an gcineál `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Ar aghaidh chuig an modh atá sainithe ar an gcineál `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Ar aghaidh chuig an modh atá sainithe ar an gcineál `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Ar aghaidh chuig an modh atá sainithe ar an gcineál `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Ar aghaidh chuig an modh atá sainithe ar an gcineál `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID agus a mhodhanna
///////////////////////////////////////////////////////////////////////////////

/// Léiríonn A `TypeId` le aitheantóir uathúil le haghaidh cineáil.
///
/// Rud teimhneach é gach `TypeId` nach gceadaíonn iniúchadh a dhéanamh ar a bhfuil istigh ach a cheadaíonn oibríochtaí bunúsacha mar chlónáil, chomparáid, phriontáil agus thaispeántas.
///
///
/// Níl `TypeId` ar fáil faoi láthair ach do chineálacha a bhaineann le `'static`, ach féadfar an teorannú seo a bhaint sa future.
///
/// Cé go gcuireann `TypeId` `Hash`, `PartialOrd`, agus `Ord` i bhfeidhm, is fiú a thabhairt faoi deara go n-athróidh na hashes agus an t-ordú idir eisiúintí Rust.
/// Beware a bheith ag brath orthu taobh istigh de do chód!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Filleann sé an `TypeId` den chineál a cuireadh an fheidhm chineálach seo ar an toirt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Tuairisceáin an t-ainm i ndáil le cineál mar slice teaghrán.
///
/// # Note
///
/// Tá sé seo beartaithe le haghaidh úsáide diagnóiseacha.
/// Ní shonraítear ábhar cruinn agus formáid na sreinge a cuireadh ar ais, seachas a bheith ina thuairisc den iarracht is fearr ar an gcineál.
/// Mar shampla, i measc na dtéad a d`fhéadfadh `type_name::<Option<String>>()` a thabhairt ar ais tá `"Option<String>"` agus `"std::option::Option<std::string::String>"`.
///
///
/// Ní gá a mheas gur aitheantóir uathúil de chineál an tsreang a chuirtear ar ais toisc go bhféadfadh ilchineálacha mapáil go dtí an cineál ainm céanna.
/// Ar an gcaoi chéanna, níl aon ráthaíocht ann go mbeidh gach cuid de chineál le feiceáil sa téad ar ais: mar shampla, ní áirítear sonraitheoirí ar feadh an tsaoil faoi láthair.
/// Lena chois sin, féadfaidh an t-aschur a athrú idir leaganacha den Tiomsaitheoir.
///
/// Úsáideann an cur i bhfeidhm faoi láthair ar an mbonneagar céanna le diagnóisic tiomsaitheoir agus debuginfo, ach nach bhfuil sé seo ráthaithe.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Tuairisceáin an t-ainm ar an gcineál na Léirigh-go luach mar slice teaghrán.
/// Tá sé seo mar an gcéanna le `type_name::<T>()`, ach is féidir é a úsáid i gcás nach bhfuil an cineál athróg ar fáil go héasca.
///
/// # Note
///
/// Tá sé seo a bheartaítear a úsáid diagnóiseacha.An t-ábhar cruinn agus formáid an teaghrán atá sonraithe, seachas a bheith cur síos is fearr-iarracht den chineál.
/// Mar shampla, d`fhéadfadh `type_name_of_val::<Option<String>>(None)` `"Option<String>"` nó `"std::option::Option<std::string::String>"` a thabhairt ar ais, ach ní `"foobar"`.
///
/// Lena chois sin, féadfaidh an t-aschur a athrú idir leaganacha den Tiomsaitheoir.
///
/// Ní dhéanann an fheidhm réiteach réada trait, rud a chiallaíonn go bhféadfadh `type_name_of_val(&7u32 as &dyn Debug)` ais `"dyn Debug"`, ach ní `"u32"`.
///
/// Níor cheart an t-ainm cineáil a mheas mar aitheantóir uathúil de chineál;
/// féadfaidh ilchineálacha an cineál céanna ainm a roinnt.
///
/// Úsáideann an cur i bhfeidhm faoi láthair ar an mbonneagar céanna le diagnóisic tiomsaitheoir agus debuginfo, ach nach bhfuil sé seo ráthaithe.
///
/// # Examples
///
/// Priontaítear an tslánuimhir réamhshocraithe agus na cineálacha snámhphointe.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}