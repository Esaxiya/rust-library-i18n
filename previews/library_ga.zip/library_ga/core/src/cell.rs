//! Coimeádáin mutable inroinnte.
//!
//! Tá sábháilteacht cuimhne Rust bunaithe ar an riail seo: I bhfianaise réad `T`, ní féidir ach ceann amháin díobh seo a leanas a bheith agat:
//!
//! - Ag a bhfuil roinnt tagairtí dochorraithe (`&T`) don réad (ar a dtugtar **ailiasú** freisin).
//! - Tagairt inathraithe amháin (`&mut T`) a bheith aige don réad (ar a dtugtar **mutability** freisin).
//!
//! Cuireann an tiomsaitheoir Rust é seo i bhfeidhm.Mar sin féin, tá cásanna ann nuair nach bhfuil an riail seo solúbtha go leor.Uaireanta, bíonn sé riachtanach go mbeadh tagairtí iomadúla a rud agus fós mutate air.
//!
//! Tá coimeádáin in-roinnte inroinnte ann chun mutability a cheadú ar bhealach rialaithe, fiú má bhíonn claonpháirteachas ann.Ligeann [`Cell<T>`] agus [`RefCell<T>`] araon é seo a dhéanamh ar bhealach aon snáithe.
//! Mar sin féin, tá súil le `Cell<T>` ná `RefCell<T>` snáithe sábháilte (nach bhfuil siad a chur i bhfeidhm [`Sync`]).
//! Más gá duit claonpháirteachas agus sóchán a dhéanamh idir iliomad snáitheanna is féidir cineálacha [`Mutex<T>`], [`RwLock<T>`] nó [`atomic`] a úsáid.
//!
//! Is féidir Luachanna na cineálacha `Cell<T>` agus `RefCell<T>` a mutated trí thagairtí roinnte (ie
//! an coitianta Cineál `&T`), ach is féidir an chuid is mó cineálacha Rust a mutated ach trí `tagairtí uathúil (&mut T`).
//! Deirimid go soláthraíonn `Cell<T>` agus `RefCell<T>` `mutability taobh istigh`, i gcodarsnacht leis na cineálacha tipiciúla Rust a thaispeánann `mutability oidhreacht`.
//!
//! chineál ceall teacht i dhá blasanna: `Cell<T>` agus `RefCell<T>`.Cuireann `Cell<T>` mutability istigh i bhfeidhm trí luachanna a bhogadh isteach agus amach as an `Cell<T>`.
//! Chun tagairtí in ionad luachanna a úsáid, ní mór ceann a bhaint as an gcineál `RefCell<T>`, a fháil glas scríobh roimh mutating.Soláthraíonn `Cell<T>` modhanna a fháil agus a athrú ar an luach istigh atá ann faoi láthair:
//!
//!  - Maidir le cineálacha a chuireann [`Copy`] i bhfeidhm, déanann an modh [`get`](Cell::get) an luach istigh atá ann faoi láthair a aisghabháil.
//!  - I gcás cineálacha a chuireann i bhfeidhm [`Default`], in áit an modh [`take`](Cell::take) an luach istigh atá ann faoi láthair le [`Default::default()`] agus tuairisceáin an luach in ionad.
//!  - I gcás gach cineál, ionad an modh [`replace`](Cell::replace) an luach istigh atá ann faoi láthair agus tuairisceáin an luach athsholáthar agus an [`into_inner`](Cell::into_inner) ídíonn modh an `Cell<T>` agus tuairisceáin an luach istigh.
//!  Ina theannta sin, glacann an modh [`set`](Cell::set) ionad an luach istigh, ag titim an luach athsholáthair.
//!
//! `RefCell<T>` úsáideann saolré Rust chun `iasachtaí dinimiciúla` a chur i bhfeidhm, próiseas trínar féidir le duine rochtain shealadach, eisiach, inathraithe ar an luach inmheánach a éileamh.
//! Iasachtaí do `RefCell<T>`S a rianú 'ag runtime', murab ionann agus cineálacha tagartha dúchais Rust atá a rianú go hiomlán statically, ag am tiomsaithe.
//! Toisc go bhfuil iasachtaí `RefCell<T>` dinimiciúil is féidir iarracht a dhéanamh luach atá ar iasacht go frithpháirteach a fháil ar iasacht cheana féin;nuair a tharlaíonn sé seo is toradh é i snáithe panic.
//!
//! # Nuair a roghnú istigh mutability
//!
//! Tá an t-inmharthanacht oidhreachta is coitianta, nuair a chaithfidh rochtain uathúil a bheith ag duine ar luach a threáitear, ar cheann de na príomhghnéithe teanga a chuireann ar chumas Rust réasúnaíocht láidir a dhéanamh faoi ailíniú pointeoir, ag cosc fabhtanna tuairteála go statach.
//! Mar gheall air sin, is fearr mutability oidhreachta, agus is é an rogha dheireanach é mutability taobh istigh.
//! Ós rud é ar chumas chineál ceall mutation gcás ina mbeadh sé a dhícheadú ar shlí eile áfach, tá ócáidí nuair a d'fhéadfadh mutability istigh a bheith oiriúnach, nó fiú *mór* a úsáid, mar shampla
//!
//! * Ag tabhairt isteach mutability 'inside' de rud dochorraithe
//! * sonraí a chur i bhfeidhm modhanna loighciúil-immutable.
//! * implementations de [`Clone`] mutating.
//!
//! ## Ag tabhairt isteach mutability 'inside' de rud dochorraithe
//!
//! Soláthraíonn go leor cineálacha pointeoir cliste roinnte, lena n-áirítear [`Rc<T>`] agus [`Arc<T>`], coimeádáin ar féidir iad a chlónáil agus a roinnt idir ilpháirtithe.
//! Toisc gur féidir na luachanna atá ann a iolrú ar iolrú, ní féidir iad a fháil ar iasacht ach le `&`, ní le `&mut`.
//! Gan cealla go mbeadh sé dodhéanta a shonraí taobh istigh claochlú tosaigh a de na leideanna cliste ar chor ar bith.
//!
//! Tá sé an-choitianta sin a chur `RefCell<T>` taobh istigh cineálacha pointeoir comhroinnte mutability reintroduce:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Cruthaigh bloc nua chun scóip na hiasachta dinimiciúla a theorannú
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Tabhair faoi deara mura ligimis d`iasacht roimhe seo an taisce titim as a raon feidhme ansin bheadh snáithe dinimiciúil panic ina chúis leis an iasacht ina dhiaidh sin.
//!     //
//!     // Is é seo an ghuais mhór a bhaineann le `RefCell` a úsáid.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Tabhair faoi deara go n-úsáideann `Rc<T>` an sampla seo agus ní `Arc<T>`.`RefCell<T>baineann siad le cásanna aon snáithe.Smaoinigh ar úsáid a bhaint as [`RwLock<T>`] nó [`Mutex<T>`] más gá tú roinnte mutability i staid il-snáithithe.
//!
//! ## Sonraí cur chun feidhme na modhanna nach féidir a aistriú go loighciúil
//!
//! Uaireanta b`fhéidir go mbeadh sé inmhianaithe gan a nochtadh i API go bhfuil sóchán ag tarlú "under the hood".
//! B`fhéidir go bhfuil sé seo toisc go bhfuil an oibríocht dochorraithe go loighciúil, ach m.sh., cuireann caching iallach ar an gcur i bhfeidhm sóchán a dhéanamh;nó toisc go gcaithfidh tú sóchán a úsáid chun modh trait a chur i bhfeidhm a sainmhíníodh ar dtús chun `&self` a thógáil.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Téann ríomh Daor anseo
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Cur chun feidhme frithpháirteach `Clone`
//!
//! Tá sé seo ach ar leith, ach coitianta, cás an roimhe: mutability bhfolach le haghaidh oibríochtaí a dealraitheach a bheith immutable.
//! Meastar nach n-athróidh an modh [`clone`](Clone::clone) an luach foinse, agus dearbhaítear go dtógfaidh sé `&self`, ní `&mut self`.
//! Dá bhrí sin, caithfidh aon sóchán a tharlaíonn sa mhodh `clone` cineálacha cille a úsáid.
//! Mar shampla, coinníonn [`Rc<T>`] a chomhaireamh tagartha laistigh `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Suíomh cuimhne mutable.
///
/// # Examples
///
/// Sa sampla seo, is féidir leat a fheiceáil a chuireann ar chumas `Cell<T>` mutation taobh istigh de struct immutable.
/// Is é sin le rá, cuireann sé ar chumas "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ERROR: Tá `my_struct` dochorraithe
/// // my_struct.regular_field =new_value;
///
/// // OIBREACHA: cé go bhfuil `my_struct` dochorraithe, is `Cell` é `special_field`,
/// // is féidir a threáitear i gcónaí
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Féach ar an [module-level documentation](self) ar feadh níos mó.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Cruthaíonn `Cell<T>`, leis an luach `Default` do T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Cruthaigh `Cell` nua ina bhfuil an luach a tugadh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Socraigh an luach atá.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Babhtáil luachanna dhá Cheall.
    /// Is Difríocht leis an `std::mem::swap` nach an fheidhm seo a cheangal ar tagairt `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // SÁBHÁILTEACHT: D`fhéadfadh sé seo a bheith contúirteach má ghlaotar air ó shnáitheanna ar leithligh, ach `Cell`
        // is `!Sync` é mar sin ní tharlóidh sé seo.
        // Ní bheidh freisin aon leideanna ó bhail ós rud a dhéanann `Cell` cinnte rud ar bith eile a bhíonn ag cur in iúl i gceachtar de na `Cell`s.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Cuirtear `val` in ionad an luacha atá ann, agus tugann sé an seanluach atá ann ar ais.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // SÁBHÁILTEACHT: D`fhéadfadh rásaí sonraí a bheith ina chúis leis seo má ghlaotar orthu ó shnáithe ar leithligh,
        // ach is é `Cell` `!Sync` mar sin ní tharlóidh sé seo.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Unwraps an luach.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Seoltar cóip den luach atá ann ar ais.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // SÁBHÁILTEACHT: D`fhéadfadh rásaí sonraí a bheith ina chúis leis seo má ghlaotar orthu ó shnáithe ar leithligh,
        // ach is é `Cell` `!Sync` mar sin ní tharlóidh sé seo.
        unsafe { *self.value.get() }
    }

    /// Cothrom le dáta an luach atá ag baint úsáide as feidhm agus tuairisceáin an luach nua.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Tuairisceáin pointeoir amh leis na sonraí bunúsacha sa chill.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Tuairisceáin tagairt mutable leis na sonraí bunúsacha.
    ///
    /// iasacht an glaoch `Cell` mutably (ag tiomsaithe-am) a ráthaíonn go mbeadh muid an t tagartha amháin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Tuairisceáin a `&Cell<T>` ó `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // SÁBHÁILTEACHT: Cinntíonn `&mut` rochtain uathúil.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Glacann an luach na cille, ag fágáil `Default::default()` ina áit.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Filleann `&[Cell<T>]` ó `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // SÁBHÁILTEACHT: Tá an leagan amach cuimhne céanna ag `Cell<T>` agus atá ag `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Suíomh cuimhne suaiteach le rialacha iasachta arna seiceáil go dinimiciúil
///
/// Féach ar an [module-level documentation](self) ar feadh níos mó.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Earráid curtha ar ais ag [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Earráid curtha ar ais ag [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Léiríonn luachanna dearfacha líon na `Ref` atá gníomhach.Léiríonn luachanna diúltacha an líon `RefMut` atá gníomhach.
// Ní féidir iolraí `RefMut` a bheith gníomhach ag an am ach má thagraíonn siad do chomhpháirteanna ar leithligh neamh-fhorleagtha de `RefCell` (m.sh., raonta difriúla slice).
//
// `Ref` agus tá `RefMut` araon dhá fhocal i méid, agus mar sin beidh riamh is dócha go leor Ref`s`nó`RefMut`s ann le overflow leath den raon `usize`.
// Mar sin, is dócha nach mbeidh `BorrowFlag` ag cur thar maoil ná ag cur thar maoil.
// Mar sin féin, nach bhfuil sé seo ráthaíocht, mar a d'fhéadfadh clár paiteolaíocha a chruthú arís agus arís eile agus ansin mem::forget `Ref`s nó`RefMut`s.
// Dá bhrí sin, ní mór do gach cód seiceáil go sainráite ar ró-shreabhadh agus ar shreabhadh d`fhonn neamhshábháilteacht a sheachaint, nó ar a laghad iompar i gceart sa chás go dtarlaíonn ró-shreabhadh nó ró-shreabhadh (m.sh., féach BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Cruthaigh `RefCell` nua ina `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Itheann an `RefCell`, ag filleadh an luach fillte.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Ós rud é go dtarlaíonn an fheidhm seo `self` (an `RefCell`) trí luach, an tiomsaitheoir statically fíorú sé gurb é nach iasacht faoi láthair.
        //
        self.value.into_inner()
    }

    /// Cuirtear luach nua in ionad an luach fillte, ag filleadh an tseanluacha, gan ceachtar acu a dhí-ainmniú.
    ///
    ///
    /// Freagraíonn an fheidhm a [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics má fhaightear an luach ar iasacht faoi láthair.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Cuirtear an luach fillte in ionad ceann nua arna ríomh ó `f`, ag filleadh an tseanluacha, gan ceachtar acu a dhí-ainmniú.
    ///
    ///
    /// # Panics
    ///
    /// Panics má fhaightear an luach ar iasacht faoi láthair.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Babhtáil luach fillte `self` le luach fillte `other`, gan ceachtar acu a dhí-ainmniú.
    ///
    ///
    /// Freagraíonn an fheidhm seo do [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics má fhaightear an luach i gceachtar `RefCell` ar iasacht faoi láthair.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Faigheann sé an luach fillte ar iasacht go dochreidte.
    ///
    /// Maireann an iasacht go dtí go dtéann an `Ref` ar ais as a scóip.
    /// Is féidir iasachtaí iomadúla dochorraithe a thógáil amach ag an am céanna.
    ///
    /// # Panics
    ///
    /// Panics má tá an luach faoi láthair a fuarthas ar iasacht mutably.
    /// I gcás a mhalairt neamh-panicking, a úsáid [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Sampla de panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Immutably iasacht an luach fillte, ag filleadh earráid má tá an luach a fuarthas ar iasacht faoi láthair mutably.
    ///
    ///
    /// Maireann an iasacht go dtí go dtéann an `Ref` ar ais as a scóip.
    /// Is féidir iasachtaí iomadúla dochorraithe a thógáil amach ag an am céanna.
    ///
    /// Is é seo an neamh-panicking mhalairt de [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // SÁBHÁILTEACHT: Cinntíonn `BorrowRef` nach bhfuil ann ach rochtain dochorraithe
            // ar an luach agus é ar iasacht.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Faigheann an luach fillte ar iasacht go frithpháirteach.
    ///
    /// Maireann an iasacht go dtí go dtéann an `RefMut` ar ais nó gach `RefMut` a dhíorthaítear óna raon feidhme imeachta.
    ///
    /// Ní féidir an luach a fháil ar iasacht fad atá an iasacht seo gníomhach.
    ///
    /// # Panics
    ///
    /// Panics má fhaightear an luach ar iasacht faoi láthair.
    /// Le haghaidh malairtí neamh-scaollála, úsáid [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Sampla de panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Faigheann an luach fillte ar iasacht go frithpháirteach, agus faightear earráid ar ais má fhaightear an luach ar iasacht faoi láthair.
    ///
    ///
    /// Maireann an iasacht go dtí go dtéann an `RefMut` ar ais nó gach `RefMut` a dhíorthaítear óna raon feidhme imeachta.
    /// Ní féidir an luach a fháil ar iasacht fad atá an iasacht seo gníomhach.
    ///
    /// Is é seo an leagan neamh-panicking de [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // SÁBHÁILTEACHT: Ráthaíonn `BorrowRef` rochtain uathúil.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Tuairisceáin pointeoir amh leis na sonraí bunúsacha sa chill.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Tuairisceáin tagairt mutable leis na sonraí bunúsacha.
    ///
    /// Faigheann an glao seo `RefCell` ar iasacht go frithpháirteach (ag am tiomsaithe) agus mar sin ní gá seiceálacha dinimiciúla a dhéanamh.
    ///
    /// Ach a bheith cúramach: ag súil an modh seo `self` a bheith mutable, a bhfuil go ginearálta nach bhfuil an cás nuair a úsáid a `RefCell`.
    ///
    /// Féach ar an modh [`borrow_mut`] ina ionad mura bhfuil `self` inathraithe.
    ///
    /// Chomh maith leis sin, tabhair faoi deara nach bhfuil an modh seo ach le haghaidh cúinsí speisialta agus de ghnáth ní hé an rud atá uait.
    /// I gcás amhrais, bain úsáid as [`borrow_mut`] ina ionad.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Cealaigh éifeacht gardaí sceite ar staid iasachta an `RefCell`.
    ///
    /// Tá an glao cosúil leis [`get_mut`] ach níos speisialaithe.
    /// Iasacht sé `RefCell` mutably chun a chinntiú nach iasacht ann agus ansin resets an stát rianú ar iasacht roinnte.
    /// Tá sé seo ábhartha más rud é go bhfuil roinnt `Ref` nó `RefMut` iasacht a bheith leaked.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Immutably iasacht an luach fillte, ag filleadh earráid má tá an luach a fuarthas ar iasacht faoi láthair mutably.
    ///
    /// # Safety
    ///
    /// Murab ionann agus `RefCell::borrow`, tá an modh sábháilte toisc nach bhfuil sé ar ais ina `Ref`, rud a fhágann an bhratach iasacht untouched.
    /// Is iompar neamhshainithe é an `RefCell` a fháil ar iasacht go frithpháirteach agus an tagairt a chuirtear ar ais leis an modh seo beo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // SÁBHÁILTEACHT: Táimid ag seiceáil go bhfuil duine ar bith ag scríobh go gníomhach anois, ach tá sé
            // freagracht an ghlaoiteora a chinntiú nach scríobhann aon duine go dtí nach mbeidh an tagairt ar ais in úsáid a thuilleadh.
            // Chomh maith leis sin, tagraíonn `self.value.get()` le luach úinéireacht ag `self` agus tá sé a ráthú mar sin a bheith bailí ar feadh shaolré na `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Glacann sé an luach fillte, ag fágáil `Default::default()` ina áit.
    ///
    /// # Panics
    ///
    /// Panics má fhaightear an luach ar iasacht faoi láthair.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics má tá an luach faoi láthair a fuarthas ar iasacht mutably.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Cruthaíonn sé `RefCell<T>`, leis an luach `Default` do T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics má fhaightear an luach i gceachtar `RefCell` ar iasacht faoi láthair.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics má fhaightear an luach i gceachtar `RefCell` ar iasacht faoi láthair.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics má fhaightear an luach i gceachtar `RefCell` ar iasacht faoi láthair.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics má fhaightear an luach i gceachtar `RefCell` ar iasacht faoi láthair.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics má fhaightear an luach i gceachtar `RefCell` ar iasacht faoi láthair.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics má fhaightear an luach i gceachtar `RefCell` ar iasacht faoi láthair.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics má fhaightear an luach i gceachtar `RefCell` ar iasacht faoi láthair.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // D`fhéadfadh luach neamhléitheoireachta (<=0) a bheith mar thoradh ar mhéadú iasachta sna cásanna seo:
            // 1. <0 a bhí ann, ie tá iasachtaí i scríbhinn, mar sin ní féidir linn iasacht léite a cheadú mar gheall ar rialacha ailínithe tagartha Rust
            // 2.
            // isize::MAX a bhí ann (uasmhéid na n-iasachtaí léitheoireachta) agus sháraigh sé isteach i isize::MIN (uasmhéid na n-iasachtaí scríbhneoireachta) agus mar sin ní féidir linn iasacht léitheoireachta breise a cheadú toisc nach féidir le isize an oiread sin iasachtaí léite a léiriú (ní féidir leis seo tarlú mura rud é mem::forget tú níos mó ná méid tairiseach beag de `Tag, nach dea-chleachtas é)
            //
            //
            //
            //
            None
        } else {
            // Is féidir incriminteach iasacht mar thoradh ar luach léitheoireachta (> 0) sna cásanna seo:
            // 1. Bhí sé=0, ní raibh sin é ar iasacht, agus táimid ag cur an chéad iasacht léamh
            // 2. Bhí sé> 0 agus <isize::MAX, ie
            // léadh iasachtaí, agus tá an méid mór go leor chun a fháil amach go bhfuil iasacht léite amháin níos mó agat
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Ó tharla go bhfuil an Tag seo ann, tá a fhios againn gur iasacht léitheoireachta í an bhratach iasachta.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Cosc a chur ar an gcuntar iasacht ó cur thar maoil isteach i iasacht scríbhneoireachta.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Fillte tagairt ar iasacht do luach i mbosca `RefCell`.
/// Cineál fillteáin ar luach a fuarthas ar iasacht go dochreidte ó `RefCell<T>`.
///
/// Féach ar an [module-level documentation](self) ar feadh níos mó.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Cóipeanna a `Ref`.
    ///
    /// Tá an `RefCell` ar iasacht go dochreidte cheana féin, mar sin ní féidir go dteipfidh air seo.
    ///
    /// Is feidhm ghaolmhar í seo nach mór a úsáid mar `Ref::clone(...)`.
    /// Chuirfeadh cur i bhfeidhm `Clone` nó modh isteach ar úsáid fhorleathan `r.borrow().clone()` chun ábhar `RefCell` a chlónáil.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Déanann `Ref` nua do chomhpháirt de na sonraí a fuarthas ar iasacht.
    ///
    /// Tá an `RefCell` ar iasacht go dochreidte cheana féin, mar sin ní féidir go dteipfidh air seo.
    ///
    /// Is feidhm ghaolmhar í seo nach mór a úsáid mar `Ref::map(...)`.
    /// Chuirfeadh modh isteach ar mhodhanna den ainm céanna ar ábhar `RefCell` a úsáidtear trí `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Déanann `Ref` nua do chomhpháirt roghnach de na sonraí a fuarthas ar iasacht.
    /// Tugtar an garda bunaidh ar ais mar `Err(..)` má fhilleann an dúnadh `None`.
    ///
    /// Tá an `RefCell` ar iasacht go dochreidte cheana féin, mar sin ní féidir go dteipfidh air seo.
    ///
    /// Is feidhm gaolmhar gur gá a bheidh le húsáid mar `Ref::filter_map(...)`.
    /// Chuirfeadh modh isteach ar mhodhanna den ainm céanna ar ábhar `RefCell` a úsáidtear trí `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Roinntear `Ref` ina iolraí `Tag 'do chomhpháirteanna éagsúla de na sonraí a fuarthas ar iasacht.
    ///
    /// Tá an `RefCell` ar iasacht go dochreidte cheana féin, mar sin ní féidir go dteipfidh air seo.
    ///
    /// Is feidhm ghaolmhar í seo nach mór a úsáid mar `Ref::map_split(...)`.
    /// Chuirfeadh modh isteach ar mhodhanna den ainm céanna ar ábhar `RefCell` a úsáidtear trí `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Tiontaigh go tagairt do na sonraí bunúsacha.
    ///
    /// Ní féidir leis an `RefCell` is bun a fháil ar iasacht mutably ó arís agus beidh sé le feiceáil i gcónaí ar iasacht immutably cheana.
    ///
    /// Ní smaoineamh maith é níos mó ná líon leanúnach tagairtí a sceitheadh.
    /// Is féidir an `RefCell` a fháil ar iasacht arís go dochreidte mura bhfuil ach líon níos lú sceitheanna tar éis tarlú san iomlán.
    ///
    /// Is feidhm ghaolmhar í seo nach mór a úsáid mar `Ref::leak(...)`.
    /// Chuirfeadh modh isteach ar mhodhanna den ainm céanna ar ábhar `RefCell` a úsáidtear trí `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // De réir a dearmad a dhéanamh ar an Tag cinnteoimid go bhfuil an gcuntar iasacht sa RefCell ní féidir dul ar ais go dtí Neamhúsáidte laistigh de shaolré `'b`.
        // Theastódh tagairt uathúil don RefCell a fuarthas ar iasacht chun an stát rianaithe tagartha a athshocrú.
        // Ní féidir aon tagairtí inathraithe breise a chruthú ón gcill bhunaidh.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Déanann `RefMut` nua do chomhpháirt de na sonraí a fuarthas ar iasacht, m.sh., malairtí enum.
    ///
    /// Tá an `RefCell` cheana féin ar iasacht mutably, mar sin ní féidir é seo a theipeann.
    ///
    /// Is feidhm ghaolmhar í seo nach mór a úsáid mar `RefMut::map(...)`.
    /// Chuirfeadh modh isteach ar mhodhanna den ainm céanna ar ábhar `RefCell` a úsáidtear trí `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): seiceáil iasacht-seiceáil
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Déanann `RefMut` nua do chomhpháirt roghnach de na sonraí a fuarthas ar iasacht.
    /// Tugtar an garda bunaidh ar ais mar `Err(..)` má fhilleann an dúnadh `None`.
    ///
    /// Tá an `RefCell` cheana féin ar iasacht mutably, mar sin ní féidir é seo a theipeann.
    ///
    /// Is feidhm gaolmhar gur gá a bheidh le húsáid mar `RefMut::filter_map(...)`.
    /// Chuirfeadh modh isteach ar mhodhanna den ainm céanna ar ábhar `RefCell` a úsáidtear trí `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): seiceáil iasacht-seiceáil
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SÁBHÁILTEACHT: coimeádann an fheidhm tagairt thagartha ar feadh an ré
        // dá ghlaoch trí `orig`, agus an pointeoir taobh istigh den ghlao fheidhm riamh ag ceadú an tagairt eisiach chun éalú ach amháin de-thagartha.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SÁBHÁILTEACHT: mar an gcéanna thuas.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Roinntear `RefMut` ina iliomad `RefMut`s do chomhpháirteanna éagsúla de na sonraí a fuarthas ar iasacht.
    ///
    /// Fanfaidh an `RefCell` bunúsach ar iasacht go frithpháirteach go dtí go rachaidh an dá `RefMut` ar ais as a raon feidhme.
    ///
    /// Tá an `RefCell` cheana féin ar iasacht mutably, mar sin ní féidir é seo a theipeann.
    ///
    /// Is feidhm ghaolmhar í seo nach mór a úsáid mar `RefMut::map_split(...)`.
    /// Chuirfeadh modh isteach ar mhodhanna den ainm céanna ar ábhar `RefCell` a úsáidtear trí `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Tiontaigh isteach tagairt mutable do na sonraí bunúsacha.
    ///
    /// Ní féidir leis an `RefCell` is bun a fháil ar iasacht ó arís agus beidh sé le feiceáil i gcónaí cheana féin a fuarthas ar iasacht mutably, an tarchur ar ais an t-aon leis an taobh istigh.
    ///
    ///
    /// Is feidhm gaolmhar gur gá a bheidh le húsáid mar `RefMut::leak(...)`.
    /// Chuirfeadh modh isteach ar mhodhanna den ainm céanna ar ábhar `RefCell` a úsáidtear trí `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // De réir a dearmad a dhéanamh ar an BorrowRefMut cinnteoimid go bhfuil an gcuntar iasacht sa RefCell ní féidir dul ar ais go dtí Neamhúsáidte laistigh de shaolré `'b`.
        // Theastódh tagairt uathúil don RefCell a fuarthas ar iasacht chun an stát rianaithe tagartha a athshocrú.
        // Ní féidir aon tagairtí eile a chruthú ó na cille bunaidh laistigh den saolré, a dhéanamh ar an iasacht atá ann faoi láthair an t-tagartha amháin do thréimhse eile.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Murab ionann agus BorrowRefMut::clone, tugtar nua chun an tosaigh a chruthú
        // tagairt inathraithe, agus mar sin ní gá go mbeadh tagairtí ann faoi láthair.
        // Mar sin, cé go incrimintí Clón an refcount mutable, anseo táimid ag a cheadú go sainráite ach dul ó úsáidtear a thairiscint nár úsáideadh, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Cluain Eois a `BorrowRefMut`.
    //
    // Tá sé seo bailí ach amháin má chomhlíontar gach ceann `BorrowRefMut` úsáidtear chun rianú tagairt mutable do leith, raon nonoverlapping an gcuspóir bunaidh.
    //
    // Níl sé seo i gclón Clón ionas nach nglaonn an cód seo air go hintuigthe.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Cosc a chur ar an gcuntar iasachta ó bheith ag cur thar maoil.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Cineál fillteáin ar luach a fuarthas ar iasacht go frithpháirteach ó `RefCell<T>`.
///
/// Féach ar an [module-level documentation](self) ar feadh níos mó.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// An croí primitive maidir le mutability taobh istigh i Rust.
///
/// Má tá tú tagairt `&T`, ansin de ghnáth i Rust na fheidhmíonn Tiomsaitheoir optimizations atá bunaithe ar an eolas go bhfuil na pointí `&T` sonraí immutable.Meastar gur iompar neamhshainithe na sonraí sin a shuaitheadh, mar shampla trí ailias nó trí `&T` a aistriú go `&mut T`.
/// `UnsafeCell<T>` roghnaíonn-as an ráthaíocht immutability haghaidh `&T`: féadfaidh ainm Stáit tagairt roinnte `&UnsafeCell<T>` pointe chun sonraí a bhíonn á mutated.Seo ar a dtugtar "interior mutability".
///
/// Úsáideann gach cineál eile a cheadaíonn sócháin inmheánach, mar shampla `Cell<T>` agus `RefCell<T>`, `UnsafeCell` go hinmheánach chun a gcuid sonraí a fhilleadh.
///
/// Tabhair faoi deara nach bhfuil ach an ráthaíocht immutability chur in ionad tagairtí roinnte tionchar ag `UnsafeCell`.Ní dhéantar aon difear don ráthaíocht uathúlachta maidir le tagairtí do-athraithe.Níl *aon* bhealach dlíthiúil ann chun ailiasacht `&mut` a fháil, ní fiú le `UnsafeCell<T>`.
///
/// Is é an API `UnsafeCell` féin go teicniúil an-simplí: [`.get()`] Tugann tú `*mut T` pointeoir amh le a bhfuil ann.Tá sé suas le _you_ mar an dearthóir astarraingthe an pointeoir amh sin a úsáid i gceart.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Is iad na rialacha aliasing beacht Rust beagán i Flux, ach nach bhfuil na príomhphointí achrannaí:
///
/// - Má chruthaíonn tú tagairt shábháilte le `'a` ar feadh an tsaoil (tagairt `&T` nó `&mut T`) atá inrochtana le cód sábháilte (mar shampla, toisc gur chuir tú ar ais é), ansin ní mór duit rochtain a fháil ar na sonraí ar bhealach ar bith a théann salach ar an tagairt sin don chuid eile. de `'a`.
/// Mar shampla, seo, ciallaíonn go má tá tú ar an `*mut T` ó `UnsafeCell<T>` agus chaith sé le `&T`, ansin caithfidh na sonraí i `T` fós immutable (modulo aon sonraí `UnsafeCell` fáil laistigh `T`, ar ndóigh) go dtí go rachaidh sin tagairt ar feadh an tsaoil.
/// Mar an gcéanna, má tá tú a chruthú tagairt `&mut T` go scaoiltear le cód sábháilte, ansin ní mór duit a rochtain ar na sonraí laistigh den `UnsafeCell` go dtí go rachaidh sin tagairt.
///
/// - Ag gach tráth, ní mór duit a sheachaint rásaí sonraí.Má tá tú rochtain ar an `UnsafeCell` céanna snáitheanna il, ansin caithfidh aon scríobhann bheith ceart tharlaíonn-roimh ndáil le gach rochtana eile (nó Atomics úsáid).
///
/// Le cuidiú le dearadh ceart, dearbhaítear go sainráite go bhfuil na cásanna seo a leanas dlíthiúil do chód aon snáithe:
///
/// 1. Is féidir le tagairt A `&T` a scaoileadh cód sábháilte agus is féidir é a bheith ar cómharthain leis tagairtí `&T` eile, ach ní le `&mut T`
///
/// 2. Féadfar tagairt `&mut T` a scaoileadh chuig cód sábháilte ar choinníoll nach bhfuil `&mut T` ná `&T` eile ann leis.Caithfidh `&mut T` a bheith uathúil i gcónaí.
///
/// Tabhair faoi deara, cé go bhfuil sé ceart go leor ábhar `&UnsafeCell<T>` a mhúchadh (cé go bhfuil tagairtí `&UnsafeCell<T>` eile ailias na cille) ceart go leor (ar an gcoinníoll go gcuireann tú na invariants thuas i bhfeidhm ar bhealach éigin eile), is iompar neamhshainithe fós é ailiasanna `&mut UnsafeCell<T>` iolracha a bheith agat.
/// Is é sin, fillteán é `UnsafeCell` atá deartha chun idirghníomhú speisialta a bheith aige le _shared_ accesses (_i.e._, trí thagairt `&UnsafeCell<_>`);níl aon draíochta ar bith agus iad ag déileáil le _exclusive_ accesses (_e.g._, trí `&mut UnsafeCell<_>`): ní fhéadfaidh na cille ná an luach fillte a aliased ar feadh ré sin `&mut` iasacht.
///
/// Taispeánann an cúlpháirtí [`.get_mut()`] é seo, is é sin _safe_ getter a thugann `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Seo sampla taispeáint conas a mutate soundly an t-ábhar ar `UnsafeCell<_>` ainneoin a bheith ann tagairtí il aliasing na cille:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Faigh tagairtí iolracha/comhthráthacha/roinnte don `x` céanna.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // SÁBHÁILTEACHT: laistigh den raon feidhme seo níl aon tagairtí eile d`ábhar`x`,
///     // mar sin tá ár linne uathúil éifeachtach.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- iasacht-+
///     *p1_exclusive += 27; // |
/// } // <---------- Ní féidir dul thar an bpointe -------------------+
///
/// unsafe {
///     // SÁBHÁILTEACHT: laistigh den raon feidhme seo níl aon duine ag súil go mbeidh rochtain eisiach aige ar ábhar `x`,
///     // ionas gur féidir linn a bheith rochtana roinnte il gcomhthráth.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Showcases an sampla seo an bhfíric go leanann sé rochtain eisiach chun an `UnsafeCell<T>` rochtain eisiach chun a `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // le rochtana eisiacha,
///                         // `UnsafeCell` Is fillteán trédhearcach aon-op é, mar sin níl aon ghá le `unsafe` anseo.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Faigh tagairt uathúil do `x` arna seiceáil ag am-tiomsaithe.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Le tagairt eisiach, is féidir linn a claochlú tosaigh an t-ábhar le haghaidh saor in aisce.
/// *p_unique.get_mut() = 0;
/// // Nó, mar an gcéanna:
/// x = UnsafeCell::new(0);
///
/// // Nuair is leis an luach muid, is féidir linn an t-ábhar a bhaint saor in aisce.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Constructs ásc nua de `UnsafeCell` a wrap an méid sonraithe.
    ///
    ///
    /// Tá gach rochtain ar an luach istigh trí mhodhanna `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Unwraps an luach.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Faigheann pointeoir inathraithe ar an luach fillte.
    ///
    /// Is féidir seo a caitheadh le pointeoir de chineál ar bith.
    /// Déan cinnte go bhfuil an rochtain uathúil (gan aon tagairtí gníomhacha, inathraithe nó nach bhfuil) agus í ag caitheamh chuig `&mut T`, agus déan cinnte nach bhfuil sócháin nó ailiasanna inathraithe ag dul ar aghaidh agus iad ag caitheamh go `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Is féidir linn a caitheadh ach an pointeoir ó `UnsafeCell<T>` go `T` agat mar gheall #[repr(transparent)].
        // Exploits an stádas speisialta libstd ar, níl aon ráthaíocht don chód úsáideora go mbeidh an obair i leaganacha future den tiomsaitheoir!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Tuairisceáin tagairt mutable leis na sonraí bunúsacha.
    ///
    /// Faigheann an glao seo an `UnsafeCell` ar iasacht go frithpháirteach (ag am tiomsaithe) a ráthaíonn go bhfuil an t-aon tagairt againn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Faigheann pointeoir inathraithe ar an luach fillte.
    /// Is é an difríocht go [`get`] go nglacann an fheidhm seo a pointeoir amh, atá úsáideach chun nach gcruthófar tagairtí sealadacha.
    ///
    /// Is féidir an toradh a chaitheamh ar phointeoir de chineál ar bith.
    /// Déan cinnte go bhfuil an rochtain uathúil (gan aon tagairtí gníomhacha, inathraithe nó nach bhfuil) agus í ag caitheamh chuig `&mut T`, agus déan cinnte nach bhfuil sócháin nó ailiasanna inathraithe ag dul ar aghaidh agus iad ag caitheamh go `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Teastaíonn `raw_get` chun an `UnsafeCell` a thionscnamh de réir a chéile, mar go mbeadh gá le tagairt do shonraí neamhdhírithe a chruthú chun `get` a ghlaoch:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Is féidir linn a caitheadh ach an pointeoir ó `UnsafeCell<T>` go `T` agat mar gheall #[repr(transparent)].
        // Exploits an stádas speisialta libstd ar, níl aon ráthaíocht don chód úsáideora go mbeidh an obair i leaganacha future den tiomsaitheoir!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Cruthaíonn `UnsafeCell`, leis an luach `Default` do T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}