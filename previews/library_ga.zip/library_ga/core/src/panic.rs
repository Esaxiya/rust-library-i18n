//! Tacaíocht Panic sa leabharlann chaighdeánach.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// Struchtúr a sholáthraíonn faisnéis faoi panic.
///
/// `PanicInfo` cuirtear an struchtúr ar aghaidh chuig panic hook arna leagan síos ag an bhfeidhm [`set_hook`].
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// Filleann sé an t-ualach pá a bhaineann leis an panic.
    ///
    /// De ghnáth is `&'static str` nó [`String`] a bheidh i gceist anseo.
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Má baineadh úsáid as an macra `panic!` ón `core` crate (ní ó `std`) le teaghrán formáidiú agus roinnt argóintí breise, tuairisceáin go teachtaireacht réidh le húsáid le haghaidh shampla [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Cuireann sé faisnéis ar ais faoin áit as ar tháinig an panic, má tá sí ar fáil.
    ///
    /// Beidh an modh faoi láthair ar ais i gcónaí [`Some`], ach d'fhéadfadh an t-athrú i leaganacha future.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Má tá sé seo athrú a thabhairt ar ais uaireanta Níl aon cheann,
        // déileáil leis an gcás sin in std::panicking::default_hook agus std::panicking::begin_panic_fmt.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: ní féidir linn downcast_ref a úsáid: :<String>() anseo
        // Níl ós rud é Teaghrán fáil in libcore!
        // Is Teaghrán an t-ualach pá nuair a ghlaoitear `std::panic!` le hargóintí iomadúla, ach sa chás sin tá an teachtaireacht ar fáil freisin.
        //

        self.location.fmt(formatter)
    }
}

/// A struct bhfuil faisnéis maidir leis an suíomh de panic.
///
/// Tá an struchtúr cruthaithe ag [`PanicInfo::location()`].
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Déantar comparáidí maidir le comhionannas agus ordú i gcomhad, líne, agus ansin tosaíocht an cholúin.
/// Cuirtear comhaid i gcomparáid mar teaghráin, ní `Path`, a d`fhéadfadh a bheith gan choinne.
/// Féach cáipéisíocht [`Suíomh: : comhad`] le haghaidh tuilleadh plé.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Filleann sé suíomh foinse ghlaoiteoir na feidhme seo.
    /// Má tá glaoiteoir na feidhme sin anótáilte ansin cuirfear a suíomh glaonna ar ais, agus mar sin de suas an chruach go dtí an chéad ghlao laistigh de chomhlacht feidhme neamh-rianaithe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Filleann sé an [`Location`] ar a dtugtar.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Tuairisceáin a [`Location`], ón suim seo sainmhíniú.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // tugann an fheidhm chéanna neamh-scáinte a reáchtáil in áit dhifriúil an toradh céanna dúinn
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // tá luach difriúil ag rith na feidhme rianaithe in áit dhifriúil
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// Tuairisceáin an t-ainm an chomhaid fhoinse óna bhfuarthas na panic tháinig.
    ///
    /// # `&str`, ní `&Path`
    ///
    /// Tagraíonn an t-ainm a cuireadh ar ais do chonair foinse ar an gcóras tiomsúcháin, ach níl sé bailí é seo a léiriú go díreach mar `&Path`.
    /// Féadfaidh an cód tiomsaithe a bheith ag rith ar chóras difriúil le cur chun feidhme `Path` difriúil seachas an córas a sholáthraíonn an t-ábhar agus níl cineál "host path" difriúil ag an leabharlann seo faoi láthair.
    ///
    /// Tarlaíonn an t-iompar is iontaí nuair a bhíonn comhad "the same" inrochtana trí ilbhealaí sa chóras modúl (ag baint úsáide as an aitreabúid `#[path = "..."]` nó a mhacasamhail de ghnáth), rud a d`fhéadfadh a bheith ina chúis leis an gcód comhionann le luachanna difriúla ón bhfeidhm seo a thabhairt ar ais.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Ní hé seo an luach oiriúnach do rith do `Path::new` nó constructors dá samhail nuair a bheidh an ardán óstach agus ardán sprioc difriúil.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// Filleann sé an uimhir líne as ar tháinig an panic.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// Filleann sé an colún as ar tháinig an panic.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// trait inmheánach a úsáideann libstd chun sonraí a aistriú ó libstd go `panic_unwind` agus rith-amanna panic eile.
/// Gan a bheith beartaithe a chobhsú am ar bith go luath, ná húsáid.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Tóg úinéireacht iomlán ar an ábhar.
    /// Is é an cineál tuairisceáin `Box<dyn Any + Send>` i ndáiríre, ach ní féidir linn `Box` a úsáid i libcore.
    ///
    /// Tar éis an modh seo a ghlaoch, níl fágtha ach roinnt luach réamhshocraithe caocha in `self`.
    /// Is botún é an modh seo a ghlaoch faoi dhó, nó `get` a ghlaoch tar éis an modh seo a ghlaoch.
    ///
    /// Faightear an argóint ar iasacht toisc nach bhfaigheann an runtime panic (`__rust_start_panic`) ach `dyn BoxMeUp` a fuarthas ar iasacht.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Just a fháil ar iasacht an t-ábhar.
    fn get(&mut self) -> &(dyn Any + Send);
}