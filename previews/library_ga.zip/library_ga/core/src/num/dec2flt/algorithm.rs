//! Na halgartaim éagsúla ón bpáipéar.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Líon na ngiotán suntasacha in Fp
const P: u32 = 64;

// Ní dhéanaimid ach an comhfhogasú is fearr a stóráil do *gach* taispeántóir, ionas gur féidir an athróg "h" agus na coinníollacha gaolmhara a fhágáil ar lár.
// Ceirdeann sé seo feidhmíocht ar feadh cúpla cileavata spáis.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// I bhformhór na n-ailtireachtaí, tá méid giotán follasach ag oibríochtaí snámhphointe, dá bhrí sin déantar beachtas an ríomha a chinneadh ar bhonn oibríochta.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Ar x86, úsáidtear an x87 FPU le haghaidh oibríochtaí snámhphointe mura bhfuil na síntí SSE/SSE2 ar fáil.
// Feidhmíonn an x87 FPU le 80 giotán beachtais de réir réamhshocraithe, rud a chiallaíonn go slánóidh oibríochtaí go 80 giotán rud a fhágfaidh go dtarlóidh slánú dúbailte nuair a léirítear luachanna sa deireadh mar
//
// 32/64 luachanna snámhphointe giotán.Chun é sin a shárú, is féidir an focal rialaithe FPU a shocrú ionas go gcomhlíonfar na ríomhanna sa chruinneas atá ag teastáil.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Struchtúr a úsáidtear chun luach bunaidh an fhocail rialaithe FPU a chaomhnú, ionas gur féidir é a athshlánú nuair a thittear an struchtúr.
    ///
    ///
    /// Is clár 16 ghiotán é an x87 FPU a bhfuil a réimsí mar seo a leanas:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Tá an cháipéisíocht do na réimsí uile ar fáil i Lámhleabhar Forbróir Bogearraí Ailtireachta IA-32 (Imleabhar 1).
    ///
    /// Is é an t-aon réimse atá ábhartha don chód seo a leanas ná ríomhaire, Beachtas Control.
    /// Cinneann an réimse seo beachtas na n-oibríochtaí a dhéanann an FPU.
    /// Is féidir é a shocrú do:
    ///  - 0b00, cruinneas aonair ie, 32-giotán
    ///  - 0b10, cruinneas dúbailte ie, 64-giotán
    ///  - 0b11, beachtas leathnaithe dúbailte ie, 80-giotán (stát réamhshocraithe) Tá an luach 0b01 curtha in áirithe agus níor cheart é a úsáid.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SÁBHÁILTEACHT: rinneadh iniúchadh ar an treoir `fldcw` le go mbeifeá in ann oibriú i gceart leis
        // aon `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Táimid ag úsáid chomhréir ATT chun tacú le LLVM 8 agus LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Socraíonn sé réimse beachtais an FPU go `T` agus seoltar `FPUControlWord` ar ais.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Ríomh an luach don réimse um Rialú Beachtas atá oiriúnach do `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 giotán
            8 => 0x0200, // 64 giotán
            _ => 0x0300, // réamhshocraithe, 80 giotán
        };

        // Faigh luach bunaidh an fhocail rialaithe chun é a chur ar ais níos déanaí, nuair a thitfear an struchtúr `FPUControlWord` SÁBHÁILTEACHT: rinneadh iniúchadh ar an treoir `fnstcw` le go mbeadh sé in ann oibriú i gceart le haon `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Táimid ag úsáid chomhréir ATT chun tacú le LLVM 8 agus LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Socraigh an focal rialaithe go beacht is mian leat.
        // Baintear é seo amach tríd an sean-chruinneas (giotáin 8 agus 9, 0x300) a cheilt agus an bhratach beachtais a ríomhtar thuas a chur ina hionad.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Conair thapa Bellerophon ag úsáid slánuimhreacha agus snámháin meánmhéide.
///
/// Baintear é seo i bhfeidhm ar leithligh ionas gur féidir iarracht a dhéanamh sula ndéantar bignum a thógáil.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Déanaimid comparáid idir an luach cruinn agus MAX_SIG gar don deireadh, níl anseo ach diúltú tapa, saor (agus saoradh an chuid eile den chód ó bheith buartha faoi shreabhadh).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Braitheann an cosán gasta go ríthábhachtach ar uimhríocht a shlánú go dtí an líon ceart giotán gan aon chothromú idirmheánach.
    // Ar x86 (gan SSE nó SSE2) éilíonn sé seo beachtas an chairn x87 FPU a athrú ionas go mbeidh sé cruinn go díreach chuig giotán 64/32.
    // Déanann feidhm `set_precision` cúram an cruinneas a leagan síos ar ailtireachtaí a éilíonn é a shocrú tríd an stát domhanda a athrú (cosúil le focal rialaithe an x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Ní féidir an cás e <0 a fhilleadh isteach sa branch eile.
    // Mar thoradh ar chumhachtaí diúltacha tá cuid chodánach athrá i ndénártha, a dhéantar a shlánú, rud a fhágann go mbíonn earráidí réadacha (agus uaireanta suntasacha go leor!) Sa toradh deiridh.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algartam Bellerophon Is cód fánach é a bhfuil údar maith leis trí anailís uimhriúil neamhfhánach.
///
/// Déanann sé ``f`` a shlánú go snámhphointe le suntasacht 64 giotán agus é a iolrú faoin gcomhfhogasú is fearr de `10^e` (san fhormáid snámhphointe céanna).Is minic gur leor é seo chun an toradh ceart a fháil.
/// Mar sin féin, nuair a bhíonn an toradh gar do leathbhealach idir dhá shnámh (ordinary) cóngarach, ciallaíonn an earráid chothromú cumaisc ó dhá chomhfhogasú a iolrú go bhféadfadh an toradh a bheith réidh le cúpla giotán.
/// Nuair a tharlaíonn sé seo, socraíonn an Algartam atriallach R rudaí suas.
///
/// Déantar an lámh-tonnach "close to halfway" go beacht leis an anailís uimhriúil sa pháipéar.
/// I bhfocail Clinger:
///
/// > Tá fána, arna shloinneadh in aonaid den ghiotán is lú suntasaí, faoi cheangal chuimsitheach don earráid
/// > carntha le linn ríomh snámhphointe an chomhfhogasú go f * 10 ^ e.(Tá fána
/// > ní faoi cheangal na fíor-earráide, ach déanann sé an difríocht idir an comhfhogasú z agus
/// > an comhfhogasú is fearr is féidir a úsáideann giotaí suntasacha agus suntasacha.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Tá na cásanna abs(e) <log5(2^N) in fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // An bhfuil an fána mór go leor chun difríocht a dhéanamh agus é ag slánú go giotáin?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Algartam atriallach a fheabhsaíonn comhfhogasú snámhphointe `f * 10^e`.
///
/// Faigheann gach atriall aonad amháin san áit dheireanach níos gaire, ar ndóigh tógann sé an-fhada teacht le chéile má bhíonn `z0` beagáinín éadrom fiú.
/// Ar ámharaí an tsaoil, nuair a úsáidtear é mar chúltaca do Bellerophon, tá an comhfhogasú tosaigh réidh le ULP amháin ar a laghad.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Faigh slánuimhreacha dearfacha `x`, `y` sa chaoi is go bhfuil `x / y` go díreach `(f *10^e) / (m* 2^k)`.
        // Ní amháin go seachnaíonn sé seo déileáil le comharthaí `e` agus `k`, cuirimid deireadh freisin le cumhacht dhá cheann is coiteann do `10^e` agus `2^k` chun na huimhreacha a dhéanamh níos lú.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Scríobhtar é seo beagán awkwardly toisc nach dtacaíonn ár bignums le huimhreacha diúltacha, mar sin bainimid úsáid as an luach iomlán + faisnéis sínithe.
        // Ní féidir leis an iolrú le m_digits cur thar maoil.
        // Má tá `x` nó `y` mór go leor go gcaithfimid a bheith buartha faoi ró-shreabhadh, ansin tá siad mór go leor freisin gur laghdaigh `make_ratio` an codán le fachtóir 2 ^ 64 nó níos mó.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Ná x níos mó uait, sábháil clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Fós ag teastáil y, déan cóip.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Má thugtar `x = f` agus `y = m` sa chás go léiríonn `f` digití deachúil ionchuir mar is gnách agus gurb é `m` an suntas agus comhfhogasú le snámhphointe, déan an cóimheas `x / y` cothrom le `(f *10^e) / (m* 2^k)`, b`fhéidir é a laghdú le cumhacht dhá cheann atá i gcoiteann ag an dá cheann.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, ach amháin go laghdaímid an codán le cumhacht éigin de dhá.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Ní féidir leis seo cur thar maoil toisc go dteastaíonn `e` dearfach agus `k` diúltach uaidh, rud nach féidir a tharlú ach do luachanna atá an-ghar do 1, rud a chiallaíonn go mbeidh `e` agus `k` measartha beag bídeach.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Ní féidir leis seo cur thar maoil ach an oiread, féach thuas.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), ag laghdú arís le comhchumhacht dhá.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Go coincheapúil, is é Algartam M an bealach is simplí chun deachúil a thiontú go snámhán.
///
/// Cruthaímid cóimheas atá cothrom le `f * 10^e`, ansin caithimid cumhachtaí de dhá cheann go dtí go dtugann sé suntasacht snámhphointe bailí.
/// Is é an t-easpónant dénártha `k` an líon uaireanta a iolraíomar uimhreoir nó ainmneoir faoi dhó, ie, is ionann `f *10^e` agus `(u / v)* 2^k` i gcónaí.
/// Nuair a fuaireamar amach suntas agus ní gá dúinn ach an chuid eile den rannán a iniúchadh, a dhéantar i bhfeidhmeanna cúntóirí níos faide thíos.
///
///
/// Tá an algartam seo thar a bheith mall, fiú leis an optamú a thuairiscítear i `quick_start()`.
/// Mar sin féin, is é an ceann is simplí de na halgartaim é a oiriúnú le haghaidh torthaí thar maoil, ró-shreafa agus torthaí neamhghnácha.
/// Glacann an cur chun feidhme seo seilbh air nuair a bhíonn Bellerophon agus Algartam R sáraithe.
/// Is furasta an ró-shreabhadh agus an ró-shreabhadh a bhrath: Níl an cóimheas fós ina thábhacht laistigh den raon, ach tá an t-easpónant minimum/maximum sroichte.
/// I gcás ró-shreabha, ní dhéanaimid ach an Infinity a thabhairt ar ais.
///
/// Tá sé níos deacra sreabhadh faoi shreabhadh agus fo-fhoirmle a láimhseáil.
/// Fadhb mhór amháin is ea go bhféadfadh an cóimheas a bheith ró-mhór le haghaidh suntasachta, agus an t-íosmhéid easpónantóra aige.
/// Féach underflow() le haghaidh sonraí.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // Optamú féideartha FIXME: ginearálú big_to_fp ionas gur féidir linn a choibhéis fp_to_float(big_to_fp(u)) a dhéanamh anseo, gan an chothromú dúbailte a dhéanamh.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Ní mór dúinn stopadh ag an easpónant is lú, má fhanfaimid go dtí `k < T::MIN_EXP_INT`, ansin bheimis faoi fhachtóir a dó.
            // Ar an drochuair, ciallaíonn sé seo go gcaithfimid gnáthuimhreacha a chásáil go speisialta agus an t-íosmhéid easpónantóra acu.
            // Faigh FIXME foirmliú níos galánta, ach rith an tástáil `tiny-pow10` chun a chinntiú go bhfuil sé ceart i ndáiríre!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Scipeáil thar fhormhór na dtreoracha Algartam M trí fhad an ghiotáin a sheiceáil.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Is é an fad giotán meastachán ar an mbonn dhá logarithm, agus log(u / v) = log(u), log(v).
    // Déantar an meastachán a laghdú 1 ar a laghad, ach gannmheastachán i gcónaí, mar sin tá an earráid ar log(u) agus log(v) den chomhartha céanna agus cealaítear amach (má tá an dá cheann mór).
    // Dá bhrí sin tá an earráid le haghaidh log(u / v) ar a laghad freisin.
    // Is é an sprioc-chóimheas ceann ina bhfuil u/v i réimse suntasach agus.Mar sin is é ár riocht foirceanta gurb é log2(u / v) na giotáin suntasacha agus plus/minus amháin.
    // FIXME D`fhéadfadh féachaint ar an dara giotán an meastachán a fheabhsú agus roinnt rannán eile a sheachaint.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Sreabhadh nó subnormal.Fág é go dtí an phríomhfheidhm.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Thar maoil.Fág é go dtí an phríomhfheidhm.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Ní hionann an cóimheas agus an t-íosmhéid easpónantóra, mar sin caithfimid giotáin iomarcacha a shlánú agus an t-easpónant a choigeartú dá réir.
    // Breathnaíonn an fíorluach mar seo anois:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(arna léiriú ag rem)
    //
    // Dá bhrí sin, nuair a bhíonn na giotáin chothromú!= 0.5 ULP, socraíonn siad an slánú leo féin.
    // Nuair atá siad cothrom agus an fuílleach neamh-nialasach, is gá an luach a shlánú fós.
    // Ach amháin nuair a bhíonn na giotáin chothromú 1/2 agus an chuid eile nialas, bíonn cás leath go cothrom againn.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Gnáth-chothromú go cothrom, géilleadh dó trí bhabhta a dhéanamh bunaithe ar an gcuid eile de roinn.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}