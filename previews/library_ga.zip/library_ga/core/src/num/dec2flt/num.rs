//! Feidhmeanna fóntais do bignums nach bhfuil an iomarca ciall acu modhanna a iompú.

// FIXME Tá ainm an mhodúil seo rud beag trua, ós rud é go n-allmhairíonn modúil eile `core::num` freisin.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Tástáil cibé an dtugann earráid choibhneasta níos lú, cothrom, nó níos mó ná 0.5 ULP, isteach gach giotán nach bhfuil chomh suntasach ná `ones_place`.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Más nialas na giotáin atá fágtha, is é= 0.5 ULP, ar shlí eile> 0.5 Mura bhfuil níos mó giotán ann (half_bit==0), filleann an méid seo thíos Comhionann i gceart freisin.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Athraíonn sé sreang ASCII nach bhfuil ann ach digití deachúil go `u64`.
///
/// Ní dhéanann sé seiceálacha ar charachtair thar maoil nó neamhbhailí, mar sin mura bhfuil an té atá ag glaoch cúramach, tá an toradh bréagach agus féadann sé panic (cé nach `unsafe` a bheidh ann).
/// Ina theannta sin, caitear le teaghráin fholamh mar nialas.
/// Tá an fheidhm seo ann mar gheall ar
///
/// 1. ag baint úsáide as `FromStr` ar `&[u8]` teastaíonn `from_utf8_unchecked`, atá go dona, agus
/// 2. tá sé níos casta torthaí `integral.parse()` agus `fractional.parse()` a chur le chéile ná an fheidhm iomlán seo.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Tiontaíonn sreangán de dhigit ASCII ina bignum.
///
/// Cosúil le `from_str_unchecked`, braitheann an fheidhm seo ar an bparsálaí chun fiaigh a dhéanamh ar neamh-dhigit.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Unwraps bignum i slánuimhir 64 giotán.Panics má tá an uimhir ró-mhór.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Sleachta raon giotán.

/// Is é Innéacs 0 an giotán is lú suntasaí agus tá an raon leath-oscailte mar is gnách.
/// Panics má iarrtar ort níos mó giotán a bhaint ná a bheith oiriúnach don chineál tuairisceáin.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}