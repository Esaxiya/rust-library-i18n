//! Fiddling giotán ar shnámháin dearfacha IEEE 754.Ní gá agus ní gá uimhreacha diúltacha a láimhseáil.
//! Tá léiriú canónach ag gnáthuimhreacha snámhphointe mar (frac, exp) sa chaoi is gurb é an luach 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) áit arb é N líon na ngiotán.
//!
//! Tá fo-ábhair beagán difriúil agus aisteach, ach tá an prionsabal céanna i bhfeidhm.
//!
//! Anseo, áfach, déanaimid ionadaíocht orthu mar (sig, k) le f dearfach, sa chaoi is go bhfuil an luach f *
//! 2 <sup>e</sup> .Seachas an "hidden bit" a dhéanamh follasach, athraíonn sé seo an t-easpónant leis an aistriú mantissa mar a thugtar air.
//!
//! Cuir bealach eile, de ghnáth scríobhtar snámháin mar (1) ach anseo scríobhtar iad mar (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Glaoimid (1) ar an **léiriú codánach** agus (2) mar an **léiriú lárnach**.
//!
//! Ní dhéileálann go leor feidhmeanna sa mhodúl seo ach gnáthuimhreacha.Glacann na gnáthaimh dec2flt go coimeádach an cosán mall atá ceart go huilíoch (Algartam M) do líon an-bheag agus an-mhór.
//! Níl ach next_float() de dhíth ar an algartam sin a dhéileálann le fo-ábhair agus nialais.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Cúntóir trait chun dúbailt bunúsach an chóid chomhshó go léir do `f32` agus `f64` a sheachaint.
///
/// Féach trácht doc an mhodúil tuismitheora ar an bhfáth go bhfuil sé sin riachtanach.
///
/// Níor cheart **riamh** a chur i bhfeidhm do chineálacha eile nó a úsáid lasmuigh den mhodúl dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Cineál a úsáideann `to_bits` agus `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Déanann sé tras-aistriú amh go slánuimhir.
    fn to_bits(self) -> Self::Bits;

    /// Déanann sé tras-aistriú amh ó shlánuimhir.
    fn from_bits(v: Self::Bits) -> Self;

    /// Filleann sé an chatagóir a mbaineann an uimhir seo léi.
    fn classify(self) -> FpCategory;

    /// Filleann sé an mantissa, an t-easpónant agus sínigh mar shlánuimhreacha é.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Díchódaíonn an snámh.
    fn unpack(self) -> Unpacked;

    /// Caisleáin ó shlánuimhir bheag ar féidir a léiriú go díreach.
    /// Panic mura féidir an tslánuimhir a léiriú, déanann an cód eile sa mhodúl seo cinnte nach ligfidh sé sin dó tarlú.
    fn from_int(x: u64) -> Self;

    /// Faigheann an luach 10 <sup>e</sup> ó thábla réamh-ríofa.
    /// Panics do `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Cad a deir an t-ainm.
    /// Tá sé níos éasca cód crua a dhéanamh ná juggling intrinsics agus tá súil agam go bhfillfidh LLVM go leanúnach air.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Coimeádaí atá ceangailte ar dhigit deachúil na n-ionchur nach féidir leo ró-shreabhadh nó nialas a tháirgeadh nó
    /// subnormals.Is dócha gurb é an t-easpónant deachúil an gnáthluach uasta, mar sin an t-ainm.
    const MAX_NORMAL_DIGITS: usize;

    /// Nuair a bhíonn luach áite níos mó ná seo ag an dhigit deachúil is suntasaí, is cinnte go ndéantar an uimhir a shlánú go héigríoch.
    ///
    const INF_CUTOFF: i64;

    /// Nuair a bhíonn luach áite níos lú ná seo ag an dhigit deachúil is suntasaí, is cinnte go ndéantar an uimhir a shlánú go nialas.
    ///
    const ZERO_CUTOFF: i64;

    /// Líon na ngiotán san easpónant.
    const EXP_BITS: u8;

    /// Líon na ngiotán sa suntas agus,*lena n-áirítear* an giotán i bhfolach.
    const SIG_BITS: u8;

    /// Líon na ngiotán sa suntas agus,*gan* an giotán i bhfolach a áireamh.
    const EXPLICIT_SIG_BITS: u8;

    /// An t-uasmhéadaitheoir dlíthiúil in ionadaíocht chodánach.
    const MAX_EXP: i16;

    /// An t-easpónant dlíthiúil íosta in ionadaíocht chodánach, seachas fo-ábhair.
    const MIN_EXP: i16;

    /// `MAX_EXP` le haghaidh ionadaíochta iomláine, ie, leis an athrú a chuirtear i bhfeidhm.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` ionchódaithe (ie, le claonadh fritháireamh)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` le haghaidh ionadaíochta iomláine, ie, leis an athrú a chuirtear i bhfeidhm.
    const MIN_EXP_INT: i16;

    /// An t-uasmhéid normalaithe normalaithe in ionadaíocht dhílis.
    const MAX_SIG: u64;

    /// An suntasacht normalaithe íosta agus an ionadaíocht dhílis.
    const MIN_SIG: u64;
}

// Oibre den chuid is mó do #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Filleann sé an mantissa, an t-easpónant agus sínigh mar shlánuimhreacha é.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Claonadh léiritheoir + aistriú mantissa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // níl rkruppe cinnte an bhfuil babhtaí `as` i gceart ar gach ardán.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Filleann sé an mantissa, an t-easpónant agus sínigh mar shlánuimhreacha é.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Claonadh léiritheoir + aistriú mantissa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // níl rkruppe cinnte an bhfuil babhtaí `as` i gceart ar gach ardán.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Tiontaíonn sé `Fp` go dtí an cineál snámhphointe meaisín is gaire.
/// Ní dhéileálann le torthaí neamhghnácha.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f is 64 giotán é, mar sin tá aistriú mantissa de 63 ag xe
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Babhta na giotán 64-giotán agus giotáin T::SIG_BITS le leath-go-cothrom.
/// Ní dhéileálann le ró-shreabhadh easpónantóra.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Coigeartaigh aistriú mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Inbhéartach `RawFloat::unpack()` d`uimhreacha normalaithe.
/// Panics mura bhfuil an suntasacht nó an t-easpónant bailí d`uimhreacha normalaithe.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Bain an giotán i bhfolach
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Coigeartaigh an t-easpónant le haghaidh claontacht easpónantúil agus aistriú mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Fág giota comhartha ag 0 ("+"), tá ár líon dearfach ar fad
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Tóg fo-neamhghnácha.Ceadaítear mantissa de 0 agus tógann sé nialas.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Is é 0 an t-easpónantóir ionchódaithe, is é 0 an giotán comhartha, mar sin ní mór dúinn na giotáin a athmhíniú.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Déan bignum a chomhfhogasú le Fp.Babhtaí laistigh de 0.5 ULP le leath go cothrom.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Gearrann muid amach na giotáin go léir roimh an innéacs `start`, ie, déanaimid athrú ceart i ndáiríre de mhéid `start`, mar sin is é seo an t-easpónant a theastaíonn uainn freisin.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Babhta (half-to-even) ag brath ar na giotáin teasctha.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Faightear an uimhir snámhphointe is mó go hiomlán níos lú ná an argóint.
/// Ní dhéileálann le subnormals, nialas, nó faoi shreabhadh easpónantóra.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Faigh an uimhir snámhphointe is lú go docht níos mó ná an argóint.
// Tá an oibríocht seo sáithithe, ie, next_float(inf) ==inf.
// Murab ionann agus an chuid is mó de chód an mhodúil seo, ní láimhseáiltear an fheidhm seo nialas, fo-fhoirmlí agus infinities.
// Mar sin féin, cosúil le gach cód eile anseo, ní dhéileálann sé le NaN agus le huimhreacha diúltacha.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Dealraíonn sé go bhfuil sé seo ró-mhaith le bheith fíor, ach oibríonn sé.
        // 0.0 ionchódaithe mar an focal uile-nialasach.Tá fo-ábhair 0x000m ... m áit arb é m an mantissa.
        // Go háirithe, is é 0x0 ... 01 an fo-neamhghnácha is lú agus is é 0x000F an ceann is mó ... F.
        // Is é 0x0010 ... 0 an gnáthuimhir is lú, mar sin oibríonn an cás cúinne seo freisin.
        // Má sháraíonn an t-incrimint an mantissa, méadaíonn an giotán iompair an t-easpónant mar is mian linn, agus éiríonn na giotáin mantissa nialas.
        // Mar gheall ar choinbhinsiún na ngiotán i bhfolach, is é seo go díreach a theastaíonn uainn!
        // Mar fhocal scoir, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}