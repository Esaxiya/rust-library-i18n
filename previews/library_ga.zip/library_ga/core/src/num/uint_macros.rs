macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// An luach is lú is féidir a léiriú leis an gcineál slánuimhir seo.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// An luach is mó is féidir a léiriú leis an gcineál slánuimhir seo.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Méid an chineáil slánuimhir seo i ngiotán.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Tiontaíonn sé sreangán i mbonn ar leith go slánuimhir.
        ///
        /// Táthar ag súil go mbeidh an sreangán ina chomhartha roghnach `+` agus digití ina dhiaidh sin.
        ///
        /// Is botún é an spás bán a threorú agus a rianú.
        /// Is fo-thacar de na carachtair seo digití, ag brath ar `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Feidhm panics mura bhfuil `radix` sa raon ó 2 go 36.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Filleann sé líon na ndaoine i léiriú dénártha `self`.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Filleann sé líon na nialais i léiriú dénártha `self`.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Filleann sé líon na nialais tosaigh i léiriú dénártha `self`.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Filleann sé líon na nialais rianaithe i léiriú dénártha `self`.
        ///
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Filleann sé líon na gceann tosaigh i léiriú dénártha `self`.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Filleann sé líon na ndaoine atá ag tarraingt i léiriú dénártha `self`.
        ///
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Athraíonn na giotáin ar chlé le méid sonraithe, `n`, ag timfhilleadh na ngiotán teasctha go dtí deireadh an tslánuimhir a leanann dá bharr.
        ///
        ///
        /// Tabhair faoi deara nach é seo an oibríocht chéanna mar oibreoir aistriú `<<`!
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Athraíonn na giotáin ar dheis de mhéid sonraithe, `n`, ag timfhilleadh na ngiotán teasctha go dtí tús an tslánuimhir a leanann dá bharr.
        ///
        ///
        /// Tabhair faoi deara nach é seo an oibríocht chéanna leis an oibreoir aistrithe `>>`!
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Aisiompaíonn ord beart an tslánuimhir.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// lig m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Aisiompaíonn ord na ngiotán sa slánuimhir.
        /// Is é an giotán is suntasaí an giotán is suntasaí, is é an dara giotán is suntasaí an dara giotán is suntasaí, srl.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// lig m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Athraíonn sé slánuimhir ó endian mór go endianness an sprioc.
        ///
        /// Ar an endian mór is no-op é seo.
        /// Ar endian beag malartaítear na bearta.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// más cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } eile {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Athraíonn sé slánuimhir ó bheagán endian go seasmhacht an sprioc.
        ///
        /// Ar endian beag tá sé seo le aon-op.
        /// Ar endian mór malartaítear na bearta.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// más cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } eile {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Athraíonn sé `self` go endian mór ó endianness an sprioc.
        ///
        /// Ar an endian mór is no-op é seo.
        /// Ar endian beag malartaítear na bearta.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// más cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } eile { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // nó gan a bheith?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Athraíonn sé `self` go endian beag ó endianness an sprioc.
        ///
        /// Ar endian beag tá sé seo le aon-op.
        /// Ar endian mór malartaítear na bearta.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// más cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } eile { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Breisiú slánuimhir seiceáilte.
        /// Computes `self + rhs`, ag filleadh `None` má tharla an ró-shreabhadh.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Breisiú slánuimhir neamhsheiceáilte.Computes `self + rhs`, ag glacadh leis nach féidir an ró-shreabhadh a tharlú.
        /// Bíonn iompar neamhshainithe mar thoradh air seo nuair a
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `unchecked_add` a sheasamh.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Dealú slánuimhir seiceáilte.
        /// Computes `self - rhs`, ag filleadh `None` má tharla an ró-shreabhadh.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Dealú slánuimhir neamhsheiceáilte.Ríomhann `self - rhs`, ní féidir glacadh leis overflow tarlú.
        /// Bíonn iompar neamhshainithe mar thoradh air seo nuair a
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `unchecked_sub` a sheasamh.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Iolrú slánuimhir seiceáilte.
        /// Computes `self * rhs`, ag filleadh `None` má tharla an ró-shreabhadh.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Iolrú slánuimhir neamhsheiceáilte.Computes `self * rhs`, ag glacadh leis nach féidir an ró-shreabhadh a tharlú.
        /// Bíonn iompar neamhshainithe mar thoradh air seo nuair a
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `unchecked_mul` a sheasamh.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Rannán slánuimhir seiceáilte.
        /// Computes `self / rhs`, ag filleadh `None` más `rhs == 0` é.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SÁBHÁILTEACHT: seiceáladh div faoi nialas thuas agus níl cineálacha eile sínithe ag aon cheann eile
                // modhanna teip le haghaidh roinnte
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Rannán Euclidean Seiceáilte.
        /// Computes `self.div_euclid(rhs)`, ag filleadh `None` más `rhs == 0` é.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Fuílleach slánuimhir seiceáilte.
        /// Computes `self % rhs`, ag filleadh `None` más `rhs == 0` é.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SÁBHÁILTEACHT: seiceáladh div faoi nialas thuas agus níl cineálacha eile sínithe ag aon cheann eile
                // modhanna teip le haghaidh roinnte
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// modulo Eoiclídeach Checked.
        /// Computes `self.rem_euclid(rhs)`, ag filleadh `None` más `rhs == 0` é.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Faillí seiceáilte.Computes `-self`, ag filleadh `None` mura `self==
        /// 0`.
        ///
        /// Tabhair faoi deara go mbeidh faillí ar aon slánuimhir dearfach ag cur thar maoil.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Seiceáil seiceáilte ar chlé.
        /// Computes `self << rhs`, ag filleadh `None` má tá `rhs` níos mó ná nó cothrom le líon na ngiotán in `self`.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Seiceáil seiceáilte ceart.
        /// Computes `self >> rhs`, ag filleadh `None` má tá `rhs` níos mó ná nó cothrom le líon na ngiotán in `self`.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Taispeántas seiceála.
        /// Computes `self.pow(exp)`, ag filleadh `None` má tharla an ró-shreabhadh.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // ó exp!=0, sa deireadh caithfidh an exp a bheith 1.
            // Déileáil le giotán deiridh an easpónantóra ar leithligh, ós rud é nach gá an bonn a scuadáil ina dhiaidh sin agus d`fhéadfadh go mbeadh ró-shreabhadh gan ghá ann.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Suim slánuimhir a shásamh.
        /// Computes `self + rhs`, sáithithe ag na teorainneacha uimhriúla in ionad cur thar maoil.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Dealú slánuimhir slánuimhir.
        /// Computes `self - rhs`, sáithithe ag na teorainneacha uimhriúla in ionad cur thar maoil.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Iolrú slánuimhir slánuimhir.
        /// Computes `self * rhs`, sáithithe ag na teorainneacha uimhriúla in ionad cur thar maoil.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Exponentiation slánuimhir sáithithe.
        /// Computes `self.pow(exp)`, sáithithe ag na teorainneacha uimhriúla in ionad cur thar maoil.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Filleadh (modular) breiseán.
        /// Ríomhann `self + rhs`, timfhilleadh timpeall ar an teorainn den chineál.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Dealú (modular) a fhilleadh.
        /// Computes `self - rhs`, ag timfhilleadh timpeall ag teorainn an chineáil.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Iolrú (modular) a fhilleadh.
        /// Computes `self * rhs`, ag timfhilleadh timpeall ag teorainn an chineáil.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// Tabhair faoi deara le do thoil go roinntear an sampla seo idir cineálacha slánuimhir.
        /// A mhíníonn cén fáth a n-úsáidtear `u8` anseo.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Filleadh rannán (modular).Computes `self / rhs`.
        /// Níl sa rannán fillte ar chineálacha neamhshínithe ach gnáthroinnt.
        /// Níl aon bhealach ann go bhféadfadh timfhilleadh tarlú riamh.
        /// Is ann don fheidhm, ionas go bhfuil na hoibríochtaí cuntas orthu sa oibríochtaí timfhilleadh.
        ///
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Rannán Eoiclídeach a Fhilleadh.Computes `self.div_euclid(rhs)`.
        /// Níl sa rannán fillte ar chineálacha neamhshínithe ach gnáthroinnt.
        /// Níl aon bhealach ann go bhféadfadh timfhilleadh tarlú riamh.
        /// Is ann don fheidhm, ionas go bhfuil na hoibríochtaí cuntas orthu sa oibríochtaí timfhilleadh.
        /// Ós rud é, maidir leis na slánuimhreacha dearfacha, go bhfuil na sainmhínithe comónta go léir ar roinnt cothrom, tá sé seo cothrom le `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Fuílleach (modular) a fhilleadh.Computes `self % rhs`.
        /// Níl sa ríomh fuílleach fillte ar chineálacha neamhshínithe ach an ríomh fuílleach rialta.
        ///
        /// Níl aon bhealach ann go bhféadfadh timfhilleadh tarlú riamh.
        /// Is ann don fheidhm, ionas go bhfuil na hoibríochtaí cuntas orthu sa oibríochtaí timfhilleadh.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Modulo Eoiclídeach a Fhilleadh.Computes `self.rem_euclid(rhs)`.
        /// Is Fillte ríomh modulo ar chineálacha gan síniú ach an ríomh eile rialta.
        /// Níl aon bhealach ann go bhféadfadh timfhilleadh tarlú riamh.
        /// Is ann don fheidhm, ionas go bhfuil na hoibríochtaí cuntas orthu sa oibríochtaí timfhilleadh.
        /// Ós rud é, do na slánuimhreacha deimhneacha, tá gach comhshainiú ar na cineálacha comhionannas Sin go díreach ionann agus `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Faillí (modular) a fhilleadh.
        /// Computes `-self`, ag timfhilleadh timpeall ag teorainn an chineáil.
        ///
        /// Ós rud é nach bhfuil coibhéisí diúltacha ag cineálacha neamhshínithe, timfhillfidh gach feidhm den fheidhm seo (seachas `-0`).
        /// Maidir le luachanna níos lú ná uasmhéid an chineáil shínithe chomhfhreagraigh tá an toradh mar an gcéanna leis an luach sínithe comhfhreagrach a chaitheamh.
        ///
        /// Is ionann aon luachanna níos mó agus `MAX + 1 - (val - MAX - 1)` áit arb é `MAX` uasmhéid an chineáil shínithe chomhfhreagraigh.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// Tabhair faoi deara le do thoil go roinntear an sampla seo idir cineálacha slánuimhir.
        /// A mhíníonn cén fáth a n-úsáidtear `i8` anseo.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-saor ó aistriú bitwise ar chlé;
        /// táirgeacht `self << mask(rhs)`, i gcás ina gcuireann `mask` deireadh le haon ghiotáin ardoird de `rhs` a d`fhágfadh go sáródh an t-aistriú giotán an chineáil.
        ///
        /// Tabhair faoi deara nach ionann é seo * agus rothlú ar chlé;tá an RHS de fhilleadh fillte ar chlé teoranta do raon an chineáil, seachas na giotáin a aistrítear as an LHS a thabhairt ar ais go dtí an ceann eile.
        /// Cuireann na cineálacha slánuimhir primitive feidhm [`rotate_left`](Self::rotate_left) i bhfeidhm, agus b`fhéidir gurb é sin a theastaíonn uait ina ionad.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SÁBHÁILTEACHT: cinntíonn an cumasc de réir giotáin an chineáil nach n-aistrímid
            // as teorainneacha
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-saor ó aistriú bitwise ar dheis;
        /// táirgeacht `self >> mask(rhs)`, i gcás ina gcuireann `mask` deireadh le haon ghiotáin ardoird de `rhs` a d`fhágfadh go sáródh an t-aistriú giotán an chineáil.
        ///
        /// Tabhair faoi deara nach ionann é seo agus * ceart rothlach;an RHS de timfhilleadh athrú-ceart teoranta do réimse den chineál, in ionad na píosaí bhog amach na LHS á seoladh ar ais chuig an taobh eile.
        /// Cuireann na cineálacha slánuimhir primitive feidhm [`rotate_right`](Self::rotate_right) i bhfeidhm, agus b`fhéidir gurb é sin a theastaíonn uait ina ionad.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SÁBHÁILTEACHT: cinntíonn an cumasc de réir giotáin an chineáil nach n-aistrímid
            // as teorainneacha
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Filleadh (modular) fillte.
        /// Computes `self.pow(exp)`, ag timfhilleadh timpeall ag teorainn an chineáil.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // ó exp!=0, sa deireadh caithfidh an exp a bheith 1.
            // Déileáil le giotán deiridh an easpónantóra ar leithligh, ós rud é nach gá an bonn a scuadáil ina dhiaidh sin agus d`fhéadfadh go mbeadh ró-shreabhadh gan ghá ann.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Ríomhann `self` + `rhs`
        ///
        /// Seoltar tuple den bhreisiú ar ais mar aon le boole a thaispeánann an dtarlódh ró-shreabhadh uimhríochta.
        /// Dá dtarlódh ró-shreabhadh ansin tugtar an luach fillte ar ais.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Ríomhann `self`, `rhs`
        ///
        /// Filleann tuple den dhealú chomh maith le boole a léiríonn an dtarlódh ró-shreabhadh uimhríochta.
        /// Dá dtarlódh ró-shreabhadh ansin tugtar an luach fillte ar ais.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Ríomh iolrú `self` agus `rhs`.
        ///
        /// Filleann tuple den iolrú mar aon le boole a thaispeánann an dtarlódh ró-shreabhadh uimhríochta.
        /// Dá dtarlódh ró-shreabhadh ansin tugtar an luach fillte ar ais.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// Tabhair faoi deara le do thoil go roinntear an sampla seo idir cineálacha slánuimhir.
        /// A mhíníonn cén fáth a n-úsáidtear `u32` anseo.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Ríomhann an roinnteoir nuair a roinntear `self` le `rhs`.
        ///
        /// Filleann tuple den roinnteoir mar aon le boole a thaispeánann an dtarlódh ró-shreabhadh uimhríochta.
        /// Tabhair faoi deara nach dtarlaíonn ró-shreabhadh do shlánuimhreacha neamhshínithe riamh, mar sin is é an dara luach `false` i gcónaí.
        ///
        /// # Panics
        ///
        /// Beidh an fheidhm seo panic má tá `rhs` 0.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Ríomhtar comhrann roinn Eoiclídeach `self.div_euclid(rhs)`.
        ///
        /// Filleann tuple den roinnteoir mar aon le boole a thaispeánann an dtarlódh ró-shreabhadh uimhríochta.
        /// Tabhair faoi deara nach dtarlaíonn ró-shreabhadh do shlánuimhreacha neamhshínithe riamh, mar sin is é an dara luach `false` i gcónaí.
        /// Ós rud é, maidir leis na slánuimhreacha dearfacha, go bhfuil na sainmhínithe comónta go léir ar rannán comhionann, tá sé seo cothrom le `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Beidh an fheidhm seo panic má tá `rhs` 0.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Ríomhtar an fuílleach nuair a roinntear `self` le `rhs`.
        ///
        /// Seoltar tuple den fhuílleach ar ais tar éis dó a roinnt i dteannta le boole a thaispeánann an dtarlódh ró-shreabhadh uimhríochta.
        /// Tabhair faoi deara nach dtarlaíonn ró-shreabhadh do shlánuimhreacha neamhshínithe riamh, mar sin is é an dara luach `false` i gcónaí.
        ///
        /// # Panics
        ///
        /// Beidh an fheidhm seo panic má tá `rhs` 0.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Ríomhtar an fuílleach `self.rem_euclid(rhs)` amhail is dá mba de réir rannán Eoiclídeach é.
        ///
        /// Tuairisceáin tuple ar an modulo tar éis roinnt mar aon le athróige Boole le fios cibé an mbeadh an overflow uimhríochtúil tarlú.
        /// Tabhair faoi deara nach dtarlaíonn ró-shreabhadh do shlánuimhreacha neamhshínithe riamh, mar sin is é an dara luach `false` i gcónaí.
        /// Ós rud é, do na slánuimhreacha deimhneacha, tá gach comhshainiú ar na cineálacha comhionannas, is é an oibríocht díreach comhionann leis `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Beidh an fheidhm seo panic má tá `rhs` 0.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Negates féin ar bhealach ag cur thar maoil.
        ///
        /// Tuairisceáin `!self + 1` ag úsáid oibríochtaí timfhilleadh chun an luach a léiríonn faillí an luacha neamhshínithe seo a thabhairt ar ais.
        /// Tabhair faoi deara go dtarlaíonn ró-shreabhadh i gcónaí do luachanna dearfacha neamhshínithe, ach ní sháraíonn faillí 0.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Aistriú féin fágtha ag giotáin `rhs`.
        ///
        /// Seoltar tuple den leagan aistrithe de féin ar ais mar aon le boole a thaispeánann an raibh luach an aistrithe níos mó ná nó cothrom le líon na ngiotán.
        /// Má tá luach an aistrithe ró-mhór, déantar an luach a chumhdach (N-1) áit arb é N líon na ngiotán, agus úsáidtear an luach seo ansin chun an t-aistriú a dhéanamh.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Athraíonn sé féin ceart le giotáin `rhs`.
        ///
        /// Seoltar tuple den leagan aistrithe de féin ar ais mar aon le boole a thaispeánann an raibh luach an aistrithe níos mó ná nó cothrom le líon na ngiotán.
        /// Má tá luach an aistrithe ró-mhór, déantar an luach a chumhdach (N-1) áit arb é N líon na ngiotán, agus úsáidtear an luach seo ansin chun an t-aistriú a dhéanamh.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Ardaíonn sé féin cumhacht `exp`, ag úsáid easpónant trí squaring.
        ///
        /// Filleann tuple den easpónant chomh maith le bool ag tabhairt le fios ar tharla ró-shreabhadh.
        ///
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, fíor));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Spás scríobtha chun torthaí thar maoil_mul a stóráil.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // ó exp!=0, sa deireadh caithfidh an exp a bheith 1.
            // Déileáil le giotán deiridh an easpónantóra ar leithligh, ós rud é nach gá an bonn a scuadáil ina dhiaidh sin agus d`fhéadfadh go mbeadh ró-shreabhadh gan ghá ann.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Ardaíonn sé féin cumhacht `exp`, ag úsáid easpónant trí squaring.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // ó exp!=0, sa deireadh caithfidh an exp a bheith 1.
            // Déileáil le giotán deiridh an easpónantóra ar leithligh, ós rud é nach gá an bonn a scuadáil ina dhiaidh sin agus d`fhéadfadh go mbeadh ró-shreabhadh gan ghá ann.
            //
            //
            acc * base
        }

        /// Déanann sé rannán Eoiclídeach.
        ///
        /// Ós rud é, maidir leis na slánuimhreacha dearfacha, go bhfuil na sainmhínithe comónta go léir ar roinn cothrom, tá sé seo cothrom le `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Beidh an fheidhm seo panic má tá `rhs` 0.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Ríomhtar an fuílleach is lú de `self (mod rhs)`.
        ///
        /// Ós rud é, maidir leis na slánuimhreacha dearfacha, go bhfuil na sainmhínithe comónta go léir ar rannán comhionann, tá sé seo cothrom le `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Beidh an fheidhm seo panic má tá `rhs` 0.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Tuairisceáin `true` más rud é agus mura bhfuil `self == 2^k` do roinnt `k` amháin.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Filleann sé cumhacht amháin níos lú ná an chéad chumhacht eile de dhá cheann.
        // (Maidir le 8u8 is é 8u8 an chéad chumhacht eile agus is é 8u8 do 6u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Is féidir an modh seo nach bhfuil thar maoil, mar atá sna cásanna thar maoil `next_power_of_two` chríochnaíonn sé ina ionad sin ar bun ag filleadh ar an luach is fearr den chineál, agus is féidir ar ais 0 as 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // SÁBHÁILTEACHT: Mar gheall ar `p > 0`, ní féidir nialais tosaigh a bheith ann go hiomlán.
            // Ciallaíonn sé sin go mbíonn an t-aistriú i gcónaí faoi theorainn, agus bíonn intreacha ctlz níos éifeachtaí ag roinnt próiseálaithe (mar intel pre-haswell) nuair a bhíonn an argóint neamh-nialasach.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Filleann sé an chumhacht is lú de dhá cheann is mó ná nó cothrom le `self`.
        ///
        /// Nuair overflows luach ar ais (is é sin, `self > (1 << (N-1))` le haghaidh cineál `uN`), tá sé panics i mód debug agus aisfhilleadh fillte go 0 i mód scaoileadh (an staid amháin inar féidir modh ar ais 0).
        ///
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Filleann sé an chumhacht is lú de dhá cheann is mó ná nó cothrom le `n`.
        /// Más mó an chéad chumhacht eile de dhá cheann ná uasluach an chineáil, tugtar `None` ar ais, ar shlí eile tá cumhacht dhá cheann fillte i `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Filleann sé an chumhacht is lú de dhá cheann is mó ná nó cothrom le `n`.
        /// Más mó an chéad chumhacht eile de dhá cheann ná uasluach an chineáil, tá an luach toraidh fillte go `0`.
        ///
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Cuir léiriú cuimhne an tslánuimhir seo ar ais mar eagar beart in ord beart mór-endian (network).
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Cuir léiriú cuimhne an tslánuimhir seo ar ais mar eagar beart in ord beart beagchríche.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Cuir léiriú cuimhne an tslánuimhir seo ar ais mar eagar beart in ord beart dúchais.
        ///
        /// De réir mar a úsáidtear seasmhacht dhúchasach an ardáin sprioc, ba cheart go n-úsáidfeadh cód iniompartha [`to_be_bytes`] nó [`to_le_bytes`], de réir mar is cuí.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, más cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } eile {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SÁBHÁILTEACHT: fuaim seasmhach toisc gur sean-datatypes simplí iad slánuimhreacha ionas gur féidir linn i gcónaí
        // iad a aistriú chuig eagair beart
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SÁBHÁILTEACHT: is sean-datatypes simplí iad slánuimhreacha ionas gur féidir linn iad a aistriú chuig
            // eagair beart
            unsafe { mem::transmute(self) }
        }

        /// Cuir léiriú cuimhne an tslánuimhir seo ar ais mar eagar beart in ord beart dúchais.
        ///
        ///
        /// [`to_ne_bytes`] a fearr thar an uair is féidir.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// lig bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     bytes, más cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } eile {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SÁBHÁILTEACHT: is sean-datatypes simplí iad slánuimhreacha ionas gur féidir linn iad a aistriú chuig
            // eagair beart
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Cruthaigh luach slánuimhir dúchasach endian óna léiriú mar eagar beart i endian mór.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// úsáid std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ionchur=scíth;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Cruthaigh luach slánuimhir dúchasach endian óna léiriú mar eagar beart ar bheagán endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// úsáid std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ionchur=scíth;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Cruthaigh luach slánuimhir dúchais endian óna ionadaíocht chuimhne mar sraith beart i endianness dúchais.
        ///
        /// Toisc go bhfuil an t-ardán sprioc ar endianness dúchais úsáidtear, cód iniompartha ba mhaith leis dócha a úsáid [`from_be_bytes`] nó [`from_le_bytes`], de réir mar is iomchuí ina ionad.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } eile {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// úsáid std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ionchur=scíth;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SÁBHÁILTEACHT: fuaim seasmhach toisc gur sean-datatypes simplí iad slánuimhreacha ionas gur féidir linn i gcónaí
        // transmute dóibh
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SÁBHÁILTEACHT: is sean-datatypes simplí iad slánuimhreacha ionas gur féidir linn aistriú chucu i gcónaí
            unsafe { mem::transmute(bytes) }
        }

        /// B`fhearr le cód nua a úsáid
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Filleann sé ar an luach is lú is féidir a léiriú leis an gcineál slánuimhir seo.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// B`fhearr le cód nua a úsáid
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Filleann sé an luach is mó ar féidir a léiriú leis an gcineál slánuimhir seo.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}