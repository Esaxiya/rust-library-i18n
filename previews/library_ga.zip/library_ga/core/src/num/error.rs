//! Cineálacha earráide le tiontú go cineálacha bunúsacha.

use crate::convert::Infallible;
use crate::fmt;

/// Cuireadh an cineál earráide ar ais nuair a theipeann ar chomhshó de chineál lárnach seiceáilte.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Meaitseáil seachas comhéigean chun a chinntiú go leanfaidh cód mar `From<Infallible> for TryFromIntError` thuas ag obair nuair a thiocfaidh `Infallible` mar ailias le `!`.
        //
        //
        match never {}
    }
}

/// Earráid is féidir a thabhairt ar ais agus slánuimhir á pharsáil.
///
/// Úsáidtear an earráid seo mar an cineál earráide le haghaidh na bhfeidhmeanna `from_str_radix()` ar na cineálacha slánuimhir primitive, mar shampla [`i8::from_str_radix`].
///
/// # Cúiseanna féideartha
///
/// I measc cúiseanna eile, is féidir `ParseIntError` a chaitheamh mar gheall ar spás bán a threorú nó a rianú sa téad eg, nuair a fhaightear é ón ionchur caighdeánach.
///
/// Trí úsáid a bhaint as an modh [`str::trim()`] cinntítear nach bhfanann aon spás bán sula ndéantar é a pharsáil.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum chun na cineálacha éagsúla earráidí a stóráil a d`fhéadfadh a bheith ina gcúis le parsáil slánuimhir.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Tá an luach atá á pharsáil folamh.
    ///
    /// I measc cúiseanna eile, tógfar an leagan seo agus sreangán á pharsáil.
    Empty,
    /// Tá dhigit neamhbhailí ann ina chomhthéacs.
    ///
    /// I measc cúiseanna eile, tógfar an leagan seo nuair a dhéantar sreangán a pharsáil ina bhfuil ruaille neamh-ASCII.
    ///
    /// Tógtar an t-athraitheach seo freisin nuair a dhéantar `+` nó `-` a chur as áit i sreangán leis féin nó i lár uimhreach.
    ///
    ///
    InvalidDigit,
    /// Tá slánuimhir ró-mhór le stóráil i gcineál sprioc slánuimhir.
    PosOverflow,
    /// Tá slánuimhir ró-bheag le stóráil i spriocchineál slánuimhir.
    NegOverflow,
    /// Ba é an luach ná nialas
    ///
    /// Astaítear an leagan seo nuair a bheidh luach nialas ag an tsreang pharsála, a bheadh mídhleathach do chineálacha neamh-nialasacha.
    ///
    Zero,
}

impl ParseIntError {
    /// Aschuir sé an chúis mhionsonraithe go dteipeann ar shlánuimhir a pharsáil.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}