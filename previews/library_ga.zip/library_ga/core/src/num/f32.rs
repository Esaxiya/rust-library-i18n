//! Tairiscintí a bhaineann go sonrach leis an gcineál snámhphointe aon-chruinneas `f32`.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Soláthraítear líon suntasach matamaiticiúil san fho-mhodúl `consts`.
//!
//! Maidir leis na tairisigh a shainmhínítear go díreach sa mhodúl seo (seachas iad siúd atá sainithe san fho-mhodúl `consts`), ba cheart go n-úsáidfeadh cód nua na tairisigh bhainteacha atá sainithe go díreach ar an gcineál `f32`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Gatha nó bonn na hionadaíochta inmheánaí de `f32`.
/// Úsáid [`f32::RADIX`] ina ionad.
///
/// # Examples
///
/// ```rust
/// // bealach dímheasa
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // bealach beartaithe
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Líon na digití suntasacha i mbonn 2.
/// Úsáid [`f32::MANTISSA_DIGITS`] ina ionad.
///
/// # Examples
///
/// ```rust
/// // bealach dímheasa
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // bealach beartaithe
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Líon measta na ndigití suntasacha i mbonn 10.
/// Úsáid [`f32::DIGITS`] ina ionad.
///
/// # Examples
///
/// ```rust
/// // bealach dímheasa
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // bealach beartaithe
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] luach do `f32`.
/// Bain úsáid as [`f32::EPSILON`] ina ionad.
///
/// Seo an difríocht idir `1.0` agus an chéad uimhir ionadaíoch eile.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // bealach dímheasa
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // bealach beartaithe
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// An luach teoranta `f32` is lú.
/// Úsáid [`f32::MIN`] ina ionad.
///
/// # Examples
///
/// ```rust
/// // bealach dímheasa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // bealach beartaithe
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// Gnáthluach dearfach `f32` is lú.
/// Úsáid [`f32::MIN_POSITIVE`] ina ionad.
///
/// # Examples
///
/// ```rust
/// // bealach dímheasa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // bealach beartaithe
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// An luach teoranta `f32` is mó.
/// Úsáid [`f32::MAX`] ina ionad.
///
/// # Examples
///
/// ```rust
/// // bealach dímheasa
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // bealach beartaithe
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Ceann amháin níos mó ná an ghnáthchumhacht is lú is féidir de 2 easpónant.
/// Úsáid [`f32::MIN_EXP`] ina ionad.
///
/// # Examples
///
/// ```rust
/// // bealach dímheasa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // bealach beartaithe
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// Uaschumhacht is féidir 2 easpónant.
/// Úsáid [`f32::MAX_EXP`] ina ionad.
///
/// # Examples
///
/// ```rust
/// // bealach dímheasa
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // bealach beartaithe
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Íosta cumhacht gnáth féideartha 10 easpónant.
/// Úsáid [`f32::MIN_10_EXP`] ina ionad.
///
/// # Examples
///
/// ```rust
/// // bealach dímheasa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // bealach beartaithe
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// Uaschumhacht is féidir de 10 easpónant.
/// Úsáid [`f32::MAX_10_EXP`] ina ionad.
///
/// # Examples
///
/// ```rust
/// // bealach dímheasa
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // bealach beartaithe
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Ní Uimhir (NaN).
/// Bain úsáid as [`f32::NAN`] ina ionad.
///
/// # Examples
///
/// ```rust
/// // bealach dímheasa
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // bealach beartaithe
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Infinity (∞).
/// Úsáid [`f32::INFINITY`] ina ionad.
///
/// # Examples
///
/// ```rust
/// // bealach dímheasa
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // bealach beartaithe
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Infinity diúltach (−∞).
/// Úsáid [`f32::NEG_INFINITY`] ina ionad.
///
/// # Examples
///
/// ```rust
/// // bealach dímheasa
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // bealach beartaithe
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Tairiscintí bunúsacha matamaitice.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: cuir tairisigh mhatamaiticiúla as cmath.

    /// Tairiseach (π) Archimedes
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// Tairiseach iomlán an chiorcail (τ)
    ///
    /// Is ionann é agus 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Uimhir Euler (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// Gatha nó bonn na hionadaíochta inmheánaí de `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Líon na digití suntasacha i mbonn 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Líon measta na ndigití suntasacha i mbonn 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] luach do `f32`.
    ///
    /// Seo an difríocht idir `1.0` agus an chéad uimhir ionadaíoch eile.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// An luach teoranta `f32` is lú.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// Gnáthluach dearfach `f32` is lú.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// An luach teoranta `f32` is mó.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Ceann amháin níos mó ná an ghnáthchumhacht is lú is féidir de 2 easpónant.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// Uaschumhacht is féidir 2 easpónant.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Íosta cumhacht gnáth féideartha 10 easpónant.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// Uaschumhacht is féidir de 10 easpónant.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Ní Uimhir (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Infinity diúltach (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Tuairisceáin `true` más é `NaN` an luach seo.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): Níl `abs` ar fáil go poiblí i libcore mar gheall ar imní faoi iniomparthacht, mar sin tá an cur chun feidhme seo le haghaidh úsáide príobháidí go hinmheánach.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Tuairisceáin `true` más Infinity dearfach nó Infinity diúltach an luach seo, agus `false` a mhalairt.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Tuairisceáin `true` mura bhfuil an uimhir seo gan teorainn ná `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Ní gá NaN a láimhseáil ar leithligh: más NaN é féin, níl an chomparáid fíor, díreach mar is mian leat.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Tuairisceáin `true` más é [subnormal] an uimhir.
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Tá luachanna idir `0` agus `min` neamhghnácha.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Tuairisceáin `true` mura bhfuil an uimhir nialas, gan teorainn, [subnormal], nó `NaN`.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Tá luachanna idir `0` agus `min` neamhghnácha.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Filleann sé an chatagóir snámhphointe den uimhir.
    /// Mura ndéanfar tástáil ach ar mhaoin amháin, is gnách go mbeidh sé níos tapa an tuar sonrach a úsáid ina ionad.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Tuairisceáin `true` má tá comhartha dearfach ag `self`, lena n-áirítear `+0.0`, `NaN le giotán comhartha dearfach agus Infinity dearfach.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Tuairisceáin `true` má tá comhartha diúltach ag `self`, lena n-áirítear `-0.0`, `NaN le giotán comhartha diúltach agus Infinity diúltach.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // Deir IEEE754: Tá isSignMinus(x) fíor más rud é agus má tá comhartha diúltach ag x amháin.
        // Baineann isSignMinus le nialais agus NaNanna freisin.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Glacann an (inverse) cómhalartach uimhir, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Athraíonn raidian go céimeanna.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // Bain úsáid as tairiseach chun cruinneas níos fearr a fháil.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Athraíonn sé céimeanna go raidianacha.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Filleann sé uasmhéid an dá uimhir.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Más NaN ceann de na hargóintí, tugtar an argóint eile ar ais.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Filleann sé an t-íosmhéid den dá uimhir.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Más NaN ceann de na hargóintí, tugtar an argóint eile ar ais.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Babhtaí i dtreo nialas agus athraíonn sé go haon chineál slánuimhir primitive, ag glacadh leis go bhfuil an luach teoranta agus go n-oireann sé don chineál sin.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Caithfidh an luach:
    ///
    /// * Gan a bheith `NaN`
    /// * Gan a bheith gan teorainn
    /// * Bí inléirithe sa chineál ar ais `Int`, tar éis á theascadh as a chodán
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `FloatToInt::to_int_unchecked` a sheasamh.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Transmutation amh go `u32`.
    ///
    /// Tá sé seo comhionann le `transmute::<f32, u32>(self)` ar gach ardán faoi láthair.
    ///
    /// Féach `from_bits` le haghaidh roinnt plé ar iniomparthacht na hoibríochta seo (níl beagnach aon cheisteanna ann).
    ///
    /// Tabhair faoi deara go bhfuil an fheidhm seo difriúil ó réitigh `as`, a dhéanann iarracht an luach *uimhriúil* a chaomhnú, agus ní an luach bitwise.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() nach bhfuil ag caitheamh!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // Is `u32` a datatype plain d'aois ionas gur féidir linn a transmute gcónaí dó: SAFETY
        unsafe { mem::transmute(self) }
    }

    /// Transmutation amh ó `u32`.
    ///
    /// Tá sé seo comhionann le `transmute::<u32, f32>(v)` ar gach ardán faoi láthair.
    /// Tarlaíonn sé go bhfuil sé seo iniompartha go hiontach, ar dhá chúis:
    ///
    /// * Tá an seasmhacht céanna ag snámháin agus Ints ar gach ardán tacaithe.
    /// * Sonraíonn IEEE-754 go beacht leagan amach giotán na snámhán.
    ///
    /// Tá caveat amháin ann: roimh leagan 2008 de IEEE-754, níor sonraíodh i ndáiríre conas an giotán comharthaíochta NaN a léirmhíniú.
    /// Phioc formhór na n-ardán (go háirithe x86 agus ARM) an léirmhíniú a caighdeánaíodh sa deireadh i 2008, ach níor thaitin cuid acu (go háirithe MIPS).
    /// Mar thoradh air sin, is NaNanna ciúin ar x86 iad gach NaN comharthaíochta ar MIPS, agus a mhalairt.
    ///
    /// Seachas iarracht a dhéanamh tras-ardán comharthaíochta a chaomhnú, is fearr leis an gcur i bhfeidhm seo na giotáin chruinne a chaomhnú.
    /// Ciallaíonn sé seo go gcaomhnófar aon ualaí pá atá ionchódaithe i NaNanna fiú má sheoltar toradh an mhodha seo thar an líonra ó mheaisín x86 go ceann MIPS.
    ///
    ///
    /// Mura ndéantar torthaí an mhodha seo a ionramháil ach ag an ailtireacht chéanna a rinne iad, ansin níl aon imní iniomparthachta ann.
    ///
    /// Murab é NaN an t-ionchur, níl aon imní iniomparthachta ann.
    ///
    /// Mura bhfuil cúram ort faoi chomharthaíocht (an-dóchúil), níl aon imní iniomparthachta ann.
    ///
    /// Tabhair faoi deara go bhfuil an fheidhm seo difriúil ó réitigh `as`, a dhéanann iarracht an luach *uimhriúil* a chaomhnú, agus ní an luach bitwise.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // SÁBHÁILTEACHT: Is sean-datatype simplí é `u32` ionas gur féidir linn aistriú uaidh i gcónaí
        // Casadh sé amach go raibh na ceisteanna sábháilteachta le sNaN overblown!Hooray!
        unsafe { mem::transmute(v) }
    }

    /// Cuir léiriú cuimhne na huimhreach snámhphointe seo ar ais mar eagar beart in ord beart mór-endian (network).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Cuir léiriú cuimhne na huimhreach snámhphointe seo ar ais mar eagar beart in ord beart beagchríche.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Fill ar ais an t-uiríoll gcuimhne ar an uimhir snámhphointe mar sraith beart d'fhonn dúchasacha de na bearta.
    ///
    /// De réir mar a úsáidtear seasmhacht dhúchasach an ardáin sprioc, ba cheart go n-úsáidfeadh cód iniompartha [`to_be_bytes`] nó [`to_le_bytes`], de réir mar is cuí.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Fill ar ais an t-uiríoll gcuimhne ar an uimhir snámhphointe mar sraith beart d'fhonn dúchasacha de na bearta.
    ///
    ///
    /// [`to_ne_bytes`] a fearr thar an uair is féidir.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // SÁBHÁILTEACHT: Is sean-datatype plain é `f32` ionas gur féidir linn aistriú chuige i gcónaí
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Cruthaigh luach snámhphointe óna léiriú mar eagar beart i gcríoch mór.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Cruthaigh luach snámhphointe óna léiriú mar eagar beart ar bheagán endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Cruthaigh luach snámhphointe óna léiriú mar eagar beart sa endian dúchais.
    ///
    /// Toisc go bhfuil an t-ardán sprioc ar endianness dúchais úsáidtear, cód iniompartha ba mhaith leis dócha a úsáid [`from_be_bytes`] nó [`from_le_bytes`], de réir mar is iomchuí ina ionad.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Filleann ordú idir luachanna féin agus luachanna eile.
    /// Murab ionann agus an chomparáid pháirteach chaighdeánach idir uimhreacha snámhphointí, cruthaíonn an chomparáid seo ordú i gcónaí de réir réamh-mheastachán iomlánOrder mar a shainmhínítear i gcaighdeán snámhphointe IEEE 754 (athbhreithniú 2008).
    /// Ordaítear na luachanna san ord seo a leanas:
    /// - NaN ciúin diúltach
    /// - Comharthaíocht dhiúltach NaN
    /// - Infinity diúltach
    /// - Uimhreacha diúltacha
    /// - Uimhreacha neamhghnácha diúltacha
    /// - Diúltach nialas
    /// - nialas dearfach
    /// - Uimhreacha dearfacha neamhghnácha
    /// - Uimhreacha dearfacha
    /// - Infinity dearfach
    /// - Comharthaíocht dhearfach NaN
    /// - NaN ciúin dearfach
    ///
    /// Tabhair faoi deara nach n-aontaíonn an fheidhm seo i gcónaí le cur chun feidhme [`PartialOrd`] agus [`PartialEq`] de `f32`.Go háirithe, measann siad go bhfuil nialas diúltach agus dearfach comhionann, cé nach bhfuil `total_cmp`.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // I gcás claonchlónna, smeach na giotáin go léir seachas an comhartha chun leagan amach cosúil leis a bhaint amach mar shlánuimhreacha comhlánaithe beirt
        //
        // Cén fáth go n-oibríonn sé seo?Tá trí réimse i snámháin IEEE 754:
        // Cláraigh giotán, easpónant agus mantissa.Tá sé de mhaoin ag an tsraith réimsí easpónantóra agus mantissa ina iomláine go bhfuil a n-ord giota cothrom leis an méid uimhriúil ina sainítear an méid.
        // De ghnáth ní shainmhínítear an méid ar luachanna NaN, ach sainmhíníonn IEEE 754 totalOrder na luachanna NaN freisin chun an t-ord bitwise a leanúint.Mar thoradh air seo tá ord a mhínítear sa trácht doc.
        // Mar sin féin, tá an léiriú ar mhéid mar an gcéanna i gcás uimhreacha diúltacha agus dearfacha-níl ach an giotán comhartha difriúil.
        // Chun na snámháin a chur i gcomparáid go héasca mar shlánuimhreacha sínithe, caithfimid na giotáin easpónantóra agus mantissa a smeach i gcás uimhreacha diúltacha.
        // Déanaimid na huimhreacha a thiontú go foirm "two's complement" go héifeachtach.
        //
        // Chun an flipping a dhéanamh, déanaimid masc agus XOR a thógáil ina choinne.
        // Déanaimid masc "all-ones except for the sign bit" a ríomh go brainseach ó luachanna sínithe diúltacha: síneann comhartha aistrithe ceart an tslánuimhir, mar sin déanaimid "fill" an masc le giotáin chomhartha, agus ansin athraímid go neamhshínithe chun giotán nialasach amháin eile a bhrú.
        //
        // Ar luachanna dearfacha, is nialais uile an masc, mar sin is no-op é.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Cuir srian ar luach go dtí eatramh áirithe mura NaN é.
    ///
    /// Tuairisceáin `max` má tá `self` níos mó ná `max`, agus `min` má tá `self` níos lú ná `min`.
    /// Seachas sin filleann sé seo `self`.
    ///
    /// Tabhair faoi deara go dtugann an fheidhm seo NaN ar ais más NaN an luach tosaigh freisin.
    ///
    /// # Panics
    ///
    /// Panics más NaN é `min > max`, `min`, nó NaN é `max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}