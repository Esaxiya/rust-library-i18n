//! Tairiscintí don chineál slánuimhir 32-giotán gan síniú.
//!
//! *[See also the `u32` primitive type][u32].*
//!
//! Ba cheart go n-úsáidfeadh cód nua na tairisigh bhainteacha go díreach ar an gcineál primitive.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u32`"
)]

int_module! { u32 }