//! Tairiscintí don chineál slánuimhir sínithe 32-giotán.
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! Ba cheart go n-úsáidfeadh cód nua na tairisigh bhainteacha go díreach ar an gcineál primitive.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }