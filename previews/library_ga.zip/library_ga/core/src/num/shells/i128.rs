//! Tairiscintí don chineál slánuimhir sínithe 128-giotán.
//!
//! *[See also the `i128` primitive type][i128].*
//!
//! Ba cheart go n-úsáidfeadh cód nua na tairisigh bhainteacha go díreach ar an gcineál primitive.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }