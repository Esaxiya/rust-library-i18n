//! Cur chun feidhme saincheaptha uimhir treallach-cruinneas (bignum).
//!
//! Tá sé seo deartha chun leithdháileadh na gcarn a sheachaint ar chostas cuimhne cruachta.
//! Tá an cineál bignum is mó a úsáidtear, `Big32x40`, teoranta ag 32 × 40=1,280 giotán agus tógfaidh sé 160 beart de chuimhne cruachta ar a mhéad.
//! Tá sé seo níos mó ná go leor chun na luachanna teoranta `f64` féideartha go léir a thapú.
//!
//! I bprionsabal, is féidir go mbeidh iliomad cineálacha bignum ann le haghaidh ionchur éagsúil, ach ní dhéanaimid amhlaidh chun an cód a bhláthú.
//!
//! Rianaítear gach bignum fós le haghaidh na n-úsáidí iarbhír, mar sin is cuma de ghnáth.
//!

// Níl an modúl seo ach le haghaidh dec2flt agus flt2dec, agus níl sé ach poiblí mar gheall ar chroí-thástálacha.
// Níl sé beartaithe é a chobhsú riamh.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// Oibríochtaí uimhríochta a éilíonn bignums.
pub trait FullOps: Sized {
    /// Filleann `(carry', v')` sa chaoi is go bhfuil `carry' * 2^W + v' = self + other + carry`, áit arb é `W` líon na ngiotán in `Self`.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// Filleann `(carry', v')` sa chaoi is go bhfuil `carry'*2^W + v' = self* other + carry`, áit arb é `W` líon na ngiotán in `Self`.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// Filleann `(carry', v')` sa chaoi is go bhfuil `carry'*2^W + v' = self* other + other2 + carry`, áit arb é `W` líon na ngiotán in `Self`.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// Tuairisceáin `(quo, rem)` sa chaoi go bhfuil `borrow *2^W + self = quo* other + rem` agus `0 <= rem < other`, áit arb é `W` líon na ngiotán in `Self`.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // Ní féidir leis seo cur thar maoil;tá an t-aschur idir `0` agus `2 * 2^nbits - 1`.
                    // FIXME: an ndéanfaidh LLVM é seo a bharrfheabhsú go ADC nó a leithéid?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // Ní féidir leis seo cur thar maoil;
                    // tá an t-aschur idir `0` agus `2^nbits * (2^nbits - 1)`.
                    // FIXME: an ndéanfaidh LLVM é seo a bharrfheabhsú go ADC nó a leithéid?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // Ní féidir leis seo cur thar maoil;
                    // tá an t-aschur idir `0` agus `2^nbits * (2^nbits - 1)`.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // Ní féidir leis seo cur thar maoil;tá an t-aschur idir `0` agus `other * (2^nbits - 1)`.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // Féach RFC #521 chun é seo a chumasú.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// Tábla cumhachtaí 5 in-ionadaithe i ndigití.Go sonrach, is é an luach {u8, u16, u32} is mó, sin cumhacht cúig, móide an t-easpónant comhfhreagrach.
/// Úsáidtear i `mul_pow5`.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// Slánuimhir cruinneas treallach-leithdháilte cruachta (suas le teorainn áirithe).
        ///
        /// Tá sraith de mhéid seasta de chineál tugtha ("digit") mar thaca leis seo.
        /// Cé nach bhfuil an t-eagar an-mhór (timpeall cúpla céad beart de ghnáth), má dhéantar é a chóipeáil go meargánta d`fhéadfadh an fheidhmíocht a bheith buailte.
        ///
        /// Mar sin ní `Copy` é seo d'aon ghnó.
        ///
        /// Gach oibríocht ar fáil do bignums panic i gcás ró-shreabhadh.
        /// Tá an té atá ag glaoch freagrach as cineálacha bignum mór go leor a úsáid.
        pub struct $name {
            /// Ceann móide an fritháireamh go dtí an "digit" uasta atá in úsáid.
            /// Ní laghdaíonn sé seo, mar sin bí ar an eolas faoin ordú ríofa.
            /// `base[size..]` chóir a bheith nialas.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` is ionann é agus `a + b *2^W + c* 2^(2W) + ...` áit arb é `W` líon na ngiotán sa chineál dhigit.
            base: [$ty; $n],
        }

        impl $name {
            /// Déanann bignum ó dhigit amháin.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// Déanann bignum ó luach `u64`.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// Filleann sé na digití inmheánacha mar shlis `[a, b, c, ...]` sa chaoi is gurb é `a + b *2^W + c* 2^(2W) + ...` an luach uimhriúil áit gurb é `W` líon na ngiotán sa chineál dhigit.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// Filleann sé an giotán `i`-ú áit arb é giotán 0 an ceann is lú suntasaí.
            /// I bhfocail eile, an giotán le meáchan `2^i`.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// Tuairisceáin `true` má tá an bignum nialas.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// Filleann sé líon na ngiotán is gá chun an luach seo a léiriú.
            /// Tabhair faoi deara go meastar go dteastaíonn 0 ngiotán ó nialas.
            pub fn bit_length(&self) -> usize {
                // Scipeáil thar na digití is suntasaí atá nialas.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // Níl aon dhigit neamh-nialasach ann, ie, is é an uimhir nialas.
                    return 0;
                }
                // D`fhéadfaí é seo a bharrfheabhsú le leading_zeros() agus giotán-aistrithe, ach is dócha nach fiú é sin a dhéanamh.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// Cuireann `other` leis féin agus cuireann sé a thagairt inathraithe féin ar ais.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// Dealaigh `other` uaidh féin agus cuireann sé a thagairt inathraithe féin ar ais.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// Iolraíonn sé é féin le `other` meánmhéide agus cuireann sé a thagairt inathraithe féin ar ais.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// Iolraíonn sé faoi `2^bits` agus cuireann sé a thagairt inathraithe féin ar ais.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // aistriú le giotáin `digits * digitbits`
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // aistriú le giotáin `bits`
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // tá self.base [.. digití] nialas, ní gá aistriú
                }

                self.size = sz;
                self
            }

            /// Iolraíonn sé faoi `5^e` agus cuireann sé a thagairt inathraithe féin ar ais.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // Tá n nialais rianaithe go díreach ar 2 ^ n, agus is iad na méideanna digiteacha ábhartha ach cumhachtaí as a chéile de dhá cheann, mar sin is innéacs an-oiriúnach é seo don tábla.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // Déan iolrú leis an gcumhacht aon-dhigit is mó chomh fada agus is féidir ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... ansin críochnaigh an chuid eile.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// Iolraíonn sé féin faoi uimhir a thuairiscíonn `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (áit arb é `W` líon na ngiotán sa chineál dhigit) agus cuireann sé a thagairt dhochreidte féin ar ais.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // an gnáthamh inmheánach.is fearr a oibríonn nuair a bhíonn aa.len() <= bb.len().
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// Roinntear é le `other` meánmhéide agus cuireann sé a thagairt dhochreidte féin *agus* an chuid eile ar ais.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// Roinn féin le bignum eile, ag frithscríobh `q` leis an gcomhrann agus `r` leis an gcuid eile.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // Roinn fhada mhall base-2 tógtha ó
                // https://en.wikipedia.org/wiki/Division_algorithm
                // Úsáideann FIXME bonn ($ty) níos mó don rannán fada.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // Socraigh giotán `i` de q go 1.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// An cineál dhigit do `Big32x40`.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// úsáidtear an ceann seo le haghaidh tástála amháin.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}