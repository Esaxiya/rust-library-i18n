macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// An luach is lú is féidir a léiriú leis an gcineál slánuimhir seo.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// An luach is mó is féidir a léiriú leis an gcineál slánuimhir seo.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// Méid an chineáil slánuimhir seo i ngiotán.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Tiontaíonn sé sreangán i mbonn ar leith go slánuimhir.
        ///
        /// Táthar ag súil go mbeidh an sreangán ina chomhartha roghnach `+` nó `-` agus digití ina dhiaidh sin.
        /// Is botún é an spás bán a threorú agus a rianú.
        /// Is fo-thacar de na carachtair seo digití, ag brath ar `radix`:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// Feidhm panics mura bhfuil `radix` sa raon ó 2 go 36.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Filleann sé líon na ndaoine i léiriú dénártha `self`.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// Filleann sé líon na nialais i léiriú dénártha `self`.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Filleann sé líon na nialais tosaigh i léiriú dénártha `self`.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// Filleann sé líon na nialais rianaithe i léiriú dénártha `self`.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// Filleann sé líon na gceann tosaigh i léiriú dénártha `self`.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// Filleann sé líon na ndaoine atá ag tarraingt i léiriú dénártha `self`.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// Athraíonn na giotáin ar chlé le méid sonraithe, `n`, ag timfhilleadh na ngiotán teasctha go dtí deireadh an tslánuimhir a leanann dá bharr.
        ///
        ///
        /// Tabhair faoi deara nach é seo an oibríocht chéanna mar oibreoir aistriú `<<`!
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// Athraíonn na giotáin ar dheis de mhéid sonraithe, `n`, ag timfhilleadh na ngiotán teasctha go dtí tús an tslánuimhir a leanann dá bharr.
        ///
        ///
        /// Tabhair faoi deara nach é seo an oibríocht chéanna leis an oibreoir aistrithe `>>`!
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// Aisiompaíonn ord beart an tslánuimhir.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// lig m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// Aisiompaíonn ord na ngiotán sa slánuimhir.
        /// Is é an giotán is suntasaí an giotán is suntasaí, is é an dara giotán is suntasaí an dara giotán is suntasaí, srl.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// lig m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// Athraíonn sé slánuimhir ó endian mór go endianness an sprioc.
        ///
        /// Ar an endian mór is no-op é seo.Ar endian beag malartaítear na bearta.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// más cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } eile {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Athraíonn sé slánuimhir ó bheagán endian go seasmhacht an sprioc.
        ///
        /// Is beag an rogha é seo ar bheagán endian.Ar endian mór malartaítear na bearta.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// más cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } eile {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Athraíonn sé `self` go endian mór ó endianness an sprioc.
        ///
        /// Ar an endian mór is no-op é seo.Ar endian beag malartaítear na bearta.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// más cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } eile { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // nó gan a bheith?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Athraíonn sé `self` go endian beag ó endianness an sprioc.
        ///
        /// Is beag an rogha é seo ar bheagán endian.Ar endian mór malartaítear na bearta.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// más cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } eile { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Breisiú slánuimhir seiceáilte.
        /// Computes `self + rhs`, ag filleadh `None` má tharla an ró-shreabhadh.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Breisiú slánuimhir neamhsheiceáilte.Computes `self + rhs`, ag glacadh leis nach féidir an ró-shreabhadh a tharlú.
        /// Bíonn iompar neamhshainithe mar thoradh air seo nuair a
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `unchecked_add` a sheasamh.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Dealú slánuimhir seiceáilte.
        /// Computes `self - rhs`, ag filleadh `None` má tharla an ró-shreabhadh.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Dealú slánuimhir neamhsheiceáilte.Ríomhann `self - rhs`, ní féidir glacadh leis overflow tarlú.
        /// Bíonn iompar neamhshainithe mar thoradh air seo nuair a
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `unchecked_sub` a sheasamh.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Iolrú slánuimhir seiceáilte.
        /// Computes `self * rhs`, ag filleadh `None` má tharla an ró-shreabhadh.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Iolrú slánuimhir neamhsheiceáilte.Computes `self * rhs`, ag glacadh leis nach féidir an ró-shreabhadh a tharlú.
        /// Bíonn iompar neamhshainithe mar thoradh air seo nuair a
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `unchecked_mul` a sheasamh.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Rannán slánuimhir seiceáilte.
        /// Computes `self / rhs`, ag filleadh `None` má tá `rhs == 0` nó an rannán ag cur thar maoil.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // SÁBHÁILTEACHT: seiceáladh div faoi nialas agus le INT_MIN thuas
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Rannán Euclidean Seiceáilte.
        /// Computes `self.div_euclid(rhs)`, ag filleadh `None` má tá `rhs == 0` nó an rannán ag cur thar maoil.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// Fuílleach slánuimhir seiceáilte.
        /// Computes `self % rhs`, ag filleadh `None` má tá `rhs == 0` nó an rannán ag cur thar maoil.
        ///
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // SÁBHÁILTEACHT: seiceáladh div faoi nialas agus le INT_MIN thuas
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Fuílleach Eoiclídeach seiceáilte.
        /// Computes `self.rem_euclid(rhs)`, ag filleadh `None` má tá `rhs == 0` nó an rannán ag cur thar maoil.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Faillí seiceáilte.
        /// Computes `-self`, ag filleadh `None` más `self == MIN` é.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Seiceáil seiceáilte ar chlé.
        /// Computes `self << rhs`, ag filleadh `None` má tá `rhs` níos mó ná nó cothrom le líon na ngiotán in `self`.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Seiceáil seiceáilte ceart.
        /// Computes `self >> rhs`, ag filleadh `None` má tá `rhs` níos mó ná nó cothrom le líon na ngiotán in `self`.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Luach glan seiceáilte.
        /// Computes `self.abs()`, ag filleadh `None` más `self == MIN` é.
        ///
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// Taispeántas seiceála.
        /// Computes `self.pow(exp)`, ag filleadh `None` má tharla an ró-shreabhadh.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // ó exp!=0, sa deireadh caithfidh an exp a bheith 1.
            // Déileáil le giotán deiridh an easpónantóra ar leithligh, ós rud é nach gá an bonn a scuadáil ina dhiaidh sin agus d`fhéadfadh go mbeadh ró-shreabhadh gan ghá ann.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Suim slánuimhir a shásamh.
        /// Computes `self + rhs`, sáithithe ag na teorainneacha uimhriúla in ionad cur thar maoil.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Dealú slánuimhir slánuimhir.
        /// Computes `self - rhs`, sáithithe ag na teorainneacha uimhriúla in ionad cur thar maoil.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Faillí slánuimhir sáithithe.
        /// Computes `-self`, ag filleadh `MAX` más `self == MIN` é in ionad cur thar maoil.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// Luach absalóideach sáithithe.
        /// Computes `self.abs()`, ag filleadh `MAX` más `self == MIN` é in ionad cur thar maoil.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// Iolrú slánuimhir slánuimhir.
        /// Computes `self * rhs`, sáithithe ag na teorainneacha uimhriúla in ionad cur thar maoil.
        ///
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// Exponentiation slánuimhir sáithithe.
        /// Computes `self.pow(exp)`, sáithithe ag na teorainneacha uimhriúla in ionad cur thar maoil.
        ///
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// Filleadh (modular) breiseán.
        /// Ríomhann `self + rhs`, timfhilleadh timpeall ar an teorainn den chineál.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Dealú (modular) a fhilleadh.
        /// Computes `self - rhs`, ag timfhilleadh timpeall ag teorainn an chineáil.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Iolrú (modular) a fhilleadh.
        /// Computes `self * rhs`, ag timfhilleadh timpeall ag teorainn an chineáil.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Filleadh rannán (modular).Computes `self / rhs`, ag timfhilleadh timpeall ag teorainn an chineáil.
        ///
        /// Is é an t-aon chás inar féidir timfhilleadh den sórt sin a dhéanamh ná nuair a roinneann duine `MIN / -1` ar chineál sínithe (i gcás gurb é `MIN` an luach íosta diúltach don chineál);tá sé seo comhionann le `-MIN`, luach dearfach atá ró-mhór le léiriú sa chineál.
        /// I gcás den sórt sin, filleann an fheidhm seo `MIN` féin.
        ///
        /// # Panics
        ///
        /// Beidh an fheidhm seo panic má tá `rhs` 0.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// Rannán Eoiclídeach a Fhilleadh.
        /// Computes `self.div_euclid(rhs)`, ag timfhilleadh timpeall ag teorainn an chineáil.
        ///
        /// Ní tharlóidh timfhilleadh ach in `MIN / -1` ar chineál sínithe (i gcás gurb é `MIN` an luach íosta diúltach don chineál).
        /// Is ionann `-MIN`, luach dearfach go bhfuil ró-mhór chun ionadaíocht a dhéanamh sa chineál.
        /// Sa chás seo, filleann an modh seo `MIN` féin.
        ///
        /// # Panics
        ///
        /// Beidh an fheidhm seo panic má tá `rhs` 0.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// Fuílleach (modular) a fhilleadh.Computes `self % rhs`, ag timfhilleadh timpeall ag teorainn an chineáil.
        ///
        /// Ní tharlaíonn timfhilleadh den sórt sin go matamaiticiúil riamh;déanann déantáin cur chun feidhme `x % y` neamhbhailí do `MIN / -1` ar chineál sínithe (áit arb é `MIN` an luach íosta diúltach).
        ///
        /// I gcás den sórt sin, filleann an fheidhm seo `0`.
        ///
        /// # Panics
        ///
        /// Beidh an fheidhm seo panic má tá `rhs` 0.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Timfhilleadh eile Eoiclídeach.Computes `self.rem_euclid(rhs)`, ag timfhilleadh timpeall ag teorainn an chineáil.
        ///
        /// Ní tharlóidh timfhilleadh ach in `MIN % -1` ar chineál sínithe (i gcás gurb é `MIN` an luach íosta diúltach don chineál).
        /// Sa chás seo, filleann an modh seo 0.
        ///
        /// # Panics
        ///
        /// Beidh an fheidhm seo panic má tá `rhs` 0.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// Faillí (modular) a fhilleadh.Computes `-self`, ag timfhilleadh timpeall ag teorainn an chineáil.
        ///
        /// Is é an t-aon chás inar féidir timfhilleadh den sórt sin a dhéanamh ná nuair a dhéantar dearmad ar `MIN` ar chineál sínithe (i gcás gurb é `MIN` an luach íosta diúltach don chineál);is luach dearfach é seo atá ró-mhór le léiriú sa chineál.
        /// I gcás den sórt sin, filleann an fheidhm seo `MIN` féin.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-saor ó aistriú bitwise ar chlé;táirgeacht `self << mask(rhs)`, sa chás go gcuireann `mask` deireadh le haon ghiotáin ardoird de `rhs` a d`fhágfadh go sáródh an t-aistriú giotán an chineáil.
        ///
        /// Tabhair faoi deara nach ionann é seo * agus rothlú ar chlé;tá an RHS de fhilleadh fillte ar chlé teoranta do raon an chineáil, seachas na giotáin a aistrítear as an LHS a thabhairt ar ais go dtí an ceann eile.
        ///
        /// Cuireann na cineálacha slánuimhir primitive feidhm [`rotate_left`](Self::rotate_left) i bhfeidhm, agus b`fhéidir gurb é sin a theastaíonn uait ina ionad.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SÁBHÁILTEACHT: cinntíonn an cumasc de réir giotáin an chineáil nach n-aistrímid
            // as teorainneacha
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-saor ó aistriú bitwise ar dheis;táirgeacht `self >> mask(rhs)`, i gcás ina mbainfidh `mask` aon giotán ard-ord `rhs` a bheadh ina údar an t-athrú a bheith níos mó ná an bitwidth den chineál.
        ///
        /// Tabhair faoi deara nach ionann é seo agus * ceart rothlach;an RHS de timfhilleadh athrú-ceart teoranta do réimse den chineál, in ionad na píosaí bhog amach na LHS á seoladh ar ais chuig an taobh eile.
        ///
        /// Cuireann na cineálacha slánuimhir primitive feidhm [`rotate_right`](Self::rotate_right) i bhfeidhm, agus b`fhéidir gurb é sin a theastaíonn uait ina ionad.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SÁBHÁILTEACHT: cinntíonn an cumasc de réir giotáin an chineáil nach n-aistrímid
            // as teorainneacha
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Luach glan (modular) a fhilleadh.Computes `self.abs()`, ag timfhilleadh timpeall ag teorainn an chineáil.
        ///
        /// Is é an t-aon chás inar féidir timfhilleadh den sórt sin a dhéanamh ná nuair a thógann sé luach absalóideach an luacha íosta dhiúltaigh don chineál;is luach dearfach é seo atá ró-mhór le léiriú sa chineál.
        /// I gcás den sórt sin, filleann an fheidhm seo `MIN` féin.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// Déanann sé luach absalóideach `self` a ríomh gan aon timfhilleadh nó scaoll a dhéanamh.
        ///
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// Filleadh (modular) fillte.
        /// Computes `self.pow(exp)`, ag timfhilleadh timpeall ag teorainn an chineáil.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // ó exp!=0, sa deireadh caithfidh an exp a bheith 1.
            // Déileáil le giotán deiridh an easpónantóra ar leithligh, ós rud é nach gá an bonn a scuadáil ina dhiaidh sin agus d`fhéadfadh go mbeadh ró-shreabhadh gan ghá ann.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Ríomhann `self` + `rhs`
        ///
        /// Seoltar tuple den bhreisiú ar ais mar aon le boole a thaispeánann an dtarlódh ró-shreabhadh uimhríochta.
        /// Dá dtarlódh ró-shreabhadh ansin tugtar an luach fillte ar ais.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Ríomhann `self`, `rhs`
        ///
        /// Filleann tuple den dhealú chomh maith le boole a léiríonn an dtarlódh ró-shreabhadh uimhríochta.
        /// Dá dtarlódh ró-shreabhadh ansin tugtar an luach fillte ar ais.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Ríomh iolrú `self` agus `rhs`.
        ///
        /// Filleann tuple den iolrú mar aon le boole a thaispeánann an dtarlódh ró-shreabhadh uimhríochta.
        /// Dá dtarlódh ró-shreabhadh ansin tugtar an luach fillte ar ais.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, fíor));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Ríomhann an roinnteoir nuair a roinntear `self` le `rhs`.
        ///
        /// Filleann tuple den roinnteoir mar aon le boole a thaispeánann an dtarlódh ró-shreabhadh uimhríochta.
        /// Dá dtarlódh ró-shreabhadh ansin tugtar an féin ar ais.
        ///
        /// # Panics
        ///
        /// Beidh an fheidhm seo panic má tá `rhs` 0.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// Ríomhtar comhrann roinn Eoiclídeach `self.div_euclid(rhs)`.
        ///
        /// Filleann tuple den roinnteoir mar aon le boole a thaispeánann an dtarlódh ró-shreabhadh uimhríochta.
        /// Dá dtarlódh ró-shreabhadh cuirtear `self` ar ais.
        ///
        /// # Panics
        ///
        /// Beidh an fheidhm seo panic má tá `rhs` 0.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// Ríomhtar an fuílleach nuair a roinntear `self` le `rhs`.
        ///
        /// Seoltar tuple den fhuílleach ar ais tar éis dó a roinnt i dteannta le boole a thaispeánann an dtarlódh ró-shreabhadh uimhríochta.
        /// Dá dtarlódh ró-shreabhadh cuirtear 0 ar ais.
        ///
        /// # Panics
        ///
        /// Beidh an fheidhm seo panic má tá `rhs` 0.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// Fuílleach Eoiclídeach ag cur thar maoil.Ríomhann `self.rem_euclid(rhs)`.
        ///
        /// Seoltar tuple den fhuílleach ar ais tar éis dó a roinnt i dteannta le boole a thaispeánann an dtarlódh ró-shreabhadh uimhríochta.
        /// Dá dtarlódh ró-shreabhadh cuirtear 0 ar ais.
        ///
        /// # Panics
        ///
        /// Beidh an fheidhm seo panic má tá `rhs` 0.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// Negates féin, ag cur thar maoil má tá sé seo cothrom leis an luach íosta.
        ///
        /// Filleann sé tuple den leagan neadaithe de féin chomh maith le boole a thaispeánann ar tharla ró-shreabhadh.
        /// Más é `self` an luach íosta (m.sh., `i32::MIN` do luachanna de chineál `i32`), cuirfear an luach íosta ar ais arís agus tabharfar `true` ar ais le haghaidh ró-shreabhadh a tharlóidh.
        ///
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// Aistriú féin fágtha ag giotáin `rhs`.
        ///
        /// Seoltar tuple den leagan aistrithe de féin ar ais mar aon le boole a thaispeánann an raibh luach an aistrithe níos mó ná nó cothrom le líon na ngiotán.
        /// Má tá luach an aistrithe ró-mhór, déantar an luach a chumhdach (N-1) áit arb é N líon na ngiotán, agus úsáidtear an luach seo ansin chun an t-aistriú a dhéanamh.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, fíor));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Athraíonn sé féin ceart le giotáin `rhs`.
        ///
        /// Seoltar tuple den leagan aistrithe de féin ar ais mar aon le boole a thaispeánann an raibh luach an aistrithe níos mó ná nó cothrom le líon na ngiotán.
        /// Má tá luach an aistrithe ró-mhór, déantar an luach a chumhdach (N-1) áit arb é N líon na ngiotán, agus úsáidtear an luach seo ansin chun an t-aistriú a dhéanamh.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, fíor));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Ríomh luach absalóideach `self`.
        ///
        /// Filleann sé tuple den leagan iomlán de féin in éineacht le boole a thaispeánann ar tharla ró-shreabhadh.
        /// Más é féin an luach is lú
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// ansin tabharfar an luach íosta ar ais arís agus tabharfar fíor ar ais le haghaidh ró-shreabhadh a tharlóidh.
        ///
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// Ardaíonn sé féin cumhacht `exp`, ag úsáid easpónant trí squaring.
        ///
        /// Filleann tuple den easpónant chomh maith le bool ag tabhairt le fios ar tharla ró-shreabhadh.
        ///
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, fíor));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Spás scríobtha chun torthaí thar maoil_mul a stóráil.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // ó exp!=0, sa deireadh caithfidh an exp a bheith 1.
            // Déileáil le giotán deiridh an easpónantóra ar leithligh, ós rud é nach gá an bonn a scuadáil ina dhiaidh sin agus d`fhéadfadh go mbeadh ró-shreabhadh gan ghá ann.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// Ardaíonn sé féin cumhacht `exp`, ag úsáid easpónant trí squaring.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // ó exp!=0, sa deireadh caithfidh an exp a bheith 1.
            // Déileáil le giotán deiridh an easpónantóra ar leithligh, ós rud é nach gá an bonn a scuadáil ina dhiaidh sin agus d`fhéadfadh go mbeadh ró-shreabhadh gan ghá ann.
            //
            //
            acc * base
        }

        /// Ríomhtar comhrann roinn Eoiclídeach `self` le `rhs`.
        ///
        /// Déanann sé seo an tslánuimhir `n` a ríomh ionas go mbeidh `self = n * rhs + self.rem_euclid(rhs)`, le `0 <= self.rem_euclid(rhs) < rhs`.
        ///
        ///
        /// Is é sin le rá, is é an toradh `self / rhs` a shlánú go dtí an tslánuimhir `n` sa chaoi go bhfuil `self >= n * rhs`.
        /// Más `self > 0` é, tá sé seo cothrom le babhta i dtreo nialas (an réamhshocrú i Rust);
        /// más `self < 0` é, tá sé seo cothrom le babhta i dtreo +/-Infinity.
        ///
        /// # Panics
        ///
        /// Beidh panic ag an bhfeidhm seo má tá `rhs` 0 nó má tá an rannán ag cur thar maoil.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// lig b=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// Ríomhtar an fuílleach neamh-shaineolaíoch is lú de `self (mod rhs)`.
        ///
        /// Déantar é seo amhail is dá mba ag algartam rannán Eoiclídeach-má thugtar `r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r`, agus `0 <= r < abs(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Beidh panic ag an bhfeidhm seo má tá `rhs` 0 nó má tá an rannán ag cur thar maoil.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// lig b=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// Ríomh luach absalóideach `self`.
        ///
        /// # Iompar thar maoil
        ///
        /// Luach absalóideach
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// ní féidir a léiriú mar
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// agus má dhéantar iarracht é a ríomh beidh sé ina chúis le ró-shreabhadh.
        /// Ciallaíonn sé seo go spreagfaidh cód i mód dífhabhtaithe panic sa chás seo agus go bhfillfidh an cód optamaithe
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// gan panic.
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // Tabhair faoi deara go gciallaíonn an#[inlíne] thuas go mbraitheann séimeantaic ró-shreafa an dealú ar an crate a bhfuilimid ag cur isteach air.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// Seoltar uimhir ar ais a léiríonn comhartha `self`.
        ///
        ///  - `0` más nialas an uimhir
        ///  - `1` má tá an uimhir dearfach
        ///  - `-1` má tá an uimhir diúltach
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// Tuairisceáin `true` má tá `self` dearfach agus `false` má tá an uimhir nialas nó diúltach.
        ///
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// Tuairisceáin `true` má tá `self` diúltach agus `false` má tá an uimhir nialas nó dearfach.
        ///
        ///
        /// # Examples
        ///
        /// Úsáid bhunúsach:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// Cuir léiriú cuimhne an tslánuimhir seo ar ais mar eagar beart in ord beart mór-endian (network).
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Cuir léiriú cuimhne an tslánuimhir seo ar ais mar eagar beart in ord beart beagchríche.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Cuir léiriú cuimhne an tslánuimhir seo ar ais mar eagar beart in ord beart dúchais.
        ///
        /// De réir mar a úsáidtear seasmhacht dhúchasach an ardáin sprioc, ba cheart go n-úsáidfeadh cód iniompartha [`to_be_bytes`] nó [`to_le_bytes`], de réir mar is cuí.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, más cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } eile {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SÁBHÁILTEACHT: fuaim seasmhach toisc gur sean-datatypes simplí iad slánuimhreacha ionas gur féidir linn i gcónaí
        // iad a aistriú chuig eagair beart
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SÁBHÁILTEACHT: is sean-datatypes simplí iad slánuimhreacha ionas gur féidir linn iad a aistriú chuig
            // eagair beart
            unsafe { mem::transmute(self) }
        }

        /// Cuir léiriú cuimhne an tslánuimhir seo ar ais mar eagar beart in ord beart dúchais.
        ///
        ///
        /// [`to_ne_bytes`] a fearr thar an uair is féidir.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// lig bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     bytes, más cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } eile {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SÁBHÁILTEACHT: is sean-datatypes simplí iad slánuimhreacha ionas gur féidir linn iad a aistriú chuig
            // eagair beart
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Cruthaigh luach slánuimhir óna léiriú mar eagar beart i endian mór.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// úsáid std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ionchur=scíth;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Cruthaigh luach slánuimhir óna léiriú mar eagar beart ar bheagán endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// úsáid std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ionchur=scíth;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Cruthaigh luach slánuimhir óna léiriú cuimhne mar eagar beart sa mhaireachtáil dhúchasach.
        ///
        /// Toisc go bhfuil an t-ardán sprioc ar endianness dúchais úsáidtear, cód iniompartha ba mhaith leis dócha a úsáid [`from_be_bytes`] nó [`from_le_bytes`], de réir mar is iomchuí ina ionad.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } eile {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// úsáid std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ionchur=scíth;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SÁBHÁILTEACHT: fuaim seasmhach toisc gur sean-datatypes simplí iad slánuimhreacha ionas gur féidir linn i gcónaí
        // transmute dóibh
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SÁBHÁILTEACHT: is sean-datatypes simplí iad slánuimhreacha ionas gur féidir linn aistriú chucu i gcónaí
            unsafe { mem::transmute(bytes) }
        }

        /// B`fhearr le cód nua a úsáid
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Filleann sé ar an luach is lú is féidir a léiriú leis an gcineál slánuimhir seo.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// B`fhearr le cód nua a úsáid
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Filleann sé an luach is mó ar féidir a léiriú leis an gcineál slánuimhir seo.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}