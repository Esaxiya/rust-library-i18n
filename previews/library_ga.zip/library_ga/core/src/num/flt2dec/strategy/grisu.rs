//! Oiriúnú Rust ar an algartam Grisu3 a thuairiscítear in "Uimhreacha Pointe Snámhphointe a Phriontáil go tapa agus go cruinn le Slánuimhreacha" [^ 1].
//! Úsáideann sé thart ar 1KB de thábla réamhchomhbhrúite, agus ar a seal, tá sé an-sciobtha d`fhormhór na n-ionchur.
//!
//! [^1]: Florian Loitsch.2010. Priontáil uimhreacha snámh-phointe go tapa agus
//!   go cruinn le slánuimhreacha.SIGPLAN Níl sé.45, 6 (Meitheamh 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// féach na tuairimí in `format_shortest_opt` don réasúnaíocht.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (F, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// I bhfianaise `x > 0`, filleann `(k, 10^k)` sa chaoi is go `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// An cur i bhfeidhm mód is giorra do Grisu.
///
/// Filleann sé `None` nuair a thabharfadh sé léiriú neamhghníomhach ar ais ar shlí eile.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // teastaíonn trí ghiotán de chruinneas breise uainn ar a laghad

    // tosú leis na luachanna normalaithe leis an easpónantóir roinnte
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // faigh aon `cached = 10^minusk` sa chaoi is go `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // ós rud é `plus` normalaithe, ciallaíonn sé seo `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // mar gheall ar ár n-roghanna de `ALPHA` agus `GAMMA`, seo cuireann `plus * cached` `[4, 2^32)` isteach.
    //
    // is léir go bhfuil sé inmhianaithe `GAMMA - ALPHA` a uasmhéadú, ionas nach mbeidh go leor cumhachtaí taisce de 10 ag teastáil uainn, ach tá roinnt breithnithe ann:
    //
    //
    // 1. ba mhaith linn `floor(plus * cached)` a choinneáil laistigh de `u32` ós rud é go dteastaíonn rannán costasach uaidh.
    //    (Nach bhfuil sé seo i ndáiríre a sheachaint, tá an chuid eile ag teastáil le haghaidh cruinneas meastacháin.)
    // 2.
    // déantar an chuid eile de `floor(plus * cached)` a iolrú arís agus arís eile faoi 10, agus níor cheart go sáródh sé.
    //
    // tugann an chéad cheann `64 + GAMMA <= 32`, agus tugann an dara ceann `10 * 2^-ALPHA <= 2^64`;
    // -60 agus is é -32 an raon uasta leis an srian seo, agus úsáideann V8 iad freisin.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // fss scála.tugann sé seo an earráid uasta de 1 ulp (cruthaithe ó Theoirim 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-Réimse iarbhír lúide
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ULP | 1 ULP |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // déantar meastacháin *cainníochtaithe* os cionn `minus`, `v` agus `plus` (earráid <1 ulp).
    // mar níl a fhios againn go bhfuil an earráid dearfach nó diúltach, úsáidimid dhá chomhfhogasú atá spásáilte go cothrom agus tá an earráid uasta 2 ulp againn.
    //
    // is eatramh liobrálach é an "unsafe region" a ghinimid i dtosach.
    // Is an "safe region" eatramh coimeádach a glacadh le linn a ach.
    // muid ag tosú leis an repr ceart laistigh den réigiún neamhshábháilte, agus iarracht a dhéanamh teacht ar an repr is gaire do `v` a bhfuil freisin laistigh den réigiún sábháilte.
    // mura féidir linn, tugaimid suas.
    //
    let plus1 = plus.f + 1;
    // lig plus0 = plus.f, 1;//amháin le haghaidh míniú lig minus0 = minus.f + 1;//amháin le haghaidh míniú
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // easpónant roinnte

    // roinn `plus1` ina chodanna dílse agus codánacha.
    // ráthaítear go n-oirfidh páirteanna bunúsacha i u32, ós rud é go ráthaíonn cumhacht taiscthe `plus < 2^32` agus go bhfuil `plus.f` normalaithe i gcónaí níos lú ná `2^64 - 2^4` mar gheall ar an gceanglas beachtais.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // ríomh an `10^max_kappa` is mó nach mó ná `plus1` (mar sin `plus1 < 10^(max_kappa+1)`).
    // seo teorainn uachtarach de `kappa` thíos.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Teoirim 6.2: más é `k` an slánuimhir is mó st
    // `0 <= y mod 10^k <= y - x`,              ansin tá `V = floor(y / 10^k) * 10^k` in `[x, y]` agus ceann de na huiríll is giorra (leis an líon íosta digití suntasacha) sa raon sin.
    //
    //
    // faigh fad an dhigit `kappa` idir `(minus1, plus1)` de réir Teoirim 6.2.
    // Is féidir Teoirim 6.2 a ghlacadh chun `x` a eisiamh trí `y mod 10^k < y - x` a éileamh ina ionad.
    // (m.sh., `x` =32000, `y` =32777; `kappa` =2 ó `y mod 10 ^ 3=777 <y, x=777`.) tá an algartam ag brath ar an gcéim fíoraithe níos déanaí chun `y` a eisiamh.
    //
    let delta1 = plus1 - minus1;
    // lig delta1int=(delta1>> e) mar usize;//amháin le haghaidh míniú
    let delta1frac = delta1 & ((1 << e) - 1);

    // tabhair páirteanna lárnacha, agus seiceáil an cruinneas ag gach céim.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // digití le tabhairt fós
    loop {
        // bíonn dhigit amháin ar a laghad againn i gcónaí le tabhairt, mar ionróirí `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (leanann sé an `remainder = plus1int % 10^(kappa+1)` sin)
        //
        //

        // roinn `remainder` le `10^kappa`.tá an dá scála de réir `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; tá an `kappa` ceart aimsithe againn.
            let ten_kappa = (ten_kappa as u64) << e; // scála 10 ^ kappa ar ais go dtí an t-easpónant roinnte
            return round_and_weed(
                // SÁBHÁILTEACHT: chuireamar tús leis an gcuimhne sin thuas.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // déan an lúb a bhriseadh nuair a bheidh gach dhigit dhílis tugtha againn.
        // is é `max_kappa + 1` an líon cruinn digití mar `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // invariants a chur ar ais
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // tabhair páirteanna codánacha, agus seiceáil an cruinneas ag gach céim.
    // an uair seo táimid ag brath ar iolraithe arís agus arís eile, mar caillfidh an cruinneas an cruinneas.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // ba chóir go mbeadh an chéad dhigit eile suntasach mar rinneamar tástáil air sin sula ndéantar ionróirí a bhriseadh amach, áit a bhfuil `m = max_kappa + 1` (#de dhigit sa chuid dhílis):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // ní bheidh thar maoil, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // roinn `remainder` le `10^kappa`.
        // tá an dá scála de réir `2^e / 10^kappa`, mar sin tá an dara ceann intuigthe anseo.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // roinnteoir intuigthe
            return round_and_weed(
                // SÁBHÁILTEACHT: chuireamar tús leis an gcuimhne sin thuas.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // invariants a chur ar ais
        kappa -= 1;
        remainder = r;
    }

    // ghin muid gach dhigit suntasach de `plus1`, ach níl muid cinnte an é an ceann is fearr is féidir é.
    // mar shampla, más é 3.00153 `minus1` ... agus 3.01158 is ea `plus1` ..., tá 5 ionadaíocht dhifriúla is giorra ó 3.14154 go 3.14158 ach níl againn ach an ceann is mó.
    // ní mór dúinn an dhigit deireanach a laghdú i ndiaidh a chéile agus seiceáil an é seo an repr is fearr.
    // tá 9 n-iarrthóir ar a mhéad (..1 go ..9), mar sin tá sé seo gasta go leor.(Céim "rounding")
    //
    // seiceálann an fheidhm an bhfuil an repr "optimal" seo laistigh de na raonta ulp, agus freisin, is féidir gur féidir an repr "second-to-optimal" a bheith optamach i ndáiríre mar gheall ar an mbotún slánaithe.
    // i gceachtar cás, filleann sé seo `None`.
    // (Céim "weeding")
    //
    // déantar gach argóint anseo a scála de réir luach coiteann (ach intuigthe) `k`, ionas:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (agus freisin, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (agus freisin, `threshold > plus1v` ó réamh-ionróirí)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // dhá chomhfhogasú a tháirgeadh go `v` (`plus1 - v` i ndáiríre) laistigh de ulpaí 1.5.
        // ba cheart gurb í an ionadaíocht a thiocfaidh as an léiriú is gaire don dá cheann.
        //
        // úsáidtear `plus1 - v` anseo ós rud é go ndéantar ríomhanna maidir le `plus1` d`fhonn overflow/underflow a sheachaint (mar sin na hainmneacha ba chosúil is cosúil a mhalartaítear).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // laghdaigh an dhigit deireanach agus stad ag an léiriú is gaire do `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // oibrímid leis na digití comhfhogasúcháin `w(n)`, atá cothrom le `plus1 - plus1 % 10^kappa` i dtosach.tar éis an comhlacht lúb a reáchtáil `n` uair, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // shocraíomar `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (mar sin `fuílleach= plus1w(0)`) chun seiceálacha a shimpliú.
            // tabhair faoi deara go bhfuil `plus1w(n)` ag méadú i gcónaí.
            //
            // tá trí choinníoll againn le deireadh a chur leis.ní fhágfaidh aon cheann acu an lúb in ann dul ar aghaidh, ach ansin tá ionadaíocht bhailí amháin againn ar a laghad is eol a bheith is gaire do `v + 1 ulp` ar aon nós.
            // cuirfimid in iúl iad mar TC1 trí TC3 ar mhaithe le géire.
            //
            // TC1: `w(n) <= v + 1 ulp`, ie, is é seo an repr deireanach is féidir a bheith ar an gceann is gaire.
            // is ionann é seo agus `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // in éineacht le TC2 (a dhéanann seiceáil an bhfuil `w(n+1)` is valid) ann, seachnaíonn sé seo an ró-shreabhadh a d`fhéadfadh a bheith ann ar ríomh `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, ie, is cinnte nach dtéann an chéad repr eile go `v`.
            // is ionann é seo agus `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // is féidir leis an taobh clé cur thar maoil, ach tá `threshold > plus1v` ar eolas againn, mar sin má tá TC1 bréagach, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` agus is féidir linn tástáil a dhéanamh go sábháilte an bhfuil `threshold - plus1w(n) < 10^kappa` ina ionad.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, ie, is é an chéad repr eile
            // nach gaire do `v + 1 ulp` ná an repr reatha.
            // tugadh `z(n) = plus1v_up - plus1w(n)`, thiocfaidh chun bheith `abs(z(n)) <= abs(z(n+1))`.arís ag glacadh leis go bhfuil TC1 bréagach, tá `z(n) > 0` againn.tá dhá chás le breithniú againn:
            //
            // - nuair a thiocfaidh `z(n+1) >= 0`: TC3 chun bheith ina `z(n) <= z(n+1)`.
            // de réir mar a bhíonn `plus1w(n)` ag méadú, ba cheart go mbeadh `z(n)` ag laghdú agus is léir go bhfuil sé bréagach.
            // - nuair `z(n+1) < 0`:
            //   - TC3a: is é an réamhchoinníoll `plus1v_up < plus1w(n) + 10^kappa`.ag glacadh leis go bhfuil TC2 bréagach, `threshold >= plus1w(n) + 10^kappa` ionas nach féidir leis cur thar maoil.
            //   - TC3b: Éiríonn TC3 ina `z(n) <= -z(n+1)`, ie, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   tugann an TC1 neadaithe `plus1v_up > plus1w(n)`, mar sin ní féidir leis cur thar maoil nó ró-shreabhadh nuair a dhéantar é a chomhcheangal le TC3a.
            //
            // dá bhrí sin, ba cheart dúinn stopadh nuair a `TC1 || TC2 || (TC3a && TC3b)`.tá an méid seo a leanas cothrom lena inbhéartach, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // ní féidir deireadh a chur leis an repr is giorra le `0`
                plus1w += ten_kappa;
            }
        }

        // seiceáil an é an léiriú seo an léiriú is gaire do `v - 1 ulp` freisin.
        //
        // tá sé seo díreach mar an gcéanna leis na coinníollacha foirceanta do `v + 1 ulp`, agus `plus1v_down` in ionad gach `plus1v_up`.
        // déantar anailís thar maoil go cothrom.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // anois tá an ionadaíocht is gaire againn do `v` idir `plus1` agus `minus1`.
        // tá sé seo ró-liobrálach, áfach, mar sin diúltaímid d`aon `w(n)` nach bhfuil idir `plus0` agus `minus0`, ie, `plus1 - plus1w(n) <= minus0` nó `plus1 - plus1w(n) >= plus0`.
        // bainimid úsáid as na fíricí go bhfuil `threshold = plus1 - minus1` agus `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// An cur i bhfeidhm mód is giorra do Grisu le Dragon fallback.
///
/// Ba cheart é seo a úsáid i bhformhór na gcásanna.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SÁBHÁILTEACHT: Níl an seiceálaí iasachta cliste go leor chun ligean dúinn `buf` a úsáid
    // sa dara branch, mar sin déanaimid an saolré a sciúradh anseo.
    // Ach ní dhéanaimid `buf` a athúsáid ach má chuir `format_shortest_opt` `None` ar ais mar sin tá sé seo ceart go leor.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Cur i bhfeidhm mód cruinn agus seasta do Grisu.
///
/// Filleann sé `None` nuair a thabharfadh sé léiriú neamhghníomhach ar ais ar shlí eile.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // teastaíonn trí ghiotán de chruinneas breise uainn ar a laghad
    assert!(!buf.is_empty());

    // `v` a normalú agus a scála.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // roinn `v` ina chodanna dílse agus codánacha.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // tá earráid <1 ulp (Teoirim 5.1) ag sean-`v` agus `v` nua (de réir scála `10^-k`).
    // toisc nach eol dúinn go bhfuil an earráid dearfach nó diúltach, bainimid úsáid as dhá chomhfhogasú atá spásáilte go cothrom agus tá an earráid uasta 2 ulp againn (mar an gcéanna leis an gcás is giorra).
    //
    //
    // is é an sprioc ná an tsraith dhigit cruinn chothromú atá coitianta do `v - 1 ulp` agus `v + 1 ulp` araon, ionas go mbeidh muid muiníneach as a chéile.
    // mura féidir é sin a dhéanamh, níl a fhios againn cé acu ceann atá mar aschur ceart do `v`, mar sin tugaimid suas agus tugaimid ar ais.
    //
    // `err` sainmhínítear `1 ulp * 2^e` anseo (mar an gcéanna leis an ulp in `vfrac`), agus déanfaimid é a scála gach uair a dhéantar scála de `v`.
    //
    //
    //
    let mut err = 1;

    // ríomh an `10^max_kappa` is mó nach mó ná `v` (mar sin `v < 10^(max_kappa+1)`).
    // seo teorainn uachtarach de `kappa` thíos.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // má táimid ag obair leis an teorannú deireanach-dhigit, caithfimid an maolán a ghiorrú roimh an rindreáil iarbhír d`fhonn slánú dúbailte a sheachaint.
    //
    // tabhair faoi deara go gcaithfimid an maolán a mhéadú arís nuair a dhéantar é a shlánú!
    let len = if exp <= limit {
        // Oops, ní féidir linn a tháirgeadh fiú *amháin* dhigit.
        // tá sé seo indéanta nuair a deir muid go bhfuil rud éigin cosúil le 9.5 againn agus é á shlánú go 10.
        //
        // i bprionsabal is féidir linn `possibly_round` a ghlaoch láithreach le maolán folamh, ach d`fhéadfadh ró-shreabhadh a bheith mar thoradh ar scálú `max_ten_kappa << e` faoi 10.
        //
        // dá bhrí sin táimid sloppy anseo agus an raon earráide a leathnú le fachtóir 10.
        // méadóidh sé seo an ráta diúltach bréagach, ach gan ach beagán,*an-* beag;
        // ní féidir ábhar suntasach a thabhairt faoi deara nuair a bhíonn an mantissa níos mó ná 60 giotán.
        //
        // SÁBHÁILTEACHT: `len=0`, mar sin tá an oibleagáid an cuimhne seo a thionscnamh fánach.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // tabhair páirteanna lárnacha.
    // tá an earráid go hiomlán codánach, mar sin ní gá dúinn í a sheiceáil sa chuid seo.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // digití le tabhairt fós
    loop {
        // bíonn dhigit amháin ar a laghad againn i gcónaí chun invariants a thabhairt:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (leanann sé an `remainder = vint % 10^(kappa+1)` sin)
        //
        //

        // roinn `remainder` le `10^kappa`.tá an dá scála de réir `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // an bhfuil an maolán lán?rith an pas slánaithe leis an gcuid eile.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SÁBHÁILTEACHT: tá go leor beart déanta againn ag `len`.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // déan an lúb a bhriseadh nuair a bheidh gach dhigit dhílis tugtha againn.
        // is é `max_kappa + 1` an líon cruinn digití mar `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // invariants a chur ar ais
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // tabhair codanna codánacha.
    //
    // i bprionsabal is féidir linn leanúint ar aghaidh go dtí an dhigit deireanach atá ar fáil agus seiceáil an bhfuil sé cruinn.
    // ar an drochuair táimid ag obair leis na slánuimhreacha meánmhéide críochta, mar sin teastaíonn critéar éigin uainn chun an ró-shreabhadh a bhrath.
    // V8 úsáideann `remainder > err`, a éiríonn bréagach nuair a bhíonn difríocht idir na chéad dhigit `i` suntasach de `v - 1 ulp` agus `v`.
    // diúltaíonn sé seo, áfach, an iomarca ionchuir atá bailí ar shlí eile.
    //
    // ós rud é go bhfuil braite ceart thar maoil ag an gcéim níos déanaí, ina ionad sin bainimid úsáid as critéar níos doichte:
    // leanaimid ar aghaidh go dtí go sáraíonn `err` `10^kappa / 2`, ionas go mbeidh dhá uiríoll chothromaithe nó níos mó sa raon idir `v - 1 ulp` agus `v + 1 ulp`.
    //
    // tá sé seo comhionann leis an gcéad dá chomparáid ó `possibly_round`, don tagairt.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invariants, áit a bhfuil `m = max_kappa + 1` (#de dhigit sa chuid dhílis):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // ní bheidh thar maoil, `2^e * 10 < 2^64`
        err *= 10; // ní bheidh thar maoil, `err * 10 < 2^e * 5 < 2^64`

        // roinn `remainder` le `10^kappa`.
        // tá an dá scála de réir `2^e / 10^kappa`, mar sin tá an dara ceann intuigthe anseo.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // an bhfuil an maolán lán?rith an pas slánaithe leis an gcuid eile.
        if i == len {
            // SÁBHÁILTEACHT: tá go leor beart déanta againn ag `len`.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // invariants a chur ar ais
        remainder = r;
    }

    // tá ríomh breise gan úsáid (is cinnte go dteipeann ar `possibly_round`), mar sin tugaimid suas.
    return None;

    // ghin muid gach dhigit iarrtha de `v`, ar cheart go mbeadh sé mar an gcéanna le digití comhfhreagracha `v - 1 ulp`.
    // anois déanaimid seiceáil an bhfuil ionadaíocht uathúil roinnte ag `v - 1 ulp` agus `v + 1 ulp` araon;féadann sé seo a bheith mar an gcéanna le digití ginte, nó leis an leagan cruinn de na digití sin.
    //
    // má tá uiríll iolracha den raon céanna sa raon, ní féidir linn a bheith cinnte agus ba cheart dúinn `None` a chur ar ais ina ionad.
    //
    // déantar gach argóint anseo a scála de réir luach coiteann (ach intuigthe) `k`, ionas:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // SÁBHÁILTEACHT: an chéad `len` bytes de `buf` mór é a thúsú.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (don tagairt, léiríonn an líne phoncúil an luach cruinn le haghaidh uiríll fhéideartha i líon áirithe digití.)
        //
        //
        // Tá earráid ró-mhór go bhfuil ar a laghad trí uiríoll féidir idir `v - 1 ulp` agus `v + 1 ulp`.
        // ní féidir linn a chinneadh cé acu ceann atá ceart.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // i ndáiríre, is leor ulp 1/2 chun dhá uiríoll fhéideartha a thabhairt isteach.
        // (cuimhnigh go dteastaíonn léiriú uathúil uainn le haghaidh `v - 1 ulp` agus `v + 1 ulp`.) ní bheidh sé seo ag cur thar maoil, mar `ulp < ten_kappa` ón gcéad seiceáil.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // má tá `v + 1 ulp` níos gaire don léiriú cruinn (atá in `buf` cheana féin), is féidir linn filleadh go sábháilte.
        // tabhair faoi deara gur féidir le `v - 1 ulp`*a bheith* níos lú ná an léiriú reatha, ach mar `1 ulp < 10^kappa / 2`, is leor an coinníoll seo:
        // ní féidir leis an bhfad idir `v - 1 ulp` agus an léiriú reatha dul thar `10^kappa / 2`.
        //
        // is ionann an riocht agus `remainder + ulp < 10^kappa / 2`.
        // ós rud é go bhféadfadh sé seo cur thar maoil go héasca, seiceáil an bhfuil `remainder < 10^kappa / 2` ar dtús.
        // tá sé fíoraithe againn cheana féin go bhfuil `ulp < 10^kappa / 2`, chomh fada is nach raibh `10^kappa` ag cur thar maoil tar éis an tsaoil, tá an dara seiceáil ceart go leor.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SÁBHÁILTEACHT: chuir ár nglaoiteoir tús leis an gcuimhne sin.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------fuílleach------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // ar an láimh eile, má tá `v - 1 ulp` níos gaire don léiriú cruinn, ba cheart dúinn slánú agus filleadh.
        // ar an gcúis chéanna ní gá dúinn `v + 1 ulp` a sheiceáil.
        //
        // is ionann an riocht agus `remainder - ulp >= 10^kappa / 2`.
        // arís déanaimid seiceáil ar dtús an bhfuil `remainder > ulp` (tabhair faoi deara nach `remainder >= ulp` é seo, toisc nach bhfuil `10^kappa` nialas riamh).
        //
        // tabhair faoi deara freisin go bhfuil `remainder - ulp <= 10^kappa`, mar sin ní sháraíonn an dara seiceáil.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // SÁBHÁILTEACHT: caithfidh ár gcuimhne a bheith tosaithe ag an té atá ag glaoch.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // ná cuir ach dhigit bhreise leis nuair a iarrtar an cruinneas seasta orainn.
                // ní mór dúinn a sheiceáil freisin, má bhí an maolán bunaidh folamh, ní féidir an dhigit bhreise a chur leis ach nuair a bhíonn `exp == limit` (cás edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // SÁBHÁILTEACHT: chuireamarne agus ár nglaoiteoir tús leis an gcuimhne sin.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // ar shlí eile táimid doomed (ie, tá roinnt luachanna idir `v - 1 ulp` agus `v + 1 ulp` ag slánú agus tá luachanna eile ag slánú) agus ag tabhairt suas.
        //
        None
    }
}

/// An cur i bhfeidhm mód cruinn agus seasta do Grisu le Dragon backback.
///
/// Ba cheart é seo a úsáid i bhformhór na gcásanna.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SÁBHÁILTEACHT: Níl an seiceálaí iasachta cliste go leor chun ligean dúinn `buf` a úsáid
    // sa dara branch, mar sin déanaimid an saolré a sciúradh anseo.
    // Ach ní dhéanaimid `buf` a athúsáid ach má chuir `format_exact_opt` `None` ar ais mar sin tá sé seo ceart go leor.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}