//! Déantar luach snámhphointe a dhíchódú i gcodanna aonair agus i raonta earráide.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Luach teoranta díchódaithe gan síniú, sa chaoi:
///
/// - Is ionann an luach bunaidh agus `mant * 2^exp`.
///
/// - Slánóidh aon uimhir ó `(mant - minus)*2^exp` go `(mant + plus)* 2^exp` go dtí an luach bunaidh.
/// Níl an raon uilechuimsitheach ach nuair atá `inclusive` `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// An mantissa de réir scála.
    pub mant: u64,
    /// An raon earráide níos ísle.
    pub minus: u64,
    /// An raon earráide uachtarach.
    pub plus: u64,
    /// An t-easpónant roinnte i mbonn 2.
    pub exp: i16,
    /// Fíor nuair a bhíonn an raon earráide uilechuimsitheach.
    ///
    /// In IEEE 754, tá sé seo fíor nuair a bhí an mantissa bunaidh fiú.
    pub inclusive: bool,
}

/// Luach díchódaithe gan síniú.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinities, dearfach nó diúltach.
    Infinite,
    /// Nialais, dearfach nó diúltach.
    Zero,
    /// Líon teoranta le réimsí breise díchódaithe.
    Finite(Decoded),
}

/// Cineál snámhphointe is féidir a `dhíchódú '.
pub trait DecodableFloat: RawFloat + Copy {
    /// An luach normalaithe dearfach íosta.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Filleann sé comhartha (fíor nuair atá sé diúltach) agus luach `FullDecoded` ón uimhir snámhphointe tugtha.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // comharsana: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode caomhnaíonn an t-easpónant i gcónaí, agus mar sin tá an mantissa de réir scála le haghaidh fo-ábhair.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // comharsana: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // áit maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // comharsana: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}