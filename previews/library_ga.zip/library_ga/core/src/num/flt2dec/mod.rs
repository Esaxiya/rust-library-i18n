/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// cé go ndéantar é seo a dhoiciméadú go fairsing, is prionsabal príobháideach é seo nach ndéantar a phoibliú ach le haghaidh tástála.
// ná nocht dúinn.
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// Halgartaim giniúna digití.
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// Íosmhéid an mhaoláin atá riachtanach don mhodh is giorra.
///
/// Tá sé rud beag fánach a dhíorthú, ach seo ceann móide an líon uasta digití deachúlacha suntasacha ó halgartaim formáidithe leis an toradh is giorra.
///
/// Is é an fhoirmle bheacht `ceil(# bits in mantissa * log_10 2 + 1)`.
pub const MAX_SIG_DIGITS: usize = 17;

/// Nuair a bhíonn digití deachúil in `d`, méadaigh an dhigit deireanach agus iomadaíodh an t-iompar.
/// Filleann sé an chéad dhigit eile nuair a athraíonn sé an fad.
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i + 1..n] is gach ní
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 babhtaí go 1000..000 le easpónant méadaithe
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // babhta maolán folamh (rud beag aisteach ach réasúnta)
            Some(b'1')
        }
    }
}

/// Páirteanna formáidithe.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// I bhfianaise líon na ndigití nialasacha.
    Zero(usize),
    /// Uimhir liteartha suas le 5 dhigit.
    Num(u16),
    /// Cóip focal ar fhocal de bhearta tugtha.
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// Filleann sé an fad beart cruinn atá sa chuid áirithe.
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// Scríobhann cuid isteach sa mhaolán a sholáthraítear.
    /// Filleann sé líon na mbeart scríofa, nó `None` mura leor an maolán.
    /// (Féadfaidh sé fós bearta atá scríofa i bpáirt a fhágáil sa mhaolán; ná bí ag brath air sin.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// Toradh formáidithe ina bhfuil cuid amháin nó níos mó.
/// Is féidir é seo a scríobh chuig an maolán beart nó é a thiontú go dtí an tsreang leithdháilte.
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// Slice beart a léiríonn comhartha, bíodh sé `""`, `"-"` nó `"+"`.
    pub sign: &'static str,
    /// Páirteanna formáidithe le tabhairt tar éis comhartha agus stuáil roghnach nialas.
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// Filleann sé an fad beacht cruinn de thoradh formáidithe comhcheangailte.
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// Scríobhann gach cuid formáidithe isteach sa mhaolán a sholáthraítear.
    /// Filleann sé líon na mbeart scríofa, nó `None` mura leor an maolán.
    /// (Féadfaidh sé fós bearta atá scríofa i bpáirt a fhágáil sa mhaolán; ná bí ag brath air sin.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// Formáidí a thugtar digití deachúil `0.<...buf...> * 10^exp` san fhoirm deachúil le líon áirithe digití codánacha ar a laghad.
///
/// Stóráiltear an toradh ar eagar na gcodanna a sholáthraítear agus tugtar slice de chodanna scríofa ar ais.
///
/// `frac_digits` is féidir a bheith níos lú ná líon na ndigití codánacha iarbhír in `buf`;
/// tabharfar neamhaird air agus priontálfar digití iomlána.Ní úsáidtear é ach chun nialais bhreise a phriontáil tar éis digití rindreáilte.
/// Mar sin ciallaíonn `frac_digits` de 0 nach ndéanfaidh sé ach digití áirithe agus aon rud eile a phriontáil.
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // má tá an srian ar shuíomh an dhigit dheireanaigh, glactar leis go bhfuil `buf` padded ar chlé leis na nialais fhíorúla.
    // is ionann líon na nialais fhíorúla, `nzeroes`, agus `max(0, exp + frac_digits - buf.len())`, ionas nach mbeidh suíomh an dhigit dheireanaigh `exp - buf.len() - nzeroes` níos mó ná `-frac_digits`:
    //
    //
    //                       |<-virtual->|
    //       | <----buf----> |nialais |exp
    //    0. 1 2 3 4 5 6 7 8 9 _ _ _ _ _ _ x 10
    //    |                  |           |
    // 10 ^ exp 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` déantar é a ríomh ina n-aonar do gach cás d`fhonn ró-shreabhadh a sheachaint.
    //

    if exp <= 0 {
        // tá an pointe deachúil roimh dhigit rindreáilte: [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..4`.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..3`.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // tá an pointe deachúil taobh istigh de dhigit rindreáilte: [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..4`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..3`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // déantar an pointe deachúil tar éis digití rindreáilte: [1234][____0000] nó [1234][__][.][__].
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..4`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..2`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// Formáidíonn sé na digití deachúil `0.<...buf...> * 10^exp` a thugtar san fhoirm easpónantúil agus an líon áirithe digití suntasacha tugtha ar a laghad.
///
/// Nuair a bheidh `upper` `true`, cuirfear `E` roimh an easpónant;ar shlí eile is é sin `e`.
/// Stóráiltear an toradh ar eagar na gcodanna a sholáthraítear agus tugtar slice de chodanna scríofa ar ais.
///
/// `min_digits` is féidir leo a bheith níos lú ná líon na ndigití suntasacha iarbhír in `buf`;
/// tabharfar neamhaird air agus priontálfar digití iomlána.Ní úsáidtear é ach chun nialais bhreise a phriontáil tar éis digití rindreáilte.
/// Mar sin, ciallaíonn `min_digits == 0` nach ndéanfaidh sé ach na digití a thugtar agus aon rud eile a phriontáil.
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x 10 ^ exp= 1.234 x 10 ^ (exp-1)
    let exp = exp as i32 - 1; // seachain an sreabhadh isteach nuair is é i16::MIN exp
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..n + 2`.
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// Sínigh roghanna formáidithe.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// Priontaí `-` do na luachanna diúltacha neamh-nialasacha amháin.
    Minus, // -inf -1 0 0 1 inf nan
    /// Priontaí `-` d`aon luachanna diúltacha amháin (an nialas diúltach san áireamh).
    MinusRaw, // -inf -1 -0 0 1 inf nan
    /// Priontaí `-` do na luachanna diúltacha neamh-nialasacha, nó `+` a mhalairt.
    MinusPlus, // -inf -1 +0 +0 +1 + inf nan
    /// Priontaí `-` d'aon luachanna diúltacha (lena n-áirítear an nialas diúltach), nó `+` a mhalairt.
    MinusPlusRaw, // -inf -1 -0 +0 +1 + inf nan
}

/// Filleann sé an tsreang statach beart a fhreagraíonn don chomhartha atá le formáidiú.
/// Is féidir é a bheith `""`, `"+"` nó `"-"`.
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// Formáidí an uimhir snámhphointe tugtha san fhoirm deachúil le líon áirithe digití codánacha ar a laghad.
/// Stóráiltear an toradh ar eagar na gcodanna a sholáthraítear agus úsáid á baint as maolán beart mar scríobadh.
/// `upper` níl sé in úsáid faoi láthair ach fágtar faoi chinneadh future cás luachanna neamhchríochnaithe a athrú, ie, `inf` agus `nan`.
///
/// Is é an chéad chuid atá le tabhairt ná `Part::Sign` i gcónaí (is féidir é a bheith ina shreang folamh mura ndéantar aon chomhartha).
///
/// `format_shortest` ba cheart gurb í an bhunfheidhm giniúna digití.
/// Ba cheart dó an chuid den mhaolán a thosaigh sé a thabhairt ar ais.
/// Is dócha go mbeadh `strategy::grisu::format_shortest` uait le haghaidh seo.
///
/// `frac_digits` is féidir a bheith níos lú ná líon na ndigití codánacha iarbhír in `v`;
/// tabharfar neamhaird air agus priontálfar digití iomlána.Ní úsáidtear é ach chun nialais bhreise a phriontáil tar éis digití rindreáilte.
/// Mar sin ciallaíonn `frac_digits` de 0 nach ndéanfaidh sé ach digití áirithe agus aon rud eile a phriontáil.
///
/// Ba chóir go mbeadh an maolán beart beart `MAX_SIG_DIGITS` ar a laghad.
/// Ba cheart go mbeadh 4 chuid ar a laghad ar fáil, mar gheall ar an gcás is measa mar `[+][0.][0000][2][0000]` le `frac_digits = 10`.
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..2`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// Formáidí an uimhir snámhphointe tugtha san fhoirm deachúil nó san fhoirm easpónantúil, ag brath ar an easpónant a leanann as.
/// Stóráiltear an toradh ar eagar na gcodanna a sholáthraítear agus úsáid á baint as maolán beart mar scríobadh.
/// `upper` úsáidtear chun cás luachanna neamhchríochnaithe (`inf` agus `nan`) nó cás réimír an easpónantóra (`e` nó `E`) a chinneadh.
/// Is é an chéad chuid atá le tabhairt ná `Part::Sign` i gcónaí (is féidir é a bheith ina shreang folamh mura ndéantar aon chomhartha).
///
/// `format_shortest` ba cheart gurb í an bhunfheidhm giniúna digití.
/// Ba cheart dó an chuid den mhaolán a thosaigh sé a thabhairt ar ais.
/// Is dócha go mbeadh `strategy::grisu::format_shortest` uait le haghaidh seo.
///
/// Is tuple `(lo, hi)` é an `dec_bounds` sa chaoi is go ndéantar an uimhir a fhormáidiú mar deachúil ach amháin nuair a bhíonn `10^lo <= V < 10^hi` ann.
/// Tabhair faoi deara gurb é seo an *dealraitheach*`V` in ionad an `v` iarbhír!Dá bhrí sin ní féidir aon easpónant chló san fhoirm easpónantúil a bheith sa réimse, ag seachaint aon mearbhaill.
///
///
/// Ba chóir go mbeadh an maolán beart beart `MAX_SIG_DIGITS` ar a laghad.
/// Ba chóir go mbeadh 6 chuid ar a laghad ar fáil, mar gheall ar an gcás is measa mar `[+][1][.][2345][e][-][6]`.
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// Filleann sé comhfhogasú sách amh (faoi cheangal uachtarach) don uasmhéid maolánach arna ríomh ón easpónant díchódaithe tugtha.
///
/// Is é an teorainn bheacht:
///
/// - nuair `exp < 0`, is é `ceil(log_10 (5^-exp * (2^64 - 1)))` an fad uasta.
/// - nuair `exp >= 0`, is é `ceil(log_10 (2^exp * (2^64 - 1)))` an fad uasta.
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` níos lú ná `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)`, atá níos lú ná `20 + (1 + exp* log_10 x)` ar a seal.
/// Úsáidimid na fíricí go bhfuil `log_10 2 < 5/16` agus `log_10 5 < 12/16`, atá leordhóthanach chun ár gcuspóirí.
///
/// Cén fáth a dteastaíonn seo uainn?Líonfaidh feidhmeanna `format_exact` an maolán iomlán mura bhfuil siad teoranta ag an srian deireanach dhigit, ach is féidir go bhfuil líon na ndigití a iarrtar mór go mór (abair, 30,000 dhigit).
///
/// Líonfar formhór mór an mhaoláin le nialais, mar sin nílimid ag iarraidh an maolán uile a leithdháileadh roimh ré.
/// Dá bharr sin, d`aon argóintí ar leith,
/// Ba cheart go mbeadh 826 beart maolán leordhóthanach do `f64`.Déan comparáid idir seo agus an uimhir iarbhír don chás is measa: 770 beart (nuair `exp = -1074`).
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// Formáidí a thugtar uimhir snámhphointe san fhoirm easpónantúil agus líon díreach digití suntasacha tugtha.
/// Stóráiltear an toradh ar eagar na gcodanna a sholáthraítear agus úsáid á baint as maolán beart mar scríobadh.
/// `upper` úsáidtear chun a chinneadh an cás an réimír easpónant (`e` nó `E`).
/// Is é an chéad chuid atá le tabhairt ná `Part::Sign` i gcónaí (is féidir é a bheith ina shreang folamh mura ndéantar aon chomhartha).
///
/// `format_exact` ba cheart gurb í an bhunfheidhm giniúna digití.
/// Ba cheart dó an chuid den mhaolán a thosaigh sé a thabhairt ar ais.
/// Is dócha go mbeadh `strategy::grisu::format_exact` uait le haghaidh seo.
///
/// Ba chóir go mbeadh an maolán beart beart `ndigits` ar a laghad mura bhfuil `ndigits` chomh mór sin nach scríobhfar ach an líon seasta digití riamh.
/// (Is é an pointe tipping do `f64` ná thart ar 800, mar sin ba chóir go mbeadh 1000 beart go leor.) Ba cheart go mbeadh 6 chuid ar a laghad ar fáil, mar gheall ar an gcás is measa mar `[+][1][.][2345][e][-][6]`.
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..3`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// Formáidí a thugtar uimhir snámhphointe san fhoirm deachúil agus an líon digití codánach tugtha go díreach.
/// Stóráiltear an toradh ar eagar na gcodanna a sholáthraítear agus úsáid á baint as maolán beart mar scríobadh.
/// `upper` níl sé in úsáid faoi láthair ach fágtar faoi chinneadh future cás luachanna neamhchríochnaithe a athrú, ie, `inf` agus `nan`.
/// Is é an chéad chuid atá le tabhairt ná `Part::Sign` i gcónaí (is féidir é a bheith ina shreang folamh mura ndéantar aon chomhartha).
///
/// `format_exact` ba cheart gurb í an bhunfheidhm giniúna digití.
/// Ba cheart dó an chuid den mhaolán a thosaigh sé a thabhairt ar ais.
/// Is dócha go mbeadh `strategy::grisu::format_exact` uait le haghaidh seo.
///
/// Ba cheart go mbeadh an maolán beart go leor don aschur mura bhfuil `frac_digits` chomh mór sin nach scríobhfar ach an líon seasta digití riamh.
/// (Is é an pointe tipping do `f64` thart ar 800, agus ba chóir go 1000 bytes mbeadh go leor.) Ba chóir go mbeadh ar a laghad 4 codanna atá ar fáil, mar gheall ar an gcás is measa cosúil `[+][0.][0000][2][0000]` le `frac_digits = 10`.
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..2`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // *Is* féidir go bhfuil `frac_digits` ridiculously mór.
            // `format_exact` cuirfear deireadh le digití rindreála i bhfad níos luaithe sa chás seo, toisc go bhfuil muid teoranta go docht ag `maxlen`.
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // níorbh fhéidir an srian a chomhlíonadh, mar sin ba cheart go mbeadh nialas ann is cuma `exp`.
                // ní chuimsíonn sé seo an cás nár comhlíonadh an srian ach tar éis an chothromú deiridh;is cás rialta é le `exp = limit + 1`.
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..2`.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // SÁBHÁILTEACHT: níor thosaíomar ach na heilimintí `..1`.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}