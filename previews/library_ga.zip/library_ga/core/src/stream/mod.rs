//! Atriall asincrónach in-inúsáidte.
//!
//! Más luachanna asincrónacha iad futures, ansin is atarrthóirí neamhshioncrónacha iad sruthanna.
//! Má tá tú ag fáil féin le bailiúchán asynchronous de chineál éigin, agus a theastaíonn chun oibríocht ar na gnéithe de bhailiúcháin sin, beidh tú ag rith go tapa 'streams' isteach.
//! Úsáidtear sruthanna go mór i gcód idiomatach asyncrónach Rust, mar sin is fiú dul i dtaithí orthu.
//!
//! Sula ndéantar níos mó a mhíniú, déanaimis labhairt faoi struchtúr an mhodúil seo:
//!
//! # Organization
//!
//! Tá an modúl seo eagraithe den chuid is mó de réir cineáil:
//!
//! * [Traits] is iad seo an chuid lárnach: sainmhíníonn na traits seo an cineál sruthanna atá ann agus cad is féidir leat a dhéanamh leo.Is fiú modhanna na traits seo a chur le roinnt ama staidéir breise.
//! * Soláthraíonn feidhmeanna roinnt bealaí cabhracha chun roinnt sruthanna bunúsacha a chruthú.
//! * Is minic gurb iad struchtúir cineálacha cineálacha na modhanna éagsúla ar traits an mhodúil seo.De ghnáth is mian leat breathnú ar an modh a chruthaíonn an `struct`, seachas an `struct` féin.
//! Le haghaidh tuilleadh sonraí faoi cén fáth, féach '[Cur Chun Feidhme Sruth](#feidhme-sruth) ".
//!
//! [Traits]: #traits
//!
//! Sin é!Déanaimis tochailt isteach i sruthanna.
//!
//! # Stream
//!
//! Is é croí agus anam an mhodúil seo an [`Stream`] trait.Is cosúil le croí [`Stream`] mar seo:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Murab ionann agus `Iterator`, déanann `Stream` idirdhealú idir an modh [`poll_next`] a úsáidtear agus `Stream` á chur i bhfeidhm, agus modh (to-be-implemented) `next` a úsáidtear agus sruth á ídiú.
//!
//! Ní gá do thomhaltóirí `Stream` ach `next` a mheas, a thugann future a thugann `Option<Stream::Item>` ar ais nuair a ghlaoitear air.
//!
//! Tabharfaidh an future a chuir `next` ar ais toradh `Some(Item)` chomh fada agus a bheidh eilimintí ann, agus a luaithe a bheidh siad uile ídithe, tabharfaidh sé `None` le fios go bhfuil an t-atriall críochnaithe.
//! Má táimid ag fanacht ar rud éigin asincrónach le réiteach, fanfaidh an future go dtí go mbeidh an sruth réidh le toradh arís.
//!
//! Féadfaidh sruthanna aonair atriall a atosú, agus mar sin má ghlaonn tú ar `next` arís féadfaidh sé nó sí `Some(Item)` a thabhairt ar ais arís ag pointe éigin.
//!
//! Cuimsíonn sainmhíniú iomlán [`Stream`] roinnt modhanna eile freisin, ach is modhanna réamhshocraithe iad, tógtha ar bharr [`poll_next`], agus mar sin faigheann tú iad saor in aisce.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Sruthán Feidhmithe
//!
//! Tá dhá chéim i gceist le sruth de do chuid féin a chruthú: `struct` a chruthú chun staid an tsrutha a shealbhú, agus ansin [`Stream`] a chur i bhfeidhm don `struct` sin.
//!
//! Déanaimis sruth darb ainm `Counter` a chomhaireamh ó `1` go `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Gcéad dul síos, an struct:
//!
//! /// Sruthán a chomhaireamh ó aon go cúig
//! struct Counter {
//!     count: usize,
//! }
//!
//! // ba mhaith linn ár n-count chun tús a chur ag ceann amháin, mar sin a ligean add a modh new() go cabhrú leat.
//! // Níl sé seo riachtanach go hiomlán, ach tá sé áisiúil.
//! // Tabhair faoi deara go bhfuil muid ag tosú `count` ag náid, beidh orainn a fheiceáil cén fáth i chun feidhme `poll_next()`'s thíos.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Ansin, táimid i bhfeidhm `Stream` dár `Counter`:
//!
//! impl Stream for Counter {
//!     // beidh muid chomhaireamh le usize
//!     type Item = usize;
//!
//!     // poll_next() an t-aon mhodh riachtanach
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Méadú ar ár gcomhaireamh.Sin é an fáth gur thosaíomar ag nialas.
//!         self.count += 1;
//!
//!         // Seiceáil a fheiceáil má tá muid comhaireamh críochnaithe nó nach bhfuil.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Tá sruthanna *leisciúil*.Ciallaíonn sé seo nach ndéanann _do_ mórán a chruthú le sruth a chruthú.Ní tharlaíonn aon rud i ndáiríre go dtí go nglaonn tú `next`.
//! Uaireanta is foinse mearbhaill é seo nuair a chruthaítear sruth dá fho-iarsmaí amháin.
//! Tabharfaidh an tiomsaitheoir rabhadh dúinn faoin gcineál seo iompair:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;