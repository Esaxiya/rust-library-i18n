use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Comhéadan chun déileáil le Iterators asynchronous.
///
/// Is é seo an príomhshruth trait.
/// Chun tuilleadh a fháil amach faoi choincheap na sruthanna i gcoitinne, féach an [module-level documentation] le do thoil.
/// Go háirithe, b`fhéidir gur mhaith leat a fháil amach conas [implement `Stream`][impl] a dhéanamh.
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// An cineál earraí a thugann an sruthán amach.
    type Item;

    /// Iarracht a tharraingt amach an luach eile den sruth, ag clárú an tasc atá ann faoi láthair le haghaidh wakeup mura bhfuil an luach ar fáil go fóill, agus ag filleadh `None` má tá an sruth ídithe.
    ///
    /// # Luach tuairisceáin
    ///
    /// Tá roinnt luachanna filleadh ar féidir, gach rud a léiríonn stát sruth ar leith:
    ///
    /// - `Poll::Pending` ciallaíonn nach bhfuil an sruth ar luach chugainn réidh go fóill.Cinnteoidh cur chun feidhme go gcuirfear an tasc reatha in iúl nuair a bheidh an chéad luach eile réidh.
    ///
    /// - `Poll::Ready(Some(val))` ciallaíonn sé gur éirigh leis an sruth luach, `val`, a tháirgeadh agus féadfaidh sé luachanna breise a tháirgeadh ar ghlaonna `poll_next` ina dhiaidh sin.
    ///
    /// - `Poll::Ready(None)` ciallaíonn sé go bhfuil deireadh leis an sruth, agus níor cheart `poll_next` a agairt arís.
    ///
    /// # Panics
    ///
    /// Chomh luath agus a sruth críochnaithe (ar ais `Ready(None)` from `poll_next`), ag iarraidh a modh `poll_next` arís Féadfaidh panic, bloc go deo, nó ar chúis cineálacha eile de fadhbanna; an trait `Stream` leagann aon cheanglais maidir le héifeachtaí den sórt sin glaoch.
    ///
    /// Mar sin féin, toisc nach bhfuil `unsafe` marcáilte ar an modh `poll_next`, tá gnáthrialacha Rust i bhfeidhm: ní mór do ghlaonna a bheith ina gcúis le hiompar neamhshainithe riamh (éilliú cuimhne, úsáid mhícheart feidhmeanna `unsafe`, nó a leithéid), beag beann ar staid an tsrutha.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Filleann sé na teorainneacha ar an gcuid eile den sruthán.
    ///
    /// Go sonrach, tuairisceáin `size_hint()` tuple sa chás go bhfuil an chéad eilimint is ísle faoi cheangal, agus is é an dara gné an cheangal uachtair.
    ///
    /// Is é an dara leath den tuple atá ar ais ar [`Option`]`<`[`usize`] `>`.
    /// Ciallaíonn [`None`] anseo nach bhfuil aon cheangal uachtarach ar eolas, nó go bhfuil an teorainn uachtarach níos mó ná [`usize`].
    ///
    /// # Nótaí cur chun feidhme
    ///
    /// Ní chuirtear i bhfeidhm go mbíonn líon dearbhaithe na n-eilimintí mar thoradh ar chur chun feidhme srutha.Féadfaidh sruth Buggy teacht isteach níos lú ná an luach is ísle faoi cheangal nó níos mó ná an cheangal uachtair na n-eilimintí.
    ///
    /// `size_hint()` tá sé beartaithe go príomha go n-úsáidfear é le haghaidh barrfheabhsúcháin mar spás a chur in áirithe d`eilimintí an tsrutha, ach ní gá muinín a bheith agat aisti, seiceálacha faoi theorainneacha a fhágáil ar lár i gcód neamhshábháilte.
    /// Níor cheart cur i bhfeidhm mícheart de `size_hint()` mar thoradh ar sáruithe sábháilteachta chuimhne.
    ///
    /// É sin ráite, ba cheart cur chun feidhme a chur ar fáil meastachán ceart, mar gheall ar shlí go mbeadh sé sárú ar prótacal na trait ar.
    ///
    /// Filleann an cur chun feidhme réamhshocraithe `(0,` [`None`]`)`atá ceart d'aon sruth.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}