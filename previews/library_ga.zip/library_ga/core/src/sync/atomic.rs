//! Cineálacha adamhacha
//!
//! Soláthraíonn cineálacha adamhacha cumarsáid primitive cuimhne roinnte idir snáitheanna, agus is bloic thógála iad de chineálacha comhthráthacha eile.
//!
//! Sainmhíníonn an modúl seo leaganacha adamhacha de líon roghnaithe de chineálacha primitive, lena n-áirítear [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], etc.
//! Cineálacha Adamhach oibríochtaí i láthair go, nuair a úsáidtear i gceart, nuashonruithe sioncrónú idir snáitheanna.
//!
//! Glacann gach modh [`Ordering`] a léiríonn neart an bhacainn chuimhne don oibríocht sin.Tá na horduithe seo mar an gcéanna leis an [C++20 atomic orderings][1].Le haghaidh tuilleadh faisnéise féach an [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Tá sé sábháilte athróga adamhacha a roinnt idir snáitheanna (cuireann siad [`Sync`] i bhfeidhm) ach ní sholáthraíonn siad féin an mheicníocht chun an [threading model](../../../std/thread/index.html#the-threading-model) de Rust a roinnt agus a leanúint.
//!
//! Is é an bealach is coitianta le hathróg adamhach a roinnt ná é a chur i [`Arc`][arc] (pointeoir roinnte comhaireamh tagartha adamhach).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Is féidir cineálacha adamhacha a stóráil in athróga statacha, agus iad a thosú ag baint úsáide as na tosaithe tosaigh seasmhach mar [`AtomicBool::new`].Is minic a úsáidtear staitisticí adamhacha le haghaidh tosaithe leisciúla domhanda.
//!
//! # Portability
//!
//! Ráthaítear gur [lock-free] gach cineál adamhach sa mhodúl seo má tá siad ar fáil.Ciallaíonn sé seo nach bhfuil siad a fháil go hinmheánach ar mutex domhanda.Ní ráthaítear go mbeidh cineálacha agus oibríochtaí adamhacha saor ó fanacht.
//! Ciallaíonn sé seo gur féidir oibríochtaí mar `fetch_or` a chur i bhfeidhm le lúb comparáide agus babhtála.
//!
//! Féadfar oibríochtaí adamhacha a chur i bhfeidhm ag an gciseal treoracha le adamh níos mó.Mar shampla, úsáideann roinnt ardáin treoracha adamhacha 4-beart chun `AtomicI8` a chur i bhfeidhm.
//! Tabhair faoi deara nár cheart go mbeadh tionchar ag an aithris seo ar chruinneas an chóid, níl ann ach rud a bheith ar an eolas faoi.
//!
//! B`fhéidir nach mbeidh na cineálacha adamhacha sa mhodúl seo ar fáil ar gach ardán.Tá na cineálacha adamhacha anseo ar fáil go forleathan, áfach, agus go hiondúil is féidir brath orthu.Is iad seo a leanas roinnt eisceachtaí suntasacha:
//!
//! * PowerPC agus níl cineálacha `AtomicU64` nó `AtomicI64` ag ardáin MIPS le leideanna 32-giotán.
//! * ARM ní sholáthraíonn ardáin mar `armv5te` nach bhfuil le haghaidh Linux ach oibríochtaí `load` agus `store`, agus ní thacaíonn siad le hoibríochtaí Déan comparáid agus Babhtáil (CAS), mar shampla `swap`, `fetch_add`, srl.
//! Ina theannta sin ar Linux, na hoibríochtaí CAS i bhfeidhm trí [operating system support], is féidir a thagann le pionós feidhmíochta.
//! * ARM ní sholáthraíonn spriocanna le `thumbv6m` ach oibríochtaí `load` agus `store`, agus ní thacaíonn siad le hoibríochtaí Déan comparáid agus Babhtáil (CAS), mar shampla `swap`, `fetch_add`, srl.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Tabhair faoi deara gur féidir ardáin future a chur leis nach bhfuil tacaíocht acu freisin do roinnt oibríochtaí adamhacha.Beidh an cód iniompartha is mó ag iarraidh a bheith cúramach faoi na cineálacha adamhacha a úsáidtear.
//! `AtomicUsize` agus `AtomicIsize` go ginearálta na cinn is iniompartha, ach fiú ansin níl siad ar fáil i ngach áit.
//! Le haghaidh tagartha, éilíonn an leabharlann `std` adamh de mhéid pointeora, cé nach bhfuil `core` ag teastáil.
//!
//! Faoi láthair beidh ort `#[cfg(target_arch)]` a úsáid go príomha chun cód le tiomsú adamhach a thiomsú go coinníollach.Tá `#[cfg(target_has_atomic)]` éagobhsaí mar aon fhéadfar a chobhsú san future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Cnagán simplí:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Fan go scaoilfidh an snáithe eile an glas
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Coinnigh comhaireamh domhanda snáitheanna beo:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Cineál Boole is féidir a roinnt go sábháilte idir snáitheanna.
///
/// Tá an léiriú cuimhne céanna ag an gcineál seo agus atá ag [`bool`].
///
/// **Tabhair faoi deara**: Tá an cineál ar fáil ach amháin ar ardáin a thacaíonn ualaí adamhach agus siopaí de `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Cruthaíonn sé `AtomicBool` tosaithe go `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Tá Seol bhfeidhm go hintuigthe ar feadh AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Cineál pointeora amh is féidir a roinnt go sábháilte idir snáitheanna.
///
/// Tá an cineál hionadaíocht in-chuimhne chéanna mar `*mut T`.
///
/// **Nóta**: Níl an cineál seo ar fáil ach ar ardáin a thacaíonn le hualaí adamhacha agus stórais leideanna.
/// Braitheann a mhéid ar an sprioc pointeoir ar mhéid.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Cruthaíonn null `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Orduithe cuimhne adamhach
///
/// Sonraíonn orduithe cuimhne an bealach a dhéanann oibríochtaí adamhacha sioncrónú cuimhne.
/// Ina [`Ordering::Relaxed`] is laige, ní dhéantar ach an chuimhne a mbíonn an oibríocht i dteagmháil léi go díreach a shioncronú.
/// Ar an láimh eile, sioncronaíonn péire ualach-stór oibríochtaí [`Ordering::SeqCst`] cuimhne eile agus ag an am céanna caomhnaíonn siad ord iomlán oibríochtaí den sórt sin ar fud na snáitheanna go léir.
///
///
/// Tá orderings Cuimhne Rust ar [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Le haghaidh tuilleadh faisnéise féach an [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Gan aon srianta ordaithe, ach oibríochtaí adamhacha.
    ///
    /// Comhfhreagraíonn sé do [`memory_order_relaxed`] i C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Nuair a dhéantar iad a chúpláil le siopa, déantar gach oibríocht roimhe seo a ordú sula ndéantar aon ualach den luach seo a ordú le [`Acquire`] (nó níos láidre).
    ///
    /// Go háirithe, go léir, scríobhann roimhe le feiceáil ag na snáitheanna a dhéanamh an [`Acquire`] (nó níos) ualach den luach.
    ///
    /// Tabhair faoi deara go n-eascraíonn oibríocht ualaigh [`Relaxed`] as an ordú seo a úsáid le haghaidh oibríochta a chomhcheanglaíonn ualaí agus stórais!
    ///
    /// Níl an t-ordú seo infheidhmithe ach maidir le hoibríochtaí ar féidir leo siopa a dhéanamh.
    ///
    /// Comhfhreagraíonn [`memory_order_release`] i C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Nuair dteannta le ualach, más rud é go scríobhadh an luach luchtaithe ag oibríocht siopa le [`Release`] (nó níos) a ordú, ansin chun bheith na hoibríochtaí dá éis d'ordaigh ina dhiaidh sin siopa.
    /// Go háirithe, feicfear sonraí scríofa os comhair an stóir i ngach ualach ina dhiaidh sin.
    ///
    /// Tabhair faoi deara go n-eascraíonn oibríocht stórais [`Relaxed`] as an ordú seo a úsáid le haghaidh oibríochta a chomhcheanglaíonn ualaí agus stórais!
    ///
    /// Níl an t-ordú seo infheidhmithe ach maidir le hoibríochtaí ar féidir leo ualach a dhéanamh.
    ///
    /// Comhfhreagraíonn sé do [`memory_order_acquire`] i C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// An bhfuil na héifeachtaí dá [`Acquire`] agus [`Release`] chéile:
    /// Le haghaidh ualaí úsáideann sé ordú [`Acquire`].I gcás siopaí Úsáideann sé an ordú [`Release`].
    ///
    /// Tabhair faoi deara gur féidir, i gcás `compare_and_swap`, go gcríochnóidh an oibríocht gan aon stór a dhéanamh agus dá bhrí sin níl ach ordú [`Acquire`] aici.
    ///
    /// Mar sin féin, ní bheidh `AcqRel` dhéanamh bhealaí isteach [`Relaxed`].
    ///
    /// Níl an t-ordú seo infheidhmithe ach maidir le hoibríochtaí a chomhcheanglaíonn ualaí agus stórais.
    ///
    /// Comhfhreagraíonn [`memory_order_acq_rel`] i C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Cosúil le [`Acquire`]/[`Release`]/[`AcqRel`](le haghaidh oibríochtaí luchtaithe, stórála agus luchtaithe le siopa, faoi seach) leis an ráthaíocht bhreise go bhfeicfidh na snáitheanna gach oibríocht atá comhsheasmhach go seicheamhach san ord céanna .
    ///
    ///
    /// Comhfhreagraíonn [`memory_order_seq_cst`] i C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// Cuireadh tús le [`AtomicBool`] go `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Cruthaigh `AtomicBool` nua.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Filleann tagairt inathraithe don [`bool`] bunúsach.
    ///
    /// Tá sé seo sábháilte toisc go ráthaíonn an tagairt inathraithe nach bhfuil aon snáitheanna eile ag teacht i gcomhthráth leis na sonraí adamhacha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // SÁBHÁILTEACHT: ráthaíonn an tagairt inathraithe úinéireacht uathúil.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Faigh rochtain adamhach ar `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // SÁBHÁILTEACHT: ráthaíonn an tagairt inathraithe úinéireacht uathúil, agus
        // Is ailíniú `bool` agus `Self` araon 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Ídíonn an adamhach agus tuairisceáin an luach atá.
    ///
    /// Tá sé seo sábháilte toisc go ráthaíonn pas `self` de réir luacha nach bhfuil aon snáitheanna eile ag teacht i gcomhthráth leis na sonraí adamhacha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Luchtaíonn sé luach ón bool.
    ///
    /// `load` glacann sé argóint [`Ordering`] a chuireann síos ar ordú cuimhne na hoibríochta seo.
    /// Is iad na luachanna féideartha [`SeqCst`], [`Acquire`] agus [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics más é `order` [`Release`] nó [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // SÁBHÁILTEACHT: aon rásaí sonraí a chosc ag intrinsics adamhach agus an amh
        // tá an pointeoir a cuireadh isteach bailí mar fuair muid é ó thagairt.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Stórálann sé luach isteach sa bool.
    ///
    /// `store` glacann sé argóint [`Ordering`] a chuireann síos ar ordú cuimhne na hoibríochta seo.
    /// Is iad na luachanna féideartha [`SeqCst`], [`Release`] agus [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics más é `order` [`Acquire`] nó [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // SÁBHÁILTEACHT: aon rásaí sonraí a chosc ag intrinsics adamhach agus an amh
        // tá an pointeoir a cuireadh isteach bailí mar fuair muid é ó thagairt.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Stórálann sé luach isteach sa bool, ag filleadh an luacha roimhe seo.
    ///
    /// `swap` glacann sé argóint [`Ordering`] a chuireann síos ar ordú cuimhne na hoibríochta seo.Is féidir gach modh ordaithe.
    /// Tabhair faoi deara go ndéanann [`Acquire`] an stór mar chuid den oibríocht seo [`Relaxed`], agus má úsáideann [`Release`] an chuid ualaigh [`Relaxed`].
    ///
    ///
    /// **Note:** Tá an modh seo ar fáil ach amháin ar ardáin a thacaíonn le hoibríochtaí adamhach ar `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Dunnes le luach isteach sa [`bool`] má tá an luach reatha a úsáid mar luach `current` an gcéanna.
    ///
    /// Is é an luach ar ais i gcónaí ar an luach roimhe.Má tá sé cothrom le `current`, rinneadh an luach a nuashonrú.
    ///
    /// `compare_and_swap` glacann sé argóint [`Ordering`] freisin a chuireann síos ar ordú cuimhne na hoibríochta seo.
    /// Tabhair faoi deara go bhféadfadh go dteipfeadh ar an oibríocht fiú agus [`AcqRel`] á húsáid agat, agus dá bhrí sin nach ndéanann sí ach ualach `Acquire` a dhéanamh, ach nach mbeadh séimeantaic `Release` aici.
    /// Trí [`Acquire`] a úsáid, bíonn an stór mar chuid den oibríocht seo [`Relaxed`] má tharlaíonn sé, agus má úsáidtear [`Release`] déantar an chuid ualaigh [`Relaxed`].
    ///
    /// **Note:** Tá an modh seo ar fáil ach amháin ar ardáin a thacaíonn le hoibríochtaí adamhach ar `u8`.
    ///
    /// # Ag aistriú go `compare_exchange` agus `compare_exchange_weak`
    ///
    /// `compare_and_swap` comhionann le `compare_exchange` leis an mapáil seo a leanas le haghaidh orduithe cuimhne:
    ///
    /// Bunaidh |Rath |Teip
    /// -------- | ------- | -------
    /// Scíth a ligean |Scíth a ligean |Fháil Relaxed |Faigh |Scaoileadh a Fháil |Scaoileadh |Relaxed AcqRel |AcqRel |SeqCst a Fháil |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` Tá cead ag theipeann spuriously fiú nuair éiríonn leis an gcomparáid, a chuireann ar chumas an Tiomsaitheoir a ghiniúint níos fearr tionól cód nuair an chur i gcomparáid agus tá babhtála úsáidtear i lúb.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Dunnes le luach isteach sa [`bool`] má tá an luach reatha a úsáid mar luach `current` an gcéanna.
    ///
    /// Is toradh é an luach toraidh a léiríonn an raibh an luach nua scríofa agus an luach roimhe sin ann.
    /// Ráthaítear go mbeidh an luach seo cothrom le `current` má éiríonn leis.
    ///
    /// `compare_exchange` tógann sé dhá argóint [`Ordering`] chun cur síos a dhéanamh ar ordú cuimhne na hoibríochta seo.
    /// `success` déanann sé cur síos ar an ordú riachtanach don oibríocht léamh-mhodhnú-scríobh a tharlaíonn má éiríonn leis an gcomparáid le `current`.
    /// `failure` déanann sé cur síos ar an ordú riachtanach don oibríocht ualaigh a tharlaíonn nuair a theipeann ar an gcomparáid.
    /// Trí [`Acquire`] a úsáid mar ordú rathúlachta is cuid den oibríocht seo [`Relaxed`] an stór, agus trí [`Release`] a úsáid déantar an t-ualach rathúil [`Relaxed`].
    ///
    /// Ní féidir leis an ordú teip a bheith ach [`SeqCst`], [`Acquire`] nó [`Relaxed`] agus caithfidh sé a bheith coibhéiseach leis an ordú rath nó níos laige.
    ///
    /// **Note:** Tá an modh seo ar fáil ach amháin ar ardáin a thacaíonn le hoibríochtaí adamhach ar `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Dunnes le luach isteach sa [`bool`] má tá an luach reatha a úsáid mar luach `current` an gcéanna.
    ///
    /// Murab ionann agus [`AtomicBool::compare_exchange`], ligtear don fheidhm seo cliseadh go spraíúil fiú nuair a éiríonn leis an gcomparáid, rud a d`fhéadfadh cód níos éifeachtaí a bheith mar thoradh air ar roinnt ardáin.
    ///
    /// Is toradh é an luach toraidh a léiríonn an raibh an luach nua scríofa agus an luach roimhe sin ann.
    ///
    /// `compare_exchange_weak` tógann sé dhá argóint [`Ordering`] chun cur síos a dhéanamh ar ordú cuimhne na hoibríochta seo.
    /// `success` déanann sé cur síos ar an ordú riachtanach don oibríocht léamh-mhodhnú-scríobh a tharlaíonn má éiríonn leis an gcomparáid le `current`.
    /// `failure` déanann sé cur síos ar an ordú riachtanach don oibríocht ualaigh a tharlaíonn nuair a theipeann ar an gcomparáid.
    /// Trí [`Acquire`] a úsáid mar ordú rathúlachta is cuid den oibríocht seo [`Relaxed`] an stór, agus trí [`Release`] a úsáid déantar an t-ualach rathúil [`Relaxed`].
    /// Ní féidir leis an ordú teip a bheith ach [`SeqCst`], [`Acquire`] nó [`Relaxed`] agus caithfidh sé a bheith coibhéiseach leis an ordú rath nó níos laige.
    ///
    /// **Note:** Tá an modh seo ar fáil ach amháin ar ardáin a thacaíonn le hoibríochtaí adamhach ar `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Loighciúil "and" le luach boole.
    ///
    /// Déanann sé oibríocht loighciúil "and" ar an luach reatha agus ar an argóint `val`, agus socraíonn sé an luach nua don toradh.
    ///
    /// Filleann sé an luach roimhe seo.
    ///
    /// `fetch_and` glacann sé argóint [`Ordering`] a chuireann síos ar ordú cuimhne na hoibríochta seo.Is féidir gach modh ordaithe.
    /// Tabhair faoi deara go ndéanann [`Acquire`] an stór mar chuid den oibríocht seo [`Relaxed`], agus má úsáideann [`Release`] an chuid ualaigh [`Relaxed`].
    ///
    ///
    /// **Note:** Tá an modh seo ar fáil ach amháin ar ardáin a thacaíonn le hoibríochtaí adamhach ar `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Loighciúil "nand" le luach boole.
    ///
    /// Déanann sé oibríocht loighciúil "nand" ar an luach reatha agus ar an argóint `val`, agus socraíonn sé an luach nua don toradh.
    ///
    /// Filleann sé an luach roimhe seo.
    ///
    /// `fetch_nand` glacann sé argóint [`Ordering`] a chuireann síos ar ordú cuimhne na hoibríochta seo.Is féidir gach modh ordaithe.
    /// Tabhair faoi deara go ndéanann [`Acquire`] an stór mar chuid den oibríocht seo [`Relaxed`], agus má úsáideann [`Release`] an chuid ualaigh [`Relaxed`].
    ///
    ///
    /// **Note:** Tá an modh seo ar fáil ach amháin ar ardáin a thacaíonn le hoibríochtaí adamhach ar `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Ní féidir linn atomic_nand a úsáid anseo mar go bhféadfadh bool a bheith ann a bhfuil luach neamhbhailí aige.
        // Tarlaíonn sé seo toisc go bhfuil an oibríocht adamhach dhéanamh leis slánuimhir 8-giotán go hinmheánach, a leagfadh an uachtair 7 giotán.
        //
        // Mar sin, linn a úsáid ach fetch_xor nó babhtála ina ionad.
        if val {
            // ! (x&fíor)== !x Ní mór dúinn an bool a aisiompú.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&bréagach)==fíor Ní mór dúinn an bool a shocrú go fíor.
            //
            self.swap(true, order)
        }
    }

    /// Loighciúil "or" le luach boole.
    ///
    /// Déanann sé oibríocht loighciúil "or" ar an luach reatha agus ar an argóint `val`, agus socraíonn sé an luach nua don toradh.
    ///
    /// Filleann sé an luach roimhe seo.
    ///
    /// `fetch_or` glacann sé argóint [`Ordering`] a chuireann síos ar ordú cuimhne na hoibríochta seo.Is féidir gach modh ordaithe.
    /// Tabhair faoi deara go ndéanann [`Acquire`] an stór mar chuid den oibríocht seo [`Relaxed`], agus má úsáideann [`Release`] an chuid ualaigh [`Relaxed`].
    ///
    ///
    /// **Note:** Tá an modh seo ar fáil ach amháin ar ardáin a thacaíonn le hoibríochtaí adamhach ar `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Loighciúil "xor" le luach boole.
    ///
    /// Déanann sé oibríocht loighciúil "xor" ar an luach reatha agus ar an argóint `val`, agus socraíonn sé an luach nua don toradh.
    ///
    /// Filleann sé an luach roimhe seo.
    ///
    /// `fetch_xor` glacann sé argóint [`Ordering`] a chuireann síos ar ordú cuimhne na hoibríochta seo.Is féidir gach modh ordaithe.
    /// Tabhair faoi deara go ndéanann [`Acquire`] an stór mar chuid den oibríocht seo [`Relaxed`], agus má úsáideann [`Release`] an chuid ualaigh [`Relaxed`].
    ///
    ///
    /// **Note:** Tá an modh seo ar fáil ach amháin ar ardáin a thacaíonn le hoibríochtaí adamhach ar `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Tugann pointeoir inathraithe ar ais don [`bool`] bunúsach.
    ///
    /// Is rás sonraí é léamha neamh-adamhacha a dhéanamh agus a scríobh ar an slánuimhir a leanann dá bharr.
    /// Tá an modh seo den chuid is mó úsáideach le haghaidh ITF, i gcás ina bhféadfadh an síniú fheidhm a úsáid `*mut bool` ionad `&AtomicBool`.
    ///
    /// Ag filleadh ar pointeoir `*mut` ó tagairt comhroinnte don adamhach atá sábháilte mar gheall ar obair na cineálacha adamhach le mutability istigh.
    /// Athraíonn gach modhnú ar adamhach an luach trí thagairt roinnte, agus féadann siad é sin a dhéanamh go sábháilte fad a úsáideann siad oibríochtaí adamhacha.
    /// Teastaíonn bloc `unsafe` chun aon úsáid a bhaint as an pointeoir amh a chuirtear ar ais agus ní mór dó an srian céanna a sheasamh: caithfidh oibríochtaí air a bheith adamhach.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Fetches an luach, agus feidhm a chur i bhfeidhm air a thugann luach nua roghnach ar ais.Filleann `Result` de `Ok(previous_value)` má chuir an fheidhm `Some(_)` ar ais, `Err(previous_value)` eile.
    ///
    /// Note: D`fhéadfadh sé seo an fheidhm a ghlaoch arís agus arís eile má athraíodh an luach ó snáitheanna eile idir an dá linn, fad a fhilleann an fheidhm `Some(_)`, ach ní bheidh an fheidhm curtha i bhfeidhm ach uair amháin ar an luach stóráilte.
    ///
    ///
    /// `fetch_update` tógann sé dhá argóint [`Ordering`] chun cur síos a dhéanamh ar ordú cuimhne na hoibríochta seo.
    /// Déanann an chéad cheann cur síos ar an ordú riachtanach nuair a éiríonn leis an oibríocht sa deireadh agus déanann an dara ceann cur síos ar an ordú riachtanach le haghaidh ualaí.
    /// Freagraíonn siad seo do rath agus orduithe teip [`AtomicBool::compare_exchange`] faoi seach.
    ///
    /// Trí [`Acquire`] a úsáid mar ordú rathúlachta is cuid den oibríocht seo [`Relaxed`] an stór, agus trí [`Release`] a úsáid déantar an t-ualach rathúil deiridh [`Relaxed`].
    /// Ní féidir le hordú ualaigh (failed) a bheith ach [`SeqCst`], [`Acquire`] nó [`Relaxed`] agus caithfidh sé a bheith coibhéiseach leis an ordú rath nó níos laige.
    ///
    /// **Note:** Tá an modh seo ar fáil ach amháin ar ardáin a thacaíonn le hoibríochtaí adamhach ar `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Cruthaigh `AtomicPtr` nua.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Filleann sé tagairt inathraithe don phointeoir bunúsach.
    ///
    /// Tá sé seo sábháilte toisc go ráthaíonn an tagairt inathraithe nach bhfuil aon snáitheanna eile ag teacht i gcomhthráth leis na sonraí adamhacha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Faigh rochtain adamhach ar phointeoir.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - ráthaíonn an tagairt inathraithe úinéireacht uathúil.
        //  - tá ailíniú `*mut T` agus `Self` mar an gcéanna ar gach ardán le tacaíocht ó rust, mar atá fíoraithe thuas.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Ídíonn an adamhach agus tuairisceáin an luach atá.
    ///
    /// Tá sé seo sábháilte toisc go ráthaíonn pas `self` de réir luacha nach bhfuil aon snáitheanna eile ag teacht i gcomhthráth leis na sonraí adamhacha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Luchtaíonn sé luach ón bpointeoir.
    ///
    /// `load` glacann sé argóint [`Ordering`] a chuireann síos ar ordú cuimhne na hoibríochta seo.
    /// Is iad na luachanna féideartha [`SeqCst`], [`Acquire`] agus [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics más é `order` [`Release`] nó [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Siopaí le luach isteach sa pointeoir.
    ///
    /// `store` glacann sé argóint [`Ordering`] a chuireann síos ar ordú cuimhne na hoibríochta seo.
    /// Is iad na luachanna féideartha [`SeqCst`], [`Release`] agus [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics más é `order` [`Acquire`] nó [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Siopaí le luach isteach sa pointeoir, ag filleadh ar an luach roimhe.
    ///
    /// `swap` glacann sé argóint [`Ordering`] a chuireann síos ar ordú cuimhne na hoibríochta seo.Is féidir gach modh ordaithe.
    /// Tabhair faoi deara go ndéanann [`Acquire`] an stór mar chuid den oibríocht seo [`Relaxed`], agus má úsáideann [`Release`] an chuid ualaigh [`Relaxed`].
    ///
    ///
    /// **Note:** Tá an modh seo ar fáil ach amháin ar ardáin a thacaíonn le hoibríochtaí adamhach ar leideanna.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Stórálann sé luach isteach sa phointeoir má tá an luach reatha mar an gcéanna leis an luach `current`.
    ///
    /// Is é an luach ar ais i gcónaí ar an luach roimhe.Má tá sé cothrom le `current`, rinneadh an luach a nuashonrú.
    ///
    /// `compare_and_swap` glacann sé argóint [`Ordering`] freisin a chuireann síos ar ordú cuimhne na hoibríochta seo.
    /// Tabhair faoi deara go bhféadfadh go dteipfeadh ar an oibríocht fiú agus [`AcqRel`] á húsáid agat, agus dá bhrí sin nach ndéanann sí ach ualach `Acquire` a dhéanamh, ach nach mbeadh séimeantaic `Release` aici.
    /// Trí [`Acquire`] a úsáid, bíonn an stór mar chuid den oibríocht seo [`Relaxed`] má tharlaíonn sé, agus má úsáidtear [`Release`] déantar an chuid ualaigh [`Relaxed`].
    ///
    /// **Note:** Tá an modh seo ar fáil ach amháin ar ardáin a thacaíonn le hoibríochtaí adamhach ar leideanna.
    ///
    /// # Ag aistriú go `compare_exchange` agus `compare_exchange_weak`
    ///
    /// `compare_and_swap` comhionann le `compare_exchange` leis an mapáil seo a leanas le haghaidh orduithe cuimhne:
    ///
    /// Bunaidh |Rath |Teip
    /// -------- | ------- | -------
    /// Scíth a ligean |Scíth a ligean |Fháil Relaxed |Faigh |Scaoileadh a Fháil |Scaoileadh |Relaxed AcqRel |AcqRel |SeqCst a Fháil |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` Tá cead ag theipeann spuriously fiú nuair éiríonn leis an gcomparáid, a chuireann ar chumas an Tiomsaitheoir a ghiniúint níos fearr tionól cód nuair an chur i gcomparáid agus tá babhtála úsáidtear i lúb.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Stórálann sé luach isteach sa phointeoir má tá an luach reatha mar an gcéanna leis an luach `current`.
    ///
    /// Is toradh é an luach toraidh a léiríonn an raibh an luach nua scríofa agus an luach roimhe sin ann.
    /// Ráthaítear go mbeidh an luach seo cothrom le `current` má éiríonn leis.
    ///
    /// `compare_exchange` tógann sé dhá argóint [`Ordering`] chun cur síos a dhéanamh ar ordú cuimhne na hoibríochta seo.
    /// `success` déanann sé cur síos ar an ordú riachtanach don oibríocht léamh-mhodhnú-scríobh a tharlaíonn má éiríonn leis an gcomparáid le `current`.
    /// `failure` déanann sé cur síos ar an ordú riachtanach don oibríocht ualaigh a tharlaíonn nuair a theipeann ar an gcomparáid.
    /// Trí [`Acquire`] a úsáid mar ordú rathúlachta is cuid den oibríocht seo [`Relaxed`] an stór, agus trí [`Release`] a úsáid déantar an t-ualach rathúil [`Relaxed`].
    ///
    /// Ní féidir leis an ordú teip a bheith ach [`SeqCst`], [`Acquire`] nó [`Relaxed`] agus caithfidh sé a bheith coibhéiseach leis an ordú rath nó níos laige.
    ///
    /// **Note:** Tá an modh seo ar fáil ach amháin ar ardáin a thacaíonn le hoibríochtaí adamhach ar leideanna.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Stórálann sé luach isteach sa phointeoir má tá an luach reatha mar an gcéanna leis an luach `current`.
    ///
    /// Murab ionann agus [`AtomicPtr::compare_exchange`], tá an fheidhm seo cead ag theipeann spuriously fiú nuair éiríonn leis an comparáid a dhéanamh, is féidir a theacht i cód níos éifeachtaí ar roinnt ardáin.
    ///
    /// Is toradh é an luach toraidh a léiríonn an raibh an luach nua scríofa agus an luach roimhe sin ann.
    ///
    /// `compare_exchange_weak` tógann sé dhá argóint [`Ordering`] chun cur síos a dhéanamh ar ordú cuimhne na hoibríochta seo.
    /// `success` déanann sé cur síos ar an ordú riachtanach don oibríocht léamh-mhodhnú-scríobh a tharlaíonn má éiríonn leis an gcomparáid le `current`.
    /// `failure` déanann sé cur síos ar an ordú riachtanach don oibríocht ualaigh a tharlaíonn nuair a theipeann ar an gcomparáid.
    /// Trí [`Acquire`] a úsáid mar ordú rathúlachta is cuid den oibríocht seo [`Relaxed`] an stór, agus trí [`Release`] a úsáid déantar an t-ualach rathúil [`Relaxed`].
    /// Ní féidir leis an ordú teip a bheith ach [`SeqCst`], [`Acquire`] nó [`Relaxed`] agus caithfidh sé a bheith coibhéiseach leis an ordú rath nó níos laige.
    ///
    /// **Note:** Tá an modh seo ar fáil ach amháin ar ardáin a thacaíonn le hoibríochtaí adamhach ar leideanna.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SÁBHÁILTEACHT: Tá an intreach seo neamhshábháilte toisc go bhfeidhmíonn sé ar phointeoir amh
        // ach tá a fhios againn go cinnte go bhfuil an pointeoir bailí (ní bhfuair muid é ach ó `UnsafeCell` atá againn trí thagairt) agus tugann an oibríocht adamhach féin deis dúinn ábhar `UnsafeCell` a threáitear go sábháilte.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Fetches an luach, agus feidhm a chur i bhfeidhm air a thugann luach nua roghnach ar ais.Filleann `Result` de `Ok(previous_value)` má chuir an fheidhm `Some(_)` ar ais, `Err(previous_value)` eile.
    ///
    /// Note: D`fhéadfadh sé seo an fheidhm a ghlaoch arís agus arís eile má athraíodh an luach ó snáitheanna eile idir an dá linn, fad a fhilleann an fheidhm `Some(_)`, ach ní bheidh an fheidhm curtha i bhfeidhm ach uair amháin ar an luach stóráilte.
    ///
    ///
    /// `fetch_update` tógann sé dhá argóint [`Ordering`] chun cur síos a dhéanamh ar ordú cuimhne na hoibríochta seo.
    /// Déanann an chéad cheann cur síos ar an ordú riachtanach nuair a éiríonn leis an oibríocht sa deireadh agus déanann an dara ceann cur síos ar an ordú riachtanach le haghaidh ualaí.
    /// Freagraíonn siad seo do rath agus orduithe teip [`AtomicPtr::compare_exchange`] faoi seach.
    ///
    /// Trí [`Acquire`] a úsáid mar ordú rathúlachta is cuid den oibríocht seo [`Relaxed`] an stór, agus trí [`Release`] a úsáid déantar an t-ualach rathúil deiridh [`Relaxed`].
    /// Ní féidir le hordú ualaigh (failed) a bheith ach [`SeqCst`], [`Acquire`] nó [`Relaxed`] agus caithfidh sé a bheith coibhéiseach leis an ordú rath nó níos laige.
    ///
    /// **Note:** Tá an modh seo ar fáil ach amháin ar ardáin a thacaíonn le hoibríochtaí adamhach ar leideanna.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Athraíonn a `bool` isteach `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Críochnaíonn an macra seo gan úsáid a bhaint as roinnt ailtireachtaí.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Cineál slánuimhir is féidir a roinnt go sábháilte idir snáitheanna.
        ///
        /// Tá an léiriú cuimhne céanna ag an gcineál seo agus atá ag an gcineál slánuimhir bhunúsach, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Le haghaidh tuilleadh faoi na difríochtaí idir na cineálacha adamhach agus cineálacha neamh-adamhach chomh maith le faisnéis maidir le inaistritheacht den chineál seo, féach le do thoil an [module-level documentation].
        ///
        ///
        /// **Note:** Níl an cineál seo ar fáil ach ar ardáin a thacaíonn le hualaí adamhacha agus stórais de [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Slánuimhir adamhach initialized go `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Tá Seol bhfeidhm hintuigthe.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Cruthaíonn slánuimhir adamhach nua.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Tugann sé tagairt inathraithe don slánuimhir bhunúsach ar ais.
            ///
            /// Tá sé seo sábháilte toisc go ráthaíonn an tagairt inathraithe nach bhfuil aon snáitheanna eile ag teacht i gcomhthráth leis na sonraí adamhacha.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// lig mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - ráthaíonn an tagairt inathraithe úinéireacht uathúil.
                //  - tá ailíniú `$int_type` agus `Self` mar an gcéanna, mar a gealladh le $cfg_align agus arna fhíorú thuas.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Ídíonn an adamhach agus tuairisceáin an luach atá.
            ///
            /// Tá sé seo sábháilte toisc go ráthaíonn pas `self` de réir luacha nach bhfuil aon snáitheanna eile ag teacht i gcomhthráth leis na sonraí adamhacha.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Ualaí a luach ón tslánuimhir is adamhach.
            ///
            /// `load` glacann sé argóint [`Ordering`] a chuireann síos ar ordú cuimhne na hoibríochta seo.
            /// Is iad na luachanna féideartha [`SeqCst`], [`Acquire`] agus [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics más é `order` [`Release`] nó [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Siopaí le luach isteach sa slánuimhir adamhach.
            ///
            /// `store` glacann sé argóint [`Ordering`] a chuireann síos ar ordú cuimhne na hoibríochta seo.
            ///  Is iad na luachanna féideartha [`SeqCst`], [`Release`] agus [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics más é `order` [`Acquire`] nó [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Stórálann sé luach isteach sa tslánuimhir adamhach, ag filleadh an luacha roimhe seo.
            ///
            /// `swap` glacann sé argóint [`Ordering`] a chuireann síos ar ordú cuimhne na hoibríochta seo.Is féidir gach modh ordaithe.
            /// Tabhair faoi deara go ndéanann [`Acquire`] an stór mar chuid den oibríocht seo [`Relaxed`], agus má úsáideann [`Release`] an chuid ualaigh [`Relaxed`].
            ///
            ///
            /// **Nóta**: Níl an modh seo ar fáil ach ar ardáin a thacaíonn le hoibríochtaí adamhacha ar
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Stórálann sé luach isteach sa tslánuimhir adamhach má tá an luach reatha mar an gcéanna leis an luach `current`.
            ///
            /// Is é an luach ar ais i gcónaí ar an luach roimhe.Má tá sé cothrom le `current`, rinneadh an luach a nuashonrú.
            ///
            /// `compare_and_swap` glacann sé argóint [`Ordering`] freisin a chuireann síos ar ordú cuimhne na hoibríochta seo.
            /// Tabhair faoi deara go bhféadfadh go dteipfeadh ar an oibríocht fiú agus [`AcqRel`] á húsáid agat, agus dá bhrí sin nach ndéanann sí ach ualach `Acquire` a dhéanamh, ach nach mbeadh séimeantaic `Release` aici.
            ///
            /// Trí [`Acquire`] a úsáid, bíonn an stór mar chuid den oibríocht seo [`Relaxed`] má tharlaíonn sé, agus má úsáidtear [`Release`] déantar an chuid ualaigh [`Relaxed`].
            ///
            /// **Nóta**: Níl an modh seo ar fáil ach ar ardáin a thacaíonn le hoibríochtaí adamhacha ar
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Ag aistriú go `compare_exchange` agus `compare_exchange_weak`
            ///
            /// `compare_and_swap` comhionann le `compare_exchange` leis an mapáil seo a leanas le haghaidh orduithe cuimhne:
            ///
            /// Bunaidh |Rath |Teip
            /// -------- | ------- | -------
            /// Scíth a ligean |Scíth a ligean |Fháil Relaxed |Faigh |Scaoileadh a Fháil |Scaoileadh |Relaxed AcqRel |AcqRel |SeqCst a Fháil |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` Tá cead ag theipeann spuriously fiú nuair éiríonn leis an gcomparáid, a chuireann ar chumas an Tiomsaitheoir a ghiniúint níos fearr tionól cód nuair an chur i gcomparáid agus tá babhtála úsáidtear i lúb.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Stórálann sé luach isteach sa tslánuimhir adamhach má tá an luach reatha mar an gcéanna leis an luach `current`.
            ///
            /// Is toradh é an luach toraidh a léiríonn an raibh an luach nua scríofa agus an luach roimhe sin ann.
            /// Ráthaítear go mbeidh an luach seo cothrom le `current` má éiríonn leis.
            ///
            /// `compare_exchange` tógann sé dhá argóint [`Ordering`] chun cur síos a dhéanamh ar ordú cuimhne na hoibríochta seo.
            /// `success` déanann sé cur síos ar an ordú riachtanach don oibríocht léamh-mhodhnú-scríobh a tharlaíonn má éiríonn leis an gcomparáid le `current`.
            /// `failure` déanann sé cur síos ar an ordú riachtanach don oibríocht ualaigh a tharlaíonn nuair a theipeann ar an gcomparáid.
            /// Trí [`Acquire`] a úsáid mar ordú rathúlachta is cuid den oibríocht seo [`Relaxed`] an stór, agus trí [`Release`] a úsáid déantar an t-ualach rathúil [`Relaxed`].
            ///
            /// Ní féidir leis an ordú teip a bheith ach [`SeqCst`], [`Acquire`] nó [`Relaxed`] agus caithfidh sé a bheith coibhéiseach leis an ordú rath nó níos laige.
            ///
            /// **Nóta**: Níl an modh seo ar fáil ach ar ardáin a thacaíonn le hoibríochtaí adamhacha ar
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Stórálann sé luach isteach sa tslánuimhir adamhach má tá an luach reatha mar an gcéanna leis an luach `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// ligtear don fheidhm seo cliseadh go spraíúil fiú nuair a éiríonn leis an gcomparáid, rud a d`fhéadfadh cód níos éifeachtaí a bheith mar thoradh air ar roinnt ardáin.
            /// Is toradh é an luach toraidh a léiríonn an raibh an luach nua scríofa agus an luach roimhe sin ann.
            ///
            /// `compare_exchange_weak` tógann sé dhá argóint [`Ordering`] chun cur síos a dhéanamh ar ordú cuimhne na hoibríochta seo.
            /// `success` déanann sé cur síos ar an ordú riachtanach don oibríocht léamh-mhodhnú-scríobh a tharlaíonn má éiríonn leis an gcomparáid le `current`.
            /// `failure` déanann sé cur síos ar an ordú riachtanach don oibríocht ualaigh a tharlaíonn nuair a theipeann ar an gcomparáid.
            /// Trí [`Acquire`] a úsáid mar ordú rathúlachta is cuid den oibríocht seo [`Relaxed`] an stór, agus trí [`Release`] a úsáid déantar an t-ualach rathúil [`Relaxed`].
            ///
            /// Ní féidir leis an ordú teip a bheith ach [`SeqCst`], [`Acquire`] nó [`Relaxed`] agus caithfidh sé a bheith coibhéiseach leis an ordú rath nó níos laige.
            ///
            /// **Nóta**: Níl an modh seo ar fáil ach ar ardáin a thacaíonn le hoibríochtaí adamhacha ar
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// lig mut old= val.load(Ordering::Relaxed);
            /// lúb {lig nua=sean * 2;
            ///     mheaitseáil val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Cuireann sé leis an luach reatha, ag filleadh an luacha roimhe seo.
            ///
            /// Fillteann an oibríocht seo timpeall ar ró-shreabhadh.
            ///
            /// `fetch_add` glacann sé argóint [`Ordering`] a chuireann síos ar ordú cuimhne na hoibríochta seo.Is féidir gach modh ordaithe.
            /// Tabhair faoi deara go ndéanann [`Acquire`] an stór mar chuid den oibríocht seo [`Relaxed`], agus má úsáideann [`Release`] an chuid ualaigh [`Relaxed`].
            ///
            ///
            /// **Nóta**: Níl an modh seo ar fáil ach ar ardáin a thacaíonn le hoibríochtaí adamhacha ar
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Dealaigh ón luach reatha, ag filleadh an luacha roimhe seo.
            ///
            /// Fillteann an oibríocht seo timpeall ar ró-shreabhadh.
            ///
            /// `fetch_sub` glacann sé argóint [`Ordering`] a chuireann síos ar ordú cuimhne na hoibríochta seo.Is féidir gach modh ordaithe.
            /// Tabhair faoi deara go ndéanann [`Acquire`] an stór mar chuid den oibríocht seo [`Relaxed`], agus má úsáideann [`Release`] an chuid ualaigh [`Relaxed`].
            ///
            ///
            /// **Nóta**: Níl an modh seo ar fáil ach ar ardáin a thacaíonn le hoibríochtaí adamhacha ar
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" leis an luach reatha.
            ///
            /// Déanann sé oibríocht "and" bitwise ar an luach reatha agus ar an argóint `val`, agus socraíonn sé an luach nua don toradh.
            ///
            /// Filleann sé an luach roimhe seo.
            ///
            /// `fetch_and` glacann sé argóint [`Ordering`] a chuireann síos ar ordú cuimhne na hoibríochta seo.Is féidir gach modh ordaithe.
            /// Tabhair faoi deara go ndéanann [`Acquire`] an stór mar chuid den oibríocht seo [`Relaxed`], agus má úsáideann [`Release`] an chuid ualaigh [`Relaxed`].
            ///
            ///
            /// **Nóta**: Níl an modh seo ar fáil ach ar ardáin a thacaíonn le hoibríochtaí adamhacha ar
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" leis an luach reatha.
            ///
            /// Fheidhmíonn a bitwise "nand" ngníomh an luach reatha agus an argóint `val`, agus leagann an luach nua go dtí an toradh.
            ///
            /// Filleann sé an luach roimhe seo.
            ///
            /// `fetch_nand` glacann sé argóint [`Ordering`] a chuireann síos ar ordú cuimhne na hoibríochta seo.Is féidir gach modh ordaithe.
            /// Tabhair faoi deara go ndéanann [`Acquire`] an stór mar chuid den oibríocht seo [`Relaxed`], agus má úsáideann [`Release`] an chuid ualaigh [`Relaxed`].
            ///
            ///
            /// **Nóta**: Níl an modh seo ar fáil ach ar ardáin a thacaíonn le hoibríochtaí adamhacha ar
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" leis an luach reatha.
            ///
            /// Fheidhmíonn a bitwise "or" ngníomh an luach reatha agus an argóint `val`, agus leagann an luach nua go dtí an toradh.
            ///
            /// Filleann sé an luach roimhe seo.
            ///
            /// `fetch_or` glacann sé argóint [`Ordering`] a chuireann síos ar ordú cuimhne na hoibríochta seo.Is féidir gach modh ordaithe.
            /// Tabhair faoi deara go ndéanann [`Acquire`] an stór mar chuid den oibríocht seo [`Relaxed`], agus má úsáideann [`Release`] an chuid ualaigh [`Relaxed`].
            ///
            ///
            /// **Nóta**: Níl an modh seo ar fáil ach ar ardáin a thacaíonn le hoibríochtaí adamhacha ar
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" leis an luach reatha.
            ///
            /// Déanann sé oibríocht "xor" bitwise ar an luach reatha agus ar an argóint `val`, agus socraíonn sé an luach nua don toradh.
            ///
            /// Filleann sé an luach roimhe seo.
            ///
            /// `fetch_xor` glacann sé argóint [`Ordering`] a chuireann síos ar ordú cuimhne na hoibríochta seo.Is féidir gach modh ordaithe.
            /// Tabhair faoi deara go ndéanann [`Acquire`] an stór mar chuid den oibríocht seo [`Relaxed`], agus má úsáideann [`Release`] an chuid ualaigh [`Relaxed`].
            ///
            ///
            /// **Nóta**: Níl an modh seo ar fáil ach ar ardáin a thacaíonn le hoibríochtaí adamhacha ar
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Fetches an luach, agus feidhm a chur i bhfeidhm air a thugann luach nua roghnach ar ais.Filleann `Result` de `Ok(previous_value)` má chuir an fheidhm `Some(_)` ar ais, `Err(previous_value)` eile.
            ///
            /// Note: D`fhéadfadh sé seo an fheidhm a ghlaoch arís agus arís eile má athraíodh an luach ó snáitheanna eile idir an dá linn, fad a fhilleann an fheidhm `Some(_)`, ach ní bheidh an fheidhm curtha i bhfeidhm ach uair amháin ar an luach stóráilte.
            ///
            ///
            /// `fetch_update` tógann sé dhá argóint [`Ordering`] chun cur síos a dhéanamh ar ordú cuimhne na hoibríochta seo.
            /// Déanann an chéad cheann cur síos ar an ordú riachtanach nuair a éiríonn leis an oibríocht sa deireadh agus déanann an dara ceann cur síos ar an ordú riachtanach le haghaidh ualaí.Freagraíonn siad seo do rath agus orduithe teip
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Trí [`Acquire`] a úsáid mar ordú rathúlachta is cuid den oibríocht seo [`Relaxed`] an stór, agus trí [`Release`] a úsáid déantar an t-ualach rathúil deiridh [`Relaxed`].
            /// Ní féidir le hordú ualaigh (failed) a bheith ach [`SeqCst`], [`Acquire`] nó [`Relaxed`] agus caithfidh sé a bheith coibhéiseach leis an ordú rath nó níos laige.
            ///
            /// **Nóta**: Níl an modh seo ar fáil ach ar ardáin a thacaíonn le hoibríochtaí adamhacha ar
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Ordú: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Ordú: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Uasmhéid leis an luach reatha.
            ///
            /// Faightear an t-uasmhéid an luach reatha agus an argóint `val`, agus leagann an luach nua go dtí an toradh.
            ///
            /// Filleann sé an luach roimhe seo.
            ///
            /// `fetch_max` glacann sé argóint [`Ordering`] a chuireann síos ar ordú cuimhne na hoibríochta seo.Is féidir gach modh ordaithe.
            /// Tabhair faoi deara go ndéanann [`Acquire`] an stór mar chuid den oibríocht seo [`Relaxed`], agus má úsáideann [`Release`] an chuid ualaigh [`Relaxed`].
            ///
            ///
            /// **Nóta**: Níl an modh seo ar fáil ach ar ardáin a thacaíonn le hoibríochtaí adamhacha ar
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// lig barra=42;
            /// lig max_foo=foo.fetch_max (barra, Ordering::SeqCst).max(bar);
            /// dearbhú! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Íosmhéid leis an luach reatha.
            ///
            /// Faightear an t-íosmhéid den luach reatha agus an argóint `val`, agus socraíonn sé an luach nua don toradh.
            ///
            /// Filleann sé an luach roimhe seo.
            ///
            /// `fetch_min` glacann sé argóint [`Ordering`] a chuireann síos ar ordú cuimhne na hoibríochta seo.Is féidir gach modh ordaithe.
            /// Tabhair faoi deara go ndéanann [`Acquire`] an stór mar chuid den oibríocht seo [`Relaxed`], agus má úsáideann [`Release`] an chuid ualaigh [`Relaxed`].
            ///
            ///
            /// **Nóta**: Níl an modh seo ar fáil ach ar ardáin a thacaíonn le hoibríochtaí adamhacha ar
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// lig barra=12;
            /// lig min_foo=foo.fetch_min (barra, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÁBHÁILTEACHT: seachnaíonn rásaí sonraí ó bhroinn adamhach.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Tuairisceáin pointeoir mutable go dtí an tslánuimhir is bun.
            ///
            /// Is rás sonraí é léamha neamh-adamhacha a dhéanamh agus a scríobh ar an slánuimhir a leanann dá bharr.
            /// Tá an modh seo den chuid is mó úsáideach le haghaidh ITF, i gcás ina bhféadfadh an síniú fheidhm a úsáid
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Ag filleadh ar pointeoir `*mut` ó tagairt comhroinnte don adamhach atá sábháilte mar gheall ar obair na cineálacha adamhach le mutability istigh.
            /// Athraíonn gach modhnú ar adamhach an luach trí thagairt roinnte, agus féadann siad é sin a dhéanamh go sábháilte fad a úsáideann siad oibríochtaí adamhacha.
            /// Teastaíonn bloc `unsafe` chun aon úsáid a bhaint as an pointeoir amh a chuirtear ar ais agus ní mór dó an srian céanna a sheasamh: caithfidh oibríochtaí air a bheith adamhach.
            ///
            ///
            /// # Examples
            ///
            /// `` `Neamhaird (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// seachtrach "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // SÁBHÁILTEACHT: Sábháilte fad is atá `my_atomic_op` adamhach.
            /// neamhshábháilte {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `atomic_store` a sheasamh.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `atomic_load` a sheasamh.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `atomic_swap` a sheasamh.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Tuairisceáin an luach roimhe seo (cosúil le __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `atomic_add` a sheasamh.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Tuairisceáin an luach roimhe seo (cosúil le __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `atomic_sub` a sheasamh.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `atomic_compare_exchange` a sheasamh.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `atomic_compare_exchange_weak` a sheasamh.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÁBHÁILTEACHT: ní mór don té atá ag glaoch ar an gconradh sábháilteachta do `atomic_and` seasamh
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `atomic_nand` a sheasamh
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `atomic_or` a sheasamh
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `atomic_xor` a sheasamh
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// tugann sé an luach uasta ar ais (comparáid sínithe)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÁBHÁILTEACHT: ní mór don té atá ag glaoch ar an gconradh sábháilteachta do `atomic_max` seasamh
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// tugann sé an luach íosta ar ais (comparáid shínithe)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `atomic_min` a sheasamh
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// tugann sé an luach uasta ar ais (comparáid gan síniú)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÁBHÁILTEACHT: ní mór don té atá ag glaoch ar an gconradh sábháilteachta do `atomic_umax` seasamh
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// tugann sé an luach mion ar ais (comparáid gan síniú)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `atomic_umin` a sheasamh
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Fál adamhach.
///
/// Ag brath ar an ordú sonraithe, cuireann fál cosc ar an tiomsaitheoir agus ar an LAP cineálacha áirithe oibríochtaí cuimhne timpeall air a athordú.
/// Cruthaíonn sé sin sioncrónú-leis an gcaidreamh idir é agus oibríochtaí adamhacha nó fálta i snáitheanna eile.
///
/// Déanann fál 'A' a bhfuil (ar a laghad) [`Release`] séimeantach á ordú aige, sioncrónú le fál 'B' le séimeantach [`Acquire`] (ar a laghad), má tá oibríochtaí X agus Y ann agus iad sin amháin, agus iad araon ag feidhmiú ar réad adamhach 'M' sa chaoi go bhfuil A curtha in ord roimhe seo Déantar X, Y a shioncronú sula dtugann B agus Y faoi deara an t-athrú go M.
/// Tugann sé seo a tharlaíonn-roimh spleáchas idir A agus B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Is féidir le hoibríochtaí Adamhach le [`Release`] nó [`Acquire`] semantics shioncrónú freisin le claí.
///
/// Glacann fál a bhfuil ordú [`SeqCst`] air, chomh maith le séimeantaic [`Acquire`] agus [`Release`] araon, páirt in ord clár domhanda na n-oibríochtaí agus/nó na gclaí [`SeqCst`] eile.
///
/// Glacann sé le horduithe [`Acquire`], [`Release`], [`AcqRel`] agus [`SeqCst`].
///
/// # Panics
///
/// Panics más `order` é `order`.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Primitive eisiamh frithpháirteach bunaithe ar spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Fan go mbeidh an seanluach `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Sioncrónaíonn an fál seo leis an stór i `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // SÁBHÁILTEACHT: tá úsáid fál adamhach sábháilte.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Fál cuimhne tiomsaitheora.
///
/// `compiler_fence` ní scaoileann sé aon chód meaisín, ach cuireann sé srian ar na cineálacha cuimhne a cheadaítear don tiomsaitheoir a dhéanamh.Go sonrach, ag brath ar na séimeantaice [`Ordering`] a thugtar, féadfar an tiomsaitheoir a dhícheadú ó léamha nó scríbhinní a bhogadh roimh nó tar éis an ghlao go dtí an taobh eile den ghlao go `compiler_fence`.Tabhair faoi deara nach gcuireann sé **cosc ar na* crua-earraí * ath-ordú den sórt sin a dhéanamh.
///
/// Ní fadhb í seo i gcomhthéacs forghníomhaithe aon-snáithe, ach nuair a fhéadfaidh snáitheanna eile cuimhne a mhodhnú ag an am céanna, teastaíonn primitive sioncrónaithe níos láidre mar [`fence`].
///
/// Is iad na ath-ordú cosc na semantics éagsúla ordú:
///
///  - le [`SeqCst`], ní cheadaítear aon léamha agus scríbhinní a athordú ar fud an phointe seo.
///  - le [`Release`], ní féidir léamha agus scríbhinní roimhe seo a bhogadh thar scríbhinní ina dhiaidh sin.
///  - le [`Acquire`], ní féidir léamha agus scríbhinní ina dhiaidh sin a bhogadh roimh na léamha roimhe seo.
///  - le [`AcqRel`], cuirtear an dá riail thuas i bhfeidhm.
///
/// `compiler_fence` de ghnáth níl sé úsáideach ach chun snáithe a chosc ó rásaíocht *leis féin*.Is é sin, má tá snáithe áirithe ag feidhmiú píosa amháin cód, agus go gcuirtear isteach air ansin, agus go dtosaíonn sé cód a fhorghníomhú in áit eile (agus é fós sa snáithe céanna, agus go coincheapúil fós ar an gcroílár céanna).I gcláir thraidisiúnta, ní fhéadfaidh sé seo tarlú ach nuair a chláraítear láimhseálaí comhartha.
/// I gcód níos ísle ar leibhéal íseal, féadann cásanna den sórt sin teacht chun cinn freisin nuair a dhéantar cur isteach a láimhseáil, agus snáitheanna glasa á gcur i bhfeidhm le réamhchlaonadh, srl.
/// Spreagtar léitheoirí aisteach plé eithne Linux ar [memory barriers] a léamh.
///
/// # Panics
///
/// Panics más `order` é `order`.
///
/// # Examples
///
/// Gan `compiler_fence`, ní ráthaítear * go n-éireoidh leis an `assert_eq!` sa chód seo a leanas, in ainneoin go dtarlaíonn gach rud i snáithe amháin.
/// Chun a fháil amach cén fáth, cuimhnigh go bhfuil an tiomsaitheoir saor chun na siopaí a mhalartú go `IMPORTANT_VARIABLE` agus `IS_READ` ós rud é gur `Ordering::Relaxed` iad araon.Má dhéanann sé, agus tá an láimhseálaí comhartha agairt ceart tar éis `IS_READY` suas chun dáta, ansin beidh an láimhseálaí comhartha féach `IS_READY=1`, ach `IMPORTANT_VARIABLE=0`.
/// Le leigheas `compiler_fence` leigheasann sé an cás seo.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // cosc a chur ar scríbhinní níos luaithe a bhogadh níos faide ná an bpointe seo
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // SÁBHÁILTEACHT: tá úsáid fál adamhach sábháilte.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Cuireann sé in iúl don phróiseálaí go bhfuil sé taobh istigh de lúb-lúb gnóthach-feitheamh ("glasáil casadh").
///
/// Ní dhéantar an fheidhm seo a thuairisciú i bhfabhar [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}