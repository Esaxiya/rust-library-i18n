//! Fóntais le formáidiú agus teaghráin phriontáil.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// ailínithe féideartha ar ais ag `Formatter::align`
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Léiriú gur cheart an t-ábhar a ailíniú ar chlé.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Léiriú gur cheart an t-ábhar a ailíniú i gceart.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Léiriú gur chóir go mbeadh an t-ábhar ailínithe go lár.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// An cineál ar ais trí mhodhanna Fhormáidithe.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// An cineál earráide a chuirtear ar ais ó theachtaireacht a fhormáidiú i sruth.
///
/// Ní thacaíonn an cineál seo le tarchur earráide seachas gur tharla earráid.
/// Ní mór aon fhaisnéis bhreise a shocrú a bheidh le tarchur trí mhodh éigin eile.
///
/// Rud tábhachtach le cuimhneamh ná nár cheart an cineál `fmt::Error` a mheascadh le [`std::io::Error`] nó [`std::error::Error`], a d`fhéadfadh a bheith agat faoi raon feidhme freisin.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// trait le haghaidh scríbhneoireachta nó formáidithe i maoláin nó sruthanna a ghlacann le Unicode.
///
/// Seo trait Glacann ach sonraí UTF-8-ionchódaithe agus nach bhfuil [flushable].
/// Más mian leat ach chun glacadh Unicode agus nach bhfuil tú gá flushing, ba chóir duit é seo a chur i bhfeidhm trait;
/// ar shlí eile ba chóir duit a chur i bhfeidhm [`std::io::Write`].
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// Scríobhann slice teaghrán isteach sa scríbhneoir, ag filleadh an bhfuil an scríobh éirigh.
    ///
    /// Ní féidir go n-éireoidh leis an modh seo ach amháin má scríobhadh an slice sreang iomlán go rathúil, agus ní fhillfidh an modh seo go dtí go mbeidh na sonraí go léir scríofa nó go dtarlóidh earráid.
    ///
    ///
    /// # Errors
    ///
    /// Fillfidh an fheidhm seo sampla de [`Error`] ar earráid.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// Scríobhann [`char`] isteach sa scríbhneoir seo, ag filleadh ar éirigh leis an scríbhinn.
    ///
    /// Is féidir [`char`] aonair a ionchódaithe mar beart níos mó ná aon.
    /// Is féidir an modh seo éireoidh ach amháin más rud é go raibh an t-ord beart ar fad scríofa go rathúil, agus ní bheidh an modh ar ais go dtí go na sonraí go léir a bheith i scríbhinn nó a tharlaíonn earráid.
    ///
    ///
    /// # Errors
    ///
    /// Fillfidh an fheidhm seo sampla de [`Error`] ar earráid.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Glue chun úsáid an macra [`write!`] le implementors den trait.
    ///
    /// Ba chóir an modh seo nach bhfuil i gcoitinne a agairt de láimh, ach tríd an macra [`write!`] féin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Cumraíocht le haghaidh formáidiú.
///
/// Léiríonn `Formatter` roghanna éagsúla a bhaineann le formáidiú.
/// Ní gá Úsáideoirí thógáil `Formatter`s díreach;Tá tagairt mutable ceann ar aghaidh chuig an modh `fmt` uile traits formáidiú, cosúil le [`Debug`] agus [`Display`].
///
///
/// Chun idirghníomhú le `Formatter`, iarrfaidh tú modhanna éagsúla chun na roghanna éagsúla a bhaineann le formáidiú a athrú.
/// Le haghaidh samplaí, féach ar an doiciméadú na modhanna atá sainithe ar `Formatter` thíos.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// Is Argóint go bunúsach optamaithe bhfeidhm go páirteach feidhm formáidiú, atá cothrom le `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result`.

extern "C" {
    type Opaque;
}

/// Léiríonn an struchtúr seo an "argument" cineálach a ghlacann teaghlach feidhmeanna Xprintf.Tá feidhm ann chun an luach tugtha a fhormáidiú.
/// Áirithítear ag am a thiomsú go bhfuil na cineálacha cearta ag an bhfeidhm agus ag an luach, agus ansin úsáidtear an struchtúr seo chun argóintí de chineál amháin a chanónú.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// Cinntíonn sé seo luach cobhsaí amháin don pointeoir fheidhm a bhaineann le indices/counts i mbonneagar formáidiú.
//
// Tabhair faoi deara nach mbeadh feidhm a shainmhínítear mar sin ceart toisc go ndéantar feidhmeanna a chlibeáil gan ainm i gcónaí leis an ísliú reatha go LLVM IR, mar sin ní mheastar go bhfuil a seoladh tábhachtach do LLVM agus dá bhrí sin d`fhéadfaí an teilgean as_usize a mhí-chomhbhrú.
//
// Go praiticiúil, ní ghlaoimid riamh as_usize ar shonraí nach bhfuil in úsáid (mar gheall ar ghiniúint statach na n-argóintí formáidithe), mar sin níl anseo ach seiceáil bhreise.
//
// Ba mhaith linn go príomha chun a chinntiú go bhfuil an pointeoir feidhm ag `USIZE_MARKER` an seoladh comhfhreagrach *amháin* feidhmeanna a ghlacadh freisin `&usize` mar a gcéad argóint.
// An read_volatile anseo Cinntíonn gur féidir linn go sábháilte réidh amach usize as an tagairt a rith agus go bhfuil an seoladh ní dhéanann pointe ag ócáid ag cur neamh-usize.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // SÁBHÁILTEACHT: Is PTR is tagairt í
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // Is `mem::transmute(x)` toisc sábháilte: SAFETY
        //     1. `&'b T` Coinníonn saolré tháinig sé le `'b` (sa chaoi is go nach bhfuil saolré unbounded)
        //     2.
        //     `&'b T` agus tá an leagan amach cuimhne céanna ag `&'b Opaque` (nuair atá `T` `Sized`, mar atá sé anseo) tá `mem::transmute(f)` sábháilte ós rud é go bhfuil an ABI céanna ag `fn(&T, &mut Formatter<'_>) -> Result` agus `fn(&Opaque, &mut Formatter<'_>) -> Result` (fad is atá `T` `Sized`)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // SÁBHÁILTEACHT: Tá an réimse `formatter` leagtha ach amháin maidir le USIZE_MARKER más rud é
            // Is é an luach a usize, agus mar sin tá sé seo sábháilte
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// bratacha ar fáil i bhformáid v1 format_args
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Nuair a úsáidtear an macra format_args! (), Úsáidtear an fheidhm seo chun an struchtúr Argóintí a ghiniúint.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// Is é an fheidhm a úsáidtear paraiméadair formáidiú neamhchaighdeánach a shonrú.
    /// Ní mór don eagar `pieces` bheith ar a laghad chomh fada agus is `fmt` a thógáil struchtúr Argóintí bailí.
    /// Chomh maith leis sin, caithfidh aon `Count` laistigh de `fmt` atá `CountIsParam` nó `CountIsNextParam` aird a dhíriú ar argóint a cruthaíodh le `argumentusize`.
    ///
    /// Mar sin féin, ina éagmais sin a dhéanamh nach bhfuil sin a deara unsafety, ach beidh neamhaird neamhbhailí.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// Meastachán ar fhad an téacs formáidithe.
    ///
    /// Tá sé i gceist le húsáid le haghaidh a shocrú acmhainn `String` tosaigh nuair a úsáid `format!`.
    /// Note: is é seo ní fhéadfaidh an níos ísle ná cheangal uachtair.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // Má thosaíonn sreang na formáide le hargóint, ná déan aon rud a réamh-leithdháileadh, mura bhfuil fad na bpíosaí suntasach.
            //
            //
            0
        } else {
            // Tá roinnt argóintí ann, mar sin déanfaidh aon bhrú breise an sreang a ath-leithdháileadh.
            //
            // Chun é sin a sheachaint, táimid ag "pre-doubling" an acmhainn anseo.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Léiríonn an struchtúr seo leagan réamhchomhbhrúite go sábháilte de shreang formáide agus a chuid argóintí.
/// Ní féidir é seo a gineadh ag runtime toisc nach féidir é a dhéanamh go sábháilte, agus mar sin níl aon constructors Tugtar agus na réimsí príobháideacha modhnú a chosc.
///
///
/// Cruthóidh an macra [`format_args!`] sampla den struchtúr seo go sábháilte.
/// bailíochtú ar an macra an teaghrán formáidithe ag tiomsaithe-am ionas gur féidir úsáid na feidhmeanna [`write()`] agus [`format()`] a dhéanamh go sábháilte.
///
/// Is féidir leat an `Arguments<'a>` a fhilleann [`format_args!`] a úsáid i gcomhthéacsanna `Debug` agus `Display` mar a fheictear thíos.
/// Léiríonn an sampla chomh maith go `Debug` agus `Display` maith chuig an rud céanna: an teaghrán formáidithe interpolated in `format_args!`.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // píosaí Format teaghrán a phriontáil.
    pieces: &'a [&'static str],

    // Sonraíochtaí áitritheora, nó `None` má tá gach spec réamhshocraithe (mar atá in "{}{}").
    fmt: Option<&'a [rt::v1::Argument]>,

    // argóintí Dinimiciúla le Idirshuíomh, a Interleaved le píosaí corda.
    // (Cuirtear sreangán roimh gach argóint.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// Faigh an tsreang formáidithe, mura bhfuil aon argóintí aici le formáidiú.
    ///
    /// Is féidir é seo a úsáid chun leithdháiltí a sheachaint sa chás is fánach.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` Ba chóir go formáid aschur i Ríomhchláraitheoir-os comhair, debugging comhthéacs.
///
/// Go ginearálta, níor cheart duit ach `derive` a `Debug` a chur i bhfeidhm.
///
/// Nuair a úsáidtear é leis an tsonraitheoir formáide malartach `#?`, tá an t-aschur clóite go deas.
///
/// Le haghaidh tuilleadh eolais a fháil ar formatters, féach [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// Is féidir é seo trait a úsáid le `#[derive]` más rud é gach réimse feidhme `Debug`.
/// Nuair a dhíorthaíonn sé struchtúir, úsáidfidh sé ainm an `struct`, ansin `{`, ansin liosta scartha le camóga d`ainm gach páirce agus luach `Debug`, ansin `}`.
/// Maidir le `enum`s, úsáidfidh sé ainm an athraitheora agus, más infheidhme, `(`, ansin luachanna `Debug` na réimsí, ansin `)`.
///
/// # Stability
///
/// Níl formáidí díorthaithe `Debug` seasmhach, agus mar sin d`fhéadfadh siad athrú le leaganacha future Rust.
/// Ina theannta sin, níl cur chun feidhme `Debug` de chineálacha a sholáthraíonn an leabharlann chaighdeánach (`libstd`, `libcore`, `liballoc`, etc.) seasmhach, agus féadfaidh siad athrú le leaganacha future Rust.
///
///
/// # Examples
///
/// Dhíorthaíonn cur i bhfeidhm:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Láimh chun feidhme:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Tá roinnt modhanna cúntóir ar an struct [`Formatter`] chun cabhrú leat le implementations lámhleabhar, ar nós [`debug_struct`].
///
/// `Debug` implementations ag baint úsáide as ceachtar `derive` nó an API debug tógálaí ar thacaíocht [`Formatter`] deas-priontáil ag baint úsáide as an bhratach malartach: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// Priontáil bhreá le `#?`:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// Formáidí an luach ag baint úsáide as an bhformáiditheoir tugtha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// Modúl ar leithligh chun an macra `Debug` a ath-thuairisciú ó prelude gan an trait `Debug`.
pub(crate) mod macros {
    /// macra Díorthaigh ghiniúint impl an `Debug` trait.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Formáid trait do bhformáid folamh, `{}`.
///
/// `Display` tá sé cosúil le [`Debug`], ach tá `Display` le haghaidh aschur atá os comhair an úsáideora, agus mar sin ní féidir é a dhíorthú.
///
///
/// Le haghaidh tuilleadh eolais a fháil ar formatters, féach [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Cur i bhfeidhm `Display` ar chineál:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// Formáidí an luach ag baint úsáide as an bhformáiditheoir tugtha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// Ba cheart don `Octal` trait a aschur a fhormáidiú mar uimhir in base-8.
///
/// Maidir le slánuimhreacha sínithe primitive (`i8` go `i128`, agus `isize`), luachanna diúltacha a formáidithe mar ionadaíocht chomhlánú an dá s.
///
///
/// Cuireann an bhratach malartach, `#`, `0o` os comhair an aschuir.
///
/// Le haghaidh tuilleadh eolais a fháil ar formatters, féach [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// úsáid Basic le `i32`:
///
/// ```
/// let x = 42; // Is é 42 '52' in ochtáin
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// Cur i bhfeidhm `Octal` ar chineál:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // tarmligean chuig cur chun feidhme i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// Formáidí an luach ag baint úsáide as an bhformáiditheoir tugtha.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// Ba cheart don trait `Binary` formáid aschur mar uimhir i dénártha.
///
/// Maidir le slánuimhreacha sínithe primitive ([`i8`] go [`i128`], agus [`isize`]), déantar luachanna diúltacha a fhormáidiú mar léiriú comhlántach na beirte.
///
///
/// Bratach na malartach, `#` Cuireann, a `0b` os comhair an t-aschur.
///
/// Le haghaidh tuilleadh eolais a fháil ar formatters, féach [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Úsáid bhunúsach le [`i32`]:
///
/// ```
/// let x = 42; // Is é 42 '101010' i ndénártha
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// `Binary` a chur i bhfeidhm ar chineál:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // tarmligean chuig cur chun feidhme i32
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// Formáidí an luach ag baint úsáide as an bhformáiditheoir tugtha.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// Ba cheart don trait `LowerHex` formáid aschur mar uimhir i hexadecimal, le `a` trí `f` sa chás íochtair.
///
/// Maidir le slánuimhreacha sínithe primitive (`i8` go `i128`, agus `isize`), luachanna diúltacha a formáidithe mar ionadaíocht chomhlánú an dá s.
///
///
/// Cuireann an bhratach malartach, `#`, `0x` os comhair an aschuir.
///
/// Le haghaidh tuilleadh eolais a fháil ar formatters, féach [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// úsáid Basic le `i32`:
///
/// ```
/// let x = 42; // Is é 42 '2a' i heacs
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// `LowerHex` a chur i bhfeidhm ar chineál:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // tarmligean chuig cur chun feidhme i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// Formáidí an luach ag baint úsáide as an bhformáiditheoir tugtha.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// Ba cheart don `UpperHex` trait a aschur a fhormáidiú mar uimhir i heicsidheachúlach, le `A` trí `F` sa chás uachtarach.
///
/// Maidir le slánuimhreacha sínithe primitive (`i8` go `i128`, agus `isize`), luachanna diúltacha a formáidithe mar ionadaíocht chomhlánú an dá s.
///
///
/// Cuireann an bhratach malartach, `#`, `0x` os comhair an aschuir.
///
/// Le haghaidh tuilleadh eolais a fháil ar formatters, féach [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// úsáid Basic le `i32`:
///
/// ```
/// let x = 42; // Is é 42 '2A' i heacs
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// Cur i bhfeidhm `UpperHex` ar chineál:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // tarmligean chuig cur chun feidhme i32
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// Formáidí an luach ag baint úsáide as an bhformáiditheoir tugtha.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// Ba cheart don trait `Pointer` formáid aschur mar láthair chuimhne.
/// Cuirtear é seo i láthair go coitianta mar heicsidheachúlach.
///
/// Le haghaidh tuilleadh eolais a fháil ar formatters, féach [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Úsáid bhunúsach le `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // Táirgeann an rud éigin cosúil le '0x7f06092ac6d0'
/// ```
///
/// `Pointer` a chur i bhfeidhm ar chineál:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // úsáid `as` go thiontú go le `*const T`, a chuireann phointeora, ar féidir linn a úsáid
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// Formáidí an luach ag baint úsáide as an bhformáiditheoir tugtha.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// Ba cheart don `LowerExp` trait a aschur a fhormáidiú i nodaireacht eolaíoch le cás íochtarach `e`.
///
/// Le haghaidh tuilleadh eolais a fháil ar formatters, féach [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Úsáid bhunúsach le `f64`:
///
/// ```
/// let x = 42.0; // 42.0 is é '4.2e1' sa nodaireacht eolaíoch
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// `LowerExp` a chur i bhfeidhm ar chineál:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // tarmligean chuig cur chun feidhme f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// Formáidí an luach ag baint úsáide as an bhformáiditheoir tugtha.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// Ba cheart don `UpperExp` trait a aschur a fhormáidiú i nodaireacht eolaíoch le cás uachtarach `E`.
///
/// Le haghaidh tuilleadh eolais a fháil ar formatters, féach [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Úsáid bhunúsach le `f64`:
///
/// ```
/// let x = 42.0; // 42.0 is é '4.2E1' sa nodaireacht eolaíoch
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// Cur i bhfeidhm `UpperExp` ar chineál:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // tarmligean chuig cur chun feidhme f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// Formáidí an luach ag baint úsáide as an bhformáiditheoir tugtha.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// Glacann an fheidhm `write` sruth aschur, agus struct `Arguments` is féidir a precompiled leis an macra `format_args!`.
///
///
/// Déanfar na hargóintí a fhormáidiú de réir na sreinge formáide sonraithe isteach sa sruth aschuir a sholáthrófar.
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Tabhair faoi deara go mb'fhéidir go mbeadh baint úsáide as [`write!`] a bheith níos fearr.Sampla:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // Is féidir linn paraiméadair formáidithe réamhshocraithe a úsáid le haghaidh gach argóint.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // Tá ag gach spec argóint comhfhreagrach atá roimh píosa teaghrán.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // SÁBHÁILTEACHT: tagann arg agus args.args ó na hargóintí céanna,
                // a ráthaíonn go mbíonn na hinnéacsanna laistigh de theorainneacha i gcónaí.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // Ní féidir ach sreangán trailing amháin a bheith fágtha.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // SÁBHÁILTEACHT: ARG agus thagair thagann as na Argóintí céanna,
    // a ráthaíonn go mbíonn na hinnéacsanna laistigh de theorainneacha i gcónaí.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // Sliocht an argóint cheart
    debug_assert!(arg.position < args.len());
    // SÁBHÁILTEACHT: ARG agus thagair thagann as na Argóintí céanna,
    // a ráthaíonn go bhfuil a innéacs laistigh de theorainneacha i gcónaí.
    let value = unsafe { args.get_unchecked(arg.position) };

    // Ansin déan roinnt priontála i ndáiríre
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // SÁBHÁILTEACHT: tagann cnt agus args ó na hargóintí céanna,
            // a ráthaíonn go bhfuil an t-innéacs i gcónaí laistigh de theorainneacha.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// Padding tar éis deireadh rud éigin.Ar ais ag `Formatter::padding`.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Scríobh an stuáil post.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // Ba mhaith linn é seo a athrú
            buf: wrap(self.buf),

            // Agus a chaomhnú na
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // Modhanna cúntóra a úsáidtear chun argóintí formáidithe a stuáil agus a phróiseáil is féidir le gach formáidiú traits a úsáid.
    //

    /// Go ndéanann sé na stuáil ceart slánuimhir atá astaítear cheana isteach i str.
    /// Ba chóir an str *nach bhfuil* an comhartha don tslánuimhir is, a chur leis an modh seo.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, an raibh an slánuimhir bunaidh dearfach nó nialas.
    /// * réimír, má sholáthraítear an carachtar '#' (Alternate), is é seo an réimír atá le cur os comhair na huimhreach.
    ///
    /// * buf, an sraith beart go bhfuil líon curtha formáidithe isteach
    ///
    /// Tabharfaidh an fheidhm seo cuntas ceart ar na bratacha a sholáthraítear chomh maith leis an leithead íosta.
    /// Ní chuirfidh sé cruinneas san áireamh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // Caithfimid "-" a bhaint den aschur uimhreacha.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // Scríobhann an comhartha más ann dó, agus ansin an réimír má iarradh é
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // Tá an réimse `width` níos mó de pharaiméadar `min-width` ag an bpointe seo.
        match self.width {
            // Mura bhfuil aon íosriachtanais faid ann is féidir linn na bearta a scríobh.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Seiceáil má tá muid thar an leithead íosta, más rud é mar sin ansin is féidir linn a freisin scríobh ach na bytes.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Téann an comhartha agus réimír roimh an stuáil má tá an carachtar líonadh náid
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // Seachas sin, téann an comhartha agus an réimír tar éis na stuála
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Tógann an fheidhm a slice téad agus astaíonn sé leis an maolán inmheánach tar éis na bratacha formáidiú iomchuí a shonrófar.
    /// Is iad na bratacha a aithnítear le haghaidh teaghráin chineálacha:
    ///
    /// * leithead, an leithead íosta is féidir a astú
    /// * fill/align - cad ba cheart a astú agus cá háit a n-astaíonn sé más gá an sreangán a sholáthraítear a phacáil
    /// * beachtas, an fad is mó a astaítear, teastaítear an sreangán má tá sé níos faide ná an fad seo
    ///
    /// Go suntasach neamhaird fheidhm seo na paraiméadair `flag`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // Déan cinnte go bhfuil cosán gasta chun tosaigh
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // Is féidir leis an réimse `precision` a léiriú mar `max-width` le haghaidh an teaghrán á formáidithe.
        //
        let s = if let Some(max) = self.precision {
            // Má tá ár n-teaghrán níos faide go bhfuil an cruinneas, ansin ní mór dúinn a bheith teascadh.
            // Caithfidh bratacha eile cosúil le `fill`, `width` agus `align` gníomhú mar a bhí i gcónaí.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // Ní féidir le LLVM anseo a chruthú nach panic `&s[..i]` a bheidh i `..i`, ach tá a fhios againn nach féidir panic a dhéanamh.
                // Úsáid `get` + `unwrap_or` chun `unsafe` a sheachaint agus murach sin ná astaíonn aon chód a bhaineann le panic anseo.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // Tá an réimse `width` níos mó de pharaiméadar `min-width` ag an bpointe seo.
        match self.width {
            // Má táimid faoin bhfad uasta, agus mura bhfuil aon íoscheanglais maidir le fad, ansin is féidir linn an sreang a astú
            //
            None => self.buf.write_str(s),
            // Má tá muid faoi an leithead uasta, seiceáil má tá muid thar an leithead íosta, más rud é mar sin tá sé chomh héasca agus is díreach astú an teaghrán.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // Má táimid faoin uasmhéid agus an leithead íosta, ansin líon an leithead íosta leis an tsreang shonraithe + roinnt ailínithe.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Scríobh an réamh-stuáil agus cuir an iar-stuáil neamhscríofa ar ais.
    /// Tá glaoiteoirí freagrach as a chinntiú go scríobhtar iar-stuáil tar éis an rud atá á stuáil.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// Glacann sé na codanna formáidithe agus cuireann sé an stuáil i bhfeidhm.
    /// Ghlacann leis go bhfuil an té atá ag glaoch go bhfuil cheana féin a rinneadh ar na codanna a bhfuil cruinneas is gá, ionas gur féidir `self.precision` a neamhaird.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // maidir leis an stuáil nialasach atá feasach ar chomharthaí, tugaimid an comhartha ar dtús agus bímid ag iompar amhail is nach mbeadh aon chomhartha againn ón tús.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // comhartha Téann ar dtús i gcónaí
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // bain an comhartha de na codanna formáidithe
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // codanna eile dul tríd an bpróiseas stuáil ngnáthnós.
            let len = formatted.len();
            let ret = if width <= len {
                // gan stuáil
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // is é seo an cás coitianta agus tógann muid aicearra
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // SÁBHÁILTEACHT: Tá sé seo a úsáidtear le haghaidh `flt2dec::Part::Num` agus `flt2dec::Part::Copy`.
            // Tá sé sábháilte a úsáid le haghaidh `flt2dec::Part::Num` ós rud é gach ruabhric Is `c` idir `b'0'` agus `b'9'`, rud a chiallaíonn go bhfuil `s` bailí UTF-8.
            // Tá sé freisin is dócha sábháilte i gcleachtas a úsáid le haghaidh `flt2dec::Part::Copy(buf)` ó `buf` a bheith plain ASCII, ach tá sé indéanta do dhuine chun pas a fháil i luach olc do `buf` `flt2dec::to_shortest_str` isteach go bhfuil sé ina feidhm phoiblí.
            //
            // FIXME: Déan amach an bhféadfadh sé seo mar thoradh UB.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 nialais
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// Scríobhann cuid de na sonraí ar an maolán bun atá sa Fhormáidithe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // Is ionann é seo agus:
    ///         // scríobh! (formáiditheoir, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// Scríobhann sé roinnt faisnéise formáidithe sa chás seo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Bratacha le haghaidh formáidithe
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Carachtair a úsáidtear mar 'fill' aon uair go bhfuil ailíniú.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // Leagaimid ailíniú cheart le ">".
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Bratach in iúl cad a iarradh cineál ailíniú.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// sonraithe Optionally tslánuimhir leithead gur chóir an t-aschur a bheith.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // Má fuaireamar leithead, úsáidimid é
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // Seachas sin ní dhéanaimid aon rud speisialta
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// Cruinneas a shonraítear go roghnach do chineálacha uimhriúla.
    /// De rogha air sin, an leithead is mó do chineálacha sreinge.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // Má fuaireamar beachtas, úsáidimid é.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // Seachas sin réamhshocraímid go 2.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// Cinneann más rud é go raibh sonraithe an bhratach `+`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// Cinneann an sonraíodh an bhratach `-`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // Ba mhaith leat a comhartha lúide?Bíodh ceann agat!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// Cinneann an sonraíodh an bhratach `#`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// Cinneann an sonraíodh an bhratach `0`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // Déanaimid neamhaird de roghanna an fhormáidithe.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: Déan cinneadh cén API poiblí atá uainn don dá bhratach seo.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// Cruthaigh tógálaí [`DebugStruct`] cúnamh chun na cruthú implementations [`fmt::Debug`] do structs.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// Cruthaíonn sé tógálaí `DebugTuple` atá deartha chun cabhrú le cur chun feidhme `fmt::Debug` a chruthú do struchtúir tuple.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// Cruthaíonn sé tógálaí `DebugList` atá deartha chun cabhrú le cur chun feidhme `fmt::Debug` a chruthú do struchtúir atá cosúil le liosta.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// Cruthaíonn sé tógálaí `DebugSet` atá deartha chun cabhrú le cur chun feidhme `fmt::Debug` a chruthú do struchtúir atá cosúil le tacar.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// Sa sampla níos casta seo, úsáidimid [`format_args!`] agus `.debug_set()` chun liosta arm meaitseála a thógáil:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// Cruthaigh tógálaí `DebugMap` cúnamh chun na cruthú implementations `fmt::Debug` do léarscáil-mhaith struchtúir.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// Implementations de na croí a fhormáidiú traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // Má riachtanais ruabhric éalú, riaráiste flush go dtí seo agus scríobh, skip eile
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // Déileálann LowerHex leis an mbrat malartach cheana féin mar bhratach speisialta-seasann sí ar cheart réimír a dhéanamh le 0x.
        // Úsáidimid é chun a fháil amach an ceart síneadh a dhéanamh le nialas nó nach ea, agus ansin é a shocrú gan choinníoll chun an réimír a fháil.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Cur i bhfeidhm Display/Debug do chineálacha éagsúla lárnacha

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // Tá an RefCell ar iasacht go frithpháirteach ionas nach féidir linn féachaint ar a luach anseo.
                // Taispeáin placeholder ina ionad.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// Má tástálacha súil tú a bheith anseo, ag féachaint in áit ar chomhad core/tests/fmt.rs, tá sé i bhfad níos éasca ná mar a chruthú gach ceann de na struchtúr rt::Piece anseo.
//
// Tá tástálacha ann freisin sa leithdháileadh crate, dóibh siúd a dteastaíonn leithdháiltí uathu.