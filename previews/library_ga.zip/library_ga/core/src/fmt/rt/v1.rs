//! Is é seo an modúl inmheánach a úsáideann an ifmt!runtime.Tá na struchtúir seo a astaítear le arrays statach a teaghráin formáid precompile roimh an am.
//!
//! Tá na sainmhínithe seo cosúil lena gcoibhéisí `ct`, ach tá siad difriúil sa mhéid is gur féidir iad seo a leithdháileadh go statach agus iad a bharrfheabhsú beagán don rith-am
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Ailínithe féideartha is féidir a iarraidh mar chuid de threoir formáidithe.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Léiriú gur cheart an t-ábhar a ailíniú ar chlé.
    Left,
    /// Léiriú gur cheart an t-ábhar a ailíniú i gceart.
    Right,
    /// Léiriú gur chóir go mbeadh an t-ábhar ailínithe go lár.
    Center,
    /// Níor iarradh aon ailíniú.
    Unknown,
}

/// Úsáidte ag sonraitheoirí [width](https://doc.rust-lang.org/std/fmt/#width) agus [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Sonraithe le huimhir liteartha, stórálann sé an luach
    Is(usize),
    /// Sonraithe ag baint úsáide as `$` agus `*` syntaxes siopaí, an t-innéacs `args` isteach
    Param(usize),
    /// Gan a bheith sonraithe
    Implied,
}