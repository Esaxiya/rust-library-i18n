#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Tá sainmhínithe struchtúracha ann maidir le leagan amach na gcineálacha ionsuite tiomsaitheora.
//!
//! Is féidir iad a úsáid mar spriocanna aistrithe i gcód neamhshábháilte chun na huiríll amh a ionramháil go díreach.
//!
//!
//! Ba cheart go mbeadh a sainmhíniú comhoiriúnach leis an ABI a shainmhínítear in `rustc_middle::ty::layout` i gcónaí.
//!

/// An ionadaíocht rud trait mhaith `&dyn SomeTrait`.
///
/// Tá an struct an leagan amach céanna a bhfuil cineálacha cosúil le `&dyn SomeTrait` agus `Box<dyn AnotherTrait>`.
///
/// `TraitObject` ráthaítear go mbeidh sé comhoiriúnach le leagan amach, ach ní cineál earraí trait é (m.sh., níl na réimsí inrochtana go díreach ar `&dyn SomeTrait`) ná ní rialaíonn sé an leagan amach sin (ní athróidh athrú an tsainmhínithe leagan amach `&dyn SomeTrait`).
///
/// Níl sé deartha ach le húsáid le cód neamhshábháilte a chaithfidh na sonraí ar leibhéal íseal a ionramháil.
///
/// Níl aon bhealach ann tagairt a dhéanamh go fial do gach réad trait, mar sin is é an t-aon bhealach chun luachanna den chineál seo a chruthú ná le feidhmeanna cosúil le [`std::mem::transmute`][transmute].
/// Mar an gcéanna, is é an t-aon bhealach a chruthú trait rud fíor ó luach `TraitObject` le `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Is dóchúil go mbeidh iompar neamhshainithe mar thoradh ar réad trait a shintéisiú le cineálacha mí-chomhoiriúnacha-ceann nach bhfreagraíonn an vtable don chineál luacha a dtugann an pointeoir sonraí aird air.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // sampla trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // lig don tiomsaitheoir réad trait a dhéanamh
/// let object: &dyn Foo = &value;
///
/// // féach ar an léiriú amh
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // Is é an pointeoir sonraí an seoladh an `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // réad nua a thógáil, ag tagairt do `i32` difriúil, agus bí cúramach an inúsáidte `i32` ó `object` a úsáid
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // ba cheart go n-oibreodh sé díreach mar a bheadh réad trait tógtha againn as `other_value` go díreach
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}