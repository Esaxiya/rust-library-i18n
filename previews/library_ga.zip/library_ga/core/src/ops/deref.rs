/// Úsáidtear le haghaidh oibríochtaí dí-chomhdhála dochorraithe, cosúil le `*v`.
///
/// Chomh maith le húsáid le haghaidh oibríochtaí sainráite díchomhdhála leis an oibreoir (unary) `*` i gcomhthéacsanna dochorraithe, úsáideann an tiomsaitheoir `Deref` go hintuigthe i go leor cúinsí.
/// Tugtar ['`Deref` coercion'][more] ar an meicníocht seo.
/// I gcomhthéacsanna inathraithe, úsáidtear [`DerefMut`].
///
/// Cur chun feidhme `Deref` do leideanna cliste a dhéanann rochtain ar na sonraí taobh thiar dóibh áisiúil, agus sin an fáth siad i bhfeidhm `Deref`.
/// Ar an láimh eile, dearadh na rialacha maidir le `Deref` agus [`DerefMut`] go sonrach chun freastal ar leideanna cliste.
/// Mar gheall air seo, níor cheart **`Deref` a chur i bhfeidhm ach amháin le haghaidh leideanna cliste** chun mearbhall a sheachaint.
///
/// Ar chúiseanna cosúla,**níor cheart go dteipfeadh ar an trait seo** riamh.Is féidir le teip le linn dí-chomhdhála a bheith an-mearbhall nuair a dhéantar `Deref` a agairt go hintuigthe.
///
/// # Tuilleadh ar chomhéigean `Deref`
///
/// Má chuireann `T` `Deref<Target = U>` i bhfeidhm, agus gur luach de chineál `T` é `x`, ansin:
///
/// * I gcomhthéacsanna dochorraithe, tá `*x` (i gcás nach tagairt é `T` ná pointeoir amh) comhionann le `* Deref::deref(&x)`.
/// * Tugtar luachanna de chineál `&T` do luachanna de chineál `&U`
/// * `T` cuireann sé gach modh (immutable) den chineál `U` i bhfeidhm go hintuigthe.
///
/// Le haghaidh tuilleadh sonraí, tabhair cuairt ar [the chapter in *The Rust Programming Language*][book] chomh maith leis na rannáin tagartha ar [the dereference operator][ref-deref-op], [method resolution] agus [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Struchtúr le réimse amháin atá inrochtana tríd an struchtúr a dhírialáil.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// An cineál mar thoradh air tar éis dí-chomhdháil.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Deretions an luach.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Úsáidtear le haghaidh oibríochtaí dereferencing mutable, cosúil le `*v = 1;`.
///
/// Chomh maith le húsáid le haghaidh oibríochtaí sainráite díchomhdhála leis an oibreoir (unary) `*` i gcomhthéacsanna inathraithe, úsáideann an tiomsaitheoir `DerefMut` go hintuigthe i go leor cúinsí.
/// Tugtar ['`Deref` coercion'][more] ar an meicníocht seo.
/// I gcomhthéacsanna dochorraithe, úsáidtear [`Deref`].
///
/// Mar gheall ar `DerefMut` a chur i bhfeidhm le haghaidh leideanna cliste tá sé áisiúil na sonraí atá taobh thiar díobh a mhúchadh, agus sin an fáth go gcuireann siad `DerefMut` i bhfeidhm.
/// Ar an láimh eile, dearadh na rialacha maidir le [`Deref`] agus `DerefMut` go sonrach chun freastal ar leideanna cliste.
/// Mar gheall air seo, níor cheart **`DerefMut` a chur i bhfeidhm ach amháin le haghaidh leideanna cliste** chun mearbhall a sheachaint.
///
/// Ar chúiseanna cosúla,**níor cheart go dteipfeadh ar an trait seo** riamh.Is féidir le teip le linn dí-chomhdhála a bheith an-mearbhall nuair a dhéantar `DerefMut` a agairt go hintuigthe.
///
/// # Tuilleadh ar chomhéigean `Deref`
///
/// Má chuireann `T` `DerefMut<Target = U>`, agus tá `x` luach chineál `T`, ansin:
///
/// * I gcomhthéacsanna inathraithe, tá `*x` (i gcás nach tagairt é `T` ná pointeoir amh) comhionann le `* DerefMut::deref_mut(&mut x)`.
/// * Tugtar luachanna de chineál `&mut T` do luachanna de chineál `&mut U`
/// * `T` cuireann sé gach modh (mutable) den chineál `U` i bhfeidhm go hintuigthe.
///
/// Le haghaidh tuilleadh sonraí, tabhair cuairt ar [the chapter in *The Rust Programming Language*][book] chomh maith leis na rannáin tagartha ar [the dereference operator][ref-deref-op], [method resolution] agus [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Struchtúr le réimse amháin atá inathraithe tríd an struchtúr a dhírialáil.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Déanann sé an luach a laghdú go frithpháirteach.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Tugann sé le fios gur féidir struchtúr a úsáid mar ghlacadóir modh, gan an ghné `arbitrary_self_types`.
///
/// Cuirtear é seo i bhfeidhm de réir cineálacha pointeoir stdlib mar `Box<T>`, `Rc<T>`, `&T`, agus `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}