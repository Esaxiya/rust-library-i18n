/// trait chun iompar an oibreora `?` a shaincheapadh.
///
/// Cineál a chuireann `Try` i bhfeidhm is ea ceann a bhfuil bealach canónach aige féachaint air i dtéarmaí déchotamaíochta success/failure.
/// Ligeann an trait seo na luachanna rathúlachta nó teipe sin a bhaint as sampla atá ann cheana agus sampla nua a chruthú ó luach rathúlachta nó teip.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// An cineál luacha seo nuair a mheastar go bhfuil sé rathúil.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Cineál an luacha seo nuair a fhéachtar air mar theip air.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Cuireann sé oibreoir "?" i bhfeidhm.Ciallaíonn tuairisceán `Ok(t)` gur chóir go leanfaí den fhorghníomhú de ghnáth, agus is é toradh `?` an luach `t`.
    /// Ciallaíonn filleadh `Err(e)` gur chóir go ndéanfaí é a fhorghníomhú branch chuig an gceann is istigh a chuimsíonn `catch`, nó filleadh ón bhfeidhm.
    ///
    /// Má thugtar toradh `Err(e)` ar ais, is é an luach `e` ná "wrapped" i gcineál tuairisceáin an scóip imfhálaithe (a chaithfidh `Try` a chur i bhfeidhm ann féin).
    ///
    /// Go sonrach, is é an luach `X::from_error(From::from(e))` ais, i gcás ina bhfuil `X` an cineál ar ais na feidhme iamh.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Wrap an luach earráid a thógáil ar an toradh ilchodach.
    /// Mar shampla, tá `Result::Err(x)` agus `Result::from_error(x)` coibhéiseach.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Wrap an luach OK a thógáil ar an toradh ilchodach.
    /// Mar shampla, tá `Result::Ok(x)` agus `Result::from_ok(x)` coibhéiseach.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}