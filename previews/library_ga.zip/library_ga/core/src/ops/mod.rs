//! Oibreoirí in-luchtaithe.
//!
//! Trí na traits seo a chur i bhfeidhm is féidir leat oibreoirí áirithe a ró-ualach.
//!
//! Allmhairítear cuid de na traits seo leis an prelude, mar sin tá siad ar fáil i ngach clár Rust.Is féidir le hoibreoirí ach le tacaíocht Fhoras na traits a overloaded.
//! Mar shampla, is féidir an t-oibreoir breisithe (`+`) a ró-ualach tríd an [`Add`] trait, ach ós rud é nach bhfuil aon tacaíocht trait ag oibreoir an taisc (`=`), níl aon bhealach ann chun a shéimeantach a ró-ualach.
//! Ina theannta sin, ní sholáthraíonn an modúl seo meicníocht ar bith chun oibreoirí nua a chruthú.
//! Má theastaíonn ró-ualach nó oibreoirí saincheaptha gan tréith, ba cheart duit féachaint i dtreo macraí nó breiseán tiomsaitheora chun comhréir Rust a leathnú.
//!
//! Níor cheart go mbeadh ionadh ar chur chun feidhme an oibreora traits ina gcomhthéacsanna faoi seach, ag cuimhneamh ar na gnáthbhrí atá leo agus [operator precedence].
//! Mar shampla, agus [`Mul`] á chur i bhfeidhm, ba cheart go mbeadh cosúlacht éigin idir an oibríocht agus iolrú (agus na hairíonna a bhfuil súil leo mar chomhlachú a roinnt).
//!
//! Tabhair faoi deara go ndéanann gearr-chiorcad oibreoirí `&&` agus `||`, ie, ní dhéanann siad a dara ceoldráma a mheas ach má chuireann sé leis an toradh.Ós rud é nach bhfuil an t-iompar seo infheidhmithe ag traits, ní thacaítear le `&&` agus `||` mar oibreoirí ró-ualaigh.
//!
//! Tógann go leor de na hoibreoirí a gcuid ceoldrámaí de réir luacha.I gcomhthéacsanna neamh-chineálacha a bhaineann le cineálacha ionsuite, ní fadhb í seo de ghnáth.
//! Mar sin féin, agus na hoibreoirí seo á n-úsáid i gcód cineálach, caithfear roinnt airde a thabhairt más gá luachanna a athúsáid seachas ligean do na hoibreoirí iad a ithe.Rogha amháin is ea [`clone`] a úsáid ó am go chéile.
//! Rogha eile is ea a bheith ag brath ar na cineálacha atá i gceist ag soláthar cur chun feidhme breise oibreoirí le haghaidh tagairtí.
//! Mar shampla, maidir le cineál `T` atá sainithe ag an úsáideoir agus a cheaptar a thacaíonn le breisiú, is dócha gur smaoineamh maith é `T` agus `&T` araon an traits [`Add<T>`][`Add`] agus [`Add<&T>`][`Add`] a chur i bhfeidhm ionas gur féidir cód cineálach a scríobh gan clónáil gan ghá.
//!
//!
//! # Examples
//!
//! Cruthaíonn an sampla a struct `Point` go léiríonn uirlisí [`Add`] agus [`Sub`], agus ansin suimiú agus dealú dhá `Point`s.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Féach na cáipéisí do gach trait le haghaidh cur chun feidhme mar shampla.
//!
//! Cuirtear an [`Fn`], [`FnMut`], agus [`FnOnce`] traits i bhfeidhm de réir cineálacha is féidir a agairt mar fheidhmeanna.Tabhair faoi deara go nglacann [`Fn`] `&self`, a thógann [`FnMut`] `&mut self` agus [`FnOnce`] Bíonn `self`.
//! Tá na fhreagraíonn do na trí cineál na modhanna is féidir a agairt ar go bhfuil drochriarachán: glao-ar-thagairt, glao-ar-mutable-tagartha, agus glao-ar-luach.
//! Is é an úsáid is coitianta de na traits feidhmiú mar bounds le feidhmeanna ardleibhéil a fheidhmeanna nó dúnadh ghlacadh de réir mar argóintí.
//!
//! Ag glacadh [`Fn`] mar pharaiméadar:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Ag tabhairt [`FnMut`] mar pharaiméadar:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Ag glacadh [`FnOnce`] mar pharaiméadar:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` ídíonn a hathróga a gabhadh, mar sin ní féidir é a rith níos mó ná uair amháin
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Ag iarraidh `func()` a agairt arís caithfear earráid `use of moved value` do `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` ní féidir iad a agairt a thuilleadh ag an bpointe seo
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;