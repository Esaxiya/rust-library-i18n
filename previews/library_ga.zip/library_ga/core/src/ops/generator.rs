use crate::marker::Unpin;
use crate::pin::Pin;

/// Toradh atosú gineadóra.
///
/// Tá an Áirithe ar ais ó na modh `Generator::resume` agus léiríonn na luachanna ar ais féideartha gineadóir.
/// Faoi láthair comhfhreagraíonn sé seo do phointe fionraí (`Yielded`) nó do phointe foirceanta (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// An gineadóir ar fionraí le luach.
    ///
    /// Léiríonn an stát a bhfuil gineadóir ar fionraí, agus de ghnáth fhreagraíonn do ráiteas `yield`.
    /// Freagraíonn an luach a chuirtear ar fáil san athróg seo leis an slonn a chuirtear ar aghaidh chuig `yield` agus tugann sé deis do ghineadóirí luach a sholáthar gach uair a thugann siad toradh.
    ///
    ///
    Yielded(Y),

    /// Chríochnaigh an gineadóir le luach toraidh.
    ///
    /// Tugann an stát seo le fios go bhfuil gineadóir tar éis a fhorghníomhú a chríochnú leis an luach curtha ar fáil.
    /// Chomh luath agus a gineadóir ais `Complete` meastar go bhfuil earráid Ríomhchláraitheoir a ghlaoch `resume` arís.
    ///
    Complete(R),
}

/// An trait curtha i bhfeidhm ag cineálacha gineadóra tógtha.
///
/// Is gné thurgnamhach teanga iad gineadóirí, ar a dtugtar coroutines freisin, i Rust.
/// Tá sé beartaithe faoi láthair gineadóirí [RFC 2033] breise a chur le bloc tógála a sholáthar go príomha do chomhréir async/await ach is dóigh go leathnóidh siad chun sainmhíniú eirgeanamaíochta a sholáthar d'athraitheoirí agus do phríomhaigh eile.
///
///
/// Is é an chomhréir agus semantics do ghineadóirí éagobhsaí agus cuirfear RFC breise do chobhsú ag teastáil.Ag an am seo, áfach, is é an error dúnadh-mhaith:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Is féidir tuilleadh doiciméadú na gineadóirí a thaispeáint suas sa leabhar éagobhsaí.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// An cineál luacha a thugann an gineadóir seo.
    ///
    /// Freagraíonn an cineál gaolmhar seo leis an slonn `yield` agus na luachanna a cheadaítear a thabhairt ar ais gach uair a thugann gineadóir toradh.
    ///
    /// Mar shampla, is dóigh go mbeadh an cineál seo mar `T` ag iterator-as-a-generator, agus an cineál á atarlú.
    ///
    type Yield;

    /// An cineál luacha a fhilleann an gineadóir seo.
    ///
    /// Freagraíonn sé seo don chineál a chuirtear ar ais ó ghineadóir le ráiteas `return` nó go hintuigthe mar an abairt dheireanach de liteartha gineadóra.
    /// Mar shampla, úsáidfeadh futures é seo mar `Result<T, E>` mar go léiríonn sé future comhlánaithe.
    ///
    ///
    type Return;

    /// Tosaigh arís ar fhorghníomhú an gineadóir.
    ///
    /// Beidh an fheidhm atosú forghníomhú an gineadóir nó tús forghníomhú mura bhfuil sé cheana.
    /// Fillfidh an glao seo ar ais go pointe fionraí deireanach an ghineadóra, ag atosú ón `yield` is déanaí.
    /// Leanfaidh an gineadóir ag feidhmiú go dtí go dtabharfaidh sé toradh nó go bhfillfidh sé, agus ag an bpointe sin fillfidh an fheidhm seo ar ais.
    ///
    /// # Luach tuairisceáin
    ///
    /// Léiríonn an t-enum `GeneratorState` a cuireadh ar ais ón bhfeidhm seo cén staid ina bhfuil an gineadóir ag filleadh.
    /// Má chuirtear an t-athraitheach `Yielded` ar ais ansin tá pointe fionraí bainte amach ag an gineadóir agus tá luach tugtha amach.
    /// Tá gineadóirí sa stát seo ar fáil lena n-atosú níos déanaí.
    ///
    /// Má chuirtear `Complete` ar ais ansin tá an gineadóir críochnaithe go hiomlán leis an luach a cuireadh ar fáil.Tá sé neamhbhailí an gineadóir a atosú arís.
    ///
    /// # Panics
    ///
    /// Féadfaidh an fheidhm seo panic a ghlaoch má ghlaotar uirthi tar éis an leagan `Complete` a bheith curtha ar ais roimhe seo.
    /// Cé go ráthaítear litearthacht gineadóirí sa teanga do panic ar atosú tar éis `Complete`, ní ráthaítear é seo do gach cur chun feidhme den `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}