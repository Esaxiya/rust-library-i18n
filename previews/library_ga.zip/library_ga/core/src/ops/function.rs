/// An leagan den oibreoir glaoch a thógann glacadóir immutable.
///
/// Is féidir cásanna `Fn` a ghlaoch arís agus arís eile gan staid mutating.
///
/// *Ní gá an trait (`Fn`) seo a mheascadh le [function pointers] (`fn`).*
///
/// `Fn` a chur i bhfeidhm go huathoibríoch trí dhúnadh nach dtógann ach tagairtí dochorraithe d`athróga a gabhadh nó nach ngabhann aon rud leo ar chor ar bith, chomh maith le (safe) [function pointers] (le roinnt caveat, féach a ndoiciméadacht le haghaidh tuilleadh sonraí).
///
/// Ina theannta sin, maidir le haon chineál `F` a chuireann `Fn` i bhfeidhm, cuireann `&F` `Fn` i bhfeidhm freisin.
///
/// Ó tharla go bhfuil [`FnMut`] agus [`FnOnce`] an dá supertraits de `Fn`, is féidir aon chás de `Fn` a úsáid mar pharaiméadar sa chás go bhfuil [`FnMut`] nó [`FnOnce`] ag súil leis.
///
/// Úsáid `Fn` mar cheangal nuair is mian leat glacadh le paraiméadar de chineál cosúil le feidhm agus ní mór duit é a ghlaoch arís agus arís eile agus gan staid muta (m.sh., agus é á ghlaoch i gcomhthráth).
/// Mura bhfuil dianriachtanais den sórt sin ag teastáil uait, bain úsáid as [`FnMut`] nó [`FnOnce`] mar theorainneacha.
///
/// Féach an [chapter on closures in *The Rust Programming Language*][book] le haghaidh tuilleadh faisnéise ar an ábhar seo.
///
/// Is díol suntais freisin an chomhréir speisialta do `Fn` traits (m.sh.
/// `Fn(usize, bool) -> usize`).Is féidir leo siúd ar spéis leo sonraí teicniúla faoi seo tagairt a dhéanamh do [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Ag glaoch ar dhúnadh
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Ag baint úsáide as paraiméadar `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ionas gur féidir le regex a bheith ag brath ar `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Déanann sé an oibríocht glaonna.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Leagan an oibreora glaonna a ghlacann glacadóir inathraithe.
///
/// Is féidir cásanna `FnMut` a ghlaoch arís agus arís eile agus féadfaidh siad mutate stáit.
///
/// `FnMut` bhfeidhm go huathoibríoch ag dúnadh a ghlacadh tagairtí mutable athróga a gabhadh, chomh maith le gach cineál a chuireann i bhfeidhm [`Fn`], mar shampla, (safe) [function pointers] (ós rud é go `FnMut` a supertrait de [`Fn`]).
/// Ina theannta sin, maidir le haon chineál `F` a chuireann `FnMut` i bhfeidhm, cuireann `&mut F` `FnMut` i bhfeidhm freisin.
///
/// Ós rud é gur supertrait de `FnMut` é [`FnOnce`], is féidir aon chás de `FnMut` a úsáid sa chás go bhfuiltear ag súil le [`FnOnce`], agus ós rud é gur foshraith de `FnMut` é [`Fn`], is féidir aon chás de [`Fn`] a úsáid ina bhfuil súil le `FnMut`.
///
/// Úsáid `FnMut` mar cheangal nuair is mian leat glacadh le paraiméadar de chineál cosúil le feidhm agus ní mór duit é a ghlaoch arís agus arís eile, agus ligean dó staid a threáitear.
/// Mura dteastaíonn uait an paraiméadar a luainiú, úsáid [`Fn`] mar cheangal;mura gá duit glaoch air arís agus arís eile, bain úsáid as [`FnOnce`].
///
/// Féach an [chapter on closures in *The Rust Programming Language*][book] le haghaidh tuilleadh faisnéise ar an ábhar seo.
///
/// Is díol suntais freisin an chomhréir speisialta do `Fn` traits (m.sh.
/// `Fn(usize, bool) -> usize`).Is féidir leo siúd ar spéis leo sonraí teicniúla faoi seo tagairt a dhéanamh do [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Ag iarraidh dúnadh a ghabháil go frithpháirteach
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Ag baint úsáide as paraiméadar `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ionas gur féidir le regex a bheith ag brath ar `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Déanann sé an oibríocht glaonna.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Leagan an oibreora glaonna a ghlacann glacadóir seachluacha.
///
/// Is féidir cásanna `FnOnce` a ghlaoch, ach d`fhéadfadh nach mbeadh siad inghlaoite arís agus arís eile.Mar gheall air seo, más é an t-aon rud atá ar eolas faoi chineál ná go gcuireann sé `FnOnce` i bhfeidhm, ní féidir glaoch air ach uair amháin.
///
/// `FnOnce` a chur i bhfeidhm go huathoibríoch trí dhúnadh a d`fhéadfadh athróga a gabhadh a ithe, chomh maith le gach cineál a chuireann [`FnMut`] i bhfeidhm, m.sh., (safe) [function pointers] (ós rud é gur supertrait de [`FnMut`] é `FnOnce`).
///
///
/// Ó tharla gur fo-thréithe de `FnOnce` iad [`Fn`] agus [`FnMut`], is féidir aon chás de [`Fn`] nó [`FnMut`] a úsáid nuair a bhíonn súil le `FnOnce`.
///
/// Úsáid `FnOnce` mar cheangal nuair is mian leat glacadh le paraiméadar de chineál cosúil le feidhm agus gan ort ach glaoch air uair amháin.
/// Más gá duit an paraiméadar a ghlaoch arís agus arís eile, bain úsáid as [`FnMut`] mar cheangal;más gá duit freisin gan stát a threáitear, bain úsáid as [`Fn`].
///
/// Féach an [chapter on closures in *The Rust Programming Language*][book] le haghaidh tuilleadh faisnéise ar an ábhar seo.
///
/// Is díol suntais freisin an chomhréir speisialta do `Fn` traits (m.sh.
/// `Fn(usize, bool) -> usize`).Is féidir leo siúd ar spéis leo sonraí teicniúla faoi seo tagairt a dhéanamh do [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Ag baint úsáide as paraiméadar `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` ídíonn a hathróga a gabhadh, mar sin ní féidir é a rith níos mó ná uair amháin.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Ag iarraidh a agairt `func()` arís beidh caith earráid `use of moved value` do `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` ní féidir iad a agairt a thuilleadh ag an bpointe seo
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ionas gur féidir le regex a bheith ag brath ar `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// An cineál a chuirtear ar ais tar éis don oibreoir glaonna a úsáid.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Déanann sé an oibríocht glaonna.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}