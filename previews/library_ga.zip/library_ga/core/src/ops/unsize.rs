use crate::marker::Unsize;

/// Trait a thugann le fios gur pointeoir nó fillteán é seo do cheann amháin, áit ar féidir neamhshábháilte a dhéanamh ar an leid.
///
/// Féach an [DST coercion RFC][dst-coerce] agus [the nomicon entry on coercion][nomicon-coerce] le haghaidh tuilleadh sonraí.
///
/// Maidir le cineálacha pointeoir tógtha, rachaidh leideanna go `T` le leideanna go `U` más `T: Unsize<U>` iad trí thiontú ó phointeoir tanaí go pointeoir saille.
///
/// Maidir le cineálacha saincheaptha, oibríonn an comhéigean anseo trí `Foo<T>` go `Foo<U>` a chomhordú ar choinníoll go bhfuil impl `CoerceUnsized<Foo<U>> for Foo<T>` ann.
/// Ní féidir impl den sórt sin a scríobh ach mura bhfuil ach réimse neamh-phantomdata amháin ag `Foo<T>` ina bhfuil `T`.
/// Más é `Bar<T>` cineál an réimse sin, ní mór `CoerceUnsized<Bar<U>> for Bar<T>` a chur i bhfeidhm.
/// Oibreoidh an comhéigean tríd an réimse `Bar<T>` a chomhéigniú go `Bar<U>` agus an chuid eile de na réimsí ó `Foo<T>` a líonadh isteach chun `Foo<U>` a chruthú.
/// Déanfaidh sé seo druileáil síos go réimse pointeora go héifeachtach agus é a chomhbhrú.
///
/// Go ginearálta, le haghaidh leideanna cliste cuirfidh tú `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` i bhfeidhm, le `?Sized` roghnach ceangailte ar `T` féin.
/// Maidir le cineálacha cumhdaigh a leabaíonn `T` go díreach cosúil le `Cell<T>` agus `RefCell<T>`, is féidir leat `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` a chur i bhfeidhm go díreach.
///
/// Ligfidh sé seo comhéifeachtaí de chineálacha cosúil le `Cell<Box<T>>` a bheith ag obair.
///
/// [`Unsize`][unsize] Úsáidtear é chun cineálacha is féidir a chomhbhrú le DSTanna a mharcáil má tá siad taobh thiar de leideanna.Cuireann an tiomsaitheoir i bhfeidhm é go huathoibríoch.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Úsáidtear é seo le haghaidh sábháilteachta réad, chun a sheiceáil gur féidir cineál glacadóra modh a sheoladh.
///
/// Sampla de chur i bhfeidhm an trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}