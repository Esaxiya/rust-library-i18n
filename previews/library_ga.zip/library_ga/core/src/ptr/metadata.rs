#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Soláthraíonn sé an cineál meiteashonraí pointeoir d'aon chineál pointeáilte.
///
/// # Meiteashonraí pointeoir
///
/// Is féidir smaoineamh ar chineálacha pointeoir amh agus cineálacha tagartha i Rust mar dhá chuid:
/// pointeoir sonraí ina bhfuil seoladh cuimhne an luacha, agus roinnt meiteashonraí.
///
/// Maidir le cineálacha de mhéid statach (a chuireann an `Sized` traits i bhfeidhm) chomh maith le cineálacha `extern`, deirtear go bhfuil leideanna `tanaí`: tá meiteashonraí meánmhéide agus is é `()` a gcineál.
///
///
/// Deirtear go bhfuil leideanna le [dynamically-sized types][dst] `leathan` nó `ramhar`, tá meiteashonraí neamh-nialasacha acu:
///
/// * Maidir le struchtúir a bhfuil DST ina réimse deireanach, is é meiteashonraí na meiteashonraí don réimse deireanach
/// * Maidir leis an gcineál `str`, tá meiteashonraí an fad, i mbearta mar `usize`
/// * I gcás cineálacha slice mhaith `[T]`, tá meiteashonraí an fad i nithe mar `usize`
/// * Maidir le rudaí trait cosúil le `dyn SomeTrait`, is é meiteashonraí [`DynMetadata<Self>`][DynMetadata] (m.sh. `DynMetadata<dyn SomeTrait>`)
///
/// Sa future, féadfaidh an teanga Rust cineálacha nua cineálacha a fháil a bhfuil meiteashonraí pointeora difriúla acu.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # An trait `Pointee`
///
/// Is é pointe an trait seo an cineál a bhaineann leis `Metadata`, is é sin `()` nó `usize` nó `DynMetadata<_>` mar a thuairiscítear thuas.
/// Cuirtear i bhfeidhm go huathoibríoch é do gach cineál.
/// Is féidir glacadh leis go gcuirtear i bhfeidhm é i gcomhthéacs cineálach, fiú gan cheangal comhfhreagrach.
///
/// # Usage
///
/// Is féidir leideanna amha a dhianscaoileadh isteach sa seoladh sonraí agus sna comhpháirteanna meiteashonraí lena modh [`to_raw_parts`].
///
/// Nó is féidir meiteashonraí amháin a bhaint leis an bhfeidhm [`metadata`].
/// Is féidir tagairt a sheoladh chuig [`metadata`] agus é a chomhbhrú go hintuigthe.
///
/// Is féidir pointeoir (possibly-wide) a chur le chéile óna sheoladh agus meiteashonraí le [`from_raw_parts`] nó [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// An cineál meiteashonraí i leideanna agus tagairtí do `Self`.
    #[lang = "metadata_type"]
    // NOTE: Coinnigh trait bounds i `static_assert_expected_bounds_for_metadata`
    //
    // i `library/core/src/ptr/metadata.rs` i info leis sin anseo:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Tá leideanna chun cineálacha cur chun feidhme an ailias trait "tanaí".
///
/// Áirítear leis seo cineálacha statically-`Sized` agus cineálacha `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: ná déan é seo a chobhsú sula mbeidh ailiasanna trait seasmhach sa teanga?
pub trait Thin = Pointee<Metadata = ()>;

/// Sliocht an chomhpháirt meiteashonraí de phointeoir.
///
/// Is féidir luachanna de chineál `*mut T`, `&T`, nó `&mut T` a chur ar aghaidh go díreach chuig an bhfeidhm seo mar go gcomhoibríonn siad go hintuigthe le `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SÁBHÁILTEACHT: Tá sé sábháilte rochtain a fháil ar an luach ón aontas `PtrRepr` ó * const T.
    // agus PtrComponents<T>tá an leagan amach chuimhne chéanna.
    // Ní féidir ach le std an ráthaíocht seo a dhéanamh.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Foirmeacha pointeoir amh (possibly-wide) ó sheoladh sonraí agus meiteashonraí.
///
/// Tá an fheidhm seo sábháilte ach ní gá go bhfuil an pointeoir ar ais sábháilte le tréigean.
/// Le haghaidh slisní, féach cáipéisíocht [`slice::from_raw_parts`] le haghaidh riachtanais sábháilteachta.
/// Maidir le rudaí trait, caithfidh na meiteashonraí teacht ó phointeoir go dtí an cineál céanna bunáite.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SÁBHÁILTEACHT: Tá sé sábháilte rochtain a fháil ar an luach ón aontas `PtrRepr` ó * const T.
    // agus PtrComponents<T>tá an leagan amach chuimhne chéanna.
    // Ní féidir ach le std an ráthaíocht seo a dhéanamh.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Feidhmíonn sé an fheidhmiúlacht chéanna le [`from_raw_parts`], ach amháin go gcuirtear pointeoir amh `*mut` ar ais, seachas pointeoir `* const` amh.
///
///
/// Féach ar dhoiciméadú an [`from_raw_parts`] le haghaidh tuilleadh sonraí.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SÁBHÁILTEACHT: Tá sé sábháilte rochtain a fháil ar an luach ón aontas `PtrRepr` ó * const T.
    // agus PtrComponents<T>tá an leagan amach chuimhne chéanna.
    // Ní féidir ach le std an ráthaíocht seo a dhéanamh.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// impl Lámhleabhar gá a sheachaint `T: Copy` cheangal.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// impl Lámhleabhar gá a sheachaint `T: Clone` cheangal.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// An meiteashonraí le haghaidh cineáil ruda `Dyn = dyn SomeTrait` trait.
///
/// Is pointeoir chuig vtable (tábla glaoch fíorúil) gur ionann an t-eolas go léir is gá a ionramháil an gcineál coincréite stóráil taobh istigh de rud trait.
/// An vtable go háirithe tá sé:
///
/// * méid cineáil
/// * ailíniú cineáil
/// * pointeoir ar impl `drop_in_place` an chineáil (d`fhéadfadh sé a bheith ina rogha ar bith le haghaidh sonraí sean-aosta)
/// * leideanna do na modhanna maidir le cineál ar chur i bhfeidhm an trait
///
/// Tabhair faoi deara go bhfuil na chéad trí cinn speisialta toisc go bhfuil siad riachtanach chun aon réad trait a leithdháileadh, a scaoil agus a thuiscint.
///
/// Is féidir an struchtúr seo a ainmniú le paraiméadar cineáil nach réad `dyn` trait (mar shampla `DynMetadata<u64>`) ach gan luach bríoch den struchtúr sin a fháil.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// An réimír coitianta de gach vtables.Tá sé ina dhiaidh ag leideanna feidhme le haghaidh modhanna trait.
///
/// Sonraí cur chun feidhme príobháideach `DynMetadata::size_of` srl.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Filleann sé méid an chineáil a bhaineann leis an mbíog seo.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Filleann sé ailíniú an chineáil a bhaineann leis an mbíog seo.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Filleann sé an méid agus an t-ailíniú le chéile mar `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SÁBHÁILTEACHT: astaíonn an tiomsaitheoir an t-inbhainte seo le haghaidh cineál coincréite Rust a
        // is eol go bhfuil leagan amach bailí aige.réasúnaíocht chéanna atá leis in `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// impls Lámhleabhar gá a sheachaint bounds `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}