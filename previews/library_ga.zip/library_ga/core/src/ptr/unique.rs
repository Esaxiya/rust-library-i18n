use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// A wrapper timpeall ar amh neamh-null `*mut T` a léiríonn go úinéireacht an sealbhóir ar an fillteán ar an tagraí.
/// Úsáideach chun astarraingtí a thógáil mar `Box<T>`, `Vec<T>`, `String`, agus `HashMap<K, V>`.
///
/// Murab ionann agus `*mut T`, behaves `Unique<T>` "as if" mba go bhfuil drochriarachán i `T`.
/// Cuireann sé `Send`/`Sync` i bhfeidhm más X002 é `T`.
/// Tugann sé le tuiscint freisin an cineál ráthaíochtaí láidre ailiastaithe ar féidir a bheith ag súil le sampla de `T`:
/// Níor cheart an tagraí an pointeoir a athrú gan cosán uathúil a Uathúil húinéir.
///
/// Mura bhfuil tú cinnte an bhfuil sé ceart `Unique` a úsáid chun do chuspóirí, smaoinigh ar `NonNull` a úsáid, a bhfuil séimeantaic níos laige ann.
///
///
/// Murab ionann agus `*mut T`, ní mór don phointeoir a bheith neamhní i gcónaí, fiú mura ndéantar an pointeoir a dhífhabhtú riamh.
/// Tá sé seo ionas gur féidir enums úsáid luach forbidden mar discriminant-`Option<Unique<T>>` Tá an méid céanna leis `Unique<T>`.
/// Ach d'fhéadfadh an pointeoir dangle fós mura bhfuil sé dereferenced.
///
/// Murab ionann agus `*mut T`, tá `Unique<T>` inmhalartaithe thar `T`.
/// Ba cheart go mbeadh sé seo ceart i gcónaí d`aon chineál a sheasann le riachtanais ailiastaithe uathúla.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: níl aon iarmhairtí ag an marcóir seo ar athraitheas, ach tá sé riachtanach
    // le dropck a thuiscint go bhfuil muid féin loighciúil a `T`.
    //
    // Le haghaidh sonraí, féach ar:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` Tá leideanna `Send` má tá `T` `Send` toisc go bhfuil na sonraí a tagartha siad unaliased.
/// Tabhair faoi deara go bhfuil an t-invariant ailiasach seo neamh-fhorfheidhmithe ag an gcóras cineáil;caithfidh an astarraingt a úsáideann an `Unique` é a fhorfheidhmiú.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` tá leideanna `Sync` más `T` `Sync` toisc go bhfuil na sonraí a ndéanann siad tagairt dóibh neamhchlaonta.
/// Tabhair faoi deara go bhfuil an t-invariant ailiasach seo neamh-fhorfheidhmithe ag an gcóras cineáil;caithfidh an astarraingt a úsáideann an `Unique` é a fhorfheidhmiú.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Cruthaíonn sé `Unique` nua atá ag crochadh, ach ailínithe go maith.
    ///
    /// Tá sé seo úsáideach chun cineálacha a leithdháileann go leisciúil a thionscnamh, mar a dhéanann `Vec::new`.
    ///
    /// Tabhair faoi deara go bhféadfadh an luach pointeoir ionadaíocht a dhéanamh d'fhéadfadh a bheith ina pointeoir bailí do `T`, rud a chiallaíonn ní mór seo a úsáid mar "not yet initialized" sentinel luach.
    /// Ní mór do chineálacha a leithdháileann leisciúil an tosach feidhme a rianú ar bhealach éigin eile.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SÁBHÁILTEACHT: mem::align_of() tuairisceáin bailí, pointeoir neamh-null.Tá an
        // urramaítear mar sin coinníollacha chun new_unchecked() a ghlaoch.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Cruthaíonn `Unique` nua.
    ///
    /// # Safety
    ///
    /// `ptr` Ní mór a bheith neamh-null.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SÁBHÁILTEACHT: ní mór don té atá ag glaoch a ráthú go bhfuil `ptr` neamh-null.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Cruthaíonn sé `Unique` nua má tá `ptr` neamh-null.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SÁBHÁILTEACHT: Seiceáladh an pointeoir cheana féin agus níl sé ar neamhní.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Faightear an pointeoir `*mut` bunúsach.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Dereferences an t-ábhar.
    ///
    /// Is é an saolré mar thoradh cheangal chun féin mar sin an behaves "as if" mba i ndáiríre go bhfuil drochriarachán i T atá ag dul ar iasacht.
    /// Má theastaíonn saolré (unbound) níos faide, bain úsáid as `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch a ráthú go gcomhlíonann `self` na
        // ceanglais maidir le tagairt.
        unsafe { &*self.as_ptr() }
    }

    /// Déanann sé an t-ábhar a chur siar go mór.
    ///
    /// Is é an saolré mar thoradh cheangal chun féin mar sin an behaves "as if" mba i ndáiríre go bhfuil drochriarachán i T atá ag dul ar iasacht.
    /// Má tá (unbound) feadh an tsaoil a thuilleadh ag teastáil, úsáid `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch a ráthú go gcomhlíonann `self` na
        // ceanglais maidir le tagairt inathraithe.
        unsafe { &mut *self.as_ptr() }
    }

    /// Casts go pointeoir de chineál eile.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SÁBHÁILTEACHT: Cruthaíonn Unique::new_unchecked() uathúil agus riachtanais nua
        // gan an pointeoir tugtha a bheith ar neamhní.
        // Ós rud é go bhfuil muid ag dul féin mar pointeoir, ní féidir é a null.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SÁBHÁILTEACHT: Ní féidir tagairt inathraithe a chur ar neamhní
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}