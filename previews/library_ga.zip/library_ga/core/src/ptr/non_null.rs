use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` ach neamh-nialasach agus covariant.
///
/// Is minic gurb é seo an rud ceart le húsáid agus struchtúir sonraí á dtógáil ag úsáid leideanna amha, ach sa deireadh bíonn sé níos contúirtí le húsáid mar gheall ar a airíonna breise.Mura bhfuil tú cinnte ar cheart duit `NonNull<T>` a úsáid, níl ort ach `*mut T` a úsáid!
///
/// Murab ionann agus `*mut T`, ní mór don phointeoir a bheith neamhní i gcónaí, fiú mura ndéantar an pointeoir a dhífhabhtú riamh.Déantar é seo ionas go bhféadfaidh enums an luach toirmiscthe seo a úsáid mar idirdhealaitheoir-tá an méid céanna ag `Option<NonNull<T>>` le `* mut T`.
/// Ach d'fhéadfadh an pointeoir dangle fós mura bhfuil sé dereferenced.
///
/// Murab ionann agus `*mut T`, roghnaíodh `NonNull<T>` chun a bheith comhlántach thar `T`.Fágann sé sin gur féidir `NonNull<T>` a úsáid agus cineálacha comhchuibhithe á dtógáil, ach tugtar isteach an baol míshuaimhnis má úsáidtear é i gcineál nár cheart a bheith comhlántach i ndáiríre.
/// (Rinneadh rogha eile do `*mut T` cé go teicniúil nach bhféadfadh an neamhshuaimhneas a bheith mar thoradh air ach feidhmeanna neamhshábháilte a ghlaoch.)
///
/// Tá an comhghaolmhaireacht ceart don chuid is mó astarraingtí sábháilte, mar shampla `Box`, `Rc`, `Arc`, `Vec`, agus `LinkedList`.Is é seo an cás toisc go soláthraíonn siad API poiblí a leanann gnáthrialacha mutable XOR roinnte Rust.
///
/// Murar féidir le do chineál a bheith comhchuingeach go sábháilte, ní mór duit a chinntiú go bhfuil réimse breise ann chun ionradh a sholáthar.Go minic beidh réimse seo a bheith ina chineál [`PhantomData`] cosúil `PhantomData<Cell<T>>` nó `PhantomData<&'a mut T>`.
///
/// Tabhair faoi deara go bhfuil sampla `From` ag `NonNull<T>` do `&T`.Ní athraíonn sé seo, áfach, gur iompar neamhshainithe é mutating trí thagairt roinnte (pointeoir a dhíorthaítear ó a) mura dtarlaíonn an sóchán taobh istigh de [`UnsafeCell<T>`].An rud céanna maidir le tagairt inathraithe a chruthú ó thagairt roinnte.
///
/// Agus an cás `From` seo á úsáid agat gan `UnsafeCell<T>`, tá sé de fhreagracht ort a chinntiú nach nglaofar `as_mut` riamh, agus nach n-úsáidtear `as_ptr` riamh le haghaidh sóchán.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` ní `Send` na leideanna toisc go bhféadtar na sonraí a ndéanann siad tagairt dóibh a ailíniú.
// NB, tá an impl gan ghá, ach ba chóir a chur ar fáil teachtaireachtaí earráide níos fearr.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` Nach bhfuil leideanna `Sync` toisc nach féidir na sonraí tagartha iad a aliased.
// NB, tá an impl gan ghá, ach ba chóir a chur ar fáil teachtaireachtaí earráide níos fearr.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Cruthaigh `NonNull` nua atá dangling, ach dea-ailínithe.
    ///
    /// Tá sé seo úsáideach chun cineálacha a leithdháileann go leisciúil a thionscnamh, mar a dhéanann `Vec::new`.
    ///
    /// Tabhair faoi deara go bhféadfadh an luach pointeoir ionadaíocht a dhéanamh d'fhéadfadh a bheith ina pointeoir bailí do `T`, rud a chiallaíonn ní mór seo a úsáid mar "not yet initialized" sentinel luach.
    /// Ní mór do chineálacha a leithdháileann leisciúil an tosach feidhme a rianú ar bhealach éigin eile.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SÁBHÁILTEACHT: mem::align_of() tuairisceáin neamh-náid usize atá casted ansin
        // le T. mut *
        // Mar sin, nach bhfuil `ptr` faoin margadh saothair agus na coinníollacha maidir le glaoch new_unchecked() urramaítear.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Cuireann sé tagairtí roinnte don luach ar ais.I gcodarsnacht le [`as_ref`], ní éilíonn sé seo go gcaithfear an luach a thosú.
    ///
    /// Féach an [`as_uninit_mut`] don mhacasamhail inathraithe.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Agus an modh seo á ghlaoch agat, caithfidh tú a chinntiú go bhfuil gach ceann díobh seo a leanas fíor:
    ///
    /// * Caithfear an pointeoir a ailíniú i gceart.
    ///
    /// * Caithfidh sé a bheith "dereferencable" sa chiall a shainmhínítear in [the module documentation].
    ///
    /// * Ní mór duit rialacha aliasing Rust fhorfheidhmiú, ós rud é an saolré ar ais é `'a` roghnaithe treallach agus ní gá go léiríonn saolré iarbhír na sonraí.
    ///
    ///   Go háirithe, ar feadh ré an tsaoil seo, ní gá go dtréigfear an chuimhne a ndéanann an pointeoir tagairt dó (ach amháin taobh istigh de `UnsafeCell`).
    ///
    /// Tá feidhm leis seo fiú mura n-úsáidtear toradh an mhodha seo!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch a ráthú go gcomhlíonann `self` na
        // ceanglais maidir le tagairt.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Filleann tagairtí uathúla don luach.I gcodarsnacht le [`as_mut`], ní éilíonn sé seo go gcaithfear an luach a thosú.
    ///
    /// Maidir leis an mhacasamhail comhroinnte fheiceáil [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Agus an modh seo á ghlaoch agat, caithfidh tú a chinntiú go bhfuil gach ceann díobh seo a leanas fíor:
    ///
    /// * Caithfear an pointeoir a ailíniú i gceart.
    ///
    /// * Caithfidh sé a bheith "dereferencable" sa chiall a shainmhínítear in [the module documentation].
    ///
    /// * Ní mór duit rialacha aliasing Rust fhorfheidhmiú, ós rud é an saolré ar ais é `'a` roghnaithe treallach agus ní gá go léiríonn saolré iarbhír na sonraí.
    ///
    ///   Go háirithe, ar feadh ré an tsaoil, an chuimhne na pointí pointeoir go mór gan a bheith rochtain (léamh nó a scríobh) trí aon pointeoir eile.
    ///
    /// Tá feidhm leis seo fiú mura n-úsáidtear toradh an mhodha seo!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch a ráthú go gcomhlíonann `self` na
        // ceanglais maidir le tagairt.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Cruthaíonn `NonNull` nua.
    ///
    /// # Safety
    ///
    /// `ptr` Ní mór a bheith neamh-null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SÁBHÁILTEACHT: ní mór don té atá ag glaoch a ráthú go bhfuil `ptr` neamh-null.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Cruthaíonn sé `NonNull` nua má tá `ptr` neamh-null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SÁBHÁILTEACHT: Seiceáiltear an pointeoir cheana féin agus níl sé ar neamhní
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Fheidhmíonn an fheidhmiúlacht céanna le [`std::ptr::from_raw_parts`], a eisceadh go bhfuil pointeoir `NonNull` ais, i gcomparáid le `*const` pointeoir amh.
    ///
    ///
    /// Féach cáipéisíocht [`std::ptr::from_raw_parts`] le haghaidh tuilleadh sonraí.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SÁBHÁILTEACHT: Tá toradh `ptr::from::raw_parts_mut` neamh-null toisc go bhfuil `data_address`.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Déan pointeoir (leathan b`fhéidir) a dhianscaoileadh ina chomhpháirteanna seoltaí agus meiteashonraí.
    ///
    /// Is féidir an pointeoir a athchruthú níos déanaí le [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Faightear an pointeoir `*mut` bunúsach.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Filleann tagairt roinnte don luach.Más féidir leis an luach a uninitialized, ní mór [`as_uninit_ref`] a úsáid in ionad.
    ///
    /// Féach an [`as_mut`] don mhacasamhail inathraithe.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Agus an modh seo á ghlaoch agat, caithfidh tú a chinntiú go bhfuil gach ceann díobh seo a leanas fíor:
    ///
    /// * Caithfear an pointeoir a ailíniú i gceart.
    ///
    /// * Caithfidh sé a bheith "dereferencable" sa chiall a shainmhínítear in [the module documentation].
    ///
    /// * Caithfidh an pointeoir tagairt do shampla tosaigh de `T`.
    ///
    /// * Ní mór duit rialacha aliasing Rust fhorfheidhmiú, ós rud é an saolré ar ais é `'a` roghnaithe treallach agus ní gá go léiríonn saolré iarbhír na sonraí.
    ///
    ///   Go háirithe, ar feadh ré an tsaoil seo, ní gá go dtréigfear an chuimhne a ndéanann an pointeoir tagairt dó (ach amháin taobh istigh de `UnsafeCell`).
    ///
    /// Tá feidhm leis seo fiú mura n-úsáidtear toradh an mhodha seo!
    /// (Níl cinneadh iomlán déanta fós ar an gcuid faoi thús a chur leis, ach go dtí go mbeidh, is é an t-aon chur chuige sábháilte ná a chinntiú go ndéantar iad a thionscnamh i ndáiríre.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch a ráthú go gcomhlíonann `self` na
        // ceanglais maidir le tagairt.
        unsafe { &*self.as_ptr() }
    }

    /// Filleann tagairt uathúil don luach.Más féidir leis an luach a uninitialized, ní mór [`as_uninit_mut`] a úsáid in ionad.
    ///
    /// Féach an [`as_ref`] don mhacasamhail roinnte.
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Agus an modh seo á ghlaoch agat, caithfidh tú a chinntiú go bhfuil gach ceann díobh seo a leanas fíor:
    ///
    /// * Caithfear an pointeoir a ailíniú i gceart.
    ///
    /// * Caithfidh sé a bheith "dereferencable" sa chiall a shainmhínítear in [the module documentation].
    ///
    /// * Caithfidh an pointeoir tagairt do shampla tosaigh de `T`.
    ///
    /// * Ní mór duit rialacha aliasing Rust fhorfheidhmiú, ós rud é an saolré ar ais é `'a` roghnaithe treallach agus ní gá go léiríonn saolré iarbhír na sonraí.
    ///
    ///   Go háirithe, ar feadh ré an tsaoil, an chuimhne na pointí pointeoir go mór gan a bheith rochtain (léamh nó a scríobh) trí aon pointeoir eile.
    ///
    /// Tá feidhm leis seo fiú mura n-úsáidtear toradh an mhodha seo!
    /// (Níl cinneadh iomlán déanta fós ar an gcuid faoi thús a chur leis, ach go dtí go mbeidh, is é an t-aon chur chuige sábháilte ná a chinntiú go ndéantar iad a thionscnamh i ndáiríre.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch a ráthú go gcomhlíonann `self` na
        // ceanglais maidir le tagairt inathraithe.
        unsafe { &mut *self.as_ptr() }
    }

    /// Casts go pointeoir de chineál eile.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SÁBHÁILTEACHT: Is pointeoir `NonNull` é `self` atá neamh-null de ghnáth
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Cruthaíonn sé slice amh neamh-null ó phointeoir tanaí agus fad.
    ///
    /// Is í argóint `len` líon na n-eilimintí **, ní líon na mbeart.
    ///
    /// Tá an fheidhm seo sábháilte, ach tá sé neamhshábháilte an luach toraidh a dhí-chomhdháil.
    /// Féach ar dhoiciméadú an [`slice::from_raw_parts`] do riachtanais sábháilteachta slice.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // pointeoir slice a chruthú agus tú ag tosú amach le pointeoir go dtí an chéad eilimint
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Tabhair faoi deara go léiríonn an sampla seo go saorga úsáid den mhodh seo, ach `lig slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SÁBHÁILTEACHT: Is pointeoir `NonNull` é `data` atá neamh-null de ghnáth
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Filleann sé fad slice amh neamh-null.
    ///
    /// Is é an luach a chuirtear ar ais ná líon na n-eilimintí **, ní líon na mbeart.
    ///
    /// Tá an fheidhm seo sábháilte, fiú nuair nach féidir an slice amh neamh-null a dhíriú ar shlisne toisc nach bhfuil seoladh bailí ag an bpointeoir.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Tuairisceáin pointeoir neamh-null le maolán an slice ar.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SÁBHÁILTEACHT: Tá a fhios againn go bhfuil `self` neamh-null.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Tugann pointeoir amh ar ais do mhaolán an tslis.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Tugann sé tagairt chomhroinnte ar ais do shlisne de luachanna a d`fhéadfadh a bheith neamhbheartaithe.I gcodarsnacht le [`as_ref`], ní éilíonn sé seo go gcaithfear an luach a thosú.
    ///
    /// Maidir leis an mhacasamhail mutable fheiceáil [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Agus an modh seo á ghlaoch agat, caithfidh tú a chinntiú go bhfuil gach ceann díobh seo a leanas fíor:
    ///
    /// * Ní mór don pointeoir a [valid] do léann do bytes `ptr.len() * mem::size_of::<T>()` go leor, agus ní mór é a chur ar chomhréim i gceart.Ciallaíonn sé seo go háirithe:
    ///
    ///     * Ní mór raon cuimhne iomlán an tslis seo a bheith laistigh d`ábhar leithdháilte amháin!
    ///       Ní féidir le Slices span fud na rudaí a leithdháileadh il.
    ///
    ///     * Ní mór an pointeoir a ailíniú fiú le haghaidh slisní faid nialasacha.
    ///     Cúis amháin leis seo ná go bhféadfadh barrfheabhsú leagan amach enum a bheith ag brath ar thagairtí (lena n-áirítear slisní ar aon fhaid) a bheith ailínithe agus neamh-null chun iad a idirdhealú ó shonraí eile.
    ///
    ///     Is féidir leat pointeoir a fháil atá inúsáidte mar `data` le haghaidh slisní faid nialasacha ag úsáid [`NonNull::dangling()`].
    ///
    /// * Ní mór nach mbeidh méid iomlán `ptr.len() * mem::size_of::<T>()` an slice níos mó ná `isize::MAX`.
    ///   Féach ar dhoiciméadú shábháilteacht [`pointer::offset`].
    ///
    /// * Ní mór duit rialacha aliasing Rust fhorfheidhmiú, ós rud é an saolré ar ais é `'a` roghnaithe treallach agus ní gá go léiríonn saolré iarbhír na sonraí.
    ///   Go háirithe, ar feadh ré an tsaoil seo, ní gá go dtréigfear an chuimhne a ndéanann an pointeoir tagairt dó (ach amháin taobh istigh de `UnsafeCell`).
    ///
    /// Tá feidhm leis seo fiú mura n-úsáidtear toradh an mhodha seo!
    ///
    /// Féach freisin [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `as_uninit_slice` a sheasamh.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Tuairisceáin tagairt uathúil do slice de luachanna b'fhéidir uninitialized.I gcodarsnacht le [`as_mut`], ní éilíonn sé seo go gcaithfear an luach a thosú.
    ///
    /// Féach [`as_uninit_slice`] don mhacasamhail roinnte.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Agus an modh seo á ghlaoch agat, caithfidh tú a chinntiú go bhfuil gach ceann díobh seo a leanas fíor:
    ///
    /// * Ní mór don pointeoir a [valid] do léann agus scríobhann do bytes `ptr.len() * mem::size_of::<T>()` go leor, agus ní mór é a chur ar chomhréim i gceart.Ciallaíonn sé seo go háirithe:
    ///
    ///     * Ní mór raon cuimhne iomlán an tslis seo a bheith laistigh d`ábhar leithdháilte amháin!
    ///       Ní féidir le Slices span fud na rudaí a leithdháileadh il.
    ///
    ///     * Ní mór an pointeoir a ailíniú fiú le haghaidh slisní faid nialasacha.
    ///     Cúis amháin leis seo ná go bhféadfadh barrfheabhsú leagan amach enum a bheith ag brath ar thagairtí (lena n-áirítear slisní ar aon fhaid) a bheith ailínithe agus neamh-null chun iad a idirdhealú ó shonraí eile.
    ///
    ///     Is féidir leat pointeoir a fháil atá inúsáidte mar `data` le haghaidh slisní faid nialasacha ag úsáid [`NonNull::dangling()`].
    ///
    /// * Ní mór nach mbeidh méid iomlán `ptr.len() * mem::size_of::<T>()` an slice níos mó ná `isize::MAX`.
    ///   Féach ar dhoiciméadú shábháilteacht [`pointer::offset`].
    ///
    /// * Ní mór duit rialacha aliasing Rust fhorfheidhmiú, ós rud é an saolré ar ais é `'a` roghnaithe treallach agus ní gá go léiríonn saolré iarbhír na sonraí.
    ///   Go háirithe, ar feadh ré an tsaoil, an chuimhne na pointí pointeoir go mór gan a bheith rochtain (léamh nó a scríobh) trí aon pointeoir eile.
    ///
    /// Tá feidhm leis seo fiú mura n-úsáidtear toradh an mhodha seo!
    ///
    /// Féach freisin [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Tá sé seo sábháilte mar tá `memory` bailí le haghaidh léamh agus scríobh do `memory.len()` go leor beart.
    /// // Tabhair faoi deara nach gceadaítear glaoch ar `memory.as_mut()` anseo mar d`fhéadfadh an t-ábhar a bheith neamhbheartaithe.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `as_uninit_slice_mut` a sheasamh.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Filltear pointeoir amh ar eilimint nó ar fholús, gan seiceáil faoi theorainneacha.
    ///
    /// Is é *[iompar neamhshainithe]* an modh seo a ghlaoch le hinnéacs lasmuigh de theorainneacha nó nuair nach féidir `self` a dhí-iompar, fiú mura n-úsáidtear an pointeoir mar thoradh air.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SÁBHÁILTEACHT: cinntíonn an té atá ag glaoch go bhfuil `self` dereferencable agus `index` istigh.
        // Mar thoradh air sin, ní féidir an pointeoir a thiocfaidh as a bheith NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SÁBHÁILTEACHT: Ní féidir pointeoir uathúil a chur ar neamhní, mar sin na coinníollacha le haghaidh
        // new_unchecked() bhfuil meas.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SÁBHÁILTEACHT: Ní féidir tagairt mutable a null.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SÁBHÁILTEACHT: Ní féidir tagairt a bheith ar neamhní, mar sin na coinníollacha le haghaidh
        // new_unchecked() bhfuil meas.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}