use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Tuairisceáin `true` má tá an pointeoir null.
    ///
    /// Tabhair faoi deara go bhfuil go leor leideanna neamhní féideartha ag cineálacha neamhshábháilte, toisc nach meastar ach an pointeoir sonraí amh, ní a fhad, a vtable, srl.
    /// Dá bhrí sin, ní fhéadfaidh dhá phointe atá ar neamhní comparáid a dhéanamh lena chéile fós.
    ///
    /// ## Iompar le linn meastóireachta const
    ///
    /// Nuair a úsáidtear an fheidhm seo le linn meastóireachta const, féadfaidh sí `false` a chur ar ais le haghaidh leideanna a bhíonn ar neamhní ag am rith.
    /// Go sonrach, nuair a dhéantar pointeoir le cuimhne éigin a fhritháireamh thar a theorainneacha sa chaoi is go bhfuil an pointeoir mar thoradh air null, fillfidh an fheidhm `false` fós.
    ///
    /// Níl aon bhealach ann go mbeadh a fhios ag CTFE suíomh iomlán na cuimhne sin, mar sin ní féidir linn a rá an bhfuil an pointeoir null nó nach bhfuil.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Déan comparáid idir teilgthe agus pointeoir tanaí, agus mar sin níl leideanna saille ach ag smaoineamh ar a gcuid "data" le haghaidh neamhní.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Casts go pointeoir de chineál eile.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Déan pointeoir (leathan b`fhéidir) a dhianscaoileadh ina chomhpháirteanna seoltaí agus meiteashonraí.
    ///
    /// Is féidir an pointeoir a athchruthú níos déanaí le [`from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Tuairisceáin `None` má tá an pointeoir null, nó tuairisceáin eile is tagairt í roinnte don luach fillte i `Some`.Más féidir leis an luach a uninitialized, ní mór [`as_uninit_ref`] a úsáid in ionad.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Agus an modh seo á ghlaoch agat, ní mór duit a chinntiú go bhfuil *ceachtar* an pointeoir NULL *nó* go bhfuil gach ceann díobh seo a leanas fíor:
    ///
    /// * Caithfear an pointeoir a ailíniú i gceart.
    ///
    /// * Caithfidh sé a bheith "dereferencable" sa chiall a shainmhínítear in [the module documentation].
    ///
    /// * Caithfidh an pointeoir tagairt do shampla tosaigh de `T`.
    ///
    /// * Ní mór duit rialacha aliasing Rust fhorfheidhmiú, ós rud é an saolré ar ais é `'a` roghnaithe treallach agus ní gá go léiríonn saolré iarbhír na sonraí.
    ///   Go háirithe, ar feadh ré an tsaoil seo, ní gá go dtréigfear an chuimhne a ndéanann an pointeoir tagairt dó (ach amháin taobh istigh de `UnsafeCell`).
    ///
    /// Tá feidhm leis seo fiú mura n-úsáidtear toradh an mhodha seo!
    /// (Níl cinneadh iomlán déanta fós ar an gcuid faoi thús a chur leis, ach go dtí go mbeidh, is é an t-aon chur chuige sábháilte ná a chinntiú go ndéantar iad a thionscnamh i ndáiríre.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Leagan neamhsheiceáilte
    ///
    /// Má tá tú cinnte nach féidir an pointeoir a bheith ar neamhní riamh agus má tá tú ag lorg cineál éigin `as_ref_unchecked` a fhilleann an `&T` in ionad `Option<&T>`, bíodh a fhios agat gur féidir leat an pointeoir a chur siar go díreach.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SÁBHÁILTEACHT: an ráthaíocht mór té atá ag glaoch go bhfuil `self` bailí
        // le haghaidh tagartha mura bhfuil sé null.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Tuairisceáin `None` má tá an pointeoir null, nó má chuireann sé tagairt roinnte ar ais don luach atá fillte in `Some`.
    /// I gcodarsnacht le [`as_ref`], ní éilíonn sé seo go gcaithfear an luach a thosú.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Agus an modh seo á ghlaoch agat, ní mór duit a chinntiú go bhfuil *ceachtar* an pointeoir NULL *nó* go bhfuil gach ceann díobh seo a leanas fíor:
    ///
    /// * Caithfear an pointeoir a ailíniú i gceart.
    ///
    /// * Caithfidh sé a bheith "dereferencable" sa chiall a shainmhínítear in [the module documentation].
    ///
    /// * Ní mór duit rialacha aliasing Rust fhorfheidhmiú, ós rud é an saolré ar ais é `'a` roghnaithe treallach agus ní gá go léiríonn saolré iarbhír na sonraí.
    ///
    ///   Go háirithe, ar feadh ré an tsaoil seo, ní gá go dtréigfear an chuimhne a ndéanann an pointeoir tagairt dó (ach amháin taobh istigh de `UnsafeCell`).
    ///
    /// Tá feidhm leis seo fiú mura n-úsáidtear toradh an mhodha seo!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch a ráthú go gcomhlíonann `self` na
        // ceanglais maidir le tagairt.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Ríomhann an fritháireamh ó pointeoir.
    ///
    /// `count` Is in aonaid de T;m.sh., is ionann `count` de 3 agus fritháireamh pointeora de bhearta `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Má sháraítear aon cheann de na coinníollacha seo a leanas, is é an toradh ná Iompar Neamhshainithe:
    ///
    /// * Ní foláir an dá an pointeoir ag tosú agus mar thoradh air bheith i bounds nó beart amháin thar an deireadh an rud céanna a leithdháileadh.
    /// Tabhair faoi deara, i Rust, go meastar gur réad leithdháilte ar leithligh é gach athróg (stack-allocated).
    ///
    /// * Ní féidir leis an bhfritháireamh ríofa,**i mbearta**, `isize` a chur thar maoil.
    ///
    /// * Ní féidir leis an bhfritháireamh atá faoi theorainneacha brath ar "wrapping around" an spás seoltaí.Is é sin, an tsuim gan teorainn-cruinneas,**i mbearta, ní mór** oiriúnach i usize.
    ///
    /// De ghnáth déanann an tiomsaitheoir agus an leabharlann chaighdeánach iarracht a chinntiú nach sroicheann leithdháiltí méid riamh ina bhfuil fritháireamh ina ábhar imní.
    /// Mar shampla, cinntíonn `Vec` agus `Box` nach leithdháileann siad riamh níos mó ná bearta `isize::MAX`, mar sin tá `vec.as_ptr().add(vec.len())` sábháilte i gcónaí.
    ///
    /// Go bunúsach ní féidir le mórchuid na n-ardán leithdháileadh den sórt sin a thógáil.
    /// Mar shampla, ní féidir le haon ardán 64-giotán ar a dtugtar iarratas ar 2 <sup>63</sup> beart a sheirbheáil riamh mar gheall ar theorainneacha tábla leathanaigh nó scoilt an spáis seoltaí.
    /// Mar sin féin, d`fhéadfadh roinnt ardáin 32-giotán agus 16-giotán iarraidh go rathúil ar níos mó ná bearta `isize::MAX` le rudaí cosúil le Síneadh Seoladh Fisiciúil.
    ///
    /// Dá réir sin, cuimhne arna sealbhú go díreach ó allocators nó comhaid cuimhne mapáilte fhéadfadh *a* ró-mhór a láimhseáil leis an bhfeidhm seo.
    ///
    /// Smaoinigh ar [`wrapping_offset`] a úsáid ina ionad má tá sé deacair na srianta seo a shásamh.
    /// Is é an t-aon bhuntáiste a bhaineann leis an modh seo ná go gcumasaíonn sé barrfheabhsú tiomsaitheora níos ionsaithí.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `offset` a sheasamh.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Ríomhtar an fritháireamh ó phointeoir ag úsáid uimhríocht timfhilleadh.
    ///
    /// `count` Is in aonaid de T;m.sh., is ionann `count` de 3 agus fritháireamh pointeora de bhearta `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Tá an oibríocht seo féin sábháilte i gcónaí, ach níl an pointeoir mar thoradh air.
    ///
    /// Tá an pointeoir mar thoradh air seo ceangailte leis an réad leithdháilte céanna a ndíríonn `self` air.
    /// Ní féidir *ní féidir* é a úsáid chun rochtain a fháil ar réad leithdháilte difriúil.Tabhair faoi deara, i Rust, go meastar gur réad leithdháilte ar leithligh é gach athróg (stack-allocated).
    ///
    /// Is é sin le rá, ní dhéanann `let z = x.wrapping_offset((y as isize) - (x as isize))` * `z` mar an gcéanna le `y` fiú má ghlacaimid leis go bhfuil méid `1` ag `T` agus nach bhfuil aon ró-shreabhadh ann: tá `z` fós ceangailte leis an réad `x` ceangailte leis, agus má dhéantar é a dhíchomhdháil tá sé ina Iompar Neamhshainithe mura `x` agus Pointe `y` isteach sa réad leithdháilte céanna.
    ///
    /// I gcomparáid le [`offset`], cuireann an modh seo moill go bunúsach ar an gceanglas fanacht laistigh den réad leithdháilte céanna: Is Iompar Neamhshainithe láithreach é [`offset`] agus teorainneacha réad á thrasnú;Táirgeann `wrapping_offset` pointeoir ach fós mar thoradh chuig Neamhshainithe Iompar má tá pointeoir dereferenced nuair a bheidh sé as-de-bounds an ruda tá sé ag gabháil leis.
    /// [`offset`] is féidir é a bharrfheabhsú níos fearr agus dá bhrí sin is fearr é i gcód atá íogair ó thaobh feidhmíochta.
    ///
    /// Ní mheasann an seiceáil mhoillithe ach luach an phointeora a bhí díthreoraithe, ní na luachanna idirmheánacha a úsáideadh le linn ríomh an toraidh dheiridh.
    /// Mar shampla, tá `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` mar an gcéanna le `x` i gcónaí.Is é sin le rá, ceadaítear an réad leithdháilte a fhágáil agus ansin é a athiontráil níos déanaí.
    ///
    /// Más gá duit teorainneacha réada a thrasnú, caith an pointeoir chuig slánuimhir agus déan an uimhríocht ansin.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// // Iterate ag baint úsáide as pointeoir amh in incrimintí de dhá ghné
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Priontaíonn an lúb seo "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SÁBHÁILTEACHT: níl aon réamhriachtanais ag an intreach `arith_offset`.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Ríomhtar an fad idir dhá threo.Tá an luach ar ais in aonaid T: roinntear an fad i mbearta le `mem::size_of::<T>()`.
    ///
    /// Is é an fheidhm seo inbhéartach [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Má sháraítear aon cheann de na coinníollacha seo a leanas, is é an toradh ná Iompar Neamhshainithe:
    ///
    /// * Caithfidh an pointeoir tosaigh agus an pointeoir eile a bheith faoi theorainneacha nó beart amháin tar éis dheireadh an ruda leithdháilte céanna.
    /// Tabhair faoi deara, i Rust, go meastar gur réad leithdháilte ar leithligh é gach athróg (stack-allocated).
    ///
    /// * Ní mór an dá threo a dhíorthú *ó* pointeoir chuig an réad céanna.
    ///   (Féach thíos sampla.)
    ///
    /// * Caithfidh an fad idir na leideanna, i mbearta, a bheith ina iolraí cruinn de mhéid `T`.
    ///
    /// * Ní féidir leis an bhfad idir na leideanna,**i mbearta**, `isize` a chur thar maoil.
    ///
    /// * Ní féidir an fad atá faoi theorainneacha a bheith ag brath ar "wrapping around" an spás seoltaí.
    ///
    /// Ní bhíonn cineálacha Rust riamh níos mó ná leithdháiltí `isize::MAX` agus Rust riamh timpeall an spáis seoltaí, mar sin sásóidh dhá threo laistigh de luach éigin d`aon chineál Rust `T` an dá choinníoll dheireanacha i gcónaí.
    ///
    /// Cinntíonn an leabharlann chaighdeánach go ginearálta nach sroicheann leithdháiltí méid riamh ina bhfuil fritháireamh ina ábhar imní.
    /// Mar shampla, cinntíonn `Vec` agus `Box` nach leithdháileann siad riamh níos mó ná bearta `isize::MAX`, mar sin sásaíonn `ptr_into_vec.offset_from(vec.as_ptr())` an dá choinníoll dheireanacha i gcónaí.
    ///
    /// Ní féidir an chuid is mó ardáin thógáil bunúsach fiú a leithéid de leithdháileadh mór.
    /// Mar shampla, ní féidir le haon ardán 64-giotán ar a dtugtar iarratas ar 2 <sup>63</sup> beart a sheirbheáil riamh mar gheall ar theorainneacha tábla leathanaigh nó scoilt an spáis seoltaí.
    /// Mar sin féin, d`fhéadfadh roinnt ardáin 32-giotán agus 16-giotán iarraidh go rathúil ar níos mó ná bearta `isize::MAX` le rudaí cosúil le Síneadh Seoladh Fisiciúil.
    /// Dá réir sin, cuimhne arna sealbhú go díreach ó allocators nó comhaid cuimhne mapáilte fhéadfadh *a* ró-mhór a láimhseáil leis an bhfeidhm seo.
    /// (Tabhair faoi deara go bhfuil teorannú comhchosúil ag [`offset`] agus [`add`] freisin agus dá bhrí sin ní féidir iad a úsáid ar leithdháiltí chomh mór sin ach an oiread.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Feidhm panics más Cineál nialais ("ZST") é `T`.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// Úsáid *mícheart*:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Déan ptr2_other an "alias" de ptr2, ach a dhíorthaítear ó ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Ós rud é go ndíorthaítear ptr2_other agus ptr2 ó leideanna chuig rudaí difriúla, is iompar neamhshainithe é a bhfritháireamh a ríomh, cé go dtugann siad aird ar an seoladh céanna!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Iompar Neamhshainithe
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `ptr_offset_from` a sheasamh.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Tuairisceáin an ráthaítear go mbeidh dhá threo cothrom.
    ///
    /// Ag am rith féin iompraíonn an fheidhm seo cosúil le `self == other`.
    /// Mar sin féin, i roinnt comhthéacsanna (m.sh., meastóireacht ar am tiomsaithe), ní féidir i gcónaí comhionannas dhá phointe a chinneadh, mar sin d`fhéadfadh an fheidhm seo `false` a thabhairt ar ais go sporúil le haghaidh leideanna a thiocfaidh chun bheith comhionann ina dhiaidh sin.
    ///
    /// Ach nuair a fhilleann sé `true`, ráthaítear go mbeidh na leideanna cothrom.
    ///
    /// Is é an fheidhm an scáthán ar [`guaranteed_ne`], ach ní ar a inbhéarta.Tá comparáidí pointeoir a bhfuil an dá fheidhm ar ais chuig `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Féadfaidh an luach toraidh athrú ag brath ar an leagan tiomsaitheora agus b`fhéidir nach mbeidh an cód neamhshábháilte ag brath ar thoradh na feidhme seo ar mhaithe le fóntacht.
    /// Moltar an fheidhm seo a úsáid le haghaidh barrfheabhsú feidhmíochta i gcás nach ndéanann luachanna aisfhillteacha `false` ón bhfeidhm seo difear don toradh, ach don fheidhmíocht amháin.
    /// Ní dhearnadh iniúchadh ar iarmhairtí an mhodha seo chun iompar runtime agus cód ama tiomsaithe a iompar ar bhealach difriúil.
    /// Níor cheart an modh seo a úsáid chun difríochtaí den sórt sin a thabhairt isteach, agus níor cheart é a chobhsú freisin sula mbeidh tuiscint níos fearr againn ar an gceist seo.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Filleann sé ar cibé an ráthaítear go mbeidh dhá threo neamhchothrom.
    ///
    /// Ag runtime seo behaves feidhm cosúil `self != other`.
    /// Mar sin féin, i roinnt comhthéacsanna (m.sh., meastóireacht ar am tiomsaithe), ní féidir i gcónaí neamhionannas dhá threo a chinneadh, mar sin d`fhéadfadh an fheidhm seo `false` a thabhairt ar ais go spleodrach le haghaidh leideanna a éiríonn níos neamhchothrom ina dhiaidh sin.
    ///
    /// Ach nuair a fhilleann sé `true`, tá na leideanna ráthaithe a bheith neamhionann.
    ///
    /// Is é an fheidhm seo scáthán [`guaranteed_eq`], ach ní inbhéartach í.Tá comparáidí pointeora ann a dtugann an dá fheidhm `false` ar ais ina leith.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Féadfaidh an luach toraidh athrú ag brath ar an leagan tiomsaitheora agus b`fhéidir nach mbeidh an cód neamhshábháilte ag brath ar thoradh na feidhme seo ar mhaithe le fóntacht.
    /// Moltar an fheidhm seo a úsáid le haghaidh barrfheabhsú feidhmíochta i gcás nach ndéanann luachanna aisfhillteacha `false` ón bhfeidhm seo difear don toradh, ach don fheidhmíocht amháin.
    /// Ní dhearnadh iniúchadh ar iarmhairtí an mhodha seo chun iompar runtime agus cód ama tiomsaithe a iompar ar bhealach difriúil.
    /// Níor cheart an modh seo a úsáid chun difríochtaí den sórt sin a thabhairt isteach, agus níor cheart é a chobhsú freisin sula mbeidh tuiscint níos fearr againn ar an gceist seo.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Ríomhann an fritháireamh ó pointeoir (áisiúlacht do `.offset(count as isize)`).
    ///
    /// `count` Is in aonaid de T;m.sh., is ionann `count` de 3 agus fritháireamh pointeora de bhearta `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Má sháraítear aon cheann de na coinníollacha seo a leanas, is é an toradh ná Iompar Neamhshainithe:
    ///
    /// * Ní foláir an dá an pointeoir ag tosú agus mar thoradh air bheith i bounds nó beart amháin thar an deireadh an rud céanna a leithdháileadh.
    /// Tabhair faoi deara, i Rust, go meastar gur réad leithdháilte ar leithligh é gach athróg (stack-allocated).
    ///
    /// * Ní féidir leis an bhfritháireamh ríofa,**i mbearta**, `isize` a chur thar maoil.
    ///
    /// * Ní féidir leis an bhfritháireamh atá faoi theorainneacha brath ar "wrapping around" an spás seoltaí.Is é sin, caithfidh an tsuim beachtais gan teorainn a bheith oiriúnach i `usize`.
    ///
    /// De ghnáth déanann an tiomsaitheoir agus an leabharlann chaighdeánach iarracht a chinntiú nach sroicheann leithdháiltí méid riamh ina bhfuil fritháireamh ina ábhar imní.
    /// Mar shampla, cinntíonn `Vec` agus `Box` nach leithdháileann siad riamh níos mó ná bearta `isize::MAX`, mar sin tá `vec.as_ptr().add(vec.len())` sábháilte i gcónaí.
    ///
    /// Go bunúsach ní féidir le mórchuid na n-ardán leithdháileadh den sórt sin a thógáil.
    /// Mar shampla, ní féidir le haon ardán 64-giotán ar a dtugtar iarratas ar 2 <sup>63</sup> beart a sheirbheáil riamh mar gheall ar theorainneacha tábla leathanaigh nó scoilt an spáis seoltaí.
    /// Mar sin féin, d`fhéadfadh roinnt ardáin 32-giotán agus 16-giotán iarraidh go rathúil ar níos mó ná bearta `isize::MAX` le rudaí cosúil le Síneadh Seoladh Fisiciúil.
    ///
    /// Dá réir sin, cuimhne arna sealbhú go díreach ó allocators nó comhaid cuimhne mapáilte fhéadfadh *a* ró-mhór a láimhseáil leis an bhfeidhm seo.
    ///
    /// Smaoinigh ar [`wrapping_add`] a úsáid ina ionad má tá sé deacair na srianta seo a shásamh.
    /// Is é an t-aon bhuntáiste a bhaineann leis an modh seo ná go gcumasaíonn sé barrfheabhsú tiomsaitheora níos ionsaithí.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `offset` a sheasamh.
        unsafe { self.offset(count as isize) }
    }

    /// Ríomhtar an fritháireamh ó phointeoir (áisiúlacht do `.offset ((comhaireamh mar isize).wrapping_neg())`).)
    ///
    /// `count` Is in aonaid de T;m.sh., is ionann `count` de 3 agus fritháireamh pointeora de bhearta `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Má sháraítear aon cheann de na coinníollacha seo a leanas, is é an toradh ná Iompar Neamhshainithe:
    ///
    /// * Ní foláir an dá an pointeoir ag tosú agus mar thoradh air bheith i bounds nó beart amháin thar an deireadh an rud céanna a leithdháileadh.
    /// Tabhair faoi deara, i Rust, go meastar gur réad leithdháilte ar leithligh é gach athróg (stack-allocated).
    ///
    /// * Ní féidir leis an bhfritháireamh ríofa dul thar `isize::MAX`**beart**.
    ///
    /// * Ní féidir leis an bhfritháireamh atá faoi theorainneacha brath ar "wrapping around" an spás seoltaí.Is é sin, caithfidh an tsuim beachtais gan teorainn a bheith oiriúnach i ngnáthúsáid.
    ///
    /// De ghnáth déanann an tiomsaitheoir agus an leabharlann chaighdeánach iarracht a chinntiú nach sroicheann leithdháiltí méid riamh ina bhfuil fritháireamh ina ábhar imní.
    /// Mar shampla, cinntíonn `Vec` agus `Box` nach leithdháileann siad riamh níos mó ná bearta `isize::MAX`, mar sin tá `vec.as_ptr().add(vec.len()).sub(vec.len())` sábháilte i gcónaí.
    ///
    /// Go bunúsach ní féidir le mórchuid na n-ardán leithdháileadh den sórt sin a thógáil.
    /// Mar shampla, ní féidir le haon ardán 64-giotán ar a dtugtar iarratas ar 2 <sup>63</sup> beart a sheirbheáil riamh mar gheall ar theorainneacha tábla leathanaigh nó scoilt an spáis seoltaí.
    /// Mar sin féin, d`fhéadfadh roinnt ardáin 32-giotán agus 16-giotán iarraidh go rathúil ar níos mó ná bearta `isize::MAX` le rudaí cosúil le Síneadh Seoladh Fisiciúil.
    ///
    /// Dá réir sin, cuimhne arna sealbhú go díreach ó allocators nó comhaid cuimhne mapáilte fhéadfadh *a* ró-mhór a láimhseáil leis an bhfeidhm seo.
    ///
    /// Smaoinigh ar [`wrapping_sub`] a úsáid ina ionad má tá sé deacair na srianta seo a shásamh.
    /// Is é an t-aon bhuntáiste a bhaineann leis an modh seo ná go gcumasaíonn sé barrfheabhsú tiomsaitheora níos ionsaithí.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `offset` a sheasamh.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Ríomhtar an fritháireamh ó phointeoir ag úsáid uimhríocht timfhilleadh.
    /// (Áisiúlacht do `.wrapping_offset(count as isize)`)
    ///
    /// `count` Is in aonaid de T;m.sh., is ionann `count` de 3 agus fritháireamh pointeora de bhearta `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Tá an oibríocht seo féin sábháilte i gcónaí, ach níl an pointeoir mar thoradh air.
    ///
    /// Tá an pointeoir mar thoradh air seo ceangailte leis an réad leithdháilte céanna a ndíríonn `self` air.
    /// Ní féidir *ní féidir* é a úsáid chun rochtain a fháil ar réad leithdháilte difriúil.Tabhair faoi deara, i Rust, go meastar gur réad leithdháilte ar leithligh é gach athróg (stack-allocated).
    ///
    /// Is é sin le rá, ní dhéanann `let z = x.wrapping_add((y as usize) - (x as usize))` * `z` mar an gcéanna le `y` fiú má ghlacaimid leis go bhfuil méid `1` ag `T` agus nach bhfuil aon ró-shreabhadh ann: tá `z` fós ceangailte leis an réad `x` ceangailte leis, agus má dhéantar é a dhíchomhdháil tá sé ina Iompar Neamhshainithe mura `x` agus Pointe `y` isteach sa réad leithdháilte céanna.
    ///
    /// I gcomparáid le [`add`], cuireann an modh seo moill go bunúsach ar an gceanglas fanacht laistigh den réad leithdháilte céanna: Is Iompar Neamhshainithe láithreach é [`add`] agus teorainneacha réad á thrasnú;Táirgeann `wrapping_add` pointeoir ach bíonn Iompar Neamhshainithe mar thoradh air fós má dhéantar pointeoir a dhífhabhtú nuair a bhíonn sé lasmuigh den teorainn a bhfuil sé ceangailte leis.
    /// [`add`] is féidir é a bharrfheabhsú níos fearr agus dá bhrí sin is fearr é i gcód atá íogair ó thaobh feidhmíochta.
    ///
    /// Ní mheasann an seiceáil mhoillithe ach luach an phointeora a bhí díthreoraithe, ní na luachanna idirmheánacha a úsáideadh le linn ríomh an toraidh dheiridh.
    /// Mar shampla, tá `x.wrapping_add(o).wrapping_sub(o)` mar an gcéanna le `x` i gcónaí.Is é sin le rá, ceadaítear an réad leithdháilte a fhágáil agus ansin é a athiontráil níos déanaí.
    ///
    /// Más gá duit teorainneacha réada a thrasnú, caith an pointeoir chuig slánuimhir agus déan an uimhríocht ansin.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// // Iterate ag baint úsáide as pointeoir amh in incrimintí de dhá ghné
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Priontaíonn an lúb seo "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Ríomhtar an fritháireamh ó phointeoir ag úsáid uimhríocht timfhilleadh.
    /// (áisiúlacht do `.wrapping_offset ((comhaireamh mar isize).wrapping_neg())`).)
    ///
    /// `count` Is in aonaid de T;m.sh., is ionann `count` de 3 agus fritháireamh pointeora de bhearta `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Tá an oibríocht seo féin sábháilte i gcónaí, ach níl an pointeoir mar thoradh air.
    ///
    /// Tá an pointeoir mar thoradh air seo ceangailte leis an réad leithdháilte céanna a ndíríonn `self` air.
    /// Ní féidir *ní féidir* é a úsáid chun rochtain a fháil ar réad leithdháilte difriúil.Tabhair faoi deara, i Rust, go meastar gur réad leithdháilte ar leithligh é gach athróg (stack-allocated).
    ///
    /// I bhfocail eile, ní `let z = x.wrapping_sub((x as usize) - (y as usize))` * bhfuil a dhéanamh `z` mar `y` an gcéanna fiú má glacadh againn go bhfuil `T` Méid `1` agus níl aon thar maoil: `z` é ceangailte go fóill ar an réad `x` ag gabháil leis, agus dereferencing is Iompar Neamhshainithe mura `x` agus pointe `y` isteach sa rud céanna a leithdháileadh.
    ///
    /// I gcomparáid le [`sub`], cuireann an modh seo moill go bunúsach ar an gceanglas fanacht laistigh den réad leithdháilte céanna: Is Iompar Neamhshainithe láithreach é [`sub`] agus teorainneacha réad á thrasnú;Táirgeann `wrapping_sub` pointeoir ach bíonn Iompar Neamhshainithe mar thoradh air fós má dhéantar pointeoir a dhífhabhtú nuair a bhíonn sé lasmuigh den teorainn a bhfuil sé ceangailte leis.
    /// [`sub`] is féidir é a bharrfheabhsú níos fearr agus dá bhrí sin is fearr é i gcód atá íogair ó thaobh feidhmíochta.
    ///
    /// Ní mheasann an seiceáil mhoillithe ach luach an phointeora a bhí díthreoraithe, ní na luachanna idirmheánacha a úsáideadh le linn ríomh an toraidh dheiridh.
    /// Mar shampla, tá `x.wrapping_add(o).wrapping_sub(o)` mar an gcéanna le `x` i gcónaí.Is é sin le rá, ceadaítear an réad leithdháilte a fhágáil agus ansin é a athiontráil níos déanaí.
    ///
    /// Más gá duit teorainneacha réada a thrasnú, caith an pointeoir chuig slánuimhir agus déan an uimhríocht ansin.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// // Iterate ag baint úsáide as pointeoir amh in incrimintí de dhá ghné (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Priontaíonn an lúb seo "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Socraíonn sé luach an phointeora go `ptr`.
    ///
    /// Sa chás go bhfuil `self` pointeoir (fat) le cineál unsized, beidh an oibríocht i bhfeidhm ach amháin an chuid pointeoir, ach do leideanna (thin) do chineálacha meánmhéide, tá an éifeacht chéanna mar sannadh simplí.
    ///
    /// Beidh bunús `val` ag an bpointeoir a bheidh mar thoradh air, ie, maidir le pointeoir saille, tá an oibríocht seo mar an gcéanna ó thaobh seimeastar le pointeoir saille nua a chruthú le luach pointeoir sonraí `val` ach meiteashonraí `self`.
    ///
    ///
    /// # Examples
    ///
    /// Tá an fheidhm seo úsáideach go príomha chun uimhríocht pointeoir ciallmhar a cheadú ar leideanna a d`fhéadfadh a bheith saille:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // priontálfaidh "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // SÁBHÁILTEACHT: I gcás pointeoir tanaí, tá na hoibríochtaí seo comhionann
        // le sannadh simplí.
        // I gcás pointeoir saille, le cur chun feidhme atá ann faoi láthair leagan pointeoir saill, is é an chéad réimse an pointeoir sórt sin i gcónaí ar an pointeoir sonraí, atá sannta mar an gcéanna.
        //
        unsafe { *thin = val };
        self
    }

    /// Léann an luach ó `self` gan gluaiseacht a dhéanamh air.
    /// Fágann sé sin nach bhfuil aon athrú ar an gcuimhne i `self`.
    ///
    /// Féach [`ptr::read`] le haghaidh imní agus samplaí sábháilteachta.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `read` a sheasamh.
        unsafe { read(self) }
    }

    /// Déanann sé léamh luaineach ar an luach ó `self` gan é a bhogadh.Fágann sé sin nach bhfuil aon athrú ar an gcuimhne i `self`.
    ///
    /// Tá sé i gceist go ngníomhóidh oibríochtaí luaineachta ar chuimhne I/O, agus ráthaítear nach gcuirfidh an tiomsaitheoir as dóibh nó go n-athainmneoidh siad iad thar oibríochtaí so-ghalaithe eile.
    ///
    ///
    /// Féach [`ptr::read_volatile`] le haghaidh imní agus samplaí sábháilteachta.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `read_volatile` a sheasamh.
        unsafe { read_volatile(self) }
    }

    /// Léann an luach ó `self` gan gluaiseacht a dhéanamh air.
    /// Fágann sé sin nach bhfuil aon athrú ar an gcuimhne i `self`.
    ///
    /// Murab ionann agus `read`, is féidir leis an pointeoir a unaligned.
    ///
    /// Féach [`ptr::read_unaligned`] le haghaidh imní agus samplaí sábháilteachta.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `read_unaligned` a sheasamh.
        unsafe { read_unaligned(self) }
    }

    /// Cóipeanna de bhearta `count * size_of<T>` ó `self` go `dest`.
    /// Féadfaidh an foinse agus an ceann scríbe forluí.
    ///
    /// NOTE: tá an t-ordú argóinte *céanna* aige seo le [`ptr::copy`].
    ///
    /// Féach [`ptr::copy`] le haghaidh imní agus samplaí sábháilteachta.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `copy` a sheasamh.
        unsafe { copy(self, dest, count) }
    }

    /// Cóipeanna de bhearta `count * size_of<T>` ó `self` go `dest`.
    /// Ní fhéadfaidh an foinse agus an ceann scríbe forluí *.
    ///
    /// NOTE: Tá sé seo an t-ordú argóint *céanna* mar [`ptr::copy_nonoverlapping`].
    ///
    /// Féach [`ptr::copy_nonoverlapping`] le haghaidh imní agus samplaí sábháilteachta.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `copy_nonoverlapping` a sheasamh.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Déanann sé an fritháireamh a chaithfear a chur i bhfeidhm ar an pointeoir chun é a ailíniú le `align`.
    ///
    /// Más rud é nach féidir a chur ar chomhréim leis an pointeoir, tuairisceáin le cur chun feidhme `usize::MAX`.
    /// Tá sé ceadaithe don chur i bhfeidhm * `usize::MAX` a thabhairt ar ais i gcónaí.
    /// Ní féidir ach feidhmíocht d`algartam a bheith ag brath ar fhritháireamh inúsáidte a fháil anseo, ní ar a chruinneas.
    ///
    /// An fhritháireamh léirítear i líon na n-eilimintí `T`, agus ní bytes.Is féidir an luach a chuirtear ar ais a úsáid leis an modh `wrapping_add`.
    ///
    /// Níl aon ráthaíochtaí ar bith ann nach sáróidh an pointeoir a fhritháireamh nó nach rachaidh sé thar an leithdháileadh a ndéanann an pointeoir tagairt dó.
    ///
    /// Is faoin té atá ag glaoch a chinntiú go bhfuil an fritháireamh ar ais ceart i ngach téarma seachas ailíniú.
    ///
    /// # Panics
    ///
    /// An fheidhm panics mura cumhacht de dhá cheann é `align`.
    ///
    /// # Examples
    ///
    /// Rochtain ar `u8` in aice láimhe mar `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // cé gur féidir an pointeoir a ailíniú trí `offset`, bheadh sé lasmuigh den leithdháileadh
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SÁBHÁILTEACHT: `align` seiceáilte a bheith ina cumhacht 2 thuas
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Filleann sé ar ais slice amh.
    ///
    /// Is é an luach a chuirtear ar ais ná líon na n-eilimintí **, ní líon na mbeart.
    ///
    /// Tá an fheidhm seo sábháilte, fiú nuair nach féidir an slice amh a chaitheamh le tagairt slice toisc go bhfuil an pointeoir null nó neamhshainithe.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SÁBHÁILTEACHT: tá sé seo sábháilte toisc go bhfuil an leagan amach céanna ag `*const [T]` agus `FatPtr<T>`.
            // Ní féidir ach le `std` an ráthaíocht seo a dhéanamh.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Tugann pointeoir amh ar ais do mhaolán an tslis.
    ///
    /// Is ionann é seo agus `self` a chaitheamh go `*const T`, ach níos sábháilte ó thaobh cineáil de.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Filltear pointeoir amh ar eilimint nó ar fholús, gan seiceáil faoi theorainneacha.
    ///
    /// Is é *[iompar neamhshainithe]* an modh seo a ghlaoch le hinnéacs lasmuigh de theorainneacha nó nuair nach féidir `self` a dhí-iompar, fiú mura n-úsáidtear an pointeoir mar thoradh air.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SÁBHÁILTEACHT: cinntíonn an té atá ag glaoch go bhfuil `self` dereferencable agus `index` istigh.
        unsafe { index.get_unchecked(self) }
    }

    /// Tuairisceáin `None` má tá an pointeoir null, nó má fhilleann sé slice roinnte ar an luach atá fillte i `Some`.
    /// I gcodarsnacht le [`as_ref`], ní éilíonn sé seo go gcaithfear an luach a thosú.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Agus an modh seo á ghlaoch agat, ní mór duit a chinntiú go bhfuil *ceachtar* an pointeoir NULL *nó* go bhfuil gach ceann díobh seo a leanas fíor:
    ///
    /// * Ní mór don pointeoir a [valid] do léann do bytes `ptr.len() * mem::size_of::<T>()` go leor, agus ní mór é a chur ar chomhréim i gceart.Ciallaíonn sé seo go háirithe:
    ///
    ///     * Ní mór raon cuimhne iomlán an tslis seo a bheith laistigh d`ábhar leithdháilte amháin!
    ///       Ní féidir le Slices span fud na rudaí a leithdháileadh il.
    ///
    ///     * Ní mór an pointeoir a ailíniú fiú le haghaidh slisní faid nialasacha.
    ///     Cúis amháin leis seo ná go bhféadfadh barrfheabhsú leagan amach enum a bheith ag brath ar thagairtí (lena n-áirítear slisní ar aon fhaid) a bheith ailínithe agus neamh-null chun iad a idirdhealú ó shonraí eile.
    ///
    ///     Is féidir leat pointeoir a fháil atá inúsáidte mar `data` le haghaidh slisní faid nialasacha ag úsáid [`NonNull::dangling()`].
    ///
    /// * Ní mór nach mbeidh méid iomlán `ptr.len() * mem::size_of::<T>()` an slice níos mó ná `isize::MAX`.
    ///   Féach ar dhoiciméadú shábháilteacht [`pointer::offset`].
    ///
    /// * Ní mór duit rialacha aliasing Rust fhorfheidhmiú, ós rud é an saolré ar ais é `'a` roghnaithe treallach agus ní gá go léiríonn saolré iarbhír na sonraí.
    ///   Go háirithe, ar feadh ré an tsaoil seo, ní gá go dtréigfear an chuimhne a ndéanann an pointeoir tagairt dó (ach amháin taobh istigh de `UnsafeCell`).
    ///
    /// Tá feidhm leis seo fiú mura n-úsáidtear toradh an mhodha seo!
    ///
    /// Féach freisin [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `as_uninit_slice` a sheasamh.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Comhionannas le haghaidh leideanna
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Comparáid le haghaidh leideanna
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}