//! Láimh a bhainistiú cuimhne trí leideanna amh.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Glacann go leor feidhmeanna sa mhodúl seo leideanna amha mar argóintí agus léann siad uathu nó scríobhann siad chucu.Ionas go mbeidh sé seo sábháilte, caithfidh na leideanna seo a bheith *bailí*.
//! Braitheann cibé an bhfuil pointeoir bailí ar an oibríocht a úsáidtear dó (léigh nó scríobh), agus méid na cuimhne a ndéantar rochtain uirthi (ie, cé mhéad beart atá read/written).
//! Baineann an chuid is mó de na feidhmeanna úsáid as `*mut T` agus `* const T` chun rochtain a fháil ar luach amháin, agus sa chás sin fágann an doiciméadacht an méid ar lár agus glactar leis go hintuigthe gur bearta `size_of::<T>()` é.
//!
//! Ní chinntear na rialacha beachta maidir le bailíocht go fóill.Tá na ráthaíochtaí a chuirtear ar fáil ag an bpointe seo an-bheag:
//!
//! * Níl pointeoir [null] bailí *riamh*, ní fiú le haghaidh rochtana ar [size zero][zst].
//! * Le go mbeidh pointeoir bailí, is gá, ach ní leor i gcónaí é, go mbeadh an pointeoir *dereferenceable*: caithfidh raon cuimhne an mhéid áirithe a thosaíonn ag an bpointeoir a bheith laistigh de theorainneacha aon réad leithdháilte amháin.
//!
//! Tabhair faoi deara, i Rust, go meastar gur réad leithdháilte ar leithligh é gach athróg (stack-allocated).
//! * Fiú amháin maidir le hoibríochtaí [size zero][zst], níor cheart go mbeadh an pointeoir dírithe ar chuimhne intuigthe, ie, déanann tuiscintocation leideanna a bheith neamhbhailí fiú le haghaidh oibríochtaí meánmhéide.
//! Mar sin féin, má dhéantar aon slánuimhir *liteartha* neamh-nialasach a dhíriú ar phointeoir bailí le haghaidh rochtana ar mhéid nialas, fiú má tharlaíonn cuimhne éigin a bheith ann ag an seoladh sin agus má dhéantar é a thuiscint.
//! Freagraíonn sé seo do leithdháilteoir féin a scríobh: níl sé an-deacair earraí de mhéid nialas a leithdháileadh.
//! Is é [`NonNull::dangling`] an bealach canónach chun pointeoir a fháil atá bailí le haghaidh rochtana meánmhéide.
//! * Tá gach rochtana a dhéanann feidhmeanna sa mhodúl seo * * neamh-adamhach de réir bhrí [atomic operations] úsáidtear chun sioncrónú idir snáitheanna.
//! Ciallaíonn sé seo gur iompar neamhshainithe é dhá rochtain chomhthráthacha a dhéanamh ar an áit chéanna ó snáitheanna éagsúla mura léann an dá rochtain ach ó chuimhne.
//! Tabhair faoi deara go bhfuil [`read_volatile`] agus [`write_volatile`] san áireamh go sainráite: Ní féidir rochtana luaineacha a úsáid le haghaidh sioncrónaithe idir snáithe.
//! * Tá an toradh ar thagairt do phointeoir a chaitheamh bailí fad is atá an réad bunúsach beo agus nach n-úsáidtear aon tagairt (ach leideanna amha) chun an chuimhne chéanna a rochtain.
//!
//! Is leor na haimsimí seo, mar aon le húsáid chúramach a dhéanamh ar [`offset`] le haghaidh uimhríocht pointeora, chun go leor rudaí úsáideacha a chur i bhfeidhm i gceart i gcód neamhshábháilte.
//! Soláthrófar ráthaíochtaí níos láidre sa deireadh, de réir mar a bheidh rialacha [aliasing] á gcinneadh.
//! Le haghaidh tuilleadh eolais a fháil, féach ar an [book] chomh maith leis an t-alt sa tagairt a bheidh dírithe ar [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Ní gá go ndéantar leideanna bailí amh mar a shainmhínítear thuas a ailíniú i gceart (i gcás go sainmhínítear ailíniú "proper" de réir an chineáil pointe, ie, caithfear `*const T` a ailíniú le `mem::align_of::<T>()`).
//! Éilíonn mórchuid na bhfeidhmeanna, áfach, go ndéantar a gcuid argóintí a ailíniú i gceart, agus luafaidh siad an riachtanas seo go sainráite ina ndoiciméadacht.
//! Is iad na heisceachtaí suntasacha leis seo ná [`read_unaligned`] agus [`write_unaligned`].
//!
//! Nuair a bhíonn ailíniú ceart ag teastáil ó fheidhm, déanann sí amhlaidh fiú má tá méid 0 ag an rochtain, ie, fiú mura ndéantar teagmháil le cuimhne i ndáiríre.Smaoinigh ar [`NonNull::dangling`] a úsáid i gcásanna den sórt sin.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Fhorghníomhú an destructor (más ann) den Léirigh-go luach.
///
/// Tá sé seo coibhéiseach go séimeantach le [`ptr::read`] a ghlaoch agus an toradh a scriosadh, ach tá na buntáistí seo a leanas aige:
///
/// * Ceanglaítear * ar `drop_in_place` a úsáid chun cineálacha neamhshonraithe cosúil le rudaí trait a ligean anuas, toisc nach féidir iad a léamh amach ar an gcruach agus iad a thit de ghnáth.
///
/// * Tá sé cairdiúla don optimizer a dhéanamh níos mó ná [`ptr::read`] nuair dropping Cuimhne láimh leithdháilte (eg, i implementations de `Box`/`Rc`/`Vec`), mar nach bhfuil an tiomsaitheoir gá a chruthú go bhfuil sé ar fuaime a elide an chóip.
///
///
/// * Is féidir iad a úsáid chun sonraí [pinned] a scaoileadh nuair nach `repr(packed)` é `T` (ní gá sonraí pinnáilte a bhogadh sula dtitfear iad).
///
/// Ní féidir na luachanna unaligned a thit ar bun, ní mór iad a chóipeáil isteach ar suíomh ailínithe ar dtús ag baint úsáide as [`ptr::read_unaligned`].Maidir le struchtúir phacáilte, déanann an tiomsaitheoir an t-aistriú seo go huathoibríoch.
/// Ciallaíonn sé seo nach scaoiltear réimsí na struchtúr pacáilte i bhfeidhm.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Tá Oibriú undefined más ann de na coinníollacha seo a leanas atáid:
///
/// * `to_drop` caithfidh [valid] a bheith ann le haghaidh léamh agus scríobh.
///
/// * `to_drop` Ní mór a chur ar chomhréim i gceart.
///
/// * Ní mór na pointí `to_drop` luach a bheith bailí ar feadh dropping, a fhéadfaidh a chiallaíonn ní mór é seasamh invariants breise, is é an cineál-spleách.
///
/// Ina theannta sin, más rud é nach bhfuil `T` [`Copy`], ag baint úsáide as an Léirigh-le luach tar éis glaoch Is féidir le `drop_in_place` a chur faoi deara iompar neamhshainithe.Tabhair faoi deara go chomhaireamh `*to_drop = foo` mar úsáid toisc go mbeidh sé faoi deara an luach a thit arís.
/// [`write()`] Is féidir a úsáid chun sonraí forscríobh nach faoi deara é a thit.
///
/// Tabhair faoi deara, fiú má tá méid `0` ag `T`, go gcaithfidh an pointeoir a bheith neamh-NULL agus ailínithe i gceart.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Bain an earra deireanach de láimh ó vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Faigh pointeoir amh don eilimint dheireanach i `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Giorraigh `v` chun an t-earra deireanach a chosc ó thit.
///     // Déanann muid go bhfuil an chéad, chun ceisteanna a má tá an `drop_in_place` thíos panics chosc.
///     v.set_len(1);
///     // Gan glao `drop_in_place`, ní scaoilfí an t-earra deireanach go deo, agus sceitheadh an chuimhne a bhainistíonn sé.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // A chinntiú go raibh thit an mhír seo caite.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Tabhair faoi deara go ndéanann an tiomsaitheoir an chóip seo go huathoibríoch agus é ag titim struchtúir phacáilte, ie, de ghnáth ní gá duit a bheith buartha faoi shaincheisteanna den sórt sin mura nglaonn tú `drop_in_place` de láimh.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Cód anseo ní ábhar, is é seo in ionad an gliú titim fíor ag an tiomsaitheoir.
    //

    // SÁBHÁILTEACHT: féach an trácht thuas
    unsafe { drop_in_place(to_drop) }
}

/// Cruthaíonn pointeoir amh null.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Cruthaigh pointeoir null amh mutable.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// impl Lámhleabhar gá a sheachaint `T: Clone` cheangal.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// impl Lámhleabhar gá a sheachaint `T: Copy` cheangal.
impl<T> Copy for FatPtr<T> {}

/// Foirmeacha slice amh ó phointeoir agus fad.
///
/// Is í argóint `len` líon na n-eilimintí **, ní líon na mbeart.
///
/// Tá an fheidhm seo sábháilte, ach tá sé neamhshábháilte an luach toraidh a úsáid.
/// Féach ar dhoiciméadú an [`slice::from_raw_parts`] do riachtanais sábháilteachta slice.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // pointeoir slice a chruthú agus tú ag tosú amach le pointeoir go dtí an chéad eilimint
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SÁBHÁILTEACHT: Tá rochtain ar an luach ón aontas `Repr` sábháilte ó * const [T]
        //
        // agus tá FatPtr na leagan amach chuimhne chéanna.Ní féidir ach le std an ráthaíocht seo a dhéanamh.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Feidhmíonn sé an fheidhmiúlacht chéanna le [`slice_from_raw_parts`], ach amháin go gcuirtear slice inathraithe amh ar ais, seachas slice dochorraithe amh.
///
///
/// Féach cáipéisíocht [`slice_from_raw_parts`] le haghaidh tuilleadh sonraí.
///
/// Tá an fheidhm seo sábháilte, ach tá sé neamhshábháilte an luach toraidh a úsáid.
/// Féach cáipéisíocht [`slice::from_raw_parts_mut`] le haghaidh riachtanais sábháilteachta slice.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // shannadh a bhfuil luach aige innéacs sa slice
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SÁBHÁILTEACHT: Tá sé sábháilte rochtain a fháil ar an luach ón aontas `Repr` ó * mut [T]
        // agus tá FatPtr na leagan amach chuimhne chéanna
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Babhtáil na luachanna ag dhá shuíomh inathraithe den chineál céanna, gan dí-ainmniú ach an oiread.
///
/// Ach don dá eisceacht, is é an fheidhm seo semantically comhionann le [`mem::swap`]:
///
///
/// * Feidhmíonn sé ar leideanna amh in ionad tagairtí.
/// Nuair a bhíonn teistiméireachtaí ar fáil, ba cheart [`mem::swap`] a roghnú.
///
/// * An dá Luaigh-chun luachanna fhéadfadh forluí.
/// Má tá forluí ar na luachanna, úsáidfear an réigiún cuimhne forluí ó `x`.
/// Tá sé seo léirithe sa dara sampla thíos.
///
/// # Safety
///
/// Tá Oibriú undefined más ann de na coinníollacha seo a leanas atáid:
///
/// * Caithfidh `x` agus `y` araon a bheith [valid] le haghaidh léamh agus scríobh.
///
/// * Ní mór `x` agus `y` araon a ailíniú i gceart.
///
/// Tabhair faoi deara, fiú má tá méid `0` ag `T`, caithfidh na leideanna a bheith neamh-NULL agus ailínithe i gceart.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Dhá réigiún neamh-fhorluiteacha a mhalartú:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // is é seo `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // is é seo `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Dhá réigiún forluiteacha a mhalartú:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // is é seo `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // is é seo `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Forluíonn innéacsanna `1..3` an slice idir `x` agus `y`.
///     // Bheadh torthaí réasúnta dóibh `[2, 3]`, ionas go mbeadh innéacsanna `0..3` `[1, 2, 3]` (a mheaitseálann `y` roimh an `swap`);nó chun iad a bheith `[0, 1]` ionas go mbeidh innéacsanna `1..4` `[0, 1, 2]` (a mheaitseálann `x` roimh an `swap`).
/////
///     // Sainmhínítear an cur chun feidhme seo chun an dara rogha a dhéanamh.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Tabhair roinnt spáis dúinn féin chun oibriú leo.
    // Ní gá dúinn a bheith buartha faoi thiteann: ní dhéanann `MaybeUninit` aon rud nuair a thittear é.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Déan an babhtáil SÁBHÁILTEACHT: ní mór don ghlaoiteoir a ráthú go bhfuil `x` agus `y` bailí le haghaidh scríbhinní agus ailínithe i gceart.
    // `tmp` Ní féidir a bheith forluiteacha ceachtar `x` nó `y` toisc go raibh `tmp` díreach leithdháileadh ar an chairn mar rud a leithdháileadh ar leith.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` agus féadfaidh `y` forluí a dhéanamh
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Malairtí `count * size_of::<T>()` bytes idir an dá réigiún na tús chuimhne ag `x` agus `y`.
/// Ní mór an dá réigiún *nach* forluí.
///
/// # Safety
///
/// Tá Oibriú undefined más ann de na coinníollacha seo a leanas atáid:
///
/// * Caithfidh `x` agus `y` araon a bheith [valid] chun `comhaireamh 'a léamh agus a scríobh *
///   size_of: :<T>() `beart.
///
/// * Ní mór `x` agus `y` araon a ailíniú i gceart.
///
/// * Réigiún na cuimhne ag tosú ag `x` le méid `comhaireamh *
///   size_of: :<T>() Ní mór `bytes * forluí le réigiún na cuimhne ag tosú ag `y` leis an méid céanna.
///
/// Tabhair faoi deara go fiú má tá an méid a chóipeáil go héifeachtach (`count * size_of: :<T>()`) Is `0`, ní mór na leideanna a bheith neamh-NULL agus ailínithe i gceart.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch a ráthú go bhfuil `x` agus `y`
    // bailí le haghaidh scríbhinní agus ailínithe i gceart.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Maidir le cineálacha níos lú ná an barrfheabhsú bloc thíos, babhtáil go díreach chun pessimizing codegen a sheachaint.
    //
    if mem::size_of::<T>() < 32 {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch a ráthú go bhfuil `x` agus `y` bailí
        // do scríobhann, ailínithe i gceart, agus neamh-forluí.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `swap_nonoverlapping` a sheasamh.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Is é an cur chuige anseo ná simd a úsáid chun x&y a mhalartú go héifeachtúil.
    // Tástáil Nochtann go bhfuil swapping ceachtar 32 bytes nó 64 beart sa turas is éifeachtaí le haghaidh próiseálaithe Intel Haswell E.
    // Is LLVM níos mó in ann bharrfheabhsú má thugaimid ar struct a #[repr(simd)], fiú amháin más rud é nach bhfuil muid úsáid i ndáiríre an struct go díreach.
    //
    //
    // FIXME repr(simd) briste ar emscripten agus Redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Lúb trí x&y, agus iad a chóipeáil `Block` ag an am Ba chóir don optimizer an lúb a rolladh go hiomlán don chuid is mó de na cineálacha NB
    // Ní féidir linn a úsáid le haghaidh lúb mar a thugann an t-impl `range` `mem::swap` hathchúrsach
    //
    let mut i = 0;
    while i + block_size <= len {
        // Cruthaigh roinnt cuimhne neamhbheartaithe mar spás scríobtha Seachnaíonn Dearbhú `t` anseo an chruach a ailíniú nuair nach n-úsáidtear an lúb seo
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SÁBHÁILTEACHT: Mar `i < len`, agus toisc go gcaithfidh an té atá ag glaoch a ráthú go bhfuil `x` agus `y` bailí
        // maidir le bearta `len`, ní mór gur seoltaí bailí iad `x + i` agus `y + i`, a chomhlíonann an conradh sábháilteachta do `add`.
        //
        // Ina theannta sin, ní mór don té atá ag glaoch a ráthú go bhfuil `x` agus `y` bailí do scríobhann, ailínithe i gceart, agus neamh-forluí, a chomhlíonann an conradh sábháilteachta do `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Babhtáil bloc beart x&y, ag úsáid t mar mhaolán sealadach Ba cheart é seo a bharrfheabhsú in oibríochtaí éifeachtacha SIMD nuair atá sé ar fáil
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Babhtáil aon bheart atá fágtha
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SÁBHÁILTEACHT: féach an trácht sábháilteachta roimhe seo.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Bog `src` isteach sa `dst` biorach, ag filleadh ar an luach `dst` roimhe.
///
/// Ní thittear ceachtar luach.
///
/// Tá an fheidhm seo coibhéiseach go séimeantach le [`mem::replace`] ach amháin go bhfeidhmíonn sí ar leideanna amha in ionad tagairtí.
/// Nuair a bhíonn teistiméireachtaí ar fáil, ba cheart [`mem::replace`] a roghnú.
///
/// # Safety
///
/// Tá Oibriú undefined más ann de na coinníollacha seo a leanas atáid:
///
/// * `dst` caithfidh [valid] a bheith ann le haghaidh léamh agus scríobh.
///
/// * `dst` Ní mór a chur ar chomhréim i gceart.
///
/// * `dst` Ní mór pointe go dtí luach túsaithe i gceart den chineál `T`.
///
/// Tabhair faoi deara, fiú má tá méid `0` ag `T`, go gcaithfidh an pointeoir a bheith neamh-NULL agus ailínithe i gceart.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` bheadh an éifeacht chéanna aige gan an bloc neamhshábháilte a cheangal.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SÁBHÁILTEACHT: an ráthaíocht mór té atá ag glaoch go bhfuil `dst` bailí a bheith
    // caitheadh le tarchur mutable (bailí le haghaidh scríobhann, ailíniú trí, initialized), agus ní féidir ní forluí `src` mar nach mór `dst` pointe ar rud a leithdháileadh ar leith.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // ní féidir forluí a dhéanamh
    }
    src
}

/// Léann an luach ó `src` gan gluaiseacht a dhéanamh air.Fágann sé sin nach bhfuil aon athrú ar an gcuimhne i `src`.
///
/// # Safety
///
/// Tá Oibriú undefined más ann de na coinníollacha seo a leanas atáid:
///
/// * `src` Ní mór a bheith [valid] do léann.
///
/// * `src` Ní mór a chur ar chomhréim i gceart.Úsáid [`read_unaligned`] mura amhlaidh atá.
///
/// * `src` Ní mór pointe go dtí luach túsaithe i gceart den chineál `T`.
///
/// Tabhair faoi deara, fiú má tá méid `0` ag `T`, go gcaithfidh an pointeoir a bheith neamh-NULL agus ailínithe i gceart.
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// [`mem::swap`] a chur i bhfeidhm de láimh:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Cruthaigh cóip bitwise den luach ag `a` in `tmp`.
///         let tmp = ptr::read(a);
///
///         // Dá bhfágfaí ag an bpointe seo é (trí fhilleadh go sainráite nó trí fheidhm a ghlaoch panics) d`fhágfaí go dtitfí an luach in `tmp` fad is a dhéantar tagairt don luach céanna le `a`.
///         // D`fhéadfadh sé seo iompar neamhshainithe a spreagadh mura `T` é `T`.
/////
/////
///
///         // Cruthaigh cóip bitwise den luach ag `b` in `a`.
///         // Tá sé seo sábháilte toisc nach féidir ailias a dhéanamh ar thagairtí inathraithe.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Mar atá thuas, d`fhéadfadh imeacht anseo iompar neamhshainithe a spreagadh toisc go ndéantar tagairt don luach céanna le `a` agus `b`.
/////
///
///         // Bog `tmp` go `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` ar athraíodh a ionad (glacann `write` úinéireacht ar a dhara argóint), mar sin ní scaoiltear aon rud go hintuigthe anseo.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Úinéireacht an Luach Aisghairthe
///
/// `read` cruthaíonn sé cóip bitwise de `T`, is cuma más `T` é [`Copy`].
/// Mura bhfuil `T` [`Copy`], ag baint úsáide as an dá an luach ar ais agus an luach ar `*src` féidir violate sábháilteacht chuimhne.
/// Tabhair faoi deara go n-áirítear sannadh do `*src` mar úsáid toisc go ndéanfaidh sé iarracht an luach ag `* src` a ísliú.
///
/// [`write()`] Is féidir a úsáid chun sonraí forscríobh nach faoi deara é a thit.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` pointí anois go dtí an chuimhne chéanna is bun le `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Nuair a shanntar do `s2` titeann a luach bunaidh.
///     // Taobh amuigh den phointe seo, ní gá `s` a úsáid a thuilleadh, mar gur saoradh an chuimhne bhunúsach.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // D`fhágfadh sannadh do `s` go dtitfí an seanluach arís, agus go mbeadh iompar neamhshainithe mar thoradh air.
/////
///     // s= String::from("bar");//ERROR
///
///     // `ptr::write` is féidir a úsáid chun luach a fhorscríobh gan é a ligean anuas.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch a ráthú go bhfuil `src` bailí le haghaidh léamha.
    // `src` Is féidir nach bhfuil forluí `tmp` toisc go raibh `tmp` díreach leithdháileadh ar an chairn mar rud a leithdháileadh ar leith.
    //
    //
    // Chomh maith leis sin, ós rud é nár scríobh muid ach luach bailí isteach i `tmp`, ráthaítear go dtosófar i gceart é.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Léann an luach ó `src` gan gluaiseacht a dhéanamh air.Fágann sé sin nach bhfuil aon athrú ar an gcuimhne i `src`.
///
/// Murab ionann agus [`read`], oibríonn `read_unaligned` le leideanna unaligned.
///
/// # Safety
///
/// Tá Oibriú undefined más ann de na coinníollacha seo a leanas atáid:
///
/// * `src` Ní mór a bheith [valid] do léann.
///
/// * `src` Ní mór pointe go dtí luach túsaithe i gceart den chineál `T`.
///
/// Cosúil le [`read`], cruthaíonn `read_unaligned` cóip bitwise de `T`, is cuma más `T` é [`Copy`].
/// Murab é `T` [`Copy`], is féidir [violate memory safety][read-ownership] a úsáid leis an luach ar ais agus an luach ag `*src`.
///
/// Tabhair faoi deara go fiú má tá `T` Méid `0`, ní mór an pointeoir a bheith neamh-NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Ar struchtúir `packed`
///
/// Tá sé dodhéanta faoi láthair leideanna amha a chruthú do réimsí neamhshainithe de struchtúr pacáilte.
///
/// Ag iarraidh pointeoir amh a chruthú do réimse struchtúir `unaligned` le slonn mar `&packed.unaligned as *const FieldType` cruthaítear tagairt idirmheánach neamhshínithe sula ndéantar é sin a thiontú go pointeoir amh.
///
/// Tá an tagairt seo sealadach agus teilgthe láithreach neamhfhreagrach toisc go mbíonn an tiomsaitheoir i gcónaí ag súil go mbeidh tagairtí ailínithe i gceart.
/// Mar thoradh air sin, is cúis ag baint úsáide as `&packed.unaligned as *const FieldType` láithreach* iompar undefined * i do chlár.
///
/// Sampla de na rudaí nach ceart a dhéanamh agus an bhaint atá aige seo le `read_unaligned` ná:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Déanaimid iarracht anseo seoladh slánuimhir 32-giotán nach bhfuil ailínithe.
///     let unaligned =
///         // Cruthaítear tagairt shealadach gan síniú anseo a mbíonn iompar neamhshainithe mar thoradh air is cuma má úsáidtear an tagairt nó nach n-úsáidtear.
/////
///         &packed.unaligned
///         // Ní chuidíonn réitigh go pointeoir amh;tharla an botún cheana féin.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Tá sé sábháilte, áfach, rochtain a fháil ar pháirceanna gan síniú go díreach le m.sh. `packed.unaligned`.
///
///
///
///
///
///
// FIXME: docs Nuashonrú bunaithe ar thoradh an RFC #2582 agus cairde.
/// # Examples
///
/// Léigh luach usize ó mhaolán beart:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch a ráthú go bhfuil `src` bailí le haghaidh léamha.
    // `src` Is féidir nach bhfuil forluí `tmp` toisc go raibh `tmp` díreach leithdháileadh ar an chairn mar rud a leithdháileadh ar leith.
    //
    //
    // Chomh maith leis sin, ós rud é nár scríobh muid ach luach bailí isteach i `tmp`, ráthaítear go dtosófar i gceart é.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Déanann sé suíomh cuimhne a fhorscríobh leis an luach tugtha gan an seanluach a léamh nó a ligean anuas.
///
/// `write` ní scaoilfidh ábhar `dst`.
/// Tá sé seo sábháilte, ach d`fhéadfadh sé leithdháiltí nó acmhainní a sceitheadh, mar sin ba chóir a bheith cúramach gan an rud ba chóir a thitim a fhorscríobh.
///
///
/// Ina theannta sin, ní scaoil sé `src`.Go séimeantach, bogtar `src` isteach sa suíomh a dtugann `dst` aird air.
///
/// Tá sé seo oiriúnach chun cuimhne neamhbheartaithe a thionscnamh, nó chun cuimhne a scríobh a raibh [`read`] roimhe seo.
///
/// # Safety
///
/// Tá Oibriú undefined más ann de na coinníollacha seo a leanas atáid:
///
/// * `dst` caithfidh [valid] a bheith ann le haghaidh scríbhinní.
///
/// * `dst` Ní mór a chur ar chomhréim i gceart.Úsáid [`write_unaligned`] mura amhlaidh an cás.
///
/// Tabhair faoi deara, fiú má tá méid `0` ag `T`, go gcaithfidh an pointeoir a bheith neamh-NULL agus ailínithe i gceart.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// [`mem::swap`] a chur i bhfeidhm de láimh:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Cruthaigh cóip bitwise den luach ag `a` in `tmp`.
///         let tmp = ptr::read(a);
///
///         // Dá bhfágfaí ag an bpointe seo é (trí fhilleadh go sainráite nó trí fheidhm a ghlaoch panics) d`fhágfaí go dtitfí an luach in `tmp` fad is a dhéantar tagairt don luach céanna le `a`.
///         // D`fhéadfadh sé seo iompar neamhshainithe a spreagadh mura `T` é `T`.
/////
/////
///
///         // Cruthaigh cóip bitwise den luach ag `b` in `a`.
///         // Tá sé seo sábháilte toisc nach féidir ailias a dhéanamh ar thagairtí inathraithe.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Mar atá thuas, d`fhéadfadh imeacht anseo iompar neamhshainithe a spreagadh toisc go ndéantar tagairt don luach céanna le `a` agus `b`.
/////
///
///         // Bog `tmp` go `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` ar athraíodh a ionad (glacann `write` úinéireacht ar a dhara argóint), mar sin ní scaoiltear aon rud go hintuigthe anseo.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Táimid ag glaoch go díreach ar an intreach chun glaonna feidhm sa chód ginte a sheachaint mar is feidhm fillteáin é `intrinsics::copy_nonoverlapping`.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SÁBHÁILTEACHT: ní mór don té atá ag glaoch a ráthú go bhfuil `dst` bailí ar feadh scríobhann.
    // `dst` ní féidir forluí a dhéanamh ar `src` toisc go bhfuil rochtain inathraithe ag an té atá ag glaoch ar `dst` agus go bhfuil `src` faoi úinéireacht na feidhme seo.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Déanann sé suíomh cuimhne a fhorscríobh leis an luach tugtha gan an seanluach a léamh nó a ligean anuas.
///
/// Murab ionann agus [`write()`], féadfar an pointeoir a bheith gan síniú.
///
/// `write_unaligned` ní scaoilfidh ábhar `dst`.Tá sé seo sábháilte, ach d'fhéadfadh sé leithdháiltí nó acmhainní sceitheadh, mar sin ba chóir cúram a ghlacadh gan a fhorscríobh rud ba chóir a thit.
///
/// Ina theannta sin, ní scaoil sé `src`.Go séimeantach, bogtar `src` isteach sa suíomh a dtugann `dst` aird air.
///
/// Tá sé seo oiriúnach chun cuimhne neamhbheartaithe a thionscnamh, nó chun cuimhne a scríobh a léadh le [`read_unaligned`] roimhe seo.
///
/// # Safety
///
/// Tá Oibriú undefined más ann de na coinníollacha seo a leanas atáid:
///
/// * `dst` caithfidh [valid] a bheith ann le haghaidh scríbhinní.
///
/// Tabhair faoi deara go fiú má tá `T` Méid `0`, ní mór an pointeoir a bheith neamh-NULL.
///
/// [valid]: self#safety
///
/// ## Ar struchtúir `packed`
///
/// Tá sé dodhéanta faoi láthair leideanna amha a chruthú do réimsí neamhshainithe de struchtúr pacáilte.
///
/// Ag iarraidh pointeoir amh a chruthú do réimse struchtúir `unaligned` le slonn mar `&packed.unaligned as *const FieldType` cruthaítear tagairt idirmheánach neamhshínithe sula ndéantar é sin a thiontú go pointeoir amh.
///
/// Tá an tagairt seo sealadach agus teilgthe láithreach neamhfhreagrach toisc go mbíonn an tiomsaitheoir i gcónaí ag súil go mbeidh tagairtí ailínithe i gceart.
/// Mar thoradh air sin, is cúis ag baint úsáide as `&packed.unaligned as *const FieldType` láithreach* iompar undefined * i do chlár.
///
/// Sampla de na rudaí nach ceart a dhéanamh agus an bhaint atá aige seo le `write_unaligned` ná:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Déanaimid iarracht anseo seoladh slánuimhir 32-giotán nach bhfuil ailínithe.
///     let unaligned =
///         // Cruthaítear tagairt shealadach gan síniú anseo a mbíonn iompar neamhshainithe mar thoradh air is cuma má úsáidtear an tagairt nó nach n-úsáidtear.
/////
///         &mut packed.unaligned
///         // Ní chuidíonn réitigh go pointeoir amh;tharla an botún cheana féin.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Tá sé sábháilte, áfach, rochtain a fháil ar pháirceanna gan síniú go díreach le m.sh. `packed.unaligned`.
///
///
///
///
///
///
///
///
///
// FIXME: docs Nuashonrú bunaithe ar thoradh an RFC #2582 agus cairde.
/// # Examples
///
/// Scríobh luach usize chuig maolán beart:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SÁBHÁILTEACHT: ní mór don té atá ag glaoch a ráthú go bhfuil `dst` bailí ar feadh scríobhann.
    // `dst` ní féidir forluí a dhéanamh ar `src` toisc go bhfuil rochtain inathraithe ag an té atá ag glaoch ar `dst` agus go bhfuil `src` faoi úinéireacht na feidhme seo.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Táimid ag glaoch go díreach ar an intreach chun glaonna feidhm sa chód ginte a sheachaint.
        intrinsics::forget(src);
    }
}

/// Fheidhmíonn a léamh luaineach de luach ó `src` gan gluaiseacht a dhéanamh air.Fágann sé sin nach bhfuil aon athrú ar an gcuimhne i `src`.
///
/// Tá sé i gceist go ngníomhóidh oibríochtaí luaineachta ar chuimhne I/O, agus ráthaítear nach gcuirfidh an tiomsaitheoir as dóibh nó go n-athainmneoidh siad iad thar oibríochtaí so-ghalaithe eile.
///
/// # Notes
///
/// Níl Rust bhfuil faoi láthair ar shamhail cuimhne dian agus go foirmiúil sainithe, mar sin tá an semantics beacht cad a chiallaíonn "volatile" anseo faoi réir athrú le himeacht ama.
/// É sin ráite, beidh na séimeantaice beagnach cosúil le [C11's definition of volatile][c11] beagnach i gcónaí.
///
/// Níor chóir an tiomsaitheoir a athrú an t-ordú gaol nó uimhir na n-oibríochtaí chuimhne so-ghalaithe.
/// Mar sin féin, oibríochtaí chuimhne so-ghalaithe ar chineálacha náid-iarrachtaí (eg, más rud é i ndáil le cineál náid-iarrachtaí a rith go `read_volatile`) Tá noops agus féadfar é a neamhaird.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Tá Oibriú undefined más ann de na coinníollacha seo a leanas atáid:
///
/// * `src` Ní mór a bheith [valid] do léann.
///
/// * `src` Ní mór a chur ar chomhréim i gceart.
///
/// * `src` Ní mór pointe go dtí luach túsaithe i gceart den chineál `T`.
///
/// Cosúil le [`read`], cruthaíonn `read_volatile` cóip bitwise de `T`, is cuma más `T` é [`Copy`].
/// Murab é `T` [`Copy`], is féidir [violate memory safety][read-ownership] a úsáid leis an luach ar ais agus an luach ag `*src`.
/// Mar sin féin, is cinnte go bhfuil stóráil cineálacha neamh-[`Cóipeála '] i gcuimhne luaineach mícheart.
///
/// Tabhair faoi deara, fiú má tá méid `0` ag `T`, go gcaithfidh an pointeoir a bheith neamh-NULL agus ailínithe i gceart.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Díreach mar atá i C, níl baint ar bith ag ceisteanna a bhaineann le rochtain chomhthráthach ó iliomad snáitheanna cibé an bhfuil oibríocht luaineach.Iompraíonn rochtana luaineachta díreach cosúil le rochtana neamh-adamhacha ina leith sin.
///
/// Go háirithe, is iompar neamhshainithe é rás idir `read_volatile` agus aon oibríocht scríbhneoireachta chuig an áit chéanna.
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Gan panicking a choinneáil ar thionchar codegen lú.
        abort();
    }
    // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `volatile_load` a sheasamh.
    unsafe { intrinsics::volatile_load(src) }
}

/// Déanann sé scríbhinn luaineach ar shuíomh cuimhne leis an luach tugtha gan an seanluach a léamh nó a ligean anuas.
///
/// Tá sé i gceist go ngníomhóidh oibríochtaí luaineachta ar chuimhne I/O, agus ráthaítear nach gcuirfidh an tiomsaitheoir as dóibh nó go n-athainmneoidh siad iad thar oibríochtaí so-ghalaithe eile.
///
/// `write_volatile` ní scaoilfidh ábhar `dst`.Tá sé seo sábháilte, ach d'fhéadfadh sé leithdháiltí nó acmhainní sceitheadh, mar sin ba chóir cúram a ghlacadh gan a fhorscríobh rud ba chóir a thit.
///
/// Ina theannta sin, ní scaoil sé `src`.Go séimeantach, bogtar `src` isteach sa suíomh a dtugann `dst` aird air.
///
/// # Notes
///
/// Níl Rust bhfuil faoi láthair ar shamhail cuimhne dian agus go foirmiúil sainithe, mar sin tá an semantics beacht cad a chiallaíonn "volatile" anseo faoi réir athrú le himeacht ama.
/// É sin ráite, beidh na séimeantaice beagnach cosúil le [C11's definition of volatile][c11] beagnach i gcónaí.
///
/// Níor chóir an tiomsaitheoir a athrú an t-ordú gaol nó uimhir na n-oibríochtaí chuimhne so-ghalaithe.
/// Mar sin féin, is noops iad oibríochtaí cuimhne luaineacha ar chineálacha meánmhéide (m.sh., má chuirtear cineál meánmhéide ar aghaidh chuig `write_volatile`) agus féadfar neamhaird a dhéanamh orthu.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Tá Oibriú undefined más ann de na coinníollacha seo a leanas atáid:
///
/// * `dst` caithfidh [valid] a bheith ann le haghaidh scríbhinní.
///
/// * `dst` Ní mór a chur ar chomhréim i gceart.
///
/// Tabhair faoi deara, fiú má tá méid `0` ag `T`, go gcaithfidh an pointeoir a bheith neamh-NULL agus ailínithe i gceart.
///
/// [valid]: self#safety
///
/// Díreach mar atá i C, níl baint ar bith ag ceisteanna a bhaineann le rochtain chomhthráthach ó iliomad snáitheanna cibé an bhfuil oibríocht luaineach.Iompraíonn rochtana luaineachta díreach cosúil le rochtana neamh-adamhacha ina leith sin.
///
/// Go háirithe, is iompar neamhshainithe rás idir `write_volatile` agus aon oibríocht eile (léamh nó scríobh) san áit chéanna.
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Gan panicking a choinneáil ar thionchar codegen lú.
        abort();
    }
    // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `volatile_store` a sheasamh.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Ailínigh pointeoir `p`.
///
/// Ríomh fhritháireamh (ó thaobh na n-eilimintí de `stride` stride) go bhfuil cur i bhfeidhm ar pointeoir `p` ionas go mbeadh pointeoir `p` fháil ailínithe le `a`.
///
/// Note: Tá an cur i bhfeidhm curtha in oiriúint go cúramach chun nach panic.Is é UB é seo go panic.
/// Is é an t-aon athrú fíor is féidir a dhéanamh anseo ná athrú `INV_TABLE_MOD_16` agus tairisigh bhainteacha.
///
/// Má shocraímid riamh go mbeimid in ann an intreach a ghlaoch le `a` nach cumhacht de bheirt é, is dócha go mbeidh sé níos críonna athrú go dtí cur chun feidhme naive seachas iarracht a dhéanamh é seo a oiriúnú chun freastal ar an athrú sin.
///
///
/// Téann ceisteanna ar bith chuig@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Feabhsaíonn úsáid dhíreach na n-intreach seo codegen go mór ag an leibhéal optúil <=
    // 1, i gcás nach bhfuil leaganacha modh na n-oibríochtaí seo líneáilte.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Ríomh inbhéartach modúlach iolraitheach de `x` modulo `m`.
    ///
    /// Tá an cur i bhfeidhm in oiriúint do `align_offset` agus tá réamhchoinníollacha seo a leanas:
    ///
    /// * `m` is cumhacht de bheirt é;
    /// * `x < m`; (Más `x ≥ m`, pas a fháil i `x % m` ina ionad)
    ///
    /// Ní chuirfear an fheidhm seo i bhfeidhm panic.Riamh.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Modulo tábla inbhéartach modúlach iolraitheach 2⁴=16.
        ///
        /// Tabhair faoi deara, nach bhfuil luachanna sa tábla seo nuair nach bhfuil inbhéartach ann (ie i gcás `0⁻¹ mod 16`, `2⁻¹ mod 16`, srl.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo a bhfuil an `INV_TABLE_MOD_16` beartaithe dó.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SÁBHÁILTEACHT: Ceanglaítear ar `m` a bheith ina chumhacht de bheirt, mar sin neamh-nialas.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Déanaimid "up" a athrá ag úsáid na foirmle seo a leanas:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // go dtí 2²ⁿ ≥ m.Ansin is féidir linn laghdú go dtí an `m` atá uainn tríd an toradh `mod m` a thógáil.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) n mod
                //
                // Tabhair faoi deara, go n-úsáideann muid oibríochtaí timfhilleadh anseo d`aon ghnó-úsáideann an fhoirmle bhunaidh m.sh., dealú `mod n`.
                // Is breá an rud é `mod usize::MAX` a dhéanamh ina ionad, mar go dtógfaimid an toradh `mod n` ag an deireadh ar aon nós.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SÁBHÁILTEACHT: Is cumhacht de bheirt é `a`, mar sin neamh-nialas.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` is féidir cás a ríomh níos simplí trí `-p (mod a)`, ach má dhéantar é sin cuireann sé cosc ar chumas LLVM treoracha mar `lea` a roghnú.Ina áit sin déanaimid ríomh
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // a dháileann oibríochtaí timpeall an ualaigh, ach a dhóthain `and` ionas go mbeidh LLVM in ann na barrfheabhsúcháin éagsúla atá ar eolas aige a úsáid.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Cheana ailínithe.Yay!
        return 0;
    } else if stride == 0 {
        // Mura bhfuil an pointeoir ailínithe, agus an eilimint de mhéid nialasach, ansin ní dhéanfaidh aon mhéid eilimintí an pointeoir a ailíniú riamh.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SÁBHÁILTEACHT: is cumhacht de bheirt í mar sin neamh-nialas.Láimhseáiltear cás==0 thuas.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SÁBHÁILTEACHT: tá uasteorainn ar gcdpow atá ar a mhéad líon na ngiotán in úsáid.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SÁBHÁILTEACHT: bíonn gcd níos mó nó cothrom le 1 i gcónaí.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Réitíonn an branch seo don chothromóid líneach seo a leanas:
        //
        // ` p + so = 0 mod a `
        //
        // `p` anseo tá luach an phointeora, `s`, stride de `T`, `o` fritháireamh i `T`s, agus `a`, an t-ailíniú iarrtha.
        //
        // Le `g = gcd(a, s)`, agus an coinníoll thuasluaite ag dearbhú go bhfuil `p` inroinnte `g` freisin, is féidir linn a in iúl `a' = a/g`, `s' = s/g`, `p' = p/g`, ansin bheidh sé sin comhionann le:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Is é an chéad téarma "the relative alignment of `p` to `a`" (arna roinnt ar an `g`), is é an dara téarma "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (arís roinnte `g`).
        //
        // Is gá deighilt le `g` chun an inbhéartach a fhoirmiú go maith mura bhfuil `a` agus `s` comh-phríomha.
        //
        // Ina theannta sin, nach bhfuil an toradh a tháirgeann an réiteach "minimal", agus mar sin tá sé riachtanach a chur ar an toradh `o mod lcm(s, a)`.Is féidir linn `lcm(s, a)` a chur in ionad `a'` amháin.
        //
        //
        //
        //
        //

        // SÁBHÁILTEACHT: `gcdpow` Tá uachtair faoi cheangal nach mó ná líon na n-trailing 0-giotán in `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SÁBHÁILTEACHT: Tá `a2` neamh-nialasach.Ní féidir le haistriú `a` le `gcdpow` aon cheann de na giotáin socraithe a aistriú
        // in `a` (a bhfuil ceann díreach aige).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SÁBHÁILTEACHT: `gcdpow` Tá uachtair faoi cheangal nach mó ná líon na n-trailing 0-giotán in `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SÁBHÁILTEACHT: Tá teorainn uachtarach ag `gcdpow` nach mó ná líon na 0-ghiotán trailing isteach
        // `a`.
        // Ina theannta sin, ní féidir leis an dealú cur thar maoil, toisc go mbeidh `a2 = a >> gcdpow` i gcónaí níos mó ná `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // Is `a2` cumhacht-de-dhá, mar a cruthaithe thuas: SÁBHÁILTEACHT.Is `s2` docht faoi bhun `a2`
        // toisc go bhfuil `(s % a) >> gcdpow` níos lú ná `a >> gcdpow` go docht.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Ní féidir é a ailíniú ar chor ar bith.
    usize::MAX
}

/// Déan comparáid idir leideanna amha don chomhionannas.
///
/// Is ionann é seo agus an t-oibreoir `==` a úsáid, ach níos lú cineálach:
/// caithfidh na hargóintí a bheith ina leideanna amha `*const T`, ní aon rud a chuireann `PartialEq` i bhfeidhm.
///
/// Is féidir é seo a úsáid chun tagairtí `&T` (a théann go hintuigthe le `*const T` go hintuigthe) a chur i gcomparáid lena seoladh seachas comparáid a dhéanamh idir na luachanna a gcuireann siad in iúl dóibh (is é sin a dhéanann cur chun feidhme `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Déantar slisní a chur i gcomparáid freisin de réir a fhad (leideanna saille):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Déantar comparáid idir Traits trína gcur i bhfeidhm:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Tá seoltaí comhionanna ag leideanna.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Tá seoltaí comhionanna ag réada, ach tá cur chun feidhme difriúil ag `Trait`.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Déantar an tagairt do `*const u8` a thiontú i gcomparáid le seoladh.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash pointeoir amh.
///
/// Is féidir é seo a úsáid chun tagairt `&T` (a chomhcheanglaíonn go hintuigthe le `*const T` go hintuigthe) a hash ag a sheoladh seachas an luach a dtugann sé aird air (is é sin a dhéanann cur chun feidhme `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls le haghaidh leideanna feidhm
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Teastaíonn an caitheadh idirmheánach mar usize le haghaidh AVR
                // ionas go gcaomhnófar spás seoltaí an phointeora feidhm foinse sa phointeoir feidhme deiridh.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Teastaíonn an caitheadh idirmheánach mar usize le haghaidh AVR
                // ionas go gcaomhnófar spás seoltaí an phointeora feidhm foinse sa phointeoir feidhme deiridh.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Níl feidhmeanna variadic le 0 paraiméadair
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Cruthaigh pointeoir amh `const` go háit, gan tagairt idirmheánach a chruthú.
///
/// Ní cheadaítear tagairt a chruthú le `&`/`&mut` ach má tá an pointeoir ailínithe i gceart agus má dhíríonn sé ar shonraí tosaigh.
/// I gcásanna nach bhfuil na ceanglais sin ann, ba cheart leideanna amha a úsáid ina ionad.
/// Mar sin féin, cruthaíonn `&expr as *const _` tagairt sula ndéantar é a chaitheamh ar phointeoir amh, agus tá an tagairt sin faoi réir na rialacha céanna le gach tagairt eile.
///
/// Is féidir an macra chruthú pointeoir amh *gan* a chruthú tagartha dtús.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` chruthódh sé tagairt neamhshainithe, agus dá bhrí sin Iompar Neamhshainithe!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Cruthaigh pointeoir amh `mut` go háit, gan tagairt idirmheánach a chruthú.
///
/// Ní cheadaítear tagairt a chruthú le `&`/`&mut` ach má tá an pointeoir ailínithe i gceart agus má dhíríonn sé ar shonraí tosaigh.
/// I gcásanna nach bhfuil na ceanglais sin ann, ba cheart leideanna amha a úsáid ina ionad.
/// Mar sin féin, cruthaíonn `&mut expr as *mut _` tagairt sula ndéantar é a chaitheamh ar phointeoir amh, agus tá an tagairt sin faoi réir na rialacha céanna le gach tagairt eile.
///
/// Is féidir an macra chruthú pointeoir amh *gan* a chruthú tagartha dtús.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` chruthódh sé tagairt neamhshainithe, agus dá bhrí sin Iompar Neamhshainithe!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` Fórsaí chóipeáil an réimse in ionad a chruthú a tagartha.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}