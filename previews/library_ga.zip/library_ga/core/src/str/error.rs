//! Sainmhínítear cineál earráide utf8.

use crate::fmt;

/// Earráidí a d`fhéadfadh tarlú nuair a dhéantar iarracht seicheamh [`u8`] a léirmhíniú mar shreang.
///
/// Mar sin, baineann an teaghlach feidhmeanna agus modhanna `from_utf8` le haghaidh [`Teaghrán`] agus [`&str`] araon úsáid as an mbotún seo, mar shampla.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Is féidir modhanna an chineáil earráide seo a úsáid chun feidhmiúlacht cosúil le `String::from_utf8_lossy` a chruthú gan cuimhne carn a leithdháileadh:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Filleann sé an t-innéacs sa tsreang a tugadh ar fíoraíodh UTF-8 bailí dó.
    ///
    /// Is é an t-innéacs uasta é go bhfillfeadh `from_utf8(&input[..index])` `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::str;
    ///
    /// // roinnt beart neamhbhailí, i vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 Filleann Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // tá an dara beart neamhbhailí anseo
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Soláthraíonn sé tuilleadh faisnéise faoin teip:
    ///
    /// * `None`: thángthas ar an deireadh an t-ionchur gan choinne.
    ///   `self.valid_up_to()` is 1 go 3 bheart ó dheireadh an ionchuir.
    ///   Má tá sruth beart (cosúil le comhad nó soicéad líonra) á dhíchódú go hincriminteach, d`fhéadfadh sé seo a bheith ina `char` bailí a bhfuil a seicheamh beart UTF-8 ag trasnú smután iolrach.
    ///
    ///
    /// * `Some(len)`: thángthas ar bheart gan choinne.
    ///   Is é an fad a sholáthraítear an seicheamh beart neamhbhailí a thosaíonn ag an innéacs a thugann `valid_up_to()`.
    ///   Ba cheart díchódú a atosú tar éis an tseicheamh sin (tar éis [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] a chur isteach) i gcás díchódú caillteach.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// ar ais earráid le linn parsála a `bool` ag baint úsáide as [`from_str`] mainneoidh
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}