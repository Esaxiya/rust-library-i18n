//! Bealaí chun slice `str` a chruthú ó bhearta.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Tiontaíonn sé slice beart le slice sreangán.
///
/// Déantar slice sreang ([`&str`]) de bhearta ([`u8`]), agus déantar slice beart ([`&[u8]`][byteslice]) de bhearta, mar sin athraíonn an fheidhm seo idir an dá cheann.
/// Ní slisní sreinge bailí gach sliseog beart, áfach: éilíonn [`&str`] go bhfuil sé bailí UTF-8.
/// `from_utf8()` seiceálacha chun a áirithiú go bhfuil na bearta bailí UTF-8, agus ansin a dhéanann an chomhshó.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Má tá tú cinnte go bhfuil an slice beart bailí UTF-8, agus mura dteastaíonn uait forchostas na seiceála bailíochta a thabhú, tá leagan neamhshábháilte den fheidhm seo, [`from_utf8_unchecked`], a bhfuil an t-iompar céanna air ach a scipeálann an seic.
///
///
/// Má theastaíonn `String` uait in ionad `&str`, smaoinigh ar [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Toisc gur féidir leat `[u8; N]` a leithdháileadh, agus gur féidir leat [`&[u8]`][byteslice] a thógáil de, is bealach amháin í an fheidhm seo le sreangán a leithdháileadh ar chairn.Tá sampla de seo sa rannóg samplaí thíos.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Tuairisceáin `Err` mura UTF-8 an slice le tuairisc ar an gcúis nach UTF-8 an slice a sholáthraítear.
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// use std::str;
///
/// // roinnt bytes, i vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Tá a fhios againn go bhfuil na bearta seo bailí, mar sin ní gá ach `unwrap()` a úsáid.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Bearta mícheart:
///
/// ```
/// use std::str;
///
/// // roinnt beart neamhbhailí, i vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Féach na docs le haghaidh [`Utf8Error`] le haghaidh tuilleadh sonraí faoi na cineálacha earráidí is féidir a chur ar ais.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // roinnt bytes, i sraith Stack-leithdháileadh
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Tá a fhios againn go bhfuil na bearta seo bailí, mar sin ní gá ach `unwrap()` a úsáid.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SÁBHÁILTEACHT: Just bailíochtú.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Tiontaíonn sé sliseog so-aistrithe de bhearta go slice sreangán.
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" mar vector mutable
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Mar is eol dúinn go bhfuil na bytes bailí, is féidir linn a úsáid `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Bearta mícheart:
///
/// ```
/// use std::str;
///
/// // Roinnt beart neamhbhailí i vector mutable
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Féach na docs le haghaidh [`Utf8Error`] le haghaidh tuilleadh sonraí faoi na cineálacha earráidí is féidir a chur ar ais.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SÁBHÁILTEACHT: Just bailíochtú.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Tiontaíonn sé slice beart go slice sreang gan a sheiceáil go bhfuil UTF-8 bailí sa téad.
///
/// Féach an leagan sábháilte, [`from_utf8`], le haghaidh tuilleadh faisnéise.
///
/// # Safety
///
/// Tá an fheidhm seo neamhshábháilte toisc nach seiceálann sí go bhfuil na bearta a cuireadh ar aghaidh bailí UTF-8.
/// Má sháraítear an srian seo, bíonn iompar neamhshainithe mar thoradh air, toisc go nglacann an chuid eile de Rust leis go bhfuil [`&str`] s bailí UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// use std::str;
///
/// // roinnt bytes, i vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SÁBHÁILTEACHT: ní mór don té atá ag glaoch a ráthú go bhfuil na bearta `v` bailí UTF-8.
    // Braitheann sé freisin ar an leagan amach céanna a bheith ag `&str` agus `&[u8]`.
    unsafe { mem::transmute(v) }
}

/// Athraíonn sé slice beart go slice sreang gan a sheiceáil go bhfuil UTF-8 bailí sa téad;leagan mutable.
///
///
/// Féach ar an leagan immutable, [`from_utf8_unchecked()`] le haghaidh tuilleadh eolais.
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SÁBHÁILTEACHT: an ráthaíocht mór té atá ag glaoch go bhfuil an bytes `v`
    // go bhfuil siad bailí UTF-8, dá bhrí sin tá an caitheadh go `*mut str` sábháilte.
    // Chomh maith leis sin, tá an iarchur pointeoir sábháilte toisc go dtagann an pointeoir sin ó thagairt a ráthaítear a bheith bailí le haghaidh scríbhinní.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}