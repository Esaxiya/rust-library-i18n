//! Ionramháil teaghrán.
//!
//! Le haghaidh tuilleadh sonraí, féach an modúl [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. as teorainneacha
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. tosú <=deireadh
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. teorainn charachtair
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // faigh an carachtar
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` caithfidh sé a bheith níos lú ná len agus teorainn char
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Filleann sé an fad `self`.
    ///
    /// Tá an fad, i mbearta, ní [`char`] s nó graphemes.
    /// Is é sin le rá, b`fhéidir nach é an rud a mheasann duine fad na sreinge.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // mhaisiúil f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Tuairisceáin `true` má tá fad náid beart ag `self`.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Seiceálacha gurb é `index`-th byte an chéad bheart i seicheamh pointe cód UTF-8 nó deireadh na sreinge.
    ///
    ///
    /// An tús agus deireadh an teaghráin (nuair `Tá innéacs== self.len()`) mheastar a bheith teorainneacha.
    ///
    /// Tuairisceáin `false` má tá `index` níos mó ná `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // tús `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // an dara beart de `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // an tríú beart de `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // Bíonn 0 agus len ceart go leor i gcónaí.
        // Déan tástáil ar 0 go sainráite ionas gur féidir leis an seic a bharrfheabhsú go héasca agus scipeáil sonraí teaghrán léitheoireachta don chás sin.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Is ionann seo agus beagán draíochta le: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Tiontaíonn sé sreangán go slice beart.
    /// Chun an slice beart a thiontú ar ais i slice sreang, úsáid an fheidhm [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SÁBHÁILTEACHT: fuaim CONST mar gheall transmute muid dhá chineál leis an leagan amach céanna
        unsafe { mem::transmute(self) }
    }

    /// Tiontaíonn sé slisne sreangán inathraithe go slice beart inathraithe.
    ///
    /// # Safety
    ///
    /// Caithfidh an té atá ag glaoch a chinntiú go bhfuil ábhar na slice bailí UTF-8 sula dtiocfaidh deireadh leis an iasacht agus go n-úsáidtear an `str` bunúsach.
    ///
    ///
    /// Is iompar neamhshainithe é `str` nach bhfuil a ábhar bailí UTF-8 a úsáid.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SÁBHÁILTEACHT: Is é an teilgthe ó `&str` go `&[u8]` sábháilte ó `str`
        // Tá an leagan amach céanna le `&[u8]` (ach libstd a dhéanamh ar an ráthaíocht).
        // Tá an iarchur pointeoir sábháilte ós rud é go dtagann sé ó thagairt inathraithe a ráthaítear a bheith bailí le haghaidh scríbhinní.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Athraíonn a slice teaghrán chuig pointeoir amh.
    ///
    /// Toisc gur slisne beart iad slisní sreinge, díríonn an pointeoir amh ar [`u8`].
    /// Beidh an pointeoir seo dírithe ar an gcéad bheart den slice sreang.
    ///
    /// Caithfidh an té atá ag glaoch a chinntiú nach scríobhtar chuig an bpointeoir ar ais riamh.
    /// Más gá duit a mutate an ábhar ar an slice teaghrán, a úsáid [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Tiontaíonn sé sreangán so-aistrithe go pointeoir amh.
    ///
    /// Toisc gur slisne beart iad slisní sreinge, díríonn an pointeoir amh ar [`u8`].
    /// Beidh an pointeoir seo dírithe ar an gcéad bheart den slice sreang.
    ///
    /// Is ortsa atá an fhreagracht a chinntiú nach ndéantar an slice sreang a mhodhnú ach ar bhealach a fhanfaidh sé bailí UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Tuairisceáin a subslice de `str`.
    ///
    /// Is é seo an rogha neamh-panicála seachas an `str` a innéacsú.
    /// Tuairisceáin [`None`] uair dóigh mbeadh oibríocht innéacsú coibhéiseach panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // innéacsanna nach bhfuil ar theorainneacha seicheamh UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // as teorainneacha
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Tuairisceáin a subslice mutable de `str`.
    ///
    /// Is é seo an rogha neamh-panicála seachas an `str` a innéacsú.
    /// Tuairisceáin [`None`] uair dóigh mbeadh oibríocht innéacsú coibhéiseach panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // fad ceart
    /// assert!(v.get_mut(0..5).is_some());
    /// // as teorainneacha
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Tuairisceáin an subslice unchecked de `str`.
    ///
    /// Is é seo an rogha eile neamhsheiceáilte seachas an `str` a innéacsú.
    ///
    /// # Safety
    ///
    /// Tá glaoiteoirí na feidhme seo freagrach go gcomhlíontar na réamhchoinníollacha seo:
    ///
    /// * Níor chóir go sáródh an t-innéacs tosaigh an t-innéacs deiridh;
    /// * Caithfidh innéacsanna a bheith laistigh de theorainneacha an tslis bhunaidh;
    /// * Caithfidh innéacsanna luí ar theorainneacha seicheamh UTF-8.
    ///
    /// Mura ndéanann sé sin, féadfaidh an tsreangán sreang a chuirtear ar ais tagairt do chuimhne neamhbhailí nó sárú a dhéanamh ar na invariants a chuirtear in iúl leis an gcineál `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `get_unchecked` a sheasamh;
        // tá an slice neamh-inchúlghairthe toisc gur tagairt shábháilte é `self`.
        // Tá an pointeoir ar ais sábháilte toisc go gcaithfidh impls `SliceIndex` a ráthú go bhfuil sé.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Filleann sé foshraith inathraithe, neamhsheiceáilte de `str`.
    ///
    /// Is é seo an rogha eile neamhsheiceáilte seachas an `str` a innéacsú.
    ///
    /// # Safety
    ///
    /// Tá glaoiteoirí na feidhme seo freagrach go gcomhlíontar na réamhchoinníollacha seo:
    ///
    /// * Níor chóir go sáródh an t-innéacs tosaigh an t-innéacs deiridh;
    /// * Caithfidh innéacsanna a bheith laistigh de theorainneacha an tslis bhunaidh;
    /// * Caithfidh innéacsanna luí ar theorainneacha seicheamh UTF-8.
    ///
    /// Mura ndéanann sé sin, féadfaidh an tsreangán sreang a chuirtear ar ais tagairt do chuimhne neamhbhailí nó sárú a dhéanamh ar na invariants a chuirtear in iúl leis an gcineál `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `get_unchecked_mut` a sheasamh;
        // tá an slice neamh-inchúlghairthe toisc gur tagairt shábháilte é `self`.
        // Tá an pointeoir ar ais sábháilte toisc go gcaithfidh impls `SliceIndex` a ráthú go bhfuil sé.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Cruthaíonn slice teaghrán ó slice teaghrán eile, ag seachaint seiceálacha sábháilteachta.
    ///
    /// De ghnáth ní mholtar é seo, bain úsáid as le rabhadh!Le haghaidh rogha shábháilte féach [`str`] agus [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Téann an slice nua seo ó `begin` go `end`, lena n-áirítear `begin` ach gan `end` a áireamh.
    ///
    /// Chun slice sreangán mutable a fháil ina ionad, féach an modh [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Tá glaoiteoirí na feidhme seo freagrach go gcomhlíontar trí réamhchoinníoll:
    ///
    /// * `begin` gan a bheith níos mó ná `end`.
    /// * `begin` agus caithfidh `end` a bheith ina suíomhanna beart laistigh den slice sreang.
    /// * `begin` agus caithfidh `end` luí ar theorainneacha seicheamh UTF-8.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `get_unchecked` a sheasamh;
        // tá an slice neamh-inchúlghairthe toisc gur tagairt shábháilte é `self`.
        // Tá an pointeoir ar ais sábháilte toisc go gcaithfidh impls `SliceIndex` a ráthú go bhfuil sé.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Cruthaíonn slice teaghrán ó slice teaghrán eile, ag seachaint seiceálacha sábháilteachta.
    /// Ní hé seo an molta go ginearálta, a úsáid le rabhadh!I gcás rogha eile sábháilte féach [`str`] agus [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Téann an slice nua seo ó `begin` go `end`, lena n-áirítear `begin` ach gan `end` a áireamh.
    ///
    /// Chun a fháil slice teaghrán immutable ina ionad, féach ar an modh [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Tá glaoiteoirí na feidhme seo freagrach go gcomhlíontar trí réamhchoinníoll:
    ///
    /// * `begin` gan a bheith níos mó ná `end`.
    /// * `begin` agus caithfidh `end` a bheith ina suíomhanna beart laistigh den slice sreang.
    /// * `begin` agus caithfidh `end` luí ar theorainneacha seicheamh UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `get_unchecked_mut` a sheasamh;
        // tá an slice neamh-inchúlghairthe toisc gur tagairt shábháilte é `self`.
        // Tá an pointeoir ar ais sábháilte toisc go gcaithfidh impls `SliceIndex` a ráthú go bhfuil sé.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Roinn slice sreang amháin ina dhá leath ag innéacs.
    ///
    /// Ba cheart go mbeadh an argóint, `mid`, mar fhritháireamh beart ó thús na sreinge.
    /// Caithfidh sé a bheith chomh maith ar an teorainn pointe cód UTF-8.
    ///
    /// An dá slices ais dul ó thús an slice teaghrán go `mid`, agus ó `mid` go dtí deireadh an slice teaghrán.
    ///
    /// Chun slisní sreanga inathraithe a fháil ina ionad, féach an modh [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics mura bhfuil `mid` ar theorainn phointe cód UTF-8, nó má tá sé thart ar dheireadh an phointe cód dheireanaigh den tsreangán sreangán.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // seiceálann is_char_boundary go bhfuil an t-innéacs i [0, .len()]
        if self.is_char_boundary(mid) {
            // SÁBHÁILTEACHT: díreach seiceáil go bhfuil `mid` ar theorainn char.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Roinn slice teaghrán inathraithe amháin ina dhá leath ag innéacs.
    ///
    /// Ba cheart go mbeadh an argóint, `mid`, mar fhritháireamh beart ó thús na sreinge.
    /// Caithfidh sé a bheith chomh maith ar an teorainn pointe cód UTF-8.
    ///
    /// An dá slices ais dul ó thús an slice teaghrán go `mid`, agus ó `mid` go dtí deireadh an slice teaghrán.
    ///
    /// Chun slisní sreinge dochorraithe a fháil ina ionad, féach an modh [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics mura bhfuil `mid` ar theorainn phointe cód UTF-8, nó má tá sé thart ar dheireadh an phointe cód dheireanaigh den tsreangán sreangán.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // seiceálann is_char_boundary go bhfuil an t-innéacs i [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SÁBHÁILTEACHT: díreach seiceáil go bhfuil `mid` ar theorainn char.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Tuairisceáin an iterator thar an [`char`] s de slice teaghrán.
    ///
    /// Mar éard a slice shraith de bailí UTF-8, is féidir linn a iterate trí slice teaghrán ag [`char`].
    /// Filleann an modh seo iteoir den sórt sin.
    ///
    /// Tá sé tábhachtach a mheabhrú go léiríonn [`char`] a scálach Luach Unicode, agus ní féidir comhoiriúnach do smaoineamh ar cad is 'character'.
    ///
    /// B`fhéidir gurb é an rud atá uait i ndáiríre an t-athrú ar bhraislí grapheme.
    /// Ní sholáthraíonn leabharlann chaighdeánach Rust an fheidhmiúlacht seo, seiceáil crates.io ina áit.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Cuimhnigh, b`fhéidir nach ionann [`char`] s agus do intuition faoi charachtair:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // ní 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Seoltar atriall ar ais thar na [`char`] de shlisne, agus a suíomhanna.
    ///
    /// Mar éard a slice shraith de bailí UTF-8, is féidir linn a iterate trí slice teaghrán ag [`char`].
    /// Tugann an modh seo atreorú den dá [`char`] seo ar ais, chomh maith lena suíomhanna beart.
    ///
    /// táirgeacht An iterator tuples.Tá an seasamh ar dtús, tá an [`char`] sa dara háit.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Cuimhnigh, b`fhéidir nach ionann [`char`] s agus do intuition faoi charachtair:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // ní (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // tabhair faoi deara an 3 anseo, thóg an carachtar deireanach dhá bheart
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Atreoraitheoir thar na bearta de shlisne.
    ///
    /// Toisc go bhfuil seicheamh beart comhdhéanta de sheicheamh beart, is féidir linn a aithris trí shlisne sreang le beart.
    /// Filleann an modh seo iteoir den sórt sin.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Scoilteann sreangán sreang de réir an spáis bháin.
    ///
    /// Fillfidh an t-iteoir a chuirtear ar ais slisní sreinge atá ina bhfo-slisní den tslis sreangán bunaidh, scartha le méid ar bith den spás bán.
    ///
    ///
    /// 'Whitespace' sainmhínítear é de réir théarmaí na Maoine Croí Díorthaithe Unicode `White_Space`.
    /// Más mian leat ach a scoilt ar ASCII spás bán ina ionad sin, a úsáid [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Breathnaítear ar gach cineál spáis bán:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Scoilteann sé sreangán le spás bán ASCII.
    ///
    /// Fillfidh an t-iteoir a chuirtear ar ais slisní sreinge atá ina bhfo-slisní den tslis teaghrán bunaidh, scartha le haon mhéid de spás bán ASCII.
    ///
    ///
    /// Chun scoilt le Unicode `Whitespace` ina ionad, bain úsáid as [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Breathnaítear ar gach cineál spáis bán ASCII:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Atriallóir thar línte sreinge, mar shlisíní sreinge.
    ///
    /// Línte a chríochnaigh le ceachtar línte nua (`\n`) nó aisfhilleadh le fotha líne (`\r\n`).
    ///
    /// Tá deireadh na líne deiridh roghnach.
    /// Fillfidh sreangán a chríochnaíonn le críochlíne deiridh na línte céanna le sreangán atá comhionann ar shlí eile gan deireadh líne dheiridh.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Ní theastaíonn deireadh deiridh na líne:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// An iterator thar na línte de shraith.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Seoltar atriall de `u16` ar ais thar an tsreang atá ionchódaithe mar UTF-16.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Filleann `true` má mheaitseálann an patrún tugtha le fo-shlisne den tsreangán seo.
    ///
    /// Tuairisceáin `false` mura ndéanann.
    ///
    /// Is féidir leis an [pattern] a bheith ina `&str`, [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Filleann `true` má mheaitseálann an patrún tugtha réimír den tsreangán seo.
    ///
    /// Tuairisceáin `false` mura ndéanann.
    ///
    /// Is féidir leis an [pattern] a bheith ina `&str`, [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Tuairisceáin `true` má mheaitseálann an patrún tugtha iarmhír den tsreangán seo.
    ///
    /// Tuairisceáin `false` mura ndéanann.
    ///
    /// Is féidir leis an [pattern] a bheith ina `&str`, [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Filleann sé an t-innéacs beart den chéad charachtar den tsreangán sreang seo a oireann don phatrún.
    ///
    /// Filleann [`None`] mura bhfuil an patrún comhoiriúnach.
    ///
    /// Is féidir leis an [pattern] a bheith ina `&str`, [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// patrúin shimplí:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// patrúin níos casta ag baint úsáide pointe saor ó stíl agus dúnadh:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Gan an patrún a aimsiú:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Filleann sé an t-innéacs beart don chéad charachtar den mheaitseáil is ceart den phatrún sa slice sreang seo.
    ///
    /// Filleann [`None`] mura bhfuil an patrún comhoiriúnach.
    ///
    /// Is féidir leis an [pattern] a bheith ina `&str`, [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// patrúin shimplí:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Patrúin níos casta le dúnadh:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Gan an patrún a aimsiú:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Atreoraitheoir os cionn substrings an tsreangán seo, scartha le carachtair a mheaitseálann patrún.
    ///
    /// Is féidir leis an [pattern] a bheith ina `&str`, [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iompar Iterator
    ///
    /// [`DoubleEndedIterator`] a bheidh san atreoraitheoir ar ais má cheadaíonn an patrún cuardach droim ar ais agus má tá na heilimintí céanna mar thoradh ar chuardach forward/reverse.
    /// Tá sé seo fíor i gcás, m.sh., [`char`], ach ní i gcás `&str`.
    ///
    /// Má cheadaíonn an patrún a cuardach droim ar ais ach b'fhéidir a chuid torthaí difriúil thagann aníos sa chuardach ar aghaidh, is féidir leis an modh [`rsplit`] a úsáid.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// patrúin shimplí:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Más slice de chars an patrún, roinn ar gach tarlú de cheann ar bith de na carachtair:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Patrún níos casta, ag úsáid dúnadh:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Má tá teaghrán Deighilteoirí tadhlach il, beidh tú ag deireadh suas le teaghráin folamh sa aschur:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Tá deighilteoirí tadhlacha scartha leis an sreangán folamh.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Tá deighilteoirí ag tús nó ag deireadh sreangán téada folamh.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Nuair a úsáidtear an sreangán folamh mar dheighilteoir, scarann sé gach carachtar sa téad, mar aon le tús agus deireadh na sreinge.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// D`fhéadfadh iompar iontais a bheith mar thoradh ar deighilteoirí tadhlacha nuair a úsáidtear spás bán mar an deighilteoir.Tá an cód seo ceart:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Déanann sé _not_ duit:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Úsáid [`split_whitespace`] don iompar seo.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Atreoraitheoir os cionn substrings an tsreangán seo, scartha le carachtair a mheaitseálann patrún.
    /// Difriúil ón iterator tháirgtear trí `split` sa mhéid is go bhfágann `split_inclusive` an chuid mheaitseáil mar an Críochnaitheoir ar an bhfotheaghrán.
    ///
    ///
    /// Is féidir leis an [pattern] a bheith ina `&str`, [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Má tá an ghné dheireanach den teaghrán atá, beidh ghné sin a chur san áireamh leis an Críochnaitheoir an bhfotheaghrán roimhe sin.
    /// Is é an substring sin an mhír dheiridh a chuir an t-atriallóir ar ais.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Atreoraitheoir os cionn substrings an tsreangán teaghrán tugtha, scartha le carachtair a mheaitseálann patrún agus a chuirtear in ord droim ar ais.
    ///
    /// Is féidir leis an [pattern] a bheith ina `&str`, [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iompar Iterator
    ///
    /// Éilíonn an t-atreoraitheoir ar ais go dtacaíonn an patrún le cuardach droim ar ais, agus gur [`DoubleEndedIterator`] a bheidh ann má tá na heilimintí céanna mar thoradh ar chuardach forward/reverse.
    ///
    ///
    /// Le haghaidh atriall ón tosaigh, is féidir an modh [`split`] a úsáid.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// patrúin shimplí:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Patrún níos casta, ag úsáid dúnadh:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Atreoraitheoir os cionn substrings an tsreangán teaghrán tugtha, scartha le carachtair a mheaitseálann patrún.
    ///
    /// Is féidir leis an [pattern] a bheith ina `&str`, [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Coibhéiseach le [`split`], eisceadh go bhfuil an t-substring trailing ndearna más folamh.
    ///
    /// [`split`]: str::split
    ///
    /// Is féidir an modh seo a úsáid le haghaidh sonraí sreinge atá _terminated_, seachas _separated_ de réir patrún.
    ///
    /// # Iompar Iterator
    ///
    /// [`DoubleEndedIterator`] a bheidh san atreoraitheoir ar ais má cheadaíonn an patrún cuardach droim ar ais agus má tá na heilimintí céanna mar thoradh ar chuardach forward/reverse.
    /// Tá sé seo fíor i gcás, m.sh., [`char`], ach ní i gcás `&str`.
    ///
    /// Má cheadaíonn an patrún cuardach droim ar ais ach d`fhéadfadh go mbeadh a thorthaí difriúil ó réamhchuardach, is féidir an modh [`rsplit_terminator`] a úsáid.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Atreoraitheoir os cionn substrings de `self`, scartha le carachtair a mheaitseálann patrún agus a chuirtear in ord droim ar ais.
    ///
    /// Is féidir leis an [pattern] a bheith ina `&str`, [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Coibhéiseach le [`split`], eisceadh go bhfuil an t-substring trailing ndearna más folamh.
    ///
    /// [`split`]: str::split
    ///
    /// Is féidir an modh seo a úsáid le haghaidh sonraí sreinge atá _terminated_, seachas _separated_ de réir patrún.
    ///
    /// # Iompar Iterator
    ///
    /// Éilíonn an t-atreoraitheoir ar ais go dtacaíonn an patrún le cuardach droim ar ais, agus go mbeidh deireadh dúbailte leis má bhíonn na heilimintí céanna mar thoradh ar chuardach forward/reverse.
    ///
    ///
    /// Le haghaidh atriall ón tosaigh, is féidir an modh [`split_terminator`] a úsáid.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Atreoraitheoir os cionn substrings an tslis sreang a thugtar, scartha le patrún, teoranta do fhilleadh ar fhormhór na míreanna `n`.
    ///
    /// Má chuirtear substrings `n` ar ais, beidh an chuid eile den tsreang sa fho-alt deireanach (an `n`th substring).
    ///
    /// Is féidir leis an [pattern] a bheith ina `&str`, [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iompar Iterator
    ///
    /// Ní bheidh dhá chríoch ag an atriall a chuirtear ar ais, toisc nach bhfuil sé éifeachtach tacú leis.
    ///
    /// Má cheadaíonn an patrún cuardach droim ar ais, is féidir an modh [`rsplitn`] a úsáid.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// patrúin shimplí:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Patrún níos casta, ag úsáid dúnadh:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Atreoraitheoir os cionn substrings an tsreangán seo, scartha le patrún, ag tosú ó dheireadh na sreinge, teoranta do fhilleadh ar a laghad míreanna `n`.
    ///
    ///
    /// Má chuirtear substrings `n` ar ais, beidh an chuid eile den tsreang sa fho-alt deireanach (an `n`th substring).
    ///
    /// Is féidir leis an [pattern] a bheith ina `&str`, [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iompar Iterator
    ///
    /// Ní bheidh dhá chríoch ag an atriall a chuirtear ar ais, toisc nach bhfuil sé éifeachtach tacú leis.
    ///
    /// Maidir le scoilteadh ó thaobh tosaigh, is féidir leis an modh [`splitn`] a úsáid.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// patrúin shimplí:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Patrún níos casta, ag úsáid dúnadh:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Scoilteann sé an tsreang ar an gcéad tarlú den teimpléad sonraithe agus cuireann sé an réimír ar ais roimh an teimpléad agus an iarmhír i ndiaidh teorannaithe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Scoilteann sé an tsreang nuair a tharla an teimpléad sonraithe go deireanach agus cuireann sé an réimír ar ais roimh an teimpléad agus an iarmhír i ndiaidh teorannaithe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Atriallóir os cionn na lasáin dhícheangailte de phatrún laistigh den tsreangán teaghrán a thugtar.
    ///
    /// Is féidir leis an [pattern] a bheith ina `&str`, [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iompar Iterator
    ///
    /// [`DoubleEndedIterator`] a bheidh san atreoraitheoir ar ais má cheadaíonn an patrún cuardach droim ar ais agus má tá na heilimintí céanna mar thoradh ar chuardach forward/reverse.
    /// Tá sé seo fíor i gcás, m.sh., [`char`], ach ní i gcás `&str`.
    ///
    /// Má cheadaíonn an patrún cuardach droim ar ais ach d`fhéadfadh go mbeadh a thorthaí difriúil ó réamhchuardach, is féidir an modh [`rmatches`] a úsáid.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// D'eascair atriall thar na lasáin dhícheangailte de phatrún laistigh den tsreangán seo, in ord droim ar ais.
    ///
    /// Is féidir leis an [pattern] a bheith ina `&str`, [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iompar Iterator
    ///
    /// Éilíonn an t-atreoraitheoir ar ais go dtacaíonn an patrún le cuardach droim ar ais, agus gur [`DoubleEndedIterator`] a bheidh ann má tá na heilimintí céanna mar thoradh ar chuardach forward/reverse.
    ///
    ///
    /// I gcás iterating ó thaobh tosaigh, is féidir leis an modh [`matches`] a úsáid.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Atreoraitheoir thar na lasáin dhícheangailte patrún laistigh den sreangán seo chomh maith leis an innéacs a dtosaíonn an cluiche.
    ///
    /// Maidir le lasáin `pat` laistigh de `self` a dhéanann forluí, ní chuirtear ar ais ach na hinnéacsanna a fhreagraíonn don chéad mheaitseáil.
    ///
    /// Is féidir leis an [pattern] a bheith ina `&str`, [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iompar Iterator
    ///
    /// [`DoubleEndedIterator`] a bheidh san atreoraitheoir ar ais má cheadaíonn an patrún cuardach droim ar ais agus má tá na heilimintí céanna mar thoradh ar chuardach forward/reverse.
    /// Tá sé seo fíor i gcás, m.sh., [`char`], ach ní i gcás `&str`.
    ///
    /// Má cheadaíonn an patrún cuardach droim ar ais ach d`fhéadfadh go mbeadh a thorthaí difriúil ó réamhchuardach, is féidir an modh [`rmatch_indices`] a úsáid.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // ach an chéad `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Cuireadh athrá ar mheaitseálacha dícheangailte patrún laistigh de `self`, in ord droim ar ais mar aon le hinnéacs an mheaitseála.
    ///
    /// Maidir le cluichí `pat` laistigh de `self` a dhéanann forluí, ní chuirtear ar ais ach na hinnéacsanna a fhreagraíonn don chluiche deireanach.
    ///
    /// Is féidir leis an [pattern] a bheith ina `&str`, [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iompar Iterator
    ///
    /// Éilíonn an t-atreoraitheoir ar ais go dtacaíonn an patrún le cuardach droim ar ais, agus gur [`DoubleEndedIterator`] a bheidh ann má tá na heilimintí céanna mar thoradh ar chuardach forward/reverse.
    ///
    ///
    /// Le haghaidh atriall ón tosaigh, is féidir an modh [`match_indices`] a úsáid.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // ach an `aba` deireanach
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Filltear sliseog sreangáin le spás bán le rá agus le rianú bainte.
    ///
    /// 'Whitespace' sainmhínítear é de réir théarmaí na Maoine Croí Díorthaithe Unicode `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Filltear sliseog sreangáin agus baintear an spás bán as.
    ///
    /// 'Whitespace' sainmhínítear é de réir théarmaí na Maoine Croí Díorthaithe Unicode `White_Space`.
    ///
    /// # Treoshuíomh téacs
    ///
    /// Is seicheamh beart é sreang.
    /// `start` sa chomhthéacs seo ciallaíonn sé an chéad suíomh den téad beart sin;i gcás teanga chlé go deas mar Bhéarla nó Rúisis, beidh sé seo ar thaobh na láimhe clé, agus i gcás teangacha ar dheis go clé mar Araibis nó Eabhrais, beidh sé seo ar an taobh dheis.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Filleann sé sreangán sreangáin agus baintear an spás bán as.
    ///
    /// 'Whitespace' sainmhínítear é de réir théarmaí na Maoine Croí Díorthaithe Unicode `White_Space`.
    ///
    /// # Treoshuíomh téacs
    ///
    /// Is seicheamh beart é sreang.
    /// `end` sa chomhthéacs seo ciallaíonn sé suíomh deireanach na sreinge beart sin;do theanga chlé go deas cosúil le Béarla Rúisis nó, beidh sé seo a bheith thaobh na láimhe deise, agus do theangacha deas go clé nós Araibis Eabhrais nó, beidh sé seo an taobh clé.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Filltear sliseog sreangáin agus baintear an spás bán as.
    ///
    /// 'Whitespace' sainmhínítear é de réir théarmaí na Maoine Croí Díorthaithe Unicode `White_Space`.
    ///
    /// # Treoshuíomh téacs
    ///
    /// Is seicheamh beart é sreang.
    /// 'Left' sa chomhthéacs seo ciallaíonn an chéad staid den teaghrán beart;i gcás teanga mar Araibis nó Eabhrais atá `ceart go clé` seachas `clé go deas`, is é seo an taobh _right_, ní an taobh clé.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Filleann sé sreangán sreangáin agus baintear an spás bán as.
    ///
    /// 'Whitespace' sainmhínítear é de réir théarmaí na Maoine Croí Díorthaithe Unicode `White_Space`.
    ///
    /// # Treoshuíomh téacs
    ///
    /// Is seicheamh beart é sreang.
    /// 'Right' sa chomhthéacs seo ciallaíonn sé suíomh deireanach na sreinge beart sin;i gcás teanga mar Araibis nó Eabhrais atá `ceart go clé` seachas `clé go deas`, is í seo an taobh _left_, ní an ceart.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Filltear sliseog sreangáin leis na réimíreanna agus na hiarmhíreanna go léir a mheaitseálann patrún a baineadh arís agus arís eile.
    ///
    /// Is féidir leis an [pattern] a bheith ina [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// patrúin shimplí:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Patrún níos casta, ag úsáid dúnadh:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Cuimhnigh ar an gcluiche is luaithe atá ar eolas, ceartaigh é thíos más rud é
            // tá an cluiche deireanach difriúil
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SÁBHÁILTEACHT: Is eol do `Searcher` innéacsanna bailí a chur ar ais.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Seoltar sreangán ar ais leis na réimíreanna go léir a mheaitseálann patrún a baineadh arís agus arís eile.
    ///
    /// Is féidir leis an [pattern] a bheith ina `&str`, [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Treoshuíomh téacs
    ///
    /// Is seicheamh beart é sreang.
    /// `start` sa chomhthéacs seo ciallaíonn sé an chéad suíomh den téad beart sin;i gcás teanga chlé go deas mar Bhéarla nó Rúisis, beidh sé seo ar thaobh na láimhe clé, agus i gcás teangacha ar dheis go clé mar Araibis nó Eabhrais, beidh sé seo ar an taobh dheis.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SÁBHÁILTEACHT: Is eol do `Searcher` innéacsanna bailí a chur ar ais.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Tuairisceáin a slice teaghrán leis an réimír a bhaint.
    ///
    /// Má thosaíonn an tsreang leis an bpatrún `prefix`, filleann sí ar ais i ndiaidh an réimír, fillte i `Some`.
    /// Murab ionann agus `trim_start_matches`, déanann an modh seo an réimír a bhaint go díreach uair amháin.
    ///
    /// Mura dtosaíonn an tsreang le `prefix`, filleann `None`.
    ///
    /// Is féidir leis an [pattern] a bheith ina `&str`, [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Filleann slice sreang agus baintear an iarmhír.
    ///
    /// Má chríochnaíonn an tsreang leis an bpatrún `suffix`, filleann sí an foshraith roimh an iarmhír, fillte i `Some`.
    /// Murab ionann agus `trim_end_matches` aistriú as an modh seo an iarmhír go díreach aon uair amháin.
    ///
    /// Mura gcríochnaíonn an tsreang le `suffix`, filleann `None`.
    ///
    /// Is féidir leis an [pattern] a bheith ina `&str`, [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Filltear sreangán ar ais leis na hiarmhíreanna go léir a mheaitseálann patrún a baineadh arís agus arís eile.
    ///
    /// Is féidir leis an [pattern] a bheith ina `&str`, [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Treoshuíomh téacs
    ///
    /// Is seicheamh beart é sreang.
    /// `end` sa chomhthéacs seo ciallaíonn sé suíomh deireanach na sreinge beart sin;do theanga chlé go deas cosúil le Béarla Rúisis nó, beidh sé seo a bheith thaobh na láimhe deise, agus do theangacha deas go clé nós Araibis Eabhrais nó, beidh sé seo an taobh clé.
    ///
    ///
    /// # Examples
    ///
    /// patrúin shimplí:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Patrún níos casta, ag úsáid dúnadh:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SÁBHÁILTEACHT: Is eol do `Searcher` innéacsanna bailí a chur ar ais.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Seoltar sreangán ar ais leis na réimíreanna go léir a mheaitseálann patrún a baineadh arís agus arís eile.
    ///
    /// Is féidir leis an [pattern] a bheith ina `&str`, [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Treoshuíomh téacs
    ///
    /// Is seicheamh beart é sreang.
    /// 'Left' sa chomhthéacs seo ciallaíonn an chéad staid den teaghrán beart;i gcás teanga mar Araibis nó Eabhrais atá `ceart go clé` seachas `clé go deas`, is é seo an taobh _right_, ní an taobh clé.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Filltear sreangán ar ais leis na hiarmhíreanna go léir a mheaitseálann patrún a baineadh arís agus arís eile.
    ///
    /// Is féidir leis an [pattern] a bheith ina `&str`, [`char`], slice de [`char`] s, nó feidhm nó dúnadh a chinneann an bhfuil carachtar comhoiriúnach.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Treoshuíomh téacs
    ///
    /// Is seicheamh beart é sreang.
    /// 'Right' sa chomhthéacs seo ciallaíonn sé suíomh deireanach na sreinge beart sin;i gcás teanga mar Araibis nó Eabhrais atá `ceart go clé` seachas `clé go deas`, is í seo an taobh _left_, ní an ceart.
    ///
    ///
    /// # Examples
    ///
    /// patrúin shimplí:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Patrún níos casta, ag úsáid dúnadh:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Parses an slice sreang seo i gcineál eile.
    ///
    /// Toisc go bhfuil `parse` chomh ginearálta, féadfaidh sé fadhbanna a chruthú le tátal cineáil.
    /// Dá bhrí sin, tá `parse` ar cheann den bheagán uaireanta a fheicfidh tú an chomhréir ar a dtugtar an 'turbofish' go grámhar: `::<>`.
    ///
    /// Cuidíonn sé seo leis an algartam tátail tuiscint a fháil go sonrach ar an gcineál atá tú ag iarraidh a pharsáil.
    ///
    /// `parse` is féidir é a pharsáil in aon chineál a chuireann an [`FromStr`] trait i bhfeidhm.
    ///

    /// # Errors
    ///
    /// Fillfidh [`Err`] mura féidir an slice sreang seo a pharsáil sa chineál atá ag teastáil.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Ag baint úsáide as an 'turbofish' in ionad anótáil `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Mainneachtain pharsáil:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Seiceálacha an bhfuil gach carachtar sa téad seo laistigh de raon ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Is féidir linn gach beart a láimhseáil mar charachtar anseo: tosaíonn gach carachtar ilbhreise le beart nach bhfuil sa raon ascii, mar sin stadfaimid ansin cheana féin.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Seiceálacha go bhfuil dhá teaghráin cás-neamhíogair mheaitseáil ASCII.
    ///
    /// Mar an gcéanna le `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, ach gan temporaries a leithdháileadh agus a chóipeáil.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Athraíonn sé an tsreang seo go coibhéis cás uachtair ASCII atá i bhfeidhm.
    ///
    /// Déantar litreacha ASCII 'a' go 'z' a mhapáil go 'A' go 'Z', ach níl aon athrú ar litreacha neamh-ASCII.
    ///
    /// Chun luach uachtarach nua a thabhairt ar ais gan an ceann atá ann a mhodhnú, úsáid [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // SÁBHÁILTEACHT: sábháilte toisc go ndéanaimid dhá chineál a aistriú leis an leagan amach céanna.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Athraíonn an teaghrán a ASCII cás íochtair coibhéiseach in-áit.
    ///
    /// ASCII litreacha 'A' go 'Z' mapáilte chuig 'a' go 'z', ach tá litreacha nach ASCII gan athrú.
    ///
    /// Chun luach íslithe nua a thabhairt ar ais gan an ceann atá ann a mhodhnú, úsáid [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // SÁBHÁILTEACHT: sábháilte toisc go ndéanaimid dhá chineál a aistriú leis an leagan amach céanna.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Cuir iteoir ar ais a éalaíonn gach char in `self` le [`char::escape_debug`].
    ///
    ///
    /// Note: ní éalófar ach códphointí leathnaithe grapheme a thosaíonn ar an tsreang.
    ///
    /// # Examples
    ///
    /// Mar iteoir:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ag baint úsáide as `println!` go díreach:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Tá an dá comhionann le:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Ag baint úsáide as `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Cuir iteoir ar ais a éalaíonn gach char in `self` le [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Mar iteoir:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ag baint úsáide as `println!` go díreach:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Tá an dá comhionann le:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Ag baint úsáide as `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Fill ar ais ar iterator a éalaíonn gach char i `self` le [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Mar iteoir:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ag baint úsáide as `println!` go díreach:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Tá an dá comhionann le:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Ag baint úsáide as `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Cruthaíonn str folamh
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Cruthaíonn str folamh mutable
    #[inline]
    fn default() -> Self {
        // SÁBHÁILTEACHT: Tá an téad folamh bailí UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Cineál fn in-ainmnithe, clónáilte
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // SÁBHÁILTEACHT: Ní sábháilte
        unsafe { from_utf8_unchecked(bytes) }
    };
}