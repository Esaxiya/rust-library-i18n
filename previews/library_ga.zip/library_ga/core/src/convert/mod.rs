//! Traits do conversions idir cineálacha.
//!
//! Soláthraíonn an traits sa mhodúl seo bealach le tiontú ó chineál amháin go cineál eile.
//! Tá cuspóir difriúil ag gach trait:
//!
//! - an trait [`AsRef`] chur i ngníomh do conversions saor tagartha-- do tagartha
//! - an trait [`AsMut`] chur i ngníomh do saor conversions mutable-go-mutable
//! - Cuir an [`From`] trait i bhfeidhm chun tiontaithe luach-go-luach a ídiú
//! - an trait [`Into`] chur i ngníomh do-luach-le luach conversions Tógann le cineálacha lasmuigh den crate atá ann faoi láthair
//! - Iompraíonn an [`TryFrom`] agus [`TryInto`] traits cosúil le [`From`] agus [`Into`], ach ba cheart iad a chur i bhfeidhm nuair a theipeann ar an tiontú.
//!
//! An traits sa mhodúl seo is minic a úsáidtear mar trait bounds as feidhmeanna ginearálta den sórt sin le hargóintí de chineálacha éagsúla dtugtar tacaíocht.Féach ar dhoiciméadú gach trait do shamplaí.
//!
//! Mar údar leabharlainne, ba chóir duit fearr i gcónaí chun feidhme [`From<T>`][`From`] nó [`TryFrom<T>`][`TryFrom`] in ionad [`Into<U>`][`Into`] nó [`TryInto<U>`][`TryInto`], mar [`From`] agus [`TryFrom`] fáil níos mó solúbthachta agus a thairiscint coibhéiseach [`Into`] nó [`TryInto`] implementations saor in aisce, a bhuíochas sin do chur i bhfeidhm blaincéad sa leabharlann caighdeánach.
//! Agus iad ag leagan roimh Rust 1.41, d'fhéadfadh go mbeadh gá [`Into`] nó [`TryInto`] a chur i bhfeidhm go díreach nuair a athrú do chineál lasmuigh den crate atá ann faoi láthair.
//!
//! # Generic Implementations
//!
//! - [`AsRef`] agus dí-cheartú [`AsMut`] más tagairt é an cineál istigh
//! - [`From`]`<U>do T` tuiscint [`Into`]`</u><T><U>do U`</u>
//! - Tugann [`TryFrom`]`<U>do T` le tuiscint [`TryInto`]`</u><T><U>le haghaidh U`</u>
//! - [`From`] agus tá [`Into`] athfhillteach, rud a chiallaíonn gur féidir le gach cineál `into` iad féin agus `from` iad féin
//!
//! Féach gach trait le haghaidh samplaí úsáide.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// An fheidhm aitheantais.
///
/// Tá dhá rudaí tábhachtacha a nóta faoi fheidhm seo:
///
/// - Níl sé i gcónaí comhionann le dúnadh nós `|x| x`, toisc go bhféadann an dúnadh chomhéigniú `x` i ndáil le cineál eile.
///
/// - Bogann sé an t-ionchur `x` ar aghaidh chuig an fheidhm.
///
/// Cé go bhféadfadh sé cosúil aisteach go mbeadh feidhm go tuairisceáin díreach ar ais an t-ionchur, tá roinnt úsáidí suimiúla.
///
///
/// # Examples
///
/// Ag baint úsáide as `identity` chun aon rud a dhéanamh i seicheamh feidhmeanna suimiúla eile:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Lig dúinn ligean gur feidhm spéisiúil é ceann a chur leis.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// `identity` a úsáid mar bhunchás "do nothing" i gcoinníollach:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // An bhfuil rudaí níos suimiúla ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Ag baint úsáide as `identity` a choinneáil ar an `Some` leaganacha de iterator de `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Úsáidtear é chun tiontú saor tagartha-tagartha a dhéanamh.
///
/// Tá an trait seo cosúil le [`AsMut`] a úsáidtear chun tiontú idir tagairtí inathraithe.
/// Más gá duit a dhéanamh ar chomhshó costasach tá sé níos fearr a chur chun feidhme [`From`] le cineál `&T` nó scríobh feidhm saincheaptha.
///
/// `AsRef` tá an síniú céanna aige le [`Borrow`], ach tá [`Borrow`] difriúil i mbeagán gnéithe:
///
/// - Murab ionann agus `AsRef`, tá impl blaincéad ag [`Borrow`] d`aon `T`, agus is féidir é a úsáid chun tagairt nó luach a ghlacadh.
/// - [`Borrow`] Éilíonn freisin go bhfuil [`Hash`], [`Eq`] agus [`Ord`] do luach a fuarthas ar iasacht coibhéiseach leo sin den luach faoi úinéireacht.
/// Ar an gcúis sin, más mian leat a fháil ar iasacht ach réimse amháin de struct is féidir leat a chur i bhfeidhm `AsRef`, ach ní [`Borrow`].
///
/// **Note: Ní féidir go dteipfidh ar an trait seo **.Más féidir go dteipfidh ar an gcomhshó, bain úsáid as modh tiomnaithe a fhilleann [`Option<T>`] nó [`Result<T, E>`].
///
/// # Generic Implementations
///
/// - `AsRef` auto-dereferences má tá an cineál istigh tagairt nó tagairt mutable (eg: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Trí trait bounds a úsáid is féidir linn glacadh le hargóintí de chineálacha éagsúla chomh fada agus is féidir iad a thiontú go cineál sonraithe `T`.
///
/// Mar shampla: Trí fheidhm chineálach a chruthú a thógann `AsRef<str>` cuirimid in iúl gur mhaith linn glacadh le gach tagairt is féidir a thiontú go [`&str`] mar argóint.
/// Ós rud é go gcuireann [`String`] agus [`&str`] `AsRef<str>` i bhfeidhm is féidir linn glacadh leis an dá cheann mar argóint ionchuir.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Déanann an tiontú.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Úsáidtear é chun tiontú tagartha saor in-aistrithe a dhéanamh.
///
/// Tá sé seo cosúil leis trait [`AsRef`] ach a úsáidtear le haghaidh athrú idir tagairtí mutable.
/// Más gá duit tiontú costasach a dhéanamh is fearr [`From`] a chur i bhfeidhm le cineál `&mut T` nó feidhm shaincheaptha a scríobh.
///
/// **Note: Ní féidir go dteipfidh ar an trait seo **.Más féidir go dteipfidh ar an gcomhshó, bain úsáid as modh tiomnaithe a fhilleann [`Option<T>`] nó [`Result<T, E>`].
///
/// # Generic Implementations
///
/// - `AsMut` auto-dereferences má tá an cineál istigh tagairt mutable (eg: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Ag baint úsáide as `AsMut` mar trait bound le haghaidh feidhm chineálach is féidir linn glacadh le gach tagairt inathraithe is féidir a thiontú go cineál `&mut T`.
/// Toisc go gcuireann [`Box<T>`] `AsMut<T>` i bhfeidhm is féidir linn feidhm `add_one` a scríobh a thógann gach argóint is féidir a thiontú go `&mut u64`.
/// Toisc chuireann [`Box<T>`] `AsMut<T>`, glacann `add_one` argóintí den chineál `&mut Box<u64>` chomh maith:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Déanann an tiontú.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// A comhshó-luach-go luach a ídíonn an luach ionchur.A mhalairt de [`From`].
///
/// Ba cheart go seachnófaí [`Into`] a chur i bhfeidhm agus [`From`] a chur i bhfeidhm ina ionad.
/// Cur Chun Feidhme [`From`] Soláthraíonn huathoibríoch amháin le cur i bhfeidhm [`Into`] buíochas le cur i bhfeidhm blaincéad sa leabharlann caighdeánach.
///
/// B`fhearr leat [`Into`] a úsáid thar [`From`] agus trait bounds á shonrú ar fheidhm chineálach lena chinntiú nach féidir cineálacha nach gcuireann ach [`Into`] i bhfeidhm a úsáid freisin.
///
/// **Note: Ní féidir go dteipfidh ar an trait seo **.Más féidir an claochlú theipeann, úsáid [`TryInto`].
///
/// # Generic Implementations
///
/// - [`From`]`<T>le haghaidh U` intuigthe `Into<U> for T`
/// - [`Into`] tá sé athfhillteach, rud a chiallaíonn go gcuirtear `Into<T> for T` i bhfeidhm
///
/// # Cur i bhfeidhm [`Into`] do conversions do chineálacha seachtracha i seanleaganacha de Rust
///
/// Roimh Rust 1.41, mura raibh an cineál ceann scríbe mar chuid den crate reatha ansin ní fhéadfá [`From`] a chur i bhfeidhm go díreach.
/// Mar shampla, a chur cód seo:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Beidh sé seo theipeann a thiomsú i leaganacha níos sine den teanga mar rialacha orphaning Rust ar úsáidtear chun bheith ina beagán níos dian.
/// Chun sheachbhóthar sin, d'fhéadfaí tú a chur i bhfeidhm go díreach [`Into`]:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Tá sé tábhachtach a thuiscint nach soláthraíonn [`Into`] cur chun feidhme [`From`] (mar a dhéanann [`From`] le [`Into`]).
/// Dá bhrí sin, ba chóir duit iarracht i gcónaí a chur [`From`] chur i bhfeidhm agus ansin thagann ar ais go dtí [`Into`] mura féidir [`From`] a chur i bhfeidhm.
///
/// # Examples
///
/// [`String`] uirlisí [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// D'fhonn a chur in iúl go ba mhaith linn feidhm cineálach a ghlacadh gach argóint is féidir a thiontú go chineál sonraithe `T`, is féidir linn a úsáid le bound trait de [`Into`]`<T>`.
///
/// Mar shampla: An `is_hello` fheidhm Glacann gach argóint is féidir iad a chomhshó ina [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Déanann an tiontú.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Úsáidtear chun tiontaithe luach-go-luach a dhéanamh agus an luach ionchuir á ídiú.Is é an t-cómhalartach [`Into`].
///
/// Ba chóir gurbh fhearr i gcónaí `From` a chur i bhfeidhm thar [`Into`] toisc go gcuireann `From` a chur i bhfeidhm go huathoibríoch le [`Into`] a bhuíochas do chur i bhfeidhm na blaincéad sa leabharlann chaighdeánach.
///
///
/// Ná cuir [`Into`] i bhfeidhm ach amháin nuair a bhíonn tú ag díriú ar leagan roimh Rust 1.41 agus ag athrú go cineál lasmuigh den crate reatha.
/// `From` ní raibh sé in ann na cineálacha tiontaithe seo a dhéanamh i leaganacha níos luaithe mar gheall ar rialacha dílleachta Rust.
/// Féach [`Into`] le haghaidh tuilleadh sonraí.
///
/// B`fhearr le [`Into`] a úsáid ná `From` a úsáid agus trait bounds á shonrú ar fheidhm chineálach.
/// Is féidir Sa tslí seo, cineálacha a chur i bhfeidhm go díreach [`Into`] a úsáid mar argóintí chomh maith.
///
/// Tá an `From` an-úsáideach freisin agus iad i mbun láimhseáil earráid.Nuair a thógáil feidhm atá in ann mainneachtain, beidh an cineál ar ais go ginearálta ar an fhoirm `Result<T, E>`.
/// Déanann an `From` trait láimhseáil earráide a shimpliú trí chead a thabhairt d`fheidhm cineál earráide amháin a chuimsiú a chuimsíonn ilchineálacha earráide.Féach an roinn "Examples" agus [the book][book] le haghaidh tuilleadh sonraí.
///
/// **Note: Ní féidir go dteipfidh ar an trait seo **.Más féidir an claochlú theipeann, úsáid [`TryFrom`].
///
/// # Generic Implementations
///
/// - `From<T> for U` Ciallaíonn [`Into`]`<U>do T`</u>
/// - `From` tá sé athfhillteach, rud a chiallaíonn go gcuirtear `From<T> for T` i bhfeidhm
///
/// # Examples
///
/// [`String`] i bhfeidhm `From<&str>`:
///
/// Déantar tiontú sainráite ó `&str` go Teaghrán:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Agus láimhseáil earráide á déanamh agat is minic a bhíonn sé úsáideach `From` a chur i bhfeidhm do do chineál earráide féin.
/// Trí chineálacha bunúsacha earráide a thiontú go dtí ár gcineál earráide saincheaptha féin a chuimsíonn an cineál earráide bunúsach, is féidir linn cineál earráide amháin a thabhairt ar ais gan faisnéis a chailleadh faoin mbunchúis.
/// An t-oibreoir '?' athraíonn go huathoibríoch ar an gcineál earráid is bun go dtí ár chineál earráide saincheaptha trí ghlaoch `Into<CliError>::into` a chuirtear ar fáil go huathoibríoch nuair a chur i bhfeidhm `From`.
/// An tiomsaitheoir ansin infers ar cheart cur i bhfeidhm `Into` a úsáid.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Déanann an tiontú.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Iarracht ar chomhshó a ídíonn `self`, a d`fhéadfadh a bheith costasach nó nach mbeadh.
///
/// De ghnáth níor cheart d`údair leabharlainne an trait seo a chur i bhfeidhm go díreach, ach b`fhearr leo an [`TryFrom`] trait a chur i bhfeidhm, a thairgeann níos mó solúbthachta agus a sholáthraíonn cur chun feidhme coibhéiseach `TryInto` saor in aisce, a bhuíochas le forfheidhmiú blaincéad sa leabharlann chaighdeánach.
/// Le haghaidh tuilleadh faisnéise air seo, féach na cáipéisí le haghaidh [`Into`].
///
/// # `TryInto` a chur i bhfeidhm
///
/// Fulaingíonn sé seo na srianta agus an réasúnaíocht chéanna le cur i bhfeidhm [`Into`], féach ansin le haghaidh sonraí.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// An cineál a cuireadh ar ais i gcás earráide tiontaithe.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Déanann an tiontú.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Athruithe simplí agus sábháilte de chineál a d`fhéadfadh go dteipfeadh orthu ar bhealach rialaithe faoi chúinsí áirithe.Is cómhalartach [`TryInto`] é.
///
/// Tá sé seo úsáideach agus tú ag déanamh comhshó cineáil a d`fhéadfadh go n-éireodh go fánach leis ach a bhféadfadh láimhseáil speisialta a bheith ag teastáil uaidh freisin.
/// Mar shampla, níl aon bhealach a thiontú ar [`i64`] isteach [`i32`] ag baint úsáide as an trait [`From`], toisc nach féidir an [`i64`] bhfuil luach nach féidir [`i32`] léiriú agus mar sin bheadh an chomhshó sonraí a chailleadh.
///
/// D'fhéadfadh sé seo a láimhseáil ag theascadh an [`i64`] chuig [`i32`] (go bunúsach a thabhairt ar an [`i64`] 's modulo luach [`i32::MAX`]) nó go simplí ag filleadh [`i32::MAX`], nó trí mhodh éigin eile.
/// Tá an trait [`From`] Tá sé i gceist le haghaidh conversions foirfe, agus mar sin an trait `TryFrom` in iúl don Ríomhchláraitheoir nuair a d'fhéadfadh a chomhshó cineál go dona agus ligeann dóibh cinneadh conas a láimhseáil é.
///
/// # Generic Implementations
///
/// - `TryFrom<T> for U` Ciallaíonn [`TryInto`]`<U>do T`</u>
/// - [`try_from`] tá sé athfhillteach, rud a chiallaíonn go gcuirtear `TryFrom<T> for T` i bhfeidhm agus nach féidir leis teip-is é an cineál `Error` gaolmhar chun `T::try_from()` a ghlaoch ar luach de chineál `T` ná [`Infallible`].
/// Nuair a bhíonn an cineál [`!`] chobhsaithe Beidh [`Infallible`] agus [`!`] coibhéiseach.
///
/// `TryFrom<T>` Is féidir a chur i bhfeidhm mar seo a leanas:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Mar a thuairiscítear, cuireann [`i32`] `TryFrom <` [`i64`]`>`i bhfeidhm:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Ciúin truncates `big_number`, éilíonn a bhrath agus a láimhseáil an t-teascadh i ndiaidh an ghnímh.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Tuairisceáin earráid toisc go bhfuil `big_number` ró-mhór a d'oirfeadh i `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Tuairisceáin `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// An cineál a cuireadh ar ais i gcás earráide tiontaithe.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Déanann an tiontú.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS GINEARÁLTA
////////////////////////////////////////////////////////////////////////////////

// Mar ardaitheoirí os a chionn&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Mar ardaitheoirí thar &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): cuir an ceann níos ginearálta seo a leanas in ionad na n-impls thuas do&/&mut:
// // Mar ardaitheoirí os cionn Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Mheánmhéide> AsRef <U>do D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// ardaitheoirí AsMut thar &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): cuir an ceann níos ginearálta seo a leanas in ionad an impl thuas do &mut:
// // Ardaíonn AsMut os cionn DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Mheánmhéide> AsMut <U>do D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Ó intuigthe Isteach
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Ó (agus dá bhrí sin Isteach) Is reflexive
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Cobhsaíochta Nóta:** Ní bhaineann sé seo impl ann fós, ach tá muid "reserving space" chun é a chur san future.
/// Féach [rust-lang/rust#64715][#64715] le haghaidh sonraí.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): déan socrú prionsabal ina ionad.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// Ciallaíonn TryFrom TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Tá tiontaithe infallible coibhéiseach go séimeantach le tiontaithe suaite le cineál earráide neamháitrithe.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS CONCRETE
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// AN CINEÁL ERROR NO-ERROR
////////////////////////////////////////////////////////////////////////////////

/// An cineál earráide chun earráidí nach féidir a tharlaíonn.
///
/// Ós rud é go bhfuil an Áirithe aon athraitheach, ní féidir le luach den chineál seo ann i ndáiríre.
/// aisiúil é seo do APIs cineálach a úsáideann [`Result`] agus parameterize an cineál earráid, a chur in iúl go bhfuil an toradh i gcónaí [`Ok`].
///
/// Mar shampla, an [`TryFrom`] trait (comhshó go tuairisceáin a [`Result`]) Tá cur chun feidhme blaincéad do gach cineál sa chás go mbíonn cur i bhfeidhm [`Into`] droim ar ais.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Comhoiriúnacht Future
///
/// Tá an ról céanna ag an enum seo le [the `!`“never”type][never], atá éagobhsaí sa leagan seo de Rust.
/// Nuair `!` cobhsaithe, tá sé beartaithe againn a dhéanamh `Infallible` ar ailias cineál dó:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... agus ar deireadh thiar deprecate `Infallible`.
///
/// Mar sin féin tá cás amháin inar féidir `!` error a úsáid sula `!` cobhsaithe mar chineál lán-chuimsitheach: i seasamh na chineál ais feidhm ar.
/// Go sonrach, is féidir cur chun feidhme a dhéanamh ar dhá chineál pointeoir feidhm éagsúla:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Le `Infallible` bheith ina Áirithe, tá an cód bailí.
/// Ach nuair a thiocfaidh `Infallible` ailias don type never, beidh an dá `impl`s tús le forluí agus dá bhrí sin a dhícheadú le rialacha comhleanúnachas trait na teanga.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}