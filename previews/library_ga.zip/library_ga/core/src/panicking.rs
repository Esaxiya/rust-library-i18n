//! Tacaíocht Panic do libcore
//!
//! Ní féidir leis an leabharlann lárnach panicking a shainiú, ach dearbhaíonn sí * panicking.
//! Ciallaíonn sé seo go gceadaítear na feidhmeanna taobh istigh de libcore do panic, ach le bheith úsáideach ní mór do crate in aghaidh srutha sainiú a dhéanamh ar phiocadh chun libcore a úsáid.
//! Is é an comhéadan reatha le haghaidh panicking:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Ligeann an sainmhíniú seo panicáil le haon teachtaireacht ghinearálta, ach ní cheadaíonn sé mainneachtain le luach `Box<Any>`.
//! (Níl ach `&(dyn Any + Send)` in `PanicInfo`, a líonann muid luach caocha ina leith i `PanicInfo: : internal_constructor`.) Is é an chúis atá leis seo ná nach gceadaítear libcore a leithdháileadh.
//!
//!
//! Tá cúpla feidhm scaollála eile sa mhodúl seo, ach níl iontu seo ach na míreanna lang riachtanacha don tiomsaitheoir.Déantar gach panics a mhaoiniú tríd an bhfeidhm amháin seo.
//! Is é an tsiombail iarbhír dhearbhú tríd an tréith `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Cur chun feidhme bunúsach macra `panic!` libcore nuair nach n-úsáidtear aon fhormáidiú.
#[cold]
// riamh inlíne mura panic_immediate_abort chun cód bloat ag na suíomhanna glaonna a sheachaint a oiread agus is féidir
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // de dhíth le codegen do panic ar thar maoil agus críochfoirt `Assert` MIR eile
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Úsáid Arguments::new_v1 ionad format_args! ("{}", Expr) a laghdú d'fhéadfadh a forchostais méid.
    // An fhormáid_args!úsáideann macra Taispeáin trait str chun expr a scríobh, a ghlaonn Formatter::pad, a chaithfidh freastal ar theascadh sreang agus stuáil (cé nach n-úsáidtear aon cheann anseo).
    //
    // Trí úsáid a bhaint as Arguments::new_v1 féadfaidh an tiomsaitheoir Formatter::pad a fhágáil ar lár ón dénártha aschuir, ag sábháil suas le cúpla cileavata.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // riachtanach le haghaidh panics const-mheasúnaithe
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // de dhíth le codegen le haghaidh panic ar rochtain OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Úsáidtear bunfheidhmiú macra `panic!` libcore nuair a úsáidtear formáidiú.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // NÓTA Ní thrasnaíonn an fheidhm seo teorainn FFI riamh;is glao Rust-to-Rust é a réitítear chuig feidhm `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SÁBHÁILTEACHT: Sainmhínítear `panic_impl` i gcód sábháilte Rust agus dá bhrí sin tá sé sábháilte glaoch air.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Feidhm inmheánach do macraí `assert_eq!` agus `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}