#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Fóntais a bhaineann le ceangail (FFI) comhéadan feidhm eachtrach.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Coibhéiseach le cineál C `void` nuair a úsáidtear é mar [pointer].
///
/// Go bunúsach, is é `*const c_void` comhionann le `const void*` C agus is `*mut c_void` comhionann le `void*` C s.
/// É sin ráite, tá sé seo nach bhfuil * * mar chineál ais `void` C, a bhfuil an cineál `()` Rust ar an gcéanna.
///
/// Chun leideanna a shamhaltú do chineálacha teimhneach i FFI, go dtí go ndéantar `extern type` a chobhsú, moltar fillteán newtype a úsáid timpeall ar eagar folamh beart.
///
/// Féach ar an [Nomicon] le haghaidh sonraí.
///
/// D'fhéadfá a úsáid `std::os::raw::c_void` más mian leo chun tacú le d'aois Rust síos Tiomsaitheoir go 1.1.0.
/// Tar éis Rust 1.30.0, rinneadh é a athonnmhairiú leis an sainmhíniú seo.
/// Le haghaidh tuilleadh faisnéise, léigh [RFC 2521] le do thoil.
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, do LLVM chun aitheantas a thabhairt don gcineál pointeoir ar neamhní agus trí feidhmeanna síneadh cosúil malloc(), ní mór dúinn a bheith acu ionadaíocht mar * i8 in LLVM bitcode.
// Cinntíonn an Áirithe a úsáidtear anseo seo agus cosc mí-úsáid den chineál "raw" ag amháin a bhfuil leagan príobháideacha.
// Teastaíonn dhá leagan uainn, toisc go ndéanann an tiomsaitheoir gearán faoin tréith repr ar shlí eile agus teastaíonn malairtí amháin ar a laghad uainn mar mura mbeadh an t-enum neamháitrithe agus UB ar a laghad a bheadh ag tagairt do leideanna den sórt sin.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Cur i bhfeidhm bunúsach `va_list`.
// Is é an t-ainm WIP, ag baint úsáide as `VaListImpl` do anois.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Invariant os cionn `'f`, mar sin tá gach réad `VaListImpl<'f>` ceangailte le réigiún na feidhme a bhfuil sé sainithe ann
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 `va_list` a chur i bhfeidhm ag ABI.
/// Féach an [AArch64 Procedure Call Standard] le haghaidh tuilleadh sonraí.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC `va_list` a chur i bhfeidhm ag ABI.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 `va_list` a chur i bhfeidhm ag ABI.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// Fillteán do `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Tiontaigh ar `VaListImpl` isteach `VaList` atá dénártha-luí leis `va_list` C s.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Tiontaigh ar `VaListImpl` isteach `VaList` atá dénártha-luí leis `va_list` C s.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// Ní mór don trait VaArgSafe a bheidh le húsáid i Comhéadain poiblí, áfach, an trait féin ní mór go mbeadh cead a úsáid taobh amuigh den mhodúl seo.
// Is dóigh go gceadóidh sé d`úsáideoirí iompar neamhshainithe a cheadú d`úsáideoirí an trait a chur i bhfeidhm do chineál nua (rud a fhágann gur féidir an va_arg intreach a úsáid ar chineál nua).
//
// FIXME(dlrobertson): D`fhonn an VaArgSafe trait a úsáid i gcomhéadan poiblí ach freisin chun a chinntiú nach féidir é a úsáid in áit eile, ní mór don trait a bheith poiblí laistigh de mhodúl príobháideach.
// Nuair a bheidh RFC 2145 curtha i bhfeidhm féach ar é seo a fheabhsú.
//
//
//
//
mod sealed_trait {
    /// Trait a cheadaíonn na cineálacha a cheadaítear a bheidh le húsáid le [super::VaListImpl::arg].
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Dul ar aghaidh chuig an gcéad argóint eile.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // SÁBHÁILTEACHT: caithfidh an té atá ag glaoch an conradh sábháilteachta do `va_arg` a sheasamh.
        unsafe { va_arg(self) }
    }

    /// Cóipeáil an `va_list` ag an suíomh reatha.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // SÁBHÁILTEACHT: ní mór don té atá ag glaoch ar an gconradh sábháilteachta do `va_end` seasamh.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // SÁBHÁILTEACHT: scríobhaimid chuig an `MaybeUninit`, dá bhrí sin tosaítear é agus tá `assume_init` dlíthiúil
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: ba chóir é seo glaoch `va_end`, ach níl aon bhealach glan
        // ráthaíocht a thabhairt go ndéantar `drop` a líneáil i gcónaí dá ghlaoiteoir, mar sin chuirfí an `va_end` go díreach ón bhfeidhm chéanna leis an `va_copy` comhfhreagrach.
        // `man va_end` deirtear go n-éilíonn C é seo, agus go leanann LLVM na seimeantach C go bunúsach, mar sin caithfimid a chinntiú go nglaoitear `va_end` i gcónaí ón bhfeidhm chéanna le `va_copy`.
        //
        // Le haghaidh tuilleadh sonraí, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Oibríonn sé seo go dtí seo, ós rud é gur rogha nua é `va_end` ar na spriocanna LLVM reatha go léir.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Scriosann an `ap` arglist ndiaidh an túsaithe le `va_start` nó `va_copy`.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Cóipeáil suíomh reatha an arglist `src` chuig an arglist `dst`.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Luchtaíonn argóint de chineál `T` ón `va_list` `ap` agus méadaíonn an argóint `ap` go.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}