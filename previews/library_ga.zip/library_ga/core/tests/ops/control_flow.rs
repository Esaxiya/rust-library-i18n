use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Ní achar dromchla seasmhach é seo, ach cuidíonn sé le `?` a choinneáil saor eatarthu, fiú mura féidir le LLVM leas a bhaint as anois.
    //
    // (Faraor tá Toradh agus Rogha neamhréireach, mar sin ní féidir le ControlFlow an dá rud a mheaitseáil.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}