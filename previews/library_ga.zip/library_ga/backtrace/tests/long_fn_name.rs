use backtrace::Backtrace;

// 50-charachtar ainm modúl
mod _234567890_234567890_234567890_234567890_234567890 {
    // Ainm struchtúir 50 carachtar
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// Ní mór do ainmneacha fheidhm Long a teascadh (MAX_SYM_NAME, 1) carachtair.
// Ná reáchtáil an tástáil seo ach le haghaidh msvc, ós rud é go ndéanann gnu priontaí "<no info>" do gach fráma.
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // 10 athrá ar ainm struchtúir, mar sin is é atleast 10 *(50 + 50)* 2=2000 carachtar an t-ainm feidhme láncháilithe.
    //
    // Tá sé i ndáiríre níos faide ós rud é folaíonn sé freisin `::`, `<>` agus ainm an mhodúil atá ann faoi láthair
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}