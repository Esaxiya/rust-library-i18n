use backtrace::Backtrace;

// Ní oibríonn an tástáil seo ach ar ardáin a bhfuil feidhm `symbol_address` oibre acu le haghaidh frámaí a thuairiscíonn seoladh tosaigh siombail.
// Mar thoradh air sin níl sé cumasaithe ach ar chúpla ardán.
//
const ENABLED: bool = cfg!(all(
    // Windows níor tástáladh i ndáiríre, agus ní thacaíonn OSX le fráma imfhálaithe a fháil, mar sin díchumasaigh é seo
    //
    target_os = "linux",
    // Nuair a aimsíonn ARM an fheidhm imfhálaithe níl ann ach an ip féin a thabhairt ar ais.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}