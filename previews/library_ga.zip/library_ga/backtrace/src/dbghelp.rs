//! Modúl chun cabhrú le ceangail dbghelp a bhainistiú ar Windows
//!
//! Backtraces ar Windows (ar a laghad le haghaidh MSVC) atá faoi thiomáint chuid is mó trí `dbghelp.dll` agus na feidhmeanna éagsúla go bhfuil sé.
//! Faoi láthair tá na feidhmeanna seo luchtaithe *go dinimiciúil* seachas a bheith nasctha le `dbghelp.dll` go statach.
//! Is í an leabharlann chaighdeánach a dhéanann é seo faoi láthair (agus teastaíonn go teoiriciúil í ansin), ach is iarracht í chun spleáchais statacha dll leabharlainne a laghdú ós rud é go mbíonn cúltacaí roghnach go leor de ghnáth.
//!
//! É sin ráite, bíonn ualaí `dbghelp.dll` beagnach i gcónaí rathúil ar Windows.
//!
//! Tabhair faoi deara, áfach, ós rud é go bhfuil an tacaíocht seo go léir á luchtú againn go dinimiciúil ní féidir linn na sainmhínithe amha in `winapi` a úsáid, ach ina ionad sin caithfimid na cineálacha pointeoir feidhm a shainiú muid féin agus an úsáid sin a úsáid.
//! Nílimid ag iarraidh i ndáiríre a bheith i ngnó na dúbláil ar winapi, sin ní mór dúinn gné Cargo `verify-winapi` a dhearbhaíonn bhfuil comhoiriúnach na ceangail sin in winapi agus tá an ghné seo ar chumas ar CI.
//!
//! Mar fhocal scoir, beidh tú faoi deara anseo go bhfuil an t-dll le `dbghelp.dll` riamh sí díluchtaithe, agus sin aon ghnó faoi láthair.
//! Is é an smaoineamh gur féidir linn é a thaisceadh go domhanda agus é a úsáid idir glaonna chuig an API, ag seachaint loads/unloads daor.
//! Más fadhb í seo do bhrathadóirí sceite nó rud éigin mar sin is féidir linn an droichead a thrasnú nuair a shroicheann muid ann.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Oibrigh timpeall `SymGetOptions` agus `SymSetOptions` gan a bheith i láthair i winapi féin.
// Seachas sin ní úsáidtear é seo ach nuair a bhíonn cineálacha seiceála dúbailte againn i gcoinne winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Níl sé sainithe i winapi fós
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Tá sé seo a shainmhínítear in winapi, ach tá sé mícheart (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Níl sé sainithe i winapi fós
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Úsáidtear an macra seo chun struchtúr `Dbghelp` a shainiú ina bhfuil na leideanna feidhm go léir a d`fhéadfaimis a luchtú go hinmheánach.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// An luchtaithe dll do `dbghelp.dll`
            dll: HMODULE,

            // Gach pointeoir feidhm do gach feidhm a d`fhéadfaimis a úsáid
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // I dtús báire ní mór dúinn a luchtú an dll
            dll: 0 as *mut _,
            // I dtosach báire tá na feidhmeanna go léir nialasach le rá go gcaithfear iad a luchtú go dinimiciúil.
            //
            $($name: 0,)*
        };

        // typedef áisiúlacht do gach cineál feidhme.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Iarrachtaí `dbghelp.dll` a oscailt.
            /// Filleann sé ar rath má oibríonn sé nó má dhéantar earráid má theipeann ar `LoadLibraryW`.
            ///
            /// Panics má tá an leabharlann luchtaithe cheana féin.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Feidhm maidir le gach modh ba mhaith linn buíochas a bhaint as.
            // Nuair a ghlaofar air léifidh sé pointeoir na feidhme i dtaisce nó luchtú é agus cuirfidh sé an luach luchtaithe ar ais.
            // Dearbhaítear go n-éireoidh le hualaí.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Seachfhreastalaí áise chun na glais ghlantacháin a úsáid chun tagairt a dhéanamh d`fheidhmeanna dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Cuir tús le gach tacaíocht is gá chun feidhmeanna `dbghelp` API a rochtain ón crate seo.
///
///
/// Tabhair faoi deara go bhfuil an fheidhm seo sábháilte ** **, tá sé go hinmheánach ar a sioncrónaithe féin.
/// Tabhair faoi deara freisin go bhfuil sé sábháilte chun glaoch fheidhm seo amanna éagsúla hathchúrsach.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Is é an chéad rud is gá dúinn a dhéanamh chun sioncrónú an fheidhm seo.Is féidir é seo a ghlaoch i gcomhthráth ó snáitheanna eile nó go hathchúrsach laistigh de shnáithe amháin.
        // Tabhair faoi deara go bhfuil sé níos deacra ná sin áfach toisc go gcaithfear an méid atá á úsáid againn anseo, `dbghelp`,* * a shioncronú leis na glaoiteoirí eile go `dbghelp` sa phróiseas seo.
        //
        // De ghnáth ní bhíonn go leor glaonna ar `dbghelp` sa phróiseas céanna agus is dócha go bhféadfaimis glacadh leis go sábháilte gurb sinne an t-aon duine a bhfuil rochtain air.
        // Tá príomhúsáideoir amháin eile ann, áfach, nach mór dúinn a bheith buartha faoi atá go híorónta féin, ach sa leabharlann chaighdeánach.
        // Braitheann leabharlann chaighdeánach Rust ar an crate seo le haghaidh tacaíochta cúlbhrait, agus tá an crate seo ar crates.io freisin.
        // Ciallaíonn sé sin, má tá an leabharlann caighdeánach priontáil cúl-lorg panic féadfaidh sé rás leis an crate ag teacht as crates.io, is cúis le segfaults.
        //
        // Chun cabhrú leis an bhfadhb sioncrónaithe seo a réiteach úsáidimid cleas a bhaineann go sonrach le Windows anseo (tar éis an tsaoil, is srian atá sainiúil do Windows faoi shioncronú é).
        // Cruthaímid mutex ainmnithe *seisiún-áitiúil* chun an glao seo a chosaint.
        // Is é an aidhm atá leis seo ná nach gá don leabharlann chaighdeánach agus don crate seo APIs ar leibhéal Rust a roinnt le sioncrónú anseo ach ina ionad sin is féidir leo oibriú taobh thiar de na radhairc chun a chinntiú go bhfuil siad ag sioncrónú lena chéile.
        //
        // Sa chaoi sin nuair atá an fheidhm seo ar a dtugtar tríd an leabharlann caighdeánach nó trí crates.io féidir linn a bheith cinnte go bhfuil an t-mutex céanna á fháil.
        //
        // Mar sin, gach ceann de sin le rá go bhfuil an chéad rud a dhéanann muid anseo linn a chruthú atomically a `HANDLE` is mutex ainmnithe ar Windows.
        // Déanaimid sioncrónú beagán le snáitheanna eile a roinneann an fheidhm seo go sonrach agus cinntímid nach gcruthaítear ach láimhseáil amháin in aghaidh gach sampla den fheidhm seo.
        // Tabhair faoi deara nach ndúnfar an láimhseáil riamh nuair a stóráiltear é ar fud an domhain.
        //
        // Tar éis tá muid ag dul i ndáiríre an ghlais linn a fháil go simplí é, agus ár n-`Init` láimhseáil muid lámh amach a bheidh freagrach as dropping é sa deireadh.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ceart go leor, phew!Anois go bhfuilimid go léir sioncrónaithe go sábháilte, déanaimis gach rud a phróiseáil i ndáiríre.
        // Ar an gcéad dul síos caithfimid a chinntiú go bhfuil `dbghelp.dll` luchtaithe sa phróiseas seo i ndáiríre.
        // Déanaimid é seo go dinimiciúil a sheachaint spleáchas statach.
        // Rinneadh é seo go stairiúil chun oibriú timpeall ar shaincheisteanna nascacha aisteach agus tá sé i gceist binaries a dhéanamh rud beag níos iniompartha ós rud é nach bhfuil anseo ach fóntais dífhabhtaithe.
        //
        //
        // Nuair a bheidh `dbghelp.dll` oscailte againn caithfimid roinnt feidhmeanna tosaigh a ghlaoch ann, agus tá níos mó sonraí thíos.
        // Déanann muid ach aon uair amháin, ach, mar sin tá muid fuair athróige Boole domhanda le fios an bhfuil muid ag déanamh go fóill nó nach bhfuil.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // A chinntiú go bhfuil an bhratach `SYMOPT_DEFERRED_LOADS` leagtha, mar de réir docs féin MSVC don faoi seo: "This is the fastest, most efficient way to use the symbol handler.", sin a ligean a dhéanamh!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // I ndáiríre thúsú siombailí le MSVC.Tabhair faoi deara gur féidir go dteipfidh air seo, ach déanaimid neamhaird air.
        // Níl tonna d`ealaín roimhe seo chuige seo, ach is cosúil go ndéanann LLVM neamhaird ar an luach toraidh anseo agus déanann ceann de na leabharlanna sláintíochta i LLVM rabhadh scanrúil a phriontáil má theipeann air seo ach go ndéanann sé neamhaird air go bunúsach.
        //
        //
        // Is cás amháin thiocfaidh an suas go leor don Rust go leabharlann caighdeánach agus tá sé seo crate ar crates.io araon ag iarraidh dul san iomaíocht do `SymInitializeW`.
        // Go stairiúil theastaigh ón leabharlann chaighdeánach an glanta sin a thionscnamh an chuid is mó den am, ach anois go bhfuil an crate seo á húsáid aici ciallaíonn sé go bhfaighidh duine tús áite ar dtús agus roghnóidh an ceann eile an tosach feidhme sin.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}