//! Tacaíocht Backtrace ag baint úsáide as APIs libunwind/gcc_s/etc.
//!
//! Sa mhodúl seo tá an cumas an chruach a scaoileadh trí úsáid a bhaint as APIanna i stíl libunwind.
//! Tabhair faoi deara go bhfuil dornán iomlán de chur i bhfeidhm an API cosúil le libunwind, agus níl anseo ach iarracht a bheith comhoiriúnach leis an gcuid is mó díobh go léir ag an am céanna seachas a bheith piocach.
//!
//!
//! Tá an API libunwind faoi thiomáint ag `_Unwind_Backtrace` agus i ndáiríre tá sé an-iontaofa maidir le cúlra a ghiniúint.
//! Níl sé soiléir go hiomlán conas a dhéanann sí é (leideanna fráma? eh_frame eolas? araon?) ach dealraíonn sé a bheith ag obair!
//!
//! Tá an chuid is mó de chastacht an mhodúil seo ag láimhseáil na ndifríochtaí ardáin éagsúla ar fud chur chun feidhme libunwind.
//! Seachas sin tá sé seo le Rust deas simplí ina gceangal ar an APIs libunwind.
//!
//! Is é seo an API scaoilte réamhshocraithe do gach ardán neamh-Windows faoi láthair.
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// Le pointeoir libunwind amh ba chóir é a ach riamh rochtain ar bhealach readonly threadsafe, mar sin tá sé `Sync`.
// Agus muid ag seoladh chuig snáitheanna eile trí `Clone` athraímid i gcónaí go leagan nach gcoinníonn leideanna istigh, mar sin ba chóir dúinn a bheith `Send` freisin.
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // Dealraíonn sé ar OSX `_Unwind_FindEnclosingFunction` go dtugann sé pointeoir ar ais chuig ... rud nach bhfuil soiléir.
        // Is cinnte nach i gcónaí an fheidhm imfhálaithe ar chúis ar bith.
        // Ní léir dom go hiomlán cad atá ar siúl anseo, mar sin déan é seo a mheas anois agus díreach an ip a chur ar ais i gcónaí.
        //
        // Tabhair faoi deara go ndéantar an tástáil `skip_inner_frames.rs` a scipeáil ar OSX mar gheall ar an gclásal seo, agus má tá sé seo socraithe is féidir an tástáil go teoiriciúil a reáchtáil ar OSX!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// Comhéadan leabharlainne gan sreang a úsáidtear le haghaidh cúltacaí
///
/// Tabhair faoi deara go bhfuil cód marbh lamháil mar seo iad ach ceangail Ní iOS úsáid gach ceann acu é ach cur níos mó ardán a bhaineann go sonrach configs pollutes an cód an iomarca
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // ARM EABI amháin a úsáideann é
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // Gan_Unwind_Backtrace ó dhúchas ar iOS
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // ar fáil ó GCC 4.2.0, ba chóir go breá le haghaidh ár n-aidhm
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // Is míthuiscint í an fheidhm seo: seachas Seoladh Fráma Canónach an fhráma seo a fháil (aka SP an fhráma glaoiteora) tugann sé SP an fhráma seo ar ais.
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x úsáideann luach CFA claonta, dá bhrí sin ní mór dúinn_Unwind_GetGR a úsáid chun an clár pointeoir cruachta (%r15) a fháil in ionad a bheith ag brath ar_Unwind_GetCFA.
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // Maidir le android agus lámh, is macraí an fheidhm `_Unwind_GetIP` agus dornán daoine eile, mar sin sainímid feidhmeanna ina bhfuil leathnú na macraí.
    //
    //
    // TODO: nasc chuig an gcomhad header a shainmhíníonn na Macraí, más féidir leat é a fháil.
    // (Ní féidir liomsa, fitzgen, an comhad ceanntásca a fuarthas ar iasacht ó chuid de na macra-fhairsingithe seo a fháil ar dtús.)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 tá an pointeoir chairn ar lámh.
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // Níl an fheidhm seo ann freisin ar Android nó ARM/Linux, mar sin déan neamh-op é.
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}