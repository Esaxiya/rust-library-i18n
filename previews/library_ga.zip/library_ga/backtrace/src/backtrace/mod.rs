use core::ffi::c_void;
use core::fmt;

/// Déanann sé iniúchadh ar an gcruach glaonna atá ann faoi láthair, agus na frámaí gníomhacha go léir á gcur isteach sa dúnadh a chuirtear ar fáil chun rian cruachta a ríomh.
///
/// Is í an fheidhm seo príomhobair na leabharlainne seo maidir le rianta cruachta do chlár a ríomh.Is é an dúnadh thugtar `cb` Fuarthas chás de `Frame` a dhéanann ionadaíocht faisnéis faoi sin fráma glaoch ar an chairn.
/// Tugtar frámaí don dhúnadh ar bhealach ón mbarr anuas (ar a dtugtar feidhmeanna ar dtús le déanaí).
///
/// Is léiriú é luach tuairisceáin an dhúnadh ar cheart leanúint den chúlra.Beidh luach ar ais `false` deireadh a chur leis cúl-lorg agus seol ar ais láithreach.
///
/// A luaithe is a `Frame` fuarthas beidh tú ag iarraidh dócha a ghlaoch `backtrace::resolve` chun an `ip` (teagasc pointeoir) nó seoladh tsiombail thiontú go `Symbol` trína an t-ainm agus/nó ainm comhaid/is féidir uimhir líne a fhoghlaim.
///
///
/// Tabhair faoi deara gur feidhm leibhéal íseal í seo agus más maith leat, mar shampla, cúlra a ghabháil le hiniúchadh níos déanaí, ansin d`fhéadfadh go mbeadh an cineál `Backtrace` níos oiriúnaí.
///
/// # Gnéithe riachtanacha
///
/// Éilíonn an fheidhm seo gné `std` den `backtrace` crate a chumasú, agus cumasaítear an ghné `std` de réir réamhshocraithe.
///
/// # Panics
///
/// Déanann an fheidhm seo iarracht riamh panic a dhéanamh, ach má sholáthraíonn an `cb` panics ansin cuirfidh roinnt ardáin iallach ar panic dúbailte an próiseas a ghinmhilleadh.
/// Roinnt ardáin a úsáid leabharlann C a úsáideann hinmheánach callbacks nach féidir a bheith unwound tríd, panicking sin ó `cb` fhéadfadh tús le Tobscoir phróiseas.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // lean ar aghaidh leis an gcúlrian
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Mar an gcéanna le `trace`, níl sé ach sábháilte mar tá sé neamhshioncronaithe.
///
/// Níl ráthaíochtaí sioncrónaithe ag an bhfeidhm seo ach tá sí ar fáil nuair nach bhfuil gné `std` den crate seo curtha le chéile.
/// Féach feidhm `trace` le haghaidh tuilleadh doiciméadaithe agus samplaí.
///
/// # Panics
///
/// Féach faisnéis ar `trace` le haghaidh caveat ar phiocadh `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// A trait a ionadaíonn fráma ar cheann de cúl-lorg, thug d'fheidhm `trace` an crate.
///
/// Beidh an fheidhm rianú ar dúnta a thug frámaí, agus tá an fráma choinsínítear beagnach mar nach bhfuil cur chun feidhme bunúsach ar eolas i gcónaí go dtí go runtime.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Tugann sé pointeoir treoracha reatha an fhráma seo ar ais.
    ///
    /// Tá sé seo de ghnáth ar an teagasc seo chugainn a fhorghníomhú i bhfráma, ach ní liosta na implementations seo le cruinneas 100% (ach tá sé de ghnáth gar go leor).
    ///
    ///
    /// Moltar an luach seo a chur ar aghaidh chuig `backtrace::resolve` chun ainm siombail a dhéanamh air.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Filleann pointeoir cruachta reatha an fhráma seo.
    ///
    /// I gcás nach féidir le inneall a ghnóthú an pointeoir chairn don fhráma, tá pointeoir null ais.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Tuairisceáin an seoladh tsiombail tosú ar an fhráma na feidhme seo.
    ///
    /// Beidh sé seo iarracht athchasadh an pointeoir teagaisc ais `ip` dtí tús na feidhme, ag filleadh sin luach.
    ///
    /// I roinnt cásanna, áfach, ní fhillfidh backends `ip` ar ais ón bhfeidhm seo.
    ///
    /// Is féidir leis an luach ar ais a úsáid uaireanta má theip `backtrace::resolve` ar an `ip` atá tugtha thuas.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Seolann sé seoladh bun an mhodúil lena mbaineann an fráma.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Caithfidh sé seo teacht ar dtús, chun a chinntiú go dtabharfaidh Miri tús áite don ardán óstach
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // siombal amháin a úsáidtear i dbghelp
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}