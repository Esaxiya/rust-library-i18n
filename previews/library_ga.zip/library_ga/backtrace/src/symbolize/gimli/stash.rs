// nach n-úsáidtear ach ar Linux anois, mar sin lig cód marbh in áit eile
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// A Allocator réimse simplí maidir le maoláin beart.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Leithdháileann maolán ar an méid sonraithe agus tuairisceáin tagairt mutable dó.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SÁBHÁILTEACHT: is é seo an t-aon fheidhm a thógann suaitheadh riamh
        // tagairt do `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SÁBHÁILTEACHT: ní bhainimid eilimintí ó `self.buffers` riamh, mar sin tagairt
        // beidh na sonraí taobh istigh d'aon mhaolán beo chomh fada agus a dhéanann `self`.
        &mut buffers[i]
    }
}