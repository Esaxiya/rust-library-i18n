//! Straitéis shiombailithe ag baint úsáide as an gcód parsála DWARF i libbacktrace.
//!
//! Tacaíonn an leabharlann libbacktrace C, a dháiltear de ghnáth le gcc, ní amháin le cúlra a ghiniúint (nach n-úsáideann muid i ndáiríre) ach freisin siombail a dhéanamh den chúlra agus láimhseáil faisnéis dífhabhtaithe dwarf faoi rudaí cosúil le frámaí inlíne agus whatnot.
//!
//!
//! Tá sé seo casta réasúnta mar gheall ar go leor de na hábhair imní éagsúla anseo, ach tá an smaoineamh bunúsach:
//!
//! * Ar dtús tugaimid `backtrace_syminfo`.Faigheann sé seo faisnéis shiombail ón tábla siombailí dinimiciúil más féidir linn.
//! * Ar aghaidh tugaimid `backtrace_pcinfo`.Déanfaidh sé seo táblaí debuginfo a pharsáil má tá siad ar fáil agus ligfidh sé dúinn faisnéis a fháil faoi fhrámaí inlíne, ainmneacha comhaid, uimhreacha líne, srl.
//!
//! Tá go leor fánach ann maidir leis na táblaí dwarf a chur i libbacktrace, ach tá súil againn nach deireadh an domhain é agus go bhfuil sé soiléir go leor agus tú ag léamh thíos.
//!
//! Is í seo an straitéis siombailithe réamhshocraithe d`ardáin neamh-MSVC agus neamh-OSX.Go libstd cé go bhfuil sé seo an straitéis réamhshocraithe le haghaidh OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Más féidir fearr an t-ainm `function` a thagann ó debuginfo agus is féidir iad de ghnáth níos cruinne le haghaidh frámaí inlíne, mar shampla.
                // Mura bhfuil sé sin i láthair, téigh siar ar ainm an tábla siombailí a shonraítear in `symname`.
                //
                // Tabhair faoi deara gur féidir uaireanta `function` bhraitheann beagán níos lú cruinn, mar shampla bheith liostaithe mar `try<i32,closure>` isntead de `std::panicking::try::do_call`.
                //
                // Níl sé soiléir cén fáth gur, ach ar an iomlán is cosúil an t-ainm `function` níos cruinne.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // aon rud a dhéanamh anois
}

/// Cineál ar an pointeoir `data` rith `syminfo_cb` isteach
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Nuair atá an callback agairt as `backtrace_syminfo` nuair a thosaíonn muid ag réiteach théann muid a thuilleadh a ghlaoch `backtrace_pcinfo`.
    // Rachaidh an fheidhm `backtrace_pcinfo` i gcomhairle le faisnéis dífhabhtaithe agus déan iarracht rudaí a dhéanamh cosúil le faisnéis file/line a aisghabháil chomh maith le frámaí inlíne.
    // Tabhair faoi deara cé gur féidir le `backtrace_pcinfo` dteipfidh air no nach bhfuil i bhfad más rud é nach bhfuil eolas debug, mar sin má tharlaíonn sé go bhfuil muid cinnte chun glaoch ar an callback le siombail ar a laghad as na `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Cineál an pointeora `data` a ritheadh isteach i `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Tacaíonn an API libbacktrace le stát a chruthú, ach ní thacaíonn sé le stát a scriosadh.
// Glacaim leis go pearsanta go gciallódh sé seo go bhfuil sé i gceist stát a chruthú agus maireachtáil go deo ansin.
//
// Ba bhreá liom láimhseálaí at_exit() a chlárú a ghlanann an stát seo, ach ní sholáthraíonn libbacktrace aon bhealach chun é sin a dhéanamh.
//
// Leis na srianta seo, tá stát i dtaisce go statach ag an bhfeidhm seo a ríomhtar an chéad uair a iarrtar é seo.
//
// Cuimhnigh go dtarlaíonn cúltaca go sraitheach (glas domhanda amháin).
//
// Tabhair faoi deara go bhfuil an easpa sioncrónaithe anseo mar gheall ar an riachtanas go bhfuil `resolve` synchronized go seachtrach.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Ná bí ag feidhmiú cumais shnáithíneacha libbacktrace ós rud é go bhfuilimid i gcónaí ag glaoch air ar bhealach sioncronaithe.
        //
        0,
        error_cb,
        ptr::null_mut(), // aon sonraí breise
    );

    return STATE;

    // Tabhair faoi deara, chun go n-oibreoidh libbacktrace ar chor ar bith, caithfidh sé faisnéis dífhabhtaithe DWARF a fháil don inrite reatha.Déanann sé de ghnáth go bhfuil trí roinnt meicníochtaí lena n-áirítear, ach gan a bheith teoranta do:
    //
    // * /proc/self/exe ar ardáin tacaithe
    // * An ainm comhaid a ritheadh i sainráite nuair a chruthú stáit
    //
    // Is wad mór de chód C í an leabharlann libbacktrace.Ciallaíonn sé seo go nádúrtha fuair sé ar leochaileachtaí sábháilteachta chuimhne, go háirithe nuair a láimhseáil debuginfo míchumtha.
    // Tá neart acu seo go stairiúil.
    //
    // Má úsáidtear /proc/self/exe ansin is féidir linn neamhaird a dhéanamh orthu seo de ghnáth mar glacaimid leis gur "mostly correct" é libbacktrace agus murach sin ní dhéanaimid rudaí aisteach le faisnéis dífhabhtaithe dwarf "attempted to be correct".
    //
    //
    // Má éiríonn linn i ainm comhaid, áfach, ansin tá sé indéanta ar roinnt ardáin (cosúil le BSDs) i gcás inar féidir le aisteoir mailíseach a chur faoi deara comhad treallach le cur ag an suíomh.
    // Ciallaíonn sé seo má insímid libbacktrace faoi ainm comhaid b`fhéidir go bhfuil sé ag baint úsáide as comhad treallach, ag cruthú segfaults b`fhéidir.
    // Mura n-insímid aon rud libbacktrace áfach, ní dhéanfaidh sé aon rud ar ardáin nach dtacaíonn le cosáin mar /proc/self/exe!
    //
    // Ós rud ar fad go déanaimid ár ndícheall chomh crua agus is féidir go *nach* pas i ainm comhaid, ach ní mór dúinn ar ardáin nach bhfuil tacaíocht /proc/self/exe ar chor ar bith.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Tabhair faoi deara go hidéalach ba mhaith linn a úsáid `std::env::current_exe`, ach ní féidir linn a cheangal `std` anseo.
            //
            // Bain úsáid as `_NSGetExecutablePath` a luchtú an cosán inrite atá ann faoi láthair isteach i limistéar statach (a má tá sé ró-bheag a thabhairt suas díreach).
            //
            //
            // Tabhair faoi deara go bhfuil muinín mhór againn as libbacktrace anseo chun nach bhfaighidh muid bás ar inriteadh truaillithe, ach is cinnte go ndéanann ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows Tá modh de chomhaid ina tar éis tá sé d'oscail ní féidir é a scriosadh a oscailt.
            // Sin go ginearálta an rud atá uainn anseo toisc go dteastaíonn uainn a chinntiú nach mbeidh ár n-inrite ag athrú amach fúinn tar éis dúinn é a thabhairt ar ais go libbacktrace, ag súil go maolóidh sé an cumas sonraí treallach a chur isteach i libbacktrace (a d`fhéadfadh a bheith mí-láimhseáil).
            //
            //
            // Ós rud é go bhfuil muid ag beagán de damhsa anseo chun iarracht a fháil ar saghas glas ar ár n-íomhá féin:
            //
            // * Faigh láimhseáil ar an bpróiseas reatha, luchtaigh ainm a chomhaid.
            // * Oscail comhad leis ainm comhaid leis na bratacha ceart.
            // * Reload an bpróiseas atá ann faoi láthair ar filename, a dhéanamh cinnte tá sé mar an gcéanna
            //
            // Más rud é go Gabhann gach muid ag teoiriciúil tar éis a osclaíodh go deimhin comhad ár bpróiseas agus táimid ag ráthú nach mbeidh sé athrú.Cóipeáiltear bunch de seo ó libstd go stairiúil, mar sin is é seo an léiriú is fearr atá agam ar a raibh ag tarlú.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Tá cuimhne statach air seo ionas gur féidir linn é a thabhairt ar ais.
                static mut BUF: [i8; N] = [0; N];
                // ... agus tá sé seo ar shaol ar an chairn ó tá sé sealadach
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // sceitheadh `handle` d`aon ghnó anseo mar ba chóir go gcaomhnódh sé an glas ar ainm an chomhaid seo má osclaítear é.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Ba mhaith linn slice a bhfuil foirceannadh neamhní air a thabhairt ar ais, mar sin má líonadh gach rud isteach agus más ionann é agus an fad iomlán, is ionann é sin agus teip.
                //
                //
                // Seachas sin nuair a bhíonn rath ar ais déan cinnte go bhfuil an beart nul san áireamh sa slice.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // earráidí cúl-lorg scuabtha faoi láthair faoi na rug
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Glaoigh ar an `backtrace_syminfo` API ar cheart dó (ó léamh an chóid) `syminfo_cb` a ghlaoch go díreach uair amháin (nó má theipeann air le hearráid is dócha).
    // Ansin láimhseáilimid níos mó laistigh den `syminfo_cb`.
    //
    // Tabhair faoi deara go ndéanaimid é seo ós rud é go rachaidh `syminfo` i gcomhairle leis an tábla siombailí, ag aimsiú ainmneacha siombailí fiú mura bhfuil aon fhaisnéis dífhabhtaithe sa dénártha.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}