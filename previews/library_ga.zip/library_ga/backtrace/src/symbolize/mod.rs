use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Réitigh seoladh chuig siombail, ag dul thar an tsiombail go dtí an dúnadh sonraithe.
///
/// Beidh an fheidhm breathnú suas ar an seoladh atá tugtha i réimsí ar nós an tábla áitiúil siombail, tábla siombail dinimiciúil, nó eolas dífhabhtaithe Dwarf (ag brath ar chur i bhfeidhm gníomhachtaithe) chun siombailí chun teacht isteach a aimsiú.
///
///
/// Ní féidir leis an dúnadh a dtugtar más rud é nach bhféadfaí rún a dhéanamh, agus d'fhéadfadh sé a bheith ar a dtugtar freisin níos mó ná uair amháin i gcás feidhmeanna inlined.
///
/// Léiríonn na siombailí a tugadh an forghníomhú ag an `addr` sonraithe, ag filleadh péirí file/line don seoladh sin (má tá siad ar fáil).
///
/// Tabhair faoi deara go má tá tú `Frame` ansin tá sé molta a bhaint as an fheidhm `resolve_frame` in áit an gceann seo.
///
/// # Gnéithe riachtanacha
///
/// Éilíonn an fheidhm seo gné `std` den `backtrace` crate a chumasú, agus cumasaítear an ghné `std` de réir réamhshocraithe.
///
/// # Panics
///
/// Déanann an fheidhm seo iarracht riamh panic a dhéanamh, ach má sholáthraíonn an `cb` panics ansin cuirfidh roinnt ardáin iallach ar panic dúbailte an próiseas a ghinmhilleadh.
/// Roinnt ardáin a úsáid leabharlann C a úsáideann hinmheánach callbacks nach féidir a bheith unwound tríd, panicking sin ó `cb` fhéadfadh tús le Tobscoir phróiseas.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // ach breathnú ar an bhfráma barr
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Réitigh fráma gabhála roimhe seo go siombail, ag dul thar an tsiombail go dtí an dúnadh sonraithe.
///
/// Comhlíonann an functin seo an fheidhm chéanna le `resolve` ach amháin go nglacann sé `Frame` mar argóint in ionad seoladh.
/// Féadann sé seo ligean do roinnt feidhmchlár ardáin de chúltacaíocht faisnéis siombailí nó faisnéis níos cruinne a sholáthar faoi fhrámaí inlíne mar shampla.
///
/// Moltar é seo a úsáid más féidir leat.
///
/// # Gnéithe riachtanacha
///
/// Éilíonn an fheidhm seo gné `std` den `backtrace` crate a chumasú, agus cumasaítear an ghné `std` de réir réamhshocraithe.
///
/// # Panics
///
/// Déanann an fheidhm seo iarracht riamh panic a dhéanamh, ach má sholáthraíonn an `cb` panics ansin cuirfidh roinnt ardáin iallach ar panic dúbailte an próiseas a ghinmhilleadh.
/// Roinnt ardáin a úsáid leabharlann C a úsáideann hinmheánach callbacks nach féidir a bheith unwound tríd, panicking sin ó `cb` fhéadfadh tús le Tobscoir phróiseas.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // ach breathnú ar an bhfráma barr
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Is iad na luachanna IP ó frámaí Stack ghnáth (always?) an teagasc *tar éis* an glaoch go bhfuil an rian Stack iarbhír.
// Symbolizing seo ar chúiseanna an uimhir filename/line a bheith chun tosaigh agus b'fhéidir isteach ar neamhní má tá sé gar do dheireadh na feidhme.
//
// Dealraíonn sé gurb amhlaidh atá i gcónaí ar gach ardán, mar sin déanaimid ceann a dhealú i gcónaí ó ip réitithe chun é a réiteach don treoir ghlaonna roimhe seo in ionad an treoir a chur ar ais.
//
//
// Go hidéalach ní ba mhaith linn é seo a.
// Go hidéalach ba mhaith linn a cheangal ar glaoiteoirí na APIs `resolve` anseo a dhéanamh de láimh ar an -1 agus cuntas gur mian leo doiciméad oifigiúil: don * * teagaisc roimhe seo, nach bhfuil an láthair.
// Go hidéalach, ba mhaith linn nochtadh a dhéanamh ar `Frame` más muidne seoladh an chéad teagaisc eile nó an reatha.
//
// Go dtí seo cé gur ábhar imní nideoige é seo agus mar sin déanaimid ceann a dhealú go hinmheánach i gcónaí.
// Ba cheart do thomhaltóirí a bheith ag obair agus torthaí an-mhaith a fháil, mar sin ba chóir dúinn a bheith maith go leor.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Mar an gcéanna le `resolve`, níl sé ach sábháilte mar tá sé neamhshioncronaithe.
///
/// Níl ráthaíochtaí sioncrónaithe ag an bhfeidhm seo ach tá sí ar fáil nuair nach bhfuil gné `std` den crate seo curtha le chéile.
/// Féach feidhm `resolve` le haghaidh tuilleadh doiciméadaithe agus samplaí.
///
/// # Panics
///
/// Féach eolas ar `resolve` do caveats ar `cb` panicking.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Mar an gcéanna le `resolve_frame`, níl sé ach sábháilte mar tá sé neamhshioncronaithe.
///
/// Níl ráthaíochtaí sioncrónaithe ag an bhfeidhm seo ach tá sí ar fáil nuair nach bhfuil gné `std` den crate seo curtha le chéile.
/// Féach feidhm `resolve_frame` le haghaidh tuilleadh doiciméadaithe agus samplaí.
///
/// # Panics
///
/// Féach eolas ar `resolve_frame` do caveats ar `cb` panicking.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait a léiríonn réiteach siombail i gcomhad.
///
/// Tugtar an trait seo mar réad trait don dúnadh a thugtar don fheidhm `backtrace::resolve`, agus seoltar é beagnach mar ní fios cén cur chun feidhme atá taobh thiar de.
///
///
/// Is féidir le siombail a thabhairt faisnéis chomhthéacsúil faoi fheidhm, mar shampla an t-ainm, ainm comhaid, uimhir líne, Seoladh beacht, etc.
/// Ní bhíonn gach faisnéis ar fáil i siombail i gcónaí, áfach, mar sin cuireann gach modh `Option` ar ais.
///
///
pub struct Symbol {
    // TODO: is gá leanúint den cheangal saoil seo go `Symbol` sa deireadh,
    // ach is athrú ceannródaíoch é sin faoi láthair.
    // Tá sé seo sábháilte anois toisc nach ndéantar `Symbol` a thabhairt amach ach trí thagairt agus ní féidir é a chlónáil.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Tuairisceáin an t-ainm na feidhme seo.
    ///
    /// Is féidir an struchtúr ar ais a úsáid chun airíonna éagsúla a cheistiú faoi ainm an tsiombail:
    ///
    ///
    /// * Cuirfidh cur i bhfeidhm `Display` phriontáil amach an tsiombail demangled.
    /// * Is féidir rochtain a fháil ar luach amh `str` an tsiombail (má tá sé bailí utf-8).
    /// * Is féidir teacht ar na bearta amh don ainm siombail.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Seoltar seoladh tosaigh na feidhme seo ar ais.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Tuairisceáin an ainm comhaid amh mar slice.
    /// Tá sé seo úsáideach go príomha le haghaidh timpeallachtaí `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Tuairisceáin an uimhir colún don áit a bhfuil an tsiombail forghníomhaitheach faoi láthair.
    ///
    /// Ní sholáthraíonn ach gimli luach anseo agus fiú ansin amháin má fhilleann `filename` `Some`, agus mar sin tá sé faoi réir caveat dá samhail dá bharr.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Tuairisceáin an uimhir líne le haghaidh ina bhfuil an tsiombail forghníomhaitheach faoi láthair.
    ///
    /// Tá an luach ar ais de ghnáth `Some` má fhilleann `filename` `Some`, agus tá sé dá bhrí sin faoi réir caveats den chineál céanna.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Seoltar ainm an chomhaid ar ais inar sainíodh an fheidhm seo.
    ///
    /// Níl sé seo ar fáil faoi láthair ach amháin nuair a bhíonn libbacktrace nó gimli á úsáid (m.sh.
    /// unix ardáin eile) agus nuair a thiomsaítear dénártha le debuginfo.
    /// Mura gcomhlíontar ceachtar de na coinníollacha seo is dócha go bhfillfidh sé seo `None`.
    ///
    /// # Gnéithe riachtanacha
    ///
    /// Éilíonn an fheidhm seo gné `std` den `backtrace` crate a chumasú, agus cumasaítear an ghné `std` de réir réamhshocraithe.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // B'fhéidir C pharsáil ++ siombail, más rud é parsáil an tsiombail mangled mar a theip ar Rust.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Bí cinnte a choinneáil ar an náid-iarrachtaí, ionas go bhfuil an ghné `cpp_demangle` gan aon chostas nuair mhíchumas.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Fillteán timpeall ar ainm siombail chun rochtana eirgeanamaíochta a sholáthar don ainm dí-chumtha, na bearta amh, an tsreang amh, srl.
///
// Ceadaigh cód marbh nuair nach bhfuil an ghné `cpp_demangle` cumasaithe.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Cruthaíonn sé ainm siombail nua as na bearta bunúsacha amh.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Filleann sé an t-ainm siombail (mangled) amh mar `str` má tá an tsiombail bailí utf-8.
    ///
    /// Bain úsáid as cur chun feidhme `Display` más mian leat an leagan demangled.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Filleann sé ainm an tsiombail amh mar liosta beart
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // D`fhéadfadh sé seo a phriontáil mura bhfuil an tsiombail dí-bhailithe bailí i ndáiríre, mar sin láimhseáil an earráid anseo go galánta trí gan í a iomadú amach.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Iarracht a éileamh ar ais go chuimhne i dtaisce úsáidtear chun seoltaí symbolicate.
///
/// Beidh an modh seo iarracht a scaoileadh ar bith struchtúir sonraí domhanda atá i dtaisce ar shlí eile ar fud an domhain nó sa snáithe a dhéanann ionadaíocht de ghnáth faisnéis Dwarf pharsáil nó a leithéid.
///
///
/// # Caveats
///
/// Cé go bhfuil an fheidhm seo ar fáil i gcónaí nach ndéanann sé i ndáiríre rud ar bith ar an chuid is mó implementations.
/// Ní sholáthraíonn leabharlanna cosúil le dbghelp nó libbacktrace áiseanna chun an stát leithdháilte a thuiscint agus a bhainistiú.
/// Chun anois tá an ghné `gimli-symbolize` den crate an ghné ach amháin nuair atá aon éifeacht fheidhm seo.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}