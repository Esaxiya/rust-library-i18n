//! Tacaíocht le haghaidh siombailithe ag baint úsáide as an `gimli` crate ar crates.io
//!
//! Is é seo a chur chun feidhme symbolication réamhshocraithe le haghaidh Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // is bréag é an saolré statach chun easpa tacaíochta do struchtúir féinmheastóireachta a hackáil.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Tiontaigh go 'saolré statach ós rud é nár cheart go bhfaigheadh na siombailí ach `map` agus `stash` ar iasacht agus táimid á gcaomhnú thíos.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Do luchtú leabharlanna dúchais ar Windows, féach ar roinnt plé ar rust-lang/rust#71060 do na straitéisí éagsúla anseo.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Faoi láthair ní thacaíonn leabharlanna MinGW le ASLR (rust-lang/rust#16514), ach is féidir DLLanna a athlonnú timpeall sa spás seoltaí.
            // Dealraíonn sé go bhfuil seoltaí i bhfaisnéis dífhabhtaithe uile amhail is dá mbeadh an leabharlann seo luchtaithe ag a "image base", réimse atá ina ceanntásca comhaid COFF.
            // Ós rud é go bhfuil an scéal seo is cosúil debuginfo a muid liosta pharsáil na seoltaí tábla tsiombail agus a stóráil mar a bheadh luchtaithe an leabharlann ag "image base" chomh maith.
            //
            // Ní féidir an leabharlann a luchtú ag "image base", áfach.
            // (Is dócha is féidir rud éigin eile a luchtú ansin?) Tá sé seo nuair a thagann an réimse `bias` i spraoi, agus ní mór dúinn a dhéanamh amach an luach na `bias` anseo.Ar an drochuair cé nach bhfuil sé soiléir conas a fháil seo ó modúl luchtaithe.
            // Is é atá againn, áfach, ná an seoladh ualaigh iarbhír (`modBaseAddr`).
            //
            // Mar rud beag le déanamh as seo amach déanaimid an comhad a mmap, léigh an fhaisnéis faoi cheanntásc an chomhaid, ansin scaoil an mmap.Tá sé seo amú mar beidh orainn athoscailt dócha go bhfuil an mmap ina dhiaidh sin, ach ba chóir é seo ag obair go maith go leor do anois.
            //
            // Nuair a bheidh an `image_base` (suíomh ualaigh inmhianaithe) agus an `base_addr` (suíomh ualaigh iarbhír) againn is féidir linn an `bias` (difríocht idir an iarbhír agus an méid atá ag teastáil) a líonadh isteach agus ansin is é seoladh luaite gach deighleog an `image_base` ós rud é sin a deir an comhad.
            //
            //
            // Chun anois gur dealraitheach go murab ionann agus ELF/MachO féidir linn a dhéanamh a dhéanamh leis deighleog amháin in aghaidh an leabharlann, ag baint úsáide as `modBaseSize` leis an méid ar fad.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS Úsáideann na APIs Mach-O formáid comhaid agus úsáidí DYLD-sonrach a luchtú liosta de na leabharlanna dúchais atá mar chuid den iarratas.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Beir an t-ainm seo leabharlann a fhreagraíonn do an chonair na nuair a luchtú sé chomh maith.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Luchtaigh an header íomhá seo leabharlainne agus a tharmligean chuig `object` a pharsáil uile ordú an t-ualach ionas gur féidir linn an figiúr amach na codanna i gceist anseo.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Abair leo thar na codanna agus clár réigiúin eol do codanna sin fhaighimid.
            // De bhreis air sin, déan deighleoga téacs faisnéise a thaifeadadh lena bpróiseáil níos déanaí, féach na tráchtanna thíos.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Aimsigh an "slide" don leabharlann a chríochnaíonn suas a bheith ar an claonadh a úsáidimid chun an figiúr amach cén áit i rudaí gcuimhne luchtaítear.
            // Is beag an ríomh aisteach é seo áfach agus is toradh é ar chúpla rud a thriail san fhiántas agus na rudaí a chloiseann a fheiceáil.
            //
            // Is é an smaoineamh ginearálta go mbeidh an `bias` móide `stated_virtual_memory_address` deighleog ann áit a bhfuil an deighleog sa spás seoltaí iarbhír.
            // Is é an rud eile a mbímid ag brath air ná gurb é fíor-sheoladh lúide an `bias` an t-innéacs le breathnú suas sa tábla siombailí agus debuginfo.
            //
            // Tarlaíonn sé, áfach, go bhfuil na ríomhanna seo mícheart i gcás leabharlanna atá luchtaithe le córais.Maidir le executables dúchais, áfach, gur dealraitheach ceart.
            // Le loighic éigin a ardú ó fhoinse LLDB tá cásáil speisialta aige don chéad chuid `__TEXT` atá luchtaithe ó fhritháireamh comhad 0 le méid nonzero.
            // Ar chúis ar bith nuair a bhíonn sé seo i láthair dealraíonn sé go gciallaíonn sé go bhfuil an tábla siombailí i gcoibhneas leis an sleamhnán vmaddr don leabharlann amháin.
            // Má tá sé *nach* i láthair ansin an tábla tsiombail i gcoibhneas leis an an sleamhnán vmaddr móide an míre seoladh luaite.
            //
            // A láimhseáil an staid seo más rud é nach bhfuil muid a *aimsiú* alt téacs ar comhad a fhritháireamh náid ansin dúinn cur leis an claonadh ag an chéad hailt téacs Seoladh an luaite agus laghdú gach seoladh atá luaite ag an méid sin chomh maith.
            //
            // Sa chaoi sin is é an tábla tsiombail gcónaí is cosúil i gcomparáid leis an méid claonadh na leabharlainne.
            // Dealraíonn sé go bhfuil na torthaí cearta air seo chun siombail a dhéanamh tríd an tábla siombailí.
            //
            // Go hionraic nílim iomlán cinnte an bhfuil sé seo ceart nó an bhfuil rud éigin eile ann a thabharfadh le fios conas é seo a dhéanamh.
            // Go dtí seo cé gur cosúil go n-oibríonn sé seo (?) sách maith agus ba cheart go mbeimis in ann é seo a tweakáil le himeacht ama más gá.
            //
            // Le haghaidh tuilleadh faisnéise féach #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Eile Unix (eg
        // Linux) ardáin úsáid ELF mar formáid an chomhaid réad agus de ghnáth a chur i bhfeidhm API dtugtar `dl_iterate_phdr` a luchtú leabharlanna dúchais.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` ba chóir go mbeadh leideanna bailí ann.
        // `vec` ba chóir go mbeadh pointeoir bailí ar `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 ní thacaíonn sé go dúchasach le faisnéis dífhabhtaithe, ach cuirfidh an córas tógála faisnéis dífhabhtaithe ag cosán `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Ba chóir gach rud eile a úsáid ELF, ach níl a fhios conas a luchtú leabharlanna dúchais.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Gach leabharlann roinnte ar eolas atá luchtaithe.
    libraries: Vec<Library>,

    /// Mapálacha taisce i gcás choinneáil ag muid ag pharsáil eolas dwarf.
    ///
    /// Tá an liosta cumas socraithe dá liftime iomlán a ardaíonn riamh.
    /// Is í an eilimint `usize` de gach péire innéacs isteach i `libraries` thuas áit a léiríonn `usize::max_value()` an inrite reatha.
    ///
    /// Is é an `Mapping` faisnéis dwarf parsáilte comhfhreagrach.
    ///
    /// Tabhair faoi deara go bhfuil sé seo go bunúsach ar taisce LRU agus beidh orainn a bheith ag aistriú rudaí thart anseo mar shiombail muid ag seoltaí.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Deighleoga den leabharlann luchtú i gcuimhne, agus nuair a bhíonn siad luchtaithe.
    segments: Vec<LibrarySegment>,
    /// An "bias" an leabharlann, de ghnáth nuair a tá sé luchtaithe i gcuimhne.
    /// Cuirtear an luach seo le seoladh luaite gach deighleog chun an seoladh cuimhne fíorúil iarbhír a bhfuil an deighleog luchtaithe ann a fháil.
    /// De bhreis air sin baintear an claonadh seo ó sheoltaí cuimhne fíorúla fíorúla chun innéacsú a dhéanamh ar dhífhabhtaithe agus ar an tábla siombailí.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Seoladh luaite na coda seo sa chomhad réada.
    /// Tá sé seo nach bhfuil i ndáiríre i gcás ina bhfuil an deighleog luchtaithe, ach tá an seoladh móide den leabharlann ina bhfuil ar `bias` gcás go bhfaighidh sé.
    ///
    stated_virtual_memory_address: usize,
    /// Méid na deighleog ths sa chuimhne.
    len: usize,
}

// neamhshábháilte mar gheall ar an a cheanglaítear a synchronized go seachtrach
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // neamhshábháilte mar gheall ar an a cheanglaítear a synchronized go seachtrach
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Taisce LRU an-bheag agus an-simplí le haghaidh mapáil faisnéise dífhabhtaithe.
        //
        // Ba cheart go mbeadh an ráta buailte an-ard, ós rud é nach dtrasnaíonn an ghnáthchruach idir go leor leabharlanna roinnte.
        //
        // Tá na struchtúir `addr2line::Context` daor go leor a chruthú.
        // Táthar ag súil a chostas a bheidh le amúchta ag seirbhísí ceisteanna `locate` ina dhiaidh sin, a ghiaráil tógadh na struchtúir á dtógáil `addr2line: : Context`s a fháil speedups deas.
        //
        // Mura mbeadh an taisce seo againn, ní tharlódh an t-amúchadh sin go deo, agus bheadh ssssllllooooowwww mar chúlra siombalach.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // An Chéad suas, tástáil má tá an `lib` aon deighleog ina bhfuil na (athlonnú láimhseáil) `addr`.Má éiríonn leis an seic seo is féidir linn leanúint ar aghaidh thíos agus an seoladh a aistriú.
                //
                // Tabhair faoi deara go bhfuil `wrapping_add` á úsáid againn anseo chun seiceálacha thar maoil a sheachaint.Tá sé le feiceáil san fhiántas go sáraíonn ríomh claonta SVMA +.
                // Dealraíonn sé rud beag aisteach mbeadh a tharlaíonn ach ní níl méid ollmhór is féidir linn a dhéanamh faoi ach amháin is dócha go neamhaird a dhéanamh ach na codanna toisc go mbíonn siad ag cur in iúl dócha amach sa spás.
                //
                // Tháinig sé seo suas ar dtús i rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Anois bhfuil a fhios againn go bhfuil `lib` `addr`, is féidir linn a fhritháireamh leis an claonadh chun seoladh chuimhne luaite virutal.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Do-athraithe: tar éis an Críochnaíonn coinníollach gan go luath ar ais
        // ó earráid, tá iontráil an taisce don chosán seo ag innéacs 0.

        if let Some(idx) = idx {
            // Nuair a bhíonn an t-mhapáil cheana féin sa taisce, é a aistriú go dtí an tosaigh.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Nuair nach bhfuil an mhapáil sa taisce, cruthaigh mapáil nua, cuir isteach é os comhair an taisce, agus díshealbhaigh an iontráil taisce is sine más gá.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // ná sceitheadh ar feadh an tsaoil `'static`, déan cinnte go bhfuil sé scópáilte go díreach dúinn féin
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Saolré `sym` a leathnú go `'static` ós rud é go gceanglaítear orainn anseo ar an drochuair, ach tá sé ag dul amach mar thagairt riamh agus mar sin níor cheart go leanfaí de thagairt dó níos faide ná an fráma seo ar aon nós.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Faoi dheireadh, faigh mapáil i dtaisce nó cruthaigh mapáil nua don chomhad seo, agus déan meastóireacht ar fhaisnéis DWARF chun an file/line/name a fháil don seoladh seo.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Bhí muid in ann a aimsiú eolas fráma don tsiombail, agus `tá hinmheánach addr2line` ar fhráma na sonraí go léir nitty gritty.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Níorbh fhéidir faisnéis dífhabhtaithe a fháil, ach fuaireamar í i dtábla siombailí an elf inrite.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}