#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Formáiditheoir le haghaidh cúltacaí.
///
/// Is féidir an cineál seo a úsáid chun cúlra a phriontáil is cuma cá as a dtagann an cúlra féin.
/// Má tá cineál `Backtrace` agat ansin úsáideann a chur i bhfeidhm `Debug` an fhormáid priontála seo cheana féin.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Na stíleanna priontála is féidir linn a phriontáil
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Priontaíonn sé cúlra níos déine nach bhfuil ann ach faisnéis ábhartha go hidéalach
    Short,
    /// Priontaíonn sé cúlra ina bhfuil gach faisnéis is féidir
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Cruthaigh `BacktraceFmt` nua a scríobhfaidh aschur chuig an `fmt` atá curtha ar fáil.
    ///
    /// Déanfaidh an argóint `format` rialú ar an stíl ina ndéantar an cúlra a phriontáil, agus úsáidfear argóint `print_path` chun cásanna `BytesOrWideString` d`ainmneacha comhaid a phriontáil.
    /// Ní dhéanann an cineál seo féin aon ainmneacha comhaid a phriontáil, ach is gá an aisghlaoch seo a dhéanamh.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Priontaí brollach don chúlra ar tí a bheith i gcló.
    ///
    /// Teastaíonn sé seo ar roinnt ardáin chun cúltacaí a shiombail go hiomlán níos déanaí, agus ar shlí eile níor cheart gurb é seo an chéad mhodh a ghlaonn tú tar éis `BacktraceFmt` a chruthú.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Cuireann sé fráma leis an aschur cúl-lorg.
    ///
    /// Tugann an tiomantas seo sampla RAII de `BacktraceFrameFmt` ar ais is féidir a úsáid chun fráma a phriontáil i ndáiríre, agus ar scriosadh é méadóidh sé an cuntar fráma.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Comhlánaíonn sé an t-aschur backtrace.
    ///
    /// Ní haon-op é seo faoi láthair ach cuirtear leis le haghaidh comhoiriúnacht future le formáidí backtrace.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Faoi láthair níl aon op-op-lena n-áirítear an hook seo chun breisithe future a cheadú.
        Ok(())
    }
}

/// Formáiditheoir le haghaidh fráma amháin de chúlra.
///
/// Cruthaítear an cineál seo leis an bhfeidhm `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Priontaí `BacktraceFrame` leis an bhformáiditheoir fráma seo.
    ///
    /// Beidh sé seo a phriontáil hathchúrsach gach cás `BacktraceSymbol` laistigh den `BacktraceFrame`.
    ///
    /// # Gnéithe riachtanacha
    ///
    /// Éilíonn an fheidhm seo gné `std` den `backtrace` crate a chumasú, agus cumasaítear an ghné `std` de réir réamhshocraithe.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Priontaí `BacktraceSymbol` laistigh de `BacktraceFrame`.
    ///
    /// # Gnéithe riachtanacha
    ///
    /// Éilíonn an fheidhm seo gné `std` den `backtrace` crate a chumasú, agus cumasaítear an ghné `std` de réir réamhshocraithe.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: níl sé seo iontach nach ndéanaimid aon rud a phriontáil
            // le hainmneacha comhaid neamh-utf8.
            // Buíochas le Dia beagnach gach rud utf8 mar sin ní ba chóir é seo a bheith ró-ró-olc.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Priontaí a amh rianú `Frame` agus `Symbol`, de ghnáth ó laistigh de callbacks amh an crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Cuireann fráma amh leis an aschur backtrace.
    ///
    /// Glacann an modh seo, murab ionann agus an ceann roimhe seo, na hargóintí amh ar eagla go mbeadh siad á bhfoinse ó áiteanna éagsúla.
    /// Tabhair faoi deara go d'fhéadfadh sé seo a bheith ar a dtugtar amanna éagsúla le haghaidh fráma amháin.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Cuireann fráma amh leis an aschur cúlbhrait, lena n-áirítear faisnéis faoi cholúin.
    ///
    /// Glacann an modh seo, cosúil leis an gceann roimhe seo, na hargóintí amh ar eagla go mbeadh siad á bhfoinse ó áiteanna éagsúla.
    /// Tabhair faoi deara go d'fhéadfadh sé seo a bheith ar a dtugtar amanna éagsúla le haghaidh fráma amháin.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Ní féidir le Fuchsia siombail a dhéanamh laistigh de phróiseas agus mar sin tá formáid speisialta aici is féidir a úsáid chun siombail a dhéanamh níos déanaí.
        // Priontáil é sin in ionad seoltaí a phriontáil inár bhformáid féin anseo.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Níl gá a phriontáil frámaí "null", go bunúsach ciallaíonn sé ach go raibh an cúl-lorg córas le beagán fonn a rianú ar ais Super dtí seo.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Chun méid TCB a laghdú i gclúdach Sgx, nílimid ag iarraidh feidhmiúlacht réitigh siombailí a chur i bhfeidhm.
        // Ina ionad sin, is féidir linn fritháireamh an seoladh a phriontáil anseo, a d`fhéadfaí a mhapáil níos déanaí chun an fheidhm cheart a bhaint amach.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Priontáil innéacs an fhráma chomh maith le pointeoir treoracha roghnach an fhráma.
        // Má táimid níos faide ná an chéad siombail den fhráma seo cé nach ndéanaimid ach spás bán oiriúnach a phriontáil.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Ansin scríobh amach ainm an tsiombail, agus an fhormáidiú malartach á úsáid agat chun tuilleadh faisnéise a fháil más cúlra iomlán muid.
        // Déanaimid láimhseáil freisin ar shiombailí nach bhfuil ainm orthu,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Agus seo caite, priontáil amach an uimhir filename/line má tá siad ar fáil.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line i gcló ar línte faoin ainm siombail, mar sin a phriontáil beagán spás bán cuí a shórtáil de dheis-ailíniú dúinn féin.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Tharmligean chuig ár thug inmheánach a phriontáil ar an ainm comhaid agus ansin a phriontáil amach an uimhir líne.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Cuir uimhir an cholúin leis, má tá sí ar fáil.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Táimid ar cúram ach thart ar an chéad siombail de fhráma
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}