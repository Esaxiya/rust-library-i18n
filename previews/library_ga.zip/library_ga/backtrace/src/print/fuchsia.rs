use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // Glacann dl_iterate_phdr aisghlaoch a gheobhaidh pointeoir dl_phdr_info do gach DSO atá nasctha leis an bpróiseas.
    // dl_iterate_phdr Cinntíonn freisin go bhfuil an t-nascóir dinimiciúil ghlas ó thús go deireadh an atriall.
    // Má fhilleann an aisghlaoch luach neamh-nialasach, cuirfear deireadh leis an atriall go luath.
    // 'data' a chur ar aghaidh mar an tríú argóint leis an callback ar gach glao.
    // 'size' tugann sé méid an dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Ní mór dúinn an ID tógála agus roinnt sonraí bunúsacha ceanntásc cláir a pharsáil a chiallaíonn go dteastaíonn beagán rudaí uainn ón sonra ELF freisin.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Anois ní mór dúinn struchtúr an chineáil dl_phdr_info a mhacasamhlú a úsáideann nascóir dinimiciúil reatha fuchsia a mhacasamhlú.
// Tá an teorainn ABI seo ag cróimiam chomh maith le crashpad.
// Eventully ba mhaith linn buíochas a bhogadh na cásanna a úsáid elf-chuardach ach ba mhaith linn gá foráil a dhéanamh go an SDK agus curtha déanta go fóill.
//
// Mar sin táimidne (agus iad) i bhfostú go gcaithfimid an modh seo a úsáid a mbíonn cúpláil daingean leis an fuchsia libc ann.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Tá aon bhealach a fhios agam seiceáil an e_phoff agus tá e_phnum bailí.
    // Ba chóir go gcinnteodh libc é seo dúinn, áfach, ionas go mbeidh sé sábháilte slis a fhoirmiú anseo.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Léiríonn Elf_Phdr ceanntásc clár ELF 64-giotán i ndeireadh na hailtireachta sprice.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Léiríonn Phdr ceanntásc bailí clár ELF agus a bhfuil ann.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Níl aon bhealach againn a sheiceáil an bhfuil p_addr nó p_memsz bailí.
    // Déanann libc Fuchsia na nótaí a pharsáil ar dtús, ach mar sin de bhua a bheith anseo caithfidh na ceanntásca seo a bheith bailí.
    //
    // Ní éilíonn NoteIter go mbeidh na sonraí bunúsacha bailí ach éilíonn sé go mbeidh na teorainneacha bailí.
    // Tá súil againn gur chinntigh libc gurb é seo an cás dúinn anseo.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// An cineál nóta do IDs thógáil.
const NT_GNU_BUILD_ID: u32 = 3;

// Is ionann Elf_Nhdr nóta header ELF i endianness an sprioc.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Léiríonn nóta nóta ELF (ceanntásc + ábhar).
// Fágtar an t-ainm mar shlis u8 toisc nach gcuirtear deireadh leis i gcónaí agus déanann rust é éasca go leor a sheiceáil go bhfuil na bearta comhoiriúnach do gach bealach.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter ligeann tú iterate go sábháilte thar teascán nóta.
// gcríochnaíonn sé chomh luath agus a tharlaíonn earráid nó nach bhfuil aon nótaí níos mó.
// Má tá tú ag iterate thar neamhbhailí sonraí mbeidh sé feidhm fé is dá mbeadh aimsíodh aon nótaí.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Is athraitheach fheidhm sin an pointeoir agus méid a tugadh á thaispeáint ar réimse bailí bytes is féidir a léamh go léir.
    // Is féidir le hábhar na mbeart seo a bheith ina rud ar bith ach caithfidh an raon a bheith bailí chun go mbeidh sé seo sábháilte.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// ailíníonn align_to 'x' le hailíniú 'to'-byte ag glacadh leis gur cumhacht 2 é 'to'.
// Leanann sé seo patrún caighdeánach i gcód parsála C/C ++ ELF ina n-úsáidtear (x + go, 1)&-to.
// Ní ligeann Rust duit dearmad a dhéanamh ar úsáid mar sin úsáidim
// comhshó 2's-chomhlánú ar athchruthú sin.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// Tógann take_bytes_align4 num bytes ón slice (má tá sé i láthair) agus cinntíonn sé freisin go bhfuil an slice deiridh ailínithe i gceart.
// Má tá líon na mbeart a iarrtar ró-mhór nó mura féidir an slice a athailíniú ina dhiaidh sin toisc nach bhfuil go leor beart fágtha, ní chuirtear aon cheann ar ais agus ní athraítear an slice.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Tá an fheidhm aon invariants fíor ní mór don té atá ag glaoch seasamh ach amháin b'fhéidir gur chóir 'bytes' a ailíniú le feidhmíocht (agus ar roinnt ailtireachtaí cruinneas).
// D'fhéadfadh na luachanna sna réimsí Elf_Nhdr a nonsense ach cinntíonn an fheidhm seo aon rud den sórt.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Tá sé seo sábháilte fad is go bhfuil go leor spáis ann agus dhearbhaíomar díreach nár cheart go mbeadh sé seo neamhshábháilte sa ráiteas thuas.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Tabhair faoi deara go bhfuil sice_of: :<Elf_Nhdr>() ailínithe 4-bheart i gcónaí.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Seiceáil an bhfuil an deireadh sroichte againn.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Aistrímid amach nhdr ach déanaimid machnamh cúramach ar an struchtúr a leanann as.
        // Ní chuirimid muinín an namesz nó descsz agus dhéanaimid aon cinntí baolach atá bunaithe ar an gcineál.
        //
        // Mar sin, fiú má fhaighimid truflais iomlán amach ba chóir dúinn a bheith sábháilte fós.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Léiríonn sé go bhfuil le teascán inrite.
const PERM_X: u32 = 0b00000001;
/// Tugann sé le fios go bhfuil teascán inscríofa.
const PERM_W: u32 = 0b00000010;
/// Tugann sé le fios go bhfuil teascán inléite.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Is ionann an deighleog ELF ag runtime.
struct Segment {
    /// Tugann sé seoladh fíorúil runtime ábhar na coda seo.
    addr: usize,
    /// Tugann an méid gcuimhne na n-ábhar deighleog seo.
    size: usize,
    /// Tugann seoladh fíorúil modúl na coda seo leis an gcomhad ELF.
    mod_rel_addr: usize,
    /// Tugann sé na ceadanna atá le fáil sa chomhad ELF.
    /// Ní gá gurb iad na ceadanna sin na ceadanna a bhíonn i láthair ag am rith, áfach.
    flags: Perm,
}

/// Lig ite amháin thar Deighleoga ó DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Is ionann an OCD ELF (Cuspóir Dinimiciúla Roinnte).
/// Tagraíonn an cineál seo do na sonraí atá stóráilte sa DSO iarbhír seachas a gcóip féin a dhéanamh.
struct Dso<'a> {
    /// Tugann an nascóir dinimiciúil i gcónaí dúinn ainm, fiú má tá an t-ainm folamh.
    /// I gcás an inrite is mó a bheidh an ainm seo a bheith folamh.
    /// I gcás comhréada beidh sé ar an soname (féach DT_SONAME).
    name: &'a str,
    /// Ar Fuchsia tá IDanna tógtha ag beagnach gach binaries ach ní dianriachtanas é seo.
    /// Níl aon bhealach ann faisnéis DSO a mheaitseáil le fíorchomhad ELF ina dhiaidh sin mura bhfuil build_id ann agus mar sin éilímid go mbeidh ceann anseo ag gach DSO.
    ///
    /// Déantar neamhaird de DSOanna gan build_id.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Seoltar atriall thar Deighleoga sa DSO seo.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Na hearráidí ionchódú ceisteanna a thagann chun cinn le linn parsáil eolas faoi gach OCD.
///
enum Error {
    /// Ciallaíonn NameError gur tharla earráid agus sreang stíl C á thiontú ina sreang rust.
    ///
    NameError(core::str::Utf8Error),
    /// Ciallaíonn BuildIDError nach bhfuaireamar ID tógála.
    /// D`fhéadfadh sé seo a bheith leis toisc nach raibh aon ID tógála ag an DSO nó toisc go raibh an deighleog ina raibh an ID tógála mífhoirmithe.
    ///
    BuildIDError,
}

/// Glaonna 'dso' nó 'error' ar gach DSO atá nasctha leis an bpróiseas ag an nascóir dinimiciúil.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter a mbeidh ceann de na modhanna ithe aige ar a dtugtar DSO foreach.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // Cinntíonn dl_iterate_phdr go ndíreoidh info.name ar shuíomh bailí.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Priontaíonn an fheidhm seo marcáil siombailí Fuchsia don fhaisnéis uile atá i DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}