# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Leabharlann chun cúltacaí a fháil ag am rith do Rust.
Tá sé mar aidhm ag an leabharlann seo tacaíocht na leabharlainne caighdeánaí a fheabhsú trí chomhéadan ríomhchláraithe a sholáthar le bheith ag obair leis, ach tacaíonn sí go simplí leis an gcúlchúl reatha cosúil le panics libstd a phriontáil.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Chun cúlrian a ghabháil agus déileáil leis a chur siar go dtí tráth níos déanaí, is féidir leat an cineál `Backtrace` barrleibhéil a úsáid.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Más mian leat, áfach, rochtain níos amh ar an bhfeidhmiúlacht rianaithe iarbhír, is féidir leat na feidhmeanna `trace` agus `resolve` a úsáid go díreach.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Réiteach an pointeoir teagaisc a ainm siombail
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // a choinneáil ag dul go dtí an fráma seo chugainn
    });
}
```

# License

Tá an tionscadal seo ceadúnaithe faoi cheachtar de

 * Ceadúnas Apache, Leagan 2.0, ([LICENSE-APACHE](LICENSE-APACHE) nó http://www.apache.org/licenses/LICENSE-2.0)
 * Ceadúnas MIT ([LICENSE-MIT](LICENSE-MIT) nó http://opensource.org/licenses/MIT)

ar do rogha.

### Contribution

Mura luann tú a mhalairt go sainráite, beidh aon ranníocaíocht a chuirfidh tú isteach d`aon ghnó lena cur san áireamh i gcúl-earraí agat, mar a shainmhínítear sa cheadúnas Apache-2.0, dé-cheadúnaithe mar atá thuas, gan aon téarmaí nó coinníollacha breise.







