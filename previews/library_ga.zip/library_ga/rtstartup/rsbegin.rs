// rsbegin.o agus tá rsend.o an "compiler runtime startup objects" mar a thugtar.
// Tá cód iontu a theastaíonn chun an t-am tiomsaitheora a thosú i gceart.
//
// Nuair a bhíonn an íomhá inrite nó dylib nasctha, tá gach cód úsáideora agus leabharlanna "sandwiched" idir an dá comhaid réad, mar sin cód nó sonraí ó rsbegin.o bheith den chéad uair sa hailt faoi seach den íomhá, ach cód agus sonraí ó rsend.o bheith na cinn seo caite.
// Is féidir an éifeacht a úsáid chun siombailí ar siúl ag tús nó ag deireadh an t-alt, chomh maith le a chur isteach le haon cheanntásca nó Buntásca ag teastáil.
//
// Tabhair faoi deara go bhfuil pointe iontrála iarbhír an mhodúil suite san réad tosaithe runtime C (ar a dtugtar `crtX.o` de ghnáth), a agairt ansin glaonna ar thúsú comhpháirteanna runtime eile (cláraithe trí rannán íomhá speisialta eile fós).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Marcanna ag tús an rannáin faisnéise fráma fráma cruachta
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Scratch spás le haghaidh leabhar inmheánach an díshealbhóra.
    // Sainmhínítear é seo mar `struct object` in $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Gnáthaimh eolais neamh-ghafa registration/deregistration.
    // Féach docs libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // cláraigh faisnéis gan staonadh maidir le tosaithe an mhodúil
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // neamhchláraithe ar múchadh
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-sonrach clárúcháin init/uninit ghnáthamh
    pub mod mingw_init {
        // Iarrfaidh rudaí tosaithe MinGW (crt0.o/dllcrt0.o) tógálaithe domhanda sna rannáin .ctors agus .dtors ar am tosaithe agus imeachta.
        // I gcás DLLanna, déantar é seo nuair a dhéantar an DLL a luchtú agus a dhíluchtú.
        //
        // Beidh an nascóir shórtáil na míreanna, a chinntíonn go bhfuil ár n-callbacks suite ag deireadh an liosta.
        // Ós rud é go reáchtáiltear tógálaithe in ord droim ar ais, cinntíonn sé seo gurb iad na glaonna ar ais an chéad cheann agus an ceann deireanach a cuireadh i gcrích.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors *: . callbacks C initialization
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: Glaonna foirceanta C.
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}