//! Windows SEH
//!
//! Ar Windows (ar MSVC faoi láthair), is é an mheicníocht láimhseála eisceachta réamhshocraithe Láimhseáil Eisceachta Struchtúrtha (SEH).
//! Tá sé seo an-éagsúil le láimhseáil eisceachta bunaithe ar Dwarf (m.sh., an méid a úsáideann ardáin unix eile) i dtéarmaí intéirnigh tiomsaitheora, mar sin éilítear ar LLVM tacaíocht mhaith a bheith acu do SEH.
//!
//! In a nutshell, cad a tharlaíonn anseo ná:
//!
//! 1. Iarrann an fheidhm `panic` an caighdeán fheidhm Windows `_CxxThrowException` le caith C++ -cosúil le eisceacht, a chuireann faoi deara an bpróiseas unwinding.
//! 2.
//! Gach pads tuirlingthe a ghineann an tiomsaitheoir a bhaint as an fheidhm pearsantacht `__CxxFrameHandler3`, feidhm sa CRT, agus beidh an cód unwinding sa Windows úsáid as an fheidhm pearsantacht a fhorghníomhú go léir cód glanta ar an chairn.
//!
//! 3. Tá ceap tuirlingthe socraithe ag gach glao a ghineann tiomsaitheoir chuig `invoke` mar threoir `cleanuppad` LLVM, a léiríonn tús an ghnáthamh glantacháin.
//! Tá an pearsantacht (i gcéim 2, atá sainithe sa CRT) freagrach as na gnáthaimh glanta.
//! 4. Faoi dheireadh déantar an cód "catch" sa intreach `try` (a ghineann an tiomsaitheoir) a fhorghníomhú agus tugann sé le fios gur cheart go dtiocfadh an rialú ar ais go Rust.
//! Déantar é seo trí threoir `catchswitch` móide treoir `catchpad` i dtéarmaí IR LLVM, agus ar deireadh gnáth-rialú a chur ar ais ar an gclár le treoir `catchret`.
//!
//! Is iad seo a leanas roinnt difríochtaí sonracha ón láimhseáil eisceachta bunaithe ar gcc:
//!
//! * Níl aon fheidhm pearsantachta saincheaptha ag Rust, tá sé ina ionad *i gcónaí*`__CxxFrameHandler3`.De bhreis air sin, ní dhéantar aon scagadh breise, agus mar sin caithfimid aon eisceacht C++ a tharlaíonn a bheith cosúil leis an gcineál atá á chaitheamh againn.
//! Tabhair faoi deara go bhfuil throwing eisceacht Rust ar iompar undefined ar aon nós, agus mar sin ba chóir é seo a chur air.
//! * Táimid agam cuid de na sonraí a tharchur thar an teorainn unwinding, go sonrach a `Box<dyn Any + Send>`.Cosúil le heisceachtaí Dwarf, stóráiltear an dá threo seo mar ualach pá san eisceacht féin.
//! Maidir le MSVC, áfach, ní gá leithdháileadh breise carn a dhéanamh toisc go gcaomhnaítear an chruach glaonna agus feidhmeanna scagaire á gcur i gcrích.
//! Ciallaíonn sé go bhfuil na leideanna ar aghaidh go díreach chuig `_CxxThrowException` a aisghabháil ansin san fheidhm scagaire a bheith scríofa ar an fráma cruaiche le linn na intreach `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Ní mór gur Rogha é seo toisc go nglacaimid leis an eisceacht trí thagairt agus go ndéanann a runtime C++ a scriosta a fhorghníomhú.
    // Nuair a chur orainn an Bosca as an eisceacht, ní mór dúinn a fhágáil ar an eisceacht i stát bailí dá destructor a reáchtáil gan dúbailte-dropping an Bosca.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// An Chéad suas, a bunch iomlán de sainmhínithe chineál.Tá cúpla rud a bhaineann go sonrach le hardáin anseo, agus go leor nach bhfuil ach cóipeáilte go soiléir ó LLVM.Is é an aidhm atá leis an uile leis an fheidhm `panic` thíos a chur i bhfeidhm trí glaoch a `_CxxThrowException`.
//
// Glacann an fheidhm seo dhá argóint.Is pointeoir é an chéad cheann maidir leis na sonraí a bhfuilimid ag cur isteach iontu, agus sa chás seo is é ár réad trait.Pretty éasca a fháil!An chéad, áfach, níos mó casta.
// Tá sé seo ar pointeoir le struchtúr `_ThrowInfo`, agus tá sé i gcoitinne i gceist ach chun cur síos ach an eisceacht á thrown.
//
// Faoi láthair tá an sainmhíniú ar an gcineál seo [1] beagáinín gruagach, agus is é an príomh-aisteach (agus an difríocht ón alt ar líne) gur leideanna iad na leideanna ar 32-giotán ach ar 64-giotán cuirtear na leideanna in iúl mar fhritháireamh 32-giotán ón Siombail `__ImageBase`.
//
// Úsáidtear an macra `ptr_t` agus `ptr!` sna modúil thíos chun é seo a chur in iúl.
//
// Leanann lúbra na sainmhínithe cineáil go dlúth leis an méid a astaíonn LLVM don chineál seo oibríochta.Mar shampla, má tá tú a chur le chéile C++ seo cód ar MSVC agus scaoileann an IR LLVM:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      neamhní foo() { rust_panic a = {0, 1};
//          caith a;}
//
// Sin go bunúsach cad tá muid ag iarraidh a aithris.An chuid is mó de na luachanna tairiseach thíos bhí a chóipeáil go díreach ó LLVM,
//
// Cibé scéal é, tógtar na struchtúir seo go léir ar an gcaoi chéanna, agus níl ann ach briathar dúinn.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Tabhair faoi deara go ndéanaimid neamhaird d`aon ghnó ar rialacha mangaireachta ainmneacha: nílimid ag iarraidh go mbeidh C++ in ann Rust panics a ghabháil trí `struct rust_panic` a dhearbhú.
//
//
// Agus tú ag athrú, déan cinnte go bhfuil an teaghrán ainm cineáil comhoiriúnach go díreach leis an gceann a úsáidtear in `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Is comhartha draíochta é an príomh-bheart `\x01` anseo i ndáiríre chuig LLVM chun *ní* mangaireacht eile cosúil le réimír le carachtar `_` a chur i bhfeidhm.
    //
    //
    // Is í an tsiombail seo an so-úsáidte a úsáideann C++ 's `std::type_info`.
    // tá Cuspóirí an chineál `std::type_info`, tuairisceoirí chineál, pointeoir leis an tábla.
    // Déantar tagairt do thuairiscí cineáil ag na struchtúir C++ EH atá sainithe thuas agus a dhéanaimid thíos.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Ní úsáidtear an tuairiscitheoir cineáil seo ach amháin nuair a bhíonn eisceacht á caitheamh.
// Tá an chuid ghabháil láimhseáil ag an intreach iarracht, a ghineann a TypeDescriptor féin.
//
// Tá an fhíneáil ó na húsáidí runtime MSVC comparáid teaghrán ar an t-ainm gcineál do TypeDescriptors mheaitseáil seachas comhionannas pointeoir.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Scriosóir a úsáidtear má chinneann an cód C++ an eisceacht a ghabháil agus é a fhágáil gan é a iomadú.
// Socróidh an chuid gabhála den iarracht intreach an chéad fhocal den réad eisceachtúil go 0 ionas go mbeidh an scriosóir scipeáilte air.
//
// Tabhair faoi deara go n-úsáideann x86 Windows an coinbhinsiún glaonna "thiscall" le haghaidh feidhmeanna ball C++ in ionad an choinbhinsiúin ghlaonna réamhshocraithe "C".
//
// Is é an fheidhm exception_copy speisialta beagán anseo: tá sé agairt ag an runtime MSVC faoi bloc try/catch agus an panic a ghineann muid anseo a úsáid mar thoradh ar an chóip eisceacht.
//
// Tá sé seo in úsáid ag an C++ runtime chun tacaíocht a thabhairt eisceachtaí a ghabháil leis std::exception_ptr, nach féidir linn tacaíocht a thabhairt mar gheall ar Bosca<dyn Any>níl sé clonable.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException Fhorghníomhú go hiomlán ar an fráma cruaiche le linn, mar sin níl aon ghá a aistriú ar shlí eile `data` leis an gcarn.
    // Ní thugaimid ach pointeoir cruachta don fheidhm seo.
    //
    // Teastaíonn an ManuallyDrop anseo ós rud é nach dteastaíonn uainn go dtitfí Eisceacht agus muid ag scaoileadh.
    // Ina áit sin scaoilfear é le eisceacht_cleanup a agraíonn an rith-ama C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // D`fhéadfadh sé seo a bheith ionadh, agus go fírinneach mar sin.Ar 32-giotán MSVC iad na leideanna idir na struchtúr díreach, leideanna.
    // Ar 64-giotán MSVC, áfach, na leideanna idir struchtúir in iúl in áit mar offsets 32-giotán ó `__ImageBase`.
    //
    // Mar thoradh air sin, ar 32-giotán MSVC is féidir linn a dhearbhú go léir na leideanna sa `static`s thuas.
    // Ar 64-giotán MSVC, ba mhaith linn a bheith dealú threo i statics, agus nach bhfuil de Rust cheadú faoi láthair a chur in iúl, mar sin ní féidir linn a dhéanamh i ndáiríre go.
    //
    // An chéad rud is fearr, is é sin a líonadh sna struchtúir ag runtime (Is panicking cheana féin ar an "slow path" ar aon nós).
    // Mar sin anseo déanaimid na réimsí pointeora seo go léir a athmhíniú mar shlánuimhreacha 32-giotán agus ansin an luach ábhartha a stóráil ann (go adamhach, mar d`fhéadfadh panics comhthráthach a bheith ag tarlú).
    //
    // Go teicniúil beidh an runtime a dhéanamh is dócha a léamh nonatomic de na réimsí, ach go teoiriciúil siad riamh a léamh an mícheart * * luach sin níor chóir é a bheith ró-olc ...
    //
    // In aon chás, ní mór dúinn go bunúsach rud éigin mar seo a dhéanamh go dtí gur féidir linn a chur in iúl oibríochtaí níos mó i statics (agus ní féidir linn a bheith in ann).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Ciallaíonn pálasta NULL anseo go bhfuair muid anseo ó ghabháil (...) na __rust_try.
    // Tarlaíonn sé seo nuair a bhíonn eisceacht eachtrach neamh-Rust gafa.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Éilíonn an tiomsaitheoir air seo a bheith ann (m.sh., is mír lang é), ach ní ghlaonn an tiomsaitheoir air i ndáiríre toisc gurb é __C_specific_handler nó _except_handler3 an fheidhm pearsantachta a úsáidtear i gcónaí.
//
// Dá bhrí sin níl anseo ach stumpa ginmhillte.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}