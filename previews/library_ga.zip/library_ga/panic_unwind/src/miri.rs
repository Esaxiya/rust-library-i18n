//! panics gan sreang do Miri.
use alloc::boxed::Box;
use core::any::Any;

// An cineál an pálasta go propagates an t-inneall Miri trí unwinding dúinn.
// Caithfidh sé a bheith pointeoir.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Feidhm sheachtrach arna soláthar ag Miri chun tosú ag scaoileadh.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Beidh an pálasta pas againn go `miri_start_panic` díreach mar an argóint a fháil againn i `cleanup` thíos.
    // Mar sin ní dhéanaimid ach é a chur i mbosca uair amháin, chun rud pointeoir a fháil.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Ghnóthú an `Box` bunúsacha.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}