# An `rustc-std-workspace-std` crate

Féach cáipéisíocht don `rustc-std-workspace-core` crate.