//! slices teaghrán Unicode.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Tá an cineál `&str` ar cheann den dá phríomhchineál sreinge, agus an ceann eile `String`.
//! Murab ionann agus a mhacasamhail `String`, a bhfuil ann a fuarthas ar iasacht.
//!
//! # Úsáid Bhunúsach
//!
//! Dearbhú bunúsach teaghrán de chineál `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Anseo tá sreangán liteartha dearbhaithe againn, ar a dtugtar slice sreang freisin.
//! Tá saolré statach ag litearthacht teaghrán, rud a chiallaíonn go ráthaítear go mbeidh an tsreang `hello_world` bailí ar feadh ré an chláir iomláin.
//!
//! Is féidir linn saolré `hello_world` a shonrú go sainráite freisin:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Go leor de na usings sa mhodúl seo a úsáid ach amháin sa chumraíocht tástála.
// Tá sé níos glaine an rabhadh neamhúsáidte_imports a mhúchadh ná iad a shocrú.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` i `Concat<str>` Níl brí anseo.
/// Níl an cineál paraiméadar seo den trait ann ach chun impl eile a chumasú.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // Ritheann lúbanna le méideanna crua-chódaithe i bhfad níos gasta speisialtóireacht na cásanna le faid deighilteora bheaga
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // fallback treallach neamh-nialas méid
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Cur i bhfeidhm optamaithe a oibríonn don dá Vec<T>(T: Cóip) agus Teaghrán s vec istigh Faoi láthair ní (2018-05-13) tá bug le thátal cineál agus speisialtóireacht (féach ceist #36262) Ar an gcúis SliceConcat<T>Níl speisialaithe le haghaidh T: Cóipeáil agus SliceConcat<str>Is é an t-aon úsáideoir na feidhme seo.
// Fágtar i bhfeidhm é nuair a shocraítear é sin.
//
// is iad S: Iasacht na teorainneacha do String-join<str>agus le haghaidh Vec-join Borrow <[T]> [T] agus str araon impl AsRef <[T]> do roinnt T
// => s.borrow().as_ref() agus bíonn slisní againn i gcónaí
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // is é an chéad slice an t-aon cheann gan deighilteoir roimhe
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // ríomh fad iomlán cruinn an Vec ceangailte má sháraíonn an ríomh `len`, beidh panic againn a bheadh imithe as cuimhne ar aon nós agus éilíonn an chuid eile den fheidhm go bhfuil an Vec iomlán réamh-leithdháilte ar mhaithe le sábháilteacht
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // maolán neamhbheartaithe a ullmhú
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // a chóipeáil deighilteoir agus slisní níos mó ná gan bounds seiceálacha a ghiniúint lúb le offsets hardcoded do dheighilteoirí beaga feabhsúchán ollmhór féideartha (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Féadfaidh cur chun feidhme aisteach iasachta slisní éagsúla a thabhairt ar ais chun an fad a ríomh agus an chóip iarbhír a fháil.
        //
        // Déan cinnte nach nochtfaimid bearta neamhbheartaithe don té atá ag glaoch.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Modhanna le haghaidh slisní sreinge.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Tiontaíonn sé `Box<str>` ina `Box<[u8]>` gan é a chóipeáil nó a leithdháileadh.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Cuirtear sreangán eile in ionad gach cluiche de phatrún.
    ///
    /// `replace` cruthaíonn sé [`String`] nua, agus cóipeálann sé na sonraí ón sreangán seo isteach ann.
    /// Agus é sin á dhéanamh, déanann sé iarracht cluichí patrún a aimsiú.
    /// Má aimsíonn sé aon cheann, cuireann sé an tslis sreangán ina áit.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Nuair nach ionann an patrún:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Cuirtear sreang eile in ionad na chéad mheaitseálacha N de phatrún.
    ///
    /// `replacen` cruthaíonn sé [`String`] nua, agus cóipeálann sé na sonraí ón sreangán seo isteach ann.
    /// Agus é sin á dhéanamh, déanann sé iarracht cluichí patrún a aimsiú.
    /// Má aimsíonn sé aon cheann, cuireann sé an slice sreangán athsholáthair ina ionad an chuid is mó uaireanta `count`.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Nuair nach ionann an patrún:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Tá súil agam na hamanna ath-leithdháilte a laghdú
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Filleann sé coibhéis an cháis íochtair den tsreangán seo, mar [`String`] nua.
    ///
    /// 'Lowercase' sainmhínítear é de réir théarmaí na Maoine Croí Díorthaithe Unicode `Lowercase`.
    ///
    /// Ós rud é gur féidir roinnt carachtair leathnú isteach carachtair éagsúla nuair a athrú ar an cás, ar ais an fheidhm seo a [`String`] ionad mhodhnú an paraiméadar in-áit.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Sampla fánach, le sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // ach ag an deireadh focail, tá sé ς, ní σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Ní athraítear teangacha gan chás:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ léarscáileanna go σ, ach amháin ag deireadh focal ina ndéanann sé mapáil go ς.
                // Is é seo an t-aon (contextual) coinníollach ach mapáil teanga-neamhspleách i `SpecialCasing.txt`, mar sin déan cód crua air seachas meicníocht chineálach "condition" a bheith agat.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // don sainmhíniú ar `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Filleann sé an choibhéis uachtarach den tsreangán seo, mar [`String`] nua.
    ///
    /// 'Uppercase' Is é an sainmhíniú i gcomhréir leis na téarmaí an Unicode dhíorthaithe Core Maoine `Uppercase`.
    ///
    /// Ós rud é gur féidir roinnt carachtair leathnú isteach carachtair éagsúla nuair a athrú ar an cás, ar ais an fheidhm seo a [`String`] ionad mhodhnú an paraiméadar in-áit.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Ní athraítear scripteanna gan chás:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Is féidir le carachtar amháin a bheith iolrach:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Tiontaíonn sé [`Box<str>`] ina [`String`] gan é a chóipeáil nó a leithdháileadh.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Cruthaítear [`String`] nua trí shreang `n` a athdhéanamh.
    ///
    /// # Panics
    ///
    /// Beidh an fheidhm panic má tá an cumas a bheadh thar maoil.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// A panic ar ró-shreabhadh:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Seoltar cóip den tsreang seo ar ais ina ndéantar gach carachtar a mhapáil dá choibhéis cás uachtair ASCII.
    ///
    ///
    /// Déantar litreacha ASCII 'a' go 'z' a mhapáil go 'A' go 'Z', ach níl aon athrú ar litreacha neamh-ASCII.
    ///
    /// Chun an luach atá i bhfeidhm a shárú, úsáid [`make_ascii_uppercase`].
    ///
    /// Chun carachtair ASCII a sheasamh i dteannta le carachtair nach carachtair ASCII iad, bain úsáid as [`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() caomhnaíonn an UTF-8 invariant.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Seoltar cóip den tsreang seo ar ais i gcás ina ndéantar gach carachtar a mhapáil dá choibhéis cás íochtair ASCII.
    ///
    ///
    /// ASCII litreacha 'A' go 'Z' mapáilte chuig 'a' go 'z', ach tá litreacha nach ASCII gan athrú.
    ///
    /// Chun an luach atá i bhfeidhm a ísliú, úsáid [`make_ascii_lowercase`].
    ///
    /// Chun carachtair ASCII a litreacha beaga i dteannta le carachtair neamh-ASCII, bain úsáid as [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() caomhnaíonn an UTF-8 invariant.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Tiontaíonn sé slice beart de bhoscaí go slice sreangán gan bhosca gan a sheiceáil go bhfuil UTF-8 bailí sa téad.
///
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}