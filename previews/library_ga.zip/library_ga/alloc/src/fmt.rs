//! Fóntais chun `Teaghrán 'a fhormáidiú agus a phriontáil.
//!
//! Cuimsíonn an modúl seo ar an tacaíocht runtime leis an síneadh ar an [`format!`] chomhréir.
//! Cuirtear an macra seo i bhfeidhm sa tiomsaitheoir chun glaonna chuig an modúl seo a astú d`fhonn argóintí a fhormáidiú ag am rith go teaghráin.
//!
//! # Usage
//!
//! Tá sé i gceist ag an macra [`format!`] a cur amach sin a thagann as feidhmeanna `printf`/`fprintf` C nó feidhm `str.format` Python ar.
//!
//! Seo a leanas roinnt samplaí den síneadh [`format!`]:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" le nialais tosaigh
//! ```
//!
//! Díobh seo, is féidir leat a fheiceáil gur sreang formáide an chéad argóint.Ceanglaíonn an tiomsaitheoir air seo a bheith ina shreangán liteartha;ní féidir athróg a rith isteach ann (d`fhonn seiceáil bailíochta a dhéanamh).
//! Ansin déanfaidh an tiomsaitheoir an sreangán formáide a pharsáil agus socróidh sé an bhfuil liosta na n-argóintí a cuireadh ar fáil oiriúnach le cur ar aghaidh chuig an tsreang fhormáid seo.
//!
//! Chun luach amháin a thiontú go sreang, úsáid an modh [`to_string`].Úsáidfidh sé seo formáidiú [`Display`] trait.
//!
//! ## Paraiméadair suímh
//!
//! Ceadaítear do gach argóint formáidithe an argóint luacha a bhfuil sí ag tagairt a shonrú, agus má fhágtar ar lár í glactar leis gur "the next argument" í.
//! Mar shampla, thógfadh an tsreang formáide `{} {} {}` trí pharaiméadar, agus dhéanfaí iad a fhormáidiú san ord céanna agus a thugtar dóibh.
//! Dhéanfadh an sreangán formáide `{2} {1} {0}`, áfach, argóintí a fhormáidiú in ord droim ar ais.
//!
//! Is féidir rudaí a fháil beagán tricky uair a thosóidh tú intermingling an dá chineál sonraitheoirí lena suímh.Is féidir leis an sonraitheoir "next argument" a cumha mar iterator thar an argóint.
//! Gach uair a fheictear sonraitheoir "next argument", déanann an t-atreoraitheoir dul chun cinn.Seo mar thoradh ar iompar mar seo:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Níl an t-atreoraitheoir inmheánach faoin argóint curtha chun cinn faoin am a fheictear an chéad `{}`, mar sin déanann sé an chéad argóint a phriontáil.Ansin nuair a shroich sé an dara `{}`, tá an t-atriallóir tar éis dul ar aghaidh go dtí an dara argóint.
//! Go bunúsach, ní dhéanann paraiméadair a ainmníonn a n-argóint go sainráite difear do pharaiméadair nach n-ainmníonn argóint i dtéarmaí sonraitheoirí suímh.
//!
//! Teastaíonn sreang formáide chun a chuid argóintí go léir a úsáid, ar shlí eile is botún ama tiomsaithe é.Féadfaidh tú tagairt a dhéanamh don argóint chéanna níos mó ná uair amháin sa téad formáide.
//!
//! ## Paraiméadair ainmnithe
//!
//! Níl coibhéis Python cosúil le paraiméadair ainmnithe le feidhm ag Rust féin, ach is síneadh comhréir é an macra [`format!`] a ligeann dó paraiméadair ainmnithe a ghiaráil.
//! Tá paraiméadair ainmnithe liostaithe ag deireadh an liosta argóintí agus tá an chomhréir acu:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Mar shampla, úsáideann na habairtí [`format!`] seo a leanas argóint ainmnithe:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Níl sé bailí paraiméadair suímh (iad siúd gan ainmneacha) a chur i ndiaidh argóintí a bhfuil ainmneacha orthu.Cosúil le paraiméadair positional, nach bhfuil sé bailí le paraiméadair ainmnithe atá gan úsáid ag an teaghrán fhormáid a chur ar fáil.
//!
//! # Paraiméadair Formáidithe
//!
//! Is féidir gach argóint atá á formáidiú a athrú le roinnt paraiméadair formáidithe (a fhreagraíonn do `format_spec` in [the syntax](#syntax)). Bíonn tionchar ag na paraiméadair seo ar léiriú sreang ar a bhfuil á formáidiú.
//!
//! ## Width
//!
//! ```
//! // Priontálann siad seo go léir "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Is paraiméadar é seo don "minimum width" ar cheart don fhormáid a ghlacadh.
//! Mura líonann sreang an luacha an iliomad carachtar seo, úsáidfear an stuáil a shonraíonn fill/alignment chun an spás riachtanach a ghlacadh (féach thíos).
//!
//! Is féidir an luach don leithead a sholáthar freisin mar [`usize`] i liosta na bparaiméadar trí iarmhír `$` a chur leis, rud a léiríonn gur [`usize`] an dara argóint a shonraíonn an leithead.
//!
//! Ní dhéanann tagairt d`argóint le comhréir an dollar difear do chuntar "next argument", mar sin de ghnáth is smaoineamh maith é tagairt d`argóintí de réir seasaimh, nó argóintí ainmnithe a úsáid.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Soláthraítear an carachtar líonta roghnach agus an t-ailíniú de ghnáth i dteannta leis an bparaiméadar [`width`](#width).Ní mór é a shainiú roimh `width`, ar dheis tar éis an `:`.
//! Tugann sé seo le fios má tá an luach atá á fhormáidiú níos lú ná `width` go ndéanfar roinnt carachtair bhreise a phriontáil timpeall air.
//! Tagann na leaganacha seo a leanas le haghaidh ailínithe éagsúla:
//!
//! * `[fill]<` - tá an argóint ailínithe i gcolúin `width`
//! * `[fill]^` - tá an argóint ailínithe i lár na gcolún `width`
//! * `[fill]>` - tá an argóint ailínithe i gceart i gcolúin `width`
//!
//! Is é an [fill/alignment](#fillalignment) réamhshocraithe do neamh-uimhreacha ná spás agus ailínithe ar chlé.Is carachtar spáis an réamhshocrú do fhormáidithe uimhriúla freisin ach le hailíniú ceart.
//! Má shonraítear bratach `0` (féach thíos) maidir le huimhreacha, ansin is é `0` an carachtar líonta intuigthe.
//!
//! Tabhair faoi deara nach bhféadfadh roinnt cineálacha ailíniú a chur i bhfeidhm.Go háirithe, ní chuirtear i bhfeidhm go ginearálta é don `Debug` trait.
//! Bealach maith lena chinntiú go gcuirtear stuáil i bhfeidhm is ea d`ionchur a fhormáidiú, ansin an sreangán seo a chur mar thoradh air chun d`aschur a fháil:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Dia duit Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Is bratacha iad seo go léir a athraíonn iompar an fhormáidithe.
//!
//! * `+` - Tá sé seo beartaithe do chineálacha uimhriúla agus tugann sé le fios gur chóir an comhartha a phriontáil i gcónaí.Ní phriontáiltear comharthaí dearfacha de réir réamhshocraithe riamh, agus ní phriontáiltear an comhartha diúltach ach de réir réamhshocraithe don `Signed` trait.
//! Tugann an bhratach seo le fios gur chóir an comhartha ceart (`+` nó `-`) a phriontáil i gcónaí.
//! * `-` - Ní úsáidtear faoi láthair
//! * `#` - Tugann an bhratach seo le fios gur chóir an fhoirm priontála "alternate" a úsáid.Is iad na foirmeacha malartacha:
//!     * `#?` - an fhormáidiú [`Debug`] a phriontáil go deas
//!     * `#x` - roimh an argóint le `0x`
//!     * `#X` - roimh an argóint le `0x`
//!     * `#b` - roimh an argóint le `0b`
//!     * `#o` - roimh an argóint le `0o`
//! * `0` - Úsáidtear é seo chun a léiriú le haghaidh formáidí slánuimhir gur chóir an stuáil go `width` a dhéanamh le carachtar `0` chomh maith le bheith feasach ar chomharthaí.
//! Thabharfadh formáid mar `{:08}` `00000001` don slánuimhir `1`, agus thabharfadh an fhormáid chéanna `-0000001` don slánuimhir `-1`.
//! Tabhair faoi deara go bhfuil nialas níos lú ná an leagan dearfach sa leagan diúltach.
//!         Tabhair faoi deara go gcuirtear nialais stuála i gcónaí i ndiaidh an chomhartha (más ann dóibh) agus roimh na digití.Nuair a úsáidtear í in éineacht leis an mbratach `#`, tá riail den chineál céanna i bhfeidhm: cuirtear nialais stuála isteach i ndiaidh an réimír ach roimh na digití.
//!         Tá an réimír san áireamh sa leithead iomlán.
//!
//! ## Precision
//!
//! Maidir le cineálacha neamh-uimhriúla, is féidir é seo a mheas mar "maximum width".
//! Má tá an tsreang mar thoradh air níos faide ná an leithead seo, teastaítear í go dtí an iliomad carachtar seo agus astaítear an luach teasctha le `fill`, `alignment` agus `width` ceart má tá na paraiméadair sin socraithe.
//!
//! Déantar neamhaird de seo i gcás cineálacha bunúsacha.
//!
//! Maidir le cineálacha snámhphointe, léiríonn sé seo cé mhéad dhigit tar éis an pointe deachúil ba chóir a phriontáil.
//!
//! Tá trí bhealach féideartha ann chun an `precision` atá ag teastáil a shonrú:
//!
//! 1. Slánuimhir `.N`:
//!
//!    is é an slánuimhir `N` féin an cruinneas.
//!
//! 2. Slánuimhir nó ainm agus comhartha dollar `.N$` ina dhiaidh:
//!
//!    format úsáid *argóint*`N` (nach mór a bheith ina `usize`) a chinnfidh an cruinneas.
//!
//! 3. Réiltín `.*`:
//!
//!    `.*` ciallaíonn sé go bhfuil baint ag an `{...}` seo le hionchuir bhformáid *dhá* seachas ceann amháin: tá cruinneas `usize` ag an gcéad ionchur, agus tá an luach le priontáil ag an dara ceann.
//!    Tabhair faoi deara, sa chás seo, má úsáideann ceann amháin an teaghrán formáide `{<arg>:<spec>.*}`, ansin tagraíonn an chuid `<arg>` don* luach * atá le priontáil, agus caithfidh an `precision` teacht san ionchur roimh `<arg>`.
//!
//! Mar shampla, déanann na glaonna seo a leanas an rud céanna a phriontáil `Hello x is 0.01000`:
//!
//! ```
//! // Is é {arg 1 (0.01) with precision specified inline (5)} Dia duit {arg 0 ("x")}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Is é {arg 2 (0.01) with precision specified in arg 0 (5)} Dia duit {arg 1 ("x")}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Is é {arg 2 (0.01) with precision specified in arg 1 (5)} Dia duit {arg 0 ("x")}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Is é {second of next two args (0.01) with precision specified in first of next two args (5)} Dia duit {next arg ("x")}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Is é {arg 2 (0.01) with precision specified in its predecessor (5)} Dia duit {next arg ("x")}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Is é {arg "number" (0.01) with precision specified in arg "prec" (5)} Dia duit {next arg ("x")}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Cé iad seo:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! phriontáil trí rudaí difríocht shuntasach:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! I roinnt teangacha cláir, braitheann iompar feidhmeanna formáidithe sreinge ar shuíomh locale an chórais oibriúcháin.
//! Níl aon choincheap maidir le locale ag na feidhmeanna formáide a sholáthraíonn leabharlann chaighdeánach Rust agus tabharfaidh siad na torthaí céanna ar gach córas beag beann ar chumraíocht an úsáideora.
//!
//! Mar shampla, beidh an cód seo a leanas a phriontáil i gcónaí `1.5` fiú má úsáideann an logchaighdeán córas deighilteoir deachúil eile seachas ponc.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Féadfar na carachtair liteartha `{` agus `}` a áireamh i sreangán sula dtéann siad leis an gcarachtar céanna.Mar shampla, éalaítear an carachtar `{` le `{{` agus éalaítear an carachtar `}` le `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Mar achoimre, anseo is féidir leat gramadach iomlán teaghráin formáide a fháil.
//! Tarraingítear an chomhréir don teanga formáidithe a úsáidtear ó theangacha eile, mar sin níor cheart go mbeadh sí ró-eachtrannach.Argóintí a formáidithe le Python-mhaith error, rud a chiallaíonn go bhfuil argóintí timpeallaithe ag `{}` ionad an C-mhaith `%`.
//! Is í an ghramadach iarbhír don chomhréir formáidithe:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Sa ghramadach thuas, ní fhéadfaidh aon charachtair `'{'` nó `'}'` a bheith i `text`.
//!
//! # Formáidiú traits
//!
//! Agus tú ag iarraidh go ndéanfaí argóint a fhormáidiú le cineál áirithe, tá tú ag iarraidh i ndáiríre argóint a bhaineann le trait áirithe.
//! Ligeann sé seo ilchineálacha iarbhír a fhormáidiú trí `{:x}` (cosúil le [`i8`] chomh maith le [`isize`]).Is é an mhapáil reatha cineálacha go traits:
//!
//! * *faic* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] le slánuimhreacha heicsidheachúlach cás íochtair
//! * `X?` ⇒ [`Debug`] le slánuimhreacha heicsidheachúlach cás uachtair
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Is é a chiallaíonn sé seo gur féidir aon chineál argóinte a chuireann an [`fmt::Binary`][`Binary`] trait i bhfeidhm a fhormáidiú le `{:b}`.Soláthraíonn an leabharlann chaighdeánach cur chun feidhme do na traits seo do roinnt cineálacha primitive.
//!
//! Mura sonraítear formáid ar bith (mar atá in `{}` nó `{:6}`), ansin is í an fhormáid trait a úsáidtear an [`Display`] trait.
//!
//! Agus formáid trait á chur i bhfeidhm agat do do chineál féin, beidh ort modh an tsínithe a chur i bhfeidhm:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // ár gcineál saincheaptha
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Rithfear do chineál mar fhothoghchán `self`, agus ansin ba cheart don fheidhm aschur a astú isteach sa sruth `f.buf`.Tá sé suas le gach formáid trait a chur i bhfeidhm cloí i gceart leis na paraiméadair formáidithe iarrtha.
//! Liostófar luachanna na bparaiméadar seo i réimsí an struchtúir [`Formatter`].Chun cabhrú leis seo, soláthraíonn an struct [`Formatter`] freisin roinnt modhanna cúntóir.
//!
//! Ina theannta sin, tá an luach ar ais an fheidhm seo [`fmt::Result`] a bhfuil ailias cineál [`Result`]`<(),`[`std: : FMT::Error`] `>`.
//! Ba cheart go gcinnteodh cur chun feidhme formáidithe go n-iomadaíonn siad earráidí ón [`Formatter`] (m.sh., nuair a bhíonn siad ag glaoch ar [`write!`]).
//! Mar sin féin, níor cheart dóibh earráidí a thabhairt ar ais go sporúil.
//! Is é sin, ní foláir agus ní fhéadfaidh cur chun feidhme formáidithe earráid a chur ar ais ach amháin má fhilleann an [`Formatter`] a cuireadh isteach earráid.
//! Tá sé seo toisc, contrártha leis an méid a mholfadh síniú na feidhme, gur oibríocht infallible í formáidiú sreanga.
//! Ní thugann an fheidhm seo toradh ar ais ach toisc go bhféadfadh go dteipfeadh ar scríobh chuig an sruth bunúsach agus caithfidh sí bealach a sholáthar chun iomadú a dhéanamh ar an bhfíric gur tharla earráid mar chúltaca den chruach.
//!
//! Is cosúil gur sampla den fhormáidiú traits a chur i bhfeidhm:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // An `f` uirlisí luach an trait `Write`, a bhfuil cad é an scríobh!tá macra ag súil leis.
//!         // Tabhair faoi deara go ndéanann an fhormáidiú seo neamhaird ar na bratacha éagsúla a chuirtear ar fáil chun teaghráin a fhormáidiú.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Ligeann traits éagsúla cineálacha éagsúla aschuir de chineál.
//! // Is é brí na formáide seo méid vector a phriontáil.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Bíodh meas agat ar na bratacha formáidithe tríd an modh cúntóra `pad_integral` a úsáid ar an réad Formatter.
//!         // Féach cáipéisíocht an mhodha le haghaidh sonraí, agus is féidir an fheidhm `pad` a úsáid chun teaghráin a eochaircheap.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Tá cuspóirí ar leith ag an dá fhormáidiú traits seo:
//!
//! - [`fmt::Display`][`Display`] implementations dhearbhú gur féidir leis an gcineál a léiriú go dílis mar theaghrán UTF-8 i gcónaí.Níltear ag súil ** go gcuirfidh gach cineál an [`Display`] trait i bhfeidhm.
//! - [`fmt::Debug`][`Debug`] ba cheart feidhmiúcháin a chur i bhfeidhm maidir le **gach** cineál poiblí.
//!   De ghnáth, léireoidh aschur an stát inmheánach chomh dílis agus is féidir.
//!   Is é cuspóir an [`Debug`] trait ná cód dífhabhtaithe Rust a éascú.I bhformhór na gcásanna, is leor agus moltar `#[derive(Debug)]` a úsáid.
//!
//! Roinnt samplaí den aschur ón dá traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Macraí gaolmhara
//!
//! Tá roinnt macraí gaolmhara sa teaghlach [`format!`].Is iad na cinn atá i bhfeidhm faoi láthair:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Dhá mhacraí iad seo agus [`writeln!`] a úsáidtear chun an tsreang fhormáid a astú go sruth sonraithe.Úsáidtear é seo chun leithdháiltí idirmheánacha teaghráin formáide a chosc agus ina ionad sin an t-aschur a scríobh go díreach.
//! Faoin gcochall, tá an fheidhm seo i ndáiríre ag agairt na feidhme [`write_fmt`] atá sainithe ar an [`std::io::Write`] trait.
//! Is é an sampla úsáide:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Scaoileann sé seo agus [`println!`] a n-aschur go stdout.Mar an gcéanna leis an macra [`write!`], is é aidhm na macraí seo leithdháiltí idirmheánacha a sheachaint agus aschur á phriontáil.Is úsáid Sampla:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Tá na macraí [`eprint!`] agus [`eprintln!`] comhionann le [`print!`] agus [`println!`], faoi seach, ach amháin go n-astaíonn siad a n-aschur go stderr.
//!
//! ### `format_args!`
//!
//! Is macra aisteach é seo a úsáidtear chun pas a fháil go sábháilte timpeall réad teimhneach ag cur síos ar shreang na formáide.Ní éilíonn an réad seo aon leithdháiltí carn a chruthú, agus ní thagraíonn sé ach faisnéis faoin gcruach.
//! Faoin gcochall, cuirtear na macraí gaolmhara go léir i bhfeidhm ina thaobh seo.
//! Ar an gcéad dul síos, úsáidtear sampla éigin:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Is é toradh na macra [`format_args!`] luach de chineál [`fmt::Arguments`].
//! Is féidir an struchtúr a chur ar aghaidh ansin chuig na feidhmeanna [`write`] agus [`format`] taobh istigh mhodúl seo chun a phróiseáil an teaghrán formáid.
//! Is é aidhm na macra seo leithdháiltí idirmheánacha a chosc a thuilleadh agus iad ag déileáil le teaghráin formáidithe.
//!
//! Mar shampla, d`fhéadfadh leabharlann lománaíochta an chomhréir formáidithe chaighdeánach a úsáid, ach rithfeadh sí timpeall an struchtúir seo go hinmheánach go dtí go gcinnfear cá háit ar cheart aschur a dhéanamh.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Glacann an fheidhm `format` struchtúr [`Arguments`] agus cuireann sé an sreangán formáidithe dá bharr ar ais.
///
///
/// Is féidir an cás [`Arguments`] a chruthú leis an macra [`format_args!`].
///
/// # Examples
///
/// Úsáid bhunúsach:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Tabhair faoi deara le do thoil go mb`fhéidir go mbeadh sé níos fearr [`format!`] a úsáid.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}