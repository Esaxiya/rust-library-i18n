#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Is iad an t-ábhar ar an chuimhne nua uninitialized.
    Uninitialized,
    /// Ráthaítear go mbeidh an chuimhne nua nialasach.
    Zeroed,
}

/// Fóntais ar leibhéal íseal chun maolán cuimhne ar an gcarn a leithdháileadh, a ath-leithdháileadh agus a thuiscint ar bhealach níos eirgeanamaíochta gan a bheith buartha faoi na cásanna cúinne go léir atá i gceist.
///
/// Tá an cineál seo den scoth chun do struchtúir sonraí féin a thógáil mar Vec agus VecDeque.
/// Go háirithe:
///
/// * Táirgeann `Unique::dangling()` ar chineálacha meánmhéide.
/// * Táirgeann `Unique::dangling()` ar leithdháiltí náid-fhad.
/// * Seachnaíonn sé `Unique::dangling()` a shaoradh.
/// * Freastalaíonn sé ar gach ró-shreabhadh i ríomhanna acmhainne (cuireann sé chun cinn iad go "capacity overflow" panics).
/// * Gardaí i gcoinne córais 32-giotán a leithdháileann níos mó ná bearta isize::MAX.
/// * Gardaí i gcoinne cur thar do fhad.
/// * Glaonna `handle_alloc_error` ar leithdháiltí suaite.
/// * Tá `ptr::Unique` ann agus dá bhrí sin tugann sé gach sochar gaolmhar don úsáideoir.
/// * Úsáidtear an barrachas a chuirtear ar ais ón leithdháilteoir chun an acmhainn is mó atá ar fáil a úsáid.
///
/// Ní dhéanann an cineál seo iniúchadh ar aon nós ar an gcuimhne a bhainistíonn sé.Nuair a scaoilfear é * saorfaidh sé a chuimhne, ach ní dhéanfaidh sé iarracht a ábhar a ligean anuas.
/// Is faoin don úsáideoir na `RawVec` chun déileáil leis na rudaí iarbhír *stóráil taobh istigh* de `RawVec`.
///
/// Tabhair faoi deara go bhfuil an bhreis ar chineál náid-iarrachtaí i gcónaí gan teorainn, agus mar sin ar ais `capacity()` gcónaí `usize::MAX`.
/// Ciallaíonn sé seo go gcaithfidh tú a bheith cúramach agus tú ag taisteal thart ar an gcineál seo le `Box<[T]>`, ós rud é nach dtabharfaidh `capacity()` an fad.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Tá sé seo ann toisc nach gá go gcomhlíonfadh `#[unstable]` `const fn` le `min_const_fn` agus mar sin ní féidir iad a ghlaoch i`min_const_fn`s ach an oiread.
    ///
    /// Má athraíonn tú `RawVec<T>::new` nó spleáchas, le do thoil a bheith cúramach chun nach isteach aon rud a bheadh a sháraíonn go fírinneach `min_const_fn`.
    ///
    /// NOTE: D`fhéadfaimis an hack seo a sheachaint agus comhréireacht a sheiceáil le roinnt tréith `#[rustc_force_min_const_fn]` a éilíonn go gcomhlíonfaí `min_const_fn` ach nach gá go gceadaítear é a ghlaoch i `stable(...) const fn`/cód úsáideora gan `foo` a chumasú nuair a bhíonn `#[rustc_const_unstable(feature = "foo", issue = "01234")]` i láthair.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Cruthaíonn sé an `RawVec` is mó is féidir (ar an gcarn córais) gan leithdháileadh.
    /// Má tá méid dearfach ag `T`, ansin déanann sé seo `RawVec` le toilleadh `0`.
    /// Má tá `T` meánmhéide, ansin déanann sé `RawVec` le toilleadh `usize::MAX`.
    /// Úsáideach chun leithdháileadh moillithe a chur i bhfeidhm.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Cruthaíonn `RawVec` (ar an gcarn gcóras) leis go díreach ar riachtanais acmhainne agus ailíniú do `[T; capacity]`.
    /// Is ionann é seo agus `RawVec::new` a ghlaoch nuair atá `capacity` `0` nó `T` de mhéid nialas.
    /// Tabhair faoi deara, má tá `T` de mhéid nialasach, ciallaíonn sé sin nach bhfaighidh tú * `RawVec` leis an gcumas iarrtha.
    ///
    /// # Panics
    ///
    /// Panics má sháraíonn acmhainn iarrtha bytes `isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Aborts ar oom.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Cosúil le `with_capacity`, ach ráthaíonn sé go bhfuil an maolán nialasach.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Athdhéanann sé `RawVec` ó phointeoir agus toilleadh.
    ///
    /// # Safety
    ///
    /// Ní mór don `ptr` a leithdháileadh (ar an gcarn gcóras), agus leis an `capacity` tugtha.
    /// Ní féidir leis an `capacity` dul thar `isize::MAX` do chineálacha meánmhéide.(imní amháin ar chórais 32-giotán).
    /// D`fhéadfadh go mbeadh toilleadh suas le `usize::MAX` ag ZST vectors.
    /// Má thagann an `ptr` agus `capacity` ó `RawVec`, ansin ráthaítear é seo.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Tá Vecs Tiny balbh.Léim go:
    // - 8 más é 1 méid na heiliminte, toisc gur dóigh go ndéanfaidh aon leithdháileoirí carn iarratas níos lú ná 8 mbeart a shlánú go 8 mbeart ar a laghad.
    //
    // - 4 má tá na heilimintí meánmhéide (<=1 KiB).
    // - 1 a mhalairt, chun an iomarca spáis a chur amú do Vecanna an-ghearr.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Cosúil le `new`, ach paraiméadraithe thar rogha an leithdháilteora don `RawVec` a cuireadh ar ais.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` ciallaíonn "unallocated".déantar neamhaird de chineálacha meánmhéide.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Cosúil le `with_capacity`, ach paraiméadraithe thar rogha an leithdháilteora don `RawVec` a cuireadh ar ais.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Cosúil le `with_capacity_zeroed`, ach paraiméadraithe thar rogha an leithdháilteora don `RawVec` a cuireadh ar ais.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Tiontaíonn `Box<[T]>` ina `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Tiontaíonn sé an maolán iomlán go `Box<[MaybeUninit<T>]>` leis an `len` sonraithe.
    ///
    /// Tabhair faoi deara go mbeidh sé seo athbhunú i gceart aon athruithe `cap` fhéadfadh a bhíodh á ndéanamh.(Féach tuairisc ar chineál haghaidh sonraí.)
    ///
    /// # Safety
    ///
    /// * `len` Ní mór a bheith níos mó ná nó cothrom le cumas déanaí a iarrtar, agus
    /// * `len` caithfidh sé a bheith níos lú ná nó cothrom le `self.capacity()`.
    ///
    /// Tabhair faoi deara, go bhféadfadh an acmhainn iarrtha agus `self.capacity()` éagsúil, mar d'fhéadfadh Allocator overallocate agus seol ar ais bloc cuimhne níos mó ná mar a iarrtar.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Seiceáil sláintíochta leath den riachtanas sábháilteachta (ní féidir linn an leath eile a sheiceáil).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Seachnaímid `unwrap_or_else` anseo toisc go sáraíonn sé an méid LLVM IR a ghintear.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Athdhéanann sé `RawVec` ó phointeoir, toilleadh agus leithdháileadh.
    ///
    /// # Safety
    ///
    /// Caithfear an `ptr` a leithdháileadh (tríd an leithdháilteoir `alloc` tugtha), agus leis an `capacity` tugtha.
    /// Ní féidir leis an `capacity` bheith níos mó ná `isize::MAX` do chineálacha meánmhéide.
    /// (imní amháin ar chórais 32-giotán).
    /// D`fhéadfadh go mbeadh toilleadh suas le `usize::MAX` ag ZST vectors.
    /// Má thagann an `ptr` agus `capacity` ó `RawVec` a cruthaíodh trí `alloc`, ansin ráthaítear é seo.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Faigheann pointeoir amh go dtí tús an leithdháilte.
    /// Tabhair faoi deara gurb é seo `Unique::dangling()` má tá `capacity == 0` nó `T` de mhéid nialas.
    /// Sa chéad chás, caithfidh tú a bheith cúramach.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Faigheann sé acmhainn an leithdháilte.
    ///
    /// Beidh sé seo i gcónaí `usize::MAX` má tá `T` meánmhéide.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Seolann tú tagairt roinnte don leithdháilteoir a thacaíonn leis an `RawVec` seo.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Tá smután cuimhne leithdháilte againn, ionas gur féidir linn seiceálacha runtime a sheachbhóthar chun ár leagan amach reatha a fháil.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Cinntíonn sé go bhfuil go leor spáis ar a laghad sa mhaolán chun eilimintí `len + additional` a choinneáil.
    /// Mura bhfuil a dhóthain cumais aige cheana, déanfaidh sé a dhóthain spáis a ath-leithdháileadh chomh maith le spás bog compordach chun iompar amúchta *O*(1) a fháil.
    ///
    /// Cuirfidh sé teorainn leis an iompar seo dá gcuirfeadh sé panic gan ghá.
    ///
    /// Má sháraíonn `len` `self.capacity()`, b`fhéidir go dteipfidh air seo an spás iarrtha a leithdháileadh i ndáiríre.
    /// Níl sé seo neamhshábháilte i ndáiríre, ach d`fhéadfadh an cód neamhshábháilte *a scríobhann tú* a bhraitheann ar iompar na feidhme seo briseadh.
    ///
    /// Tá sé seo oiriúnach chun oibríocht mórchóir-bhrú mar `extend` a chur i bhfeidhm.
    ///
    /// # Panics
    ///
    /// Panics má sháraíonn acmhainn nua bytes `isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Aborts ar oom.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // bheadh an cúlchiste tar éis ginmhilleadh nó scaoll a dhéanamh dá sáródh an len `isize::MAX` agus mar sin tá sé seo sábháilte a dhéanamh gan seiceáil anois.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// mar `reserve` An rud céanna, ach tá torthaí ar earráidí in ionad panicking nó tobscor.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Cinntíonn sé go bhfuil go leor spáis ar a laghad sa mhaolán chun eilimintí `len + additional` a choinneáil.
    /// Más rud é nach ndéanann sé cheana bheidh, ath-leithdháileadh ar an méid is lú is féidir de chuimhne is gá.
    /// Go ginearálta beidh sé seo a bheith go díreach an méid chuimhne is gá, ach i bprionsabal go bhfuil an Tá Allocator saor in aisce a thabhairt ar ais níos mó ná d'iarramar.
    ///
    ///
    /// Má sháraíonn `len` `self.capacity()`, b`fhéidir go dteipfidh air seo an spás iarrtha a leithdháileadh i ndáiríre.
    /// Níl sé seo neamhshábháilte i ndáiríre, ach d`fhéadfadh an cód neamhshábháilte *a scríobhann tú* a bhraitheann ar iompar na feidhme seo briseadh.
    ///
    /// # Panics
    ///
    /// Panics má sháraíonn acmhainn nua bytes `isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Aborts ar oom.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Mar an gcéanna le `reserve_exact`, ach filleann sé ar earráidí in ionad piocadh nó ginmhilleadh.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Laghdaíonn an leithdháileadh síos go dtí an méid sonraithe.
    /// Más é 0 an méid a thugtar, tuigtear go hiomlán é.
    ///
    /// # Panics
    ///
    /// Panics má tá an méid tugtha *níos mó* ná an toilleadh reatha.
    ///
    /// # Aborts
    ///
    /// Aborts ar oom.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Tuairisceáin más gá an maolán ar intinn againn a cumas breise ag teastáil a chomhlíonadh.
    /// Úsáidtear go príomha chun glaonna cúltaca inlíne a dhéanamh indéanta gan `grow` a chur isteach.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Is gnách go gcuirtear an modh seo ar an toirt go minic.Mar sin ba mhaith linn go mbeadh sé chomh beag agus is féidir, chun amanna tiomsúcháin a fheabhsú.
    // Ach teastaíonn uainn freisin go mbeidh an oiread dá ábhar in-ríomhtha go statach agus is féidir, chun go mbeidh an cód ginte ag rith níos gasta.
    // Dá bhrí sin, scríobhtar an modh seo go cúramach ionas go mbeidh an cód go léir atá ag brath ar `T` istigh ann, cé go bhfuil an oiread den chód nach bhfuil ag brath ar `T` agus is féidir i bhfeidhmeanna atá neamhchineálach thar `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Cinntítear é seo leis na comhthéacsanna glaonna.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Ó fhillimid acmhainn `usize::MAX` nuair a bhíonn `elem_size`
            // 0, má shroicheann tú anseo is gá go bhfuil an `RawVec` róshásta.
            return Err(CapacityOverflow);
        }

        // Ní dhéanfaidh aon ní is féidir linn a dhéanamh i ndáiríre faoi na seiceálacha seo, faraor.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Ráthaíonn sé seo fás easpónantúil.
        // Ní féidir leis an dúbailt cur thar maoil toisc gurb é `cap <= isize::MAX` agus an cineál `cap` `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` neamh-chineálach os cionn `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Tá na srianta ar an modh seo mórán mar an gcéanna leis na srianta ar `grow_amortized`, ach is gnách go ndéantar an modh seo a mhoilliú chomh minic agus mar sin níl sé chomh criticiúil.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Ó fhillimid acmhainn `usize::MAX` nuair a bhíonn méid an chineáil ann
            // 0, má shroicheann tú anseo is gá go bhfuil an `RawVec` róshásta.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` neamh-chineálach os cionn `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Is é an fheidhm lasmuigh `RawVec` a íoslaghdú amanna tiomsaithe.Féach ar an trácht thuas `RawVec::grow_amortized` le haghaidh sonraí.
// (Níl an paraiméadar `A` suntasach, toisc go bhfuil líon na cineálacha `A` éagsúla le feiceáil i gcleachtas i bhfad níos lú ná líon na gcineálacha `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Seiceáil an earráid anseo go n-íoslaghdófar an méid de `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Seiceálann an leithdháilteoir ar chomhionannas ailínithe
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Saoirse an chuimhne atá ar úinéireacht ag an `RawVec`*gan* iarracht a dhéanamh a bhfuil ann a ligean anuas.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Feidhm lárnach maidir le láimhseáil earráidí cúltaca.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Caithfimid na rudaí seo a leanas a ráthú:
// * Ní leithdháilimid rudaí de mhéid beart `> isize::MAX` riamh.
// * Ní Déanann muid thar maoil `usize::MAX` agus ar ndóigh, a leithdháileadh ró-beag.
//
// Ar 64-giotán ní gá dúinn ach seiceáil a dhéanamh ar ró-shreabhadh ós rud é go dteipfidh orainn iarracht a dhéanamh bearta `> isize::MAX` a leithdháileadh.
// Ar 32-giotán agus 16-giotán caithfimid garda breise a chur leis seo ar eagla go mbeimis ag rith ar ardán a fhéadfaidh gach 4GB a úsáid i spás úsáideora, m.sh., PAE nó x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Feidhm lárnach amháin atá freagrach as acmhainn tuairiscithe a bheith ag cur thar maoil.
// Cinnteoidh sé seo gur beag an ghiniúint cód a bhaineann leis na panics seo toisc nach bhfuil ann ach suíomh amháin a bhfuil panics ann seachas bunán ar fud an mhodúil.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}