//! An leithdháileadh Prelude
//!
//! Is é aidhm an mhodúil seo allmhairí earraí a úsáidtear go coitianta den `alloc` crate a mhaolú trí allmhairiú glob a chur le barr na modúl:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;