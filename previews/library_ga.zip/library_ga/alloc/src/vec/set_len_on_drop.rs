// Socraigh fad an vec nuair a théann an luach `SetLenOnDrop` as raon feidhme.
//
// Is é an smaoineamh: Is athróg áitiúil é an réimse faid i SetLenOnDrop nach bhfeicfidh an optimizer ailias le siopaí ar bith trí phointeoir sonraí an Vec.
// Is é seo an workaround le haghaidh eisiúint anailíse, tá réimse seo #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}