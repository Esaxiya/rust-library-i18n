use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// Speisialtóireacht eile trait do Vec::from_iter atá riachtanach chun tosaíocht a thabhairt de láimh do speisialtóireachtaí forluiteacha féach [`SpecFromIter`](super::SpecFromIter) le haghaidh sonraí.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Unroll an chéad atriall, mar go bhfuil an vector ag dul a leathnú ar an atriall i ngach cás nuair nach bhfuil an iterable fholmhú, ach nach bhfuil an lúb i extend_desugared() dul chun an vector bheith go hiomlán sa cúpla timthriall lúb ina dhiaidh sin.
        //
        // Mar sin faighimid tuar branch níos fearr.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // caithfidh sé toscaireacht a dhéanamh chuig spec_extend() ós rud é go ndéanann extend() féin toscaireacht chuig spec_from do Vecanna folmha
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // caithfidh sé toscaireacht a dhéanamh chuig spec_extend() ós rud é go ndéanann extend() féin toscaireacht chuig spec_from do Vecanna folmha
        //
        vector.spec_extend(iterator);
        vector
    }
}