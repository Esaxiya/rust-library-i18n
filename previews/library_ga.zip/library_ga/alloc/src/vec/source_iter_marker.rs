use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// marcóir Speisialtóireachta bhailiú píblíne iterator isteach i CGO agus a athúsáid an leithdháileadh foinse, ie
/// an phíblíne a fhorghníomhú i bhfeidhm.
///
/// Tá an tuismitheoir SourceIter trait riachtanach chun go bhféadfaidh an fheidhm speisialtóireachta rochtain a fháil ar an leithdháileadh atá le hathúsáid.
/// Ach ní leor an speisialtóireacht a bheith bailí.
/// Féach bounds breise ar an impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// Ní chuirtear slabhraí Cuibheoir i bhfeidhm ach an std-inmheánach SourceIter/InPlaceIterable traits <Adapter<Adapter<IntoIter>>> (gach ceann faoi úinéireacht core/std).
// Níl teorainneacha breise ar chur chun feidhme an oiriúnaitheora (níos faide ná `impl<I: Trait> Trait for Adapter<I>`) ag brath ach ar traits eile atá marcáilte cheana mar speisialtóireacht traits (Cóip, TrustedRandomAccess, FusedIterator).
//
// I.e. nach bhfuil an marcóir ag brath ar saoil de chineálacha úsáideoirí-sholáthar.Modulo the Copy hole, a bhfuil roinnt speisialtóireachtaí eile ag brath air cheana féin.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Ceanglais bhreise nach féidir a chur in iúl trí trait bounds.Táimid ag brath ar mheasúnú seasta ina ionad:
        // a) aon ZSTs is nach mbeadh aon leithdháileadh a athúsáid agus uimhríocht pointeoir bheadh panic b) mheaitseáil méid mar a éilíonn Alloc Conradh c) ailínithe comhoiriúnach mar a cheanglaítear le conradh Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // cúlghairm ar chur chun feidhme níos cineálacha
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // bain úsáid as try-fold ó shin
        // - veicteoirí sé níos fearr do roinnt oiriúnaitheoirí iteora
        // - murab ionann agus an chuid is mó de mhodhanna atráchta inmheánacha, ní thógann sé ach &mut féin
        // - ligeann sé dúinn an pointeoir scríbhneoireachta a shnáithiú trína innards agus é a fháil ar ais sa deireadh
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // d'éirigh leis an atriall, ná scaoil an ceann
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // seiceáil an seasadh le caveat le conradh SourceIter: mura raibh siad b`fhéidir nach bhféadfaimis é a dhéanamh go dtí an pointe seo
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // seiceáil chonradh InPlaceIterable.Ní féidir é seo a dhéanamh ach má chuir an t-atreoraitheoir an pointeoir foinse chun cinn ar chor ar bith.
        // Má úsáideann sé rochtain neamhsheiceáilte trí TrustedRandomAccess, fanfaidh an pointeoir foinse ina áit tosaigh agus ní féidir linn é a úsáid mar thagairt
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // scaoil aon luachanna atá fágtha ag eireaball na foinse ach cosc a chur ar an leithdháileadh féin a luaithe a théann IntoIter as a raon feidhme má scaoil an titim panics ansin sceitheann muid aon eilimintí a bhailítear isteach i dst_buf freisin
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // Ní féidir an conradh InPlaceIterable a fhíorú go beacht anseo ó tá an tagairt eisiach do na pointeoir foinse try_fold gach is féidir linn a dhéanamh ná a sheiceáil má tá sé fós i raon
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}