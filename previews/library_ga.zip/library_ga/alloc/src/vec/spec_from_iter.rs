use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Speisialtóireacht trait a úsáidtear le haghaidh Vec::from_iter
///
/// ## Graf na toscaireachta:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Is é cás coitianta vector a chur i bhfeidhm a athbhailíonn láithreach i vector.
        // Táimid Is féidir le chuaird gearr seo i gcás inarbh IntoIter nár cinn ar chor ar bith.
        // Nuair a bheidh sé curtha chun cinn Is féidir linn an chuimhne a athúsáid agus na sonraí a bhogadh chun tosaigh.
        // Ach linn a dhéanamh ach sin nuair nach mbeadh an CGO mar thoradh air cumas níos nach bhfuil in úsáid ná a chruthú sé trí chur i bhfeidhm FromIterator cineálach bheadh.
        //
        // Níl an teorannú sin riachtanach go hiomlán toisc go bhfuil iompar leithdháilte Vec neamhshonraithe d`aon ghnó.
        // Ach is rogha coimeádach é.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // caithfidh sé toscaireacht a dhéanamh chuig spec_extend() ós rud é go ndéanann extend() féin toscaireacht chuig spec_from do Vecanna folmha
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Úsáideann sé seo `iterator.as_slice().to_vec()` mar nach mór spec_extend céimeanna níos ghlacadh chun cúis mar gheall ar an fad acmhainn + deiridh agus dá bhrí sin a dhéanamh níos mó oibre.
// `to_vec()` déanann an méid ceart a leithdháileadh go díreach agus é a líonadh go díreach.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): leis cfg(test) an modh `[T]::to_vec` gné dhílis, atá ag teastáil le haghaidh an mhínithe modh nach bhfuil, ar fáil.
    // Ina áit sin bain úsáid as an bhfeidhm `slice::to_vec` nach bhfuil ar fáil ach le cfg(test) NB féach an modúl slice::hack in slice.rs chun tuilleadh faisnéise a fháil
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}