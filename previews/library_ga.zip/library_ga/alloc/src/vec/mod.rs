//! Cineál eagar inathraithe inathraithe le hábhar leithdháilte carn, scríofa `Vec<T>`.
//!
//! Vectors ní mór `O(1)` innéacsú, amúchta `O(1)` bhrú (go dtí deireadh) agus `O(1)` pop (ó dheireadh).
//!
//!
//! Cinntíonn Vectors nach leithdháileann siad riamh níos mó ná bearta `isize::MAX`.
//!
//! # Examples
//!
//! Is féidir leat [`Vec`] a chruthú go sainráite le [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... nó tríd an macra [`vec!`] a úsáid:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // deich nialais
//! ```
//!
//! Is féidir leat [`push`] luachanna ar deireadh ar vector (a fhásfaidh an vector mar is gá):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Oibríonn luachanna popping ar an mbealach céanna i bhfad:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors tacaíocht innéacsú (trí [`Index`] agus [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Cineál eagar inathraithe inathraithe, scríofa mar `Vec<T>` agus fuaimniú 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Cuirtear an macra [`vec!`] ar fáil chun an tionscnamh a dhéanamh níos áisiúla:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Féadann sé gach eilimint de `Vec<T>` a thosú le luach ar leith.
/// D`fhéadfadh sé seo a bheith níos éifeachtaí ná leithdháileadh agus tosaithe a dhéanamh i gcéimeanna ar leithligh, go háirithe agus vector de nialais á dtionscnamh:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Tá an méid seo a leanas coibhéiseach, ach d`fhéadfadh sé a bheith níos moille:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Le haghaidh tuilleadh faisnéise, féach [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Úsáid `Vec<T>` mar chruach éifeachtach:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Priontaí 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Ceadaíonn an cineál `Vec` le luachanna rochtain innéacs, toisc go gcuireann sé ar an trait [`Index`].Beidh sampla bheith níos soiléire:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // taispeánfaidh sé '2'
/// ```
///
/// Bí cúramach, áfach: má dhéanann tú iarracht teacht ar innéacs nach bhfuil sa `Vec`, déanfaidh do bhogearraí panic!Ní féidir leat é seo:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Úsáid [`get`] agus [`get_mut`] más mian leat a sheiceáil an bhfuil an t-innéacs sa `Vec`.
///
/// # Slicing
///
/// Is féidir `Vec` a athrú.Ar an láimh eile, is rudaí inléite amháin iad slisní.
/// Chun [slice][prim@slice] a fháil, úsáid [`&`].Sampla:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... agus sin uile!
/// // is féidir leat é a dhéanamh mar seo freisin:
/// let u: &[usize] = &v;
/// // nó mar seo:
/// let u: &[_] = &v;
/// ```
///
/// I Rust, tá sé níos coitianta slisní a rith mar argóintí seachas vectors nuair nach dteastaíonn uait ach rochtain inléite a sholáthar.An rud céanna téann [`String`] agus [`&str`].
///
/// # Cumas agus ath-leithdháileadh
///
/// Is é toilleadh vector an méid spáis a leithdháiltear ar aon eilimintí future a chuirfear ar an vector.Ní gá é seo a mheascadh le *fad* vector, a shonraíonn líon na n-eilimintí iarbhír laistigh den vector.
/// Má sháraíonn fad vector a chumas, méadófar a chumas go huathoibríoch, ach caithfear a eilimintí a ath-leithdháileadh.
///
/// Mar shampla, bheadh vector le toilleadh 10 agus fad 0 ina vector folamh le spás do 10 n-eilimint eile.Ní dhéanfaidh athrú 10 n-eilimint nó níos lú ar an vector athrú ar a chumas ná ní chuirfear ath-leithdháileadh air.
/// Mar sin féin, má tá fad an vector Tháinig méadú go dtí 11, beidh sé a ath-leithdháileadh ar, is féidir a bheith mall.Ar an gcúis seo, moltar [`Vec::with_capacity`] a úsáid nuair is féidir chun a shonrú cé chomh mór agus a mheastar a gheobhaidh an vector.
///
/// # Guarantees
///
/// Mar gheall ar a nádúr dochreidte bunúsach, déanann `Vec` go leor ráthaíochtaí maidir lena dhearadh.Cinntíonn sé seo go bhfuil sé chomh híseal agus is féidir sa chás ginearálta, agus gur féidir é a ionramháil i gceart ar bhealaí primitive trí chód neamhshábháilte.Tabhair faoi deara go dtagraíonn na ráthaíochtaí seo do `Vec<T>` neamhcháilithe.
/// Má chuirtear paraiméadair de chineál breise leis (m.sh., chun tacú le leithdháilteoirí saincheaptha), féadfaidh sárú a gcuid mainneachtainí an t-iompar a athrú.
///
/// Go bunúsach, is triplet (pointeoir, toilleadh, fad) é `Vec` agus beidh sé i gcónaí.Níl níos mó, ní lú.Is é an t-ordú de na réimsí go hiomlán neamhshonraithe, agus ba chóir duit a úsáid na modhanna iomchuí a mhodhnú seo.
/// Ní bheidh an pointeoir ar neamhní riamh, mar sin tá an cineál seo optamaithe le pointeoir null.
///
/// Mar sin féin, b`fhéidir nach ndíríonn an pointeoir ar chuimhne leithdháilte i ndáiríre.
/// Go háirithe, má tá tú a thógáil `Vec` le cumas 0 via [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], nó trí ghlaoch [`shrink_to_fit`] ar CGO folamh, ní bheidh sé cuimhne a dháileadh.Mar an gcéanna, má tá tú a stóráil cineálacha náid-iarrachtaí taobh istigh de `Vec`, ní bheidh sé a leithdháileadh spás dóibh.
/// *Tabhair faoi deara sa chás seo ní fhéadfaidh an `Vec` [`capacity`] de 0* a thuairisciú.
/// `Vec` leithdháilfidh sé más rud é agus mura ndéanfaidh [`mem: : size_of::agus sin amháin<T>`]`() * capacity()> 0`.
/// Go ginearálta, tá sonraí leithdháilte `Vec` an-caol-má tá sé ar intinn agat cuimhne a leithdháileadh ag úsáid `Vec` agus é a úsáid le haghaidh rud éigin eile (bíodh sé le pas a fháil chuig cód neamhshábháilte, nó chun do bhailiúchán féin le tacaíocht cuimhne a thógáil), bí cinnte chun an chuimhne seo a thuiscint trí `from_raw_parts` a úsáid chun an `Vec` a aisghabháil agus ansin é a ligean ar lár.
///
/// Má tá *cuimhne leithdháilte ag `Vec`*, ansin tá an chuimhne a ndéanann sé tagairt dó ar an gcarn (mar atá sainmhínithe ag an leithdháilteoir Rust cumraithe le húsáid de réir réamhshocraithe), agus díríonn a phointe pointeoir ar eilimintí tadhlacha tosaigh [`len`] in ord (an rud a dhéanfá fheiceáil má brú tú é a slice), agus ina dhiaidh [`capacity`]`,`[`len`] loighciúil uninitialized, eilimintí tadhlach.
///
///
/// Is féidir vector ina bhfuil na heilimintí `'a'` agus `'b'` le toilleadh 4 a fheiceáil mar atá thíos.Tá an chuid is fearr an struct `Vec`, tá sé ina pointeoir chuig ceann an leithdháilte i gcarn, fad agus cumas.
/// Is é an chuid bun an leithdháileadh ar an gcarn, bloc cuimhne tadhlach.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - Léiríonn **uninit** cuimhne nach bhfuil tosaithe, féach [`MaybeUninit`].
/// - Note: níl an ABI seasmhach agus ní thugann `Vec` aon ráthaíochtaí maidir lena leagan amach cuimhne (lena n-áirítear ord na réimsí).
///
/// `Vec` ní dhéanfaidh "small optimization" riamh nuair a stóráiltear eilimintí ar an gcruach ar dhá chúis:
///
/// * Dhéanfadh sé níos deacra do chód neamhshábháilte `Vec` a ionramháil i gceart.Ní bheadh seoladh seasmhach in ábhar `Vec` mura mbogfaí é ach, agus bheadh sé níos deacra a chinneadh an raibh cuimhne leithdháilte ag `Vec` i ndáiríre.
///
/// * Bheadh sé pionós a ghearradh ar an cás ginearálta, a thabhú an branch sa bhreis ar gach rochtain.
///
/// `Vec` ní dhéanfaidh sé é féin a chrapadh go huathoibríoch, fiú má bhíonn sé folamh go hiomlán.Cinntíonn sé seo mbíonn aon leithroinnt nó deallocations gan ghá.Fholmhú a `Vec` agus ansin a líonadh sé ar ais suas go dtí an [`len`] céanna, ba chóir thabhú aon glaonna ar an Allocator.Más mian leat a shaoradh cuimhne nach bhfuil in úsáid, a úsáid [`shrink_to_fit`] nó [`shrink_to`].
///
/// [`push`] agus ní bheidh [`insert`] (ath) leithdháileadh má tá an cumas tuairiscithe leordhóthanach.[`push`] agus [`insert`] Beidh * *(ath) a leithdháileadh más rud é [`len`]`==`[`capacity`].Is é sin, is é an cumas a tuairiscíodh go hiomlán cruinn, agus gur féidir brath orthu.Is féidir é a úsáid fiú saor in aisce ar láimh an chuimhne leithdháilte ag `Vec` más inmhianaithe.
/// Modhanna a chur isteach Bulc *Féadfaidh* a athleithroinnt, fiú amháin nuair nach bhfuil gá.
///
/// `Vec` ní ráthaíonn sé aon straitéis fáis ar leith nuair a dhéantar í a ath-leithdháileadh nuair atá sí lán, ná nuair a ghlaoitear [`reserve`].Tá an straitéis reatha bunúsach agus b`fhéidir go mbeadh sé inmhianaithe fachtóir fáis neamhsheasmhach a úsáid.Ráthaíonn cibé straitéis a úsáidtear, ar ndóigh,*O*(1) amúchta [`push`].
///
/// `vec![x; n]`, Déanfaidh `vec![a, b, c, d]`, agus [`Vec::with_capacity(n)`][`Vec::with_capacity`], `Vec` go léir a tháirgeadh leis an gcumas iarrtha go díreach.
/// Más rud é [`len`]`==`[`acmhainn`], (mar is amhlaidh i gcás na macra [`vec!`]), ansin is féidir `Vec<T>` a thiontú go [`Box<[T]>`][owned slice] agus uaidh gan na heilimintí a ath-leithdháileadh nó a bhogadh.
///
/// `Vec` ní dhéanfaidh sé aon sonraí a bhaintear astu a fhorscríobh go sonrach, ach ní chaomhnóidh siad go sonrach iad freisin.Is é an chuimhne neamhbheartaithe atá aige ná spás scríobtha a fhéadfaidh sé a úsáid, áfach.De ghnáth ní dhéanfaidh sé ach cibé rud is éifeachtaí nó is furasta a chur i bhfeidhm ar bhealach eile.Ná bí ag brath ar shonraí bhaint a scriosadh chun críocha slándála.
/// Fiú má scaoilfidh tú `Vec`, féadfar a mhaolán a athúsáid le `Vec` eile.
/// Fiú má náid tú `Cuimhne Vec` chéad, ní fhéadfadh go dtarlódh i ndáiríre toisc nach bhfuil an optimizer mheas an taobh-éifeacht nach mór a chaomhnú.
/// Tá cás amháin nach mbeidh muid ag briseadh, áfach: ag baint úsáide as `unsafe` cód le scríobh ar an cumas breise, agus ansin méadú ar fad a mheaitseáil go bhfuil, i gcónaí bailí.
///
/// Faoi láthair, ní ráthaíonn `Vec` an t-ord ina dtittear eilimintí.
/// Tá an t-ordú athraithe san am atá thart agus d`fhéadfadh sé athrú arís.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Modhanna dúchasacha
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Tógann `Vec<T>` folamh nua.
    ///
    /// Ní leithdháilfidh an vector go dtí go ndéanfar eilimintí a bhrú air.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Tógann `Vec<T>` folamh nua leis an gcumas sonraithe.
    ///
    /// Beidh an vector in ann eilimintí `capacity` a shealbhú go díreach gan ath-leithdháileadh.
    /// Más 000 `capacity`, ní leithdháilfidh an vector.
    ///
    /// Tá sé tábhachtach a thabhairt faoi deara, cé go bhfuil an *acmhainn* sonraithe ag an vector a cuireadh ar ais, beidh fad nialas * ag an vector.
    ///
    /// Le míniú a fháil ar an difríocht idir fad agus toilleadh, féach *[Cumas agus ath-leithdháileadh]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // Tá vector Níl aon rud, cé go bhfuil sé cumas níos
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Déantar iad seo go léir gan ath-leithdháileadh ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ach d`fhéadfadh sé seo an vector a ath-leithdháileadh
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Cruthaíonn sé `Vec<T>` go díreach ó chomhpháirteanna amha vector eile.
    ///
    /// # Safety
    ///
    /// Tá sé seo an-neamhshábháilte, mar gheall ar líon na n-ionróirí nach ndéantar a sheiceáil:
    ///
    /// * `ptr` is gá gur leithdháileadh roimhe seo é trí [`Teaghrán`]/`Vec<T>`(ar a laghad, is beag seans go mbeidh sé mícheart mura raibh).
    /// * `T` ní mór go mbeadh an méid agus an t-ailíniú céanna leis an méid a leithdháileadh `ptr` air.
    ///   (Ní leor `T` a bhfuil ailíniú chomh dian aige, is gá go mbeadh an t-ailíniú comhionann chun an riachtanas [`dealloc`] a shásamh go gcaithfear cuimhne a leithdháileadh agus a thuiscint leis an leagan amach céanna.)
    ///
    /// * `length` ní mór go mbeadh `capacity` níos lú ná nó cothrom leis.
    /// * `capacity` ní foláir gurb é an acmhainn a leithdháileadh an pointeoir air.
    ///
    /// D`fhéadfadh fadhbanna a bheith mar shárú ar struchtúir sonraí inmheánacha an leithdháilteora má dhéantar iad seo a shárú.Mar shampla níl sé **sábháilte**`Vec<u8>` a thógáil ó phointeoir go sraith C `char` le fad `size_t`.
    /// Níl sé sábháilte freisin ceann a thógáil ó `Vec<u16>` agus a fhad, toisc go bhfuil cúram ar an leithdháilteoir faoin ailíniú, agus tá ailínithe difriúla ag an dá chineál seo.
    /// Leithdháileadh an maolán le ailíniú 2 (do `u16`), ach tar éis casadh sé isteach ar `Vec<u8>` beidh sé a bheith deallocated le ailíniú 1.
    ///
    /// Aistrítear úinéireacht `ptr` go héifeachtach chuig an `Vec<T>` a fhéadfaidh ansin ábhar na cuimhne a dtugann an pointeoir toil dó a lua, a ath-leithdháileadh nó a athrú.
    /// Déan cinnte nach n-úsáideann aon rud eile an pointeoir tar éis an fheidhm seo a ghlaoch.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Nuashonrú seo nuair atá vec_into_raw_parts chobhsaithe.
    ///     // Cosc a chur ar an scriosóir `v` a reáchtáil ionas go mbeidh smacht iomlán againn ar an leithdháileadh.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Tarraing amach na píosaí tábhachtacha éagsúla faisnéise faoi `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Cuimhne a fhorscríobh le 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Cuir gach rud ar ais le chéile i Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Tógann `Vec<T, A>` folamh nua.
    ///
    /// Ní leithdháilfidh an vector go dtí go ndéanfar eilimintí a bhrú air.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Tógann `Vec<T, A>` folamh nua leis an gcumas sonraithe leis an leithdháilteoir a sholáthraítear.
    ///
    /// Beidh an vector in ann eilimintí `capacity` a shealbhú go díreach gan ath-leithdháileadh.
    /// Más 000 `capacity`, ní leithdháilfidh an vector.
    ///
    /// Tá sé tábhachtach a thabhairt faoi deara, cé go bhfuil an *acmhainn* sonraithe ag an vector a cuireadh ar ais, beidh fad nialas * ag an vector.
    ///
    /// Le míniú a fháil ar an difríocht idir fad agus toilleadh, féach *[Cumas agus ath-leithdháileadh]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // Tá vector Níl aon rud, cé go bhfuil sé cumas níos
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Déantar iad seo go léir gan ath-leithdháileadh ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ach d`fhéadfadh sé seo an vector a ath-leithdháileadh
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Cruthaíonn sé `Vec<T, A>` go díreach ó chomhpháirteanna amha vector eile.
    ///
    /// # Safety
    ///
    /// Tá sé seo an-neamhshábháilte, mar gheall ar líon na n-ionróirí nach ndéantar a sheiceáil:
    ///
    /// * `ptr` is gá gur leithdháileadh roimhe seo é trí [`Teaghrán`]/`Vec<T>`(ar a laghad, is beag seans go mbeidh sé mícheart mura raibh).
    /// * `T` ní mór go mbeadh an méid agus an t-ailíniú céanna leis an méid a leithdháileadh `ptr` air.
    ///   (Ní leor `T` a bhfuil ailíniú chomh dian aige, is gá go mbeadh an t-ailíniú comhionann chun an riachtanas [`dealloc`] a shásamh go gcaithfear cuimhne a leithdháileadh agus a thuiscint leis an leagan amach céanna.)
    ///
    /// * `length` ní mór go mbeadh `capacity` níos lú ná nó cothrom leis.
    /// * `capacity` ní foláir gurb é an acmhainn a leithdháileadh an pointeoir air.
    ///
    /// D`fhéadfadh fadhbanna a bheith mar shárú ar struchtúir sonraí inmheánacha an leithdháilteora má dhéantar iad seo a shárú.Mar shampla níl sé **sábháilte**`Vec<u8>` a thógáil ó phointeoir go sraith C `char` le fad `size_t`.
    /// Níl sé sábháilte freisin ceann a thógáil ó `Vec<u16>` agus a fhad, toisc go bhfuil cúram ar an leithdháilteoir faoin ailíniú, agus tá ailínithe difriúla ag an dá chineál seo.
    /// Leithdháileadh an maolán le ailíniú 2 (do `u16`), ach tar éis casadh sé isteach ar `Vec<u8>` beidh sé a bheith deallocated le ailíniú 1.
    ///
    /// Aistrítear úinéireacht `ptr` go héifeachtach chuig an `Vec<T>` a fhéadfaidh ansin ábhar na cuimhne a dtugann an pointeoir toil dó a lua, a ath-leithdháileadh nó a athrú.
    /// Déan cinnte nach n-úsáideann aon rud eile an pointeoir tar éis an fheidhm seo a ghlaoch.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Nuashonrú seo nuair atá vec_into_raw_parts chobhsaithe.
    ///     // Cosc a chur ar an scriosóir `v` a reáchtáil ionas go mbeidh smacht iomlán againn ar an leithdháileadh.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Tarraing amach na píosaí tábhachtacha éagsúla faisnéise faoi `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Cuimhne a fhorscríobh le 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Cuir gach rud ar ais le chéile i Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Dianscaoileann a `Vec<T>` isteach a chomhpháirteanna amh.
    ///
    /// Filleann an pointeoir amh ar na sonraí bunúsacha, fad an vector (in eilimintí), agus acmhainn leithdháilte na sonraí (in eilimintí).
    /// Seo iad na hargóintí céanna san ord céanna leis na hargóintí le [`from_raw_parts`].
    ///
    /// Tar éis glaoch fheidhm seo, is é an t-té atá ag glaoch freagrach as an chuimhne mbainistiú roimhe seo ag an `Vec`.
    /// Is é an t-aon bhealach chun é seo a dhéanamh an pointeoir amh, an fad agus an toilleadh a thiontú ar ais ina `Vec` leis an bhfeidhm [`from_raw_parts`], rud a ligeann don scriosóir an glanta a dhéanamh.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Is féidir linn athruithe a dhéanamh anois ar na comhpháirteanna, mar shampla an pointeoir amh a aistriú go cineál comhoiriúnach.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Dianscaoileann a `Vec<T>` isteach a chomhpháirteanna amh.
    ///
    /// Filleann an pointeoir amh ar na sonraí bunúsacha, fad an vector (in eilimintí), acmhainn leithdháilte na sonraí (in eilimintí), agus an leithdháilteoir.
    /// Is iad seo na hargóintí céanna san ord céanna leis na hargóintí a [`from_raw_parts_in`].
    ///
    /// Tar éis glaoch fheidhm seo, is é an t-té atá ag glaoch freagrach as an chuimhne mbainistiú roimhe seo ag an `Vec`.
    /// Is é an t-aon bhealach chun é seo a thiontú ar an pointeoir amh, fad, agus cumas ar ais isteach i `Vec` leis an bhfeidhm [`from_raw_parts_in`], ag ceadú an destructor a dhéanamh an glanta.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Is féidir linn athruithe a dhéanamh anois ar na comhpháirteanna, mar shampla an pointeoir amh a aistriú go cineál comhoiriúnach.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Filleann sé líon na n-eilimintí is féidir leis an vector a shealbhú gan ath-leithdháileadh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Cúlchistí an acmhainn chun `additional` ar a laghad níos mó eilimintí a chur isteach sa `Vec<T>` a thugtar.
    /// Féadfaidh an bailiúchán níos mó spáis a chur in áirithe chun ath-leithdháileadh minic a sheachaint.
    /// Tar éis `reserve` a ghlaoch, beidh an toilleadh níos mó ná nó cothrom le `self.len() + additional`.
    /// Ní dhéanann sé aon rud más leor an acmhainn cheana féin.
    ///
    /// # Panics
    ///
    /// Panics má sháraíonn acmhainn nua bytes `isize::MAX`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Cúlchistí an cumas íosta maidir le heilimintí go díreach `additional` mó le cur isteach sa `Vec<T>` ar leith.
    ///
    /// Tar éis `reserve_exact` a ghlaoch, beidh an toilleadh níos mó ná nó cothrom le `self.len() + additional`.
    /// Ní dhéanann sé aon rud más leor an acmhainn cheana féin.
    ///
    /// Tabhair faoi deara go bhféadfaidh an leithdháilteoir níos mó spáis a thabhairt don bhailiúchán ná mar a iarrann sé.
    /// Dá bhrí sin, ní féidir a bheith ag brath ar acmhainn a bheith an-bheag agus is féidir.
    /// Is fearr `reserve` má tá súil le cuir isteach future.
    ///
    /// # Panics
    ///
    /// Panics má sháraíonn an acmhainn nua `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Déanann sé iarracht acmhainn a chur in áirithe go gcuirfear `additional` ar a laghad níos mó eilimintí isteach sa `Vec<T>` a thugtar.
    /// Féadfaidh an bailiúchán níos mó spáis a chur in áirithe chun ath-leithdháileadh minic a sheachaint.
    /// Tar éis `try_reserve` a ghlaoch, beidh an toilleadh níos mó ná nó cothrom le `self.len() + additional`.
    /// Ní dhéanann sé aon rud más leor an acmhainn cheana féin.
    ///
    /// # Errors
    ///
    /// Má sháraíonn an toilleadh, nó má thuairiscíonn an leithdháilteoir cliseadh, tugtar earráid ar ais.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Déan an chuimhne a chur in áirithe roimh ré, mura féidir linn
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Anois tá a fhios againn nach féidir seo a dhéanamh OOM i lár ár gcuid oibre casta
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // an-chasta
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Déanann sé iarracht an acmhainn íosta a chur in áirithe chun eilimintí `additional` go díreach a chur isteach sa `Vec<T>` a thugtar.
    /// Tar éis glaoch `try_reserve_exact`, beidh toilleadh bheith níos mó ná nó cothrom le `self.len() + additional` má fhilleann sí `Ok(())`.
    ///
    /// Ní dhéanann sé aon rud más leor an acmhainn cheana féin.
    ///
    /// Tabhair faoi deara go bhféadfaidh an leithdháilteoir níos mó spáis a thabhairt don bhailiúchán ná mar a iarrann sé.
    /// Dá bhrí sin, ní féidir a bheith ag brath ar acmhainn a bheith an-bheag agus is féidir.
    /// Is fearr `reserve` má tá súil le cuir isteach future.
    ///
    /// # Errors
    ///
    /// Má sháraíonn an toilleadh, nó má thuairiscíonn an leithdháilteoir cliseadh, tugtar earráid ar ais.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Déan an chuimhne a chur in áirithe roimh ré, mura féidir linn
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Anois tá a fhios againn nach féidir seo a dhéanamh OOM i lár ár gcuid oibre casta
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // an-chasta
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Laghdaíonn sé acmhainn an vector a oiread agus is féidir.
    ///
    /// Beidh sé ag titim chomh gar agus is féidir don fhad ach féadfaidh an leithdháileadh a chur in iúl don vector fós go bhfuil spás ann do chúpla eilimint eile.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Ní bhíonn an acmhainn riamh níos lú ná an fad, agus níl aon rud le déanamh nuair a bhíonn siad comhionann, ionas gur féidir linn cás panic i `RawVec::shrink_to_fit` a sheachaint ach é a ghlaoch le cumas níos mó.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Laghdaíonn sé toilleadh an vector le teorainn níos ísle.
    ///
    /// Fanfaidh an toilleadh ar a laghad chomh mór leis an fad agus an luach a sholáthraítear.
    ///
    ///
    /// Má tá an toilleadh reatha níos lú ná an teorainn is ísle, is rogha eile é seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Tiontaíonn sé an vector go [`Box<[T]>`][owned slice].
    ///
    /// Tabhair faoi deara go scaoilfidh sé seo aon acmhainn iomarcach.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Baintear aon acmhainn iomarcach:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Giorraíonn sé an vector, ag coinneáil na chéad eilimintí `len` agus ag titim an chuid eile.
    ///
    /// Má tá `len` níos mó ná fad atá ann faoi láthair an vector ar, tá sé seo aon éifeacht.
    ///
    /// Is féidir leis an modh [`drain`] aithris a dhéanamh ar `truncate`, ach is cúis leis na heilimintí iomarcacha a thabhairt ar ais in ionad iad a thit.
    ///
    ///
    /// Tabhair faoi deara go bhfuil an modh seo nach bhfuil aon éifeacht ar an acmhainn a leithdháileadh ar an vector.
    ///
    /// # Examples
    ///
    /// Truncáil cúig ghné vector go dhá ghné:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Tarlaíonn aon teascadh nuair a bhíonn `len` níos mó ná fad atá ann faoi láthair an vector ar:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Truncating nuair a bhíonn `len == 0` comhionann le modh [`clear`] a ghlaoch.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Tá sé seo sábháilte mar gheall ar:
        //
        // * Is é an slice ar aghaidh chuig `drop_in_place` bailí;seachnaíonn cás `len > self.len` slice neamhbhailí a chruthú, agus
        // * an `len` an vector atá shrunk sula ag glaoch `drop_in_place`, sa chaoi go mbeidh aon luach a thit faoi dhó i gcás `drop_in_place` bhí go panic uair amháin (má tá sé panics faoi dhó, an aborts an chláir).
        //
        //
        //
        unsafe {
            // Note: Tá sé ar intinn gurb é seo `>` agus ní `>=`.
            //       Tá impleachtaí feidhmíochta diúltacha ag athrú go `>=` i roinnt cásanna.
            //       Féach #78884 le haghaidh tuilleadh.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Sleachta slisne ina bhfuil an vector ar fad.
    ///
    /// Coibhéiseach le `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Sleachta slisne inathraithe den vector ar fad.
    ///
    /// Coibhéiseach le `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Tugann pointeoir amh ar ais do mhaolán vector.
    ///
    /// Ní mór don té atá ag glaoch a chinntiú go sáraíonn an vector an pointeoir a fhilleann an fheidhm seo, nó go ndíreoidh sé ar truflais sa deireadh.
    /// Má dhéantar an vector a mhodhnú, féadfar a mhaolán a ath-leithdháileadh, rud a d`fhágfadh go mbeadh aon leideanna dó neamhbhailí.
    ///
    /// Ní mór don té atá ag glaoch a chinntiú freisin go bhfuil an chuimhne na pointí (non-transitively) pointeoir riamh scríofa go (ach amháin taobh istigh `UnsafeCell`) ag baint úsáide as an pointeoir nó aon pointeoir a dhíorthaítear ó sé.
    /// Más gá duit a mutate an ábhar ar an slice, bain úsáid as [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Táimid ag scáth an modh slice an t-ainm céanna a sheachaint ag dul trí `deref`, a chruthaíonn tagairt idirmheánach.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Tuairisceáin an pointeoir mutable neamhshábháilte chun maolán an vector ar.
    ///
    /// Ní mór don té atá ag glaoch a chinntiú go sáraíonn an vector an pointeoir a fhilleann an fheidhm seo, nó go ndíreoidh sé ar truflais sa deireadh.
    ///
    /// Má dhéantar an vector a mhodhnú, féadfar a mhaolán a ath-leithdháileadh, rud a d`fhágfadh go mbeadh aon leideanna dó neamhbhailí.
    ///
    /// # Examples
    ///
    /// ```
    /// // Leithdháileadh vector mór go leor le haghaidh 4 eilimint.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Cuir tús le heilimintí trí scríbhinní pointeora amh, ansin fad socraithe.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Scáthaímid an modh slice den ainm céanna chun dul trí `deref_mut` a sheachaint, rud a chruthaíonn tagairt idirmheánach.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Filleann tagairt don leithdháilteoir bunúsach.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Fórsaí an fad an vector go `new_len`.
    ///
    /// Is oibríocht ísealleibhéil í seo nach gcoinníonn aon cheann de ghnáth-ionróirí an chineáil.
    /// De ghnáth déantar fad vector a athrú trí cheann de na hoibríochtaí sábháilte a úsáid ina ionad, mar shampla [`truncate`], [`resize`], [`extend`], nó [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` caithfidh sé a bheith níos lú ná nó cothrom le [`capacity()`].
    /// - Caithfear na heilimintí ag `old_len..new_len` a thosú.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Is féidir leis an modh seo a bheith úsáideach i gcásanna ina bhfuil an vector ag feidhmiú mar mhaolán do chód eile, go háirithe thar FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Níl anseo ach creatlach íosta don sampla doc;
    /// # // ná bain úsáid as seo mar phointe tosaigh do leabharlann cheart.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Per an modh FFI ar docs, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // SÁBHÁILTEACHT: Nuair a fhilleann `deflateGetDictionary` `Z_OK`, maíonn sé:
    ///     // 1. `dict_length` tosaíodh eilimintí.
    ///     // 2.
    ///     // `dict_length` <=Cumas (32_768) a dhéanann `set_len` sábháilte glaoch.
    ///     unsafe {
    ///         // Déan glao FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... agus an fad a nuashonrú go dtí an méid a tionscnaíodh i dtosach.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Cé go bhfuil an sampla seo a leanas fónta, tá sceitheadh cuimhne ann ó níor saoradh na vectors istigh roimh an nglao `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` folamh mar sin ní gá eilimintí ar bith a thionscnamh.
    /// // 2. `0 <= capacity` bíonn cibé `capacity` i gcónaí.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// De ghnáth, anseo, d`úsáidfeadh duine [`clear`] ina ionad chun an t-ábhar a ligean i gceart agus dá bhrí sin gan cuimhne a sceitheadh.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Bain eilimint ón vector agus seol ar ais í.
    ///
    /// Cuirtear an eilimint dheireanach den vector in ionad na heiliminte bainte.
    ///
    /// Ní chaomhnaíonn sé seo ordú, ach is é O(1) é.
    ///
    /// # Panics
    ///
    /// Panics má tá `index` as teorainneacha.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Cuirimid an eilimint dheireanach in ionad féin [innéacs].
            // Tabhair faoi deara má éiríonn leis an seiceáil teorainneacha thuas ní mór go mbeadh eilimint dheiridh ann (ar féidir léi a bheith féin [innéacs] féin).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Cuireann gné ag seasamh `index` laistigh den vector, aistriú gach gné tar éis é a cheart.
    ///
    ///
    /// # Panics
    ///
    /// Panics más `index > len` é.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // spás don eilimint nua
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // infallible An láthair chun an luach nua a chur
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Aistrigh gach rud chun spás a dhéanamh.
                // (An eilimint `innéacs` a dhúbailt ina dhá áit as a chéile.)
                ptr::copy(p, p.offset(1), len - index);
                // Scríobh isteach é, ag scríobh an chéad chóip den eilimint `innéacs '.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Bain agus tuairisceáin an eilimint ag seasamh `index` laistigh den vector, aistriú gach gné tar éis é a ar an taobh clé.
    ///
    ///
    /// # Panics
    ///
    /// Panics má tá `index` as teorainneacha.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // an áit a bhfuilimid ag glacadh as.
                let ptr = self.as_mut_ptr().add(index);
                // déan é a chóipeáil, gan cóip den luach ar an gcruach agus sa vector ag an am céanna.
                //
                ret = ptr::read(ptr);

                // Shift síos gach rud a líonadh sa láthair.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Ní choinníonn sé ach na heilimintí a shonraíonn an tuar.
    ///
    /// Is é sin le rá, bain na heilimintí `e` go léir ionas go bhfillfidh `f(&e)` `false`.
    /// Feidhmíonn an modh seo i bhfeidhm, ag tabhairt cuairte ar gach eilimint díreach uair amháin san ord bunaidh, agus ag caomhnú ord na n-eilimintí coinnithe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Toisc go dtugtar cuairt ar na heilimintí go díreach uair amháin san ord bunaidh, féadfar stát seachtrach a úsáid chun cinneadh a dhéanamh ar na heilimintí atá le coinneáil.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Seachain titim dhúbailte mura ndéantar an garda titim a fhorghníomhú, mar d`fhéadfaimis roinnt poill a dhéanamh le linn an phróisis.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-próiseáilte len-> |^-in aice le seiceáil
        //                  | <-scriosta cnt-> |
        //      | <-original_len-> |Coinnigh: Eilimintí a thuar go bhfuil na torthaí fíor.
        //
        // Poll: Sliotán eilimint ar athraíodh a ionad nó a thit.
        // Unchecked: eilimintí bailí unchecked.
        //
        // Déanfar an garda titim seo a agairt nuair a bheidh predicate nó `drop` den eilimint pioctha.
        // Athraíonn sé eilimintí neamhsheiceáilte chun poill agus `set_len` a chlúdach go dtí an fad ceart.
        // I gcásanna nuair nach dtéann predicate agus `drop` i scaoll, déanfar é a bharrfheabhsú.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SÁBHÁILTEACHT: Ní mór Trailing míreanna unchecked bailí riamh ó muid teagmháil leo.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SÁBHÁILTEACHT: Tar éis poill a líonadh, tá cuimhne chomhtheagmhálach ar gach earra.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SÁBHÁILTEACHT: Caithfidh an eilimint neamhsheiceáilte a bheith bailí.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Téigh ar aghaidh go luath chun titim dhúbailte a sheachaint má chliseann `drop_in_place`.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SÁBHÁILTEACHT: Ní dhéanaimid teagmháil riamh leis an eilimint seo arís tar éis titim.
                unsafe { ptr::drop_in_place(cur) };
                // Chuireamar an cuntar chun cinn cheana féin.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SÁBHÁILTEACHT: `deleted_cnt`> 0, mar sin níor cheart go ndéanfadh an sliotán poll forluí leis an eilimint reatha.
                // Úsáidimid cóip le haghaidh gluaiseachta, agus ní dhéanaimid teagmháil leis an eilimint seo arís.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // mír Gach phróiseáil.Is féidir é seo a uasmhéadú chun `set_len` ag LLVM.
        drop(g);
    }

    /// Baintear gach eilimint as a chéile ach an chéad cheann díobh sa vector a réitíonn go dtí an eochair chéanna.
    ///
    ///
    /// Má dhéantar an vector a shórtáil, baintear é seo as gach dúblach.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Baintear gach ceann ach an chéad cheann de na heilimintí as a chéile sa vector a shásaíonn gaol comhionannas ar leith.
    ///
    /// Gabhann feidhm `same_bucket` tagairtí do dhá ghné ón vector agus caithfidh sí a chinneadh an bhfuil na heilimintí i gcomparáid lena chéile.
    /// Ritear na heilimintí in ord contrártha óna n-ord sa slice, mar sin má fhilleann `same_bucket(a, b)` `true`, baintear `a`.
    ///
    ///
    /// Má dhéantar an vector a shórtáil, baintear é seo as gach dúblach.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Appends gné go dtí cúl bailiúchán.
    ///
    /// # Panics
    ///
    /// Panics má sháraíonn acmhainn nua bytes `isize::MAX`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Seo Beidh panic nó Tobscoir má ba mhaith linn a leithdháileadh> isize::MAX bytes nó más rud é go mbeadh an incrimint fad thar maoil le haghaidh cineálacha náid-iarrachtaí.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Bain an rud is deireanaí ó vector agus tuairisceáin é, nó [`None`] má tá sé folamh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Téigh go léir na gnéithe den `other` `Self` isteach, ag fágáil `other` folamh.
    ///
    /// # Panics
    ///
    /// Panics má sháraíonn líon na n-eilimintí sa vector `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Cuirtear eilimintí i bhfeidhm ar `Self` ó mhaolán eile.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Cruthaíonn sé iterator draenála a bhaineann an raon sonraithe sa vector agus a thugann na míreanna bainte.
    ///
    /// Nuair a thit **an t-iteoir**, baintear na heilimintí go léir sa raon ón vector, fiú mura raibh an t-atreoraitheoir ídithe go hiomlán.
    /// Mura scaoiltear **an t-iteoir**(le [`mem::forget`] mar shampla), tá sé neamhshonraithe cé mhéad eilimint a bhaintear.
    ///
    /// # Panics
    ///
    /// Panics má tá an pointe tosaigh níos mó ná an pointe deiridh nó má tá an pointe deiridh níos mó ná fad an vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Glanann raon iomlán an vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Sábháilteacht cuimhne
        //
        // Nuair a chruthaítear an Drain den chéad uair, giorraíonn sé fad na foinse vector chun a chinntiú nach bhfuil aon eilimintí neamhbheartaithe nó bogtha inrochtana ar chor ar bith mura bhfaigheann scriosóir an Drain rith riamh.
        //
        //
        // Déanfaidh Drain ptr::read na luachanna atá le baint a bhaint.
        // Nuair a chríochnaigh, tá eireaball eile den vec chóipeáil ar ais a chlúdach an poll, agus tá an fad vector ar ais ar an fad nua.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // socraigh faid self.vec le tosú, le bheith sábháilte ar eagla go sceitheadh Drain
            self.set_len(start);
            // Úsáid an iasacht san IterMut chun iompar iasachta an iterator Drain iomlán a léiriú (cosúil le &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Glanann an vector, ag baint na luachanna go léir.
    ///
    /// Tabhair faoi deara go bhfuil an modh seo nach bhfuil aon éifeacht ar an acmhainn a leithdháileadh ar an vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Filleann sé líon na n-eilimintí sa vector, dá ngairtear a 'length' freisin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Tuairisceáin `true` mura bhfuil aon eilimintí sa vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Roinntear an bailiúchán ina dhá leath ag an innéacs a thugtar.
    ///
    /// Tuairisceáin a vector nua-leithdháilte a bhfuil na nithe sa réimse `[at, len)`.
    /// Tar éis an ghlao, fágfar an vector bunaidh ina mbeidh na heilimintí `[0, at)` agus a chumas roimhe seo gan athrú.
    ///
    ///
    /// # Panics
    ///
    /// Panics más `at > len` é.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // Is féidir leis an vector nua a ghlacadh ar láimh ar an maolán bunaidh agus an chóip a sheachaint
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // `set_len` go neamhshábháilte agus cóipeáil míreanna chuig `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Athraigh méid an `Vec` i bhfeidhm ionas go mbeidh `len` cothrom le `new_len`.
    ///
    /// Má tá `new_len` níos mó ná `len`, tá an `Vec` shíneadh leis an difríocht, a bhfuil gach sliotán sa bhreis líonadh leis an toradh ghlaoch ar an dúnadh `f`.
    ///
    /// Críochnóidh na luachanna toraidh ó `f` san `Vec` san ord a gineadh iad.
    ///
    /// Má tá `new_len` níos lú ná `len`, teastaítear an `Vec` go simplí.
    ///
    /// Úsáideann an modh seo dúnadh chun luachanna nua a chruthú ar gach brú.Más fearr leat [`Clone`] luach ar leith, úsáid [`Vec::resize`].
    /// Más mian leat an [`Default`] trait a úsáid chun luachanna a ghiniúint, is féidir leat [`Default::default`] a rith mar an dara argóint.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Ídíonn agus leaks an `Vec`, ag filleadh tagairt mutable leis an ábhar, `&'a mut [T]`.
    /// Tabhair faoi deara go gcaithfidh an cineál `T` an saolré `'a` roghnaithe a mhaireachtáil.
    /// Mura bhfuil ach tagairtí statacha ag an gcineál, nó gan tagairtí statacha ar bith ann, féadfar é seo a roghnú le bheith `'static`.
    ///
    /// Tá an fheidhm seo cosúil leis an bhfeidhm [`leak`][Box::leak] ar [`Box`] ach amháin nach bhfuil aon bhealach ann an chuimhne sceite a aisghabháil.
    ///
    ///
    /// Tá an fheidhm seo úsáideach go príomha le haghaidh sonraí a mhaireann ar feadh an chuid eile de shaol an chláir.
    /// Má scaoiltear an tagairt ar ais beidh sceitheadh cuimhne ann.
    ///
    /// # Examples
    ///
    /// Úsáid shimplí:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Tuairisceáin an acmhainn bhreise eile den vector mar slice de `MaybeUninit<T>`.
    ///
    /// Is féidir an slice a cuireadh ar ais a úsáid chun an vector a líonadh le sonraí (m.sh.
    /// trí léamh ó chomhad) sula marcáiltear na sonraí mar sonraí tosaigh agus an modh [`set_len`] á úsáid.
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Leithdháileadh vector mór go leor le haghaidh 10 eilimint.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Líon na chéad 3 ghné.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Marcáil na chéad 3 ghné den vector mar thúsú.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Ní chuirtear an modh seo i bhfeidhm i dtéarmaí `split_at_spare_mut`, chun leideanna ó thaobh an mhaoláin a chur ó bhail.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Filleann sé ábhar vector mar shlisne de `T`, mar aon leis an acmhainn spártha atá fágtha den vector mar shlisne de `MaybeUninit<T>`.
    ///
    /// Is féidir an slice acmhainne spártha a cuireadh ar ais a úsáid chun an vector a líonadh le sonraí (m.sh. trí léamh ó chomhad) sula marcáiltear na sonraí mar sonraí tosaigh agus an modh [`set_len`] á úsáid.
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Tabhair faoi deara gur API leibhéal íseal é seo, ba cheart a úsáid go cúramach chun críocha optamaithe.
    /// Más gá duit sonraí a chur i gceangal le `Vec` is féidir leat [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] nó [`resize_with`] a úsáid, ag brath ar do riachtanais chruinne.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Cúlchiste spás breise go leor mór do 10 eilimintí.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Líon na 4 ghné eile.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Marcáil an 4 eilimintí an vector le bheith initialized.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - Déantar neamhaird de len agus mar sin ní athraítear í riamh
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Sábháilteacht: meastar gurb ionann an t-athrú ar ais .2 (&mut usize) agus `.set_len(_)` a ghlaoch.
    ///
    /// Úsáidtear an modh seo chun rochtain uathúil a bheith aige ar gach cuid vec ag `extend_from_within` ag an am céanna.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` ráthaítear go mbeidh sé bailí d`eilimintí `len`
        // - `spare_ptr` ag díriú eilimint amháin anuas ar an maolán, mar sin níl sí ag forluí le `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Athraigh méid an `Vec` i bhfeidhm ionas go mbeidh `len` cothrom le `new_len`.
    ///
    /// Má tá `new_len` níos mó ná `len`, déantar an `Vec` a leathnú leis an difríocht, agus líontar gach sliotán breise le `value`.
    ///
    /// Má tá `new_len` níos lú ná `len`, teastaítear an `Vec` go simplí.
    ///
    /// Éilíonn an modh seo ar `T` [`Clone`] a chur i bhfeidhm, d`fhonn a bheith in ann an luach a rith a chlónáil.
    /// Más gá duit níos mó solúbthachta (nó ag iarraidh a bheith ag brath ar [`Default`] in áit [`Clone`]), bain úsáid as [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Clónáil agus cuir gach eilimint i slisne leis an `Vec`.
    ///
    /// Iterates thar an slice `other`, Clónáil gach eilimint, agus ansin é a chur i gceangal leis an `Vec` seo.
    /// Déantar an `other` vector a thrasnú in ord.
    ///
    /// Tabhair faoi deara go bhfuil an fheidhm seo mar [`extend`] gcéanna ach amháin go bhfuil sé speisialaithe a bheith ag obair le slices ina ionad.
    ///
    /// Má dhéantar agus nuair a fhaigheann Rust speisialtóireacht is dócha go ndéanfar an fheidhm seo a dhímheas (ach fós ar fáil).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Cóipeanna eilimintí ó `src` raon go dtí deireadh an vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` ráthaíonn sé go bhfuil an raon tugtha bailí chun féin a innéacsú
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Déanann an cód seo `extend_with_{element,default}` a ghinearálú.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Leathnaigh an vector de réir luachanna `n`, agus an gineadóir tugtha á úsáid agat.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Úsáid SetLenOnDrop chun oibriú timpeall ar fhabht sa chás nach dtuigeann an tiomsaitheoir an siopa trí `ptr` trí self.set_len() ná ailias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Scríobh gach gné seachas an ceann deireanach
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Méadú ar an bhfad i ngach céim i gcás next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Is féidir linn a scríobh an rud is deireanaí go díreach gan chlónáil needlessly
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len socraithe ag garda scóip
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Baintear eilimintí as a chéile arís agus arís eile sa vector de réir chur chun feidhme [`PartialEq`] trait.
    ///
    ///
    /// Má dhéantar an vector a shórtáil, baintear é seo as gach dúblach.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Modhanna agus feidhmeanna inmheánacha
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` Ní mór a bheith innéacs bailí
    /// - `self.capacity() - self.len()` caithfidh `>= src.len()` a bheith ann
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - ní mhéadaítear len ach tar éis eilimintí a thionscnamh
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - Ráthaíonn an té atá ag glaoch gur innéacs bailí é src
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Bhí Eilimint initialized díreach leis `MaybeUninit::write`, mar sin tá sé ceart go leor a LEN increace
            // - Méadaítear len tar éis gach eilimint chun sceitheanna a chosc (féach eagrán #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - Ráthaíonn an té atá ag glaoch gur innéacs bailí é `src`
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Cruthaítear an dá threo ó thagairtí slice ar leith (`&mut [_]`) ionas go mbeidh siad bailí agus nach ndéanann siad forluí.
            //
            // - Is iad seo a leanas na gnéithe: Cóipeáil mar sin tá sé ceart go leor iad a chóipeáil, gan aon rud a dhéanamh leis na bunluachanna
            // - `count` is comhionann leis an LEN na `source`, agus mar sin tá foinse bailí ar feadh `count` léann
            // - `.reserve(count)` ráthaíonn sé go bhfuil `spare.len() >= count` chomh spártha bailí le haghaidh scríbhinní `count`
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Cuireadh tús díreach leis na heilimintí le `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Cur chun feidhme coitianta trait do Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): leis cfg(test) an modh `[T]::to_vec` gné dhílis, atá ag teastáil le haghaidh an mhínithe modh nach bhfuil, ar fáil.
    // Ina áit sin bain úsáid as an bhfeidhm `slice::to_vec` nach bhfuil ar fáil ach le cfg(test) NB féach an modúl slice::hack in slice.rs chun tuilleadh faisnéise a fháil
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // rud ar bith nach mbeidh a overwritten titim
        self.truncate(other.len());

        // self.len <= other.len mar gheall ar an truncate thuas, mar sin tá na slisní anseo istigh i gcónaí.
        //
        let (init, tail) = other.split_at(self.len());

        // athúsáid na luachanna atá ann allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Cruthaíonn sé iterator íditheach, is é sin, ceann a ghluaiseann gach luach as an vector (ó thús go deireadh).
    /// Ní féidir an vector a úsáid tar éis é seo a ghlaoch.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s cineál Teaghrán, ní &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // modh duilleoige a tharmligfidh cur chun feidhme SpecFrom/SpecExtend éagsúla nuair nach bhfuil aon optamaithe breise le cur i bhfeidhm acu
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Is amhlaidh atá i gcás atreoraithe ginearálta.
        //
        // Ba cheart go mbeadh an fheidhm seo comhionann le morálta:
        //
        //      le haghaidh mír in iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB Is féidir ní thar maoil ó ba mhaith linn bhí acu go alloc an seoladh spáis
                self.set_len(len + 1);
            }
        }
    }

    /// Cruthaíonn sé iterator splicing a chuireann an t-iteoir `replace_with` tugtha in ionad an raoin shonraithe sa vector agus a thugann na míreanna bainte.
    ///
    /// `replace_with` ní gá go mbeadh an fad céanna le `range`.
    ///
    /// `range` baintear é fiú mura gcaitear an t-iteoir go dtí an deireadh.
    ///
    /// Is neamhshonraithe cé mhéad gnéithe bhaintear as an vector má tá an luach `Splice` leaked.
    ///
    /// Ní ídítear an t-iteoir ionchuir `replace_with` ach nuair a thittear luach `Splice`.
    ///
    /// Tá sé seo optamach más rud é:
    ///
    /// * Is é an t-eireaball (eilimintí sa vector ndiaidh `range`) folamh,
    /// * nó táirgeacht `replace_with` níos lú nó cothrom eilimintí seachas `fad range` ar
    /// * nó tá an teorainn íochtarach dá `size_hint()` cruinn.
    ///
    /// Seachas sin, leithdháiltear vector sealadach agus bogtar an t-eireaball faoi dhó.
    ///
    /// # Panics
    ///
    /// Panics má tá an pointe tosaigh níos mó ná an pointe deiridh nó má tá an pointe deiridh níos mó ná fad an vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Cruthaíonn sé iterator a úsáideann dúnadh chun a fháil amach ar cheart eilimint a bhaint.
    ///
    /// Má fhilleann an dúnadh fíor, baintear an eilimint agus táirgtear í.
    /// Má fhilleann an dúnadh bréagach, beidh an eilimint fanacht sa vector agus ní fuarthas ag an iterator.
    ///
    /// Is ionann an modh seo a úsáid agus an cód seo a leanas:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // do chód anseo
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Ach tá `drain_filter` níos éasca a úsáid.
    /// `drain_filter` tá sé níos éifeachtaí freisin, toisc go bhféadann sé eilimintí an eagair a chúlú ar an mórchóir.
    ///
    /// Tabhair faoi deara go ligeann `drain_filter` duit gach eilimint sa dúnadh scagaire a threáitearú, is cuma má roghnaíonn tú é a choinneáil nó a bhaint.
    ///
    ///
    /// # Examples
    ///
    /// Roinntear eagar ina n-oícheanta agus na n-odds, agus an leithdháileadh bunaidh á athúsáid:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Garda i gcoinne muid a sceitheadh (aimpliú sceite)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Leathnú chun feidhme go bhfuil eilimintí cóipeanna as tagairtí sula brú orthu ar an gCoiste Gairmoideachais.
///
/// Tá an cur i bhfeidhm speisialaithe do Iterators slice, i gcás ina n-úsáideann sé [`copy_from_slice`] i gceangal leis an slice ar fad ag an am céanna.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Cuireann sé comparáid idir vectors, i bhfeidhm [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Cuireann ordú de vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // bain úsáid as titim le haghaidh [T] bain úsáid as slice amh chun tagairt a dhéanamh d`eilimintí an vector mar an cineál is laige is gá;
            //
            // d`fhéadfadh ceisteanna bailíochta a sheachaint i gcásanna áirithe
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // Láimhseálann RawVec deallocation
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Cruthaíonn `Vec<T>` folamh.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: tarraingíonn tástáil libstd, rud a chruthaíonn earráidí anseo
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: tarraingíonn tástáil libstd, rud a chruthaíonn earráidí anseo
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Faigheann ábhar iomlán an `Vec<T>` mar eagar, más ionann a mhéid agus méid an eagráin iarrtha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Mura n-oireann an fad, tagann an t-ionchur ar ais i `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Má tá tú ceart go leor gan réimír den `Vec<T>` a fháil, is féidir leat [`.truncate(N)`](Vec::truncate) a ghlaoch ar dtús.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SÁBHÁILTEACHT: Tá `.set_len(0)` fónta i gcónaí.
        unsafe { vec.set_len(0) };

        // SÁBHÁILTEACHT: Tá pointeoir `Vec` ailínithe i gceart i gcónaí, agus
        // tá an t-ailíniú a theastaíonn ó eagar mar an gcéanna leis na míreanna.
        // Rinneamar seiceáil níos luaithe go bhfuil go leor earraí againn.
        // Beidh na nithe nach double-titim mar a insíonn an `set_len` an `Vec` gan titim orthu chomh maith.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}