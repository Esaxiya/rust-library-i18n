//! Radharc dinimiciúil-iarrachtaí i seicheamh tadhlach, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Is éard atá i slisní ná radharc ar bhloc cuimhne a léirítear mar threoir agus faid.
//!
//! ```
//! // ag slisniú Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // ag brú eagar ar shlisne
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Tá slisní inathraithe nó roinnte.
//! Is é an cineál slice roinnte `&[T]`, agus is é `&mut [T]` an cineál slice inathraithe, áit a léiríonn `T` an cineál eiliminte.
//! Mar shampla, is féidir leat an bloc cuimhne a dhíríonn ar shliseog inathraithe a threisiú:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Seo cuid de na rudaí atá sa mhodúl seo:
//!
//! ## Structs
//!
//! Tá roinnt struchtúr ann atá úsáideach do shlisníní, mar shampla [`Iter`], a léiríonn atriall thar shlis.
//!
//! ## Trait Implementations
//!
//! Tá roinnt cur chun feidhme de traits coitianta le haghaidh slisní.I measc roinnt samplaí tá:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], d'slices bhfuil eilimint de chineál iad [`Eq`] nó [`Ord`].
//! * [`Hash`] - le haghaidh slisní arb é a gcineál eiliminte [`Hash`].
//!
//! ## Iteration
//!
//! Cuireann na slisní `IntoIterator` i bhfeidhm.táirgeacht An iterator tagairtí do na heilimintí slice.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Tugann an slice inathraithe tagairtí do-athraithe do na heilimintí:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Tugann an t-iteoir seo tagairtí do-athraithe d`eilimintí an tslis, mar sin cé gurb é `i32` cineál eilimint an tslis, is é `&mut i32` cineál eiliminte an iteora.
//!
//!
//! * [`.iter`] agus [`.iter_mut`] na modhanna follasacha chun na iteoirí réamhshocraithe a chur ar ais.
//! * Modhanna breise a chuireann iteoirí ar ais ná [`.split`], [`.splitn`], [`.chunks`], [`.windows`] agus níos mó.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Go leor de na usings sa mhodúl seo a úsáid ach amháin sa chumraíocht tástála.
// Tá sé níos glaine an rabhadh neamhúsáidte_imports a mhúchadh ná iad a shocrú.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Modhanna bunúsacha síneadh slice
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) a theastaíonn chun macra `vec!` a chur i bhfeidhm le linn NB a thástáil, féach an modúl `hack` sa chomhad seo le haghaidh tuilleadh sonraí.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) a theastaíonn chun `Vec::clone` a chur i bhfeidhm le linn NB a thástáil, féach an modúl `hack` sa chomhad seo le haghaidh tuilleadh sonraí.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Le nach bhfuil cfg(test) `impl [T]` ar fáil, is modhanna iad na trí fheidhm seo atá in `impl [T]` ach nach bhfuil in `core::slice::SliceExt`, ní mór dúinn na feidhmeanna seo a sholáthar don tástáil `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Níor cheart dúinn tréith inlíne a chur leis seo ós rud é go n-úsáidtear é seo i macra `vec!` den chuid is mó agus is cúis le aischéimniú foirfe é.
    // Féach #71204 le plé agus perf torthaí.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // Bhí míreanna marcáilte initialized sa lúb thíos
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) riachtanach chun LLVM seiceálacha faoi theorainneacha a bhaint agus tá codegen níos fearr aige ná zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // leithdháileadh agus tionscnaíodh an vec thuas go dtí an fad seo ar a laghad.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // leithdháilte thuas le toilleadh `s`, agus tosaigh go `s.len()` in ptr::copy_to_non_overlapping thíos.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Sórtáil an slice.
    ///
    /// Tá an saghas cobhsaí (.i dhéanann, eilimintí comhionanna ní dhéanfaidh atheagar) agus *O*(*n*\*log(* n*)) is measa ar chás.
    ///
    /// Nuair is infheidhme, is fearr sórtáil éagobhsaí toisc go bhfuil sé níos gasta i gcoitinne ná sórtáil chobhsaí agus ní leithdháileann sé cuimhne chúnta.
    /// Féach [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Cur i bhfeidhm reatha
    ///
    /// Is é an algartam atá ann faoi láthair oiriúnaitheach, merge sórtáil atriallach spreagtha ag [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Tá sé deartha chun a bheith an-tapa i gcásanna ina bhfuil an t-slice curtha in eagar beagnach, nó de dhá nó sraitheanna níos curtha in eagar concatenated i ndiaidh a chéile.
    ///
    ///
    /// Chomh maith leis sin, leithdháileann sé stóráil shealadach leath mhéid `self`, ach i gcás slisní gearra úsáidtear sórt isteach neamh-leithdháilte ina ionad.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Sórtálfar an slice le feidhm comparadóir.
    ///
    /// Tá an saghas cobhsaí (.i dhéanann, eilimintí comhionanna ní dhéanfaidh atheagar) agus *O*(*n*\*log(* n*)) is measa ar chás.
    ///
    /// Caithfidh feidhm an chomparadóra ordú iomlán a shainiú do na heilimintí sa slice.Mura bhfuil an t-ordú iomlán, tá ord na n-eilimintí neamhshonraithe.
    /// Is ordú iomlán ordú más ea (do gach `a`, `b` agus `c`):
    ///
    /// * iomlán agus antisymmetric: Tá sé ceann de na `a < b`, `a == b` nó `a > b` fíor, agus
    /// * aistreacha, `a < b` agus `b < c` tuiscint `a < c`.Ní mór an rud céanna a bheith ag `==` agus `>` araon.
    ///
    /// Mar shampla, cé nach bhfuil [`f64`] a chur i bhfeidhm [`Ord`] gheall `NaN != NaN`, is féidir linn a úsáid `partial_cmp` mar ár fheidhm saghas nuair a fhios againn an slice níl a `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Nuair is infheidhme, is fearr sórtáil éagobhsaí toisc go bhfuil sé níos gasta i gcoitinne ná sórtáil chobhsaí agus ní leithdháileann sé cuimhne chúnta.
    /// Féach [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Cur i bhfeidhm reatha
    ///
    /// Is é an algartam atá ann faoi láthair oiriúnaitheach, merge sórtáil atriallach spreagtha ag [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Tá sé deartha chun a bheith an-tapa i gcásanna ina bhfuil an t-slice curtha in eagar beagnach, nó de dhá nó sraitheanna níos curtha in eagar concatenated i ndiaidh a chéile.
    ///
    /// Chomh maith leis sin, leithdháileann sé stóráil shealadach leath mhéid `self`, ach i gcás slisní gearra úsáidtear sórt isteach neamh-leithdháilte ina ionad.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // sórtáil droim ar ais
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Sórtáil an slice le príomhfheidhm eastósctha.
    ///
    /// Tá an sórt seo seasmhach (ie, ní athordaíonn sé eilimintí comhionanna) agus *O*(*m*\* * n *\* log(*n*)) sa chás is measa, áit a bhfuil an phríomhfheidhm *O*(*m*).
    ///
    /// Le haghaidh príomhfheidhmeanna costasacha (m.sh.
    /// feidhmeanna nach rochtana simplí maoine nó oibríochtaí bunúsacha iad), is dóigh go mbeidh [`sort_by_cached_key`](slice::sort_by_cached_key) i bhfad níos gasta, toisc nach ndéanann sé eochracha eiliminte a chúiteamh.
    ///
    ///
    /// Nuair is infheidhme, is fearr sórtáil éagobhsaí toisc go bhfuil sé níos gasta i gcoitinne ná sórtáil chobhsaí agus ní leithdháileann sé cuimhne chúnta.
    /// Féach [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Cur i bhfeidhm reatha
    ///
    /// Is é an algartam atá ann faoi láthair oiriúnaitheach, merge sórtáil atriallach spreagtha ag [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Tá sé deartha chun a bheith an-tapa i gcásanna ina bhfuil an t-slice curtha in eagar beagnach, nó de dhá nó sraitheanna níos curtha in eagar concatenated i ndiaidh a chéile.
    ///
    /// Chomh maith leis sin, leithdháileann sé stóráil shealadach leath mhéid `self`, ach i gcás slisní gearra úsáidtear sórt isteach neamh-leithdháilte ina ionad.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Sórtáil an slice le príomhfheidhm eastósctha.
    ///
    /// Le linn sórtála, ní thugtar an phríomhfheidhm ach uair amháin in aghaidh na heiliminte.
    ///
    /// Tá an saghas cobhsaí (ie, ní eilimintí comhionann nach atheagar) agus *O*(*m*\* * n *+* n *\* log(*n*)) measa, i gcás ina bhfuil an phríomhfheidhm *O*(*m*) .
    ///
    /// Maidir le príomhfheidhmeanna shimplí (m.sh., feidhmeanna atá rochtana maoine nó oibríochtaí bunúsacha), is dócha go mbeidh níos tapúla [`sort_by_key`](slice::sort_by_key).
    ///
    /// # Cur i bhfeidhm reatha
    ///
    /// Tá an algartam reatha bunaithe ar [pattern-defeating quicksort][pdqsort] le Orson Peters, a chomhcheanglaíonn an cás mear tapa de quicksort randamach leis an gcás is measa go tapa de heapsort, agus am líneach á bhaint amach ar shlisní le patrúin áirithe.
    /// Úsáideann sé roinnt randomization a sheachaint cásanna degenerate, ach le seed seasta chun iompar deterministic a chur ar fáil i gcónaí.
    ///
    /// Sa chás is measa, leithdháileann an algartam stóráil shealadach i `Vec<(K, usize)>` fad an tslis.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Macra cúntóra chun ár vector a innéacsú de réir an chineáil is lú is féidir, chun an leithdháileadh a laghdú.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Is iad na gnéithe de `indices` uathúil, mar a bhfuil siad innéacsú, mar sin beidh aon saghas a bheith seasmhach maidir leis an slice bunaidh.
                // Bainimid úsáid as `sort_unstable` anseo mar a éilíonn sé leithdháileadh cuimhne níos lú.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Cóipeanna `self` isteach i `Vec` nua.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Anseo, is féidir `s` agus `x` a mhodhnú go neamhspleách.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Cóipeáil `self` i `Vec` nua le leithdháilteoir.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Anseo, is féidir `s` agus `x` a mhodhnú go neamhspleách.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, féach an modúl `hack` sa chomhad seo le haghaidh tuilleadh sonraí.
        hack::to_vec(self, alloc)
    }

    /// Tiontaíonn `self` ina vector gan chlóin nó leithdháileadh.
    ///
    /// Is féidir leis an vector mar thoradh air a thiontú ar ais mbosca via `CGO<T>` 'S `into_boxed_slice` modh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` ní féidir é a úsáid níos mó toisc gur athraíodh é go `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, féach an modúl `hack` sa chomhad seo le haghaidh tuilleadh sonraí.
        hack::into_vec(self)
    }

    /// Cruthaíonn sé vector trí slice `n` a athrá.
    ///
    /// # Panics
    ///
    /// Beidh an fheidhm panic má tá an cumas a bheadh thar maoil.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// A panic ar ró-shreabhadh:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Má tá `n` níos mó ná nialas, is féidir é a roinnt mar `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` an uimhir a léirítear leis an giotán '1' is faide ar chlé de `n`, agus is é `rem` an chuid eile de `n`.
        //
        //

        // Ag baint úsáide as `Vec` chun `set_len()` a rochtain.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` déantar athrá trí `buf` `expn`-times a dhúbailt.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Más `m > 0` é, tá giotáin fágtha suas go dtí an '1' is faide ar chlé.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` tá toilleadh `self.len() * n` aige.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) déantar athrá trí chéad athrá `rem` a chóipeáil ó `buf` féin.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Níl sé seo ag forluí ó `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` cothrom le `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Déanann slice de `T` a chothromú i luach amháin `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Déanann slice de `T` a chothromú i luach amháin `Self::Output`, ag cur deighilteoir ar leith idir gach ceann acu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Déanann slice de `T` a chothromú i luach amháin `Self::Output`, ag cur deighilteoir ar leith idir gach ceann acu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Seoltar vector ar ais ina bhfuil cóip den slice seo ina ndéantar gach beart a mhapáil dá choibhéis cás uachtair ASCII.
    ///
    ///
    /// Déantar litreacha ASCII 'a' go 'z' a mhapáil go 'A' go 'Z', ach níl aon athrú ar litreacha neamh-ASCII.
    ///
    /// Chun an luach atá i bhfeidhm a shárú, úsáid [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Seoltar vector ar ais ina bhfuil cóip den slice seo áit a ndéantar gach beart a mhapáil dá choibhéis cás íochtair ASCII.
    ///
    ///
    /// ASCII litreacha 'A' go 'Z' mapáilte chuig 'a' go 'z', ach tá litreacha nach ASCII gan athrú.
    ///
    /// Chun an luach atá i bhfeidhm a ísliú, úsáid [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// traits a leathnú le haghaidh slisní thar chineálacha sonracha sonraí
////////////////////////////////////////////////////////////////////////////////

/// Cúntóir trait le haghaidh [`[T]: : concat`](slice::concat).
///
/// Note: ní úsáidtear an paraiméadar cineál `Item` sa trait seo, ach tugann sé deis do impls a bheith níos cineálach.
/// Gan é, faighimid an earráid seo:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Tá sé seo toisc go bhféadfadh cineálacha `V` a bheith ann le il-impleachtaí `Borrow<[_]>`, sa chaoi go mbeadh ilchineálacha `T` i bhfeidhm:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// An cineál mar thoradh air tar éis concatenation
    type Output;

    /// Cur i bhfeidhm [`[T]: : concat`](slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Cúntóir trait le haghaidh [`[T]: : join`](slice::join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// An cineál mar thoradh air tar éis concatenation
    type Output;

    /// Cur i bhfeidhm [`[T]: : join`](slice::páirteach)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Cur chun feidhme caighdeánach trait le haghaidh slisní
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // rud ar bith i sprioc nach mbeidh a bheith overwritten titim
        target.truncate(self.len());

        // target.len <= self.len mar gheall ar an truncate thuas, mar sin tá na slisní anseo istigh i gcónaí.
        //
        let (init, tail) = self.split_at(target.len());

        // athúsáid na luachanna atá ann allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Cuir `v[0]` isteach i seicheamh réamh-sórtáilte `v[1..]` ionas go ndéanfar `v[..]` iomlán a shórtáil.
///
/// Is é seo an fo-riail dhílis de shórtáil isteach.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Tá trí bhealach ann le cuir isteach a chur i bhfeidhm anseo:
            //
            // 1. Babhtáil eilimintí cóngaracha go dtí go sroicheann an chéad cheann a cheann scríbe deiridh.
            //    Ar an mbealach seo, áfach, déanaimid sonraí a chóipeáil timpeall níos mó ná mar is gá.
            //    Más struchtúir mhóra iad eilimintí (costasach le cóipeáil), beidh an modh seo mall.
            //
            // 2. Abair leo go dtí go áit ceart don chéad eilimint leathanach Torthaí.
            // Ansin aistrigh na heilimintí ina dhiaidh sin chun seomra a dhéanamh dó agus ar deireadh cuir sa pholl atá fágtha é.
            // Is modh maith é seo.
            //
            // 3. Cóipeáil an chéad eilimint in athróg sealadach.Iterate go dtí go bhfaightear an áit cheart dó.
            // Agus muid ag dul ar aghaidh, cóipeáil gach eilimint thrasnaithe sa sliotán atá rompu.
            // Faoi dheireadh, cóipeáil sonraí ón athróg sealadach isteach sa pholl atá fágtha.
            // Tá an modh seo an-mhaith.
            // Léirigh tagarmharcanna feidhmíocht beagán níos fearr ná mar a bhí leis an 2ú modh.
            //
            // Bhí tagarmharcáil Gach modhanna, agus an 3ú léirigh na torthaí is fearr.Mar sin, roghnaigh muid go bhfuil ceann.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Rianaíonn `hole` staid idirmheánach an phróisis isteach i gcónaí, a fhreastalaíonn ar dhá chuspóir:
            // 1. Cosnaíonn sláine `v` ó panics in `is_less`.
            // 2. Líonann an poll atá fágtha i `v` sa deireadh.
            //
            // Sábháilteacht Panic:
            //
            // Má dhéantar `is_less` panics ag pointe ar bith le linn an phróisis, scaoilfear `hole` agus líonfaidh sé an poll i `v` le `tmp`, ag cinntiú mar sin go gcoinníonn `v` gach réad a bhí aige i dtosach díreach uair amháin.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` titeann sé agus dá bhrí sin cóipeálann `tmp` isteach sa pholl atá fágtha i `v`.
        }
    }

    // Nuair a thit siad, cóipeanna ó `src` isteach i `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Ritheann cumasc neamh-laghdaitheach `v[..mid]` agus `v[mid..]` ag úsáid `buf` mar stóráil shealadach, agus stórálann sé an toradh i `v[..]`.
///
/// # Safety
///
/// Caithfidh an dá shlisní a bheith neamhfholamh agus caithfidh `mid` a bheith faoi theorainneacha.
/// Caithfidh maolán `buf` a bheith fada go leor chun cóip den slice is giorra a choinneáil.
/// Chomh maith leis sin, ní gá gur cineál meánmhéide é `T`.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Déanann an próiseas cumaisc cóipeáil den chéad uair i `buf`.
    // Ansin rianaíonn sé an rith nua-chóipeáilte agus an rith níos faide ar aghaidh (nó ar gcúl), ag comparáid idir na chéad eilimintí eile gan iarraidh agus ag cóipeáil an ceann is lú (nó níos mó) i `v`.
    //
    // Chomh luath agus a bhfuil an rith níos giorra chaitear go hiomlán, is é an próiseas déanta.Má fhaigheann an rith níos faide chaitear ar dtús, ansin ní mór dúinn a chóipeáil cuma cad atá fágtha an reatha giorra isteach sa pholl fágtha sa `v`.
    //
    // Rianaíonn `hole` staid idirmheánach an phróisis i gcónaí, a fhreastalaíonn ar dhá chuspóir:
    // 1. Cosnaíonn sláine `v` ó panics in `is_less`.
    // 2. Líonann an poll atá fágtha i `v` má thagann an rith níos faide chaitear ar dtús.
    //
    // Sábháilteacht Panic:
    //
    // Má dhéantar `is_less` panics ag pointe ar bith le linn an phróisis, tiocfaidh `hole` anuas agus líonfaidh sé an poll i `v` leis an raon neamh-inchúisithe in `buf`, ag cinntiú mar sin go gcoinníonn `v` gach réad a bhí aige i dtosach díreach uair amháin.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Is giorra an rith ar chlé.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Ar dtús, díríonn na leideanna seo ar thús a n-eagair.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Ithe an taobh is lú.
            // Más comhionann, is fearr an rith ar chlé cobhsaíocht a choimeád ar bun.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Is é an reáchtáil ceart giorra.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Ar dtús, díríonn na leideanna seo thar fhoircinn a n-eagair.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Ithe an taobh is mó.
            // Más comhionann é, b`fhearr leat an rith cheart chun an chobhsaíocht a choinneáil.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Faoi dheireadh, titeann `hole`.
    // Más rud é nach raibh an rith níos giorra chaitear go hiomlán, beidh cuma cad iarsmaí de a chóipeáil anois isteach sa pholl san `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Nuair a thit sé, cóipeáil an raon `start..end` go `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ní cineál meánmhéide é, mar sin tá sé ceart go leor a roinnt de réir a mhéid.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Faigheann an sórtáil chumaisc seo roinnt smaointe (ach ní iad uile) ó TimSort, a ndéantar cur síos mionsonraithe air [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Aithníonn an t-algartam iarmhéideanna íslitheach agus neamh-íslitheach, ar a dtugtar ritheann nádúrtha.Tá carn de ritheann ar feitheamh fós le cumasc.
/// Déantar gach rith nua-aimsithe a bhrú ar an gcruach, agus ansin déantar roinnt péirí rith cóngaracha a chumasc go dtí go mbeidh an dá ionradh seo sásta:
///
/// 1. do gach `i` in `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. do gach `i` in `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Cinntíonn na hionróirí gurb é an t-am reatha iomlán *O*(*n*\*log(* n*)) sa chás is measa.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Slices de suas le fad an fháil curtha in eagar ag baint úsáide as sort leanas a chur isteach.
    const MAX_INSERTION: usize = 20;
    // Déantar rianta an-ghearr a shíneadh trí úsáid a bhaint as sórtáil isteach chun an iliomad eilimintí seo a chuimsiú.
    const MIN_RUN: usize = 10;

    // Sórtáil Níl iompar brí ar chineálacha náid-iarrachtaí.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Déantar eagair ghearra a shórtáil i bhfeidhm trí shórtáil isteach chun leithdháiltí a sheachaint.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Leithdháil maolán a úsáid mar chuimhne scratch.Coinnímid an fad 0 ionas gur féidir linn cóipeanna éadomhain d`ábhar `v` a choinneáil ann gan cur isteach ar na dtors atá ag rith ar chóipeanna más `is_less` panics.
    //
    // Nuair a chumasc dhá ritheann curtha in eagar, tá an maolán cóip den rith giorra, a mbeidh i gcónaí fad ar a mhéad `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // D`fhonn ritheann nádúrtha in `v` a aithint, déanaimid é a thrasnú ar gcúl.
    // D`fhéadfadh sé gur cosúil gur cinneadh aisteach é sin, ach smaoinigh ar an bhfíric go dtéann cumasc níos minice sa treo eile (forwards).
    // De réir tagarmharcanna, tá cumasc ar aghaidh beagán níos tapa ná cumasc ar gcúl.
    // Mar fhocal scoir, trí fheidhmíocht a aithint trí thrasnú siar, feabhsaítear an fheidhmíocht.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Faigh an chéad rith nádúrtha eile, agus déan é a aisiompú má tá sé ag dul go docht.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Cuir roinnt eilimintí eile isteach sa rith má tá sé ró-ghearr.
        // Tá sórtáil isteach níos tapa ná sórtáil chumaisc ar sheichimh ghearra, agus mar sin feabhsaíonn sé seo an fheidhmíocht go suntasach.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Brúigh an rith seo ar an gcruach.
        runs.push(Run { start, len: end - start });
        end = start;

        // Cumaisc roinnt péirí ritheann cóngaracha chun na hionróirí a shásamh.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Faoi dheireadh, go díreach caithfidh rith amháin fanacht sa chruach.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Scrúdaíonn sé cruachta na ritheann agus sainaithníonn sé an chéad péire rith eile le cumasc.
    // Go sonrach, má thugtar `Some(r)` ar ais, ciallaíonn sé sin go gcaithfear `runs[r]` agus `runs[r + 1]` a chumasc ina dhiaidh sin.
    // Más ceart don algartam leanúint le rith nua a thógáil ina ionad, tugtar `None` ar ais.
    //
    // Tá TimSort clúiteach as a chur i bhfeidhm fabhtála, mar a thuairiscítear anseo:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Is é an gist an scéal: ní mór dúinn an invariants bhfeidhm ar na ceithre ritheann barr ar an chairn.
    // Ní leor iad a fhorfheidhmiú ar na trí cinn is fearr chun a chinntiú go gcoinneoidh na hionróirí ar feadh *gach* rith sa chruach.
    //
    // Seiceálann an fheidhm seo ionróirí i gceart do na ceithre rith is fearr.
    // Ina theannta sin, má thosaíonn an rith barr ag innéacs 0, éileoidh sé oibríocht chumaisc i gcónaí go dtí go mbeidh an chruach tite go hiomlán, d`fhonn an sórtáil a chur i gcrích.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}