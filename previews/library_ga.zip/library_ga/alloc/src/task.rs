#![stable(feature = "wake_trait", since = "1.51.0")]
//! Cineálacha agus Traits do bheith ag obair le tascanna asynchronous.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Cur i bhfeidhm Airdeallach tasc ar sheiceadóir.
///
/// Is féidir é seo trait a úsáid chun a chruthú [`Waker`].
/// Is féidir le seiceadóir a shainmhíniú cur i bhfeidhm an trait, agus úsáid a bhaint as sin a thógáil Waker chun pas a fháil do na tascanna atá a fhorghníomhófar ar sin seiceadóir.
///
/// Is rogha malartach cuimhne agus eirgeanamaíochta é an trait seo seachas [`RawWaker`] a thógáil.
/// Tacaíonn sé leis an dearadh seiceadóir coitianta ina bhfuil na sonraí a úsáidtear a osclaíonn tasc atá stóráilte in [`Arc`].
/// Ní féidir le roinnt seiceadóirí (go háirithe iad siúd le haghaidh córais leabaithe) an API seo a úsáid, agus sin an fáth go bhfuil [`RawWaker`] ann mar mhalairt ar na córais sin.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Feidhm bhunúsach `block_on` a thógann future agus a ritheann go dtí go mbeidh sí críochnaithe ar an snáithe reatha.
///
/// **Note:** Ceirdeann an sampla seo cruinneas na simplíochta.
/// D`fhonn deadlocks a chosc, beidh ar chur chun feidhme ghrád táirgeachta glaonna idirmheánacha chuig `thread::unpark` a láimhseáil chomh maith le haighneachtaí neadaithe.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Buaiteoir a dhúisíonn an snáithe reatha nuair a ghlaoitear air.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Rith ar future chun críche ar an snáithe atá ann faoi láthair.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Bioráin an future ionas gur féidir é a pholarú.
///     let mut fut = Box::pin(fut);
///
///     // Cruthaigh comhthéacs nua a chur ar aghaidh chuig an future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Rith an future go críochnaithe.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Wake an tasc seo.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Wake an tasc gan ithe an Waker.
    ///
    /// Má thacaíonn seiceadóir le bealach níos saoire le múscailt gan an waker a chaitheamh, ba cheart dó an modh seo a shárú.
    /// De réir réamhshocraithe, clónálann sé an [`Arc`] agus glaonn sé [`wake`] ar an gclón.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SÁBHÁILTEACHT: Tá sé seo toisc go sábháilte constructs raw_waker go sábháilte
        // RawWaker ó Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Úsáidtear an fheidhm phríobháideach seo chun RawWaker a thógáil, seachas
// é seo a imlíne isteach san impl `From<Arc<W>> for RawWaker`, chun a chinntiú nach mbraitheann sábháilteacht `From<Arc<W>> for Waker` ar an seoladh ceart trait, ina ionad sin glaonn an dá impls an fheidhm seo go díreach agus go sainráite.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Incrimint an líon tagartha an stua a Clón air.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Múscail de réir luacha, ag bogadh an Arc isteach i bhfeidhm Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Múscail trí thagairt, timfhilleadh an waker i ManuallyDrop chun nach dtitfidh sé
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Laghdaigh comhaireamh tagartha an Arc ar titim
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}