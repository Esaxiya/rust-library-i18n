//! # Leithdháileadh lárnach Rust agus bailiúcháin leabharlainne
//!
//! Soláthraíonn an leabharlann seo leideanna agus bailiúcháin chliste chun luachanna leithdháilte carn a bhainistiú.
//!
//! De ghnáth ní gá an leabharlann seo, cosúil le libcore, a úsáid go díreach ós rud é go ndéantar a cuid ábhair a athonnmhairiú sa [`std` crate](../std/index.html).
//! De ghnáth ní bheidh Crates a úsáideann an tréith `#![no_std]` ag brath ar `std`, mar sin d`úsáidfidís an crate seo ina ionad.
//!
//! ## Luachanna bosca
//!
//! Is cineál pointeoir cliste é an cineál [`Box`].Ní féidir ach úinéir amháin [`Box`] a bheith ann, agus is féidir leis an úinéir cinneadh a dhéanamh an t-ábhar a mhaireachtáil ar an gcarn.
//!
//! Is féidir an cineál seo a sheoladh i measc snáitheanna go héifeachtúil toisc go bhfuil méid luach `Box` mar an gcéanna le méid pointeora.
//! Is minic a thógtar struchtúir sonraí cosúil le crainn le boscaí mar is minic nach mbíonn ach úinéir amháin ag gach nód, an tuismitheoir.
//!
//! ## Leideanna comhaireamh tagartha
//!
//! Is cineál pointeoir comhaireamh tagartha neamh-snáithe-chomhaireamh é an cineál [`Rc`] atá beartaithe chun cuimhne a roinnt laistigh de snáithe.
//! Fillteann pointeoir [`Rc`] cineál, `T`, agus ní cheadaíonn sé ach rochtain ar `&T`, tagairt roinnte.
//!
//! Tá an cineál seo úsáideach nuair a bhíonn suaiteacht oidhreachta (mar shampla [`Box`] a úsáid) róshrianta d`iarratas, agus is minic a bhíonn sé péireáilte leis na cineálacha [`Cell`] nó [`RefCell`] d`fhonn sóchán a cheadú.
//!
//!
//! ## Leideanna tagartha adamhach a chomhaireamh
//!
//! Is é an cineál [`Arc`] coibhéis threadsafe den chineál [`Rc`].Soláthraíonn sé an fheidhmiúlacht chéanna uile de [`Rc`], ach amháin go n-éilíonn sé go bhfuil an cineál `T` atá ann inroinnte.
//! Ina theannta sin, tá [`Arc<T>`][`Arc`] féin inseolta cé nach bhfuil [`Rc<T>`][`Rc`].
//!
//! Ceadaíonn an cineál seo maidir le rochtain chomhroinnte leis na sonraí atá, agus tá sé péireáilte minic le primitives sioncrónaithe nós mutexes sóchán na n-acmhainní comhroinnte a cheadú.
//!
//! ## Collections
//!
//! Sainmhínítear cur chun feidhme na struchtúr sonraí ilchuspóra is coitianta sa leabharlann seo.Déantar iad a athonnmhairiú tríd an [standard collections library](../std/collections/index.html).
//!
//! ## Comhéadain carn
//!
//! Sainmhíníonn an modúl [`alloc`](alloc/index.html) an comhéadan leibhéal íseal leis an leithdháilteoir domhanda réamhshocraithe.Níl sé comhoiriúnach leis an API leithdháilte libc.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// Go teicniúil, fabht é seo i rustdoc: feiceann rustdoc go bhfuil an cháipéisíocht ar bhloic `#[lang = slice_alloc]` do `&[T]`, a bhfuil cáipéisíocht ann freisin a úsáideann an ghné seo in `core`, agus a éiríonn as a mheabhair nach bhfuil an geata gné cumasaithe.
// Go hidéalach, ní bheadh sé a sheiceáil don gheata gné d'docs ó crates eile, ach ós rud é is féidir é seo le feiceáil ach amháin le haghaidh míreanna lang, ní chuireann sé cosúil go fiú a shocrú.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// Lig tástáil a dhéanamh ar an leabharlann seo

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// Modúl le Macraí inmheánacha a úsáideann modúil eile (riachtanais atá le háireamh sula modúil eile).
#[macro_use]
mod macros;

// Leideanna curtha ar fáil do straitéisí leithdháilte leibhéal íseal

pub mod alloc;

// Cineálacha primitive ag baint úsáide as na carnáin thuas

// Is gá an mod ó `boxed.rs` a shainiú go coinníollach chun dúbailt na n-ítimí lang a sheachaint agus an cfg tástála á thógáil isteach;ach ní mór freisin ligean don chód dearbhuithe `use boxed::Box;` a bheith acu.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}