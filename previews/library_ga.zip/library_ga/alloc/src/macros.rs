/// Cruthaíonn sé [`Vec`] ina bhfuil na hargóintí.
///
/// `vec!` ceadaíonn `Vec`s a shainiú leis an gcomhréir chéanna le nathanna eagair.
/// Tá dhá chineál an macra:
///
/// - Cruthaigh [`Vec`] ina bhfuil liosta ar leith na n-eilimintí:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Cruthaigh [`Vec`] ó gné ar leith agus méid:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Tabhair faoi deara, murab ionann agus nathanna eagar, tacaíonn an chomhréir seo leis na heilimintí go léir a chuireann [`Clone`] i bhfeidhm agus ní gá go mbeadh líon na n-eilimintí seasmhach.
///
/// Úsáidfidh sé seo `clone` chun slonn a mhacasamhlú, mar sin ba chóir a bheith cúramach agus é seo á úsáid le cineálacha a bhfuil cur chun feidhme `Clone` neamhchaighdeánach acu.
/// Mar shampla, `vec![Rc::new(1);5] cruthóidh `vector de chúig thagairt don luach slánuimhir boscaithe céanna, ní cúig thagairt a dhíríonn ar shlánuimhreacha a bhfuil bosca neamhspleách orthu.
///
///
/// Chomh maith leis sin, tabhair faoi deara go gceadaítear `vec![expr; 0]`, agus go dtáirgeann sé vector folamh.
/// Déanfaidh sé seo meastóireacht fós ar `expr`, áfach, agus scaoilfidh sé an luach a bheidh mar thoradh air láithreach, mar sin bí aireach ar na fo-iarsmaí.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): le cfg(test) níl an modh bunúsach `[T]::into_vec`, atá riachtanach don macra-sainmhíniú seo, ar fáil.
// Ina áit sin bain úsáid as an bhfeidhm `slice::into_vec` nach bhfuil ar fáil ach le cfg(test) NB féach an modúl slice::hack in slice.rs chun tuilleadh faisnéise a fháil
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Cruthaíonn sé `String` ag baint úsáide as idirshuíomh nathanna runtime.
///
/// Is é an chéad argóint a fhaigheann `format!` ná sreangán formáide.Caithfidh sé seo a bheith liteartha sreang.Tá cumhacht na sreinge formáidithe sna `{}` s atá ann.
///
/// Cuirtear paraiméadair bhreise a chuirtear ar aghaidh chuig `format!` in ionad na `{}` s laistigh den sreang formáidithe san ord a thugtar mura n-úsáidtear paraiméadair ainmnithe nó suímh;féach [`std::fmt`] le haghaidh tuilleadh faisnéise.
///
///
/// Úsáid choitianta le haghaidh `format!` is ea comhchaitseáil agus idirshuíomh teaghráin.
/// Is é an coinbhinsiún céanna a úsáidtear le [`print!`] agus [`write!`] Macraí, ag brath ar an gceann scríbe atá beartaithe na sreinge.
///
/// Chun luach amháin a thiontú go sreang, úsáid an modh [`to_string`].Úsáidfidh sé seo formáidiú [`Display`] trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics má chuireann earráid formáidiú trait earráid ar ais.
/// Léiríonn sé seo cur i bhfeidhm mícheart ós rud é nach gcuireann `fmt::Write for String` earráid ar ais riamh.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Cuir nód AST i bhfeidhm chun slonn chun diagnóisic a fheabhsú i suíomh patrún.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}