//! Scuaine tosaíochta curtha i bhfeidhm le carn dénártha.
//!
//! Tá castacht ama *O*(log(*n*)) ag an eilimint is mó a chur isteach agus a popping.
//! Is é *O*(1) an eilimint is mó a sheiceáil.Is féidir vector a thiontú go carn dénártha a dhéanamh in áit, agus tá castacht *O*(*n*) aige.
//! Is féidir carn dénártha a thiontú go vector sórtáilte in áit, rud a fhágann gur féidir é a úsáid le haghaidh heapsort in-áit *O*(*n*\*log(* n*)).
//!
//! # Examples
//!
//! Is sampla níos mó é seo a chuireann [Dijkstra's algorithm][dijkstra] i bhfeidhm chun an [shortest path problem][sssp] a réiteach ar [directed graph][dir_graph].
//!
//! Taispeánann sé conas [`BinaryHeap`] a úsáid le cineálacha saincheaptha.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Braitheann an scuaine tosaíochta ar `Ord`.
//! // Cuir an trait i bhfeidhm go sainráite ionas go mbeidh an scuaine ina charn mion in ionad uas-gcarn.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Tabhair faoi deara go smeach muid an t-ordú ar chostais.
//!         // I gcás comhionannas vótaí déanaimid comparáid idir seasaimh, is gá an chéim seo chun feidhmiúcháin `PartialEq` agus `Ord` a dhéanamh comhsheasmhach.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` is gá a chur i bhfeidhm freisin.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Déantar gach nód a léiriú mar `usize`, le cur chun feidhme níos giorra.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // An algartam cosáin is giorra ag Dijkstra.
//!
//! // Tosaigh ag `start` agus bain úsáid as `dist` chun an fad is giorra reatha do gach nód a rianú.Níl an cur chun feidhme seo éifeachtach ó thaobh cuimhne de toisc go bhféadfadh sé nóid dhúblacha a fhágáil sa scuaine.
//! //
//! // Úsáideann sé `usize::MAX` freisin mar luach sentinel, chun é a chur i bhfeidhm níos simplí.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [nód]=an t-achar is giorra reatha ó `start` go `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Táimid ag `start`, gan costas nialasach
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Scrúdaigh an teorainn le nóid ar chostas níos ísle ar dtús (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Nó d`fhéadfaimis a bheith tar éis teacht ar na cosáin is giorra go léir
//!         if position == goal { return Some(cost); }
//!
//!         // Tábhachtach mar b`fhéidir go bhfuaireamar bealach níos fearr cheana féin
//!         if cost > dist[position] { continue; }
//!
//!         // Maidir le gach nód is féidir linn a bhaint amach, féach an féidir linn bealach a fháil le costas níos ísle ag dul tríd an nód sin
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Má tá, é a chur leis an teorainn agus leanúint ar aghaidh
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Scíth a ligean, tá bealach níos fearr aimsithe againn anois
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Ní féidir an sprioc a bhaint amach
//!     None
//! }
//!
//! fn main() {
//!     // Is é seo an graf treoraithe a úsáidfimid.
//!     // Freagraíonn uimhreacha na nód do na stáit éagsúla, agus samhlaíonn na meáchain edge an costas a bhaineann le bogadh ó nód amháin go ceann eile.
//!     //
//!     // Tabhair faoi deara go bhfuil na himill aon-bhealach.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Léirítear an graf mar liosta aclaíochta ina bhfuil liosta de na himill atá ag dul as gach innéacs, a fhreagraíonn do luach nód.
//!     // Roghnaithe as a éifeachtúlacht.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Nód 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Nód 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Nód 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Nód 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Nód 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Scuaine tosaíochta curtha i bhfeidhm le carn dénártha.
///
/// Uas-gcarn a bheidh anseo.
///
/// Is botún loighic é mír a mhodhnú sa chaoi is go n-athraíonn ordú na míre i gcoibhneas le haon earra eile, mar a chinneann an `Ord` trait, fad a bhíonn sí sa gcarn.
///
/// De ghnáth ní féidir é seo a dhéanamh ach trí `Cell`, `RefCell`, stát domhanda, I/O, nó cód neamhshábháilte.
/// Ní shonraítear an t-iompar a eascraíonn as earráid loighic den sórt sin, ach ní bheidh iompar neamhshainithe mar thoradh air.
/// D`fhéadfadh panics, torthaí míchearta, ginmhilleadh, sceitheadh cuimhne agus neamh-fhoirceannadh a bheith san áireamh anseo.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Ligeann tátal cineáil dúinn síniú sainráite cineáil a fhágáil ar lár (a bheadh `BinaryHeap<i32>` sa sampla seo).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Is féidir linn peek a úsáid chun breathnú ar an gcéad earra eile sa gcarn.
/// // Sa chás seo, níl aon earraí ann fós agus mar sin ní fhaighimid aon cheann.
/// assert_eq!(heap.peek(), None);
///
/// // Cuirimis roinnt scóir leis ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Anois taispeánann peek an rud is tábhachtaí sa gcarn.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Is féidir linn fad carn a sheiceáil.
/// assert_eq!(heap.len(), 3);
///
/// // Is féidir linn na míreanna sa gcarn a athrá, cé go gcuirtear ar ais iad in ord randamach.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Má dhéanaimid na scóir seo a popáil ina ionad sin, ba cheart dóibh teacht ar ais in ord.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Is féidir linn soiléir ar an gcarn de aon ítimí eile.
/// heap.clear();
///
/// // Ba chóir go mbeadh an gcarn folamh anois.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Is féidir ceachtar `std::cmp::Reverse` nó cur chun feidhme saincheaptha `Ord` a úsáid chun mion-gcarn a dhéanamh de `BinaryHeap`.
/// Fágann sé sin go dtugann `heap.pop()` an luach is lú ar ais in ionad an luach is mó.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Luachanna fillte in `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Má dhéanaimid na scóir seo a phiocadh anois, ba cheart dóibh teacht ar ais san ord droim ar ais.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Castacht ama
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Is costas ionchais an luach do `push`;tugann an doiciméadacht modhanna anailís níos mionsonraithe.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Struchtúr ag timfhilleadh tagairt inathraithe don earra is mó ar `BinaryHeap`.
///
///
/// Cruthaítear an `struct` seo leis an modh [`peek_mut`] ar [`BinaryHeap`].
/// Féach a dhoiciméadú le haghaidh tuilleadh.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // SÁBHÁILTEACHT: Ní chuirtear PeekMut ar an toirt ach le haghaidh carnáin nach bhfuil folamh.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SÁBHÁILTE: Ní chuirtear PeekMut ar an toirt ach le haghaidh carnáin nach bhfuil folamh
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SÁBHÁILTE: Ní chuirtear PeekMut ar an toirt ach le haghaidh carnáin nach bhfuil folamh
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Bain an luach scafa ón gcarn agus seol ar ais é.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Cruthaíonn `BinaryHeap<T>` folamh.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Cruthaíonn sé `BinaryHeap` folamh mar uas-gcarn.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Cruthaíonn sé `BinaryHeap` folamh le cumas sonrach.
    /// Déanann sé seo dóthain cuimhne a leithdháileadh ar eilimintí `capacity`, ionas nach gá an `BinaryHeap` a ath-leithdháileadh go dtí go mbeidh go leor luachanna ann ar a laghad.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Seoltar tagairt inathraithe ar ais don earra is mó sa gcarn dénártha, nó `None` má tá sé folamh.
    ///
    /// Note: Má sceitear an luach `PeekMut`, d`fhéadfadh go mbeadh an gcarn i riocht neamhréireach.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Castacht ama
    ///
    /// Má dhéantar an t-earra a mhodhnú ansin is é *O*(log(*n*)) an chastacht ama is measa, nó *O*(1) is ea é.
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Bain an t-earra is mó ón gcarn dénártha agus seol ar ais é, nó `None` má tá sé folamh.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Castacht ama
    ///
    /// Is é *O*(log(*n*)) an costas cáis is measa de `pop` ar charn ina bhfuil eilimintí *n*.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // SÁBHÁILTEACHT: Ciallaíonn !self.is_empty() go bhfuil self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Brúigh mír ar an gcarn dénártha.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Castacht ama
    ///
    /// Is é an costas a bhfuil súil leis de `push`, ar an meán thar gach ordú féideartha de na heilimintí atá á mbrú, agus os cionn líon mór brú, ná *O*(1).
    ///
    /// Is é seo an méadracht costais is suntasaí nuair a bhíonn eilimintí nach bhfuil * cheana féin in aon phatrún sórtáilte á bhrú.
    ///
    /// Díscaoileann an chastacht ama má dhéantar eilimintí a bhrú in ord ardaitheach den chuid is mó.
    /// Sa chás is measa, déantar eilimintí a bhrú in ord ardaitheach ardaitheach agus is é an costas amúchta in aghaidh an bhrú ná *O*(log(*n*)) i gcoinne carn ina bhfuil eilimintí *n*.
    ///
    /// Is é an costas cáis is measa a bhaineann le glao *aonair* go `push` ná *O*(*n*).Tarlaíonn an cás is measa nuair a ídítear an toilleadh agus nuair a bhíonn méid athraithe ag teastáil.
    /// Amúchtar an costas méide sna figiúirí roimhe seo.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // SÁBHÁILTEACHT: Ó bhrúigh muid mír nua ciallaíonn sé sin
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Itheann sé an `BinaryHeap` agus cuireann sé vector ar ais in ord sórtáilte (ascending).
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // SÁBHÁILTEACHT: Téann `end` ó `self.len() - 1` go 1 (an dá cheann san áireamh),
            //  mar sin is innéacs bailí é i gcónaí chun rochtain a fháil air.
            //  Tá sé sábháilte rochtain a fháil ar innéacs 0 (ie `ptr`), mar gheall ar
            //  1 <=deireadh <self.len(), rud a chiallaíonn self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // SÁBHÁILTEACHT: Téann `end` ó `self.len() - 1` go 1 (an dá cheann san áireamh) mar sin:
            //  0 <1 <=deireadh <= self.len(), 1 <self.len() Rud a chiallaíonn 0 <deireadh agus deireadh <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Úsáideann cur i bhfeidhm sift_up agus sift_down bloic neamhshábháilte d`fhonn eilimint a bhogadh amach as an vector (ag fágáil poll ina dhiaidh), aistriú feadh na cinn eile agus an eilimint bainte a aistriú ar ais isteach sa vector ag suíomh deiridh an phoill.
    //
    // Úsáidtear an cineál `Hole` chun é seo a léiriú, agus déan cinnte go líontar an poll ar ais ag deireadh a raon feidhme, fiú ar panic.
    // Laghdaíonn úsáid poll an fachtóir tairiseach i gcomparáid le babhtálacha a úsáid, a mbíonn dhá oiread gluaiseachtaí i gceist leis.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Caithfidh an té atá ag glaoch ráthaíocht a thabhairt go bhfuil `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Tóg amach an luach ag `pos` agus cruthaigh poll.
        // SÁBHÁILTEACHT: Ráthaíonn an té atá ag glaoch go bhfuil pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // SÁBHÁILTEACHT: hole.pos()> tús>=0, rud a chiallaíonn hole.pos()> 0
            //  agus mar sin ní féidir le hole.pos(), 1 cur faoi.
            //  Ráthaíonn sé seo don tuismitheoir <hole.pos() mar sin is innéacs bailí é agus freisin!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // SÁBHÁILTEACHT: Mar an gcéanna thuas
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Tóg eilimint ag `pos` agus bog síos an gcarn é, cé go bhfuil a leanaí níos mó.
    ///
    ///
    /// # Safety
    ///
    /// Caithfidh an té atá ag glaoch ráthaíocht a thabhairt go bhfuil `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // SÁBHÁILTEACHT: Ráthaíonn an té atá ag glaoch go bhfuil pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Lúb invariant: leanbh==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // déan comparáid leis an gceann is mó den dá leanbh SÁBHÁILTEACHT: leanbh <deireadh, 1 <self.len() agus leanbh + 1 <deireadh <= self.len(), mar sin is innéacsanna bailí iad.
            //
            //  leanbh==2 *hole.pos() + 1!= hole.pos() agus leanbh + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: D`fhéadfadh 2 *hole.pos() + 1 nó 2* hole.pos() + 2 cur thar maoil más ZST é T.
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // má táimid cheana féin in ord, stad.
            // SÁBHÁILTEACHT: is é an leanbh anois an sean-leanbh nó an sean-leanbh + 1
            //  Chruthaigh muid cheana go bhfuil an dá cheann <self.len() agus!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // SÁBHÁILTEACHT: mar an gcéanna thuas.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // SÁBHÁILTEACHT: &&ciorcad gearr, rud a chiallaíonn go bhfuil sa
        //  an dara coinníoll tá sé fíor cheana féin go==deireadh leanbh, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // SÁBHÁILTEACHT: cruthaítear gur innéacs bailí é an leanbh cheana féin agus
            //  leanbh==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Caithfidh an té atá ag glaoch ráthaíocht a thabhairt go bhfuil `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // SÁBHÁILTEACHT: ráthaíonn an té atá ag glaoch pos <len agus
        //  ar ndóigh len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Tóg eilimint ag `pos` agus bog í an bealach ar fad síos an gcarn, ansin sift suas go dtí a suíomh.
    ///
    ///
    /// Note: Tá sé seo níos tapa nuair is eol go bhfuil an eilimint mór/ba chóir go mbeadh sí níos gaire don bhun.
    ///
    /// # Safety
    ///
    /// Caithfidh an té atá ag glaoch ráthaíocht a thabhairt go bhfuil `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // SÁBHÁILTEACHT: Ráthaíonn an té atá ag glaoch go bhfuil pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Lúb invariant: leanbh==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // SÁBHÁILTEACHT: leanbh <deireadh, 1 <self.len() agus
            //  leanbh + 1 <deireadh <= self.len(), mar sin go bhfuil siad innéacsanna bailí.
            //  leanbh==2 *hole.pos() + 1!= hole.pos() agus leanbh + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: D`fhéadfadh 2 *hole.pos() + 1 nó 2* hole.pos() + 2 cur thar maoil más ZST é T.
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // SÁBHÁILTEACHT: Mar an gcéanna thuas
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // SÁBHÁILTEACHT: leanbh==deireadh, 1 <self.len(), mar sin is innéacs bailí é
            //  agus leanbh==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // SÁBHÁILTEACHT: is é pos an seasamh sa pholl agus cruthaíodh cheana é
        //  a bheith ina innéacs bailí.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // SÁBHÁILTEACHT: tosaíonn n ó self.len()/2 agus téann sé síos go dtí 0.
            //  Is é an t-aon chás nuair! (N <self.len()) ná má self.len() ==0, ach tá riocht na lúibe ag cur as dó.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Bogann sé gach gné de `other` go `self`, ag fágáil `other` folamh.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` tógann sé oibríochtaí O(len1 + len2) agus thart ar 2 *(len1 + len2) comparáidí sa chás is measa agus tógann `extend` oibríochtaí O(len2* log(len1)) agus thart ar chomparáidí 1 *len2* log_2(len1) sa chás is measa, ag glacadh le len1>= len2.
        // Maidir le heaps níos mó, an pointe crossover thuilleadh a leanas an réasúnaíocht agus bhí sé meáite empirically.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Seoltar atriall ar ais a ghnóthaíonn eilimintí in ord carn.
    /// Baintear na heilimintí aisghafa ón gcarn bunaidh.
    /// Bainfear na heilimintí eile nuair a bheidh siad in ord carn.
    ///
    /// Note:
    /// * `.drain_sorted()` is *O*(*n*\*log(* n*)); i bhfad níos moille ná `.drain()`.
    ///   Ba cheart duit an dara ceann a úsáid i bhformhór na gcásanna.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // baintear na heilimintí go léir in ord carn
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Ní choinníonn sé ach na heilimintí a shonraíonn an tuar.
    ///
    /// Is é sin le rá, bain na heilimintí `e` go léir ionas go bhfillfidh `f(&e)` `false`.
    /// Tugtar cuairt ar na heilimintí in ord neamh-eagraithe (agus neamhshonraithe).
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // ná coinnigh ach uimhreacha cothrom
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Seoltar atriall ar ais ag tabhairt cuairte ar na luachanna uile sa vector bunúsach, in ord treallach.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Priontáil 1, 2, 3, 4 in ord treallach
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Seoltar atriall ar ais a ghnóthaíonn eilimintí in ord carn.
    /// Ídíonn an modh seo an carn bunaidh.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Filleann sé an rud is mó sa gcarn dénártha, nó `None` má tá sé folamh.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Castacht ama
    ///
    /// Is é an costas *O*(1) sa chás is measa.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Filleann sé líon na n-eilimintí is féidir leis an gcarn dénártha a shealbhú gan ath-leithdháileadh.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Forchoimeádann sé an acmhainn íosta chun go díreach `additional` níos mó eilimintí a chur isteach sa `BinaryHeap` a thugtar.
    /// Ní dhéanann sé aon rud más leor an acmhainn cheana féin.
    ///
    /// Tabhair faoi deara go bhféadfaidh an leithdháilteoir níos mó spáis a thabhairt don bhailiúchán ná mar a iarrann sé.
    /// Mar sin ní féidir a bheith ag brath ar acmhainn a bheith an-bheag agus is féidir.
    /// Is fearr [`reserve`] má tá súil le cuir isteach future.
    ///
    /// # Panics
    ///
    /// Panics má sháraíonn an acmhainn nua `usize`.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Forchoimeádann sé acmhainn chun `additional` ar a laghad níos mó eilimintí a chur isteach sa `BinaryHeap`.
    /// Féadfaidh an bailiúchán níos mó spáis a chur in áirithe chun ath-leithdháileadh minic a sheachaint.
    ///
    /// # Panics
    ///
    /// Panics má sháraíonn an acmhainn nua `usize`.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Scriosann sé an oiread acmhainne breise agus is féidir.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Scriosann sé toilleadh le teorainn níos ísle.
    ///
    /// Fanfaidh an toilleadh ar a laghad chomh mór leis an fad agus an luach a sholáthraítear.
    ///
    ///
    /// Má tá an toilleadh reatha níos lú ná an teorainn is ísle, is rogha eile é seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Itheann sé an `BinaryHeap` agus cuireann sé an vector bunúsach ar ais in ord treallach.
    ///
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // An mbeidh sé i gcló in ord éigin
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Filleann sé fad an gcarn dénártha.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Seiceálacha an bhfuil an carn dénártha folamh.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Glanann an carn dénártha, ag atreorú ar ais thar na heilimintí a baineadh.
    ///
    /// Baintear na heilimintí in ord treallach.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Drops gach earra ón gcarn dénártha.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Is ionann poll agus poll i slice ie, innéacs gan luach bailí (toisc gur aistríodh é nó gur dúbraíodh é).
///
/// Ag titim, athshlánóidh `Hole` an slice tríd an suíomh poll a líonadh leis an luach a baineadh ar dtús.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Cruthaigh `Hole` nua ag innéacs `pos`.
    ///
    /// Neamhshábháilte toisc go gcaithfidh pos a bheith laistigh den slice sonraí.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SÁBHÁILTE: ba chóir go mbeadh pos taobh istigh den slice
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Tugann sé tagairt don eilimint a baineadh ar ais.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Filleann tagairt don eilimint ag `index`.
    ///
    /// Neamhshábháilte toisc go gcaithfidh an t-innéacs a bheith laistigh den slice sonraí agus gan a bheith cothrom le pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Bog poll go suíomh nua
    ///
    /// Neamhshábháilte toisc go gcaithfidh an t-innéacs a bheith laistigh den slice sonraí agus gan a bheith cothrom le pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // líon an poll arís
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Atriallóir thar eilimintí `BinaryHeap`.
///
/// Tá an `struct` seo cruthaithe ag [`BinaryHeap::iter()`].
/// Féach a dhoiciméadú le haghaidh tuilleadh.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Bain i bhfabhar `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Atreoraitheoir úinéireachta ar eilimintí `BinaryHeap`.
///
/// Cruthaítear an `struct` seo le [`BinaryHeap::into_iter()`] (arna sholáthar ag an `IntoIterator` trait).
/// Féach a dhoiciméadú le haghaidh tuilleadh.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Atreoraitheoir draenála thar eilimintí `BinaryHeap`.
///
/// Tá an `struct` seo cruthaithe ag [`BinaryHeap::drain()`].
/// Féach a dhoiciméadú le haghaidh tuilleadh.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Atreoraitheoir draenála thar eilimintí `BinaryHeap`.
///
/// Tá an `struct` seo cruthaithe ag [`BinaryHeap::drain_sorted()`].
/// Féach a dhoiciméadú le haghaidh tuilleadh.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Bain eilimintí carn in ord carn.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Tiontaíonn `Vec<T>` ina `BinaryHeap<T>`.
    ///
    /// Tarlaíonn an tiontú seo i bhfeidhm, agus tá castacht ama *O*(*n*) aige.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Tiontaíonn `BinaryHeap<T>` ina `Vec<T>`.
    ///
    /// Ní éilíonn an tiontú seo aon ghluaiseacht ná leithdháileadh sonraí, agus tá castacht ama leanúnach aige.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Cruthaíonn sé iteoir íditheach, is é sin, ceann a ghluaiseann gach luach as an gcarn dénártha in ord treallach.
    /// Ní féidir an carn dénártha a úsáid tar éis é seo a ghlaoch.
    ///
    /// # Examples
    ///
    /// Úsáid bhunúsach:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Priontáil 1, 2, 3, 4 in ord treallach
    /// for x in heap.into_iter() {
    ///     // tá cineál i32 ag x, ní &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}