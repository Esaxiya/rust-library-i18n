use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Stocann sé nód a d`fhéadfadh a bheith gann go leor trí chumasc le siblín nó goid uaidh.
    /// Má éiríonn leis ach ar chostas an nód tuismitheora a chrapadh, filleann sé an nód tuismitheora craptha sin.
    /// Filleann `Err` más fréamh folamh an nód.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Déanann sé nód a d'fhéadfadh a bheith gann a stocáil, agus má laghdaíonn sé sin a nód tuismitheora, déanann sé an tuismitheoir a stocáil arís agus arís eile.
    /// Filleann `true` má shocraigh sé an crann, `false` mura bhféadfadh sé toisc go raibh an nód fréimhe folamh.
    ///
    /// Níl an modh seo ag súil go mbeidh sinsear gann go leor cheana féin ar iontráil agus panics má thagann sé ar sinsear folamh.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// Bain leibhéil folamh ar an mbarr, ach coimeádann sé duilleog folamh má tá an crann iomlán folamh.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// Stoic suas nó cumasc ar shiúl nóid ar bith ar theorainn cheart an chrainn.
    /// Caithfidh eilimintí MIN_LEN ar a laghad a bheith ag na nóid eile, iad siúd nach iad an fhréamh ná an edge is ceart.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// Clón siméadrach `fix_right_border`.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// Stoc suas nóid ar bith ar theorainn cheart an chrainn.
    /// Caithfidh na nóid eile, iad siúd nach iad an fhréamh ná an edge is ceart, a bheith ullamh chun suas le heilimintí MIN_LEN a ghoid.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // Seiceáil an bhfuil an leanbh ceart-gann.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // Caithfimid goid.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // Téigh níos faide síos.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Déanann sé an leanbh ar chlé a stocáil, ag glacadh leis nach bhfuil an leanbh ceart gann, agus soláthraíonn sé gné bhreise chun a leanaí a chumasc ar a seal gan a bheith gann.
    ///
    /// Filleann an leanbh ar chlé.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` chun readjust a sheachaint má tharlaíonn cumasc ar an gcéad leibhéal eile.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// Déanann sé an leanbh ceart a stocáil, ag glacadh leis nach bhfuil an leanbh clé gann, agus soláthraíonn sé gné bhreise chun a leanaí a chumasc ar a seal gan a bheith gann.
    ///
    /// Tuairisceáin cibé áit a chríochnaigh an leanbh ceart.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` chun readjust a sheachaint má tharlaíonn cumasc ar an gcéad leibhéal eile.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}