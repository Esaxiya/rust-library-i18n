use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Tógann sé coibhéis dhochorraithe eile den raon céanna amach go sealadach.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Aimsíonn sé na himill duille ar leith atá ag teorannú raon sonraithe i gcrann.
    /// Filleann péire Láimhseálann éagsúla ar ais sa chrann céanna nó péire roghanna folmha.
    ///
    /// # Safety
    ///
    /// Mura `Immut` é `BorrowType`, ná bain úsáid as na láimhseálacha dúblacha chun cuairt a thabhairt ar an KV céanna faoi dhó.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Coibhéiseach le `(root1.first_leaf_edge(), root2.last_leaf_edge())` ach níos éifeachtaí.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Aimsíonn sé an péire imill duille ag teorannú raon sonrach i gcrann.
    ///
    /// Is é an toradh bhrí ach amháin má tá an crann de réir eochair, cosúil leis an crann i `BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // SÁBHÁILTEACHT: tá ár gcineál iasachta dochorraithe.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Aimsíonn sé an péire imill duille ag teorannú crann iomlán.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Roinntear tagairt uathúil i péire imill duille ag teorannú raon sonraithe.
    /// Is é an toradh tagairtí neamh-uathúla lena gceadaítear sóchán (some), a chaithfear a úsáid go cúramach.
    ///
    /// Is é an toradh bhrí ach amháin má tá an crann de réir eochair, cosúil leis an crann i `BTreeMap`.
    ///
    ///
    /// # Safety
    /// Ná húsáid na láimhseálacha dúblacha chun cuairt a thabhairt ar an KV céanna faoi dhó.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Roinntear tagairt uathúil i péire imill duille ag teorannú raon iomlán an chrainn.
    /// Is tagairtí neamh-uathúla iad na torthaí a cheadaíonn sóchán (luachanna amháin), mar sin caithfear iad a úsáid go cúramach.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Déanaimid an fréamh NodeRef a mhacasamhlú anseo-ní thabharfaimid cuairt ar an KV céanna faoi dhó, agus ní dhéanfaimid tagairtí luacha forluiteacha go deo.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Roinntear tagairt uathúil i péire imill duille ag teorannú raon iomlán an chrainn.
    /// Is tagairtí neamh-uathúla iad na torthaí a cheadaíonn sóchán ollmhór millteach, mar sin caithfear iad a úsáid go cúramach.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Déanaimid an fréamh NodeRef a mhacasamhlú anseo-ní dhéanfaimid rochtain air go deo ar bhealach a dhéanann forluí ar thagairtí a fhaightear ón bhfréamh.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Nuair a thugtar láimhseáil duille edge air, filleann [`Result::Ok`] le láimhseáil chuig an KV comharsanachta ar an taobh dheis, atá sa nód duille céanna nó i nód sinsear.
    ///
    /// Más é an duilleog edge an ceann deireanach sa chrann, filleann [`Result::Err`] leis an nód fréimhe.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Nuair a thugtar láimhseáil duille edge air, filleann [`Result::Ok`] le láimhseáil chuig an KV comharsanachta ar an taobh clé, atá sa nód duille céanna nó i nód sinsear.
    ///
    /// Más é an duilleog edge an chéad cheann sa chrann, filleann [`Result::Err`] leis an nód fréimhe.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Nuair a thugtar láimhseáil inmheánach edge air, filleann [`Result::Ok`] le láimhseáil chuig an KV comharsanachta ar an taobh dheis, atá sa nód inmheánach céanna nó i nód sinsear.
    ///
    /// Más é an edge inmheánach an ceann deireanach sa chrann, filleann [`Result::Err`] leis an nód fréimhe.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Nuair a thugtar láimhseáil duille edge isteach i gcrann atá ag fáil bháis, filleann an chéad duilleog eile edge ar an taobh dheis, agus an péire eochairluacha eatarthu, atá sa nód duille céanna, i nód sinsear, nó nach bhfuil ann.
    ///
    ///
    /// Déanann an modh seo tuiscint ar aon node(s) a shroicheann sé deireadh.
    /// Tugann sé seo le tuiscint mura mbeidh péire eochairluach níos mó ann, go mbeidh an chuid eile den chrann intuigthe agus nach mbeidh aon rud le filleadh.
    ///
    /// # Safety
    /// Ní féidir nár chuir an comhghleacaí `deallocating_next_back` an edge a tugadh ar ais roimhe seo.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Nuair a thugtar láimhseáil duille edge isteach i gcrann atá ag fáil bháis, filleann an chéad duilleog eile edge ar an taobh clé, agus an péire eochairluacha eatarthu, atá sa nód duille céanna, i nód sinsear, nó nach bhfuil ann.
    ///
    ///
    /// Déanann an modh seo tuiscint ar aon node(s) a shroicheann sé deireadh.
    /// Tugann sé seo le tuiscint mura mbeidh péire eochairluach níos mó ann, go mbeidh an chuid eile den chrann intuigthe agus nach mbeidh aon rud le filleadh.
    ///
    /// # Safety
    /// Ní féidir nár chuir an comhghleacaí `deallocating_next` an edge a tugadh ar ais roimhe seo.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Déanann carn nóid a dhí-leithdháileadh ón duilleog suas go dtí an fhréamh.
    /// Is é seo an t-aon bhealach chun an chuid eile de chrann a thuiscint tar éis do `deallocating_next` agus `deallocating_next_back` a bheith ag cnagadh ar dhá thaobh an chrainn, agus an edge céanna a bhualadh.
    /// Toisc nach bhfuil sé beartaithe é a ghlaoch ach nuair a bheidh na heochracha agus na luachanna uile curtha ar ais, ní dhéantar aon ghlanadh ar aon cheann de na heochracha nó na luachanna.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Bogann an láimhseáil duille edge go dtí an chéad duilleog eile edge agus tugann sé tagairtí don eochair agus don luach eatarthu.
    ///
    ///
    /// # Safety
    /// Ní mór go mbeadh KV eile sa treo a thaistealaítear.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Bogann sé an láimhseáil duille edge go dtí an duilleog roimhe seo edge agus cuireann sé tagairtí ar ais don eochair agus don luach eatarthu.
    ///
    ///
    /// # Safety
    /// Ní mór go mbeadh KV eile sa treo a thaistealaítear.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Bogann an láimhseáil duille edge go dtí an chéad duilleog eile edge agus tugann sé tagairtí don eochair agus don luach eatarthu.
    ///
    ///
    /// # Safety
    /// Ní mór go mbeadh KV eile sa treo a thaistealaítear.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Tá sé níos tapa é seo a dhéanamh, de réir tagarmharcanna.
        kv.into_kv_valmut()
    }

    /// Bogann sé an láimhseáil duille edge go dtí an duilleog roimhe seo agus cuireann sé tagairtí ar ais don eochair agus don luach eatarthu.
    ///
    ///
    /// # Safety
    /// Ní mór go mbeadh KV eile sa treo a thaistealaítear.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Tá sé níos tapa é seo a dhéanamh, de réir tagarmharcanna.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Bogann sé an láimhseáil duille edge go dtí an chéad duilleog eile edge agus cuireann sé an eochair agus an luach eatarthu ar ais, ag tuiscint aon nód a fhágtar ina dhiaidh agus an edge comhfhreagrach ina nód tuismitheora ag crochadh.
    ///
    /// # Safety
    /// - Ní mór go mbeadh KV eile sa treo a thaistealaítear.
    /// - Níor chuir an comhghleacaí `next_back_unchecked` an KV sin ar ais roimhe seo ar aon chóip de na láimhseálacha a bhí á n-úsáid chun an crann a thrasnú.
    ///
    /// Is é an t-aon bhealach sábháilte chun dul ar aghaidh leis an láimhseáil nuashonraithe ná é a chur i gcomparáid, é a ligean anuas, an modh seo a ghlaoch arís faoi réir a choinníollacha sábháilteachta, nó glaoch ar mhacasamhail `next_back_unchecked` faoi réir a choinníollacha sábháilteachta.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Bogann sé an láimhseáil duille edge go dtí an duilleog roimhe seo edge agus cuireann sé an eochair agus an luach eatarthu ar ais, ag tuiscint aon nód a fágadh ar lár agus an edge comhfhreagrach ina nód tuismitheora ag crochadh.
    ///
    /// # Safety
    /// - Ní mór go mbeadh KV eile sa treo a thaistealaítear.
    /// - Níor chuir an comhghleacaí `next_unchecked` an duilleog edge ar ais roimhe seo ar aon chóip de na láimhseálacha a bhí á n-úsáid chun an crann a thrasnú.
    ///
    /// Is é an t-aon bhealach sábháilte chun dul ar aghaidh leis an láimhseáil nuashonraithe ná é a chur i gcomparáid, é a ligean anuas, an modh seo a ghlaoch arís faoi réir a choinníollacha sábháilteachta, nó glaoch ar mhacasamhail `next_unchecked` faoi réir a choinníollacha sábháilteachta.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Filleann sé an duilleog is faide ar chlé edge i nód nó faoi, i bhfocail eile, an edge a theastaíonn uait ar dtús agus tú ag dul ar aghaidh (nó an ceann deireanach agus tú ag dul ar gcúl).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Filleann sé an duilleog is ceart edge i nód nó faoi, i bhfocail eile, an edge a theastaíonn uait go deireanach agus tú ag dul ar aghaidh (nó ar dtús agus tú ag dul ar gcúl).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Tugann sé cuairt ar nóid duille agus KVanna inmheánacha in ord eochracha ardaitheacha, agus tugann siad cuairt freisin ar nóid inmheánacha ina n-iomláine ar an gcéad ord domhain, rud a chiallaíonn go dtéann nóid inmheánacha roimh a KVanna aonair agus a nóid linbh.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Ríomhtar líon na n-eilimintí i gcrann (fo).
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Filleann sé an duilleog edge is gaire do KV le haghaidh nascleanúna ar aghaidh.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Filleann sé an duilleog edge is gaire do KV le haghaidh nascleanúna siar.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}