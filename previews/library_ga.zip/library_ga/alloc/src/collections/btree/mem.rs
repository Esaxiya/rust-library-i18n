use core::intrinsics;
use core::mem;
use core::ptr;

/// Tagann sé seo in ionad an luach atá taobh thiar de thagairt uathúil `v` tríd an bhfeidhm ábhartha a ghlaoch.
///
///
/// Má tharlaíonn panic sa dúnadh `change`, ginmhilleadh an próiseas iomlán.
#[allow(dead_code)] // coinnigh mar léiriú agus le húsáid future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Tagann sé seo in ionad an luach atá taobh thiar de thagairt uathúil `v` trí ghlaoch ar an bhfeidhm ábhartha, agus tugann sé toradh a fuarthas ar an mbealach ar ais.
///
///
/// Má tharlaíonn panic sa dúnadh `change`, ginmhilleadh an próiseas iomlán.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}