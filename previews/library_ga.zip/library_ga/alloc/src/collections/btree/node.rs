// Iarracht é seo ar chur i bhfeidhm de réir na hidéalach
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Ós rud é nach bhfuil cineálacha cleithiúnacha agus athchúrsáil polymorfach ag Rust i ndáiríre, bímid ag baint le go leor neamhshábháilteachta.
//

// Is é príomhaidhm an mhodúil seo castacht a sheachaint tríd an gcrann a chóireáil mar choimeádán cineálach (má tá cruth aisteach air) agus gan déileáil le mórchuid na n-ionróirí B-Chrann a sheachaint.
//
// Dá bhrí sin, is cuma leis an modúl seo an bhfuil na hiontrálacha curtha in eagar, cé na nóid is féidir a bheith gann, nó fiú cad is brí le fo-earra.Mar sin féin, táimid ag brath ar chúpla ionradh:
//
// - Caithfidh crainn aonfhoirmeach depth/height a bheith acu.Ciallaíonn sé seo go bhfuil an fad céanna ag gach cosán síos go duilleog ó nód ar leith.
// - Tá eochracha `n`, luachanna `n`, agus imill `n + 1` ag nód ar fhad `n`.
//   Tugann sé seo le tuiscint go bhfuil edge amháin ar a laghad ag nód folamh.
//   Maidir le nód duille, ní chiallaíonn "having an edge" ach gur féidir linn suíomh sa nód a aithint, ós rud é go bhfuil imill duille folamh agus gan aon ionadaíocht sonraí de dhíth orthu.
// I nód inmheánach, sainaithníonn edge suíomh agus tá pointeoir ann do nód linbh.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Ionadaíocht bhunúsach na nóid duille agus cuid d`ionadaíocht nóid inmheánacha.
struct LeafNode<K, V> {
    /// Ba mhaith linn a bheith comhlántach i `K` agus `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Innéacs an nód seo i sraith `edges` an nód tuismitheora.
    /// `*node.parent.edges[node.parent_idx]` ba chóir go mbeadh an rud céanna le `node`.
    /// Ní ráthaítear é seo a thionscnamh ach nuair a bheidh `parent` neamh-null.
    parent_idx: MaybeUninit<u16>,

    /// Líon na n-eochracha agus na luachanna a stórálann an nód seo.
    len: u16,

    /// Na eagair a stórálann sonraí iarbhír an nód.
    /// Níl ach na chéad eilimintí `len` de gach eagar tosaigh agus bailí.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Cuirtear tús le `LeafNode` nua i bhfeidhm.
    unsafe fn init(this: *mut Self) {
        // Mar bheartas ginearálta, fágaimid réimsí gan trácht más féidir leo a bheith, mar ba chóir go mbeadh sé seo beagán níos tapa agus níos éasca a rianú i Valgrind.
        //
        unsafe {
            // tá parent_idx, eochracha, agus vals go léir MayUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Cruthaíonn `LeafNode` bosca nua.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Ionadaíocht bhunúsach na nóid inmheánacha.Mar aon le `LeafNode`s, ba chóir iad seo a chur i bhfolach taobh thiar de`BoxedNode`s chun cosc a chur ar eochracha agus luachanna neamhbheartaithe a ligean anuas.
/// Is féidir aon phointeoir ar `InternalNode` a chasadh go díreach chuig pointeoir leis an gcuid `LeafNode` bunúsach den nód, rud a ligeann don chód gníomhú ar nóid duille agus inmheánacha go fial gan a bheith fiú a sheiceáil cé acu den dá phointe a bhfuil pointeoir ag pointeáil air.
///
/// Cumasaítear an mhaoin seo trí `repr(C)` a úsáid.
///
#[repr(C)]
// gdb_providers.py úsáideann an cineál-ainm seo le haghaidh ionchoirithe.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Na leideanna do leanaí an nód seo.
    /// `len + 1` meastar go bhfuil siad seo tosaigh agus bailí, ach amháin gar don deireadh, cé go gcoinnítear an crann trí chineál iasachta `Dying`, tá cuid de na leideanna seo ag crochadh.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Cruthaíonn `InternalNode` bosca nua.
    ///
    /// # Safety
    /// Is ionradh ar nóid inmheánacha go bhfuil edge bailí amháin ar a laghad bailí acu.
    /// Ní chuireann an fheidhm seo edge ar bun.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Ní gá dúinn ach na sonraí a thúsú;Is iad na himill MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// A bhainistiú, neamh-null pointeoir chuig nód.Is pointeoir faoi úinéireacht é seo go `LeafNode<K, V>` nó pointeoir faoi úinéireacht `InternalNode<K, V>`.
///
/// Mar sin féin, níl aon fhaisnéis in `BoxedNode` maidir le cé acu den dá chineál nóid atá ann i ndáiríre, agus, go páirteach mar gheall ar an easpa faisnéise seo, ní cineál ar leithligh é agus níl aon scriosóir ann.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Nód fréimhe crainn faoi úinéireacht.
///
/// Tabhair faoi deara nach scriosóir é seo, agus caithfear é a ghlanadh de láimh.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Filleann sé crann faoi úinéireacht nua, lena nód fréimhe féin atá folamh i dtosach.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` níor chóir go mbeadh sé nialas.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Faigheann an nód fréimhe faoi úinéireacht ar iasacht go frithpháirteach.
    /// Murab ionann agus `reborrow_mut`, tá sé seo sábháilte toisc nach féidir an luach toraidh a úsáid chun an fhréamh a scriosadh, agus ní féidir tagairtí eile a dhéanamh don chrann.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Faigheann an nód fréimhe faoi úinéireacht beagán ar iasacht.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Aistríonn go dochúlaithe chuig tagairt a cheadaíonn trasnú agus a thairgeann modhanna millteach agus gan mórán eile.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Cuireann sé nód inmheánach nua le edge aonair dírithe ar an nód fréimhe roimhe seo, déan an nód fréimhe sin den nód fréimhe, agus seol ar ais é.
    /// Méadaíonn sé seo an airde faoi 1 agus a mhalairt de `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, eisceadh go Forgot againn ach tá muid inmheánach anois:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Baintear an nód fréimhe inmheánach, ag úsáid a chéad linbh mar an nód fréimhe nua.
    /// Toisc nach bhfuil sé beartaithe é a ghlaoch ach nuair nach bhfuil ach leanbh amháin ag an nód fréimhe, ní dhéantar aon ghlanadh ar aon cheann de na heochracha, na luachanna agus leanaí eile.
    ///
    /// Laghdaíonn sé seo an airde faoi 1 agus a mhalairt de `push_internal_level`.
    ///
    /// Éilíonn sé rochtain eisiach ar an réad `Root` ach ní ar an nód fréimhe;
    /// ní chuirfidh sé láimhseálacha nó tagairtí eile don nód fréimhe ó bhail.
    ///
    /// Panics mura bhfuil leibhéal inmheánach ann, ie, más duilleog an nód fréimhe.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SÁBHÁILTEACHT: dhearbhaíomar a bheith inmheánach.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SÁBHÁILTEACHT: fuaireamar `self` ar iasacht go heisiach agus tá a chineál iasachta eisiach.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SÁBHÁILTEACHT: tosaítear an chéad edge i gcónaí.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. Tá `NodeRef` comhleanúnach i gcónaí i `K` agus `V`, fiú nuair is é an `BorrowType` `Mut`.
// Tá sé seo mícheart go teicniúil, ach ní féidir aon neamhshábháilteacht a bheith mar thoradh air mar gheall ar úsáid inmheánach `NodeRef` toisc go bhfanfaimid go hiomlán cineálach thar `K` agus `V`.
//
// Mar sin féin, aon uair a fillteann cineál poiblí `NodeRef`, déan cinnte go bhfuil an athraitheas ceart aige.
//
/// Tagairt do nód.
///
/// Tá roinnt paraiméadair ag an gcineál seo a rialaíonn an chaoi a bhfeidhmíonn sé:
/// - `BorrowType`: Cineál caocha a chuireann síos ar an gcineál iasachta agus a mhaireann ar feadh an tsaoil.
///    - Nuair is é seo `Immut<'a>`, gníomhaíonn an `NodeRef` go garbh cosúil le `&'a Node`.
///    - Nuair is é seo `ValMut<'a>`, gníomhaíonn an `NodeRef` go garbh cosúil le `&'a Node` maidir le heochracha agus struchtúr na gcrann, ach ceadaíonn sé freisin go leor tagairtí suaracha do luachanna ar fud an chrainn a chónaí.
///    - Nuair is é seo `Mut<'a>`, gníomhaíonn an `NodeRef` go garbh cosúil le `&'a mut Node`, cé go gceadaíonn modhanna isteach isteach pointeoir inathraithe ar luach a chómhaoiniú.
///    - Nuair is é seo `Owned`, gníomhaíonn an `NodeRef` go garbh cosúil le `Box<Node>`, ach níl scriosóir aige, agus caithfear é a ghlanadh de láimh.
///    - Nuair is é seo `Dying`, gníomhaíonn an `NodeRef` go garbh cosúil le `Box<Node>`, ach tá modhanna aige chun an crann a scriosadh céim ar chéim, agus cé nach bhfuil sé marcáilte go bhfuil sé neamhshábháilte glaoch, is féidir leis UB a agairt má ghlaotar go mícheart air.
///
///   Ós rud é go gceadaíonn aon `NodeRef` nascleanúint a dhéanamh tríd an gcrann, baineann `BorrowType` go héifeachtach leis an gcrann iomlán, ní amháin leis an nód féin.
/// - `K` agus `V`: Seo iad na cineálacha eochracha agus luachanna atá stóráilte sna nóid.
/// - `Type`: Is féidir seo a bheith `Leaf`, `Internal`, nó `LeafOrInternal`.
/// Nuair is é seo `Leaf`, díríonn an `NodeRef` ar nód duille, nuair is é seo `Internal` díríonn an `NodeRef` ar nód inmheánach, agus nuair is é seo `LeafOrInternal` d`fhéadfadh an `NodeRef` a bheith dírithe ar cheachtar cineál nód.
///   `Type` ainmnithe `NodeType` nuair a úsáidtear lasmuigh `NodeRef`.
///
/// Cuireann `BorrowType` agus `NodeType` araon srian ar na modhanna a chuirimid i bhfeidhm, chun sábháilteacht de chineál statach a shaothrú.Tá teorainneacha leis an mbealach is féidir linn srianta den sórt sin a chur i bhfeidhm:
/// - Maidir le gach paraiméadar cineáil, ní féidir linn modh a shainiú go fial nó do chineál amháin.
/// Mar shampla, ní féidir linn modh cosúil le `into_kv` a shainiú go fial do gach `BorrowType`, nó uair amháin do gach cineál a bhfuil saolré aige, toisc go dteastaíonn uainn tagairtí `&'a` a thabhairt ar ais.
///   Dá bhrí sin, ní dhéanaimid é a shainiú ach don chineál `Immut<'a>` is lú cumhacht.
/// - Ní féidir linn comhéigean intuigthe a fháil ó abair `Mut<'a>` go `Immut<'a>`.
///   Dá bhrí sin, ní mór dúinn `reborrow` a ghlaoch go sainráite ar `NodeRef` níos cumhachtaí d`fhonn modh mar `into_kv` a bhaint amach.
///
/// Gach modh ar `NodeRef` a chuireann tagairt de chineál éigin ar ais, ach an oiread:
/// - Tóg `self` de réir luacha, agus faigh ar ais an saolré a iompraíonn `BorrowType`.
///   Uaireanta, chun modh den sórt sin a agairt, caithfimid `reborrow_mut` a ghlaoch.
/// - Tóg `self` trí thagairt, agus (implicitly) ais go tagairt ar feadh an tsaoil, in ionad an tsaoil iompraíonn `BorrowType`.
/// Ar an mbealach sin, ráthaíonn an seiceálaí iasachta go bhfanfaidh an `NodeRef` ar iasacht chomh fada agus a úsáidtear an tagairt ar ais.
///   Lúbann na modhanna a thacaíonn le hiontráil an riail seo trí phointeoir amh a thabhairt ar ais, ie tagairt gan saolré ar bith.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Líon na leibhéal a bhfuil an nód agus leibhéal na duilleoga scartha óna chéile, tairiseach den nód nach féidir le `Type` cur síos iomlán a dhéanamh air, agus nach stórálann an nód féin.
    /// Ní gá dúinn ach airde an nód fréimhe a stóráil, agus airde gach nód eile a dhíorthú.
    /// Caithfidh sé a bheith nialasach má tá `Type` `Leaf` agus neamh-nialas más `Type` `Internal`.
    ///
    ///
    height: usize,
    /// An pointeoir leis an duilleog nó an nód inmheánach.
    /// Cinntíonn sainmhíniú `InternalNode` go bhfuil an pointeoir bailí ar aon bhealach.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Díphacáil tagairt nód a bhí pacáilte mar `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Nochtann sé sonraí nód inmheánach.
    ///
    /// Seoltar ptr amh ar ais chun tagairtí eile don nód seo a chur ó bhail.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SÁBHÁILTEACHT: is é `Internal` an cineál nód statach.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Faigheann sé rochtain eisiach ar shonraí nód inmheánach ar iasacht.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Faightear fad an nód.Seo líon na n-eochracha nó na luachanna.
    /// Tá líon na himill `len() + 1`.
    /// Tabhair faoi deara, in ainneoin a bheith sábháilte, go bhféadfadh fo-iarmhairt a bheith ag glaoch ar an bhfeidhm seo tagairtí dochúlaithe a chruthaigh cód neamhshábháilte a chur ó bhail.
    ///
    pub fn len(&self) -> usize {
        // Go ríthábhachtach, ní dhéanaimid rochtain ach ar réimse `len` anseo.
        // Más marker::ValMut é BorrowType, d`fhéadfadh go mbeadh tagairtí inathraithe gan íoc ann do luachanna nach mór dúinn a chur ó bhail.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Filleann sé líon na leibhéal a bhfuil an nód agus na duilleoga óna chéile.
    /// Ciallaíonn airde nialais gur duilleog féin an nód.
    /// Má phictiúr tú crainn leis an bhfréamh ar a mbarr, deir an uimhir ag an ingearchló atá an nód le feiceáil.
    /// Má tá tú pictiúr crann le duilleoga ar bharr, a deir an t-uimhir cé chomh hard leathnaíonn an crann os cionn an nód.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Tógann sé tagairt eile dochorraithe don nód céanna go sealadach.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Nochtann an chuid duilleog d'aon duilleog nó nód inmheánach.
    ///
    /// Seoltar ptr amh ar ais chun tagairtí eile don nód seo a chur ó bhail.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Caithfidh an nód a bheith bailí don chuid LeafNode ar a laghad.
        // Ní tagairt é seo sa chineál NodeRef toisc nach bhfuil a fhios againn ar cheart go mbeadh sé uathúil nó roinnte.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Aimsíonn tuismitheoir an nód reatha.
    /// Filleann sé `Ok(handle)` má tá tuismitheoir ag an nód reatha i ndáiríre, áit a dtugann `handle` aird ar edge an tuismitheora a dhíríonn ar an nód reatha.
    ///
    /// Tuairisceáin `Err(self)` mura bhfuil aon tuismitheoir ag an nód reatha, ag tabhairt an `NodeRef` bunaidh ar ais.
    ///
    /// Glacann ainm an mhodha leat crainn a phictiúr leis an nód fréimhe ar a bharr.
    ///
    /// `edge.descend().ascend().unwrap()` agus níor cheart go ndéanfadh `node.ascend().unwrap().descend()`, ar rath, aon rud a dhéanamh.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Ní mór dúinn leideanna amha a úsáid chun nóid mar, más marker::ValMut é BorrowType, d`fhéadfadh go mbeadh tagairtí suaracha gan íoc ann do luachanna nach mór dúinn a chur ó bhail.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Tabhair faoi deara go gcaithfidh `self` a bheith dosháraithe.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Tabhair faoi deara go gcaithfidh `self` a bheith dosháraithe.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Nochtann an chuid duilleog d`aon duilleog nó nód inmheánach i gcrann dochorraithe.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SÁBHÁILTEACHT: ní féidir tagairtí suaithinseacha a bheith ann don chrann seo a fuarthas ar iasacht mar `Immut`.
        unsafe { &*ptr }
    }

    /// Faightear léargas ar iasacht ar na heochracha atá stóráilte sa nód.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Cosúil le `ascend`, faigheann sé tagairt do nód tuismitheora nód, ach tuigeann sé an nód reatha sa phróiseas freisin.
    /// Tá sé seo neamhshábháilte toisc go mbeidh an nód reatha inrochtana fós in ainneoin go bhfuil sé intuigthe.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Dearbhaíonn go neamhshábháilte don tiomsaitheoir an fhaisnéis statach gur `Leaf` an nód seo.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Dearbhaíonn go neamhshábháilte don tiomsaitheoir an fhaisnéis statach gur `Internal` an nód seo.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Go sealadach tógann sé tagairt inathraithe eile don nód céanna.Beware, toisc go bhfuil an modh seo an-chontúirteach, go dúbailte mar sin toisc nach bhféadfadh sé a bheith contúirteach láithreach.
    ///
    /// Toisc gur féidir le leideanna inathraithe fánaíocht áit ar bith timpeall an chrainn, is féidir an pointeoir ar ais a úsáid go héasca chun an pointeoir bunaidh a chrochadh, as teorainneacha, nó a bheith neamhbhailí faoi rialacha cruachta iasachta.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) smaoineamh ar pharaiméadar de chineál eile a chur le `NodeRef` a chuireann srian ar úsáid modhanna nascleanúna ar leideanna athfhorbartha, ag cosc na neamhshábháilteachta seo.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Faigheann rochtain eisiach ar chuid duilleog aon nód duille nó inmheánach.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SÁBHÁILTEACHT: tá rochtain eisiach againn ar an nód iomlán.
        unsafe { &mut *ptr }
    }

    /// Tairgeann sé rochtain eisiach ar an gcuid duilleog d'aon duilleog nó nód inmheánach.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SÁBHÁILTEACHT: tá rochtain eisiach againn ar an nód iomlán.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Iasacht rochtain eisiach chun gné an limistéir stórála eochair.
    ///
    /// # Safety
    /// `index` faoi theorainneacha 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SÁBHÁILTEACHT: ní bheidh an té atá ag glaoch in ann modhanna breise a ghlaoch air féin
        // go dtí go dtitfear an tagairt eochair slice, mar tá rochtain uathúil againn ar feadh shaolré na hiasachta.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Faigh rochtain eisiach ar eilimint nó slice de limistéar stórála luacha an nód.
    ///
    /// # Safety
    /// `index` faoi theorainneacha 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SÁBHÁILTEACHT: ní bheidh an té atá ag glaoch in ann modhanna breise a ghlaoch air féin
        // go dtí go dtitfear an tagairt slice luacha, toisc go bhfuil rochtain uathúil againn ar feadh shaolré na hiasachta.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Faigh rochtain eisiach ar eilimint nó ar shliseog de limistéar stórála an nód le haghaidh ábhar edge.
    ///
    /// # Safety
    /// `index` faoi theorainneacha 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SÁBHÁILTEACHT: ní bheidh an té atá ag glaoch in ann modhanna breise a ghlaoch air féin
        // go dtí go dtitfear tagairt slice edge, toisc go bhfuil rochtain uathúil againn ar feadh shaolré na hiasachta.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Tá níos mó ná eilimintí tosaigh `idx` ag an nód.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Ní chruthaímid tagairt ach don ghné amháin a bhfuil suim againn inti, chun ailias a sheachaint le tagairtí gan íoc d`eilimintí eile, go háirithe iad siúd a chuirtear ar ais chuig an té atá ag glaoch i dtreoracha níos luaithe.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Ní mór dúinn comhoiriúnú a dhéanamh ar leideanna eagar neamhshábháilte mar gheall ar eisiúint Rust #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Faigh rochtain eisiach ar fhad an nód.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Socraíonn sé nasc an nód lena thuismitheoir edge, gan tagairtí eile don nód a chur ó bhail.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Glanann nasc na fréimhe lena tuismitheoir edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Cuireann sé péire príomhluacha le deireadh an nód.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Is innéacs bailí edge don nód gach mír a chuireann `range` ar ais.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Cuireann sé péire príomhluacha, agus edge le dul ar thaobh na láimhe deise den phéire sin, go dtí deireadh an nód.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Seiceálacha an nód nód `Internal` nó nód `Leaf` é nód.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Tagairt do phéire sonrach príomhluacha nó edge laistigh de nód.
/// Ní mór `NodeRef` a bheith sa pharaiméadar `Node`, agus is féidir gurb é `KV` an `Type` (láimhseáil ar phéire príomhluacha) nó `Edge` (ag síniú láimhseáil ar edge).
///
/// Tabhair faoi deara gur féidir Láimhseálann `Edge` a bheith ag fiú nóid `Leaf`.
/// In ionad pointeoir a léiriú ar nód linbh, is ionann iad sin agus na spásanna ina rachadh leideanna leanaí idir na péirí eochairluacha.
/// Mar shampla, i nód le fad 2, bheadh 3 shuíomh edge féideartha, ceann ar thaobh na láimhe clé den nód, ceann idir an dá phéire, agus ceann ar thaobh na láimhe deise den nód.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Níl ginearáltacht iomlán `#[derive(Clone)]` de dhíth orainn, mar is é an t-aon uair amháin a bheidh `Node` `Clónáilte 'ná nuair is tagairt dochorraithe é agus mar sin `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Aisghabhann an nód ina bhfuil an edge nó an péire eochairluacha a ndíríonn an láimhseáil seo air.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Filleann sé suíomh an láimhseála seo sa nód.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Cruthaíonn láimhseáil nua péire péire príomhluacha in `node`.
    /// Neamhshábháilte toisc go gcaithfidh an té atá ag glaoch a chinntiú go bhfuil `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// D`fhéadfadh sé gur cur chun feidhme poiblí de PartialEq a bheadh ann, ach nach n-úsáidtear ach sa mhodúl seo.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Tógann láimhseáil eile dochorraithe go sealadach ar an áit chéanna.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Ní féidir linn Handle::new_kv nó Handle::new_edge a úsáid mar níl a fhios againn cén cineál atá againn
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Dearbhaíonn go sábháilte don tiomsaitheoir an fhaisnéis statach gur `Leaf` nód an láimhseála.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Tógann sé láimhseáil inathraithe eile go sealadach ar an áit chéanna.
    /// Beware, toisc go bhfuil an modh seo an-chontúirteach, go dúbailte mar sin toisc nach bhféadfadh sé a bheith contúirteach láithreach.
    ///
    ///
    /// Le haghaidh sonraí, féach `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Ní féidir linn Handle::new_kv nó Handle::new_edge a úsáid mar níl a fhios againn cén cineál atá againn
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Cruthaíonn láimhseáil nua do edge i `node`.
    /// Neamhshábháilte mar ní mór an té atá ag glaoch go `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Nuair a thugtar innéacs edge inar mian linn a chur isteach i nód atá líonta go hacmhainn, ríomhtar innéacs ciallmhar KV de phointe scoilte agus cá háit a gcuirfear isteach é.
///
/// Is é aidhm an phointe scoilte go n-éireoidh a eochair agus a luach i nód tuismitheora;
/// déantar na heochracha, na luachanna agus na himill ar thaobh na láimhe clé den phointe scoilte mar an leanbh clé;
/// déantar na heochracha, na luachanna agus na himill ar thaobh na láimhe deise den phointe scoilte mar an leanbh ceart.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Déanann Rust eagrán #74834 iarracht na rialacha siméadracha seo a mhíniú.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ionsáigh péire nua fíor-riachtanach-luach idir na péirí eochair-luach leis an gceart agus ar chlé ar an edge.
    /// Glactar leis an modh seo go bhfuil go leor spáis sa nód chun go n-oirfeadh an péire nua.
    ///
    /// Díríonn an pointeoir ar ais ar an luach a cuireadh isteach.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ionsáigh péire nua fíor-riachtanach-luach idir na péirí eochair-luach leis an gceart agus ar chlé ar an edge.
    /// Scoilteann an modh seo an nód mura bhfuil go leor seomra ann.
    ///
    /// Díríonn an pointeoir ar ais ar an luach a cuireadh isteach.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Fixes an pointeoir tuismitheoir agus innéacs sa nód leanbh go nascann sé seo edge a.
    /// Tá sé seo úsáideach nuair a athraítear ordú na n-imill,
    fn correct_parent_link(self) {
        // Cruthaigh backpointer gan tagairtí eile don nód a chur ó bhail.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Ionsáigh péire eochairluach nua agus edge a rachaidh ar thaobh na láimhe deise den phéire nua sin idir an edge seo agus an péire príomhluacha ar thaobh na láimhe deise den edge seo.
    /// Glactar leis an modh seo go bhfuil go leor spáis sa nód chun go n-oirfeadh an péire nua.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Ionsáigh péire eochairluach nua agus edge a rachaidh ar thaobh na láimhe deise den phéire nua sin idir an edge seo agus an péire príomhluacha ar thaobh na láimhe deise den edge seo.
    /// Scoilteann an modh seo an nód mura bhfuil go leor seomra ann.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ionsáigh péire nua fíor-riachtanach-luach idir na péirí eochair-luach leis an gceart agus ar chlé ar an edge.
    /// Scoilteann an modh seo an nód mura bhfuil go leor seomra ann, agus déanann sé iarracht an chuid scoilte a chur isteach sa nód tuismitheora go hathchúrsach, go dtí go sroichtear an fhréamh.
    ///
    ///
    /// Más `Fit` an toradh a chuirtear ar ais, is féidir gurb é nód a láimhseála an nód edge seo nó sinsear.
    /// Más `Split` an toradh a cuireadh ar ais, is é an réimse `left` an nód fréimhe.
    /// Díríonn an pointeoir ar ais ar an luach a cuireadh isteach.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Faightear an nód a dtugann an edge seo aird air.
    ///
    /// Glacann ainm an mhodha leat crainn a phictiúr leis an nód fréimhe ar a bharr.
    ///
    /// `edge.descend().ascend().unwrap()` agus níor cheart go ndéanfadh `node.ascend().unwrap().descend()`, ar rath, aon rud a dhéanamh.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Ní mór dúinn leideanna amha a úsáid chun nóid mar, más marker::ValMut é BorrowType, d`fhéadfadh go mbeadh tagairtí suaracha gan íoc ann do luachanna nach mór dúinn a chur ó bhail.
        // Níl aon imní ann rochtain a fháil ar an réimse airde toisc go ndéantar an luach sin a chóipeáil.
        // Bí ar an eolas, a luaithe a dhéantar pointeoir an nód a dhífhabhtú, go ndéanaimid rochtain ar eagar na n-imill le tagairt (Rust eagrán #73987) agus aon tagairtí eile don eagar nó laistigh di a chur ó bhail, má tá siad thart.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Ní féidir linn glaoch ar eochair agus luach modhanna ar leith, mar gheall ar ghlaoch ar an dara invalidates amháin an tagairt ar ais ag an gcéad.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Cuir an eochair agus an luach a dtagraíonn an láimhseáil KV ina ionad.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Cuidíonn sé le `split` a chur i bhfeidhm le haghaidh `NodeType` áirithe, trí aire a thabhairt do shonraí duille.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Roinntear an nód bunúsach ina thrí chuid:
    ///
    /// - Teastaítear an nód chun nach mbeidh ann ach na péirí eochairluacha ar thaobh na láimhe clé den láimhseáil seo.
    /// - Baintear an eochair agus an luach a dtugann an láimhseáil seo aird orthu.
    /// - Cuirtear na péirí eochairluacha uile ar thaobh na láimhe deise den láimhseáil seo i nód nua-leithdháilte.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Baintear an péire príomhluacha a dtugann an láimhseáil seo aird air agus seol ar ais é, in éineacht leis an edge ar thit an péire príomhluacha isteach ann.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Roinntear an nód bunúsach ina thrí chuid:
    ///
    /// - Teastaítear an nód chun nach mbeidh ann ach na himill agus na péirí eochairluacha ar thaobh na láimhe clé den láimhseáil seo.
    /// - Baintear an eochair agus an luach a dtugann an láimhseáil seo aird orthu.
    /// - Cuirtear na himill agus na péirí eochairluacha uile ar thaobh na láimhe deise den láimhseáil seo i nód nua-leithdháilte.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Is ionann é agus seisiún chun oibríocht chothromaíochta a mheas agus a dhéanamh timpeall ar phéire inmheánach príomhluacha.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Roghnaíonn sé comhthéacs cothromaíochta ina bhfuil an nód mar leanbh, mar sin idir an KV láithreach ar chlé nó ar dheis sa nód tuismitheora.
    /// Filleann `Err` mura bhfuil aon tuismitheoir ann.
    /// Panics má tá an tuismitheoir folamh.
    ///
    /// Is fearr an taobh clé a bheith barrmhaith má tá an nód a thugtar gann ar bhealach, rud a chiallaíonn anseo ach go bhfuil níos lú eilimintí aige ná a siblín clé agus ná a siblín ceart, má tá siad ann.
    /// Sa chás sin, is tapa an cumasc leis an siblín clé, ós rud é nach gá dúinn ach eilimintí N an nód a bhogadh, in ionad iad a aistriú ar dheis agus níos mó ná eilimintí N a bhogadh chun tosaigh.
    /// Is gnách go mbíonn goid ón siblín clé níos gasta freisin, ós rud é nach gá dúinn ach eilimintí N an nód a aistriú ar dheis, in ionad N ar a laghad d`eilimintí an siblín a aistriú ar chlé.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Filleann sé an féidir cumasc a dhéanamh, ie, an bhfuil go leor spáis i nód chun an KV lárnach a chomhcheangal leis an dá nóid linbh in aice láimhe.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Déanann sé cumasc agus ligeann do dhúnadh cinneadh a dhéanamh ar cad ba cheart a thabhairt ar ais.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SÁBHÁILTEACHT: tá airde na nóid atá á gcumasc ceann faoi bhun an airde
                // de nód an edge seo, mar sin os cionn nialas, mar sin tá siad inmheánach.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Nascann sé péire príomhluacha an tuismitheora agus an dá nóid linbh in aice láimhe isteach i nód an linbh chlé agus tugann sé nód an tuismitheora shrunk ar ais.
    ///
    ///
    /// Panics mura ndéanaimid `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Nascann sé péire príomhluacha an tuismitheora agus an dá nóid linbh in aice láimhe i nód an linbh chlé agus cuireann an nód linbh sin ar ais.
    ///
    ///
    /// Panics mura ndéanaimid `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Nascann sé péire príomhluacha an tuismitheora agus an dá nóid linbh in aice láimhe i nód an linbh chlé agus tugann sé an láimhseáil edge ar ais sa nód linbh sin inar chríochnaigh an leanbh rianaithe edge,
    ///
    ///
    /// Panics mura ndéanaimid `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Bain péire príomhluacha ón leanbh ar chlé agus é a chur i stóráil príomhluacha an tuismitheora, agus an péire sean-luacha tuismitheora á bhrú isteach sa leanbh ceart.
    ///
    /// Seoltar láimhseáil ar ais chuig an edge sa leanbh ceart a fhreagraíonn don áit ar chríochnaigh an edge bunaidh a shonraigh `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Bain péire príomhluacha ón leanbh ceart agus é a chur i stóráil príomhluacha an tuismitheora, agus an péire péire eochairluacha tuismitheora á bhrú ar an leanbh ar chlé.
    ///
    /// Seoltar láimhseáil ar ais chuig an edge sa leanbh ar chlé a shonraíonn `track_left_edge_idx`, nár bhog.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Déanann sé seo goid cosúil le `steal_left` ach déanann sé iliomad eilimintí a ghoid ag an am céanna.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Déan cinnte go bhféadfaimis goid go sábháilte.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Bog sonraí duille.
            {
                // Déan seomra d`eilimintí goidte sa pháiste ceart.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Bog eilimintí ón leanbh clé go dtí an ceann ceart.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Bog an péire is mó a ghoid go dtí an tuismitheoir.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Bog péire príomhluacha tuismitheora chuig an leanbh ceart.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Déan seomra d`imill ghoidte.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Goill imill.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Clón siméadrach `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Déan cinnte go bhféadfaimis goid go sábháilte.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Bog sonraí duille.
            {
                // Bog an péire ceart-goidte go dtí an tuismitheoir.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Bog péire príomhluacha tuismitheora chuig an leanbh ar chlé.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Bog eilimintí ón leanbh ceart go dtí an ceann clé.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Líon bearna mar a bhíodh eilimintí goidte.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Goill imill.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // bearna Líon nuair a úsáidtear imill goideadh a bheith.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Baintear aon fhaisnéis statach ag dearbhú gur nód `Leaf` an nód seo.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Baintear aon fhaisnéis statach ag dearbhú gur nód `Internal` an nód seo.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Seiceálacha an nód `Internal` nó nód `Leaf` an nód bunúsach.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Bog an iarmhír i ndiaidh `self` ó nód amháin go ceann eile.Caithfidh `right` a bheith folamh.
    /// Tá an chéad edge de `right` gan athrú.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Toradh an chur isteach, nuair ba ghá nód a leathnú thar a chumas.
pub struct SplitResult<'a, K, V, NodeType> {
    // Nód athraithe sa chrann atá ann cheana le heilimintí agus imill a bhaineann leis an taobh clé de `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Roinnt eochair agus luacha roinnte, le cur isteach in áit eile.
    pub kv: (K, V),
    // Nód nua faoi úinéireacht, gan teagmháil, le heilimintí agus imill a bhaineann le ceart `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Cibé an gceadaíonn tagairtí nód den chineál iasachta seo trasnú go nóid eile sa chrann.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Ní gá traversal, tarlaíonn sé ag baint úsáide as toradh `borrow_mut`.
        // Trí thrasnú a dhíchumasú, agus gan ach tagairtí nua do fhréamhacha a chruthú, tá a fhios againn go bhfuil gach tagairt den chineál `Owned` do nód fréimhe.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Cuir luach isteach i slice d`eilimintí tosaigh agus eilimint neamhbheartaithe amháin ina dhiaidh sin.
///
/// # Safety
/// Tá níos mó ná eilimintí `idx` sa slice.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Bain agus tuairisceáin a luach ó slice de na heilimintí initialized, ag fágáil taobh thiar de amháin trailing eilimint uninitialized.
///
///
/// # Safety
/// Tá níos mó ná eilimintí `idx` sa slice.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Aistrigh na heilimintí i bpíosa slice `distance` ar chlé.
///
/// # Safety
/// Tá eilimintí `distance` ar a laghad sa slice.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Aistrigh na heilimintí i bpíosa slice `distance` ar dheis.
///
/// # Safety
/// Tá eilimintí `distance` ar a laghad sa slice.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Bogann sé na luachanna go léir ó shlisne d`eilimintí tosaigh go slice d`eilimintí neamhbheartaithe, ag fágáil `src` taobh thiar mar gach neamhinitialú.
///
/// Oibríonn sé mar `dst.copy_from_slice(src)` ach ní éilíonn sé gurb é `T` `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;