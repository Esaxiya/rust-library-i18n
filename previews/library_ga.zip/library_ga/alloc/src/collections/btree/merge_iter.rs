use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// Croí iteora a chumasc aschur dhá atriallóir atá ag dul suas go docht, mar shampla aontas nó difríocht siméadrach.
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// Tagarmharcanna níos gasta ná an dá iteoir a fhilleadh ar Peekable, is dócha toisc go bhfuil sé d'acmhainn againn FusedIterator faoi cheangal a fhorchur.
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// Cruthaíonn sé croí nua d`athraitheoir a chumasc péire foinsí.
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// Filleann sé an chéad péire earraí eile a d'eascair ón bpéire foinsí a bhí á gcumasc.
    /// Má tá luach sa dá rogha a cuireadh ar ais, tá an luach sin cothrom agus tarlaíonn sé sa dá fhoinse.
    /// Má tá luach i gceann de na roghanna a cuireadh ar ais, ní tharlaíonn an luach sin san fhoinse eile (nó níl na foinsí ag dul suas go docht).
    ///
    /// Mura bhfuil luach i gceachtar den dá rogha a cuireadh ar ais, tá an t-atriall críochnaithe agus seolfaidh glaonna ina dhiaidh sin an péire folamh céanna ar ais.
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// Filleann sé péire teorainneacha uachtaracha don `size_hint` den atriall deiridh.
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}