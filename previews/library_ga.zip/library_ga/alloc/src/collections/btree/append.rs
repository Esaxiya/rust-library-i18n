use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Cuirtear gach péire príomhluacha ón aontas de dhá iteoir ardaitheacha i gceangal, ag méadú athróg `length` ar an mbealach.Déanann an dara ceann é a dhéanamh níos éasca don té atá ag glaoch sceitheadh a sheachaint nuair a bhíonn láimhseálaí titim ag piocadh.
    ///
    /// Má tháirgeann an dá ite an eochair chéanna, titeann an modh seo an péire ón iteoir ar chlé agus cuireann sé an péire ón atriallóir ceart.
    ///
    /// Más mian leat go gcríochnódh an crann in ord díreach ardaitheach, cosúil le `BTreeMap`, ba cheart don dá iteoir eochracha a tháirgeadh in ord ardaitheach, gach ceann acu níos mó ná na heochracha uile sa chrann, lena n-áirítear aon eochracha atá sa chrann cheana féin ar iontráil dó.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Ullmhaímid chun `left` agus `right` a chumasc i seicheamh sórtáilte in am líneach.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Idir an dá linn, tógaimid crann ón seicheamh sórtáilte in am líneach.
        self.bulk_push(iter, length)
    }

    /// Brúigh gach péire príomhluacha go dtí deireadh an chrainn, ag méadú athróg `length` ar an mbealach.
    /// Déanann an dara ceann é a dhéanamh níos éasca don té atá ag glaoch sceitheadh a sheachaint nuair a bhíonn an t-atriall ag piocadh.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Iterate trí gach péirí luach-eochair, agus iad a bhrú i nóid ag an leibhéal ceart.
        for (key, value) in iter {
            // Déan iarracht péire príomhluacha a bhrú isteach sa nód duilleog reatha.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Níl aon spás fágtha, téigh suas agus brú ansin.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Aimsíodh nód le spás fágtha, brúigh anseo.
                                open_node = parent;
                                break;
                            } else {
                                // Téigh suas arís.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Táimid ag an mbarr, nód fréimhe nua a chruthú agus a bhrú ansin.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Brúigh péire eochairluacha agus fotheideal ceart nua.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Téigh síos go dtí an duilleog is ceart arís.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Fad an mhéadaithe ar gach atriall, chun a chinntiú go dtiteann an léarscáil na heilimintí atá i gceangal fiú má chuirtear na scaoll iteora chun cinn.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Eagaróir chun dhá shraith sórtáilte a chumasc i gceann amháin
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Má tá dhá eochracha cothrom, filleann an péire príomhluacha ón bhfoinse cheart.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}