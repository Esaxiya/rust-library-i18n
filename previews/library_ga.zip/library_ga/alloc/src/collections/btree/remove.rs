use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// Bain péire príomhluacha ón gcrann, agus cuireann sé an péire sin ar ais, chomh maith leis an duilleog edge a fhreagraíonn don iarphéire sin.
    /// Is féidir go bhfolaíonn sé seo nód fréimhe atá inmheánach, ar chóir don té atá ag glaoch é a phiocadh ón léarscáil a bhfuil an crann aige.
    /// Ba cheart don ghlaoiteoir fad na léarscáile a laghdú freisin.
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // Ní mór dúinn dearmad a dhéanamh go sealadach ar an gcineál linbh, toisc nach bhfuil aon chineál nód ar leith ann do thuismitheoirí láithreacha duille.
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // SÁBHÁILTEACHT: Is é `new_pos` an duilleog as ar thosaigh muid nó siblín.
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // Ach má rinneamar cumasc, tá an tuismitheoir (más ann dó) tar éis crapadh, ach mura n-íocann an chéim seo a leanas a mhalairt ní íocann sé as i tagarmharcanna.
            //
            // SÁBHÁILTEACHT: Ní scriosfaimid ná ní athshocróimid an duilleog ina bhfuil `pos`
            // trína thuismitheoir a láimhseáil go hathchúrsach;ag an rud is measa déanfaimid an tuismitheoir a scriosadh nó a atheagrú tríd an seantuismitheoir, agus ar an gcaoi sin athróimid an nasc leis an tuismitheoir taobh istigh den duilleog.
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // Bain KV cóngarach óna duilleog agus ansin cuir ar ais é in áit na heiliminte a iarradh orainn a bhaint.
        //
        // Is fearr an KV ar chlé in aice láimhe, ar na cúiseanna atá liostaithe in `choose_parent_kv`.
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // B`fhéidir gur goideadh an nód inmheánach nó gur rinneadh é a chumasc.
        // Téigh ar ais ar dheis chun a fháil amach cá chríochnaigh an KV bunaidh.
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}