use core::marker::PhantomData;
use core::ptr::NonNull;

/// Múnlaítear aischur de thagairt uathúil, nuair a bhíonn a fhios agat nach n-úsáidfear an t-aischur agus a shliocht go léir (ie, gach pointe agus tagairt a dhíorthaítear uaidh) níos mó ag pointe éigin, agus ina dhiaidh sin ba mhaith leat an tagairt uathúil bhunaidh a úsáid arís. .
///
///
/// De ghnáth, láimhseálann an seiceálaí iasachta an cruachadh iasachtaí seo duit, ach tá roinnt sreafaí rialaithe a chuireann an cruachadh seo i gcrích ró-chasta don tiomsaitheoir a leanúint.
/// Ligeann `DormantMutRef` duit iasachtaí a sheiceáil tú féin, agus a nádúr cruachta á chur in iúl fós, agus an cód pointeoir amh a theastaíonn chun é seo a dhéanamh a iompar gan iompar neamhshainithe.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Faigh iasacht uathúil, agus déan í a atheagrú láithreach.
    /// Maidir leis an tiomsaitheoir, tá saolré na tagartha nua mar an gcéanna le saolré na tagartha bunaidh, ach déanann tú promise a úsáid ar feadh tréimhse níos giorra.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SÁBHÁILTEACHT: coinnímid an iasacht ar fud 'a via `_marker`, agus nochtaímid
        // an tagairt seo amháin, mar sin tá sé uathúil.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Téigh ar ais chuig an iasacht uathúil a gabhadh i dtosach.
    ///
    /// # Safety
    ///
    /// Ní foláir go raibh deireadh leis an aischur, ie, ní gá an tagairt a chuir `new` ar ais agus gach leideanna agus tagairtí a dhíorthaítear uaidh a úsáid níos mó.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SÁBHÁILTEACHT: tugann ár gcoinníollacha sábháilteachta féin le tuiscint go bhfuil an tagairt seo uathúil arís.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;