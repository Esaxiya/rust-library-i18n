use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Tá sé beagáinín deacair tástáil chomhtháthaithe a scríobh idir leithdháilteoirí tríú páirtí agus `RawVec` toisc nach nochtann API `RawVec` modhanna leithdháilte suaite, mar sin ní féidir linn a sheiceáil cad a tharlaíonn nuair a bhíonn an leithdháilteoir ídithe (seachas panic a bhrath).
    //
    //
    // Ina áit sin, ní dhéanann sé seo ach seiceáil go dtéann na modhanna `RawVec` tríd an API Allocator ar a laghad nuair a choinníonn sé stóráil.
    //
    //
    //
    //
    //

    // Leithdháilteoir balbh a ídíonn méid seasta breosla sula dtosaíonn iarrachtaí leithdháilte ag teip.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (is cúis le hathdháileadh, agus 50 + 150=200 aonad breosla á úsáid)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Ar dtús, leithdháileann `reserve` cosúil le `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // Tá 97 níos mó ná dhá oiread 7, mar sin ba chóir go n-oibreodh `reserve` mar `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // Tá 3 níos lú ná leath de 12, mar sin caithfidh `reserve` fás go heaspónantúil.
        // Agus an fachtóir fáis tástála seo á scríobh, is é 2 an cumas fáis nua, áfach, tá fachtóir fáis 1.5 ceart go leor freisin.
        //
        // Dá réir sin `>= 18` i ndearbhú.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}