//! Leideanna comhairimh tagartha aon snáithe.Seasann 'Rc' do 'Tagairt
//! Counted'.
//!
//! Soláthraíonn an cineál [`Rc<T>`][`Rc`] comhúinéireacht ar luach de chineál `T`, arna leithdháileadh sa gcarn.
//! Nuair a dhéantar [`clone`][clone] a agairt ar [`Rc`], cruthaítear pointeoir nua ar an leithdháileadh céanna sa gcarn.
//! Nuair a dhéantar an pointeoir [`Rc`] deireanach le leithdháileadh ar leith a scriosadh, titeann an luach atá stóráilte sa leithdháileadh sin (dá ngairtear "inner value" go minic).
//!
//! Dícheadaíonn tagairtí roinnte i Rust sóchán de réir réamhshocraithe, agus ní haon eisceacht é [`Rc`]: de ghnáth ní féidir leat tagairt inathraithe a fháil do rud éigin taobh istigh de [`Rc`].
//! Má theastaíonn mutability uait, cuir [`Cell`] nó [`RefCell`] taobh istigh den [`Rc`];féach [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] úsáideann comhaireamh tagartha neamh-adamhach.
//! Ciallaíonn sé seo go bhfuil forchostais an-íseal, ach ní féidir [`Rc`] a sheoladh idir snáitheanna, agus dá bharr sin ní chuireann [`Rc`] [`Send`][send] i bhfeidhm.
//! Mar thoradh air sin, seiceálfaidh an tiomsaitheoir Rust *ag an am tiomsaithe* nach bhfuil tú ag seoladh [`Rc`] s idir snáitheanna.
//! Má theastaíonn comhaireamh tagartha adamhach ilsnáithe uait, úsáid [`sync::Arc`][arc].
//!
//! Is féidir an modh [`downgrade`][downgrade] a úsáid chun pointeoir [`Weak`] neamhúinéireachta a chruthú.
//! Is féidir pointeoir [`Weak`] a [`uasghrádú`][uasghrádú] d go [`Rc`], ach tabharfaidh sé seo [`None`] ar ais má tá an luach atá stóráilte sa leithdháileadh tite cheana féin.
//! Is é sin le rá, ní choinníonn leideanna `Weak` an luach taobh istigh den leithdháileadh beo;áfach, coimeádann siad * an leithdháileadh (an stór tacaíochta don luach istigh) beo.
//!
//! Ní thuigfear timthriall idir leideanna [`Rc`] go deo.
//! Ar an gcúis seo, úsáidtear [`Weak`] chun timthriallta a bhriseadh.
//! Mar shampla, d`fhéadfadh go mbeadh leideanna láidre [`Rc`] ag crann ó nóid tuismitheora go leanaí, agus leideanna [`Weak`] ó leanaí ar ais go dtí a dtuismitheoirí.
//!
//! `Rc<T>` dereferences go huathoibríoch ar `T` (tríd an [`Deref`] trait), ionas gur féidir leat modhanna `T` a ghlaoch ar luach de chineál [`Rc<T>`][`Rc`].
//! Chun a sheachaint troideanna ainm le `modhanna T` ar, na modhanna [`Rc<T>`][`Rc`] féin feidhmeanna a bhaineann, ar a dtugtar ag baint úsáide as [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Is féidir comhréir láncháilithe a thabhairt freisin ar chur chun feidhme traits cosúil le `Clone`.
//! Is fearr le daoine áirithe comhréir láncháilithe a úsáid, ach is fearr le daoine eile comhréir modh-ghlaonna a úsáid.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Comhréir modh-ghlao
//! let rc2 = rc.clone();
//! // Comhréir láncháilithe
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] Ní chuireann auto-téigh i go `T`, toisc nach féidir an luach istigh a bheith thit cheana féin.
//!
//! # Tagairtí clónála
//!
//! Déantar tagairt nua don leithdháileadh céanna a chruthú le pointeoir comhaireamh tagartha atá ann cheana trí úsáid a bhaint as an `Clone` trait a cuireadh i bhfeidhm le haghaidh [`Rc<T>`][`Rc`] agus [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Is ionann an dá chomhréir thíos.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a agus b araon dírithe ar an áit chuimhne chéanna le foo.
//! ```
//!
//! Is í an chomhréir `Rc::clone(&from)` an ceann is idiomatacha toisc go dtugann sí brí an chóid níos sainráite.
//! Sa sampla thuas, déanann an chomhréir seo níos éasca a fheiceáil go bhfuil tagairt nua á chruthú ag an gcód seo seachas ábhar iomlán foo a chóipeáil.
//!
//! # Examples
//!
//! Smaoinigh ar chás ina bhfuil tacar `Gadget 'faoi úinéireacht `Owner` ar leith.
//! Ba mhaith linn go bhfuil ár `pointe Gadget`s a `Owner`.Ní féidir linn é seo a dhéanamh le húinéireacht uathúil, mar d`fhéadfadh go mbaineann níos mó ná gadget amháin leis an `Owner` céanna.
//! [`Rc`] ligeann dúinn `Owner` a roinnt idir iolraí `Gadget`s, agus an `Owner` a bheith leithdháilte chomh fada le haon phointí `Gadget` air.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... réimsí eile
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... réimsí eile
//! }
//!
//! fn main() {
//!     // Cruthaigh `Owner` comhaireamh tagartha.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Cruthaigh `Gadget`s nach a bhaineann le `gadget_owner`.
//!     // Trí chlónáil ar an `Rc<Owner>` tugtar pointeoir nua dúinn ar an leithdháileadh `Owner` céanna, ag méadú an chomhaireamh tagartha sa phróiseas.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Déan ár n-athróg áitiúil `gadget_owner` a dhiúscairt.
//!     drop(gadget_owner);
//!
//!     // In ainneoin gur thit `gadget_owner`, táimid fós in ann ainm an `Owner` de na `Gadget`s a phriontáil.
//!     // Tá sé seo toisc nár thit muid ach `Rc<Owner>` amháin, ní an `Owner` a dtugann sé aird air.
//!     // Fad a bheidh `Rc<Owner>` eile dírithe ar an leithdháileadh `Owner` céanna, fanfaidh sé beo.
//!     // An teilgean réimse `gadget1.owner.name` Oibríonn gheall `Rc<Owner>` dereferences go huathoibríoch go dtí `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Ag deireadh na feidhme, déantar `gadget1` agus `gadget2` a scriosadh, agus in éineacht leo tá na tagairtí comhaireamh deiridh dár `Owner`.
//!     // Gadget Fear Faigheann scriosta anois chomh maith.
//!     //
//! }
//! ```
//!
//! Má athraíonn ár riachtanais, agus ní mór dúinn freisin a bheith in ann trasnú ó `Owner` go `Gadget`, beidh fadhbanna againn.
//! Tugann pointeoir [`Rc`] ó `Owner` go `Gadget` timthriall isteach.
//! Ciallaíonn sé seo nach féidir a gcomhaireamh tagartha a bhaint amach 0 riamh, agus ní scriosfar an leithdháileadh go deo:
//! sceitheadh cuimhne.D`fhonn dul timpeall air seo, is féidir linn leideanna [`Weak`] a úsáid.
//!
//! I ndáiríre déanann Rust rud beag deacair an lúb seo a tháirgeadh ar an gcéad dul síos.D`fhonn dhá luach a bhaint amach a dhíríonn ar a chéile, ní foláir ceann acu a bheith inathraithe.
//! Tá sé seo deacair toisc [`Rc`] Forfheidhmíonn sábháilteachta gcuimhne ag amháin a thabhairt i gcrích tagairtí roinnte don luach wraps sé, agus nach bhfuil siad ar cheadú mutation díreach.
//! Ní mór dúinn an chuid den luach a theastaíonn uainn a threisiú i [`RefCell`], a sholáthraíonn *mutability taobh istigh*: modh chun mutability a bhaint amach trí thagairt roinnte.
//! [`RefCell`] cuireann sé rialacha iasachtaíochta Rust i bhfeidhm ag am rith.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... réimsí eile
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... réimsí eile
//! }
//!
//! fn main() {
//!     // Cruthaigh `Owner` comhaireamh tagartha.
//!     // Tabhair faoi deara gur chuir muid vector an `Úinéara` de`Gadget`s taobh istigh de `RefCell` ionas gur féidir linn é a threisiú trí thagairt roinnte.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Cruthaigh `Gadget`s a bhaineann le `gadget_owner`, mar a rinneadh cheana.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Cuir an `Gadget`s a `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` Críochnaíonn fháil ar iasacht dinimiciúil anseo.
//!     }
//!
//!     // Iterate thar ár `Gadget`s, ag priontáil a gcuid sonraí amach.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` Is `Weak<Gadget>`.
//!         // Ós rud é nach féidir le leideanna `Weak` a ráthú go bhfuil an leithdháileadh fós ann, caithfimid `upgrade` a ghlaoch, a thugann `Option<Rc<Gadget>>` ar ais.
//!         //
//!         //
//!         // Sa chás seo tá a fhios againn go bhfuil an leithdháileadh fós ann, mar sin níl againn ach `unwrap` an `Option`.
//!         // I gclár níos casta, b`fhéidir go mbeidh láimhseáil earráide galánta ag teastáil uait le haghaidh toradh `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Ag deireadh na feidhme, déantar `gadget_owner`, `gadget1`, agus `gadget2` a scriosadh.
//!     // Níl aon leideanna láidre (`Rc`) ann anois maidir leis na giuirléidí, mar sin déantar iad a scriosadh.
//!     // Déanann sé seo an comhaireamh tagartha ar Gadget Man a nialasú, agus mar sin déantar é a scriosadh freisin.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Is cruthúnas repr(C) go future é seo i gcoinne athordú allamuigh féideartha, a chuirfeadh isteach ar [into|from]_raw() sábháilte de chineálacha istigh in-aistrithe.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Pointeoir comhaireamh tagartha aon-snáithe.Seasann 'Rc' do 'Tagairt
/// Counted'.
///
/// Féach an [module-level documentation](./index.html) le haghaidh tuilleadh sonraí.
///
/// Is feidhmeanna gaolmhara iad modhanna bunúsacha `Rc`, rud a chiallaíonn go gcaithfidh tú glaoch orthu mar eg, [`Rc::get_mut(&mut value)`][get_mut] in ionad `value.get_mut()`.
/// Seachnaíonn sé seo salach modhanna den chineál istigh `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Tá an neamhshábháilteacht seo ceart go leor mar gheall ar cé go bhfuil an Rc seo beo táimid cinnte go bhfuil an pointeoir istigh bailí.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Constructs a `Rc<T>` nua.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Tá pointeoir lag intuigthe ann atá faoi úinéireacht na leideanna láidre go léir, rud a chinntíonn nach saorann an scriosóir lag an leithdháileadh fad a bhíonn an scriosóir láidir ag rith, fiú má stóráiltear an pointeoir lag taobh istigh den cheann láidir.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Tógann `Rc<T>` nua ag baint úsáide as tagairt lag dó féin.
    /// Beidh luach `None` mar thoradh ar iarracht a dhéanamh an tagairt lag a uasghrádú sula bhfillfidh an fheidhm seo.
    ///
    /// Mar sin féin, féadfar an tagairt lag a chlónáil go saor agus a stóráil le húsáid níos déanaí.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... níos mó réimsí
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Tóg an taobh istigh sa stát "uninitialized" le tagairt lag amháin.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Tá sé tábhachtach nach dtabharfaimid suas úinéireacht ar an bpointeoir lag, nó eile d`fhéadfaí an chuimhne a shaoradh faoin am a fhillfidh `data_fn`.
        // Má bhíomar ag iarraidh i ndáiríre chun úinéireacht pas, d'fhéadfadh muid a chruthú pointeoir lag sa bhreis dúinn féin, ach bheadh sé seo mar thoradh nuashonruithe sa bhreis ar an líon tagartha lag ní a d'fhéadfadh a bheith riachtanach ar shlí eile.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Ba cheart tagairtí láidre féin i dteannta a tagairt lag roinnte, ní amhlaidh a théann siad ar an destructor le haghaidh ár tagartha lag d'aois.
        //
        mem::forget(weak);
        strong
    }

    /// Tógann `Rc` nua le hábhar neamhbheartaithe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Tosú tosaigh:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Constructs a `Rc` nua le hábhair uninitialized, leis an chuimhne á líonadh le `0` bytes.
    ///
    ///
    /// Féach [`MaybeUninit::zeroed`][zeroed] le haghaidh samplaí d`úsáid cheart agus mhícheart an mhodha seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Tógann `Rc<T>` nua, ag cur earráide ar ais má theipeann ar an leithdháileadh
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Tá pointeoir lag intuigthe ann atá faoi úinéireacht na leideanna láidre go léir, rud a chinntíonn nach saorann an scriosóir lag an leithdháileadh fad a bhíonn an scriosóir láidir ag rith, fiú má stóráiltear an pointeoir lag taobh istigh den cheann láidir.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Tógann `Rc` nua le hábhar neamhbheartaithe, ag cur earráide ar ais má theipeann ar an leithdháileadh
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Tosú tosaigh:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Tógann `Rc` nua le hábhar neamhbheartaithe, agus an chuimhne á líonadh le bearta `0`, ag cur earráide ar ais má theipeann ar an leithdháileadh
    ///
    ///
    /// Féach [`MaybeUninit::zeroed`][zeroed] le haghaidh samplaí d`úsáid cheart agus mhícheart an mhodha seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Tógann `Pin<Rc<T>>` nua.
    /// Mura gcuireann `T` `Unpin` i bhfeidhm, ansin beidh `value` pinned sa chuimhne agus ní féidir é a bhogadh.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Tuairisceáin an luach istigh, má tá go díreach amháin tagairt láidir na `Rc`.
    ///
    /// Seachas sin, tá an [`Err`] ais leis an `Rc` gcéanna ritheadh i.
    ///
    ///
    /// Éireoidh leis seo fiú má tá tagairtí laga gan íoc ann.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // cóipeáil an réad atá ann

                // Cuir in iúl do Weaks nach féidir iad a chur chun cinn tríd an gcomhaireamh láidir a laghdú, agus ansin an pointeoir intuigthe "strong weak" a bhaint agus an loighic titim a láimhseáil trí lagú bréige a dhéanamh.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Tógann sé slice nua comhaireamh tagartha le hábhar neamhbheartaithe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Tosú tosaigh:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Tógann sé slice nua comhaireamh tagartha le hábhar neamhbheartaithe, agus an chuimhne á líonadh le bearta `0`.
    ///
    ///
    /// Féach [`MaybeUninit::zeroed`][zeroed] le haghaidh samplaí d`úsáid cheart agus mhícheart an mhodha seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Tiontaíonn sé go `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Mar is amhlaidh le [`MaybeUninit::assume_init`], is faoin té atá ag glaoch a ráthú go bhfuil an luach istigh i riocht tosaigh i ndáiríre.
    ///
    /// Má ghlaotar air seo nuair nach bhfuil an t-ábhar tosaithe go hiomlán fós is cúis le hiompar neamhshainithe láithreach.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Tosú tosaigh:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Tiontaíonn sé go `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Mar is amhlaidh le [`MaybeUninit::assume_init`], is faoin té atá ag glaoch a ráthú go bhfuil an luach istigh i riocht tosaigh i ndáiríre.
    ///
    /// Má ghlaotar air seo nuair nach bhfuil an t-ábhar tosaithe go hiomlán fós is cúis le hiompar neamhshainithe láithreach.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Tosú tosaigh:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Itheann an `Rc`, ag filleadh an pointeora fillte.
    ///
    /// Chun sceitheadh cuimhne a sheachaint caithfear an pointeoir a thiontú ar ais go `Rc` agus [`Rc::from_raw`][from_raw] á úsáid.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Soláthraíonn pointeoir amh do na sonraí.
    ///
    /// Ní dhéantar difear do na comhaireamh ar bhealach ar bith agus ní ídítear an `Rc`.
    /// Tá an pointeoir bailí chomh fada agus go bhfuil comhaireamh láidir sa `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SÁBHÁILTEACHT: Ní féidir leis seo dul trí Deref::deref nó Rc::inner mar gheall
        // éilítear é seo chun foinse raw/mut a choinneáil sa chaoi is go m.sh.
        // `get_mut` Is féidir a scríobh tríd an pointeoir tar éis an Rc aisghabháil trí `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Tógann `Rc<T>` ó phointeoir amh.
    ///
    /// Ní foláir an pointeoir amh a bheith curtha ar ais roimhe seo le glao ar [`Rc<U>::into_raw`][into_raw] áit a gcaithfidh `U` an méid agus an t-ailíniú céanna a bheith ag `T`.
    /// Tá sé seo fíor go fánach más `U` é `U`.
    /// Tabhair faoi deara más rud é nach `T` é `U` ach go bhfuil an méid agus an t-ailíniú céanna aige, tá sé seo go bunúsach cosúil le tagairtí aistrithe de chineálacha éagsúla.
    /// Féach [`mem::transmute`][transmute] chun tuilleadh faisnéise a fháil faoi na srianta atá i bhfeidhm sa chás seo.
    ///
    /// Caithfidh úsáideoir `from_raw` a chinntiú nach dtitfear luach sonrach `T` ach uair amháin.
    ///
    /// Tá an fheidhm seo neamhshábháilte toisc go bhféadfadh neamhshábháilteacht cuimhne a bheith mar thoradh ar úsáid mhíchuí, fiú mura ndéantar rochtain ar an `Rc<T>` a cuireadh ar ais riamh.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Tiontaigh ar ais go `Rc` chun sceitheadh a chosc.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Bheadh glaonna breise ar `Rc::from_raw(x_ptr)` neamhshábháilte ó thaobh cuimhne de.
    /// }
    ///
    /// // Scaoileadh an chuimhne nuair a chuaigh `x` as a raon feidhme thuas, mar sin tá `x_ptr` ag crochadh anois!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Déan an fritháireamh a aisiompú chun an RcBox bunaidh a fháil.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Cruthaíonn pointeoir [`Weak`] nua leis an leithdháileadh seo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Déan cinnte nach gcruthóimid Lag lag
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Faigheann líon na leideanna [`Weak`] leis an leithdháileadh seo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Faigheann líon na leideanna láidre (`Rc`) leis an leithdháileadh seo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Tuairisceáin `true` mura bhfuil aon leideanna `Rc` nó [`Weak`] eile leis an leithdháileadh seo.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Filleann tagairt inathraithe ar an `Rc` a thugtar, mura bhfuil aon leideanna `Rc` nó [`Weak`] eile leis an leithdháileadh céanna.
    ///
    ///
    /// Tuairisceáin [`None`] ar shlí eile, toisc nach bhfuil sé sábháilte luach comhroinnte a threáitear.
    ///
    /// Féach freisin [`make_mut`][make_mut], a thabharfaidh [`clone`][clone] an luach istigh nuair a bheidh leideanna eile ann.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Seoltar tagairt inathraithe ar ais sa `Rc` a tugadh, gan aon seiceáil.
    ///
    /// Féach freisin [`get_mut`], atá sábháilte agus a dhéanann seiceálacha iomchuí.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Níor cheart aon leideanna `Rc` nó [`Weak`] eile a bhaineann leis an leithdháileadh céanna a dhí-chosaint ar feadh ré na hiasachta ar ais.
    ///
    /// Is fíor an cás é mura bhfuil aon leideanna den sórt sin ann, mar shampla díreach tar éis `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Bímid cúramach gan *gan* tagairt a chruthú a chlúdóidh na réimsí "count", mar go mbeadh sé seo ag teacht salach ar rochtain ar na comhaireamh tagartha (e.g.
        // ag `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Tuairisceáin `true` má dhíríonn an dá `Rc ar an leithdháileadh céanna (i vein cosúil le [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Déanann sé tagairt inathraithe don `Rc` a thugtar.
    ///
    /// Má tá leideanna `Rc` eile leis an leithdháileadh céanna, ansin cuirfidh `make_mut` [`clone`] an luach istigh le leithdháileadh nua chun úinéireacht uathúil a chinntiú.
    /// Tugtar clón-ar-scríobh air seo freisin.
    ///
    /// Mura bhfuil aon leideanna `Rc` eile leis an leithdháileadh seo, déanfar leideanna [`Weak`] don leithdháileadh seo a dhícheangal.
    ///
    /// Féach freisin [`get_mut`], a dteipfidh air seachas clónáil.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Ní chlónfaidh mé rud ar bith
    /// let mut other_data = Rc::clone(&data);    // Sonraí istigh An mbeidh ní Clón
    /// *Rc::make_mut(&mut data) += 1;        // Clónáil sonraí istigh
    /// *Rc::make_mut(&mut data) += 1;        // Ní chlónfaidh mé rud ar bith
    /// *Rc::make_mut(&mut other_data) *= 2;  // Ní chlónfaidh mé rud ar bith
    ///
    /// // Anois díríonn `data` agus `other_data` ar leithdháiltí éagsúla.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] déanfar leideanna a dhícheangal:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Clónáil Gotta na sonraí, tá Rcs eile ann.
            // Réamh-leithdháileadh cuimhne chun ligean don luach clónáilte a scríobh go díreach.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // In ann na sonraí a ghoid, níl fágtha ach Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Bain tagairt intuigthe láidir-lag (ní gá lagú bréige a cheird anseo-tá a fhios againn gur féidir le Laigí eile glanadh suas dúinn)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Tá an neamhshábháilteacht seo ceart go leor mar gheall orainn a bheith cinnte gurb é an pointeoir a chuirtear ar ais an pointeoir *amháin* a thabharfar ar ais do T.
        // Ráthaítear gurb é 1 ár gcomhaireamh tagartha ag an bpointe seo, agus d`éilíomar gur `mut` an `Rc<T>` féin, agus mar sin táimid ag filleadh an t-aon tagairt fhéideartha don leithdháileadh.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Déan iarracht an `Rc<dyn Any>` a ísliú go cineál coincréite.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Leithdháileann sé `RcBox<T>` le dóthain spáis le haghaidh luach istigh nach féidir a bheith neamhshonraithe sa chás go bhfuil an leagan amach curtha ar fáil ag an luach.
    ///
    /// Tugtar feidhm `mem_to_rcbox` leis an pointeoir sonraí agus caithfidh sí pointeoir (a d`fhéadfadh a bheith ramhar) don `RcBox<T>` a thabhairt ar ais.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Ríomh an leagan amach ag baint úsáide as an leagan amach luacha tugtha.
        // Roimhe seo, ríomhadh an leagan amach ar an slonn `&*(ptr as* const RcBox<T>)`, ach chruthaigh sé seo tagairt mhí-sínithe (féach #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Leithdháileann sé `RcBox<T>` le dóthain spáis le haghaidh luach inmheánach nach féidir a bheith neamhshonraithe sa chás go bhfuil an leagan amach curtha ar fáil ag an luach, agus earráid a thabhairt ar ais má theipeann ar an leithdháileadh.
    ///
    ///
    /// Tugtar feidhm `mem_to_rcbox` leis an pointeoir sonraí agus caithfidh sí pointeoir (a d`fhéadfadh a bheith ramhar) don `RcBox<T>` a thabhairt ar ais.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Ríomh an leagan amach ag baint úsáide as an leagan amach luacha tugtha.
        // Roimhe seo, ríomhadh an leagan amach ar an slonn `&*(ptr as* const RcBox<T>)`, ach chruthaigh sé seo tagairt mhí-sínithe (féach #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Leithdháileadh don leagan amach.
        let ptr = allocate(layout)?;

        // Cuir tús leis an RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Leithdháileann sé `RcBox<T>` le go leor spáis le haghaidh luach inmheánach neamhshábháilte
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Leithdháileadh don `RcBox<T>` ag baint úsáide as an luach tugtha.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Cóipeáil luach mar bhearta
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Saor an leithdháileadh gan a ábhar a ligean anuas
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Leithdháileann sé `RcBox<[T]>` leis an fhad a thugtar.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Cóipeáil eilimintí ón slice isteach i Rc <\[T\]> nua-leithdháilte
    ///
    /// Neamhshábháilte toisc go gcaithfidh an té atá ag glaoch úinéireacht a ghlacadh nó `T: Copy` a cheangal
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Tógann `Rc<[T]>` ó iterator ar eol a bheith de mhéid áirithe.
    ///
    /// Tá an t-iompar neamhshainithe má tá an méid mícheart.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Garda Panic agus clónáil ar eilimintí T.
        // I gcás panic, beidh na heilimintí a bhí scríofa isteach sa RcBox nua a fhágáil ar lár, ansin an chuimhne freed.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pointeoir go dtí an chéad eilimint
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Gach soiléir.Déan dearmad ar an garda ionas nach saorfaidh sé an RcBox nua.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Speisialtóireacht trait a úsáidtear le haghaidh `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Drops an `Rc`.
    ///
    /// Laghdóidh sé seo an comhaireamh láidir tagartha.
    /// Má shroicheann an comhaireamh láidir tagartha nialas is é an t-aon tagairtí eile (más ann dóibh) ná [`Weak`], mar sin déanaimid `drop` an luach istigh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Ní phriontálann sé rud ar bith
    /// drop(foo2);   // Priontaí "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // scrios an réad atá ann
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // bain an pointeoir intuigthe "strong weak" anois go bhfuil an t-ábhar scriosta againn.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Déanann sé clón den phointeoir `Rc`.
    ///
    /// Cruthaíonn sé seo pointeoir eile leis an leithdháileadh céanna, ag méadú an líon tagartha láidir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Cruthaíonn sé `Rc<T>` nua, leis an luach `Default` do `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack chun speisialtóireacht a cheadú ar `Eq` cé go bhfuil modh ag `Eq`.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Táimid ag déanamh na speisialtóireachta seo anseo, agus ní mar bharrfheabhsú níos ginearálta ar `&T`, mar gheall go gcuirfeadh sé costas ar gach seiceáil comhionannais ar thagairtí.
/// Glacaimid leis go n-úsáidtear `Rc`s chun luachanna móra a stóráil, atá mall le clónáil, ach atá trom freisin chun comhionannas a sheiceáil, rud a fhágann go n-íocfaidh an costas seo níos éasca.
///
/// Is dóichí freisin go mbeidh dhá chlón `Rc` ann, a bhfuil an luach céanna orthu, ná dhá `&T`.
///
/// Ní féidir linn é seo a dhéanamh ach nuair a d`fhéadfadh `T: Eq` mar `PartialEq` a bheith irreflexive d`aon ghnó.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Chomhionannas do dhá `Rc`s.
    ///
    /// Tá dhá `Rc` comhionann má tá a luachanna istigh comhionann, fiú má tá siad stóráilte i leithdháileadh difriúil.
    ///
    /// Má chuireann `T` freisin `Eq` (bheir reflexivity an chomhionannais), dhá `Rc`s go bhfuil pointe ar an leithdháileadh céanna comhionann i gcónaí.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Éagothroime do dhá `Rc`.
    ///
    /// Tá dhá `Rc 'neamhchothrom má tá a luachanna istigh neamhchothrom.
    ///
    /// Má chuireann `T` `Eq` i bhfeidhm freisin (le tuiscint ar athléimneacht an chomhionannais), ní bhíonn dhá `Rc a dhíríonn ar an leithdháileadh céanna neamhchothrom riamh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Comparáid pháirteach ar dhá `Rc.
    ///
    /// Déantar comparáid idir an dá cheann trí ghlaoch a chur ar `partial_cmp()` ar a luachanna istigh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Níos lú ná comparáid idir dhá `Rc '.
    ///
    /// Déantar comparáid idir an dá cheann trí ghlaoch a chur ar `<` ar a luachanna istigh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Comparáid 'Níos lú ná nó cothrom le' dhá Rc.
    ///
    /// Déantar comparáid idir an dá cheann trí ghlaoch a chur ar `<=` ar a luachanna istigh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Comparáid níos mó ná dhá `Rc`.
    ///
    /// Déantar comparáid idir an dá cheann trí ghlaoch a chur ar `>` ar a luachanna istigh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Comparáid 'Níos mó ná nó cothrom le' dhá Rc.
    ///
    /// Déantar comparáid idir an dá cheann trí ghlaoch a chur ar `>=` ar a luachanna istigh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Comparáid idir dhá `Rc '.
    ///
    /// Tá an dá chur i gcomparáid trí ghlaoch `cmp()` ar a luachanna istigh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Leithdháileadh slice comhaireamh tagartha agus líon é trí chlónáil ar mhíreanna `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Leithroinn slice teaghrán comhaireamh tagartha agus cóipeáil `v` isteach ann.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Leithroinn slice teaghrán comhaireamh tagartha agus cóipeáil `v` isteach ann.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Bog réad i mboscaí chuig leithdháileadh nua, comhaireamh tagartha.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Leithdháileadh slice comhaireamh tagartha agus bog míreanna `v` isteach ann.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Lig don Vec a chuimhne a shaoradh, ach gan a bhfuil ann a scriosadh
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Glacann sé gach eilimint sa `Iterator` agus bailítear é i `Rc<[T]>`.
    ///
    /// # Saintréithe feidhmíochta
    ///
    /// ## An cás ginearálta
    ///
    /// Sa chás ginearálta, tá a bhailiú `Rc<[T]>` isteach déanta ag an gcéad bhailiú isteach i `Vec<T>`.Is é sin, agus an méid seo a leanas á scríobh:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// iompraíonn sé seo amhail is gur scríobh muid:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Tarlaíonn an chéad tacar leithdháiltí anseo.
    ///     .into(); // Tarlaíonn an dara leithdháileadh do `Rc<[T]>` anseo.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Leithdháilfidh sé seo a mhéad uair is gá chun an `Vec<T>` a thógáil agus ansin leithdháilfidh sé uair amháin chun an `Vec<T>` a iompú ina `Rc<[T]>`.
    ///
    ///
    /// ## Iterators ar a dtugtar fad
    ///
    /// Nuair a chuireann do `Iterator` `TrustedLen` agus tá sé de méid cruinn, beidh leithdháilte aonair a dhéanamh maidir le `Rc<[T]>`.Mar shampla:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Ní tharlaíonn ach leithdháileadh amháin anseo.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Speisialtóireacht trait a úsáidtear le bailiú i `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Is amhlaidh atá i gcás iteora `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SÁBHÁILTEACHT: Ní mór dúinn a chinntiú go bhfuil fad cruinn ag an iterator agus atá againn.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Titim ar ais go gnáthfheidhmiú.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` Is leagan de [`Rc`] go seilbh tagairt neamh-húinéir leithdháileadh bhainistiú.Is féidir teacht ar an leithdháileadh trí ghlaoch a chur ar [`upgrade`] ar an pointeoir `Weak`, a chuireann [`Rogha`]`<`[`Rc`] `ar ais<T>>`.
///
/// Ós rud é nach n-áirítear tagairt `Weak` i dtreo úinéireachta, ní choiscfidh sé an luach atá stóráilte sa leithdháileadh a thitim, agus ní thugann `Weak` féin aon ráthaíochtaí faoin luach atá fós ann.
/// Mar sin féadfaidh sé [`None`] a thabhairt ar ais nuair a bheidh [`uasghrádú`] d.
/// Tabhair faoi deara, áfach, go gcuireann tagairt `Weak` * cosc ar an leithdháileadh féin (an stór tacaíochta) a thuiscint.
///
/// Tá pointeoir `Weak` úsáideach chun tagairt shealadach a choinneáil don leithdháileadh arna bhainistiú ag [`Rc`] gan a luach inmheánach a chosc ó thit.
/// Úsáidtear é freisin chun tagairtí ciorclacha idir leideanna [`Rc`] a chosc, ós rud é nach gceadódh tagairtí úinéireachta frithpháirtí ceachtar [`Rc`] a thit.
/// Mar shampla, d`fhéadfadh go mbeadh leideanna láidre [`Rc`] ag crann ó nóid tuismitheora go leanaí, agus leideanna `Weak` ó leanaí ar ais go dtí a dtuismitheoirí.
///
/// Is é an bealach tipiciúil chun pointeoir `Weak` a fháil ná [`Rc::downgrade`] a ghlaoch.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Is `NonNull` é seo chun ligean do mhéid an chineáil seo a bharrfheabhsú in enums, ach ní pointeoir bailí é de ghnáth.
    //
    // `Weak::new` socraíonn sé seo go `usize::MAX` ionas nach gá dó spás a leithdháileadh ar an gcarn.
    // Ní luach é sin a bheidh ag pointeoir fíor riamh toisc go bhfuil ailíniú 2 ar a laghad ag RcBox.
    // Tá sé seo indéanta ach amháin nuair `T: Sized`;`T` neamhshábháilte riamh dangle.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Tógann `Weak<T>` nua, gan aon chuimhne a leithdháileadh.
    /// Tugann [`None`] glaoch ar [`upgrade`] ar an luach toraidh i gcónaí.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Cineál cúntóra chun rochtain a fháil ar na comhaireamh tagartha gan aon dearbhuithe a dhéanamh faoin réimse sonraí.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Tugann pointeoir amh ar ais don réad `T` a dtugann an `Weak<T>` seo aird air.
    ///
    /// Is é an t pointeoir bailí ach amháin má tá roinnt tagairtí láidre.
    /// Féadfaidh an pointeoir a bheith ag crochadh, gan síniú nó fiú [`null`] ar shlí eile.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Díríonn an dá rud ar an réad céanna
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Coinníonn an láidir anseo é beo, ionas gur féidir linn rochtain a fháil ar an réad fós.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ach ní níos mó.
    /// // Is féidir linn weak.as_ptr() a dhéanamh, ach bheadh iompar neamhshainithe mar thoradh ar an pointeoir a rochtain.
    /// // assert_eq! ("Dia duit", neamhshábháilte {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Má tá an pointeoir ag crochadh, cuirimid an sentinel ar ais go díreach.
            // Ní féidir seo a bheith ina ainm na payload bailí, mar go bhfuil an pálasta a laghad chomh ailíniú le RcBox (usize).
            ptr as *const T
        } else {
            // SÁBHÁILTEACHT: má fhilleann is_dangling bréagach, ansin tá an pointeoir dereferencable.
            // Féadfar an t-ualach pá a ísliú ag an bpointe seo, agus ní mór dúinn bunáitíocht a choinneáil, mar sin bain úsáid as ionramháil pointeoir amh.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Itheann sé an `Weak<T>` agus é a iompú ina phointeoir amh.
    ///
    /// Athraíonn sé seo an pointeoir lag ina pointeoir amh, agus úinéireacht úinéireachta tagartha lag amháin á chaomhnú aige (ní dhéantar an comhaireamh lag a mhodhnú leis an oibríocht seo).
    /// Is féidir é a iompú ar ais sa `Weak<T>` le [`from_raw`].
    ///
    /// Tá feidhm ag na srianta céanna maidir le rochtain a fháil ar sprioc an phointeora agus atá ag [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Athraíonn sé pointeoir amh a chruthaigh [`into_raw`] roimhe seo ar ais i `Weak<T>`.
    ///
    /// Is féidir é seo a úsáid chun tagairt láidir a fháil go sábháilte (trí ghlaoch a chur ar [`upgrade`] níos déanaí) nó chun an comhaireamh lag a thuiscint tríd an `Weak<T>` a ligean anuas.
    ///
    /// Glacann sé úinéireacht ar thagairt lag amháin (cé is moite de leideanna a chruthaigh [`new`], toisc nach leo féin aon rud; oibríonn an modh orthu fós).
    ///
    /// # Safety
    ///
    /// Caithfidh gur ón [`into_raw`] a tháinig an pointeoir agus caithfidh tagairt tagartha lag a bheith aige fós.
    ///
    /// Ceadaítear gurb é 0 an comhaireamh láidir nuair a ghlaofar air seo.
    /// Mar sin féin, glacann sé seo úinéireacht ar thagairt lag amháin a léirítear faoi láthair mar phointeoir amh (ní dhéantar an comhaireamh lag a mhodhnú leis an oibríocht seo) agus dá bhrí sin caithfear é a phéireáil le glao roimhe seo ar [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Laghdaigh an comhaireamh lag deireanach.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Féach Weak::as_ptr le haghaidh comhthéacs ar an gcaoi a ndíorthaítear an pointeoir ionchuir.

        let ptr = if is_dangling(ptr as *mut T) {
            // Is é seo a Lag dangling.
            ptr as *mut RcBox<T>
        } else {
            // Seachas sin, táimid ag ráthaíocht gur ó lagmhisneach a tháinig an pointeoir.
            // SÁBHÁILTEACHT: tá sé sábháilte glaoch ar data_offset, toisc go dtagraíonn ptr do T. fíor (a d`fhéadfadh a bheith tite).
            let offset = unsafe { data_offset(ptr) };
            // Dá bhrí sin, a fhreaschur táimid ag fritháireamh ó fháil ar an RcBox fad.
            // SÁBHÁILTEACHT: tháinig an pointeoir ó Lag, mar sin tá an fritháireamh seo sábháilte.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SÁBHÁILTEACHT: ní mór dúinn a aisghabháil anois ar an pointeoir Lag bunaidh, ionas gur féidir a chruthú ar an lag.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Iarrachtaí an pointeoir `Weak` a uasghrádú go [`Rc`], ag cur moill ar thitim an luach istigh má éiríonn leis.
    ///
    ///
    /// Tuairisceáin [`None`] má tá an luach istigh a fhágáil ar lár ó shin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Scrios gach leideanna láidre.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Faigheann líon na leideanna (`Rc`) láidir dírithe ar an leithdháileadh.
    ///
    /// Dá `self` cruthaithe ag baint úsáide [`Weak::new`], beidh sé seo ar ais 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Faigheann líon na leideanna `Weak` atá dírithe ar an leithdháileadh seo.
    ///
    /// Mura bhfanann aon leideanna láidre, fillfidh sé seo nialas.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // dealraigh an ptr lag intuigthe
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Tuairisceáin `None` nuair a bhíonn an pointeoir ag crochadh agus mura leithdháiltear `RcBox`, (ie, nuair a chruthaigh `Weak::new` an `Weak` seo).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Táimid go cúramach chun *nach* chruthú is tagairt í a chlúdaíonn an réimse "data", de réir mar a réimse a mutated i gcomhthráth (mar shampla, má tá an `Rc` caite thit, an réimse sonraí a thit in-áit).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Tuairisceáin `true` má dhíríonn an dá `Lag ar an leithdháileadh céanna (cosúil le [`ptr::eq`]), nó mura ndéanann an dá rud aon leithdháileadh (toisc gur cruthaíodh iad le `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Ós rud é go ndéanann sé seo comparáid idir leideanna, ciallaíonn sé go mbeidh `Weak::new()` cothrom lena chéile, cé nach ndíríonn siad ar aon leithdháileadh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Comparáid a `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Drops an pointeoir `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ní phriontálann sé rud ar bith
    /// drop(foo);        // Priontaí "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // tosaíonn an comhaireamh lag ag 1, agus ní rachaidh sé go nialas ach má tá na leideanna láidre go léir imithe.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Dhéanann Clón an pointeoir `Weak` go pointí leithdháileadh céanna.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Tógann `Weak<T>` nua, ag leithdháileadh cuimhne do `T` gan é a thionscnamh.
    /// Tugann [`None`] glaoch ar [`upgrade`] ar an luach toraidh i gcónaí.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Rinneamar seiceáil_add anseo chun déileáil le mem::forget go sábháilte.Go háirithe
// má dhéanann tú mem::forget Rcs (nó Weaks), is féidir leis an athchomhaireamh a bheith ag cur thar maoil, agus ansin is féidir leat an leithdháileadh a shaoradh fad is atá Rcs (nó Weaks) gan íoc.
//
// Déanaimid ginmhilleadh toisc gur cás chomh díghrádaithe é seo nach bhfuil mórán measa againn ar a dtarlaíonn-níor cheart go mbeadh taithí ag aon fhíorchlár air seo riamh.
//
// Ba cheart go mbeadh forchostas neamhbhríoch leis seo ós rud é nach gá duit iad seo a chlónáil i Rust a bhuíochas le húinéireacht agus le seimineár gluaiseachta.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Ba mhaith linn ginmhilleadh a dhéanamh ar ró-shreabhadh in ionad an luach a ísliú.
        // Ní bheidh an comhaireamh tagartha nialas go deo nuair a ghlaofar air seo;
        // mar sin féin, cuirimid ginmhilleadh isteach anseo chun LLVM a thabhairt le tuiscint ag barrfheabhsú a chailltear ar shlí eile.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Ba mhaith linn ginmhilleadh a dhéanamh ar ró-shreabhadh in ionad an luach a ísliú.
        // Ní bheidh an comhaireamh tagartha nialas go deo nuair a ghlaofar air seo;
        // mar sin féin, cuirimid ginmhilleadh isteach anseo chun LLVM a thabhairt le tuiscint ag barrfheabhsú a chailltear ar shlí eile.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Faigh an fritháireamh laistigh de `RcBox` don ualach pá taobh thiar de phointeoir.
///
/// # Safety
///
/// Caithfidh an pointeoir tagairt do (agus meiteashonraí bailí a bheith aige do) sampla T a bhí bailí roimhe seo, ach ceadaítear an T a thitim.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Ailínigh an luach unsized go dtí deireadh an RcBox.
    // Toisc go bhfuil RcBox repr(C), beidh sé i gcónaí ar an réimse deireanach sa chuimhne.
    // SÁBHÁILTEACHT: ós rud é gurb iad na cineálacha neamhshábháilte amháin is féidir slisní, rudaí trait,
    // agus cineálacha seachtracha, is leor an ceanglas sábháilteachta ionchuir faoi láthair chun riachtanais align_of_val_raw a shásamh;tá sé seo go mion chun feidhme an teanga nach féidir a bheith ag brath air taobh amuigh de std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}