#![stable(feature = "rust1", since = "1.0.0")]

//! Leideanna comhaireamh tagartha slán-snáithe.
//!
//! Féach cáipéisíocht [`Arc<T>`][Arc] le haghaidh tuilleadh sonraí.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Teorainn bhog ar an méid tagairtí is féidir a dhéanamh do `Arc`.
///
/// Giorróidh dul os cionn na teorann seo do chlár (cé nach gá) ag tagairtí _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// Ní thacaíonn ThreadSanitizer le fálta cuimhne.
// Chun tuairiscí bréagacha dearfacha i bhfeidhmiú Arc/Lag a sheachaint bain úsáid as ualaí adamhacha le haghaidh sioncrónaithe ina ionad.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Pointeoir comhaireamh tagartha snáithe-sábháilte.Seasann 'Arc' do 'Atomically Reference Counted'.
///
/// Soláthraíonn an cineál `Arc<T>` úinéireacht roinnte de luach den chineál `T`, leithdháileadh sa gcarn.Nuair a dhéantar [`clone`][clone] a agairt ar `Arc` cruthaítear sampla `Arc` nua, a dhíríonn ar an leithdháileadh céanna ar an gcarn agus an fhoinse `Arc`, agus comhaireamh tagartha á mhéadú.
/// Nuair a bhíonn an `Arc` pointeoir seo caite le leithdháileadh ar leith scriosta, an luach a stóráil sa leithdháileadh (go minic dá ngairtear "inner value") atá thit freisin.
///
/// Dícheadaíonn tagairtí roinnte i Rust sóchán de réir réamhshocraithe, agus ní haon eisceacht é `Arc`: de ghnáth ní féidir leat tagairt inathraithe a fháil do rud éigin taobh istigh de `Arc`.Más gá duit mutate trí `Arc`, bain úsáid as [`Mutex`][mutex], [`RwLock`][rwlock], nó ceann de na cineálacha [`Atomic`][atomic].
///
/// ## Sábháilteacht Snáithe
///
/// Murab ionann agus [`Rc<T>`], úsáideann `Arc<T>` oibríochtaí adamhacha chun a chomhaireamh tagartha.Ciallaíonn sé seo go bhfuil sé sábháilte le snáithe.Is é an míbhuntáiste ná go bhfuil oibríochtaí adamhacha níos costasaí ná gnáthrochtana cuimhne.Mura bhfuil leithdháiltí comhaireamh tagartha á roinnt agat idir snáitheanna, smaoinigh ar [`Rc<T>`] a úsáid le haghaidh lasnairde níos ísle.
/// [`Rc<T>`] is réamhshocrú sábháilte é, toisc go ngabhfaidh an tiomsaitheoir le haon iarracht [`Rc<T>`] a sheoladh idir snáitheanna.
/// Mar sin féin, d'fhéadfadh leabharlann roghnú `Arc<T>` d'fhonn a thabhairt do thomhaltóirí leabharlainne breis solúbthachta.
///
/// `Arc<T>` cuirfidh sé [`Send`] agus [`Sync`] i bhfeidhm chomh fada agus a chuirfidh an `T` [`Send`] agus [`Sync`] i bhfeidhm.
/// Cén fáth nach féidir leat cineál `T` neamh-snáithe-sábháilte a chur i `Arc<T>` chun é a dhéanamh sábháilte ó thaobh snáithe?D`fhéadfadh sé seo a bheith beagáinín frith-iomasach ar dtús: tar éis an tsaoil, nach pointe sábháilteachta snáithe `Arc<T>` é?Is í an eochair é seo: déanann `Arc<T>` go bhfuil sé sábháilte snáithe a bheith aige ar ilúinéireacht ar na sonraí céanna, ach ní chuireann sé sábháilteacht snáithe lena chuid sonraí.
///
/// Smaoinigh ar `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] ní [`Sync`] é, agus má bhí `Arc<T>` i gcónaí [`Send`], `Arc <` [`RefCell<T>bheadh`]`>`chomh maith.
/// Ach ansin bheadh fadhb againn:
/// [`RefCell<T>`] nach bhfuil snáithe sábháilte;coimeádann sé súil ar an líon iasachtaí trí oibríochtaí neamh-adamhacha a úsáid.
///
/// Sa deireadh, ciallaíonn sé seo go mb`fhéidir go mbeidh ort péire `Arc<T>` a phéireáil le cineál éigin [`std::sync`], [`Mutex<T>`][mutex] de ghnáth.
///
/// ## Timthriallta briste le `Weak`
///
/// Is féidir an modh [`downgrade`][downgrade] a úsáid chun pointeoir [`Weak`] neamhúinéireachta a chruthú.Is féidir pointeoir [`Weak`] a [`uasghrádú`][uasghrádú] d go `Arc`, ach fillfidh sé seo [`None`] má tá an luach atá stóráilte sa leithdháileadh tite cheana féin.
/// Is é sin le rá, ní choinníonn leideanna `Weak` an luach taobh istigh den leithdháileadh beo;áfach, coimeádann siad * an leithdháileadh (an stór tacaíochta don luach) beo.
///
/// Ní bheidh timthriall idir leideanna `Arc` a deallocated.
/// Ar an gcúis seo, úsáidtear [`Weak`] chun timthriallta a bhriseadh.Mar shampla, d'fhéadfadh crann bheith leideanna `Arc` láidir ó nóid thuismitheoir do leanaí, agus leideanna [`Weak`] ó leanaí ar ais go dtí a dtuismitheoirí.
///
/// # Tagairtí clónála
///
/// Ag cruthú tagairt nua ó pointeoir tagartha-chomhaireamh atá ann ag déanamh a ag baint úsáide as an trait `Clone` i bhfeidhm do [`Arc<T>`][Arc] agus [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Is ionann an dá chomhréir thíos.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // is Arcs iad a, b, agus foo a dhíríonn ar an áit chuimhne chéanna
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` dereferences go huathoibríoch ar `T` (tríd an [`Deref`][deref] trait), ionas gur féidir leat modhanna `T` a ghlaoch ar luach de chineál `Arc<T>`.Chun comhrianta ainm le modhanna `T` a sheachaint, is feidhmeanna gaolmhara iad modhanna `Arc<T>` féin, ar a dtugtar [fully qualified syntax] a úsáid:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>`Is féidir implementations'sde traits cosúil `Clone` a dtugtar freisin ag baint úsáide as error láncháilithe.
/// Is fearr le daoine áirithe comhréir láncháilithe a úsáid, ach is fearr le daoine eile comhréir modh-ghlaonna a úsáid.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Comhréir modh-ghlao
/// let arc2 = arc.clone();
/// // Comhréir láncháilithe
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] Ní chuireann auto-téigh i go `T`, toisc nach féidir an luach istigh a bheith thit cheana féin.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Roinnt sonraí dochorraithe a roinnt idir snáitheanna:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Tabhair faoi deara go bhfuil muid ag **nach bhfuil** na tástálacha a reáchtáil anseo.
// Na tógálaithe windows fháil Super sásta má outlives snáithe an príomh snáithe agus ansin bealaí amach ag an am céanna (rud deadlocks) mar sin a sheachaint againn ach seo go hiomlán más rud é nach ag rith na tástálacha.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Roinnt a [`AtomicUsize`] mutable:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Féach an [`rc` documentation][rc_examples] le haghaidh tuilleadh samplaí de chomhaireamh tagartha i gcoitinne.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` is leagan de [`Arc`] é a bhfuil tagairt neamhúinéireachta aige don leithdháileadh bainistithe.
/// Is féidir teacht ar an leithdháileadh trí [`upgrade`] a ghlaoch ar an pointeoir `Weak`, a fhilleann [`Rogha`]`<`[`Arc`] `<T>>`.
///
/// Ós rud é nach n-áirítear tagairt `Weak` i dtreo úinéireachta, ní choiscfidh sé an luach atá stóráilte sa leithdháileadh a thitim, agus ní thugann `Weak` féin aon ráthaíochtaí faoin luach atá fós ann.
///
/// Mar sin féadfaidh sé [`None`] a thabhairt ar ais nuair a bheidh [`uasghrádú`] d.
/// Tabhair faoi deara, áfach, go gcuireann tagairt `Weak` * cosc ar an leithdháileadh féin (an stór tacaíochta) a thuiscint.
///
/// Tá pointeoir `Weak` úsáideach chun tagairt shealadach a choinneáil don leithdháileadh arna bhainistiú ag [`Arc`] gan a luach inmheánach a chosc ó thit.
/// Úsáidtear é freisin chun tagairtí ciorclacha idir leideanna [`Arc`] a chosc, ós rud é nach gceadódh tagairtí úinéireachta frithpháirtí ceachtar [`Arc`] a thit.
/// Mar shampla, d'fhéadfadh crann bheith leideanna [`Arc`] láidir ó nóid thuismitheoir do leanaí, agus leideanna `Weak` ó leanaí ar ais go dtí a dtuismitheoirí.
///
/// Is é an bealach tipiciúil chun pointeoir `Weak` a fháil ná [`Arc::downgrade`] a ghlaoch.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Is `NonNull` é seo chun ligean do mhéid an chineáil seo a bharrfheabhsú in enums, ach ní pointeoir bailí é de ghnáth.
    //
    // `Weak::new` socraíonn sé seo go `usize::MAX` ionas nach gá dó spás a leithdháileadh ar an gcarn.
    // Ní luach é sin a bheidh ag pointeoir fíor riamh toisc go bhfuil ailíniú 2 ar a laghad ag RcBox.
    // Tá sé seo indéanta ach amháin nuair `T: Sized`;`T` neamhshábháilte riamh dangle.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Is cruthúnas repr(C) go future é seo i gcoinne athordú allamuigh féideartha, a chuirfeadh isteach ar [into|from]_raw() sábháilte de chineálacha istigh in-aistrithe.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // feidhmíonn an luach usize::MAX mar fhairtheoir le haghaidh "locking" go sealadach an cumas leideanna laga a uasghrádú nó cinn láidre a íosghrádú;úsáidtear é seo chun rásaí in `make_mut` agus `get_mut` a sheachaint.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Tógann `Arc<T>` nua.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Cuir tús leis an gcomhaireamh pointeoir lag mar 1 arb é an pointeoir lag atá i seilbh na leideanna láidre (kinda) go léir, féach std/rc.rs le haghaidh tuilleadh faisnéise
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Tógann `Arc<T>` nua ag baint úsáide as tagairt lag dó féin.
    /// Beidh luach `None` mar thoradh ar iarracht a dhéanamh an tagairt lag a uasghrádú sula bhfillfidh an fheidhm seo.
    /// Mar sin féin, féadfar an tagairt lag a chlónáil go saor agus a stóráil le húsáid níos déanaí.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Tóg an taobh istigh sa stát "uninitialized" le tagairt lag amháin.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Tá sé tábhachtach nach dtabharfaimid suas úinéireacht ar an bpointeoir lag, nó eile d`fhéadfaí an chuimhne a shaoradh faoin am a fhillfidh `data_fn`.
        // Má bhíomar ag iarraidh i ndáiríre chun úinéireacht pas, d'fhéadfadh muid a chruthú pointeoir lag sa bhreis dúinn féin, ach bheadh sé seo mar thoradh nuashonruithe sa bhreis ar an líon tagartha lag ní a d'fhéadfadh a bheith riachtanach ar shlí eile.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Anois is féidir linn an luach istigh a thosú i gceart agus tagairt láidir a dhéanamh dár dtagairt lag.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Ní mór don scríobh thuas don réimse sonraí a bheith le feiceáil ar aon snáitheanna a bhreathnú chomhaireamh neamh-náid láidir.
            // Dá bhrí sin, ní mór dúinn ar a laghad "Release" ordú chun sioncrónú leis an `compare_exchange_weak` in `Weak::upgrade`.
            //
            // "Acquire" Níl ordú ag teastáil.
            // Agus muid ag smaoineamh ar iompraíochtaí féideartha `data_fn` ní gá dúinn ach féachaint ar an méid a d`fhéadfadh sé a dhéanamh le tagairt do `Weak` neamh-uasghrádaithe:
            //
            // - Is féidir é *Clón* an `Weak`, ag méadú an líon tagartha lag.
            // - Féadann sé na Cluain Eois sin a ligean anuas, an líon tagartha lag a laghdú (ach riamh go nialas).
            //
            // Ní chuireann na fo-iarsmaí tionchar dúinn ar bhealach ar bith, agus aon fo-éifeachtaí eile is féidir leis an cód sábháilte ina n-aonar.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Ba cheart tagairtí láidre féin i dteannta a tagairt lag roinnte, ní amhlaidh a théann siad ar an destructor le haghaidh ár tagartha lag d'aois.
        //
        mem::forget(weak);
        strong
    }

    /// Tógann `Arc` nua le hábhar neamhbheartaithe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Tosú tosaigh:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Tógann `Arc` nua le hábhar neamhbheartaithe, agus an chuimhne á líonadh le bearta `0`.
    ///
    ///
    /// Féach [`MaybeUninit::zeroed`][zeroed] le haghaidh samplaí d`úsáid cheart agus mhícheart an mhodha seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Tógann `Pin<Arc<T>>` nua.
    /// Mura gcuireann `T` `Unpin` i bhfeidhm, ansin beidh `data` pinned sa chuimhne agus ní féidir é a bhogadh.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Constructs a `Arc<T>` nua, ag filleadh earráid má theipeann leithdháileadh.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Cuir tús leis an gcomhaireamh pointeoir lag mar 1 arb é an pointeoir lag atá i seilbh na leideanna láidre (kinda) go léir, féach std/rc.rs le haghaidh tuilleadh faisnéise
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Constructs a `Arc` nua le hábhair uninitialized, ag filleadh earráid má theipeann leithdháileadh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Tosú tosaigh:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Tógann sé `Arc` nua le hábhar neamhbheartaithe, agus an chuimhne á líonadh le bearta `0`, ag cur earráide ar ais má theipeann ar an leithdháileadh.
    ///
    ///
    /// Féach [`MaybeUninit::zeroed`][zeroed] le haghaidh samplaí d`úsáid cheart agus mhícheart an mhodha seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Tuairisceáin an luach istigh, má tá go díreach amháin tagairt láidir na `Arc`.
    ///
    /// Seachas sin, tugtar [`Err`] ar ais leis an `Arc` céanna a ritheadh isteach.
    ///
    ///
    /// Éireoidh leis seo fiú má tá tagairtí laga gan íoc ann.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Déan pointeoir lag a ghlanadh suas an tagairt láidir-lag intuigthe
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Tógann sé slice nua comhaireamh tagartha adamhach le hábhar neamhbheartaithe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Tosú tosaigh:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Tógann sé slice nua comhaireamh tagartha adamhach le hábhar neamhbheartaithe, agus an chuimhne á líonadh le bearta `0`.
    ///
    ///
    /// Féach [`MaybeUninit::zeroed`][zeroed] le haghaidh samplaí d`úsáid cheart agus mhícheart an mhodha seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Tiontaíonn sé go `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Mar is amhlaidh le [`MaybeUninit::assume_init`], is faoin té atá ag glaoch a ráthú go bhfuil an luach istigh i riocht tosaigh i ndáiríre.
    ///
    /// Má ghlaotar air seo nuair nach bhfuil an t-ábhar tosaithe go hiomlán fós is cúis le hiompar neamhshainithe láithreach.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Tosú tosaigh:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Tiontaíonn sé go `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Mar is amhlaidh le [`MaybeUninit::assume_init`], is faoin té atá ag glaoch a ráthú go bhfuil an luach istigh i riocht tosaigh i ndáiríre.
    ///
    /// Má ghlaotar air seo nuair nach bhfuil an t-ábhar tosaithe go hiomlán fós is cúis le hiompar neamhshainithe láithreach.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Tosú tosaigh:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Itheann an `Arc`, ag filleadh an pointeora fillte.
    ///
    /// Chun a sheachaint sceitheadh cuimhne caithfidh an pointeoir a chur ar ais a chomhshó chun an `Arc` ag baint úsáide as [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Soláthraíonn pointeoir amh do na sonraí.
    ///
    /// Ní dhéantar difear do na comhaireamh ar bhealach ar bith agus ní ídítear an `Arc`.
    /// Tá an pointeoir bailí chomh fada agus a bhfuil comhaireamh láidir sa `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SÁBHÁILTEACHT: Ní féidir leis seo dul trí Deref::deref nó RcBoxPtr::inner mar gheall
        // éilítear é seo chun foinse raw/mut a choinneáil sa chaoi is go m.sh.
        // `get_mut` Is féidir a scríobh tríd an pointeoir tar éis an Rc aisghabháil trí `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Tógann `Arc<T>` ó phointeoir amh.
    ///
    /// Ní foláir an pointeoir amh a bheith curtha ar ais roimhe seo le glao ar [`Arc<U>::into_raw`][into_raw] áit a gcaithfidh `U` an méid agus an t-ailíniú céanna a bheith ag `T`.
    /// Tá sé seo fíor go fánach más `U` é `U`.
    /// Tabhair faoi deara más rud é nach `T` é `U` ach go bhfuil an méid agus an t-ailíniú céanna aige, tá sé seo go bunúsach cosúil le tagairtí aistrithe de chineálacha éagsúla.
    /// Féach [`mem::transmute`][transmute] chun tuilleadh faisnéise a fháil faoi na srianta atá i bhfeidhm sa chás seo.
    ///
    /// Caithfidh úsáideoir `from_raw` a chinntiú nach dtitfear luach sonrach `T` ach uair amháin.
    ///
    /// Tá an fheidhm seo neamhshábháilte toisc go bhféadfadh neamhshábháilteacht cuimhne a bheith mar thoradh ar úsáid mhíchuí, fiú mura ndéantar rochtain ar an `Arc<T>` a cuireadh ar ais riamh.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Tiontaigh ar ais go `Arc` chun sceitheadh a chosc.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Bheadh glaonna breise ar `Arc::from_raw(x_ptr)` neamhshábháilte ó thaobh cuimhne de.
    /// }
    ///
    /// // Scaoileadh an chuimhne nuair a chuaigh `x` as a raon feidhme thuas, mar sin tá `x_ptr` ag crochadh anois!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Déan an fritháireamh a aisiompú chun an ArcInner bunaidh a fháil.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Cruthaíonn pointeoir [`Weak`] nua leis an leithdháileadh seo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Tá an Relaxed seo ceart go leor mar táimid ag seiceáil an luach sa CAS thíos.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // seiceáil má tá an gcuntar lag faoi láthair "locked";más ea, casadh.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: neamhaird ar an cód faoi láthair ar an bhféidearthacht thar maoil
            // isteach i usize::MAX;go ginearálta is gá Rc agus Arc a choigeartú chun déileáil le ró-shreabhadh.
            //

            // Murab ionann agus le Clone(), ní mór dúinn seo a bheith ina Fháil léamh chun sioncrónú leis an scríobh ag teacht ó `is_unique`, ionas go mbeidh a tharlóidh na himeachtaí roimh an scríobh roimh an léamh.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Déan cinnte nach gcruthóimid Lag lag
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Faigheann líon na leideanna [`Weak`] leis an leithdháileadh seo.
    ///
    /// # Safety
    ///
    /// Tá an modh seo a chuireann sé féin sábháilte, ach é a úsáid a éilíonn gceart cúram breise.
    /// Is féidir le snáithe eile an comhaireamh lag a athrú ag am ar bith, lena n-áirítear idir an modh seo a ghlaoch agus gníomhú ar an toradh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Tá an dearbhú seo cinntitheach toisc nach bhfuil an `Arc` nó `Weak` roinnte againn idir snáitheanna.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Má tá an comhaireamh lag ghlas faoi láthair, ba é an luach an chomhairimh 0 díreach sula ndéanfaidh sé an bunachar sonraí.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Faigheann líon na leideanna láidre (`Arc`) leis an leithdháileadh seo.
    ///
    /// # Safety
    ///
    /// Tá an modh seo a chuireann sé féin sábháilte, ach é a úsáid a éilíonn gceart cúram breise.
    /// Is féidir le snáithe eile athrú ar an líon láidir ag am ar bith, lena n-áirítear d'fhéadfadh idir an glaoch an modh seo agus ag gníomhú di ar an toradh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Tá an dearbhú seo cinntitheach toisc nach bhfuil an `Arc` roinnte againn idir snáitheanna.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Méadaíonn sé an comhaireamh láidir tagartha ar an `Arc<T>` a bhaineann leis an bpointeoir a sholáthraíonn duine.
    ///
    /// # Safety
    ///
    /// Caithfidh an pointeoir a bheith faighte trí `Arc::into_raw`, agus caithfidh an cás `Arc` gaolmhar a bheith bailí (ie
    /// caithfidh an comhaireamh láidir a bheith 1) ar a laghad ar feadh ré an mhodha seo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Tá an dearbhú seo cinntitheach toisc nach bhfuil an `Arc` roinnte againn idir snáitheanna.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Coimeád Arc, ach ná bainidh refcount ag timfhilleadh i ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Anois athlíon comhaireamh, ach ná scaoil athchomhaireamh nua ach an oiread
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Laghdaíonn sé an comhaireamh láidir tagartha ar an `Arc<T>` a bhaineann leis an bpointeoir a sholáthraíonn duine.
    ///
    /// # Safety
    ///
    /// Caithfidh an pointeoir a bheith faighte trí `Arc::into_raw`, agus caithfidh an cás `Arc` gaolmhar a bheith bailí (ie
    /// caithfidh an comhaireamh láidir a bheith 1) ar a laghad agus an modh seo á agairt.
    /// Is féidir an modh seo a úsáid chun an `Arc` deiridh agus an stóráil taca a scaoileadh, ach níor cheart **a ghlaoch** tar éis an `Arc` deiridh a scaoileadh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Tá na dearbhuithe sin cinntitheach toisc nach bhfuil an `Arc` roinnte againn idir snáitheanna.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Tá an neamhshábháilteacht seo ceart go leor mar gheall ar cé go bhfuil an stua seo beo táimid cinnte go bhfuil an pointeoir istigh bailí.
        // Ina theannta sin, tá a fhios againn gurb é `Sync` an struchtúr `ArcInner` féin toisc go bhfuil na sonraí istigh `Sync` freisin, mar sin táimid ceart go leor pointeoir dochorraithe a thabhairt ar iasacht do na hábhair seo.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Cuid neamhlíne de `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Scrios na sonraí ag an am seo, cé nach bhféadfaimis an leithdháileadh bosca féin a shaoradh (d`fhéadfadh go mbeadh leideanna laga fós ann).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Buail an tagairt lag atá le chéile ag gach tagairt láidir
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Tuairisceáin `true` má dhíríonn an dá `Arc` ar an leithdháileadh céanna (i vein cosúil le [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Leithdháileann sé `ArcInner<T>` le dóthain spáis le haghaidh luach istigh nach féidir a bheith neamhshonraithe sa chás go bhfuil an leagan amach curtha ar fáil ag an luach.
    ///
    /// Is é an fheidhm `mem_to_arcinner` dtugtar leis an pointeoir sonraí agus ní mór filleadh ar ais ar (d'fhéadfadh a bheith saill)-pointer don `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Ríomh an leagan amach ag baint úsáide as an leagan amach luacha tugtha.
        // Roimhe seo, ríomhadh an leagan amach ar an slonn `&*(ptr as* const ArcInner<T>)`, ach chruthaigh sé seo tagairt mhí-sínithe (féach #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Leithdháileann sé `ArcInner<T>` le dóthain spáis le haghaidh luach inmheánach nach féidir a bheith neamhshonraithe sa chás go bhfuil an leagan amach curtha ar fáil ag an luach, agus earráid a thabhairt ar ais má theipeann ar an leithdháileadh.
    ///
    ///
    /// Is é an fheidhm `mem_to_arcinner` dtugtar leis an pointeoir sonraí agus ní mór filleadh ar ais ar (d'fhéadfadh a bheith saill)-pointer don `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Ríomh an leagan amach ag baint úsáide as an leagan amach luacha tugtha.
        // Roimhe seo, ríomhadh an leagan amach ar an slonn `&*(ptr as* const ArcInner<T>)`, ach chruthaigh sé seo tagairt mhí-sínithe (féach #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Cuir tús leis an ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Leithdháileann sé `ArcInner<T>` le go leor spáis le haghaidh luach inmheánach neamhshábháilte.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Leithdháileadh don `ArcInner<T>` ag baint úsáide as an luach tugtha.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Cóipeáil luach mar bhearta
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Saor an leithdháileadh gan a ábhar a ligean anuas
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Leithdháileann sé `ArcInner<[T]>` leis an fhad a thugtar.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Cóipeáil eilimintí ón slice isteach in Arc <\[T\]> nua-leithdháilte
    ///
    /// Neamhshábháilte toisc go gcaithfidh an té atá ag glaoch úinéireacht a ghlacadh nó `T: Copy` a cheangal.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Constructs an `Arc<[T]>` ó iterator eol a bheith de mhéid áirithe.
    ///
    /// Tá an t-iompar neamhshainithe má tá an méid mícheart.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Garda Panic agus clónáil ar eilimintí T.
        // I gcás panic, scaoilfear eilimintí a scríobhadh isteach san ArcInner nua, ansin saoradh an chuimhne.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pointeoir go dtí an chéad eilimint
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Gach soiléir.Déan dearmad ar an garda sin nach ndéanann sé saor in aisce leis ArcInner nua.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Speisialtóireacht trait a úsáidtear le haghaidh `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Déanann sé clón den phointeoir `Arc`.
    ///
    /// Cruthaíonn sé seo pointeoir eile leis an leithdháileadh céanna, ag méadú an líon tagartha láidir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Ag baint úsáide as ordú relaxed Is ceart go leor anseo, mar cosc eolas ar an tagartha bunaidh snáitheanna eile as hearráideach scriosadh an réad.
        //
        // Mar a míníodh sna [Boost documentation][1], Méadú an gcuntar tagartha is féidir a dhéanamh i gcónaí le memory_order_relaxed: Is féidir le tagairtí nua do rud a bhunú ach amháin ó tagairt atá ann cheana féin, agus ag dul ar an tagairt atá ann cheana féin ó snáithe amháin go ceann eile ní mór a chur ar fáil cheana féin ar aon sioncrónaithe teastáil.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Mar sin féin caithfimid cosaint a dhéanamh ar athchuntais ollmhóra ar eagla go bhfuil duine éigin `mem: : déan dearmad ar Arcs.
        // Mura ndéanaimid é seo is féidir leis an gcomhaireamh cur thar maoil agus úsáidfidh úsáideoirí saor in aisce.
        // Sáithimid go ciníoch le `isize::MAX` ag glacadh leis nach bhfuil snáitheanna ~2 billiún ag méadú an chomhaireamh tagartha ag an am céanna.
        //
        // Ní bheidh sé seo branch a ghlacadh in aon chlár réalaíoch.
        //
        // tobscoir againn toisc go bhfuil a leithéid de chlár incredibly degenerate, agus ní dhéanaimid cúram chun tacaíocht a thabhairt dó.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Déanann sé tagairt inathraithe don `Arc` a thugtar.
    ///
    /// Má tá `Arc` nó [`Weak`] leideanna eile don leithdháileadh chéanna, ansin beidh `make_mut` chruthú leithdháileadh nua agus agairt [`clone`][clone] ar an luach istigh a chinntiú úinéireacht uathúil.
    /// Tugtar clón-ar-scríobh air seo freisin.
    ///
    /// Tabhair faoi deara go bhfuil sé seo difriúil le hiompar [`Rc::make_mut`] a dhealraíonn aon leideanna `Weak` atá fágtha.
    ///
    /// Féach freisin [`get_mut`][get_mut], a dteipfidh air seachas clónáil.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Ní chlónfaidh mé rud ar bith
    /// let mut other_data = Arc::clone(&data); // Sonraí istigh An mbeidh ní Clón
    /// *Arc::make_mut(&mut data) += 1;         // Clónáil sonraí istigh
    /// *Arc::make_mut(&mut data) += 1;         // Ní chlónfaidh mé rud ar bith
    /// *Arc::make_mut(&mut other_data) *= 2;   // Ní chlónfaidh mé rud ar bith
    ///
    /// // Anois díríonn `data` agus `other_data` ar leithdháiltí éagsúla.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Tabhair faoi deara go bhfuil tagairt láidir agus tagairt lag againn araon.
        // Dá bhrí sin, a scaoileadh ár tagartha láidir amháin nach mbeidh, a chuireann sé féin, a chur faoi deara an chuimhne a bheidh le deallocated.
        //
        // Úsáid Acquire chun a chinntiú go bhfeicimid aon scríbhinní chuig `weak` a tharlaíonn sula scríobhann scaoileadh (ie, laghduithe) chuig `strong`.
        // Ós rud é go atá againn chomhaireamh lag, níl aon seans d'fhéadfadh an ArcInner féin a deallocated.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // ann pointeoir eile láidir, mar sin ní mór dúinn a Clón.
            // Réamh-leithdháileadh cuimhne chun ligean don luach clónáilte a scríobh go díreach.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Is leor scíth a ligean sa mhéid thuas toisc gur barrfheabhsú é seo go bunúsach: táimid ag rásaíocht i gcónaí agus leideanna lag á dtitim.
            // cás is measa, táimid ag deireadh suas leithdháilte Arc nua gan ghá.
            //

            // Bhaineamar an tagairt láidir deireanach amach, ach tá tagairtí laga breise fágtha.
            // Bogfaimid an t-ábhar go Arc nua, agus cuirfimid na tagairtí laga eile ó bhailíocht.
            //

            // Tabhair faoi deara nach féidir le léamh `weak` usize::MAX a thabhairt (ie, faoi ghlas), ós rud é nach féidir an comhaireamh lag a ghlasáil ach le snáithe le tagairt láidir.
            //
            //

            // Cuir ár bpointeoir lag intuigthe féin i bhfeidhm, ionas gur féidir leis an ArcInner a ghlanadh de réir mar is gá.
            //
            let _weak = Weak { ptr: this.ptr };

            // In ann na sonraí a ghoid, níl fágtha ach Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Ba sinne an t-aon tagairt de cheachtar den dá chineál;bump ar ais suas an comhaireamh láidir tag.
            //
            this.inner().strong.store(1, Release);
        }

        // Mar is amhlaidh le `get_mut()`, tá an neamhshábháilteacht ceart go leor toisc go raibh ár dtagairt uathúil chun tús a chur leis, nó gur tagairt í ar chlónáil an ábhair.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Tuairisceáin tagairt mutable isteach sa `Arc` thugtar, mura bhfuil aon `Arc` ná [`Weak`] leideanna eile don leithdháileadh céanna.
    ///
    ///
    /// Tuairisceáin [`None`] ar shlí eile, toisc nach bhfuil sé sábháilte luach comhroinnte a threáitear.
    ///
    /// Féach freisin [`make_mut`][make_mut], a thabharfaidh [`clone`][clone] an luach istigh nuair a bheidh leideanna eile ann.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Tá an neamhshábháilteacht seo ceart go leor mar gheall orainn a bheith cinnte gurb é an pointeoir a chuirtear ar ais an pointeoir *amháin* a thabharfar ar ais do T.
            // Ráthaítear gurb é 1 ár gcomhaireamh tagartha ag an bpointe seo, agus d`éilíomar gur `mut` an Arc féin, agus mar sin táimid ag filleadh an t-aon tagairt is féidir do na sonraí istigh.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Seoltar tagairt inathraithe ar ais sa `Arc` a tugadh, gan aon seiceáil.
    ///
    /// Féach freisin [`get_mut`], atá sábháilte agus a dhéanann seiceálacha iomchuí.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Níor cheart aon leideanna `Arc` nó [`Weak`] eile a bhaineann leis an leithdháileadh céanna a dhí-chosaint ar feadh ré na hiasachta ar ais.
    ///
    /// Is fíor an cás é mura bhfuil aon leideanna den sórt sin ann, mar shampla díreach tar éis `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Bímid cúramach gan *gan* tagairt a chruthú a chlúdaíonn na réimsí "count", mar a dhéanfadh sé seo ailias le rochtain chomhthráthach ar na comhaireamh tagartha (e.g.
        // ag `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Déan amach an bhfuil sé seo an tagairt uathúil (lena n-áirítear cuir lag) leis na sonraí bunúsacha.
    ///
    ///
    /// Tabhair faoi deara go n-éilíonn sé seo Glasáil an líon ref lag.
    fn is_unique(&mut self) -> bool {
        // glas an comhaireamh pointeoir lag más dealraitheach gurb sinne an t-aon sealbhóir pointeoir lag.
        //
        // Cinntíonn an lipéad fála anseo caidreamh a tharlaíonn roimh ré le haon scríbhinní chuig `strong` (go háirithe in `Weak::upgrade`) sula ndéantar laghduithe ar chomhaireamh `weak` (trí `Weak::drop`, a úsáideann scaoileadh).
        // Murar thit an tagairt lag uasghrádaithe riamh, teipfidh ar an CAS anseo agus mar sin is cuma linn sioncrónú.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Ní mór gur `Acquire` é seo chun sioncrónú le laghdú an chuntair `strong` in `drop`-an t-aon rochtain a tharlaíonn nuair a bhíonn aon tagairt ach an tagairt dheireanach á titim.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Sioncrónaíonn an scríbhinn eisiúna anseo le léamh in `downgrade`, ag cosc go héifeachtach an léamh thuas de `strong` a tharlú tar éis na scríbhneoireachta.
            //
            //
            self.inner().weak.store(1, Release); // scaoil an glas
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Drops an `Arc`.
    ///
    /// Laghdóidh sé seo an comhaireamh láidir tagartha.
    /// Má shroicheann an comhaireamh láidir tagartha nialas is é an t-aon tagairtí eile (más ann dóibh) ná [`Weak`], mar sin déanaimid `drop` an luach istigh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Ní phriontálann sé rud ar bith
    /// drop(foo2);   // Priontaí "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Toisc go bhfuil `fetch_sub` adamhach cheana, ní féidir linn gá chun sioncrónú le snáitheanna eile ach amháin má táimid ag dul chun scriosadh an réad.
        // Baineann an loighic chéanna leis an `fetch_sub` thíos le comhaireamh `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Teastaíonn an fál seo chun cosc a chur ar athúsáid na sonraí agus na sonraí a scriosadh.
        // Toisc go bhfuil sé marcáilte `Release`, an laghdú ar na Sioncrónaíonn chomhaireamh tagartha leis an fál `Acquire`.
        // Ciallaíonn sé go dtarlaíonn úsáid na sonraí sula gcuirfear laghdú an comhaireamh tagartha, a tharlaíonn roimh an fál, a tharlaíonn roimh scriosadh na sonraí.
        //
        // Mar a míníodh sa [Boost documentation][1],
        //
        // > Tá sé tábhachtach aon rochtain fhéideartha ar an réad a fhorfheidhmiú i gceann amháin
        // > snáithe (trí tagairt atá ann cheana féin) chun *tarlú roimh* scriosadh
        // > an réad i snáithe difriúil.Baintear é seo amach ag "release"
        // > oibriú tar éis tagairt a ligean anuas (aon rochtain ar an réad
        // > tríd an ní mór an tagairt a tharla ar ndóigh roimh), agus
        // > "acquire" oibriú roimh scriosadh an réad.
        //
        // Go háirithe, cé go mbíonn ábhar Arc dochorraithe de ghnáth, is féidir scríbhinní istigh a scríobh chuig rud éigin cosúil le Mutex<T>.
        // Ós rud é nach bhfaightear Mutex nuair a scriostar é, ní féidir linn brath ar a loighic sioncrónaithe chun scríbhinní i snáithe A a dhéanamh infheicthe ag scriosóir atá ag rith i snáithe B.
        //
        //
        // Tabhair faoi deara freisin go bhféadfadh an fál Fháil anseo a chur in ionad dócha le ualach Fháil, a d'fhéadfadh a feabhas a chur ar fheidhmíocht i gcásanna ard-áitigh.Féach [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Déan iarracht an `Arc<dyn Any + Send + Sync>` a ísliú go cineál coincréite.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Tógann `Weak<T>` nua, gan aon chuimhne a leithdháileadh.
    /// Tugann [`None`] glaoch ar [`upgrade`] ar an luach toraidh i gcónaí.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Cineál cúntóra chun rochtain a fháil ar na comhaireamh tagartha gan aon dearbhuithe a dhéanamh faoin réimse sonraí.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Tugann pointeoir amh ar ais don réad `T` a dtugann an `Weak<T>` seo aird air.
    ///
    /// Is é an t pointeoir bailí ach amháin má tá roinnt tagairtí láidre.
    /// Féadfaidh an pointeoir a bheith ag crochadh, gan síniú nó fiú [`null`] ar shlí eile.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Díríonn an dá rud ar an réad céanna
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Coinníonn an láidir anseo é beo, ionas gur féidir linn rochtain a fháil ar an réad fós.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ach ní níos mó.
    /// // Is féidir linn weak.as_ptr() a dhéanamh, ach bheadh iompar neamhshainithe mar thoradh ar an pointeoir a rochtain.
    /// // assert_eq! ("Dia duit", neamhshábháilte {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Má tá an pointeoir ag crochadh, cuirimid an sentinel ar ais go díreach.
            // Ní féidir gur seoladh bailí ualaigh pá é seo, toisc go bhfuil an t-ualach pá chomh ailínithe le ArcInner (usize) ar a laghad.
            ptr as *const T
        } else {
            // SÁBHÁILTEACHT: má fhilleann is_dangling bréagach, ansin tá an pointeoir dereferencable.
            // Féadfar an t-ualach pá a ísliú ag an bpointe seo, agus ní mór dúinn bunáitíocht a choinneáil, mar sin bain úsáid as ionramháil pointeoir amh.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Itheann sé an `Weak<T>` agus é a iompú ina phointeoir amh.
    ///
    /// Athraíonn sé seo an pointeoir lag ina pointeoir amh, agus úinéireacht úinéireachta tagartha lag amháin á chaomhnú aige (ní dhéantar an comhaireamh lag a mhodhnú leis an oibríocht seo).
    /// Is féidir é a iompú ar ais sa `Weak<T>` le [`from_raw`].
    ///
    /// Tá feidhm ag na srianta céanna maidir le rochtain a fháil ar sprioc an phointeora agus atá ag [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Athraíonn sé pointeoir amh a chruthaigh [`into_raw`] roimhe seo ar ais i `Weak<T>`.
    ///
    /// Is féidir é seo a úsáid chun tagairt láidir a fháil go sábháilte (trí ghlaoch a chur ar [`upgrade`] níos déanaí) nó chun an comhaireamh lag a thuiscint tríd an `Weak<T>` a ligean anuas.
    ///
    /// Glacann sé úinéireacht ar thagairt lag amháin (cé is moite de leideanna a chruthaigh [`new`], toisc nach leo féin aon rud; oibríonn an modh orthu fós).
    ///
    /// # Safety
    ///
    /// Caithfidh gur ón [`into_raw`] a tháinig an pointeoir agus caithfidh tagairt tagartha lag a bheith aige fós.
    ///
    /// Ceadaítear gurb é 0 an comhaireamh láidir nuair a ghlaofar air seo.
    /// Mar sin féin, glacann sé seo úinéireacht ar thagairt lag amháin a léirítear faoi láthair mar phointeoir amh (ní dhéantar an comhaireamh lag a mhodhnú leis an oibríocht seo) agus dá bhrí sin caithfear é a phéireáil le glao roimhe seo ar [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Laghdaigh an comhaireamh lag deireanach.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Féach Weak::as_ptr le haghaidh comhthéacs ar an gcaoi a ndíorthaítear an pointeoir ionchuir.

        let ptr = if is_dangling(ptr as *mut T) {
            // Is é seo a Lag dangling.
            ptr as *mut ArcInner<T>
        } else {
            // Seachas sin, táimid ag ráthaíocht gur ó lagmhisneach a tháinig an pointeoir.
            // SÁBHÁILTEACHT: tá sé sábháilte glaoch ar data_offset, toisc go dtagraíonn ptr do T. fíor (a d`fhéadfadh a bheith tite).
            let offset = unsafe { data_offset(ptr) };
            // Dá bhrí sin, a fhreaschur táimid ag fritháireamh ó fháil ar an RcBox fad.
            // SÁBHÁILTEACHT: tháinig an pointeoir ó Lag, mar sin tá an fritháireamh seo sábháilte.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SÁBHÁILTEACHT: ní mór dúinn a aisghabháil anois ar an pointeoir Lag bunaidh, ionas gur féidir a chruthú ar an lag.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Iarrachtaí an pointeoir `Weak` a uasghrádú go [`Arc`], ag cur moill ar thitim an luach istigh má éiríonn leis.
    ///
    ///
    /// Tuairisceáin [`None`] má tá an luach istigh a fhágáil ar lár ó shin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Scrios gach leideanna láidre.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Úsáidimid lúb CAS chun an comhaireamh láidir a mhéadú in ionad fetch_add mar níor cheart go dtógfadh an fheidhm seo an comhaireamh tagartha ó nialas go ceann amháin.
        //
        //
        let inner = self.inner()?;

        // Ualach scíth a ligean toisc go bhfágann aon scríbhinn de 0 is féidir linn breathnú air an réimse i riocht buan nialasach (mar sin tá léamh "stale" de 0 go maith), agus dearbhaítear aon luach eile tríd an CAS thíos.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Féach tráchtanna in `Arc::clone` maidir le cén fáth a ndéanaimid é seo (le haghaidh `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Is Relaxed breá le haghaidh an cás teip toisc nach bhfuil againn aon súil faoi staid nua.
            // Is Fháil is gá chun an cás rath chun sioncrónú leis `Arc::new_cyclic`, nuair is féidir leis an luach istigh a initialized tar éis tagairtí `Weak` cruthaithe cheana féin.
            // Sa chás sin, táimid ag súil le breathnú ar an luach túsaithe hiomlán.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null a sheiceáil thuas
                Err(old) => n = old,
            }
        }
    }

    /// Faigheann líon na leideanna láidre (`Arc`) atá dírithe ar an leithdháileadh seo.
    ///
    /// Dá `self` cruthaithe ag baint úsáide [`Weak::new`], beidh sé seo ar ais 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Faigheann an comhfhogasú a dhéanamh ar líon na leideanna `Weak` dírithe ar an leithdháileadh.
    ///
    /// Má cruthaíodh `self` ag baint úsáide as [`Weak::new`], nó mura bhfuil aon leideanna láidre fágtha, fillfidh sé seo 0.
    ///
    /// # Accuracy
    ///
    /// Mar gheall ar mhionsonraí cur chun feidhme, féadtar an luach a chuirtear ar ais a laghdú faoi 1 i gceachtar treo nuair a bhíonn snáitheanna eile ag ionramháil aon `Arc`s nó` Lag 'atá dírithe ar an leithdháileadh céanna.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Ó thugamar faoi deara go raibh pointeoir láidir amháin ar a laghad ann tar éis an comhaireamh lag a léamh, tá a fhios againn go raibh an tagairt intuigthe lag (i láthair gach uair a bhíonn tagairtí láidre beo) thart nuair a thugamar faoi deara an comhaireamh lag, agus dá bhrí sin is féidir é a dhealú go sábháilte.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Tuairisceáin `None` nuair a bhíonn an pointeoir ag crochadh agus mura leithdháiltear `ArcInner`, (ie, nuair a chruthaigh `Weak::new` an `Weak` seo).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Táimid go cúramach chun *nach* chruthú is tagairt í a chlúdaíonn an réimse "data", de réir mar a réimse a mutated i gcomhthráth (mar shampla, má tá an `Arc` caite thit, an réimse sonraí a thit in-áit).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Tuairisceáin `true` má dhíríonn an dá `Lag ar an leithdháileadh céanna (cosúil le [`ptr::eq`]), nó mura ndéanann an dá rud aon leithdháileadh (toisc gur cruthaíodh iad le `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Ós rud é go ndéanann sé seo comparáid idir leideanna, ciallaíonn sé go mbeidh `Weak::new()` cothrom lena chéile, cé nach ndíríonn siad ar aon leithdháileadh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Comparáid a `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Dhéanann Clón an pointeoir `Weak` go pointí leithdháileadh céanna.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Féach tráchtanna in Arc::clone() ar an bhfáth go bhfuil sé seo réchúiseach.
        // Féadann sé seo fetch_add a úsáid (gan neamhaird a dhéanamh den ghlas) toisc nach bhfuil an comhaireamh lag faoi ghlas ach sa chás nach bhfuil *aon leideanna laga* eile ann.
        //
        // (Mar sin, ní féidir linn a bheith ag rith an cód sa chás sin).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Féach tráchtanna in Arc::clone() maidir le cén fáth a ndéanaimid é seo (le haghaidh mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Tógann `Weak<T>` nua, gan cuimhne a leithdháileadh.
    /// Tugann [`None`] glaoch ar [`upgrade`] ar an luach toraidh i gcónaí.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Drops an pointeoir `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ní phriontálann sé rud ar bith
    /// drop(foo);        // Priontaí "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Má fhaighimid amach gurbh sinne an pointeoir lag deireanach, ansin tá an t-am aige na sonraí a thuiscint go hiomlán.Féach an plé in Arc::drop() faoi na horduithe cuimhne
        //
        // Ní gá seiceáil a dhéanamh ar an stát faoi ghlas anseo, mar ní féidir an comhaireamh lag a ghlasáil ach amháin má bhí tag lag amháin ann, rud a chiallaíonn nach bhféadfadh titim titim ach ina dhiaidh sin ar an tag lag atá fágtha, rud nach féidir a tharlú ach amháin tar éis an glas a scaoileadh.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Táimid ag déanamh na speisialtóireachta seo anseo, agus ní mar bharrfheabhsú níos ginearálta ar `&T`, mar gheall go gcuirfeadh sé costas ar gach seiceáil comhionannais ar thagairtí.
/// Glacaimid leis go n-úsáidtear `Arc`s chun luachanna móra a stóráil, atá mall le clónáil, ach atá trom freisin chun comhionannas a sheiceáil, rud a fhágann go n-íocfaidh an costas seo níos éasca.
///
/// Is dóichí freisin go mbeidh dhá chlón `Arc` ann, a bhfuil an luach céanna orthu, ná dhá `&T`.
///
/// Ní féidir linn é seo a dhéanamh ach nuair a d`fhéadfadh `T: Eq` mar `PartialEq` a bheith irreflexive d`aon ghnó.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Chomhionannas do dhá `Arc`s.
    ///
    /// Tá dhá `Arc`s comhionanna má tá a gcuid luachanna istigh chomhionann, fiú má tá siad stóráil i leithdháileadh éagsúla.
    ///
    /// Má chuireann `T` `Eq` i bhfeidhm freisin (le tuiscint ar athléimneacht an chomhionannais), is ionann dhá `Arc 'a dhíríonn ar an leithdháileadh céanna.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Éagothroime do dhá `Arc`.
    ///
    /// Tá dhá `Arc 'neamhchothrom má tá a luachanna istigh neamhchothrom.
    ///
    /// Má chuireann `T` `Eq` i bhfeidhm freisin (le tuiscint ar athléimneacht an chomhionannais), ní bhíonn dhá `Arc` a léiríonn an luach céanna neamhchothrom riamh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Comparáid pháirteach ar dhá `Arc`.
    ///
    /// Déantar comparáid idir an dá cheann trí ghlaoch a chur ar `partial_cmp()` ar a luachanna istigh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Níos lú ná comparáid idir dhá `Arc`.
    ///
    /// Déantar comparáid idir an dá cheann trí ghlaoch a chur ar `<` ar a luachanna istigh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Comparáid 'Níos lú ná nó cothrom le' dhá 'Arc`.
    ///
    /// Déantar comparáid idir an dá cheann trí ghlaoch a chur ar `<=` ar a luachanna istigh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Comparáid níos mó ná dhá `Arc`.
    ///
    /// Déantar comparáid idir an dá cheann trí ghlaoch a chur ar `>` ar a luachanna istigh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Comparáid 'níos mó ná nó cothrom le' dhá 'Arc'.
    ///
    /// Déantar comparáid idir an dá cheann trí ghlaoch a chur ar `>=` ar a luachanna istigh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Comparáid idir dhá `Arc`.
    ///
    /// Tá an dá chur i gcomparáid trí ghlaoch `cmp()` ar a luachanna istigh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Cruthaíonn sé `Arc<T>` nua, leis an luach `Default` do `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Leithdháileadh slice comhaireamh tagartha agus líon é trí chlónáil ar mhíreanna `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Leithdháileadh `str` comhaireamh tagartha agus cóipeáil `v` isteach ann.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Leithdháileadh `str` comhaireamh tagartha agus cóipeáil `v` isteach ann.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Bog réad i mboscaí chuig leithdháileadh nua, comhaireamh tagartha.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Leithdháileadh slice comhaireamh tagartha agus bog míreanna `v` isteach ann.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Lig don Vec a chuimhne a shaoradh, ach gan a bhfuil ann a scriosadh
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Glacann sé gach eilimint sa `Iterator` agus bailítear é i `Arc<[T]>`.
    ///
    /// # Saintréithe feidhmíochta
    ///
    /// ## An cás ginearálta
    ///
    /// Go ginearálta, déantar bailiú isteach i `Arc<[T]>` trí bhailiú i `Vec<T>` ar dtús.Is é sin, agus an méid seo a leanas á scríobh:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// iompraíonn sé seo amhail is gur scríobh muid:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Tarlaíonn an chéad tacar leithdháiltí anseo.
    ///     .into(); // Tarlaíonn an dara leithdháileadh do `Arc<[T]>` anseo.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Leithdháilfidh sé seo a mhéad uair is gá chun an `Vec<T>` a thógáil agus ansin leithdháilfidh sé uair amháin chun an `Vec<T>` a iompú ina `Arc<[T]>`.
    ///
    ///
    /// ## Iterators ar a dtugtar fad
    ///
    /// Nuair a chuireann do `Iterator` `TrustedLen` agus tá sé de méid cruinn, beidh leithdháilte aonair a dhéanamh maidir le `Arc<[T]>`.Mar shampla:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Ní tharlaíonn ach leithdháileadh amháin anseo.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Speisialtóireacht trait a úsáidtear le haghaidh bhailiú `Arc<[T]>` isteach.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Is amhlaidh atá i gcás iteora `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SÁBHÁILTEACHT: Ní mór dúinn a chinntiú go bhfuil fad cruinn ag an iterator agus atá againn.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Titim ar ais go gnáthfheidhmiú.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Faigh an fritháireamh laistigh de `ArcInner` don ualach pá taobh thiar de phointeoir.
///
/// # Safety
///
/// Caithfidh an pointeoir tagairt do (agus meiteashonraí bailí a bheith aige do) sampla T a bhí bailí roimhe seo, ach ceadaítear an T a thitim.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Ailínigh an luach neamhshábháilte go dtí deireadh an ArcInner.
    // Toisc go bhfuil RcBox repr(C), beidh sé i gcónaí ar an réimse deireanach sa chuimhne.
    // SÁBHÁILTEACHT: ós rud é gurb iad na cineálacha neamhshábháilte amháin is féidir slisní, rudaí trait,
    // agus cineálacha seachtracha, is leor an ceanglas sábháilteachta ionchuir faoi láthair chun riachtanais align_of_val_raw a shásamh;tá sé seo go mion chun feidhme an teanga nach féidir a bheith ag brath air taobh amuigh de std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}