//! Cineál pointeora le haghaidh leithdháileadh carn.
//!
//! [`Box<T>`], dá ngairtear 'box' go casually, soláthraíonn sé an fhoirm is simplí de leithdháileadh carn i Rust.Soláthraíonn boscaí úinéireacht ar an leithdháileadh seo, agus scaoilfidh siad a n-ábhar nuair a théann siad as a raon feidhme.Cinntíonn boscaí freisin nach leithdháileann siad níos mó ná bearta `isize::MAX` riamh.
//!
//! # Examples
//!
//! Bog luach ón gcruach go dtí an gcarn trí [`Box`] a chruthú:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! Bog luach ó [`Box`] ar ais go dtí an chairn le [dereferencing]:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! Struchtúr athchúrsach sonraí a chruthú:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! Priontálfaidh sé seo `Cons (1, Cons(2, Nil))`.
//!
//! Caithfear struchtúir athchúrsacha a chur i mboscaí, mar má bhí an chuma ar an sainmhíniú ar `Cons`:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! Ní oibreodh sé.Tá sé seo toisc go mbraitheann méid `List` ar an méid eilimintí atá ar an liosta, agus mar sin níl a fhios againn cé mhéad cuimhne atá le leithdháileadh le haghaidh `Cons`.Trí [`Box<T>`] a thabhairt isteach, a bhfuil méid sainithe aige, tá a fhios againn cé chomh mór agus a chaithfidh `Cons` a bheith.
//!
//! # Leagan amach na cuimhne
//!
//! Maidir le luachanna neamh-nialasacha, úsáidfidh [`Box`] an leithdháilteoir [`Global`] chun é a leithdháileadh.Tá sé bailí an dá bhealach a thiontú idir [`Box`] agus pointeoir amh arna leithdháileadh leis an leithdháilteoir [`Global`], ós rud é go bhfuil an [`Layout`] a úsáidtear leis an leithdháilteoir ceart don chineál.
//!
//! Níos cruinne, féadfar `value:*mut T` a leithdháileadh leis an leithdháilteoir [`Global`] le `Layout::for_value(&* value)` a thiontú ina bhosca ag úsáid [`Box::<T>::from_raw(value)`].
//! Os a choinne sin, féadtar an chuimhne a thacaíonn le `value:*mut T` a fhaightear ó [`Box::<T>::into_raw`] a thuiscint trí úsáid a bhaint as an leithdháileadh [`Global`] le [`Layout::for_value(&* value)`].
//!
//! Maidir le luachanna meánmhéide, ní mór fós an pointeoir `Box` a bheith [valid] le haghaidh léamha agus scríbhneoireachta agus ailínithe go leordhóthanach.
//! Go háirithe, má dhéantar aon slánuimhir ailínithe neamh-nialasach a ailíniú le pointeoir amh, cruthaítear pointeoir bailí, ach níl pointeoir a dhíríonn ar chuimhne a leithdháileadh roimhe seo bailí ó shin.
//! Is é an bealach a mholtar Bosca a thógáil go ZST mura féidir `Box::new` a úsáid ná [`ptr::NonNull::dangling`] a úsáid.
//!
//! Chomh fada le `T: Sized`, ráthaítear go léireofar `Box<T>` mar phointeoir aonair agus go bhfuil sé comhoiriúnach le ABI le leideanna C (ie an cineál C `T*`).
//! Ciallaíonn sé seo má tá feidhmeanna seachtracha "C" Rust agat a ghlaofar ó C, is féidir leat na feidhmeanna Rust sin a shainiú trí chineálacha `Box<T>` a úsáid, agus `T*` a úsáid mar chineál comhfhreagrach ar an taobh C.
//! Mar shampla, smaoinigh ar an gceannteideal C seo a dhearbhaíonn feidhmeanna a chruthaíonn agus a scriosann cineál éigin de luach `Foo`:
//!
//! ```c
//! /* C ceanntásc */
//!
//! /* Tugann sé úinéireacht ar ais don té atá ag glaoch */
//! struct Foo* foo_new(void);
//!
//! /* Glacann sé úinéireacht ón té atá ag glaoch;aon-op nuair a agairt le NULL */
//! void foo_delete(struct Foo*);
//! ```
//!
//! D'fhéadfaí an dá fheidhm seo a chur i bhfeidhm i Rust mar seo a leanas.Anseo, aistrítear an cineál `struct Foo*` ó C go `Box<Foo>`, a ghabhann na srianta úinéireachta.
//! Tabhair faoi deara freisin go léirítear an argóint in-inúsáidte le `foo_delete` i Rust mar `Option<Box<Foo>>`, ós rud é nach féidir `Box<Foo>` a chur ar neamhní.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! Cé go bhfuil an ionadaíocht chéanna ag `Box<T>` agus C ABI agus pointeoir C, ní chiallaíonn sé sin gur féidir leat `T*` treallach a thiontú ina `Box<T>` agus a bheith ag súil go n-oibreoidh rudaí.
//! `Box<T>` beidh luachanna ailínithe go hiomlán i gcónaí, leideanna neamh-null.Thairis sin, déanfaidh an scriosóir do `Box<T>` iarracht an luach a shaoradh leis an leithdháileadh domhanda.Go ginearálta, is é an cleachtas is fearr gan `Box<T>` a úsáid ach amháin le haghaidh leideanna a tháinig ón leithdháilteoir domhanda.
//!
//! **Tábhachtach.** Faoi láthair ar a laghad, ba cheart duit cineálacha `Box<T>` a sheachaint le haghaidh feidhmeanna atá sainithe i C ach a agairt ó Rust.Sna cásanna sin, ba cheart duit na cineálacha C a scáthán go díreach chomh dlúth agus is féidir.
//! Má úsáidtear cineálacha mar `Box<T>` ina bhfuil an sainmhíniú C ag úsáid `T*`, féadfar iompar neamhshainithe a bheith mar thoradh air, mar a thuairiscítear in [rust-lang/unsafe-code-guidelines#198][ucg#198].
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// Cineál pointeora le haghaidh leithdháileadh carn.
///
/// Féach an [module-level documentation](../../std/boxed/index.html) le haghaidh tuilleadh.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// Leithdháileann cuimhne ar an gcarn agus ansin cuirtear `x` isteach ann.
    ///
    /// Ní leithdháileann sé seo i ndáiríre má tá `T` meánmhéide.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// Tógann bosca nua le hábhar neamhbheartaithe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Tosú tosaigh:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// Tógann `Box` nua le hábhar neamhbheartaithe, agus an chuimhne á líonadh le bearta `0`.
    ///
    ///
    /// Féach [`MaybeUninit::zeroed`][zeroed] le haghaidh samplaí d`úsáid cheart agus mhícheart an mhodha seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// Tógann `Pin<Box<T>>` nua.
    /// Mura gcuireann `T` `Unpin` i bhfeidhm, ansin beidh `x` pinned sa chuimhne agus ní féidir é a bhogadh.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// Leithdháileann cuimhne ar an gcarn ansin cuireann `x` isteach ann, agus earráid ar ais má theipeann ar an leithdháileadh
    ///
    ///
    /// Ní leithdháileann sé seo i ndáiríre má tá `T` meánmhéide.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// Tógann sé bosca nua le hábhar neamhbheartaithe ar an gcarn, agus earráid á chur ar ais má theipeann ar an leithdháileadh
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Tosú tosaigh:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// Tógann `Box` nua le hábhar neamhbheartaithe, agus an chuimhne á líonadh le bearta `0` ar an gcarn
    ///
    ///
    /// Féach [`MaybeUninit::zeroed`][zeroed] le haghaidh samplaí d`úsáid cheart agus mhícheart an mhodha seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// Leithdháileann cuimhne sa leithdháilteoir tugtha ansin cuireann `x` isteach ann.
    ///
    /// Ní leithdháileann sé seo i ndáiríre má tá `T` meánmhéide.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// Leithdháileann cuimhne sa leithdháilteoir tugtha ansin cuireann `x` isteach ann, agus earráid ar ais má theipeann ar an leithdháileadh
    ///
    ///
    /// Ní leithdháileann sé seo i ndáiríre má tá `T` meánmhéide.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// Tógann sé bosca nua le hábhar neamhdhírithe sa leithdháilteoir a sholáthraítear.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // Tosú tosaigh:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: B`fhearr leat an cluiche thar unwrap_or_else ós rud é nach mbíonn sé inlíne uaireanta.
        // Dhéanfadh sé sin méid an chóid níos mó.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Tógann sé bosca nua le hábhar neamhbheartaithe sa leithdháilteoir a sholáthraítear, agus earráid á chur ar ais má theipeann ar an leithdháileadh
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // Tosú tosaigh:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Tógann sé `Box` nua le hábhar neamhbheartaithe, agus an chuimhne á líonadh le bearta `0` sa leithdháilteoir a sholáthraítear.
    ///
    ///
    /// Féach [`MaybeUninit::zeroed`][zeroed] le haghaidh samplaí d`úsáid cheart agus mhícheart an mhodha seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: B`fhearr leat an cluiche thar unwrap_or_else ós rud é nach mbíonn sé inlíne uaireanta.
        // Dhéanfadh sé sin méid an chóid níos mó.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Tógann sé `Box` nua le hábhar neamhdhírithe, agus an chuimhne á líonadh le bearta `0` sa leithdháilteoir a sholáthraítear, ag cur earráide ar ais má theipeann ar an leithdháileadh,
    ///
    ///
    /// Féach [`MaybeUninit::zeroed`][zeroed] le haghaidh samplaí d`úsáid cheart agus mhícheart an mhodha seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Tógann `Pin<Box<T, A>>` nua.
    /// Mura gcuireann `T` `Unpin` i bhfeidhm, ansin beidh `x` pinned sa chuimhne agus ní féidir é a bhogadh.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// Tiontaíonn `Box<T>` ina `Box<[T]>`
    ///
    /// Ní leithdháileann an tiontú seo ar an gcarn agus tarlaíonn sé i bhfeidhm.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// Itheann an `Box`, ag filleadh an luach fillte.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// Tógann sé slice nua i mboscaí le hábhar neamhbheartaithe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Tosú tosaigh:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// Constructs slice mboscaí nua le hábhair uninitialized, leis an chuimhne á líonadh le `0` bytes.
    ///
    ///
    /// Féach [`MaybeUninit::zeroed`][zeroed] le haghaidh samplaí d`úsáid cheart agus mhícheart an mhodha seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// Tógann sé slice nua i mboscaí le hábhar neamhbheartaithe sa leithdháilteoir a sholáthraítear.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // Tosú tosaigh:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// Tógann sé slice nua i mboscaí le hábhar neamhdhírithe sa leithdháilteoir a sholáthraítear, agus an chuimhne á líonadh le bearta `0`.
    ///
    ///
    /// Féach [`MaybeUninit::zeroed`][zeroed] le haghaidh samplaí d`úsáid cheart agus mhícheart an mhodha seo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// Tiontaíonn sé go `Box<T, A>`.
    ///
    /// # Safety
    ///
    /// Mar is amhlaidh le [`MaybeUninit::assume_init`], is faoin té atá ag glaoch a ráthú go bhfuil an luach i riocht tosaigh i ndáiríre.
    ///
    /// Má ghlaotar air seo nuair nach bhfuil an t-ábhar tosaithe go hiomlán fós is cúis le hiompar neamhshainithe láithreach.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // Tosú tosaigh:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// Tiontaíonn sé go `Box<[T], A>`.
    ///
    /// # Safety
    ///
    /// Mar is amhlaidh le [`MaybeUninit::assume_init`], is faoin té atá ag glaoch a ráthú go bhfuil na luachanna i riocht tosaigh i ndáiríre.
    ///
    /// Má ghlaotar air seo nuair nach bhfuil an t-ábhar tosaithe go hiomlán fós is cúis le hiompar neamhshainithe láithreach.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Tosú tosaigh:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// Tógann bosca as pointeoir amh.
    ///
    /// Tar éis an fheidhm seo a ghlaoch, is leis an `Box` mar thoradh air an pointeoir amh.
    /// Go sonrach, cuirfidh an destructor `Box` glaoch ar an destructor `T` agus saorfaidh sé an chuimhne leithdháilte.
    /// Chun é seo a bheith sábháilte, caithfear an chuimhne a leithdháileadh de réir an [memory layout] a úsáideann `Box`.
    ///
    ///
    /// # Safety
    ///
    /// Tá an fheidhm seo neamhshábháilte toisc go bhféadfadh fadhbanna cuimhne a bheith mar thoradh ar úsáid mhíchuí.
    /// Mar shampla, d`fhéadfadh go mbeadh saor ó dhúbailt ann má thugtar an fheidhm faoi dhó ar an bpointeoir amh céanna.
    ///
    /// Déantar cur síos ar na coinníollacha sábháilteachta sa chuid [memory layout].
    ///
    /// # Examples
    ///
    /// Athchruthú `Box` a athraíodh roimhe seo go pointeoir amh ag úsáid [`Box::into_raw`]:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Cruthaigh `Box` de láimh de láimh tríd an leithdháileadh domhanda a úsáid:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // Go ginearálta teastaíonn .write chun iarracht a dhéanamh an t-ábhar (uninitialized) roimhe seo de `ptr` a scriosadh, ach mar shampla, d'oibrigh `*ptr = 5` chomh maith.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// Tógann sé bosca ó phointeoir amh sa leithdháilteoir tugtha.
    ///
    /// Tar éis an fheidhm seo a ghlaoch, is leis an `Box` mar thoradh air an pointeoir amh.
    /// Go sonrach, cuirfidh an destructor `Box` glaoch ar an destructor `T` agus saorfaidh sé an chuimhne leithdháilte.
    /// Chun é seo a bheith sábháilte, caithfear an chuimhne a leithdháileadh de réir an [memory layout] a úsáideann `Box`.
    ///
    ///
    /// # Safety
    ///
    /// Tá an fheidhm seo neamhshábháilte toisc go bhféadfadh fadhbanna cuimhne a bheith mar thoradh ar úsáid mhíchuí.
    /// Mar shampla, d`fhéadfadh go mbeadh saor ó dhúbailt ann má thugtar an fheidhm faoi dhó ar an bpointeoir amh céanna.
    ///
    /// # Examples
    ///
    /// Athchruthú `Box` a athraíodh roimhe seo go pointeoir amh ag úsáid [`Box::into_raw_with_allocator`]:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Cruthaigh `Box` de láimh de láimh trí leithdháileadh an chórais a úsáid:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // Go ginearálta teastaíonn .write chun iarracht a dhéanamh an t-ábhar (uninitialized) roimhe seo de `ptr` a scriosadh, ach mar shampla, d'oibrigh `*ptr = 5` chomh maith.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// Itheann an `Box`, ag filleadh pointeoir amh fillte.
    ///
    /// Beidh an pointeoir ailínithe i gceart agus neamh-null.
    ///
    /// Tar éis dó an fheidhm seo a ghlaoch, tá an té atá ag glaoch freagrach as an gcuimhne a bhainistigh an `Box` roimhe seo.
    /// Go háirithe, ba cheart don té atá ag glaoch `T` a scriosadh i gceart agus an chuimhne a scaoileadh, agus an [memory layout] a úsáideann `Box` á chur san áireamh.
    /// Is é an bealach is éasca chun é seo a dhéanamh an pointeoir amh a thiontú ar ais ina `Box` leis an bhfeidhm [`Box::from_raw`], rud a ligeann don scriosóir `Box` an glanta a dhéanamh.
    ///
    ///
    /// Note: is feidhm ghaolmhar í seo, rud a chiallaíonn go gcaithfidh tú é a ghlaoch mar `Box::into_raw(b)` in ionad `b.into_raw()`.
    /// Déantar é seo ionas nach mbeidh aon choimhlint ann le modh ar an gcineál istigh.
    ///
    /// # Examples
    /// An pointeoir amh a thiontú ar ais ina `Box` le [`Box::from_raw`] le haghaidh glanta uathoibríoch:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Glantachán láimhe tríd an destructor a rith go sainráite agus an chuimhne a thuiscint:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// Itheann sé an `Box`, ag filleadh pointeoir amh fillte agus an leithdháilteoir.
    ///
    /// Beidh an pointeoir ailínithe i gceart agus neamh-null.
    ///
    /// Tar éis dó an fheidhm seo a ghlaoch, tá an té atá ag glaoch freagrach as an gcuimhne a bhainistigh an `Box` roimhe seo.
    /// Go háirithe, ba cheart don té atá ag glaoch `T` a scriosadh i gceart agus an chuimhne a scaoileadh, agus an [memory layout] a úsáideann `Box` á chur san áireamh.
    /// Is é an bealach is éasca chun é seo a dhéanamh an pointeoir amh a thiontú ar ais ina `Box` leis an bhfeidhm [`Box::from_raw_in`], rud a ligeann don scriosóir `Box` an glanta a dhéanamh.
    ///
    ///
    /// Note: is feidhm ghaolmhar í seo, rud a chiallaíonn go gcaithfidh tú é a ghlaoch mar `Box::into_raw_with_allocator(b)` in ionad `b.into_raw_with_allocator()`.
    /// Déantar é seo ionas nach mbeidh aon choimhlint ann le modh ar an gcineál istigh.
    ///
    /// # Examples
    /// An pointeoir amh a thiontú ar ais ina `Box` le [`Box::from_raw_in`] le haghaidh glanta uathoibríoch:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Glantachán láimhe tríd an destructor a rith go sainráite agus an chuimhne a thuiscint:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // Aithnítear Bosca mar "unique pointer" ag Stacked Borrows, ach go hinmheánach is pointeoir amh é don chóras cineáil.
        // Ní aithneofaí gurb é "releasing" an pointeoir uathúil chun é a iontráil go díreach ina phointeoir amh chun rochtana amh ailiasacha a cheadú, mar sin ní mór do gach modh pointeoir amh dul trí `Box::leak`.
        //
        // Ag iompú *sin* go pointeoir amh iompraíonn sé i gceart.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// Filleann tagairt don leithdháilteoir bunúsach.
    ///
    /// Note: is feidhm ghaolmhar í seo, rud a chiallaíonn go gcaithfidh tú é a ghlaoch mar `Box::allocator(&b)` in ionad `b.allocator()`.
    /// Déantar é seo ionas nach mbeidh aon choimhlint ann le modh ar an gcineál istigh.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// Déanann an `Box` a ithe agus a sceitheadh, agus tagairt inathraithe a thabhairt ar ais, `&'a mut T`.
    /// Tabhair faoi deara go gcaithfidh an cineál `T` an saolré `'a` roghnaithe a mhaireachtáil.
    /// Mura bhfuil ach tagairtí statacha ag an gcineál, nó gan tagairtí statacha ar bith ann, féadfar é seo a roghnú le bheith `'static`.
    ///
    /// Tá an fheidhm seo úsáideach go príomha le haghaidh sonraí a mhaireann ar feadh an chuid eile de shaol an chláir.
    /// Má scaoiltear an tagairt ar ais beidh sceitheadh cuimhne ann.
    /// Mura bhfuil sé sin inghlactha, ba chóir an tagairt a fhilleadh ar dtús leis an bhfeidhm [`Box::from_raw`] a tháirgeann `Box`.
    ///
    /// Is féidir an `Box` seo a thit ansin a scriosfaidh `T` i gceart agus a scaoilfidh an chuimhne leithdháilte.
    ///
    /// Note: is feidhm ghaolmhar í seo, rud a chiallaíonn go gcaithfidh tú é a ghlaoch mar `Box::leak(b)` in ionad `b.leak()`.
    /// Déantar é seo ionas nach mbeidh aon choimhlint ann le modh ar an gcineál istigh.
    ///
    /// # Examples
    ///
    /// Úsáid shimplí:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// Sonraí gan laghdú:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// Tiontaíonn `Box<T>` ina `Pin<Box<T>>`
    ///
    /// Ní leithdháileann an tiontú seo ar an gcarn agus tarlaíonn sé i bhfeidhm.
    ///
    /// Tá sé seo ar fáil freisin trí [`From`].
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // Ní féidir taobh istigh `Pin<Box<T>>` a bhogadh nó a athsholáthar nuair a bhíonn `T: !Unpin` ann, mar sin tá sé sábháilte é a phionáil go díreach gan aon cheanglais bhreise.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: Ná déan aon rud, déanann an tiomsaitheoir titim faoi láthair.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// Cruthaíonn sé `Box<T>`, leis an luach `Default` do T.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// Seoltar bosca nua ar ais le `clone()` d`ábhar an bhosca seo.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // Tá an luach mar an gcéanna
    /// assert_eq!(x, y);
    ///
    /// // Ach is rudaí uathúla iad
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // Réamh-leithdháileadh cuimhne chun ligean don luach clónáilte a scríobh go díreach.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// Cóipeáil ábhar `foinse` isteach i `self` gan leithdháileadh nua a chruthú.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // Tá an luach mar an gcéanna
    /// assert_eq!(x, y);
    ///
    /// // Agus níor tharla aon leithdháileadh
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // déanann sé seo cóip de na sonraí
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// Tiontaíonn cineál cineálach `T` ina `Box<T>`
    ///
    /// Leithdháileann an tiontú ar an gcarn agus bogann `t` ón gcruach isteach ann.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// Tiontaíonn `Box<T>` ina `Pin<Box<T>>`
    ///
    /// Ní leithdháileann an tiontú seo ar an gcarn agus tarlaíonn sé i bhfeidhm.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// Tiontaíonn `&[T]` ina `Box<[T]>`
    ///
    /// Leithdháileann an tiontú seo ar an gcarn agus déanann sé cóip de `slice`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // a chruthú&[faoi 8] agus bainfear leas as a chruthú Bosca <[faoi 8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// Tiontaíonn `&str` ina `Box<str>`
    ///
    /// Leithdháileann an tiontú seo ar an gcarn agus déanann sé cóip de `s`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// Tiontaíonn `Box<str>` ina `Box<[u8]>`
    /// Ní leithdháileann an tiontú seo ar an gcarn agus tarlaíonn sé i bhfeidhm.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // cruthaigh Bosca<str>a úsáidfear chun Bosca <[u8]> a chruthú
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // a chruthú&[faoi 8] agus bainfear leas as a chruthú Bosca <[faoi 8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// Tiontaíonn `[T; N]` ina `Box<[T]>`
    /// Bogann an tiontú seo an eagar go cuimhne nua-leithdháilte carn.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Déan iarracht an bosca a ísliú go cineál coincréite.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Déan iarracht an bosca a ísliú go cineál coincréite.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// Déan iarracht an bosca a ísliú go cineál coincréite.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ní féidir an Uniq istigh a bhaint go díreach as an mBosca, ach ina ionad sin caithimid é chuig * const a ailiasann an Uathúil
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// Speisialtóireacht do `Mise 'meánmhéide a úsáideann` I' a chur i bhfeidhm `last()` in ionad na réamhshocraithe.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}