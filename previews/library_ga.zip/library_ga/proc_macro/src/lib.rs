//! Leabharlann tacaíochta d`údar macra agus iad ag sainiú macraí nua.
//!
//! Soláthraíonn an leabharlann seo, arna soláthar ag an dáileadh caighdeánach, na cineálacha a ídítear i gcomhéadain na sainmhínithe macra atá sainithe go nós imeachta mar macraí cosúil le feidhm `#[proc_macro]`, macra-tréithe `#[proc_macro_attribute]` agus tréithe díorthach saincheaptha`#[proc_macro_derive]`.
//!
//!
//! Féach [the book] le haghaidh tuilleadh.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Cinneann an bhfuil proc_macro déanta rochtain ag an clár ag rith faoi láthair.
///
/// Níl an proc_macro crate beartaithe ach le húsáid taobh istigh de chur i bhfeidhm macraí nós imeachta.Gach na feidhmeanna sa crate panic má agairt ó lasmuigh de macra nós imeachta, ar nós ó script a thógáil nó tástáil aonad nó gnáth Rust dénártha.
///
/// Agus aird á tabhairt ar leabharlanna Rust atá deartha chun tacú le cásanna macra-úsáide agus neamh-macra, soláthraíonn `proc_macro::is_available()` bealach neamh-scaoll chun a fháil amach an bhfuil an bonneagar atá riachtanach chun an API de proc_macro a úsáid ar fáil faoi láthair.
/// Tuairisceáin fíor má dhéantar iad a agairt ón taobh istigh de mhacra nós imeachta, bréagach má dhéantar é a agairt ó aon dénártha eile.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// An príomh gcineál sholáthraíonn an crate, rud a léiríonn sruth teibí de tokens, nó, go sonrach, sraith de chrainn token.
/// Soláthraíonn an cineál comhéadain le haghaidh atarlú thar na crainn token sin agus, os a choinne sin, roinnt crann token a bhailiú in aon sruth amháin.
///
///
/// Is é seo ionchur agus aschur sainmhínithe `#[proc_macro]`, `#[proc_macro_attribute]` agus `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Earráid ar ais ó `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Filleann sé `TokenStream` folamh nach bhfuil aon chrainn token ann.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Seiceálacha an bhfuil an `TokenStream` seo folamh.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Iarrachtaí an tsreang a bhriseadh síos i tokens agus na tokens sin a pharsáil i sruth token.
/// D`fhéadfadh go dteipfeadh air ar chúiseanna éagsúla, mar shampla, má tá teimpléid neamhchothromaithe nó carachtair nach bhfuil sa teanga sa tsraith.
///
/// Faigheann gach tokens sa sruth parsáilte trasna `Span::call_site()`.
///
/// NOTE: d`fhéadfadh panics a bheith ina chúis le roinnt earráidí in ionad `LexError` a thabhairt ar ais.Cúlchiste againn an ceart chun athrú ar na hearráidí i`LexError`s ina dhiaidh sin.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, ní sholáthraíonn an droichead ach `to_string`, cuir `fmt::Display` i bhfeidhm bunaithe air (droim ar ais an ghnáthchaidrimh idir an dá cheann).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Priontaítear an sruth token mar shreang a cheaptar a bheith in-chomhshóite ar ais isteach sa sruth token céanna (réisí modulo), ach amháin b`fhéidir`TokenTree: : Group`s le teimpléid `Delimiter::None` agus liteartha uimhriúla diúltacha.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Priontaí token i bhfoirm atá oiriúnach le haghaidh dífhabhtaithe.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Cruthaíonn sé sruth token ina bhfuil crann token amháin.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Bailíonn sé roinnt crann token in aon sruth amháin.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Bailíonn oibríocht "flattening" ar shruthanna token, crainn token ó iliomad sruthanna token isteach i sruth amháin.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Úsáid if/when cur chun feidhme optamaithe is féidir.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// sonraí i bhfeidhm Phoiblí don chineál `TokenStream`, ar nós Iterators.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Eagaróir ar `TokenTree`s`TokenStream`s.
    /// Is é "shallow" an t-atriall, m.sh., ní fhilleann an t-atriall i ngrúpaí teorannaithe, agus filleann sé grúpaí iomlána mar chrainn token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` glacann sé le treallach tokens agus leathnaíonn sé isteach i `TokenStream` ag cur síos ar an ionchur.
/// Mar shampla, soláthróidh `quote!(a + b)` slonn, a thógfaidh, nuair a dhéantar meastóireacht air, an `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Déantar unquoting le `$`, agus oibríonn sé tríd an gcéad aitheantais aonair a ghlacadh mar an téarma neamhluaite.
/// Chun `$` féin a lua, úsáid `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Réigiún de chód foinse, mar aon le faisnéis faoi leathnú macra.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Cruthaíonn sé `Diagnostic` nua leis an `message` tugtha ag an réise `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Réimse a réitíonn ag an suíomh macra-sainmhínithe.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// An réise an agairt an macra atá ann faoi láthair nós imeachta.
    /// Réiteofar aitheantóirí a cruthaíodh leis an réise seo amhail is gur scríobhadh iad go díreach ag an suíomh macra-ghlaonna (sláinteachas láithreán glaonna) agus beidh cód eile ag an suíomh macra-ghlaonna in ann tagairt a dhéanamh dóibh freisin.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Réimse a léiríonn sláinteachas `macro_rules`, agus a réitíonn uaireanta ag an suíomh macra-sainmhínithe (athróga áitiúla, lipéid, `$crate`) agus uaireanta ag an suíomh macra-ghlaonna (gach rud eile).
    ///
    /// Is é an suíomh réise tógtha as an glaoch an láthair.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// An comhad foinse bunaidh a bhfuil an réise seo dírithe air.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// An `Span` don tokens i leathnú macra roimhe ónar gineadh `self` ó, más ann dó.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// An réise don chód foinse tionscnaimh as ar gineadh `self`.
    /// Murar gineadh an `Span` seo ó macra-fhairsingithe eile, is ionann an luach toraidh agus `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Faigheann an line/column tosaigh sa chomhad foinse don réise seo.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Faigheann an line/column dar críoch sa chomhad foinse don réise seo.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Cruthaigh réise nua a chuimsíonn `self` agus `other`.
    ///
    /// Tuairisceáin `None` má tá `self` agus `other` ó chomhaid éagsúla.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Cruthaigh réise nua leis an t-eolas line/column céanna le `self` ach go siombailí le rún amhail is dá mba ag `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Cruthaíonn sé réise nua leis an iompar réitigh ainm céanna le `self` ach leis an bhfaisnéis line/column de `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Déan comparáid idir réisí le fáil amach an bhfuil siad comhionann.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Tuairisceáin an téacs foinse taobh thiar de réimse.
    /// Caomhnaíonn sé seo an bunchód, lena n-áirítear spásanna agus tráchtanna.
    /// Ní fhilleann sé toradh ach má fhreagraíonn an réise do chód foinse fíor.
    ///
    /// Note: Níor cheart go mbeadh toradh inbhraite macra ag brath ach ar an tokens agus ní ar an mbunthéacs seo.
    ///
    /// Is é toradh na feidhme seo an iarracht is fearr le húsáid le haghaidh diagnóisic amháin.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Priontaíonn réise i bhfoirm atá oiriúnach le haghaidh dífhabhtaithe.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Péire colún líne a léiríonn tús nó deireadh `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// An líne 1-innéacsaithe sa chomhad foinse ar a dtosaíonn nó a chríochnaíonn an réise (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// An colún 0-innéacsaithe (i gcarachtair UTF-8) sa chomhad foinse ar a dtosóidh an réise nó a chríochnaíonn (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Comhad foinse `Span` ar leith.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Faigheann tú an cosán chuig an gcomhad foinse seo.
    ///
    /// ### Note
    /// Má ghin macra seachtrach an réise cód a bhaineann leis an `SourceFile` seo, an macra seo, b`fhéidir nach cosán iarbhír é seo ar an gcóras comhaid.
    /// Bain úsáid as [`is_real`] a sheiceáil.
    ///
    /// Tabhair faoi deara freisin, fiú má fhilleann `is_real` `true`, má ritheadh `--remap-path-prefix` ar an líne ordaithe, b`fhéidir nach mbeidh an cosán mar a thugtar bailí i ndáiríre.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Tuairisceáin `true` más comhad foinse fíor é an comhad foinse seo, agus nach ngineann leathnú macra seachtrach é.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Is é seo an hack go dtí go théann trasna intercrate i bhfeidhm agus is féidir linn a bheith comhaid foinse fíor do théann trasna gineadh i Macraí seachtracha.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// A token amháin nó sraith luadhfar a theoranta crann token (eg, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Sruth token timpeallaithe ag teimpléid lúibíní.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Aitheantóir.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// A carachtar poncaíochta amháin (`+`, `,`, `$`, etc.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// A carachtar litriúil (`'a'`), téad (`"hello"`), uimhir (`2.3`), etc.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Filleann sé réise an chrainn seo, ag tarmligean chuig modh `span` an token atá ann nó sruth teorannaithe.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Cumraigh an réise don *token* seo amháin.
    ///
    /// Tabhair faoi deara más `Group` an token seo, ní chumróidh an modh seo réise gach ceann de na tokens inmheánach, ní tharmligfidh sé seo ach modh `set_span` gach athraitheora.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Crann Prints token i bhfoirm áisiúil chun debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Tá an t-ainm ar gach ceann díobh seo sa chineál struchtúir sa dífhabhtaithe díorthaithe, mar sin ná bac le sraith bhreise indirection
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, ní sholáthraíonn an droichead ach `to_string`, cuir `fmt::Display` i bhfeidhm bunaithe air (droim ar ais an ghnáthchaidrimh idir an dá cheann).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Priontaítear an crann token mar shreang a cheaptar a bheidh inchomhshóite gan chailleadh ar ais sa chrann token céanna (réisí modulo), ach amháin b`fhéidir`TokenTree: : Group`s le teimpléid `Delimiter::None` agus litreacha diúltacha uimhriúla.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// A theorainneacha socraithe token sruth.
///
/// A `Group` Tá hinmheánach a `TokenStream` atá timpeallaithe ag `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Cur síos ar an gcaoi a bhfuil sraith de chrainn token theorainneacha socraithe.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// An teormharcóir intuigthe, a d'fhéadfadh, mar shampla, Is féidir le fáil timpeall tokens ag teacht ó `$var` "macro variable".
    /// Tá sé tábhachtach tosaíochtaí oibreoirí a chaomhnú i gcásanna mar `$var * 3` áit a bhfuil `$var` `1 + 2`.
    /// Ní féidir carachtair, nó réimsí Intuigthe maireachtáil roundtrip sruth token trí teaghrán.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Cruthaíonn sé `Group` nua leis an sruth delimiter agus token tugtha.
    ///
    /// Socróidh an tógálaí seo an réise don ghrúpa seo go `Span::call_site()`.
    /// Chun an réise a athrú is féidir leat an modh `set_span` thíos a úsáid.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Filleann sé teorantóir an `Group` seo
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Tuairisceáin an `TokenStream` an tokens atá teormharcáilte sa `Group`.
    ///
    /// Tabhair faoi deara nach n-áiríonn an sruth token a cuireadh ar ais an teorantóir a cuireadh ar ais thuas.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Filleann sé an réise do theorainneacha an tsrutha token seo, a chuimsíonn an `Group` iomlán.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Filleann sé an réise a dhíríonn ar theorannóir tosaigh an ghrúpa seo.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Filleann sé an réise a dhíríonn ar theorannóir deiridh an ghrúpa seo.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Cumraíonn sé an réise do theorainneacha an Ghrúpa seo, ach ní a tokens inmheánach.
    ///
    /// Ní shocróidh an modh seo ** réise na tokens inmheánach go léir a chuimsíonn an grúpa seo, ach ina ionad sin ní shocróidh sé ach réise an teimpléad tokens ag leibhéal an `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, ní sholáthraíonn an droichead ach `to_string`, cuir `fmt::Display` i bhfeidhm bunaithe air (droim ar ais an ghnáthchaidrimh idir an dá cheann).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Priontaí an grúpa mar theaghrán ba chóir a bheith ar ais losslessly inchomhshóite isteach sa ghrúpa céanna (théann trasna modulo), ach amháin i gcás b'fhéidir `TokenTree: : Group`s le carachtair, nó réimsí `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// Is carachtar poncaíochta aonair é `Punct` cosúil le `+`, `-` nó `#`.
///
/// Déantar oibreoirí ilcharachtair cosúil le `+=` a léiriú mar dhá chás de `Punct` agus foirmeacha éagsúla `Spacing` curtha ar ais.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Cibé an `Punct` é díreach tar éis `Punct` eile nó ina dhiaidh token nó spás bán eile.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// sh, tá `+` `Alone` i `+ =`, `+ident` nó `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// eg, is é `+` `Joint` in `+=` nó `'#`.
    /// Ina theannta sin, is féidir le luachan aonair `'` dul in éineacht le haitheantóirí chun saolré `'ident` a fhoirmiú.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Cruthaíonn sé `Punct` nua ón gcarachtar agus an spásáil a thugtar.
    /// Caithfidh an argóint `ch` a bheith ina carachtar poncaíochta bailí a cheadaíonn an teanga, ar shlí eile beidh an fheidhm panic.
    ///
    /// Beidh an réise réamhshocraithe `Span::call_site()` ag an `Punct` a cuireadh ar ais agus is féidir é a chumrú tuilleadh leis an modh `set_span` thíos.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Filleann luach an charachtair poncaíochta seo mar `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Tugann sé spásáil an charachtair poncaíochta seo ar ais, ag tabhairt le fios an bhfuil `Punct` eile sa sruth token ina dhiaidh sin, ionas gur féidir iad a chomhcheangal le hoibreoir ilcharachtair (`Joint`), nó go leanfaidh token nó spás bán (`Alone`) eile é agus mar sin is cinnte go bhfuil an t-oibreoir cinnte dar críoch.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Filleann sé an réise don charachtar poncaíochta seo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Cumraigh an réimse seo carachtar poncaíochta.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ní sholáthraíonn an droichead ach `to_string`, cuir `fmt::Display` i bhfeidhm bunaithe air (droim ar ais an ghnáthchaidrimh idir an dá cheann).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Priontáil an carachtar poncaíochta mar theaghrán ba chóir a bheith ar ais losslessly inchóirithe an carachtar céanna.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Aitheantóir (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Cruthaíonn sé `Ident` nua leis an `string` tugtha chomh maith leis an `span` sonraithe.
    /// Caithfidh an argóint `string` a bheith ina haitheantóir bailí a cheadaíonn an teanga (lena n-áirítear eochairfhocail, m.sh. `self` nó `fn`).Seachas sin, beidh an fheidhm panic.
    ///
    /// Tabhair faoi deara go gcumraíonn `span`, atá i rustc faoi láthair, an fhaisnéis sláinteachais don aitheantóir seo.
    ///
    /// Amhail an t-am seo, déanann `Span::call_site()` sláinteachas "call-site" a roghnú go sainráite, rud a chiallaíonn go réiteofar aitheantóirí a cruthaíodh leis an réise seo amhail is go raibh siad scríofa go díreach ag suíomh an ghlao macra, agus beidh cód eile ag an suíomh macra-ghlaonna in ann tagairt a dhéanamh dó iad freisin.
    ///
    ///
    /// Ligfidh réisí níos déanaí mar `Span::def_site()` rogha a dhéanamh do shláinteachas "definition-site" rud a chiallaíonn go réiteofar aitheantóirí a chruthaítear leis an réise seo ag suíomh an sainmhínithe macra agus ní bheidh cód eile ag an suíomh macra-ghlaonna in ann tagairt a dhéanamh dóibh.
    ///
    /// Mar gheall ar thábhacht reatha na sláinteachais, éilíonn an tógálaí seo, murab ionann agus tokens eile, `Span` a shonrú ag an tógáil.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Mar an gcéanna le `Ident::new`, ach cruthaíonn sé aitheantóir amh (`r#ident`).
    /// Is aitheantóir bailí í argóint `string` a cheadaíonn an teanga (eochairfhocail san áireamh, m.sh. `fn`).
    /// Keywords atá inúsáidte i míreanna cosáin (m.sh.
    /// `self`, `Super`) nach dtugtar tacaíocht, agus a chur faoi deara panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Filleann sé réise an `Ident` seo, ag cuimsiú na sreinge iomláine a chuir [`to_string`](Self::to_string) ar ais.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Cumraíocht an réimse seo `Ident`, b'fhéidir, a athrú ina chomhthéacs sláinteachais.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ní sholáthraíonn an droichead ach `to_string`, cuir `fmt::Display` i bhfeidhm bunaithe air (droim ar ais an ghnáthchaidrimh idir an dá cheann).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Priontáil an t-aitheantóir mar theaghrán ba chóir a bheith ar ais losslessly inchomhshóite isteach san aitheantóir céanna.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// A teaghrán litriúil (`"hello"`), beart teaghrán (`b"hello"`), carachtar (`'a'`), carachtar beart (`b'a'`), slánuimhir nó uimhir snámhphointe le nó gan iarmhír (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Ní bhaineann litreacha Boole cosúil le `true` agus `false` anseo, is `Ident`s iad.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Cruthaigh nua suffixed slánuimhir litriúil leis an méid sonraithe.
        ///
        /// Cruthóidh an fheidhm seo slánuimhir cosúil le `1u32` áit arb é luach an tslánuimhir a shonraítear an chéad chuid den token agus iarmhírtear an slánuimhir ag an deireadh freisin.
        /// Ní fhéadfaidh litreacha a chruthaítear ó uimhreacha diúltacha maireachtáil ar thurais bhabhta trí `TokenStream` nó teaghráin agus féadfar iad a bhriseadh síos ina dhá tokens (`-` agus liteartha dearfach).
        ///
        ///
        /// Tá an réise `Span::call_site()` ag litreacha a chruthaítear tríd an modh seo de réir réamhshocraithe, ar féidir iad a chumrú leis an modh `set_span` thíos.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Cruthaigh litriúil slánuimhir nua unsuffixed leis an méid sonraithe.
        ///
        /// Beidh an fheidhm chruthú slánuimhir mhaith `1` nuair a bhaineann luach slánuimhir shonraithe an chéad chuid den token.
        /// Ní shonraítear aon iarmhír ar an token seo, rud a chiallaíonn go bhfuil cuireadh mar `Literal::i8_unsuffixed(1)` comhionann le `Literal::u32_unsuffixed(1)`.
        /// Ní féidir le litriúla cruthaíodh ó uimhreacha diúltacha a maireachtáil rountrips trí `TokenStream` nó teaghráin agus féadfar é a bhriseadh suas i dhá tokens (`-` agus litriúil dearfach).
        ///
        ///
        /// Tá an réise `Span::call_site()` ag litreacha a chruthaítear tríd an modh seo de réir réamhshocraithe, ar féidir iad a chumrú leis an modh `set_span` thíos.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Cruthaíonn unsuffixed snámh-phointe litriúil nua.
    ///
    /// Tá an tógálaí seo cosúil leis na cinn cosúil le `Literal::i8_unsuffixed` ina n-astaítear luach an snámháin go díreach isteach sa token ach nach n-úsáidtear iarmhír, mar sin féadtar a thuiscint gur `f64` é níos déanaí sa tiomsaitheoir.
    ///
    /// Ní féidir le litriúla cruthaíodh ó uimhreacha diúltacha a maireachtáil rountrips trí `TokenStream` nó teaghráin agus féadfar é a bhriseadh suas i dhá tokens (`-` agus litriúil dearfach).
    ///
    /// # Panics
    ///
    /// Éilíonn an fheidhm go bhfuil an snámhphointe shonraithe críochta, mar shampla má tá sé Infinity nó NaN an fheidhm sin a panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Cruthaíonn suffixed snámh-phointe litriúil nua.
    ///
    /// Beidh sé seo cruthaitheoir chruthú liteartha cosúil `1.0f32` nuair a bhaineann luach sonraithe chuid sin roimhe an token agus is `f32` an iarmhír an token.
    /// Beidh an token a thuiscint i gcónaí a bheith ina `f32` sa tiomsaitheoir.
    /// Ní féidir le litriúla cruthaíodh ó uimhreacha diúltacha a maireachtáil rountrips trí `TokenStream` nó teaghráin agus féadfar é a bhriseadh suas i dhá tokens (`-` agus litriúil dearfach).
    ///
    ///
    /// # Panics
    ///
    /// Éilíonn an fheidhm go bhfuil an snámhphointe shonraithe críochta, mar shampla má tá sé Infinity nó NaN an fheidhm sin a panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Cruthaíonn unsuffixed snámh-phointe litriúil nua.
    ///
    /// Tá an tógálaí seo cosúil leis na cinn cosúil le `Literal::i8_unsuffixed` ina n-astaítear luach an snámháin go díreach isteach sa token ach nach n-úsáidtear iarmhír, mar sin féadtar a thuiscint gur `f64` é níos déanaí sa tiomsaitheoir.
    ///
    /// Ní féidir le litriúla cruthaíodh ó uimhreacha diúltacha a maireachtáil rountrips trí `TokenStream` nó teaghráin agus féadfar é a bhriseadh suas i dhá tokens (`-` agus litriúil dearfach).
    ///
    /// # Panics
    ///
    /// Éilíonn an fheidhm go bhfuil an snámhphointe shonraithe críochta, mar shampla má tá sé Infinity nó NaN an fheidhm sin a panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Cruthaíonn suffixed snámh-phointe litriúil nua.
    ///
    /// Cruthóidh an tógálaí seo liteartha cosúil le `1.0f64` áit arb é an luach a shonraítear an chuid roimhe seo den token agus gurb é `f64` iarmhír an token.
    /// Déanfar an token seo a thátal i gcónaí mar `f64` sa tiomsaitheoir.
    /// Ní féidir le litriúla cruthaíodh ó uimhreacha diúltacha a maireachtáil rountrips trí `TokenStream` nó teaghráin agus féadfar é a bhriseadh suas i dhá tokens (`-` agus litriúil dearfach).
    ///
    ///
    /// # Panics
    ///
    /// Éilíonn an fheidhm go bhfuil an snámhphointe shonraithe críochta, mar shampla má tá sé Infinity nó NaN an fheidhm sin a panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Teaghrán liteartha.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Carachtar liteartha.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Beart teaghrán liteartha.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Filleann sé an réise a chuimsíonn an liteartha seo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Cumraíonn sé an réise a bhaineann leis an liteartha seo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Filleann sé `Span` ar fo-thacar de `self.span()` é nach bhfuil ann ach na bearta foinse i raon `range`.
    /// Tuairisceáin `None` má tá an réimse a bheadh-a bhearradh lasmuigh de theorainneacha `self`.
    ///
    // FIXME(SergioBenitez): seiceáil go dtosaíonn agus go gcríochnaíonn an raon beart ag teorainn UTF-8 den fhoinse.
    // a mhalairt, tá sé dóchúil go mbeidh panic tharlaíonn aon áit eile nuair a bhíonn an téacs foinse clóite.
    // FIXME(SergioBenitez): níl aon bhealach chun an t-úsáideoir a fháil amach cad léarscáileanna `self.span()` i ndáiríre go, ionas gur féidir an modh seo faoi láthair a dtugtar ach blindly.
    // Mar shampla, `to_string()` do charachtar 'c' tuairisceáin "'\u{63}'";níl aon bhealach ann go mbeadh a fhios ag an úsáideoir an raibh an téacs foinse 'c' nó an '\u{63}' a bhí ann.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) rud éigin cosúil le `Option::cloned`, ach le haghaidh `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, ní sholáthraíonn an droichead ach `to_string`, cuir `fmt::Display` i bhfeidhm bunaithe air (droim ar ais an ghnáthchaidrimh idir an dá cheann).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Priontaí an litriúil mar theaghrán ba chóir a bheith ar ais losslessly inchóirithe an litriúil céanna (ach amháin i gcás slánú is féidir do litriúla snámhphointe).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Rochtain rianaithe ar athróga comhshaoil.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Aisghabh ar athróg timpeallachta agus é a chur le cur info spleáchas.
    /// Beidh a fhios ag an gcóras tógála a fhorghníomhaíonn an tiomsaitheoir go ndearnadh rochtain ar an athróg le linn an tiomsú, agus go mbeidh sé in ann an tógáil a athcheangal nuair a athróidh luach an athróg sin.
    ///
    /// Chomh maith le ba chóir an spleáchas rianú an fheidhm seo a bheith coibhéiseach le `env::var` ón leabharlann caighdeánach, a eisceadh go gcaithfidh an argóint a UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}