//! `Cell` malairt ar feadh saolré existential (scoped).

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// Cineál lambda-iarratas, le ar feadh an tsaoil.
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// Cineál lambda a thógann ar feadh an tsaoil, ie, `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) obair timpeall teorainneacha teilgean le FIXME(#52812) newtype ina ionad `&'a mut <T as ApplyL<'b>>::Out`
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// Socraíonn sé an luach in `self` go `replacement` agus tú ag rith `f`, a fhaigheann an seanluach, go frithpháirteach.
    /// Beidh an luach sean a chur ar ais i ndiaidh bealaí amach `f`, fiú ag panic, lena n-áirítear modhnuithe a dhéanfar chuige faoi `f`.
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// Fillteán a chinntíonn go líontar an cill i gcónaí (leis an stát bunaidh, arna athrú go roghnach ag `f`), fiú má bhí `f` tar éis piocadh.
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// Socraigh an luach i `self` go `value` agus a reáchtáil `f`.
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}