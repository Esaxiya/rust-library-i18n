#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// Féach [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_READ: i32 = 0;

/// Féach [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_WRITE: i32 = 1;

/// Féach [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// Féach [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// Féach [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// Féach [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// Faigh an líne taisce ina bhfuil seoladh `p` agus an `rw` agus `locality` tugtha agat.
///
/// Ní mór don `rw` bheith ar cheann de:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): Tá an prefetch ullmhú le haghaidh léamh.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): tá an réamhfhocal ag ullmhú do scríbhinn.
///
/// Ní mór don `locality` bheith ar cheann de:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): Réamhtheacht sruthaithe nó neamh-ama, le haghaidh sonraí nach n-úsáidtear ach uair amháin.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): Beir isteach leibhéal 3 taisce.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): Beir isteach ar leibhéal 2 taisce.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): Beir i leibhéal 1 taisce.
///
/// Tugann an treoir treoracha cuimhne réamhshocraithe comhartha don chóras cuimhne gur dóigh go mbeidh rochtain ar chuimhne ó sheoladh sonraithe gar do future.
/// Féidir leis an gcóras cuimhne freagra trí ghníomhartha a bhfuiltear ag súil chun dlús a chur leis an rochtain cuimhne nuair a tharlaíonn siad, ar nós Réamhluchtáil an seoladh sonraithe i caches amháin nó níos mó a thógáil.
///
/// Toisc nach bhfuil sna comharthaí seo ach leideanna, tá sé bailí do LAP áirithe aon cheann nó gach treoir réamhshocraithe a láimhseáil mar NOP.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // Bainimid úsáid as an `llvm.prefetch` instrinsic le `cache type` =1 (taisce sonraí).
    // `rw` agus tá siad `strategy` bunaithe ar na paraiméadair fheidhm.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}