`core::arch` - Croí-ailtireacht shonrach ailtireachta leabharlainne Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Cuireann an modúl `core::arch` intreacha atá ag brath ar ailtireacht i bhfeidhm (m.sh. SIMD).

# Usage 

`core::arch` ar fáil mar chuid den `libcore` agus tá sé ath-heasportáladh `libstd`.Is fearr é a úsáid trí `core::arch` nó `std::arch` ná tríd an crate seo.
Is minic a bhíonn gnéithe éagobhsaí ar fáil i Rust oíche tríd an `feature(stdsimd)`.

Ag baint úsáide as `core::arch` tríd an crate Éilíonn gach oíche Rust, agus is féidir é (agus a dhéanann) briseadh go minic.Is iad na cásanna amháin ina ba cheart duit smaoineamh ag baint úsáide as é tríd an crate:

* más gá duit `core::arch` a ath-thiomsú tú féin, m.sh., le gnéithe sprice áirithe cumasaithe nach bhfuil cumasaithe do `libcore`/`libstd`.
Note: más gá duit a ath-chur le chéile é ar feadh sprioc neamhchaighdeánach, le do thoil fearr ag baint úsáide as `xargo` agus ath-thiomsú `libcore`/`libstd` réir mar is iomchuí seachas úsáid a bhaint an crate.
  
* ag baint úsáide as roinnt gnéithe nach d'fhéadfadh a bheith ar fáil, fiú taobh thiar gnéithe éagobhsaí Rust.déanaimid ár ndícheall chun iad a choinneáil ar a laghad.
Más gá duit a úsáid roinnt de na gnéithe seo, le do thoil oscailt ceist ionas gur féidir linn iad a nochtadh i gach oíche Rust agus is féidir leat iad a úsáid ó ann.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` Déantar é a dháileadh go príomha faoi théarmaí an cheadúnais MIT agus an Cheadúnais Apache (Leagan 2.0), le codanna clúdaithe ag ceadúnais éagsúla cosúil le BSD.

Féach LICENSE-APACHE, agus LICENSE-MIT le haghaidh sonraí.

# Contribution

Mura tú go sainráite stáit a mhalairt, déanfar aon ranníocaíocht ghnó isteach le cur san áireamh i `core_arch` ag tú, mar atá sainmhínithe sa cheadúnas Apache-2.0, a dhé ceadúnaithe mar atá thuas, gan aon téarmaí nó coinníollacha breise.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












