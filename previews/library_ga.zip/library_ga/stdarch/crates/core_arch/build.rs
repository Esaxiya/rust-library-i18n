use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // A úsáidtear chun insint ár nótaí `#[assert_instr]` go bhfuil gach intrinsics SIMD fáil chun tástáil a n codegen, ós rud é go bhfuil roinnt gated taobh thiar `-Ctarget-feature=+unimplemented-simd128` breise nach bhfuil aon choibhéis i `#[target_feature]` ceart anois.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}