# Ag cur le stdarch

Tá an crate `stdarch` níos mó ná sásta glacadh le ranníocaíochtaí!An Chéad beidh tú ag iarraidh dócha a sheiceáil amach an stór agus a chinntiú go pas tástálacha ar do shon:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Sa chás go bhfuil `<your-target-arch>` an sprioc triple in úsáid mar ag `rustup`, eg `x86_x64-unknown-linux-gnu` (gan aon `nightly-` roimhe sin nó a leithéid).
Chomh maith leis cuimhnigh go n-éilíonn an stór ar an cainéal gach oíche de Rust!
Éilíonn na tástálacha thuas a dhéanamh i ndáiríre gach oíche rust a bheith ar an réamhshocraithe ar do chóras, a shocrú go úsáid `rustup default nightly` (agus `rustup default stable` dul ar ais).

Mura bhfuil aon cheann de na céimeanna thuas obair, [please let us know][new]!

Next suas is féidir leat [find an issue][issues] chun cuidiú amach ar, tá muid roghnaithe a lua leis an [`help wanted`][help] agus [`impl-period`][impl] clibeanna a d'fhéadfadh a úsáideann go háirithe roinnt cabhrú leat. 
D'fhéadfá a bheith an chuid is mó suim acu i [#40][vendor], a chur i bhfeidhm go léir intrinsics díoltóir ar x86.Go s eisiúint fuair roinnt leideanna maith faoin áit chun tús a!

Má tá ceisteanna ginearálta agat bíodh leisce ort [join us on gitter][gitter] agus fiafraigh timpeall!Thig leat a ping ceachtar@BurntSushi nó@alexcrichton le ceisteanna.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Conas samplaí a scríobh le haghaidh intreacha stdarch

Tá cúpla gné ann nach mór a chumasú chun go n-oibreoidh an intreach áirithe i gceart agus ní mór an sampla a rith le `cargo test --doc` ach amháin nuair a thacaíonn an LAP leis an ngné.

Mar thoradh air sin, ní oibreoidh an `fn main` réamhshocraithe a ghineann `rustdoc` (i bhformhór na gcásanna).
Smaoinigh ar an méid seo a leanas a úsáid mar threoir chun a chinntiú go n-oibreoidh do shampla mar a bhí súil leis.

```rust
/// # // Teastaíonn cfg_target_feature uainn chun a chinntiú nach bhfuil sa sampla ach
/// # // á reáchtáil ag `cargo test --doc` nuair a thacaíonn an LAP leis an ngné
/// # #![feature(cfg_target_feature)]
/// # // gá againn target_feature don intreach d'obair
/// # #![feature(target_feature)]
/// #
/// # // rustdoc trí mhainneachtain Úsáideann `extern crate stdarch`, ach is gá dúinn an
/// # // `#[macro_use]`
/// # # [Macro_use] seachtrach crate stdarch;
/// #
/// # // An phríomhfheidhm fíor
/// # fn main() {
/// #     // Ná rith é seo ach má thacaítear le `<target feature>`
/// #     más cfg_feature_enabled! ("<target feature>"){
/// #         // Cruthaigh feidhm `worker` nach rithfear ach má tá an ghné sprice ann
/// #         // Tá tacaíocht agus a chinntiú go bhfuil `target_feature` cumasaithe do do oibrí
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         neamhshábháilte fn worker() {
/// // Scríobh do shampla anseo.Beidh intrinsics sonracha Gné obair anseo!Téigh fiáin!
///
/// #         }
///
/// #         neamhshábháilte { worker(); }
/// #     }
/// # }
```

Más rud é nach ndéanann cuid de na chomhréir thuas cuma ar an eolas, cur síos ar an t-alt [Documentation as tests] den [Rust Book] an error `rustdoc` go measartha maith.
Mar is gnáth, glaoch a [join us on gitter][gitter] agus iarr linn má bhuail tú aon snags, agus go raibh maith agat as cuidiú chun feabhas a chur ar an doiciméadú na `stdarch`!

# Treoracha Tástáil Malartacha

Luaitear mar mholadh go ginearálta go n-úsáideann tú `ci/run.sh` a rith na tástálacha.
Mar sin féin ní fhéadfadh sé seo a bheith ag obair ar do shon, mar shampla má tá tú ar Windows.

Sa chás sin is féidir leat titim ar ais go dtí a reáchtáil `cargo +nightly test` agus `cargo +nightly test --release -p core_arch` le haghaidh tástála a ghiniúint cód.
Tabhair faoi deara go n-éilíonn siad seo an t-uirlisí oíche a shuiteáil agus go mbeadh eolas ag `rustc` faoi do sprioc triple agus a LAP.
Go háirithe ní mór duit an athróg timpeallachta `TARGET` a shocrú mar a dhéanfá le haghaidh `ci/run.sh`.
Ina theannta sin ní mór duit a shocrú `RUSTCFLAGS` (riachtanas an `C`) a chur in iúl gnéithe sprioc, mar shampla `RUSTCFLAGS="-C -target-features=+avx2"`.
Is féidir leat a leagtar freisin `-C -target-cpu=native` má tá tú ag "just" fhorbairt i gcoinne do LAP atá ann faoi láthair.

Bí rabhadh go nuair a úsáideann tú na treoracha eile, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], eg
Is féidir tástálacha a ghiniúint teagasc theipeann mar gheall ar an dídhíolamóra ainmnithe iad éagsúil, eg
féadfaidh sé `vaesenc` a ghiniúint in ionad treoracha `aesenc` ainneoin iad a bheith ag iompar mar an gcéanna.
Chomh maith leis sin déanann na treoracha seo níos lú tástálacha ná mar a dhéanfaí de ghnáth, mar sin ná bíodh iontas ort go bhféadfadh roinnt earráidí a bheith i dtástálacha nach gclúdaítear anseo nuair a dhéanann tú iarratas sa deireadh.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






