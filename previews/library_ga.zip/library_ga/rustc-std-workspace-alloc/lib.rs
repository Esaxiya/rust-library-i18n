#![feature(no_core)]
#![no_core]

// Féach rustc-std-spás oibre-lárnach fáth go bhfuil an crate ag teastáil.

// Athainmnigh an crate a sheachaint salach ar an modúl alloc in liballoc.
extern crate alloc as foo;

pub use foo::*;