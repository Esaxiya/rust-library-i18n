# An `rustc-std-workspace-core` crate

Is crate caol agus folamh é an crate seo atá ag brath go simplí ar `libcore` agus a ábhar ar fad a athsheoladh.
Is é an crate an crux cumhacht a thabhairt don leabharlann caighdeánach brath ar crates ó crates.io

Crates ar crates.io a bhfuil an leabharlann chaighdeánach ag brath air is gá a bheith ag brath ar an `rustc-std-workspace-core` crate ó crates.io, atá folamh.

Bainimid úsáid as `[patch]` a shárú go dtí seo crate sa stór.
Mar thoradh air sin, tarraingeoidh crates ar crates.io spleáchas edge go `libcore`, an leagan atá sainithe sa stór seo.
Ba cheart go dtarraingeodh sé sin na himill spleáchais ar fad chun a chinntiú go dtógfaidh Cargo crates go rathúil!

Tabhair faoi deara gur gá crates ar crates.io bheith ag brath ar an crate leis an ainm `core` do gach rud a bheith ag obair i gceart.Chun é sin a dhéanamh is féidir leo a úsáid:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Trí úsáid a bhaint as an eochair `package`, athainmnítear an crate go `core`, rud a chiallaíonn go mbeidh an chuma air

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

nuair a agraíonn Cargo an Tiomsaitheoir, a shásamh an treoir `extern crate core` intuigthe ghann ag an tiomsaitheoir.




