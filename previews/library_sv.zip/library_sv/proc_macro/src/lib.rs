//! Ett supportbibliotek för makroförfattare när nya makron definieras.
//!
//! Detta bibliotek, som tillhandahålls av standarddistributionen, tillhandahåller de typer som konsumeras i gränssnitten för procedurdefinierade makrodefinitioner såsom funktionsliknande makron `#[proc_macro]`, makroattribut `#[proc_macro_attribute]` och anpassade härledningsattribut '#[proc_macro_derive] `.
//!
//!
//! Se [the book] för mer information.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Avgör om proc_macro har gjorts tillgängligt för det program som för närvarande körs.
///
/// Proc_macro crate är endast avsedd att användas inom implementeringen av procedurmakron.Alla funktioner i denna crate panic om de anropas utifrån ett procedurmakro, till exempel från ett byggskript eller enhetstest eller vanligt Rust-binärt.
///
/// Med hänsyn till Rust-bibliotek som är utformade för att stödja både makro-och icke-makroanvändningsfall, erbjuder `proc_macro::is_available()` ett panikfritt sätt att upptäcka om infrastrukturen som krävs för att använda API för proc_macro för närvarande är tillgänglig.
/// Returnerar sant om det anropas från insidan av ett procedurmakro, falskt om det åberopas från någon annan binär.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Huvudtypen som tillhandahålls av denna crate, som representerar en abstrakt ström av tokens, eller mer specifikt en sekvens av token-träd.
/// Typen tillhandahåller gränssnitt för iterering över dessa token-träd och omvänt att samla in ett antal token-träd i en ström.
///
///
/// Detta är både in-och utgången för `#[proc_macro]`-, `#[proc_macro_attribute]`-och `#[proc_macro_derive]`-definitioner.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Fel returnerat från `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Returnerar en tom `TokenStream` som inte innehåller några token-träd.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Kontrollerar om den här `TokenStream` är tom.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Försök att bryta strängen i tokens och analysera dessa tokens i en token-ström.
/// Kan misslyckas av flera anledningar, till exempel om strängen innehåller obalanserade avgränsare eller tecken som inte finns på språket.
///
/// Alla tokens i den analyserade strömmen får `Span::call_site()`-spann.
///
/// NOTE: vissa fel kan orsaka panics istället för att returnera `LexError`.Vi förbehåller oss rätten att ändra dessa fel till 'LexError' senare.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// OBS, bryggan tillhandahåller bara `to_string`, implementerar `fmt::Display` baserat på den (det motsatta av det vanliga förhållandet mellan de två).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Skriver ut token-strömmen som en sträng som ska vara förlustlöst omvandlingsbar till samma token-ström (modulo spänner), förutom eventuellt 'TokenTree: : Groups med `Delimiter::None` avgränsare och negativa numeriska bokstäver.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Skriver ut token i en form som är bekväm för felsökning.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Skapar en token-ström som innehåller ett enda token-träd.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Samlar ett antal token-träd i en enda ström.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// En "flattening"-operation på token-strömmar, samlar token-träd från flera token-strömmar till en enda ström.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Använd en optimerad implementering if/when möjlig.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Offentliga implementeringsdetaljer för `TokenStream`-typen, såsom iteratorer.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// En iterator över TokenStreams TokenTree.
    /// Iterationen är "shallow", t.ex. återgår inte iteratorn till avgränsade grupper och returnerar hela grupper som token-träd.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` accepterar godtycklig tokens och expanderar till en `TokenStream` som beskriver ingången.
/// Till exempel kommer `quote!(a + b)` att producera ett uttryck som, när det utvärderas, konstruerar `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Unquoting görs med `$` och fungerar genom att ta nästa nästa ident som den unciterade termen.
/// För att citera `$` själv, använd `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// En region med källkoden, tillsammans med information om makroxpansion.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Skapar en ny `Diagnostic` med den givna `message` i intervallet `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Ett intervall som löser sig på makrodefinitionswebbplatsen.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Omfattningen av anropet av det nuvarande förfarandemakroet.
    /// Identifierare som skapats med detta intervall kommer att lösas som om de skrevs direkt på makroanropsplatsen (samtalshygien) och annan kod på makroanropsplatsen kan också hänvisa till dem.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Ett intervall som representerar `macro_rules`-hygien och ibland löser sig på makrodefinieringsplatsen (lokala variabler, etiketter, `$crate`) och ibland på makroanropsplatsen (allt annat).
    ///
    /// Spännplatsen tas från samtalsplatsen.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Den ursprungliga källfilen som detta spann pekar in i.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` för tokens i föregående makroutvidgning från vilken `self` genererades från, om någon.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Spännvidden för ursprungskällkoden som `self` genererades från.
    /// Om denna `Span` inte genererades från andra makroutvidgningar är returvärdet detsamma som `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Hämtar start-line/column i källfilen för detta intervall.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Hämtar slutet av line/column i källfilen för detta intervall.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Skapar ett nytt intervall som omfattar `self` och `other`.
    ///
    /// Returnerar `None` om `self` och `other` kommer från olika filer.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Skapar ett nytt intervall med samma line/column-information som `self` men som löser symboler som om det vore vid `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Skapar ett nytt intervall med samma upplösningsbeteende som `self` men med line/column-informationen på `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Jämfört med spann för att se om de är lika.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Returnerar källtexten bakom ett intervall.
    /// Detta bevarar den ursprungliga källkoden, inklusive mellanslag och kommentarer.
    /// Det returnerar bara ett resultat om intervallet motsvarar verklig källkod.
    ///
    /// Note: Det observerbara resultatet av ett makro bör endast förlita sig på tokens och inte på denna källtext.
    ///
    /// Resultatet av denna funktion är ett bästa försök att endast användas för diagnostik.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Skriver ut ett intervall i ett formulär som är bekvämt för felsökning.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Ett linjekolumnpar som representerar början eller slutet av en `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Den 1-indexerade raden i källfilen där intervallet börjar eller slutar (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Den 0-indexerade kolumnen (i UTF-8-tecken) i källfilen där intervallet börjar eller slutar (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Källfilen för en viss `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Hämtar sökvägen till den här källfilen.
    ///
    /// ### Note
    /// Om kodspänningen associerad med den här `SourceFile` genererades av ett externt makro, det här makrot, kanske det här inte är en riktig sökväg i filsystemet.
    /// Använd [`is_real`] för att kontrollera.
    ///
    /// Observera också att även om `is_real` returnerar `true`, om `--remap-path-prefix` skickades på kommandoraden, kanske den angivna sökvägen inte är giltig.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Returnerar `true` om den här källfilen är en riktig källfil och inte genereras av ett externt makro-expansion.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Detta är ett hack tills intercrate-spänningar implementeras och vi kan ha riktiga källfiler för spänningar som genereras i externa makron.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// En enda token eller en avgränsad sekvens av token-träd (t.ex. `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// En token-ström omgiven av parentesavgränsare.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// En identifierare.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Ett enda skiljetecken (`+`, `,`, `$`, etc.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// En bokstavlig karaktär (`'a'`), sträng (`"hello"`), nummer (`2.3`), etc.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Returnerar spannet för detta träd och delegerar till `span`-metoden för den inneslutna token eller en avgränsad ström.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Konfigurerar intervallet för *endast denna token*.
    ///
    /// Observera att om denna token är en `Group`, konfigurerar denna metod inte spännvidden för var och en av de interna tokens, detta kommer helt enkelt att delegeras till `set_span`-metoden för varje variant.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Skriver ut token-träd i en form som är bekväm för felsökning.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Var och en av dessa har namnet i strukturtypen i den härledda felsökningen, så bry dig inte om ett extra lager av indirektion
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// OBS, bryggan tillhandahåller bara `to_string`, implementerar `fmt::Display` baserat på den (det motsatta av det vanliga förhållandet mellan de två).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Skriver ut token-trädet som en sträng som ska vara förlustlöst omvandlingsbar till samma token-träd (modulo spänner), med undantag för möjligen `TokenTree: : Group`s med `Delimiter::None` avgränsare och negativa numeriska bokstäver.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// En avgränsad token-ström.
///
/// En `Group` innehåller internt en `TokenStream` som omges av "avgränsare".
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Beskriver hur en sekvens av token-träd avgränsas.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// En implicit avgränsare, som till exempel kan visas runt tokens som kommer från en "macro variable" `$var`.
    /// Det är viktigt att bevara operatörens prioriteringar i fall som `$var * 3` där `$var` är `1 + 2`.
    /// Implicita avgränsare kanske inte överlever en token-ström genom en sträng.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Skapar en ny `Group` med angiven avgränsare och token-ström.
    ///
    /// Denna konstruktör ställer in spännvidden för denna grupp till `Span::call_site()`.
    /// För att ändra intervallet kan du använda `set_span`-metoden nedan.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Returnerar avgränsaren för denna `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Returnerar `TokenStream` för tokens som är avgränsade i denna `Group`.
    ///
    /// Observera att den returnerade token-strömmen inte inkluderar avgränsaren som returneras ovan.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Returnerar intervallet för avgränsarna för denna token-ström, som spänner över hela `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Returnerar intervallet som pekar på inledningsavgränsaren för denna grupp.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Returnerar intervallet som pekar på den avgränsande avgränsaren för denna grupp.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Konfigurerar intervallet för den här gruppens avgränsare, men inte dess interna tokens.
    ///
    /// Denna metod **kommer inte** att ställa in intervallet för alla de interna tokens som spänns av denna grupp, utan snarare bara ställa in intervallet för avgränsaren tokens på nivån för `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// OBS, bryggan tillhandahåller bara `to_string`, implementerar `fmt::Display` baserat på den (det motsatta av det vanliga förhållandet mellan de två).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Skriver ut gruppen som en sträng som ska vara förlustlöst konverterbar till samma grupp (modulo spans), med undantag för eventuellt `TokenTree: : Group`s med `Delimiter::None` avgränsare.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// En `Punct` är en enda skiljetecken som `+`, `-` eller `#`.
///
/// Flera karaktärsoperatörer som `+=` representeras som två instanser av `Punct` med olika former av `Spacing` returnerade.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Oavsett om en `Punct` följs omedelbart av en annan `Punct` eller följs av en annan token eller ett mellanslag.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// till exempel är `+` `Alone` i `+ =`, `+ident` eller `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// till exempel är `+` `Joint` i `+=` eller `'#`.
    /// Dessutom kan enstaka offert `'` gå med identifierare för att bilda livstid `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Skapar en ny `Punct` från den givna karaktären och avståndet.
    /// `ch`-argumentet måste vara ett giltigt skiljetecken tillåtet av språket, annars kommer funktionen att panic.
    ///
    /// Den returnerade `Punct` har standardintervallet `Span::call_site()` som kan konfigureras ytterligare med `set_span`-metoden nedan.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Returnerar värdet på denna skiljetecken som `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Returnerar avståndet för detta skiljetecken, vilket indikerar om det omedelbart följs av en annan `Punct` i token-strömmen, så att de potentiellt kan kombineras till en multi-teckenoperatör (`Joint`), eller om det följs av någon annan token eller ett blanksteg (`Alone`) så att operatören verkligen har slutade.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Returnerar intervallet för denna skiljetecken.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigurera intervallet för denna skiljetecken.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// OBS, bryggan tillhandahåller bara `to_string`, implementerar `fmt::Display` baserat på den (det motsatta av det vanliga förhållandet mellan de två).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Skriver ut interpunktionstecknet som en sträng som ska vara förlustfritt konverterbar till samma tecken.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// En identifierare (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Skapar en ny `Ident` med angiven `string` samt den angivna `span`.
    /// `string`-argumentet måste vara en giltig identifierare som är tillåten av språket (inklusive nyckelord, t.ex. `self` eller `fn`).I annat fall kommer funktionen panic.
    ///
    /// Observera att `span`, för närvarande i rustc, konfigurerar hygieninformationen för denna identifierare.
    ///
    /// Från och med den här tiden väljer `Span::call_site()` uttryckligen in i "call-site"-hygien, vilket innebär att identifierare som skapats med detta intervall kommer att lösas som om de skrevs direkt på platsen för makroanropet, och annan kod på makroanropssidan kan hänvisa till dem också.
    ///
    ///
    /// Senare spänningar som `Span::def_site()` gör det möjligt att välja "definition-site"-hygien, vilket innebär att identifierare som skapats med detta intervall kommer att lösas på platsen för makrodefinitionen och annan kod på platsen för makroanrop kan inte hänvisa till dem.
    ///
    /// På grund av hygienens nuvarande betydelse kräver denna konstruktör, till skillnad från andra tokens, att en `Span` ska specificeras vid konstruktionen.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Samma som `Ident::new`, men skapar en rå identifierare (`r#ident`).
    /// `string`-argumentet är en giltig identifierare som tillåts av språket (inklusive nyckelord, t.ex. `fn`).
    /// Nyckelord som är användbara i bansegment (t.ex.
    /// `self`, 'super') stöds inte och kommer att orsaka en panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Returnerar intervallet för denna `Ident`, som omfattar hela strängen som returneras av [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigurerar räckvidden för denna `Ident`, eventuellt ändrar dess hygienkontext.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// OBS, bryggan tillhandahåller bara `to_string`, implementerar `fmt::Display` baserat på den (det motsatta av det vanliga förhållandet mellan de två).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Skriver ut identifieraren som en sträng som ska vara förlustfritt omvandlingsbar till samma identifierare.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// En bokstavsträng (`"hello"`), byte-sträng (`b"hello"`), tecken (`'a'`), byte-tecken (`b'a'`), ett heltal eller flyttal med eller utan suffix (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Booleska bokstäver som `true` och `false` hör inte hemma, de är `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Skapar ett nytt suffix heltal bokstavligt med det angivna värdet.
        ///
        /// Denna funktion skapar ett heltal som `1u32` där det angivna helvärdet är den första delen av token och integralen också är suffix i slutet.
        /// Bokstäver skapade med negativa siffror kanske inte överlever rundresor genom `TokenStream` eller strängar och kan delas upp i två tokens (`-` och positiva bokstäver).
        ///
        ///
        /// Bokstäver skapade med den här metoden har `Span::call_site()`-intervallet som standard, vilket kan konfigureras med `set_span`-metoden nedan.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Skapar ett nytt icke-fixerat heltal bokstavligt med det angivna värdet.
        ///
        /// Denna funktion skapar ett heltal som `1` där det angivna helvärdet är den första delen av token.
        /// Inget suffix anges på denna token, vilket betyder att anrop som `Literal::i8_unsuffixed(1)` motsvarar `Literal::u32_unsuffixed(1)`.
        /// Bokstäver skapade med negativa tal kanske inte överlever rountrips genom `TokenStream` eller strängar och kan delas in i två tokens (`-` och positiva bokstäver).
        ///
        ///
        /// Bokstäver skapade med den här metoden har `Span::call_site()`-intervallet som standard, vilket kan konfigureras med `set_span`-metoden nedan.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Skapar en ny icke-fixerad flytande punkt bokstavlig.
    ///
    /// Denna konstruktör liknar de som `Literal::i8_unsuffixed` där flottörens värde emitteras direkt till token men inget suffix används, så det kan härledas att vara en `f64` senare i kompilatorn.
    ///
    /// Bokstäver skapade med negativa tal kanske inte överlever rountrips genom `TokenStream` eller strängar och kan delas in i två tokens (`-` och positiva bokstäver).
    ///
    /// # Panics
    ///
    /// Denna funktion kräver att den angivna flottören är ändlig, till exempel om den är oändlig eller NaN kommer denna funktion att panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Skapar en ny suffix flytande punkt bokstavlig.
    ///
    /// Denna konstruktör skapar en bokstav som `1.0f32` där det angivna värdet är den föregående delen av token och `f32` är suffixet för token.
    /// Denna token kommer alltid att bli en `f32` i kompilatorn.
    /// Bokstäver skapade med negativa tal kanske inte överlever rountrips genom `TokenStream` eller strängar och kan delas in i två tokens (`-` och positiva bokstäver).
    ///
    ///
    /// # Panics
    ///
    /// Denna funktion kräver att den angivna flottören är ändlig, till exempel om den är oändlig eller NaN kommer denna funktion att panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Skapar en ny icke-fixerad flytande punkt bokstavlig.
    ///
    /// Denna konstruktör liknar de som `Literal::i8_unsuffixed` där flottörens värde emitteras direkt till token men inget suffix används, så det kan härledas att vara en `f64` senare i kompilatorn.
    ///
    /// Bokstäver skapade med negativa tal kanske inte överlever rountrips genom `TokenStream` eller strängar och kan delas in i två tokens (`-` och positiva bokstäver).
    ///
    /// # Panics
    ///
    /// Denna funktion kräver att den angivna flottören är ändlig, till exempel om den är oändlig eller NaN kommer denna funktion att panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Skapar en ny suffix flytande punkt bokstavlig.
    ///
    /// Denna konstruktör skapar en bokstav som `1.0f64` där det angivna värdet är den föregående delen av token och `f64` är suffixet för token.
    /// Denna token kommer alltid att bli en `f64` i kompilatorn.
    /// Bokstäver skapade med negativa tal kanske inte överlever rountrips genom `TokenStream` eller strängar och kan delas in i två tokens (`-` och positiva bokstäver).
    ///
    ///
    /// # Panics
    ///
    /// Denna funktion kräver att den angivna flottören är ändlig, till exempel om den är oändlig eller NaN kommer denna funktion att panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Sträng bokstavlig.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Karaktär bokstavlig.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Byte sträng bokstavlig.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Returnerar intervallet som omfattar denna bokstavliga.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigurerar intervallet för denna bokstav.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Returnerar en `Span` som är en delmängd av `self.span()` som endast innehåller källbyten i intervallet `range`.
    /// Returnerar `None` om det trimmade intervallet ligger utanför gränserna för `self`.
    ///
    // FIXME(SergioBenitez): kontrollera att byteområdet börjar och slutar vid en UTF-8-gräns för källan.
    // annars är det troligt att en panic kommer att förekomma någon annanstans när källtexten skrivs ut.
    // FIXME(SergioBenitez): det finns inget sätt för användaren att veta vad `self.span()` faktiskt kartlägger till, så den här metoden kan för närvarande bara kallas blindt.
    // Till exempel returnerar `to_string()` för tecknet 'c' "'\u{63}'";det finns inget sätt för användaren att veta om källtexten var 'c' eller om det var '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) något som liknar `Option::cloned`, men för `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// OBS, bryggan tillhandahåller bara `to_string`, implementerar `fmt::Display` baserat på den (det motsatta av det vanliga förhållandet mellan de två).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Skriver ut bokstaven som en sträng som ska vara förlustfri konverterbar tillbaka till samma bokstav (förutom eventuell avrundning för flytande punkt).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Spårad åtkomst till miljövariabler.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Hämta en miljövariabel och lägg till den för att bygga beroendeinformation.
    /// Byggsystem som kör kompilatorn vet att variabeln nås under kompileringen och kommer att kunna köra om byggnaden när värdet på variabeln ändras.
    ///
    /// Förutom beroendespårningen bör denna funktion motsvara `env::var` från standardbiblioteket, förutom att argumentet måste vara UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}