# `rustc-std-workspace-core` crate

Denna crate är en shim och tom crate som helt enkelt beror på `libcore` och exporterar allt innehåll igen.
crate är kärnan i att bemyndiga standardbiblioteket att vara beroende av crates från crates.io

Crates på crates.io som standardbiblioteket beror på måste bero på `rustc-std-workspace-core` crate från crates.io, som är tomt.

Vi använder `[patch]` för att åsidosätta den till denna crate i det här förvaret.
Som ett resultat kommer crates på crates.io att dra ett beroende edge till `libcore`, den version som definieras i detta förvar.
Det borde dra alla beroendekanter för att säkerställa att Cargo bygger crates framgångsrikt!

Observera att crates på crates.io måste vara beroende av denna crate med namnet `core` för att allt ska fungera korrekt.För att göra det kan de använda:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Genom att använda `package`-tangenten byts namn på crate till `core`, vilket betyder att det ser ut som

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

när Cargo åberopar kompilatorn och uppfyller det implicita `extern crate core`-direktivet som injiceras av kompilatorn.




