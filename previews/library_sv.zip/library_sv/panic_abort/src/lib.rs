//! Implementering av Rust panics via processavbrott
//!
//! Jämfört med implementeringen via avkoppling är denna crate *mycket* enklare!Med detta sagt är det inte lika mångsidigt, men här går det!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" nyttolast och mellanlägg till relevant avbrott på plattformen i fråga.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // ring std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // På Windows använder du den processorspecifika __fastfail-mekanismen.I Windows 8 och senare avslutas processen omedelbart utan att köra några undantagshanterare i processen.
            // I tidigare versioner av Windows kommer denna sekvens av instruktioner att behandlas som ett åtkomstbrott och avsluta processen men utan att nödvändigtvis kringgå alla undantagshanterare.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: detta är samma implementering som i libstds `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Detta ... är lite konstigt.Tl; dr;är att detta krävs för att länka korrekt, den längre förklaringen nedan.
//
// Just nu sammanställs binärerna för libcore/libstd som vi levererar alla med `-C panic=unwind`.Detta görs för att säkerställa att binärfilerna är maximalt kompatibla med så många situationer som möjligt.
// Kompilatorn kräver dock en "personality function" för alla funktioner som sammanställs med `-C panic=unwind`.Denna personlighetsfunktion är hårdkodad till symbolen `rust_eh_personality` och definieras av `eh_personality` lang-objektet.
//
// So...
// varför inte bara definiera det långa objektet här?Bra fråga!Sättet att panic-driftstider är länkade är faktiskt lite subtilt eftersom de är "sort of" i kompilatorns crate-butik, men bara faktiskt länkade om en annan inte är länkad.
//
// Detta slutar med att både crate och panic_unwind crate kan visas i kompilatorns crate-butik, och om båda definierar `eh_personality` lang-objektet kommer det att träffa ett fel.
//
// För att hantera detta kräver kompilatorn endast att `eh_personality` är definierad om panic-körtiden som länkas är avlindningstiden, och annars krävs inte att den definieras (med rätta).
// I det här fallet definierar detta bibliotek dock bara den här symbolen så det finns åtminstone någon personlighet någonstans.
//
// I grund och botten är den här symbolen precis definierad för att kopplas upp till libcore/libstd-binärer, men den ska aldrig kallas eftersom vi inte länkar i en avlindad körtid alls.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // På x86_64-pc-windows-gnu använder vi vår egen personlighetsfunktion som behöver returnera `ExceptionContinueSearch` när vi skickar alla våra ramar.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // I likhet med ovan motsvarar detta `eh_catch_typeinfo` lang-objektet som för närvarande endast används på Emscripten.
    //
    // Eftersom panics inte genererar undantag och utländska undantag för närvarande är UB med -C panic=avbryts (även om detta kan komma att ändras), kommer alla catch_unwind-samtal aldrig använda denna typinfo.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Dessa två kallas av våra startobjekt på i686-pc-windows-gnu, men de behöver inte göra någonting så kropparna är nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}