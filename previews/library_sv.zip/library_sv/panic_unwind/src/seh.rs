//! Windows SEH
//!
//! På Windows (för närvarande endast på MSVC) är standardhanteringsmekanismen Structured Exception Handling (SEH).
//! Detta är helt annorlunda än dvärgbaserad undantagshantering (t.ex. vad andra unix-plattformar använder) när det gäller kompilatorinternaler, så LLVM krävs för att ha en hel del extra stöd för SEH.
//!
//! I ett nötskal är vad som händer här:
//!
//! 1. `panic`-funktionen kallar standard Windows-funktionen `_CxxThrowException` för att kasta ett C++ -liknande undantag, vilket utlöser avlindningsprocessen.
//! 2.
//! Alla landningsplattor som genereras av kompilatorn använder personlighetsfunktionen `__CxxFrameHandler3`, en funktion i CRT, och avkopplingskoden i Windows kommer att använda denna personlighetsfunktion för att utföra alla saneringskoder på stacken.
//!
//! 3. Alla kompilatorgenererade samtal till `invoke` har en landningsplatta inställd som en `cleanuppad` LLVM-instruktion, vilket indikerar början på rengöringsrutinen.
//! Personligheten (i steg 2, definierad i CRT) är ansvarig för att köra saneringsrutinerna.
//! 4. Så småningom körs "catch"-koden i `try` inneboende (genererad av kompilatorn) och indikerar att kontrollen ska komma tillbaka till Rust.
//! Detta görs via en `catchswitch` plus en `catchpad`-instruktion i LLVM IR-termer och slutligen återgår normal kontroll till programmet med en `catchret`-instruktion.
//!
//! Några specifika skillnader från den gcc-baserade undantagshanteringen är:
//!
//! * Rust har ingen anpassad personlighetsfunktion, det är istället *alltid*`__CxxFrameHandler3`.Dessutom utförs ingen extra filtrering, så vi slutar fånga några C++ -undantag som råkar se ut som det vi kastar.
//! Observera att att kasta ett undantag i Rust är odefinierat beteende ändå, så det borde vara bra.
//! * Vi har lite data att överföra över avlindningsgränsen, särskilt en `Box<dyn Any + Send>`.Liksom med undantag för dvärg lagras dessa två pekare som en nyttolast i undantaget i sig.
//! På MSVC finns det dock inget behov av en extra högtilldelning eftersom samtalsstacken bevaras medan filterfunktioner körs.
//! Detta innebär att pekarna skickas direkt till `_CxxThrowException` som sedan återställs i filterfunktionen för att skrivas till stapelramen för `try` inneboende.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Detta måste vara ett alternativ eftersom vi fångar undantaget genom referens och dess destruktör körs av C++ körtid.
    // När vi tar bort rutan från undantaget måste vi lämna undantaget i ett giltigt tillstånd för att dess förstörare ska kunna köras utan att dubbelt släppa rutan.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Först och främst, en hel massa typdefinitioner.Det finns några plattformsspecifika konstigheter här, och mycket som bara blatant kopieras från LLVM.Syftet med allt detta är att implementera `panic`-funktionen nedan genom ett samtal till `_CxxThrowException`.
//
// Denna funktion tar två argument.Den första är en pekare till data vi skickar in, som i det här fallet är vårt trait-objekt.Ganska lätt att hitta!Nästa är dock mer komplicerad.
// Detta är en pekare till en `_ThrowInfo`-struktur, och den är i allmänhet bara avsedd att bara beskriva undantaget som kastas.
//
// För närvarande är definitionen av denna typ [1] lite hårig, och den främsta konstigheten (och skillnaden från onlineartikeln) är att pekare är på 32-bitars pekare men på 64-bitars uttrycks pekarna som 32-bitars förskjutningar från `__ImageBase` symbol.
//
// `ptr_t`-och `ptr!`-makrot i modulerna nedan används för att uttrycka detta.
//
// Labyrinten av typdefinitioner följer också noggrant vad LLVM avger för denna typ av operation.Om du till exempel kompilerar den här C++ -koden på MSVC och släpper ut LLVM IR:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      ogiltig foo() { rust_panic a = {0, 1};
//          kasta en;}
//
// Det är i princip vad vi försöker efterlikna.De flesta av de konstanta värdena nedan kopierades bara från LLVM,
//
// I alla fall är dessa strukturer konstruerade på samma sätt, och det är bara något ordentligt för oss.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Observera att vi medvetet ignorerar regler för namnmangling här: vi vill inte att C++ ska kunna fånga Rust panics genom att helt enkelt förklara en `struct rust_panic`.
//
//
// När du ändrar, se till att typnamnsträngen exakt matchar den som används i `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Den ledande `\x01`-byten här är faktiskt en magisk signal till LLVM om att *inte* tillämpa någon annan mangling som prefix med ett `_`-tecken.
    //
    //
    // Denna symbol är vtabellen som används av C++ `std::type_info`.
    // Objekt av typen `std::type_info`, typbeskrivare, har en pekare till denna tabell.
    // Typbeskrivare refereras av C++ EH-strukturerna som definieras ovan och som vi konstruerar nedan.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Denna typbeskrivare används bara när du kastar ett undantag.
// Fångstdelen hanteras av försökets inneboende, som genererar sin egen TypeDescriptor.
//
// Det här är bra eftersom MSVC-körningen använder strängjämförelse på typnamnet för att matcha TypeDescriptors snarare än pekarlikhet.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor används om C++ -koden beslutar att fånga undantaget och släppa det utan att sprida det.
// Fångstdelen av försökets inneboende kommer att sätta det första ordet i undantagsobjektet till 0 så att det hoppas över av förstöraren.
//
// Observera att x86 Windows använder "thiscall"-anropskonventionen för C++ -medelfunktioner istället för standard "C"-anropskonventionen.
//
// Exception_copy-funktionen är lite speciell här: den åberopas av MSVC-körningen under ett try/catch-block och panic som vi genererar här kommer att användas som resultatet av undantagskopian.
//
// Detta används av C++ runtime för att fånga undantag med std::exception_ptr, vilket vi inte kan stödja eftersom Box<dyn Any>är inte klonbar.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException körs helt på den här stapelramen, så det finns ingen anledning att på annat sätt överföra `data` till högen.
    // Vi skickar bara en stackpekare till den här funktionen.
    //
    // ManuallyDrop behövs här eftersom vi inte vill att Undantag ska tappas när du varva ner.
    // Istället kommer den att släppas av exception_cleanup som åberopas av C++ runtime.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Detta ... kan verka överraskande och med rätta.På 32-bitars MSVC är pekarna mellan dessa strukturer just det, pekare.
    // På 64-bitars MSVC uttrycks emellertid pekarna mellan strukturerna snarare som 32-bitars förskjutningar från `__ImageBase`.
    //
    // Följaktligen kan vi på 32-bitars MSVC deklarera alla dessa pekare i 'statiska' ovan.
    // På 64-bitars MSVC måste vi uttrycka subtraktion av pekare i statik, vilket Rust för närvarande inte tillåter, så vi kan faktiskt inte göra det.
    //
    // Det näst bästa är att fylla i dessa strukturer vid körning (panik är redan "slow path" ändå).
    // Så här tolkar vi alla dessa pekfält som 32-bitars heltal och lagrar sedan relevant värde i det (atomärt, eftersom samtidiga panics kan hända).
    //
    // Tekniskt sett kommer runtime förmodligen att göra en nonatomisk läsning av dessa fält, men i teorin läser de aldrig *fel*-värdet så det borde inte vara så dåligt ...
    //
    // I vilket fall som helst måste vi i princip göra något så här tills vi kan uttrycka fler operationer i statik (och vi kanske aldrig kommer att kunna).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // En NULL nyttolast här betyder att vi kom hit från fångsten (...) av __rust_try.
    // Detta händer när ett utländskt undantag som inte är Rust fångas.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Detta krävs av kompilatorn för att existera (t.ex., det är ett långt objekt), men det kallas aldrig egentligen av kompilatorn eftersom __C_specific_handler eller_except_handler3 är den personlighetsfunktion som alltid används.
//
// Därför är detta bara en avbrottstubbe.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}