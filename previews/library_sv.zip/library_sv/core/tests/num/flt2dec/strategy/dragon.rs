use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri är för långsam
fn exact_sanity_test() {
    // Det här testet slutar med att köra vad jag bara kan anta är något hörn-ish-fall av `exp2`-biblioteksfunktionen, definierad i vilken C-körning vi använder.
    // I VS 2013 hade den här funktionen uppenbarligen ett fel eftersom det här testet misslyckades när det länkades, men med VS 2015 verkar det vara fixat eftersom testet går bra.
    //
    // Felet verkar vara en skillnad i returvärdet på `exp2(-1057)`, där det i VS 2013 returnerar en dubbel med bitmönstret 0x2 och i VS 2015 returnerar det 0x20000.
    //
    //
    // För nu bara ignorera detta test helt på MSVC eftersom det testas någon annanstans i alla fall och vi är inte superintresserade av att testa varje plattforms exp2-implementering.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}