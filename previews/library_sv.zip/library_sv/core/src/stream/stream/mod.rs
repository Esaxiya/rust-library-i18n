use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Ett gränssnitt för hantering av asynkrona iteratorer.
///
/// Detta är huvudströmmen trait.
/// För mer information om begreppet strömmar i allmänhet, se [module-level documentation].
/// I synnerhet kanske du vill veta hur man ska [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Den typ av objekt som strömmen ger.
    type Item;

    /// Försök att dra ut nästa värde för den här strömmen, registrera den aktuella uppgiften för väckning om värdet ännu inte är tillgängligt och returnera `None` om strömmen är slut.
    ///
    /// # Returvärde
    ///
    /// Det finns flera möjliga returvärden, var och en indikerar ett distinkt strömtillstånd:
    ///
    /// - `Poll::Pending` betyder att strömens nästa värde inte är klart än.Implementeringar säkerställer att den aktuella uppgiften kommer att meddelas när nästa värde kan vara klart.
    ///
    /// - `Poll::Ready(Some(val))` betyder att strömmen framgångsrikt har producerat ett värde, `val`, och kan producera ytterligare värden vid efterföljande `poll_next`-samtal.
    ///
    /// - `Poll::Ready(None)` betyder att strömmen har avslutats och `poll_next` inte ska åberopas igen.
    ///
    /// # Panics
    ///
    /// När en ström har slutförts (returnerat `Ready(None)` from `poll_next`), att anropa sin `poll_next`-metod igen kan panic, blockera för evigt eller orsaka andra problem; `Stream` trait ställer inga krav på effekterna av ett sådant samtal.
    ///
    /// Eftersom `poll_next`-metoden inte är markerad som `unsafe`, gäller dock Rust: s vanliga regler: samtal får aldrig orsaka odefinierat beteende (minneskorruption, felaktig användning av `unsafe`-funktioner eller liknande), oavsett strömens tillstånd.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Returnerar gränserna för återstående längd av strömmen.
    ///
    /// Specifikt returnerar `size_hint()` en tupel där det första elementet är den nedre gränsen och det andra elementet är den övre gränsen.
    ///
    /// Den andra halvan av tupeln som returneras är ett [`Option`]`<`[`usize`] `>`.
    /// En [`None`] betyder här att antingen det inte finns någon känd övre gräns eller så är den övre gränsen större än [`usize`].
    ///
    /// # Implementeringsanmärkningar
    ///
    /// Det verkställs inte att en strömimplementering ger det deklarerade antalet element.En buggy-ström kan ge mindre än den nedre gränsen eller mer än den övre gränsen för element.
    ///
    /// `size_hint()` är främst avsedd att användas för optimeringar som att reservera utrymme för elementen i strömmen, men får inte lita på att t.ex. utelämna gränskontroller i osäker kod.
    /// Felaktig implementering av `size_hint()` bör inte leda till brott mot minnessäkerheten.
    ///
    /// Med detta sagt ska implementeringen ge en korrekt uppskattning, för annars skulle det vara ett brott mot trait s protokoll.
    ///
    /// Standardimplementeringen returnerar `(0,` [`None`]`)`som är korrekt för alla strömmar.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}