//! Komponerbar asynkron iteration.
//!
//! Om futures är asynkrona värden är strömmar asynkrona iteratorer.
//! Om du har hittat dig med en asynkron samling av något slag och behövt utföra en operation på elementen i nämnda samling, kommer du snabbt att stöta på 'streams'.
//! Strömmar används starkt i idiomatisk asynkron Rust-kod, så det är värt att bli bekant med dem.
//!
//! Innan vi förklarar mer, låt oss prata om hur den här modulen är uppbyggd:
//!
//! # Organization
//!
//! Denna modul är till stor del organiserad efter typ:
//!
//! * [Traits] är kärnan: dessa traits definierar vilken typ av strömmar som finns och vad du kan göra med dem.Metoderna i dessa traits är värda att lägga lite extra studietid på.
//! * Funktioner ger några användbara sätt att skapa några grundläggande strömmar.
//! * Structs är ofta returtyperna för de olika metoderna på den här modulens traits.Du vill vanligtvis titta på metoden som skapar `struct`, snarare än själva `struct`.
//! Mer information om varför finns i '[Implementing Stream](#implementeringsström)'.
//!
//! [Traits]: #traits
//!
//! Det är allt!Låt oss gräva i strömmar.
//!
//! # Stream
//!
//! Hjärtat och själen i denna modul är [`Stream`] trait.Kärnan i [`Stream`] ser ut så här:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Till skillnad från `Iterator` gör `Stream` en skillnad mellan [`poll_next`]-metoden som används vid implementering av en `Stream` och en (to-be-implemented) `next`-metod som används vid konsumtion av en ström.
//!
//! Konsumenter av `Stream` behöver bara överväga `next`, som när den anropas returnerar en future som ger `Option<Stream::Item>`.
//!
//! future som returneras av `next` ger `Some(Item)` så länge det finns element, och när de alla är uttömda kommer de att ge `None` för att indikera att iteration är klar.
//! Om vi väntar på något asynkront att lösa, väntar future tills strömmen är redo att ge igen.
//!
//! Enskilda strömmar kan välja att återuppta iteration, och så att ringa `next` igen kan eller inte så småningom ge `Some(Item)` igen någon gång.
//!
//! [`Stream`s fullständiga definition innehåller också ett antal andra metoder, men de är standardmetoder, byggda ovanpå [`poll_next`], så du får dem gratis.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Implementera ström
//!
//! Att skapa en egen ström innehåller två steg: att skapa en `struct` för att hålla strömens tillstånd och sedan implementera [`Stream`] för den `struct`.
//!
//! Låt oss skapa en ström med namnet `Counter` som räknas från `1` till `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Först strukturen:
//!
//! /// En ström som räknas från en till fem
//! struct Counter {
//!     count: usize,
//! }
//!
//! // vi vill att vårt antal ska börja med en, så låt oss lägga till en new()-metod för att hjälpa till.
//! // Detta är inte absolut nödvändigt, men är bekvämt.
//! // Observera att vi startar `count` på noll, vi får se varför i `poll_next()`'s-implementeringen nedan.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Sedan implementerar vi `Stream` för vår `Counter`:
//!
//! impl Stream for Counter {
//!     // vi kommer att räkna med storleken
//!     type Item = usize;
//!
//!     // poll_next() är den enda metoden som krävs
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Öka vårt antal.Det är därför vi började på noll.
//!         self.count += 1;
//!
//!         // Kontrollera om vi har räknat slut eller inte.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Strömmar är *lat*.Det betyder att bara skapa en ström inte _do_ mycket.Ingenting händer egentligen förrän du ringer till `next`.
//! Detta är ibland en förvirring när man skapar en ström enbart för dess biverkningar.
//! Kompilatorn kommer att varna oss för denna typ av beteende:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;