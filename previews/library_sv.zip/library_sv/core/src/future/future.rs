#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// En future representerar en asynkron beräkning.
///
/// En future är ett värde som kanske inte har avslutat beräkningen ännu.
/// Denna typ av "asynchronous value" gör det möjligt för en tråd att fortsätta göra användbart arbete medan den väntar på att värdet blir tillgängligt.
///
///
/// # `poll`-metoden
///
/// Kärnmetoden för future, `poll`,*försöker* lösa future till ett slutvärde.
/// Denna metod blockeras inte om värdet inte är klart.
/// Istället är den nuvarande uppgiften planerad att väckas när det är möjligt att göra ytterligare framsteg genom att `polla 'igen.
/// `context` som skickats till `poll`-metoden kan ge en [`Waker`], som är ett handtag för att väcka upp den aktuella uppgiften.
///
/// När du använder en future ringer du vanligtvis inte `poll` direkt, utan istället `.await` värdet.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Den typ av värde som produceras vid slutförandet.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Försök att lösa future till ett slutligt värde och registrera den aktuella uppgiften för väckning om värdet ännu inte är tillgängligt.
    ///
    /// # Returvärde
    ///
    /// Den här funktionen returnerar:
    ///
    /// - [`Poll::Pending`] om future inte är redo än
    /// - [`Poll::Ready(val)`] med resultatet `val` av denna future om den slutfördes framgångsrikt.
    ///
    /// När en future är klar bör klienter inte `poll` igen.
    ///
    /// När en future inte är klar än, returnerar `poll` `Poll::Pending` och lagrar en klon av [`Waker`] som kopierats från den aktuella [`Context`].
    /// Denna [`Waker`] väcks sedan när future kan göra framsteg.
    /// Till exempel skulle en future som väntar på att ett uttag blir läsbart ringa `.clone()` på [`Waker`] och lagra det.
    /// När en signal anländer någon annanstans som indikerar att uttaget är läsbart, anropas [`Waker::wake`] och uttaget future: s uppgift väcks.
    /// När en uppgift har väckts bör den försöka `poll` future igen, vilket kanske eller inte kan ge ett slutligt värde.
    ///
    /// Observera att vid flera samtal till `poll` ska endast [`Waker`] från [`Context`] som skickats till det senaste samtalet planeras för att få en väckning.
    ///
    /// # Runtime egenskaper
    ///
    /// Futures ensam är *inerta*;de måste *aktiveras*"avfrågas" för att göra framsteg, vilket innebär att varje gång den aktuella uppgiften väcks, bör den aktivt ompröva i väntan på futures som den fortfarande har ett intresse av.
    ///
    /// `poll`-funktionen anropas inte upprepade gånger i en snäv slinga-istället ska den bara anropas när future indikerar att den är redo att göra framsteg (genom att ringa `wake()`).
    /// Om du känner till `poll(2)`-eller `select(2)`-syscalls på Unix är det värt att notera att futures vanligtvis *inte* lider av samma problem som "all wakeups must poll all events";de liknar mer `epoll(4)`.
    ///
    /// En implementering av `poll` bör sträva efter att återvända snabbt och bör inte blockeras.Återkomst snabbt förhindrar onödigt igensättning av trådar eller eventslingor.
    /// Om det är känt i förväg att ett samtal till `poll` kan ta slut en stund, bör arbetet laddas ned till en trådpool (eller något liknande) för att säkerställa att `poll` kan återvända snabbt.
    ///
    /// # Panics
    ///
    /// När en future har slutförts (returnerat `Ready` från `poll`), kan anropa till `poll`-metoden igen panic, blockera för alltid eller orsaka andra typer av problem;`Future` trait ställer inga krav på effekterna av ett sådant samtal.
    /// Eftersom `poll`-metoden inte är markerad som `unsafe`, gäller dock Rust: s vanliga regler: samtal får aldrig orsaka odefinierat beteende (minneskorruption, felaktig användning av `unsafe`-funktioner eller liknande), oavsett future: s tillstånd.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}