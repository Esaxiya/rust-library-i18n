use crate::future::Future;

/// Omvandling till en `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Den produktion som future kommer att producera vid slutförandet.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Vilken typ av future gör vi detta till?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Skapar en future från ett värde.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}