//! En modul för att arbeta med lånad data.

#![stable(feature = "rust1", since = "1.0.0")]

/// En trait för upplåning av data.
///
/// I Rust är det vanligt att tillhandahålla olika representationer av en typ för olika användningsfall.
/// Till exempel kan lagringsplats och hantering för ett värde väljas som lämpligt för en viss användning via pekartyper som [`Box<T>`] eller [`Rc<T>`].
/// Utöver dessa generiska omslag som kan användas med alla typer, erbjuder vissa typer valfria aspekter som ger potentiellt kostsamma funktioner.
/// Ett exempel för en sådan typ är [`String`] som lägger till möjligheten att utöka en sträng till den grundläggande [`str`].
/// Detta kräver att ytterligare information är onödig för en enkel, oföränderlig sträng.
///
/// Dessa typer ger åtkomst till underliggande data genom referenser till typen av data.De sägs vara "lånade som" den typen.
/// Till exempel kan en [`Box<T>`] lånas som `T` medan en [`String`] kan lånas som `str`.
///
/// Typer uttrycker att de kan lånas som någon typ `T` genom att implementera `Borrow<T>`, vilket ger en referens till en `T` i trait s [`borrow`]-metod.En typ är fri att låna som flera olika typer.
/// Om den önskar låna mutabelt som typ-så att underliggande data kan modifieras, kan den dessutom implementera [`BorrowMut<T>`].
///
/// Vidare, när man tillhandahåller implementeringar för ytterligare traits, måste det övervägas om de ska bete sig identiska med de av den underliggande typen som en följd av att de fungerar som en representation av den underliggande typen.
/// Generisk kod använder vanligtvis `Borrow<T>` när den förlitar sig på samma beteende för dessa ytterligare trait-implementeringar.
/// Dessa traits kommer sannolikt att visas som ytterligare trait bounds.
///
/// I synnerhet `Eq`, `Ord` och `Hash` måste vara ekvivalenta för lånade och ägda värden: `x.borrow() == y.borrow()` ska ge samma resultat som `x == y`.
///
/// Om generisk kod bara behöver fungera för alla typer som kan ge en referens till relaterad typ `T`, är det ofta bättre att använda [`AsRef<T>`] eftersom fler typer säkert kan implementera den.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Som en datainsamling äger [`HashMap<K, V>`] både nycklar och värden.Om nyckelns faktiska data är insvept i en hanteringstyp av något slag, bör det dock fortfarande vara möjligt att söka efter ett värde med hjälp av en hänvisning till nyckelns data.
/// Till exempel, om nyckeln är en sträng, lagras den sannolikt med hash-kartan som en [`String`], medan det borde vara möjligt att söka med en [`&str`][`str`].
/// Således måste `insert` fungera på en `String` medan `get` måste kunna använda en `&str`.
///
/// Något förenklat ser de relevanta delarna av `HashMap<K, V>` ut så här:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // fält utelämnade
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Hela hashkartan är generisk över en nyckeltyp `K`.Eftersom dessa nycklar lagras med hash-kartan måste denna typ äga nyckelns data.
/// När du sätter in ett nyckel-värdepar får kartan en sådan `K` och måste hitta rätt hash-hink och kontrollera om nyckeln redan finns baserat på den `K`.Det kräver därför `K: Hash + Eq`.
///
/// När du söker efter ett värde på kartan måste du dock ange en referens till en `K` som nyckel för att söka efter att alltid skapa ett sådant ägt värde.
/// För strängnycklar skulle detta innebära att ett `String`-värde måste skapas bara för sökning efter fall där endast en `str` är tillgänglig.
///
/// Istället är `get`-metoden generisk över typen av underliggande nyckeldata, som kallas `Q` i metodsignaturen ovan.Det anges att `K` lånar som en `Q` genom att kräva att `K: Borrow<Q>`.
/// Genom att dessutom kräva `Q: Hash + Eq`, signalerar det kravet att `K` och `Q` har implementeringar av `Hash` och `Eq` traits som ger identiska resultat.
///
/// Implementeringen av `get` förlitar sig särskilt på identiska implementeringar av `Hash` genom att bestämma nyckelns hash-hink genom att anropa `Hash::hash` på `Q`-värdet trots att den infogade nyckeln baserat på hashvärdet beräknat från `K`-värdet.
///
///
/// Som en konsekvens bryts hashkartan om ett `K` som slår in ett `Q`-värde ger en annan hash än `Q`.Tänk dig till exempel att du har en typ som slår in en sträng men jämför ASCII-bokstäver som ignorerar deras fall:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Eftersom två lika värden behöver producera samma hashvärde måste implementeringen av `Hash` också ignorera ASCII-fall:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Kan `CaseInsensitiveString` implementera `Borrow<str>`?Det kan verkligen ge en referens till en strängskiva via den innehöll ägda strängen.
/// Men eftersom dess `Hash`-implementering skiljer sig, beter sig den annorlunda än `str` och får därför faktiskt inte implementera `Borrow<str>`.
/// Om den vill ge andra tillgång till den underliggande `str`, kan den göra det via `AsRef<str>` som inte innehåller några extra krav.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Oförlåtligt lånar från ett ägt värde.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// En trait för att låna data föränderligt.
///
/// Som följeslagare till [`Borrow<T>`] tillåter denna trait en typ att låna som en underliggande typ genom att tillhandahålla en förändrad referens.
/// Se [`Borrow<T>`] för mer information om upplåning som en annan typ.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Lånar mutabelt från ett ägt värde.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}