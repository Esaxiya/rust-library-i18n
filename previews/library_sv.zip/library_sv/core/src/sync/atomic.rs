//! Atomtyper
//!
//! Atomtyper ger primitiv delad minneskommunikation mellan trådar och är byggstenarna för andra samtidiga typer.
//!
//! Den här modulen definierar atomversioner av ett urval antal primitiva typer, inklusive [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], etc.
//! Atomtyper presenterar operationer som, när de används korrekt, synkroniserar uppdateringar mellan trådar.
//!
//! Varje metod tar en [`Ordering`] som representerar minnesbarriärens styrka för den operationen.Dessa beställningar är desamma som [C++20 atomic orderings][1].För mer information se [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Atomiska variabler är säkra att dela mellan trådar (de implementerar [`Sync`]) men de tillhandahåller inte själva mekanismen för delning och följer [threading model](../../../std/thread/index.html#the-threading-model) i Rust.
//!
//! Det vanligaste sättet att dela en atomvariabel är att placera den i en [`Arc`][arc] (en atomreferensräknad delad pekare).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Atomtyper kan lagras i statiska variabler, initialiserade med konstanta initialiserare som [`AtomicBool::new`].Atomstatik används ofta för lat global initialisering.
//!
//! # Portability
//!
//! Alla atomtyper i den här modulen är garanterat [lock-free] om de är tillgängliga.Detta innebär att de inte internt förvärvar en global mutex.Atomtyper och operationer garanteras inte att de är väntafria.
//! Detta innebär att operationer som `fetch_or` kan implementeras med en jämför-och-byt-slinga.
//!
//! Atomoperationer kan implementeras vid instruktionsskiktet med större atom.Till exempel använder vissa plattformar atominstruktioner med 4 byte för att implementera `AtomicI8`.
//! Observera att denna emulering inte borde påverka kodens korrekthet, det är bara något att vara medveten om.
//!
//! Atomtyperna i denna modul är kanske inte tillgängliga på alla plattformar.Atomtyperna här är dock alla allmänt tillgängliga och kan i allmänhet lita på att de finns.Några anmärkningsvärda undantag är:
//!
//! * PowerPC och MIPS-plattformar med 32-bitarspekare har inte `AtomicU64`-eller `AtomicI64`-typer.
//! * ARM plattformar som `armv5te` som inte är för Linux tillhandahåller endast `load`-och `store`-operationer och stöder inte Jämför och byt (CAS)-operationer, till exempel `swap`, `fetch_add`, etc.
//! Dessutom på Linux implementeras dessa CAS-operationer via [operating system support], vilket kan medföra prestationsstraff.
//! * ARM mål med `thumbv6m` tillhandahåller endast `load`-och `store`-operationer och stöder inte Jämför och byt (CAS)-operationer, till exempel `swap`, `fetch_add`, etc.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Observera att future-plattformar kan läggas till som inte heller har stöd för vissa atomoperationer.Maximal bärbar kod vill vara försiktig med vilka atomtyper som används.
//! `AtomicUsize` och `AtomicIsize` är i allmänhet de mest bärbara, men även då är de inte tillgängliga överallt.
//! Som referens kräver `std`-biblioteket atomär pekstorlek, även om `core` inte gör det.
//!
//! För närvarande måste du använda `#[cfg(target_arch)]` främst för att villkorligt sammanställa i kod med atom.Det finns också en instabil `#[cfg(target_has_atomic)]` som kan stabiliseras i future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! En enkel snurrlås:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Vänta tills den andra tråden släpper låset
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Håll ett globalt antal live-trådar:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// En boolesk typ som säkert kan delas mellan trådar.
///
/// Denna typ har samma in-memory-representation som en [`bool`].
///
/// **Obs**: Den här typen är endast tillgänglig på plattformar som stöder atombelastningar och lager av `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Skapar en `AtomicBool` initialiserad till `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Skicka implementeras implicit för AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// En rå pekartyp som säkert kan delas mellan trådar.
///
/// Denna typ har samma in-memory-representation som en `*mut T`.
///
/// **Obs**: Denna typ är endast tillgänglig på plattformar som stöder atombelastningar och lager av pekare.
/// Storleken beror på målpekarens storlek.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Skapar en null `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Atomiska minnesbeställningar
///
/// Minnesbeställningar anger hur atomoperationer synkroniserar minne.
/// I sin svagaste [`Ordering::Relaxed`] synkroniseras bara minnet som direkt berörs av operationen.
/// Å andra sidan synkroniserar ett store-load-par [`Ordering::SeqCst`]-operationer annat minne samtidigt som en total ordning av sådana operationer bevaras över alla trådar.
///
///
/// Rust: s minnesbeställningar är [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// För mer information se [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Inga beställningsbegränsningar, bara atomoperationer.
    ///
    /// Motsvarar [`memory_order_relaxed`] i C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// I kombination med en butik beställs alla tidigare operationer innan någon belastning av detta värde med [`Acquire`] (eller starkare) beställning.
    ///
    /// I synnerhet blir alla tidigare skrivningar synliga för alla trådar som utför en [`Acquire`] (eller starkare) belastning av detta värde.
    ///
    /// Observera att användning av denna beställning för en operation som kombinerar laster och lagrar leder till en [`Relaxed`]-lastoperation!
    ///
    /// Denna beställning gäller endast för operationer som kan utföra en butik.
    ///
    /// Motsvarar [`memory_order_release`] i C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// När det laddade värdet skrivs av en butiksoperation med [`Release`] (eller starkare) beställning, kommer alla efterföljande operationer att beställas efter den butiken.
    /// I synnerhet kommer alla efterföljande laster att se data skrivna innan butiken.
    ///
    /// Observera att användning av denna beställning för en operation som kombinerar laster och lagrar leder till en [`Relaxed`]-butiksoperation!
    ///
    /// Denna beställning gäller endast för operationer som kan utföra en belastning.
    ///
    /// Motsvarar [`memory_order_acquire`] i C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Har effekterna av både [`Acquire`] och [`Release`] tillsammans:
    /// För laster använder den [`Acquire`]-beställning.För butiker använder den [`Release`]-beställningen.
    ///
    /// Observera att i fallet `compare_and_swap` är det möjligt att operationen slutar att inte utföra någon butik och därför har den bara [`Acquire`]-beställning.
    ///
    /// `AcqRel` kommer dock aldrig att utföra [`Relaxed`]-åtkomst.
    ///
    /// Denna beställning gäller endast för operationer som kombinerar både laster och butiker.
    ///
    /// Motsvarar [`memory_order_acq_rel`] i C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Liksom [`Acquire`]/[`Release`]/[`AcqRel`](för laddnings-, lagrings-och laddnings-med-butiksoperationer) med den extra garantin att alla trådar ser alla sekventiellt konsekventa operationer i samma ordning .
    ///
    ///
    /// Motsvarar [`memory_order_seq_cst`] i C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// En [`AtomicBool`] initialiserad till `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Skapar en ny `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Returnerar en muterbar referens till den underliggande [`bool`].
    ///
    /// Detta är säkert eftersom den muterbara referensen garanterar att inga andra trådar samtidigt får åtkomst till atomdata.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // SÄKERHET: den förändrade referensen garanterar unikt ägande.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Få atomåtkomst till en `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // SÄKERHET: den förändrade referensen garanterar unikt ägande, och
        // inriktningen för både `bool` och `Self` är 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Förbrukar atomen och returnerar det inneslutna värdet.
    ///
    /// Detta är säkert eftersom att passera `self` efter värde garanterar att inga andra trådar samtidigt får åtkomst till atomdata.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Läser in ett värde från bool.
    ///
    /// `load` tar ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.
    /// Möjliga värden är [`SeqCst`], [`Acquire`] och [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics om `order` är [`Release`] eller [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // SÄKERHET: eventuella dataraser förhindras av atomens inneboende och råa
        // pekaren som skickas in är giltig eftersom vi fick den från en referens.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Lagrar ett värde i bool.
    ///
    /// `store` tar ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.
    /// Möjliga värden är [`SeqCst`], [`Release`] och [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics om `order` är [`Acquire`] eller [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // SÄKERHET: eventuella dataraser förhindras av atomens inneboende och råa
        // pekaren som skickas in är giltig eftersom vi fick den från en referens.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Lagrar ett värde i bool och returnerar det tidigare värdet.
    ///
    /// `swap` tar ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.Alla beställningslägen är möjliga.
    /// Observera att användning av [`Acquire`] gör butiken till en del av denna operation [`Relaxed`], och användning av [`Release`] gör lastdelen [`Relaxed`].
    ///
    ///
    /// **Note:** Den här metoden är endast tillgänglig på plattformar som stöder atomoperationer på `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // SÄKERHET: dataraser förhindras av atomär inneboende.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Lagrar ett värde i [`bool`] om det aktuella värdet är detsamma som `current`-värdet.
    ///
    /// Returvärdet är alltid det tidigare värdet.Om det är lika med `current` uppdaterades värdet.
    ///
    /// `compare_and_swap` tar också ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.
    /// Observera att även när du använder [`AcqRel`] kan operationen misslyckas och därför bara utföra en `Acquire`-belastning, men inte ha `Release`-semantik.
    /// Användning av [`Acquire`] gör butiken till en del av denna operation [`Relaxed`] om det händer, och användning av [`Release`] gör lastdelen [`Relaxed`].
    ///
    /// **Note:** Den här metoden är endast tillgänglig på plattformar som stöder atomoperationer på `u8`.
    ///
    /// # Migrerar till `compare_exchange` och `compare_exchange_weak`
    ///
    /// `compare_and_swap` motsvarar `compare_exchange` med följande kartläggning för minnesbeställningar:
    ///
    /// Original |Framgång |Fel
    /// -------- | ------- | -------
    /// Avslappnad |Avslappnad |Avslappnad förvärva |Förvärva |Skaffa släpp |Släpp |Avslappnad AcqRel |AcqRel |Skaffa SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` får misslyckas felaktigt även när jämförelsen lyckas, vilket gör att kompilatorn kan generera bättre monteringskod när jämförelsen och bytet används i en slinga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Lagrar ett värde i [`bool`] om det aktuella värdet är detsamma som `current`-värdet.
    ///
    /// Returvärdet är ett resultat som anger om det nya värdet skrevs och innehöll det tidigare värdet.
    /// Vid framgång är detta värde garanterat lika med `current`.
    ///
    /// `compare_exchange` tar två [`Ordering`]-argument för att beskriva minnesordningen för denna operation.
    /// `success` beskriver den ordning som krävs för läs-modifier-skriv-operationen som äger rum om jämförelsen med `current` lyckas.
    /// `failure` beskriver beställningen som krävs för lastoperationen som sker när jämförelsen misslyckas.
    /// Att använda [`Acquire`] som framgångsbeställning gör butiken till en del av denna operation [`Relaxed`], och med [`Release`] blir den framgångsrika belastningen [`Relaxed`].
    ///
    /// Felbeställningen kan bara vara [`SeqCst`], [`Acquire`] eller [`Relaxed`] och måste motsvara eller svagare än framgångsbeställningen.
    ///
    /// **Note:** Den här metoden är endast tillgänglig på plattformar som stöder atomoperationer på `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SÄKERHET: dataraser förhindras av atomär inneboende.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Lagrar ett värde i [`bool`] om det aktuella värdet är detsamma som `current`-värdet.
    ///
    /// Till skillnad från [`AtomicBool::compare_exchange`] får denna funktion felaktigt misslyckas även när jämförelsen lyckas, vilket kan resultera i mer effektiv kod på vissa plattformar.
    ///
    /// Returvärdet är ett resultat som anger om det nya värdet skrevs och innehöll det tidigare värdet.
    ///
    /// `compare_exchange_weak` tar två [`Ordering`]-argument för att beskriva minnesordningen för denna operation.
    /// `success` beskriver den ordning som krävs för läs-modifier-skriv-operationen som äger rum om jämförelsen med `current` lyckas.
    /// `failure` beskriver beställningen som krävs för lastoperationen som sker när jämförelsen misslyckas.
    /// Att använda [`Acquire`] som framgångsbeställning gör butiken till en del av denna operation [`Relaxed`], och med [`Release`] blir den framgångsrika belastningen [`Relaxed`].
    /// Felbeställningen kan bara vara [`SeqCst`], [`Acquire`] eller [`Relaxed`] och måste motsvara eller svagare än framgångsbeställningen.
    ///
    /// **Note:** Den här metoden är endast tillgänglig på plattformar som stöder atomoperationer på `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SÄKERHET: dataraser förhindras av atomär inneboende.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Logisk "and" med ett booleskt värde.
    ///
    /// Utför en logisk "and"-operation på det aktuella värdet och argumentet `val` och ställer in det nya värdet till resultatet.
    ///
    /// Returnerar föregående värde.
    ///
    /// `fetch_and` tar ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.Alla beställningslägen är möjliga.
    /// Observera att användning av [`Acquire`] gör butiken till en del av denna operation [`Relaxed`], och användning av [`Release`] gör lastdelen [`Relaxed`].
    ///
    ///
    /// **Note:** Den här metoden är endast tillgänglig på plattformar som stöder atomoperationer på `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // SÄKERHET: dataraser förhindras av atomär inneboende.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Logisk "nand" med ett booleskt värde.
    ///
    /// Utför en logisk "nand"-operation på det aktuella värdet och argumentet `val` och ställer in det nya värdet till resultatet.
    ///
    /// Returnerar föregående värde.
    ///
    /// `fetch_nand` tar ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.Alla beställningslägen är möjliga.
    /// Observera att användning av [`Acquire`] gör butiken till en del av denna operation [`Relaxed`], och användning av [`Release`] gör lastdelen [`Relaxed`].
    ///
    ///
    /// **Note:** Den här metoden är endast tillgänglig på plattformar som stöder atomoperationer på `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Vi kan inte använda atomic_nand här eftersom det kan resultera i en bool med ett ogiltigt värde.
        // Detta händer eftersom atomoperationen görs med ett 8-bitars heltal internt, vilket skulle ställa in de övre 7 bitarna.
        //
        // Så vi använder bara fetch_xor eller byter istället.
        if val {
            // ! (x&true)== !x Vi måste invertera bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true Vi måste ställa in bool till true.
            //
            self.swap(true, order)
        }
    }

    /// Logisk "or" med ett booleskt värde.
    ///
    /// Utför en logisk "or"-operation på det aktuella värdet och argumentet `val` och ställer in det nya värdet till resultatet.
    ///
    /// Returnerar föregående värde.
    ///
    /// `fetch_or` tar ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.Alla beställningslägen är möjliga.
    /// Observera att användning av [`Acquire`] gör butiken till en del av denna operation [`Relaxed`], och användning av [`Release`] gör lastdelen [`Relaxed`].
    ///
    ///
    /// **Note:** Den här metoden är endast tillgänglig på plattformar som stöder atomoperationer på `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // SÄKERHET: dataraser förhindras av atomär inneboende.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Logisk "xor" med ett booleskt värde.
    ///
    /// Utför en logisk "xor"-operation på det aktuella värdet och argumentet `val` och ställer in det nya värdet till resultatet.
    ///
    /// Returnerar föregående värde.
    ///
    /// `fetch_xor` tar ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.Alla beställningslägen är möjliga.
    /// Observera att användning av [`Acquire`] gör butiken till en del av denna operation [`Relaxed`], och användning av [`Release`] gör lastdelen [`Relaxed`].
    ///
    ///
    /// **Note:** Den här metoden är endast tillgänglig på plattformar som stöder atomoperationer på `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // SÄKERHET: dataraser förhindras av atomär inneboende.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Returnerar en muterbar pekare till den underliggande [`bool`].
    ///
    /// Att göra icke-atomiska läsningar och skrivningar på det resulterande heltalet kan vara en datalopp.
    /// Denna metod är mest användbar för FFI, där funktionssignaturen kan använda `*mut bool` istället för `&AtomicBool`.
    ///
    /// Att returnera en `*mut`-pekare från en delad referens till denna atom är säkert eftersom atomtyperna fungerar med inre mutabilitet.
    /// Alla modifieringar av en atom förändrar värdet genom en delad referens och kan göra det säkert så länge de använder atomoperationer.
    /// All användning av den returnerade råa pekaren kräver ett `unsafe`-block och måste fortfarande upprätthålla samma begränsning: operationerna på den måste vara atomära.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Hämtar värdet och tillämpar en funktion på det som returnerar ett valfritt nytt värde.Returnerar en `Result` av `Ok(previous_value)` om funktionen returnerade `Some(_)`, annars `Err(previous_value)`.
    ///
    /// Note: Detta kan anropa funktionen flera gånger om värdet har ändrats från andra trådar under tiden, så länge som funktionen returnerar `Some(_)`, men funktionen har bara tillämpats en gång på det lagrade värdet.
    ///
    ///
    /// `fetch_update` tar två [`Ordering`]-argument för att beskriva minnesordningen för denna operation.
    /// Den första beskriver den erforderliga beställningen för när operationen slutligen lyckas medan den andra beskriver den önskade beställningen för laster.
    /// Dessa motsvarar framgångs-och misslyckanden för [`AtomicBool::compare_exchange`].
    ///
    /// Att använda [`Acquire`] som framgångsbeställning gör butiken till en del av denna operation [`Relaxed`], och med [`Release`] blir den slutgiltiga lyckade belastningen [`Relaxed`].
    /// (failed) lastbeställning kan endast vara [`SeqCst`], [`Acquire`] eller [`Relaxed`] och måste motsvara eller svagare än framgångsbeställningen.
    ///
    /// **Note:** Den här metoden är endast tillgänglig på plattformar som stöder atomoperationer på `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Skapar en ny `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Returnerar en muterbar referens till den underliggande pekaren.
    ///
    /// Detta är säkert eftersom den muterbara referensen garanterar att inga andra trådar samtidigt får åtkomst till atomdata.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Få atomåtkomst till en pekare.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - den förändrade referensen garanterar unikt ägande.
        //  - inriktningen av `*mut T` och `Self` är densamma på alla plattformar som stöds av rust, som verifierat ovan.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Förbrukar atomen och returnerar det inneslutna värdet.
    ///
    /// Detta är säkert eftersom att passera `self` efter värde garanterar att inga andra trådar samtidigt får åtkomst till atomdata.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Lägger in ett värde från pekaren.
    ///
    /// `load` tar ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.
    /// Möjliga värden är [`SeqCst`], [`Acquire`] och [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics om `order` är [`Release`] eller [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // SÄKERHET: dataraser förhindras av atomär inneboende.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Lagrar ett värde i pekaren.
    ///
    /// `store` tar ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.
    /// Möjliga värden är [`SeqCst`], [`Release`] och [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics om `order` är [`Acquire`] eller [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // SÄKERHET: dataraser förhindras av atomär inneboende.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Lagrar ett värde i pekaren och returnerar det tidigare värdet.
    ///
    /// `swap` tar ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.Alla beställningslägen är möjliga.
    /// Observera att användning av [`Acquire`] gör butiken till en del av denna operation [`Relaxed`], och användning av [`Release`] gör lastdelen [`Relaxed`].
    ///
    ///
    /// **Note:** Denna metod är endast tillgänglig på plattformar som stöder atomoperationer på pekare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // SÄKERHET: dataraser förhindras av atomär inneboende.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Lagrar ett värde i pekaren om det aktuella värdet är detsamma som `current`-värdet.
    ///
    /// Returvärdet är alltid det tidigare värdet.Om det är lika med `current` uppdaterades värdet.
    ///
    /// `compare_and_swap` tar också ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.
    /// Observera att även när du använder [`AcqRel`] kan operationen misslyckas och därför bara utföra en `Acquire`-belastning, men inte ha `Release`-semantik.
    /// Användning av [`Acquire`] gör butiken till en del av denna operation [`Relaxed`] om det händer, och användning av [`Release`] gör lastdelen [`Relaxed`].
    ///
    /// **Note:** Denna metod är endast tillgänglig på plattformar som stöder atomoperationer på pekare.
    ///
    /// # Migrerar till `compare_exchange` och `compare_exchange_weak`
    ///
    /// `compare_and_swap` motsvarar `compare_exchange` med följande kartläggning för minnesbeställningar:
    ///
    /// Original |Framgång |Fel
    /// -------- | ------- | -------
    /// Avslappnad |Avslappnad |Avslappnad förvärva |Förvärva |Skaffa släpp |Släpp |Avslappnad AcqRel |AcqRel |Skaffa SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` får misslyckas felaktigt även när jämförelsen lyckas, vilket gör att kompilatorn kan generera bättre monteringskod när jämförelsen och bytet används i en slinga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Lagrar ett värde i pekaren om det aktuella värdet är detsamma som `current`-värdet.
    ///
    /// Returvärdet är ett resultat som anger om det nya värdet skrevs och innehöll det tidigare värdet.
    /// Vid framgång är detta värde garanterat lika med `current`.
    ///
    /// `compare_exchange` tar två [`Ordering`]-argument för att beskriva minnesordningen för denna operation.
    /// `success` beskriver den ordning som krävs för läs-modifier-skriv-operationen som äger rum om jämförelsen med `current` lyckas.
    /// `failure` beskriver beställningen som krävs för lastoperationen som sker när jämförelsen misslyckas.
    /// Att använda [`Acquire`] som framgångsbeställning gör butiken till en del av denna operation [`Relaxed`], och med [`Release`] blir den framgångsrika belastningen [`Relaxed`].
    ///
    /// Felbeställningen kan bara vara [`SeqCst`], [`Acquire`] eller [`Relaxed`] och måste motsvara eller svagare än framgångsbeställningen.
    ///
    /// **Note:** Denna metod är endast tillgänglig på plattformar som stöder atomoperationer på pekare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SÄKERHET: dataraser förhindras av atomär inneboende.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Lagrar ett värde i pekaren om det aktuella värdet är detsamma som `current`-värdet.
    ///
    /// Till skillnad från [`AtomicPtr::compare_exchange`] får denna funktion felaktigt misslyckas även när jämförelsen lyckas, vilket kan resultera i mer effektiv kod på vissa plattformar.
    ///
    /// Returvärdet är ett resultat som anger om det nya värdet skrevs och innehöll det tidigare värdet.
    ///
    /// `compare_exchange_weak` tar två [`Ordering`]-argument för att beskriva minnesordningen för denna operation.
    /// `success` beskriver den ordning som krävs för läs-modifier-skriv-operationen som äger rum om jämförelsen med `current` lyckas.
    /// `failure` beskriver beställningen som krävs för lastoperationen som sker när jämförelsen misslyckas.
    /// Att använda [`Acquire`] som framgångsbeställning gör butiken till en del av denna operation [`Relaxed`], och med [`Release`] blir den framgångsrika belastningen [`Relaxed`].
    /// Felbeställningen kan bara vara [`SeqCst`], [`Acquire`] eller [`Relaxed`] och måste motsvara eller svagare än framgångsbeställningen.
    ///
    /// **Note:** Denna metod är endast tillgänglig på plattformar som stöder atomoperationer på pekare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SÄKERHET: Denna inneboende är osäker eftersom den fungerar på en rå pekare
        // men vi vet säkert att pekaren är giltig (vi har precis fått den från en `UnsafeCell` som vi har som referens) och själva atomoperationen gör att vi säkert kan mutera `UnsafeCell`-innehållet.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Hämtar värdet och tillämpar en funktion på det som returnerar ett valfritt nytt värde.Returnerar en `Result` av `Ok(previous_value)` om funktionen returnerade `Some(_)`, annars `Err(previous_value)`.
    ///
    /// Note: Detta kan anropa funktionen flera gånger om värdet har ändrats från andra trådar under tiden, så länge som funktionen returnerar `Some(_)`, men funktionen har bara tillämpats en gång på det lagrade värdet.
    ///
    ///
    /// `fetch_update` tar två [`Ordering`]-argument för att beskriva minnesordningen för denna operation.
    /// Den första beskriver den erforderliga beställningen för när operationen slutligen lyckas medan den andra beskriver den önskade beställningen för laster.
    /// Dessa motsvarar framgångs-och misslyckanden för [`AtomicPtr::compare_exchange`].
    ///
    /// Att använda [`Acquire`] som framgångsbeställning gör butiken till en del av denna operation [`Relaxed`], och med [`Release`] blir den slutgiltiga lyckade belastningen [`Relaxed`].
    /// (failed) lastbeställning kan endast vara [`SeqCst`], [`Acquire`] eller [`Relaxed`] och måste motsvara eller svagare än framgångsbeställningen.
    ///
    /// **Note:** Denna metod är endast tillgänglig på plattformar som stöder atomoperationer på pekare.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Konverterar en `bool` till en `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Detta makro blir slutligen oanvänd på vissa arkitekturer.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// En heltalstyp som kan delas säkert mellan trådar.
        ///
        /// Denna typ har samma minnesrepresentation som den underliggande heltalstypen, ['
        ///
        #[doc = $s_int_type]
        /// `].
        /// För mer information om skillnaderna mellan atomtyper och icke-atomtyper samt information om portabiliteten för denna typ, se [module-level documentation].
        ///
        ///
        /// **Note:** Denna typ är endast tillgänglig på plattformar som stöder atombelastningar och lagrar [[
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Ett atomärt heltal initialiserat till `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Skicka implementeras implicit.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Skapar ett nytt atomalt heltal.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Returnerar en muterbar referens till det underliggande heltalet.
            ///
            /// Detta är säkert eftersom den muterbara referensen garanterar att inga andra trådar samtidigt får åtkomst till atomdata.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// låt mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - den förändrade referensen garanterar unikt ägande.
                //  - inriktningen av `$int_type` och `Self` är densamma, som lovat av $cfg_align och verifierat ovan.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Förbrukar atomen och returnerar det inneslutna värdet.
            ///
            /// Detta är säkert eftersom att passera `self` efter värde garanterar att inga andra trådar samtidigt får åtkomst till atomdata.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Läser in ett värde från atomens heltal.
            ///
            /// `load` tar ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.
            /// Möjliga värden är [`SeqCst`], [`Acquire`] och [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics om `order` är [`Release`] eller [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // SÄKERHET: dataraser förhindras av atomär inneboende.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Lagrar ett värde i atomens heltal.
            ///
            /// `store` tar ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.
            ///  Möjliga värden är [`SeqCst`], [`Release`] och [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics om `order` är [`Acquire`] eller [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // SÄKERHET: dataraser förhindras av atomär inneboende.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Lagrar ett värde i atomens heltal och returnerar det tidigare värdet.
            ///
            /// `swap` tar ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.Alla beställningslägen är möjliga.
            /// Observera att användning av [`Acquire`] gör butiken till en del av denna operation [`Relaxed`], och användning av [`Release`] gör lastdelen [`Relaxed`].
            ///
            ///
            /// **Obs**: Denna metod är endast tillgänglig på plattformar som stöder atomoperationer på
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÄKERHET: dataraser förhindras av atomär inneboende.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Lagrar ett värde i atomens heltal om det aktuella värdet är detsamma som `current`-värdet.
            ///
            /// Returvärdet är alltid det tidigare värdet.Om det är lika med `current` uppdaterades värdet.
            ///
            /// `compare_and_swap` tar också ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.
            /// Observera att även när du använder [`AcqRel`] kan operationen misslyckas och därför bara utföra en `Acquire`-belastning, men inte ha `Release`-semantik.
            ///
            /// Användning av [`Acquire`] gör butiken till en del av denna operation [`Relaxed`] om det händer, och användning av [`Release`] gör lastdelen [`Relaxed`].
            ///
            /// **Obs**: Denna metod är endast tillgänglig på plattformar som stöder atomoperationer på
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Migrerar till `compare_exchange` och `compare_exchange_weak`
            ///
            /// `compare_and_swap` motsvarar `compare_exchange` med följande kartläggning för minnesbeställningar:
            ///
            /// Original |Framgång |Fel
            /// -------- | ------- | -------
            /// Avslappnad |Avslappnad |Avslappnad förvärva |Förvärva |Skaffa släpp |Släpp |Avslappnad AcqRel |AcqRel |Skaffa SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` får misslyckas felaktigt även när jämförelsen lyckas, vilket gör att kompilatorn kan generera bättre monteringskod när jämförelsen och bytet används i en slinga.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Lagrar ett värde i atomens heltal om det aktuella värdet är detsamma som `current`-värdet.
            ///
            /// Returvärdet är ett resultat som anger om det nya värdet skrevs och innehöll det tidigare värdet.
            /// Vid framgång är detta värde garanterat lika med `current`.
            ///
            /// `compare_exchange` tar två [`Ordering`]-argument för att beskriva minnesordningen för denna operation.
            /// `success` beskriver den ordning som krävs för läs-modifier-skriv-operationen som äger rum om jämförelsen med `current` lyckas.
            /// `failure` beskriver beställningen som krävs för lastoperationen som sker när jämförelsen misslyckas.
            /// Att använda [`Acquire`] som framgångsbeställning gör butiken till en del av denna operation [`Relaxed`], och med [`Release`] blir den framgångsrika belastningen [`Relaxed`].
            ///
            /// Felbeställningen kan bara vara [`SeqCst`], [`Acquire`] eller [`Relaxed`] och måste motsvara eller svagare än framgångsbeställningen.
            ///
            /// **Obs**: Denna metod är endast tillgänglig på plattformar som stöder atomoperationer på
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // SÄKERHET: dataraser förhindras av atomär inneboende.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Lagrar ett värde i atomens heltal om det aktuella värdet är detsamma som `current`-värdet.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// denna funktion får felaktigt misslyckas även när jämförelsen lyckas, vilket kan resultera i mer effektiv kod på vissa plattformar.
            /// Returvärdet är ett resultat som anger om det nya värdet skrevs och innehöll det tidigare värdet.
            ///
            /// `compare_exchange_weak` tar två [`Ordering`]-argument för att beskriva minnesordningen för denna operation.
            /// `success` beskriver den ordning som krävs för läs-modifier-skriv-operationen som äger rum om jämförelsen med `current` lyckas.
            /// `failure` beskriver beställningen som krävs för lastoperationen som sker när jämförelsen misslyckas.
            /// Att använda [`Acquire`] som framgångsbeställning gör butiken till en del av denna operation [`Relaxed`], och med [`Release`] blir den framgångsrika belastningen [`Relaxed`].
            ///
            /// Felbeställningen kan bara vara [`SeqCst`], [`Acquire`] eller [`Relaxed`] och måste motsvara eller svagare än framgångsbeställningen.
            ///
            /// **Obs**: Denna metod är endast tillgänglig på plattformar som stöder atomoperationer på
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// låt mut gammal= val.load(Ordering::Relaxed);
            /// loop {let new=old * 2;
            ///     matcha val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // SÄKERHET: dataraser förhindras av atomär inneboende.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Lägger till det aktuella värdet och returnerar det tidigare värdet.
            ///
            /// Den här åtgärden slingrar sig vid överflöd.
            ///
            /// `fetch_add` tar ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.Alla beställningslägen är möjliga.
            /// Observera att användning av [`Acquire`] gör butiken till en del av denna operation [`Relaxed`], och användning av [`Release`] gör lastdelen [`Relaxed`].
            ///
            ///
            /// **Obs**: Denna metod är endast tillgänglig på plattformar som stöder atomoperationer på
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÄKERHET: dataraser förhindras av atomär inneboende.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Subtraherar från det aktuella värdet och returnerar det tidigare värdet.
            ///
            /// Den här åtgärden slingrar sig vid överflöd.
            ///
            /// `fetch_sub` tar ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.Alla beställningslägen är möjliga.
            /// Observera att användning av [`Acquire`] gör butiken till en del av denna operation [`Relaxed`], och användning av [`Release`] gör lastdelen [`Relaxed`].
            ///
            ///
            /// **Obs**: Denna metod är endast tillgänglig på plattformar som stöder atomoperationer på
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÄKERHET: dataraser förhindras av atomär inneboende.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitvis "and" med aktuellt värde.
            ///
            /// Utför en bitvis "and"-operation på det aktuella värdet och argumentet `val` och ställer in det nya värdet till resultatet.
            ///
            /// Returnerar föregående värde.
            ///
            /// `fetch_and` tar ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.Alla beställningslägen är möjliga.
            /// Observera att användning av [`Acquire`] gör butiken till en del av denna operation [`Relaxed`], och användning av [`Release`] gör lastdelen [`Relaxed`].
            ///
            ///
            /// **Obs**: Denna metod är endast tillgänglig på plattformar som stöder atomoperationer på
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÄKERHET: dataraser förhindras av atomär inneboende.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitvis "nand" med aktuellt värde.
            ///
            /// Utför en bitvis "nand"-operation på det aktuella värdet och argumentet `val` och ställer in det nya värdet till resultatet.
            ///
            /// Returnerar föregående värde.
            ///
            /// `fetch_nand` tar ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.Alla beställningslägen är möjliga.
            /// Observera att användning av [`Acquire`] gör butiken till en del av denna operation [`Relaxed`], och användning av [`Release`] gör lastdelen [`Relaxed`].
            ///
            ///
            /// **Obs**: Denna metod är endast tillgänglig på plattformar som stöder atomoperationer på
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÄKERHET: dataraser förhindras av atomär inneboende.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitvis "or" med aktuellt värde.
            ///
            /// Utför en bitvis "or"-operation på det aktuella värdet och argumentet `val` och ställer in det nya värdet till resultatet.
            ///
            /// Returnerar föregående värde.
            ///
            /// `fetch_or` tar ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.Alla beställningslägen är möjliga.
            /// Observera att användning av [`Acquire`] gör butiken till en del av denna operation [`Relaxed`], och användning av [`Release`] gör lastdelen [`Relaxed`].
            ///
            ///
            /// **Obs**: Denna metod är endast tillgänglig på plattformar som stöder atomoperationer på
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÄKERHET: dataraser förhindras av atomär inneboende.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitvis "xor" med aktuellt värde.
            ///
            /// Utför en bitvis "xor"-operation på det aktuella värdet och argumentet `val` och ställer in det nya värdet till resultatet.
            ///
            /// Returnerar föregående värde.
            ///
            /// `fetch_xor` tar ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.Alla beställningslägen är möjliga.
            /// Observera att användning av [`Acquire`] gör butiken till en del av denna operation [`Relaxed`], och användning av [`Release`] gör lastdelen [`Relaxed`].
            ///
            ///
            /// **Obs**: Denna metod är endast tillgänglig på plattformar som stöder atomoperationer på
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÄKERHET: dataraser förhindras av atomär inneboende.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Hämtar värdet och tillämpar en funktion på det som returnerar ett valfritt nytt värde.Returnerar en `Result` av `Ok(previous_value)` om funktionen returnerade `Some(_)`, annars `Err(previous_value)`.
            ///
            /// Note: Detta kan anropa funktionen flera gånger om värdet har ändrats från andra trådar under tiden, så länge som funktionen returnerar `Some(_)`, men funktionen har bara tillämpats en gång på det lagrade värdet.
            ///
            ///
            /// `fetch_update` tar två [`Ordering`]-argument för att beskriva minnesordningen för denna operation.
            /// Den första beskriver den erforderliga beställningen för när operationen slutligen lyckas medan den andra beskriver den önskade beställningen för laster.Dessa motsvarar framgång och misslyckade beställningar av
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Att använda [`Acquire`] som framgångsbeställning gör butiken till en del av denna operation [`Relaxed`], och med [`Release`] blir den slutgiltiga lyckade belastningen [`Relaxed`].
            /// (failed) lastbeställning kan endast vara [`SeqCst`], [`Acquire`] eller [`Relaxed`] och måste motsvara eller svagare än framgångsbeställningen.
            ///
            /// **Obs**: Denna metod är endast tillgänglig på plattformar som stöder atomoperationer på
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Beställning: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Beställning: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Max med det aktuella värdet.
            ///
            /// Hitta det högsta av det aktuella värdet och argumentet `val` och ställer in det nya värdet till resultatet.
            ///
            /// Returnerar föregående värde.
            ///
            /// `fetch_max` tar ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.Alla beställningslägen är möjliga.
            /// Observera att användning av [`Acquire`] gör butiken till en del av denna operation [`Relaxed`], och användning av [`Release`] gör lastdelen [`Relaxed`].
            ///
            ///
            /// **Obs**: Denna metod är endast tillgänglig på plattformar som stöder atomoperationer på
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// låt bar=42;
            /// låt max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// hävda! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÄKERHET: dataraser förhindras av atomär inneboende.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Minsta med det aktuella värdet.
            ///
            /// Hitta minsta av det aktuella värdet och argumentet `val` och ställer in det nya värdet till resultatet.
            ///
            /// Returnerar föregående värde.
            ///
            /// `fetch_min` tar ett [`Ordering`]-argument som beskriver minnesordningen för denna operation.Alla beställningslägen är möjliga.
            /// Observera att användning av [`Acquire`] gör butiken till en del av denna operation [`Relaxed`], och användning av [`Release`] gör lastdelen [`Relaxed`].
            ///
            ///
            /// **Obs**: Denna metod är endast tillgänglig på plattformar som stöder atomoperationer på
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// låt bar=12;
            /// låt min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // SÄKERHET: dataraser förhindras av atomär inneboende.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Returnerar en muterbar pekare till det underliggande heltalet.
            ///
            /// Att göra icke-atomiska läsningar och skrivningar på det resulterande heltalet kan vara en datalopp.
            /// Denna metod är mest användbar för FFI, där funktionssignaturen kan använda
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Att returnera en `*mut`-pekare från en delad referens till denna atom är säkert eftersom atomtyperna fungerar med inre mutabilitet.
            /// Alla modifieringar av en atom förändrar värdet genom en delad referens och kan göra det säkert så länge de använder atomoperationer.
            /// All användning av den returnerade råa pekaren kräver ett `unsafe`-block och måste fortfarande upprätthålla samma begränsning: operationerna på den måste vara atomära.
            ///
            ///
            /// # Examples
            ///
            /// `` ignorera (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // SÄKERHET: Säker så länge `my_atomic_op` är atomär.
            /// osäkra {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Returnerar det tidigare värdet (som __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Returnerar det tidigare värdet (som __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// returnerar maxvärdet (signerad jämförelse)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// returnerar minvärdet (signerad jämförelse)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// returnerar maxvärdet (osignerad jämförelse)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// returnerar minvärdet (osignerad jämförelse)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Ett atomstaket.
///
/// Beroende på angiven ordning förhindrar ett staket kompilatorn och CPU: n att omordna vissa typer av minnesoperationer runt den.
/// Det skapar synkroniserar-med relationer mellan det och atomoperationer eller staket i andra trådar.
///
/// Ett staket 'A' som har (åtminstone) [`Release`] beställningssemantik, synkroniseras med ett staket 'B' med (åtminstone) [`Acquire`] semantik, om och bara om det finns operationer X och Y, båda arbetar på något atomföremål 'M' så att A sekvenseras före X, Y synkroniseras innan B och Y observerar ändringen till M.
/// Detta ger ett händelser före beroende mellan A och B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Atomoperationer med [`Release`]-eller [`Acquire`]-semantik kan också synkroniseras med ett staket.
///
/// Ett staket som har [`SeqCst`]-beställning, förutom att ha både [`Acquire`]-och [`Release`]-semantik, deltar i den globala programordningen för de andra [`SeqCst`]-operationerna och/eller staket.
///
/// Accepterar [`Acquire`], [`Release`], [`AcqRel`] och [`SeqCst`] beställningar.
///
/// # Panics
///
/// Panics om `order` är [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // En ömsesidig uteslutning primitiv baserad på spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Vänta tills det gamla värdet är `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Detta staket synkroniseras med butiken i `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // SÄKERHET: Att använda ett atomstaket är säkert.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Ett kompilatorminnesstaket.
///
/// `compiler_fence` avger inte någon maskinkod, men begränsar de typer av minne som ombeställning av kompilatorn får göra.Specifikt, beroende på den givna [`Ordering`]-semantiken, kan kompilatorn inte tillåtas att flytta läsningar eller skrivningar före eller efter samtalet till andra sidan av samtalet till `compiler_fence`.Observera att det **inte** hindrar *hårdvaran* från att göra sådan ombeställning.
///
/// Detta är inte ett problem i en enskild tråd, exekveringskontext, men när andra trådar kan ändra minnet samtidigt krävs starkare synkroniseringsprimitiv som [`fence`].
///
/// Ombeställningen som de olika beställningssemantikerna förhindrar är:
///
///  - med [`SeqCst`] är ingen ombeställning av läsningar och skrivningar över denna punkt tillåten.
///  - med [`Release`] kan föregående läsningar och skrivningar inte flyttas förbi efterföljande skrivningar.
///  - med [`Acquire`] kan efterföljande läsningar och skrivningar inte flyttas före föregående läsningar.
///  - med [`AcqRel`] tillämpas båda ovanstående regler.
///
/// `compiler_fence` är i allmänhet bara användbart för att förhindra en tråd från att tävla *med sig själv*.Det vill säga om en viss tråd kör en kod kod och sedan avbryts och börjar köra någon annanstans (medan den fortfarande är i samma tråd och konceptuellt fortfarande på samma kärna).I traditionella program kan detta bara inträffa när en signalhanterare är registrerad.
/// I mer lågnivåkod kan sådana situationer också uppstå när man hanterar avbrott, vid implementering av gröna trådar med förköp etc.
/// Nyfikna läsare uppmanas att läsa Linux-kärnans diskussion om [memory barriers].
///
/// # Panics
///
/// Panics om `order` är [`Relaxed`].
///
/// # Examples
///
/// Utan `compiler_fence` är `assert_eq!` i följande kod *inte* garanterad att lyckas, trots att allt händer i en enda tråd.
/// För att se varför, kom ihåg att kompilatorn är fri att byta butiker till `IMPORTANT_VARIABLE` och `IS_READ` eftersom de båda är `Ordering::Relaxed`.Om det gör det och signalhanteraren anropas direkt efter att `IS_READY` har uppdaterats, kommer signalhanteraren att se `IS_READY=1`, men `IMPORTANT_VARIABLE=0`.
/// Att använda en `compiler_fence` avhjälper denna situation.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // förhindra att tidigare skrivningar flyttas bortom denna punkt
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // SÄKERHET: Att använda ett atomstaket är säkert.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Signalerar processorn om att den är inne i en upptagen-vänta snurrslinga ("snurrlås").
///
/// Den här funktionen har upphört till förmån för [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}