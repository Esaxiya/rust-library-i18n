use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Ett omslag som hindrar kompilatorn från att automatiskt anropa T-förstöraren.
/// Detta omslag kostar 0.
///
/// `ManuallyDrop<T>` är föremål för samma layoutoptimeringar som `T`.
/// Som en konsekvens har det *ingen effekt* på antaganden som kompilatorn gör om dess innehåll.
/// Att initialisera en `ManuallyDrop<&mut T>` med [`mem::zeroed`] är till exempel odefinierat beteende.
/// Om du behöver hantera oinitialiserad data, använd [`MaybeUninit<T>`] istället.
///
/// Observera att åtkomst till värdet i en `ManuallyDrop<T>` är säkert.
/// Detta innebär att en `ManuallyDrop<T>` vars innehåll har tappats inte får exponeras via ett allmänt säkert API.
/// På motsvarande sätt är `ManuallyDrop::drop` osäker.
///
/// # `ManuallyDrop` och släpp order.
///
/// Rust har en väldefinierad [drop order] värden.
/// För att säkerställa att fält eller lokalbefolkningen tappas i en specifik ordning, ordna om deklarationerna så att den implicita släppordningen är rätt.
///
/// Det är möjligt att använda `ManuallyDrop` för att styra släppordningen, men detta kräver osäker kod och det är svårt att göra korrekt i närvaro av varning.
///
///
/// Om du till exempel vill se till att ett visst fält tappas efter de andra, gör det till det sista fältet i en struktur:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` kommer att tappas efter `children`.
///     // Rust garanterar att fält tappas i deklarationsordningen.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Slå in ett värde som ska släppas manuellt.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Du kan fortfarande använda värdet på ett säkert sätt
    /// assert_eq!(*x, "Hello");
    /// // Men `Drop` kommer inte att köras här
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Extraherar värdet från `ManuallyDrop`-behållaren.
    ///
    /// Detta gör att värdet kan släppas igen.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Detta tappar `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Tar ut värdet från `ManuallyDrop<T>`-behållaren.
    ///
    /// Denna metod är främst avsedd för att flytta ut värden i fall.
    /// I stället för att använda [`ManuallyDrop::drop`] för att manuellt släppa värdet kan du använda den här metoden för att ta värdet och använda det oavsett önskat.
    ///
    /// När det är möjligt är det bättre att använda [`into_inner`][`ManuallyDrop::into_inner`] istället, vilket förhindrar att duplicera innehållet i `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Den här funktionen flyttar semantiskt ut det inneslutna värdet utan att förhindra ytterligare användning och lämnar tillståndet för denna behållare oförändrat.
    /// Det är ditt ansvar att se till att denna `ManuallyDrop` inte används igen.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SÄKERHET: vi läser från en referens, vilket är garanterat
        // för att vara giltig för läsningar.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Manuellt tappar det inneslutna värdet.Detta motsvarar exakt att anropa [`ptr::drop_in_place`] med en pekare till det inneslutna värdet.
    /// Som sådan, såvida inte det inneslutna värdet är en packad struktur, kommer destruktorn att kallas på plats utan att flytta värdet och kan därmed användas för att säkert släppa [pinned]-data.
    ///
    /// Om du äger värdet kan du använda [`ManuallyDrop::into_inner`] istället.
    ///
    /// # Safety
    ///
    /// Denna funktion kör destruktorn för det inneslutna värdet.
    /// Förutom ändringar som görs av själva destruktorn, är minnet oförändrat, och vad beträffar kompilatorn har det fortfarande ett bitmönster som är giltigt för typen `T`.
    ///
    ///
    /// Detta "zombie"-värde bör dock inte exponeras för säker kod, och den här funktionen bör inte anropas mer än en gång.
    /// Att använda ett värde efter att det har tappats eller släppa ett värde flera gånger kan orsaka odefinierat beteende (beroende på vad `drop` gör).
    /// Detta förhindras normalt av typsystemet, men användare av `ManuallyDrop` måste upprätthålla dessa garantier utan hjälp från kompilatorn.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SÄKERHET: vi tappar det värde som pekas på med en förändrad referens
        // vilket garanterat är giltigt för skrivningar.
        // Det är upp till den som ringer att se till att `slot` inte tappas igen.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}