//! Grundläggande funktioner för att hantera minne.
//!
//! Den här modulen innehåller funktioner för att fråga efter storlek och justering av typer, initiera och manipulera minne.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Tar ägande och "forgets" om värdet **utan att köra dess destruktör**.
///
/// Alla resurser som värdet hanterar, till exempel heapminne eller ett filhandtag, kommer att stanna kvar i ett oåtkomligt tillstånd.Det garanterar dock inte att pekare till detta minne förblir giltiga.
///
/// * Om du vill läcka minne, se [`Box::leak`].
/// * Om du vill få en rå pekare till minnet, se [`Box::into_raw`].
/// * Om du vill avyttra ett värde på rätt sätt, kör dess destruktor, se [`mem::drop`].
///
/// # Safety
///
/// `forget` är inte markerat som `unsafe`, eftersom Rust s säkerhetsgarantier inte innehåller en garanti för att förstörare alltid kommer att köras.
/// Ett program kan till exempel skapa en referenscykel med [`Rc`][rc] eller ringa [`process::exit`][exit] för att avsluta utan att köra förstörare.
/// Att tillåta `mem::forget` från säker kod ändrar således inte i grunden Rust s säkerhetsgarantier.
///
/// Med detta sagt är läckande resurser som minne eller I/O-objekt vanligtvis inte önskvärt.
/// Behovet kommer upp i vissa specialiserade användningsfall för FFI eller osäker kod, men även då är [`ManuallyDrop`] vanligtvis att föredra.
///
/// Eftersom glömma ett värde är tillåtet måste alla `unsafe`-koder du skriver tillåta denna möjlighet.Du kan inte returnera ett värde och förvänta dig att den som ringer nödvändigtvis kommer att köra värdets destruktör.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Den kanoniska säkra användningen av `mem::forget` är att kringgå ett värdes destruktor som implementeras av `Drop` trait.Till exempel kommer detta att läcka en `File`, dvs.
/// återta utrymmet som tas av variabeln men stäng aldrig den underliggande systemresursen:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Detta är användbart när äganderätten till den underliggande resursen tidigare överfördes till kod utanför Rust, till exempel genom att överföra råfilbeskrivaren till C-kod.
///
/// # Förhållande till `ManuallyDrop`
///
/// Medan `mem::forget` också kan användas för att överföra *minne* äganderätt, är det felbenäget att göra det.
/// [`ManuallyDrop`] bör användas istället.Tänk till exempel på den här koden:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Bygg en `String` med hjälp av innehållet i `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // läcka `v` eftersom dess minne nu hanteras av `s`
/// mem::forget(v);  // FEL, v är ogiltigt och får inte överföras till en funktion
/// assert_eq!(s, "Az");
/// // `s` tappas implicit och dess minne omplaceras.
/// ```
///
/// Det finns två problem med exemplet ovan:
///
/// * Om mer kod adderades mellan konstruktionen av `String` och anropet av `mem::forget()`, skulle en panic inom den orsaka dubbelfri eftersom samma minne hanteras av både `v` och `s`.
/// * Efter att ha ringt `v.as_mut_ptr()` och överfört äganderätten till data till `s` är `v`-värdet ogiltigt.
/// Även när ett värde bara flyttas till `mem::forget` (som inte inspekterar det), har vissa typer strikta krav på sina värden som gör dem ogiltiga när de dinglar eller inte längre ägs.
/// Att använda ogiltiga värden på något sätt, inklusive att skicka dem till eller returnera dem från funktioner, utgör odefinierat beteende och kan bryta antaganden från kompilatorn.
///
/// Att byta till `ManuallyDrop` undviker båda problemen:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Innan vi tar isär `v` i dess råa delar, se till att den inte tappas!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Demontera nu `v`.Dessa operationer kan inte panic, så det kan inte läcka.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Slutligen bygg en `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` tappas implicit och dess minne omplaceras.
/// ```
///
/// `ManuallyDrop` förhindrar starkt dubbelfri eftersom vi inaktiverar `v`s förstörare innan vi gör något annat.
/// `mem::forget()` tillåter inte detta eftersom det förbrukar sitt argument och tvingar oss att ringa det först efter att ha extraherat allt vi behöver från `v`.
/// Även om en panic infördes mellan konstruktionen av `ManuallyDrop` och byggandet av strängen (vilket inte kan hända i koden som visas), skulle det resultera i en läcka och inte en dubbelfri.
/// Med andra ord, `ManuallyDrop` felar på sidan av läckage istället för att fel på sidan av (dubbel-) droppe.
///
/// `ManuallyDrop` hindrar oss också från att behöva "touch" `v` efter att ha överfört ägandet till `s`-det sista steget i att interagera med `v` för att avyttra det utan att köra dess destruktör undviks helt.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Gillar [`forget`], men accepterar också icke-stora värden.
///
/// Denna funktion är bara ett mellanlägg som är avsett att tas bort när `unsized_locals`-funktionen blir stabiliserad.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Returnerar storleken på en typ i byte.
///
/// Mer specifikt är detta förskjutningen i byte mellan på varandra följande element i en matris med den objekttypen inklusive inriktningspolstring.
///
/// Således, för alla typer `T` och längd `n` har `[T; n]` en storlek på `n * size_of::<T>()`.
///
/// I allmänhet är storleken på en typ inte stabil över sammanställningar, men specifika typer som primitiva är.
///
/// Följande tabell anger storleken på primitiver.
///
/// Typ |storlek av: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 röd |4
///
/// Dessutom har `usize` och `isize` samma storlek.
///
/// Typerna `*const T`, `&T`, `Box<T>`, `Option<&T>` och `Option<Box<T>>` har alla samma storlek.
/// Om `T` är storlek har alla dessa typer samma storlek som `usize`.
///
/// En pekares mutabilitet ändrar inte dess storlek.Som sådan har `&T` och `&mut T` samma storlek.
/// Likaså för `*const T` och `* mut T`.
///
/// # Storlek på `#[repr(C)]`-föremål
///
/// `C`-representationen för objekt har en definierad layout.
/// Med denna layout är storleken på objekten också stabil så länge alla fält har en stabil storlek.
///
/// ## Structts storlek
///
/// För `structs` bestäms storleken av följande algoritm.
///
/// För varje fält i strukturen ordnad efter deklarationsorder:
///
/// 1. Lägg till fältets storlek.
/// 2. Runda upp den aktuella storleken till närmaste multipel av nästa fält [alignment].
///
/// Avsluta slutligen storleken på strukturen till närmaste multipel av dess [alignment].
/// Inriktningen av strukturen är vanligtvis den största inriktningen av alla dess fält;detta kan ändras med hjälp av `repr(align(N))`.
///
/// Till skillnad från `C` avrundas inte nollstorlekar upp till en byte i storlek.
///
/// ## Storlek på Enums
///
/// Enum som inte innehåller någon annan information än den diskriminerande har samma storlek som C-enum på plattformen de är sammanställda för.
///
/// ## Unions storlek
///
/// Storleken på en union är storleken på dess största fält.
///
/// Till skillnad från `C` avrundas inte nollstora fackföreningar upp till en byte i storlek.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Några primitiva
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Några matriser
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Pekarens storlek jämlikhet
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Använda `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Storleken på det första fältet är 1, så lägg till 1 i storleken.Storlek är 1.
/// // Inriktningen för det andra fältet är 2, så lägg till 1 i storleken för vaddering.Storlek är 2.
/// // Storleken på det andra fältet är 2, så lägg till 2 i storleken.Storlek är 4.
/// // Inriktningen för det tredje fältet är 1, så lägg till 0 i storleken för vaddering.Storlek är 4.
/// // Storleken på det tredje fältet är 1, så lägg till 1 i storleken.Storlek är 5.
/// // Slutligen är strukturens inriktning 2 (eftersom den största inriktningen bland dess fält är 2), så lägg 1 till storleken för vaddering.
/// // Storlek är 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple structs följer samma regler.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Observera att omordning av fälten kan minska storleken.
/// // Vi kan ta bort båda vadderingsbyten genom att sätta `third` före `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Unionens storlek är storleken på det största fältet.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Returnerar storleken på det pekade värdet i byte.
///
/// Detta är vanligtvis detsamma som `size_of::<T>()`.
/// Men när `T`*har* ingen statligt känd storlek, t.ex. en skiva [`[T]`][slice] eller en [trait object], kan `size_of_val` användas för att få den dynamiskt kända storleken.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SÄKERHET: `val` är en referens, så det är en giltig råpekare
    unsafe { intrinsics::size_of_val(val) }
}

/// Returnerar storleken på det pekade värdet i byte.
///
/// Detta är vanligtvis detsamma som `size_of::<T>()`.Men när `T`*har* ingen statligt känd storlek, t.ex. en skiva [`[T]`][slice] eller en [trait object], kan `size_of_val_raw` användas för att få den dynamiskt kända storleken.
///
/// # Safety
///
/// Denna funktion är endast säker att ringa om följande villkor gäller:
///
/// - Om `T` är `Sized` är den här funktionen alltid säker att ringa.
/// - Om den osorterade svansen på `T` är:
///     - en [slice], så måste längden på skivsvansen vara ett initialiserat heltal och storleken på *hela värdet*(dynamisk svanslängd + prefix för statisk storlek) måste passa i `isize`.
///     - en [trait object], så måste vtabeldelen av pekaren peka på en giltig vtabell som förvärvats av en osäker tvång, och storleken på *hela värdet*(dynamisk svanslängd + statiskt storlek prefix) måste passa in i `isize`.
///
///     - en (unstable) [extern type], då är den här funktionen alltid säker att ringa, men kan panic eller på annat sätt returnera fel värde, eftersom den externa typens layout inte är känd.
///     Detta är samma beteende som [`size_of_val`] vid en referens till en typ med en extern svans.
///     - annars är det konservativt inte tillåtet att anropa denna funktion.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SÄKERHET: den som ringer måste tillhandahålla en giltig rå pekare
    unsafe { intrinsics::size_of_val(val) }
}

/// Returnerar den [ABI]-krav minsta justeringen av en typ.
///
/// Varje referens till ett värde av typen `T` måste vara en multipel av detta nummer.
///
/// Detta är den inriktning som används för strukturfält.Det kan vara mindre än den föredragna inriktningen.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Returnerar den [ABI]-krav minsta justering av typen av värde som `val` pekar på.
///
/// Varje referens till ett värde av typen `T` måste vara en multipel av detta nummer.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SÄKERHET: val är en referens, så det är en giltig rå pekare
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Returnerar den [ABI]-krav minsta justeringen av en typ.
///
/// Varje referens till ett värde av typen `T` måste vara en multipel av detta nummer.
///
/// Detta är den inriktning som används för strukturfält.Det kan vara mindre än den föredragna inriktningen.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Returnerar den [ABI]-krav minsta justering av typen av värde som `val` pekar på.
///
/// Varje referens till ett värde av typen `T` måste vara en multipel av detta nummer.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SÄKERHET: val är en referens, så det är en giltig rå pekare
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Returnerar den [ABI]-krav minsta justering av typen av värde som `val` pekar på.
///
/// Varje referens till ett värde av typen `T` måste vara en multipel av detta nummer.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Denna funktion är endast säker att ringa om följande villkor gäller:
///
/// - Om `T` är `Sized` är den här funktionen alltid säker att ringa.
/// - Om den osorterade svansen på `T` är:
///     - en [slice], så måste längden på skivsvansen vara ett initialiserat heltal och storleken på *hela värdet*(dynamisk svanslängd + prefix för statisk storlek) måste passa i `isize`.
///     - en [trait object], så måste vtabeldelen av pekaren peka på en giltig vtabell som förvärvats av en osäker tvång, och storleken på *hela värdet*(dynamisk svanslängd + statiskt storlek prefix) måste passa in i `isize`.
///
///     - en (unstable) [extern type], då är den här funktionen alltid säker att ringa, men kan panic eller på annat sätt returnera fel värde, eftersom den externa typens layout inte är känd.
///     Detta är samma beteende som [`align_of_val`] på en hänvisning till en typ med en extern svans.
///     - annars är det konservativt inte tillåtet att anropa denna funktion.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SÄKERHET: den som ringer måste tillhandahålla en giltig rå pekare
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Returnerar `true` om släppande värden av typen `T` betyder något.
///
/// Detta är enbart en optimeringstips och kan implementeras konservativt:
/// det kan returnera `true` för typer som inte behöver släppas.
/// Som sådan skulle alltid returnera `true` vara en giltig implementering av denna funktion.Men om den här funktionen faktiskt returnerar `false`, kan du vara säker på att `T` tappar har ingen bieffekt.
///
/// Lågnivåimplementeringar av saker som samlingar, som måste släppa data manuellt, bör använda den här funktionen för att undvika att i onödan försöka släppa allt innehåll när de förstörs.
///
/// Det här kanske inte gör någon skillnad i release-build (där en loop som inte har några biverkningar lätt kan upptäckas och elimineras), men är ofta en stor vinst för debug builds.
///
/// Observera att [`drop_in_place`] redan utför denna kontroll, så om din arbetsbelastning kan minskas till något litet antal [`drop_in_place`]-samtal är det onödigt att använda detta.
/// Observera särskilt att du kan [`drop_in_place`] en skiva, och det kommer att göra en enda behov_droppskontroll för alla värden.
///
/// Typer som Vec är därför bara `drop_in_place(&mut self[..])` utan att använda `needs_drop` uttryckligen.
/// Typer som [`HashMap`], å andra sidan, måste släppa värdena en i taget och bör använda detta API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Här är ett exempel på hur en samling kan använda `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // släpp data
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Returnerar värdet av typen `T` representerad av byte-mönstret helt noll.
///
/// Detta innebär att till exempel vadderingsbyte i `(u8, u16)` inte nödvändigtvis nollställs.
///
/// Det finns ingen garanti för att ett byte-mönster helt noll representerar ett giltigt värde av någon typ `T`.
/// Till exempel är byte-mönstret helt noll inte ett giltigt värde för referenstyper (`&T`, `&mut T`) och funktionspekare.
/// Att använda `zeroed` på sådana typer orsakar omedelbar [undefined behavior][ub] eftersom [the Rust compiler assumes][inv] att det alltid finns ett giltigt värde i en variabel som den anser vara initialiserad.
///
///
/// Detta har samma effekt som [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Det är användbart för FFI ibland, men bör i allmänhet undvikas.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Korrekt användning av denna funktion: initialisering av ett heltal med noll.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Felaktig* användning av denna funktion: initialisering av en referens med noll.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Odefinierat beteende!
/// let _y: fn() = unsafe { mem::zeroed() }; // Och igen!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SÄKERHET: den som ringer måste garantera att ett nollvärde är giltigt för `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Bypassar Rust: s normala minnesinitialiseringskontroller genom att låtsas producera ett värde av typen `T`, medan du inte gör någonting alls.
///
/// **Denna funktion är utfasad.** Använd [`MaybeUninit<T>`] istället.
///
/// Anledningen till avskrivningen är att funktionen i princip inte kan användas korrekt: den har samma effekt som [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Som [`assume_init` documentation][assume_init] förklarar är [the Rust compiler assumes][inv] att värdena initialiseras ordentligt.
/// Som en konsekvens ringer t.ex.
/// `mem::uninitialized::<bool>()` orsakar omedelbart odefinierat beteende för att returnera en `bool` som inte definitivt är varken `true` eller `false`.
/// Värre, riktigt oinitialiserat minne som det som kommer tillbaka här är speciellt eftersom kompilatorn vet att det inte har ett fast värde.
/// Detta gör det odefinierat beteende att ha oinitialiserad data i en variabel även om variabeln har en heltalstyp.
/// (Observera att reglerna kring oinitialiserade heltal inte är slutgiltiga än, men tills de är det är det lämpligt att undvika dem.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SÄKERHET: den som ringer måste garantera att ett enhetligt värde är giltigt för `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Byt värdena på två muterbara platser utan att avinitialisera någon av dem.
///
/// * Om du vill byta med ett standard-eller dummyvärde, se [`take`].
/// * Om du vill byta med ett godkänt värde, returnera det gamla värdet, se [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SÄKERHET: de råa pekarna har skapats från säkra muterbara referenser som uppfyller alla
    // begränsningar för `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Ersätter `dest` med standardvärdet `T` och returnerar det tidigare `dest`-värdet.
///
/// * Om du vill ersätta värdena för två variabler, se [`swap`].
/// * Om du vill ersätta med ett godkänt värde istället för standardvärdet, se [`replace`].
///
/// # Examples
///
/// Ett enkelt exempel:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` gör det möjligt att ta ägande av ett strukturfält genom att ersätta det med ett "empty"-värde.
/// Utan `take` kan du stöta på problem som dessa:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Observera att `T` inte nödvändigtvis implementerar [`Clone`], så det kan inte ens klona och återställa `self.buf`.
/// Men `take` kan användas för att koppla bort originalvärdet för `self.buf` från `self`, så att det kan returneras:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Flyttar `src` till den refererade `dest` och returnerar det tidigare `dest`-värdet.
///
/// Inget värde tappas.
///
/// * Om du vill ersätta värdena för två variabler, se [`swap`].
/// * Om du vill ersätta med ett standardvärde, se [`take`].
///
/// # Examples
///
/// Ett enkelt exempel:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` tillåter konsumtion av ett strukturfält genom att ersätta det med ett annat värde.
/// Utan `replace` kan du stöta på problem som dessa:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Observera att `T` inte nödvändigtvis implementerar [`Clone`], så vi kan inte ens klona `self.buf[i]` för att undvika flytten.
/// Men `replace` kan användas för att koppla bort det ursprungliga värdet vid det indexet från `self`, så att det kan returneras:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SÄKERHET: Vi läser från `dest` men skriver direkt `src` i den efteråt,
    // så att det gamla värdet inte dupliceras.
    // Ingenting tappas och inget här kan panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Avyttrar ett värde.
///
/// Detta görs genom att kalla argumentets implementering av [`Drop`][drop].
///
/// Detta gör faktiskt ingenting för typer som implementerar `Copy`, t.ex.
/// integers.
/// Sådana värden kopieras och _then_ flyttas till funktionen, så värdet kvarstår efter detta funktionsanrop.
///
///
/// Denna funktion är inte magisk;det definieras bokstavligen som
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Eftersom `_x` flyttas till funktionen tappas den automatiskt innan funktionen återvänder.
///
/// [drop]: Drop
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // släpp vector uttryckligen
/// ```
///
/// Eftersom [`RefCell`] tillämpar lånereglerna under körning kan `drop` släppa en [`RefCell`]-lån:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // avstå från den mutabla lånen på den här platsen
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Heltals och andra typer som implementerar [`Copy`] påverkas inte av `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // en kopia av `x` flyttas och släpps
/// drop(y); // en kopia av `y` flyttas och släpps
///
/// println!("x: {}, y: {}", x, y.0); // fortfarande tillgängliga
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Tolkar `src` som typ `&U` och läser sedan `src` utan att flytta det inneslutna värdet.
///
/// Denna funktion antar säkert att pekaren `src` är giltig för [`size_of::<U>`][size_of] byte genom att överföra `&T` till `&U` och sedan läsa `&U` (förutom att detta görs på ett sätt som är korrekt även när `&U` ställer strängare justeringskrav än `&T`).
/// Det skapar också en säker kopia av det inneslutna värdet istället för att flytta ut ur `src`.
///
/// Det är inte ett kompileringsfel om `T` och `U` har olika storlekar, men det rekommenderas starkt att endast åberopa denna funktion där `T` och `U` har samma storlek.Denna funktion utlöser [undefined behavior][ub] om `U` är större än `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopiera data från 'foo_array' och behandla dem som en 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Ändra kopierade data
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Innehållet i 'foo_array' borde inte ha ändrats
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Om U har ett högre inriktningskrav kanske src inte är lämpligt inriktade.
    if align_of::<U>() > align_of::<T>() {
        // SÄKERHET: `src` är en referens som garanterat är giltig för läsningar.
        // Den som ringer måste garantera att den faktiska transmutationen är säker.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SÄKERHET: `src` är en referens som garanterat är giltig för läsningar.
        // Vi kontrollerade precis att `src as *const U` var korrekt anpassad.
        // Den som ringer måste garantera att den faktiska transmutationen är säker.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Ogenomskinlig typ som representerar enumets diskriminant.
///
/// Se [`discriminant`]-funktionen i den här modulen för mer information.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Dessa trait-implementeringar kan inte härledas eftersom vi inte vill ha några gränser för T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Returnerar ett värde som unikt identifierar enum-varianten i `v`.
///
/// Om `T` inte är enum, kommer anrop till denna funktion inte att resultera i odefinierat beteende, men returvärdet är ospecificerat.
///
///
/// # Stability
///
/// Diskriminanten för enum-variant kan ändras om definitionen av enum ändras.
/// En diskriminant av någon variant kommer inte att växla mellan sammanställningar med samma kompilator.
///
/// # Examples
///
/// Detta kan användas för att jämföra enums som bär data, samtidigt som man bortser från de faktiska uppgifterna:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Returnerar antalet varianter i enumtypen `T`.
///
/// Om `T` inte är enum, kommer anrop till denna funktion inte att resultera i odefinierat beteende, men returvärdet är ospecificerat.
/// På samma sätt, om `T` är ett antal med fler varianter än `usize::MAX`, är returvärdet ospecificerat.
/// Obebodda varianter kommer att räknas.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}