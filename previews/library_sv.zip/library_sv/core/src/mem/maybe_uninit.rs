use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// En omslagstyp för att konstruera oinitialiserade instanser av `T`.
///
/// # Initialisering invariant
///
/// Kompilatorn antar i allmänhet att en variabel är korrekt initierad enligt kraven för variabelns typ.Till exempel måste en variabel med referens typ vara inriktad och inte NULL.
/// Detta är en invariant som *alltid* måste upprätthållas, även i osäker kod.
/// Som en konsekvens orsakar nollinitiering av en variabel av referens typ omedelbar [undefined behavior][ub], oavsett om referensen någonsin blir van vid att komma åt minne:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // odefinierat beteende!⚠️
/// // Motsvarande kod med `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // odefinierat beteende!⚠️
/// ```
///
/// Detta utnyttjas av kompilatorn för olika optimeringar, till exempel eliminering av körningstider och optimering av `enum`-layout.
///
/// På samma sätt kan helt oinitialiserat minne ha något innehåll, medan en `bool` alltid måste vara `true` eller `false`.Därför är att skapa ett oinitialiserat `bool` odefinierat beteende:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // odefinierat beteende!⚠️
/// // Motsvarande kod med `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // odefinierat beteende!⚠️
/// ```
///
/// Dessutom är oinitialiserat minne speciellt eftersom det inte har ett fast värde ("fixed" betyder "it won't change without being written to").Att läsa samma oinitialiserade byte flera gånger kan ge olika resultat.
/// Detta gör det odefinierat beteende att ha oinitialiserad data i en variabel även om variabeln har en heltalstyp, som annars kan innehålla alla *fasta* bitmönster:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // odefinierat beteende!⚠️
/// // Motsvarande kod med `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // odefinierat beteende!⚠️
/// ```
/// (Observera att reglerna kring oinitialiserade heltal inte är slutgiltiga än, men tills de är det är det lämpligt att undvika dem.)
///
/// Utöver det, kom ihåg att de flesta typer har ytterligare invarianter utöver att bara betraktas som initialiserade på typnivå.
/// Till exempel anses en '1'-initierad [`Vec<T>`] vara initialiserad (under den nuvarande implementeringen; detta utgör inte en stabil garanti) eftersom det enda kravet som kompilatorn vet om det är att datapekaren måste vara icke-null.
/// Att skapa en sådan `Vec<T>` orsakar inte *omedelbart* odefinierat beteende, men kommer att orsaka odefinierat beteende med de mest säkra operationerna (inklusive att tappa det).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` tjänar till att möjliggöra osäker kod för att hantera oinitialiserad data.
/// Det är en signal till kompilatorn som indikerar att data här kanske *inte* initialiseras:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Skapa en uttryckligen oinitialiserad referens.
/// // Kompilatorn vet att data i en `MaybeUninit<T>` kan vara ogiltiga, och därför är detta inte UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Ställ in ett giltigt värde.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Extrahera initialiserade data-detta är endast tillåtet *efter* att `x` har initialiserats ordentligt!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Kompilatorn vet då att inte göra några felaktiga antaganden eller optimeringar för den här koden.
///
/// Du kan tänka på `MaybeUninit<T>` som att vara lite som `Option<T>` men utan någon av körtidsspårningen och utan någon säkerhetskontroll.
///
/// ## out-pointers
///
/// Du kan använda `MaybeUninit<T>` för att implementera "out-pointers": istället för att returnera data från en funktion, skicka en pekare till något (uninitialized)-minne för att lägga resultatet i.
/// Detta kan vara användbart när det är viktigt för den som ringer att styra hur minnet resultatet lagras i tilldelas och du vill undvika onödiga drag.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` tappar inte det gamla innehållet, vilket är viktigt.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Nu vet vi att `v` är initialiserat!Detta säkerställer också att vector tappas ordentligt.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Initiera en matris element för element
///
/// `MaybeUninit<T>` kan användas för att initiera en stor grupp element-för-element:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Skapa en oinitialiserad matris av `MaybeUninit`.
///     // `assume_init` är säker eftersom den typ vi hävdar att vi har initierat här är en massa `MaybeUninit`s, som inte kräver initialisering.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Att släppa en `MaybeUninit` gör ingenting.
///     // Användning av råpekartilldelning istället för `ptr::write` orsakar således inte att det gamla oinitialiserade värdet tappas.
/////
///     // Också om det finns en panic under den här slingan har vi en minnesläcka, men det finns inget minnessäkerhetsproblem.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Allt är initialiserat.
///     // Transmutera matrisen till den initialiserade typen.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Du kan också arbeta med delvis initierade matriser, som kan hittas i datastrukturer på låg nivå.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Skapa en oinitialiserad matris av `MaybeUninit`.
/// // `assume_init` är säker eftersom den typ vi hävdar att vi har initierat här är en massa `MaybeUninit`s, som inte kräver initialisering.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Räkna antalet element vi har tilldelat.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // För varje objekt i matrisen, släpp om vi tilldelade den.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Initiera en struktur fält-för-fält
///
/// Du kan använda `MaybeUninit<T>` och [`std::ptr::addr_of_mut`]-makrot för att initiera strukturer fält för fält:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Initierar `name`-fältet
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Initiera `list`-fältet Om det finns en panic här läcker `String` i `name`-fältet.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Alla fält är initialiserade, så vi kallar `assume_init` för att få en initialiserad Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` garanteras ha samma storlek, justering och ABI som `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Kom dock ihåg att en typ *som innehåller* en `MaybeUninit<T>` inte nödvändigtvis är samma layout;Rust garanterar i allmänhet inte att fälten i en `Foo<T>` har samma ordning som en `Foo<U>` även om `T` och `U` har samma storlek och inriktning.
///
/// Eftersom något bitvärde är giltigt för en `MaybeUninit<T>` kan kompilatorn inte tillämpa non-zero/niche-filling-optimeringar, vilket kan resultera i en större storlek:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Om `T` är FFI-säkert är `MaybeUninit<T>` det också.
///
/// Medan `MaybeUninit` är `#[repr(transparent)]` (vilket indikerar att den garanterar samma storlek, inriktning och ABI som `T`), ändrar detta inte * någon av de föregående förbehållen.
/// `Option<T>` och `Option<MaybeUninit<T>>` kan fortfarande ha olika storlekar, och typer som innehåller ett fält av typen `T` kan läggas ut (och dimensioneras) annorlunda än om det fältet var `MaybeUninit<T>`.
/// `MaybeUninit` är en unionstyp och `#[repr(transparent)]` på fackföreningar är instabil (se [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Med tiden kan de exakta garantierna för `#[repr(transparent)]` på fackföreningar utvecklas, och `MaybeUninit` kan eller kanske inte förbli `#[repr(transparent)]`.
/// Med detta sagt kommer `MaybeUninit<T>`*alltid* att garantera att den har samma storlek, inriktning och ABI som `T`;det är bara det sätt som `MaybeUninit` implementerar den garantin kan utvecklas.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang objekt så att vi kan linda in andra typer i det.Detta är användbart för generatorer.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Vi ringer inte `T::clone()`, vi kan inte veta om vi är initialiserade nog för det.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Skapar en ny `MaybeUninit<T>` initialiserad med det angivna värdet.
    /// Det är säkert att ringa [`assume_init`] på returvärdet för denna funktion.
    ///
    /// Observera att att släppa en `MaybeUninit<T>` inte kommer att ringa T-kod.
    /// Det är ditt ansvar att se till att `T` tappas om den initialiseras.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Skapar en ny `MaybeUninit<T>` i oinitialiserat tillstånd.
    ///
    /// Observera att att släppa en `MaybeUninit<T>` inte kommer att ringa T-kod.
    /// Det är ditt ansvar att se till att `T` tappas om den initialiseras.
    ///
    /// Se [type-level documentation][MaybeUninit] för några exempel.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Skapa en ny uppsättning `MaybeUninit<T>`-objekt, i oinitialiserat tillstånd.
    ///
    /// Note: i en future Rust-version kan denna metod bli onödig när matris bokstavlig syntax tillåter [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Exemplet nedan kan då använda `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Returnerar en (möjligen mindre) bit data som faktiskt har lästs
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SÄKERHET: En oinitialiserad `[MaybeUninit<_>; LEN]` är giltig.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Skapar en ny `MaybeUninit<T>` i oinitialiserat tillstånd, där minnet fylls med `0` byte.Det beror på `T` om det redan ger rätt initialisering.
    ///
    /// Till exempel initialiseras `MaybeUninit<usize>::zeroed()`, men `MaybeUninit<&'static i32>::zeroed()` beror inte på att referenser inte får vara null.
    ///
    /// Observera att att släppa en `MaybeUninit<T>` inte kommer att ringa T-kod.
    /// Det är ditt ansvar att se till att `T` tappas om den initialiseras.
    ///
    /// # Example
    ///
    /// Korrekt användning av denna funktion: att initiera en struktur med noll, där alla fält i strukturen kan hålla bitmönstret 0 som ett giltigt värde.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Felaktig* användning av denna funktion: anrop till `x.zeroed().assume_init()` när `0` inte är ett giltigt bitmönster för typen:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Inuti ett par skapar vi en `NotZero` som inte har en giltig diskriminant.
    /// // Detta är odefinierat beteende.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SÄKERHET: `u.as_mut_ptr()` pekar på tilldelat minne.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Ställer in värdet på `MaybeUninit<T>`.
    /// Detta skriver över alla tidigare värden utan att tappa det, så var försiktig så att du inte använder detta två gånger såvida du inte vill hoppa över att köra förstöraren.
    ///
    /// För din bekvämlighet returnerar detta också en förändrad referens till (nu säkert initierat) innehåll i `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SÄKERHET: Vi initialiserade just detta värde.
        unsafe { self.assume_init_mut() }
    }

    /// Får en pekare till det inneslutna värdet.
    /// Att läsa från den här pekaren eller förvandla den till en referens är odefinierat beteende såvida inte `MaybeUninit<T>` initialiseras.
    /// Att skriva till minnet som den här pekaren (non-transitively) pekar på är odefinierat beteende (utom i en `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Korrekt användning av denna metod:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Skapa en referens till `MaybeUninit<T>`.Det här är okej eftersom vi initialiserade det.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Felaktig* användning av denna metod:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Vi har skapat en referens till en oinitialiserad vector!Detta är odefinierat beteende.⚠️
    /// ```
    ///
    /// (Observera att reglerna kring referenser till oinitialiserad data inte är slutgiltiga än, men tills de är det är det tillrådligt att undvika dem.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` och `ManuallyDrop` är båda `repr(transparent)` så att vi kan kasta pekaren.
        self as *const _ as *const T
    }

    /// Hämtar en muterbar pekare till det inneslutna värdet.
    /// Att läsa från den här pekaren eller förvandla den till en referens är odefinierat beteende såvida inte `MaybeUninit<T>` initialiseras.
    ///
    /// # Examples
    ///
    /// Korrekt användning av denna metod:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Skapa en referens till `MaybeUninit<Vec<u32>>`.
    /// // Det här är okej eftersom vi initialiserade det.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Felaktig* användning av denna metod:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Vi har skapat en referens till en oinitialiserad vector!Detta är odefinierat beteende.⚠️
    /// ```
    ///
    /// (Observera att reglerna kring referenser till oinitialiserad data inte är slutgiltiga än, men tills de är det är det tillrådligt att undvika dem.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` och `ManuallyDrop` är båda `repr(transparent)` så att vi kan kasta pekaren.
        self as *mut _ as *mut T
    }

    /// Extraherar värdet från `MaybeUninit<T>`-behållaren.Detta är ett utmärkt sätt att säkerställa att data släpps, eftersom den resulterande `T` är föremål för den vanliga dropphanteringen.
    ///
    /// # Safety
    ///
    /// Det är upp till den som ringer att garantera att `MaybeUninit<T>` verkligen är i initialiserat tillstånd.Att anropa detta när innehållet ännu inte är fullständigt initierat orsakar omedelbart odefinierat beteende.
    /// [type-level documentation][inv] innehåller mer information om denna initialiseringsvariant.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Utöver det, kom ihåg att de flesta typer har ytterligare invarianter utöver att bara betraktas som initialiserade på typnivå.
    /// Till exempel anses en '1'-initierad [`Vec<T>`] vara initialiserad (under den nuvarande implementeringen; detta utgör inte en stabil garanti) eftersom det enda kravet som kompilatorn vet om det är att datapekaren måste vara icke-null.
    ///
    /// Att skapa en sådan `Vec<T>` orsakar inte *omedelbart* odefinierat beteende, men kommer att orsaka odefinierat beteende med de mest säkra operationerna (inklusive att tappa det).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Korrekt användning av denna metod:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Felaktig* användning av denna metod:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` hade inte initialiserats ännu, så den sista raden orsakade odefinierat beteende.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SÄKERHET: den som ringer måste garantera att `self` initialiseras.
        // Detta innebär också att `self` måste vara en `value`-variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Läser värdet från `MaybeUninit<T>`-behållaren.Den resulterande `T` är föremål för den vanliga dropphanteringen.
    ///
    /// När det är möjligt är det att föredra att använda [`assume_init`] istället, vilket förhindrar att duplicera innehållet i `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Det är upp till den som ringer att garantera att `MaybeUninit<T>` verkligen är i initialiserat tillstånd.Att anropa detta när innehållet ännu inte är fullständigt initierat orsakar odefinierat beteende.
    /// [type-level documentation][inv] innehåller mer information om denna initialiseringsvariant.
    ///
    /// Dessutom lämnar detta en kopia av samma data i `MaybeUninit<T>`.
    /// När du använder flera kopior av data (genom att ringa `assume_init_read` flera gånger, eller först ringa `assume_init_read` och sedan [`assume_init`]), är det ditt ansvar att se till att dessa data verkligen kan dupliceras.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Korrekt användning av denna metod:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` är `Copy`, så vi kan läsa flera gånger.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Det är okej att kopiera ett `None`-värde, så vi kan läsa flera gånger.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Felaktig* användning av denna metod:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Vi skapade nu två kopior av samma vector, vilket ledde till en dubbelfri ⚠️ när de båda tappas!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SÄKERHET: den som ringer måste garantera att `self` initialiseras.
        // Att läsa från `self.as_ptr()` är säkert eftersom `self` bör initieras.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Tappar det inneslutna värdet på plats.
    ///
    /// Om du äger `MaybeUninit` kan du istället använda [`assume_init`].
    ///
    /// # Safety
    ///
    /// Det är upp till den som ringer att garantera att `MaybeUninit<T>` verkligen är i initialiserat tillstånd.Att anropa detta när innehållet ännu inte är fullständigt initierat orsakar odefinierat beteende.
    ///
    /// Utöver det måste alla ytterligare invarianter av typen `T` vara uppfyllda, eftersom `Drop`-implementeringen av `T` (eller dess medlemmar) kan förlita sig på detta.
    /// Till exempel anses en '1'-initierad [`Vec<T>`] vara initialiserad (under den nuvarande implementeringen; detta utgör inte en stabil garanti) eftersom det enda kravet som kompilatorn vet om det är att datapekaren måste vara icke-null.
    ///
    /// Att släppa en sådan `Vec<T>` kommer dock att orsaka odefinierat beteende.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SÄKERHET: den som ringer måste garantera att `self` initialiseras och
        // uppfyller alla invarianter av `T`.
        // Att släppa värdet på plats är säkert om så är fallet.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Hämtar en delad referens till det inneslutna värdet.
    ///
    /// Detta kan vara användbart när vi vill komma åt en `MaybeUninit` som har initierats men inte äger `MaybeUninit` (vilket förhindrar att `.assume_init()`) används.
    ///
    /// # Safety
    ///
    /// Att ringa detta när innehållet ännu inte är helt initierat orsakar odefinierat beteende: det är upp till den som ringer att garantera att `MaybeUninit<T>` verkligen är i ett initialiserat tillstånd.
    ///
    ///
    /// # Examples
    ///
    /// ### Korrekt användning av denna metod:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Initiera `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Nu när det är känt att vår `MaybeUninit<_>` är initialiserad är det okej att skapa en delad referens till den:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SÄKERHET: `x` har initierats.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Felaktig* användning av denna metod:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Vi har skapat en referens till en oinitialiserad vector!Detta är odefinierat beteende.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Initiera `MaybeUninit` med `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Hänvisning till en oinitialiserad `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SÄKERHET: den som ringer måste garantera att `self` initialiseras.
        // Detta innebär också att `self` måste vara en `value`-variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Hämtar en muterbar (unique)-referens till det inneslutna värdet.
    ///
    /// Detta kan vara användbart när vi vill komma åt en `MaybeUninit` som har initierats men inte äger `MaybeUninit` (vilket förhindrar att `.assume_init()`) används.
    ///
    /// # Safety
    ///
    /// Att ringa detta när innehållet ännu inte är helt initierat orsakar odefinierat beteende: det är upp till den som ringer att garantera att `MaybeUninit<T>` verkligen är i ett initialiserat tillstånd.
    /// Till exempel kan `.assume_init_mut()` inte användas för att initialisera en `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Korrekt användning av denna metod:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Initierar *alla* byte i inmatningsbufferten.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Initiera `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Nu vet vi att `buf` har initierats, så vi kan `.assume_init()` det.
    /// // Användning av `.assume_init()` kan dock utlösa en `memcpy` av 2048 byte.
    /// // För att hävda att vår buffert har initierats utan att kopiera den uppgraderar vi `&mut MaybeUninit<[u8; 2048]>` till en `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // SÄKERHET: `buf` har initierats.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Nu kan vi använda `buf` som en vanlig skiva:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Felaktig* användning av denna metod:
    ///
    /// Du kan inte använda `.assume_init_mut()` för att initialisera ett värde:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Vi har skapat en (mutable)-referens till en oinitialiserad `bool`!
    ///     // Detta är odefinierat beteende.⚠️
    /// }
    /// ```
    ///
    /// Du kan till exempel inte [`Read`] till en oinitialiserad buffert:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) referens till oinitialiserat minne!
    ///                             // Detta är odefinierat beteende.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Du kan inte heller använda direkt fältåtkomst för att gradvis initiera fält för fält:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referens till oinitialiserat minne!
    ///                  // Detta är odefinierat beteende.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referens till oinitialiserat minne!
    ///                  // Detta är odefinierat beteende.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Vi litar för närvarande på att ovanstående är felaktiga, dvs vi har referenser till oinitialiserad data (t.ex. i `libcore/fmt/float.rs`).
    // Vi bör fatta ett slutgiltigt beslut om reglerna innan stabilisering.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SÄKERHET: den som ringer måste garantera att `self` initialiseras.
        // Detta innebär också att `self` måste vara en `value`-variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Extraherar värdena från en uppsättning `MaybeUninit`-behållare.
    ///
    /// # Safety
    ///
    /// Det är upp till den som ringer att garantera att alla element i matrisen är i ett initialiserat tillstånd.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SÄKERHET: Nu säkert när vi initialiserade alla element
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Den som ringer garanterar att alla element i matrisen initialiseras
        // * `MaybeUninit<T>` och T har garanterat samma layout
        // * MaybeUnint tappar inte, så det finns inga dubbelfriheter och därmed är konverteringen säker
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Förutsatt att alla element är initialiserade, få en bit till dem.
    ///
    /// # Safety
    ///
    /// Det är upp till den som ringer att garantera att `MaybeUninit<T>`-elementen verkligen är i ett initialiserat tillstånd.
    ///
    /// Att anropa detta när innehållet ännu inte är fullständigt initierat orsakar odefinierat beteende.
    ///
    /// Se [`assume_init_ref`] för mer information och exempel.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SÄKERHET: att kasta skiva till en `*const [T]` är säkert eftersom den som ringer garanterar det
        // `slice` initialiseras och `MaybeUninit` har garanterat samma layout som `T`.
        // Den erhållna pekaren är giltig eftersom den hänvisar till minne som ägs av `slice`, vilket är en referens och därmed garanterat giltigt för läsningar.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Förutsatt att alla element är initialiserade, få en muterbar del till dem.
    ///
    /// # Safety
    ///
    /// Det är upp till den som ringer att garantera att `MaybeUninit<T>`-elementen verkligen är i ett initialiserat tillstånd.
    ///
    /// Att anropa detta när innehållet ännu inte är fullständigt initierat orsakar odefinierat beteende.
    ///
    /// Se [`assume_init_mut`] för mer information och exempel.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SÄKERHET: liknar säkerhetsanvisningar för `slice_get_ref`, men vi har en
        // muterbar referens som också garanteras vara giltig för skrivningar.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Hämtar en pekare till det första elementet i matrisen.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Hämtar en muterbar pekare till det första elementet i matrisen.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Kopierar elementen från `src` till `this` och returnerar en förändrad referens till det nu initaliserade innehållet i `this`.
    ///
    /// Om `T` inte implementerar `Copy`, använd [`write_slice_cloned`]
    ///
    /// Detta liknar [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Denna funktion kommer att panic om de två skivorna har olika längder.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SÄKERHET: vi har just kopierat alla delar av len till ledig kapacitet
    /// // de första src.len()-elementen i vec är giltiga nu.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SÄKERHET: &[T] och&[MaybeUninit<T>] har samma layout
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SÄKERHET: Giltiga element har just kopierats till `this` så det är initaliserat
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Klonar elementen från `src` till `this`, vilket ger en muterbar referens till det nu initaliserade innehållet i `this`.
    /// Eventuella redan initaliserade element kommer inte att tas bort.
    ///
    /// Om `T` implementerar `Copy`, använd [`write_slice`]
    ///
    /// Detta liknar [`slice::clone_from_slice`] men tappar inte befintliga element.
    ///
    /// # Panics
    ///
    /// Denna funktion kommer att panic om de två skivorna har olika längder, eller om implementeringen av `Clone` panics.
    ///
    /// Om det finns en panic kommer de redan klonade elementen att släppas.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SÄKERHET: vi har precis klonat alla delar av len i ledig kapacitet
    /// // de första src.len()-elementen i vec är giltiga nu.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // till skillnad från copy_from_slice kallar detta inte clone_from_slice på segmentet detta beror på att `MaybeUninit<T: Clone>` inte implementerar Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SÄKERHET: denna råa skiva innehåller endast initialiserade objekt
                // det är därför det är tillåtet att släppa det.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Vi måste skära dem uttryckligen i samma längd
        // för att gränskontroll ska elideras, och optimeraren genererar memcpy för enkla fall (till exempel T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // vakt behövs b/c panic kan hända under en klon
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SÄKERHET: Giltiga element har precis skrivits in i `this` så det är initaliserat
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}