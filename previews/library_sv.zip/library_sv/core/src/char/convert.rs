//! Teckenomvandlingar.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Konverterar en `u32` till en `char`.
///
/// Observera att alla [`char`] är giltiga [`u32`] s och kan gjutas till en med
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Det motsatta är dock inte sant: inte alla giltiga [`u32`] är giltiga [`char`] s.
/// `from_u32()` returnerar `None` om ingången inte är ett giltigt värde för en [`char`].
///
/// För en osäker version av denna funktion som ignorerar dessa kontroller, se [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Returnerar `None` när ingången inte är en giltig [`char`]:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Konverterar en `u32` till en `char` och ignorerar giltigheten.
///
/// Observera att alla [`char`] är giltiga [`u32`] s och kan gjutas till en med
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Det motsatta är dock inte sant: inte alla giltiga [`u32`] är giltiga [`char`] s.
/// `from_u32_unchecked()` kommer att ignorera detta och blindt casta till [`char`], eventuellt skapa en ogiltig.
///
///
/// # Safety
///
/// Denna funktion är osäker, eftersom den kan konstruera ogiltiga `char`-värden.
///
/// För en säker version av denna funktion, se [`from_u32`]-funktionen.
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // SÄKERHET: den som ringer måste garantera att `i` är ett giltigt char-värde.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Konverterar en [`char`] till en [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Konverterar en [`char`] till en [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Tecknet kastas till värdet på kodpunkten och utvidgas sedan till 64 bitar.
        // Se [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Konverterar en [`char`] till en [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Tecknet kastas till värdet på kodpunkten och utvidgas sedan till 128 bitar.
        // Se [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Kartor en byte i 0x00 ..=0xFF till en `char` vars kodpunkt har samma värde, i U + 0000 ..=U + 00FF.
///
/// Unicode är utformad så att detta effektivt avkodar byte med den teckenkodning som IANA kallar ISO-8859-1.
/// Denna kodning är kompatibel med ASCII.
///
/// Observera att detta skiljer sig från ISO/IEC 8859-1 aka
/// ISO 8859-1 (med ett bindestreck mindre), vilket lämnar några "blanks", bytevärden som inte tilldelas något tecken.
/// ISO-8859-1 (IANA one) tilldelar dem till kontrollkoderna C0 och C1.
///
/// Observera att detta *också* skiljer sig från Windows-1252 aka
/// kodsida 1252, som är ett superset ISO/IEC 8859-1 som tilldelar några (inte alla!) blanketter till skiljetecken och olika latinska tecken.
///
/// För att förvirra saker ytterligare är [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` och `windows-1252` alla alias för ett superset av Windows-1252 som fyller de återstående blanketterna med motsvarande C0-och C1-kontrollkoder.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Konverterar en [`u8`] till en [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Ett fel som kan returneras vid parsning av en röd.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // SÄKERHET: kontrollerat att det är ett lagligt unicode-värde
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Feltypen returneras när en konvertering från u32 till char misslyckas.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Konverterar en siffra i en given radix till en `char`.
///
/// En 'radix' här kallas ibland också en 'base'.
/// En radix av två indikerar ett binärt tal, en radix av tio, decimal och en radix av sexton, hexadecimal, för att ge några gemensamma värden.
///
/// Godtyckliga strålar stöds.
///
/// `from_digit()` returnerar `None` om ingången inte är en siffra i den angivna radixen.
///
/// # Panics
///
/// Panics om det ges en radix större än 36.
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Decimal 11 är en enda siffra i bas 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Återgår till `None` när ingången inte är en siffra:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Passerar en stor radix och orsakar en panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}