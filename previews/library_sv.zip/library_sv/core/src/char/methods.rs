//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Den högsta giltiga kodpunkten som en `char` kan ha.
    ///
    /// En `char` är en [Unicode Scalar Value], vilket betyder att den är en [Code Point], men bara en inom ett visst intervall.
    /// `MAX` är den högsta giltiga kodpunkten som är en giltig [Unicode Scalar Value].
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () används i Unicode för att representera ett avkodningsfel.
    ///
    /// Det kan till exempel inträffa när ge-formade UTF-8 byte till [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Den version av [Unicode](http://www.unicode.org/) som Unicode-delarna av `char`-och `str`-metoderna bygger på.
    ///
    /// Nya versioner av Unicode släpps regelbundet och därefter uppdateras alla metoder i standardbiblioteket beroende på Unicode.
    /// Därför förändras beteendet hos vissa `char`-och `str`-metoder och värdet på denna konstant över tiden.
    /// Detta anses *inte* vara en brytande förändring.
    ///
    /// Versionsnummereringsschemat förklaras i [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Skapar en iterator över UTF-16-kodade kodpunkter i `iter`, och returnerar oparade surrogater som ``Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// En förlustavkodare kan erhållas genom att ersätta `Err`-resultat med ersättningstecken:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Konverterar en `u32` till en `char`.
    ///
    /// Observera att alla `char`s är giltiga [`u32`] s och kan gjutas till en med
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Det motsatta är dock inte sant: inte alla giltiga [`u32`] är giltiga`char`s.
    /// `from_u32()` returnerar `None` om ingången inte är ett giltigt värde för en `char`.
    ///
    /// För en osäker version av denna funktion som ignorerar dessa kontroller, se [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Returnerar `None` när ingången inte är en giltig `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Konverterar en `u32` till en `char` och ignorerar giltigheten.
    ///
    /// Observera att alla `char`s är giltiga [`u32`] s och kan gjutas till en med
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Det motsatta är dock inte sant: inte alla giltiga [`u32`] är giltiga`char`s.
    /// `from_u32_unchecked()` kommer att ignorera detta och blindt casta till `char`, eventuellt skapa en ogiltig.
    ///
    ///
    /// # Safety
    ///
    /// Denna funktion är osäker, eftersom den kan konstruera ogiltiga `char`-värden.
    ///
    /// För en säker version av denna funktion, se [`from_u32`]-funktionen.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // SÄKERHET: Säkerhetsavtalet måste upprätthållas av den som ringer.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Konverterar en siffra i en given radix till en `char`.
    ///
    /// En 'radix' här kallas ibland också en 'base'.
    /// En radix av två indikerar ett binärt tal, en radix av tio, decimal och en radix av sexton, hexadecimal, för att ge några gemensamma värden.
    ///
    /// Godtyckliga strålar stöds.
    ///
    /// `from_digit()` returnerar `None` om ingången inte är en siffra i den angivna radixen.
    ///
    /// # Panics
    ///
    /// Panics om det ges en radix större än 36.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Decimal 11 är en enda siffra i bas 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Återgår till `None` när ingången inte är en siffra:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Passerar en stor radix och orsakar en panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Kontrollerar om en `char` är en siffra i den angivna radixen.
    ///
    /// En 'radix' här kallas ibland också en 'base'.
    /// En radix av två indikerar ett binärt tal, en radix av tio, decimal och en radix av sexton, hexadecimal, för att ge några gemensamma värden.
    ///
    /// Godtyckliga strålar stöds.
    ///
    /// Jämfört med [`is_numeric()`] känner den här funktionen bara igen tecknen `0-9`, `a-z` och `A-Z`.
    ///
    /// 'Digit' definieras som endast följande tecken:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// För en mer omfattande förståelse av 'digit', se [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics om det ges en radix större än 36.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Passerar en stor radix och orsakar en panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Konverterar en `char` till en siffra i den angivna radixen.
    ///
    /// En 'radix' här kallas ibland också en 'base'.
    /// En radix av två indikerar ett binärt tal, en radix av tio, decimal och en radix av sexton, hexadecimal, för att ge några gemensamma värden.
    ///
    /// Godtyckliga strålar stöds.
    ///
    /// 'Digit' definieras som endast följande tecken:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Returnerar `None` om `char` inte hänvisar till en siffra i den angivna radixen.
    ///
    /// # Panics
    ///
    /// Panics om det ges en radix större än 36.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Att skicka ett icke-siffrigt resultat misslyckas:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Passerar en stor radix och orsakar en panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // koden delas upp här för att förbättra körningshastigheten för fall där `radix` är konstant och 10 eller mindre
        //
        let val = if likely(radix <= 10) {
            // Om inte en siffra skapas ett tal som är större än radix.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Returnerar en iterator som ger den hexadecimala Unicode-flykten för ett tecken som `char`s.
    ///
    /// Detta kommer att undkomma tecken med Rust-syntax för formen `\u{NNNNNN}` där `NNNNNN` är en hexadecimal representation.
    ///
    ///
    /// # Examples
    ///
    /// Som en iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Använda `println!` direkt:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Båda motsvarar:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Använda `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // eller-ing 1 säkerställer att för c==0 koden beräknar att en siffra ska skrivas ut och (som är densamma) undviker (31, 32) underflödet
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // index för den viktigaste hex-siffran
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// En utökad version av `escape_debug` som valfritt tillåter att släppa utökade Grapheme-kodpunkter.
    /// Detta gör att vi kan formatera tecken som icke-avståndsmärken bättre när de är i början av en sträng.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Returnerar en iterator som ger en karaktärs bokstavliga flyktkod som `char`s.
    ///
    /// Detta kommer att undkomma karaktärerna som liknar `Debug`-implementeringarna av `str` eller `char`.
    ///
    ///
    /// # Examples
    ///
    /// Som en iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Använda `println!` direkt:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Båda motsvarar:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Använda `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Returnerar en iterator som ger en karaktärs bokstavliga flyktkod som `char`s.
    ///
    /// Standardvalet väljs med en bias mot att producera bokstäver som är lagliga på en mängd olika språk, inklusive C++ 11 och liknande C-familjespråk.
    /// De exakta reglerna är:
    ///
    /// * Fliken rymdes som `\t`.
    /// * Vagnreturen ryms som `\r`.
    /// * Linjematning undgår som `\n`.
    /// * Enstaka offert släpptes som `\'`.
    /// * Dubbel offert undviks som `\"`.
    /// * Backslash undviks som `\\`.
    /// * Alla tecken i det 'utskrivbara ASCII'-området `0x20` .. `0x7e` inklusive undviks inte.
    /// * Alla andra tecken ges hexadecimala Unicode-räddningar;se [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Som en iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Använda `println!` direkt:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Båda motsvarar:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Använda `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Returnerar antalet byte som denna `char` skulle behöva om kodad i UTF-8.
    ///
    /// Antalet byte är alltid mellan 1 och 4 inklusive.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str`-typen garanterar att dess innehåll är UTF-8, och så kan vi jämföra den längd det skulle ta om varje kodpunkt representerades som en `char` vs i själva `&str`:
    ///
    ///
    /// ```
    /// // som tecken
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // båda kan representeras som tre byte
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // som en &str är dessa två kodade i UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // vi kan se att de tar sex byte totalt ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... precis som &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Returnerar antalet 16-bitars kodenheter som denna `char` skulle behöva om kodad i UTF-16.
    ///
    ///
    /// Se dokumentationen för [`len_utf8()`] för mer förklaring av detta koncept.
    /// Denna funktion är en spegel, men för UTF-16 istället för UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Kodar det här tecknet som UTF-8 i den tillhandahållna bytebufferten och returnerar sedan delens del av bufferten som innehåller det kodade tecknet.
    ///
    ///
    /// # Panics
    ///
    /// Panics om bufferten inte är tillräckligt stor.
    /// En buffert med längden fyra är tillräckligt stor för att koda alla `char`.
    ///
    /// # Examples
    ///
    /// I båda dessa exempel tar 'ß' två byte att koda.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// En buffert som är för liten:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // SÄKERHET: `char` är inte ett surrogat, så detta är giltigt UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Kodar det här tecknet som UTF-16 i den medföljande `u16`-bufferten och returnerar sedan delens del av bufferten som innehåller det kodade tecknet.
    ///
    ///
    /// # Panics
    ///
    /// Panics om bufferten inte är tillräckligt stor.
    /// En buffert med längd 2 är tillräckligt stor för att koda alla `char`.
    ///
    /// # Examples
    ///
    /// I båda dessa exempel tar '𝕊' två `u16`s att koda.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// En buffert som är för liten:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Returnerar `true` om denna `char` har `Alphabetic`-egenskapen.
    ///
    /// `Alphabetic` beskrivs i kapitel 4 (Karaktärsegenskaper) i [Unicode Standard] och specificeras i [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // kärlek är många saker, men den är inte alfabetisk
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Returnerar `true` om denna `char` har `Lowercase`-egenskapen.
    ///
    /// `Lowercase` beskrivs i kapitel 4 (Karaktärsegenskaper) i [Unicode Standard] och specificeras i [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // De olika kinesiska manus och skiljetecken har inte fall, och så:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Returnerar `true` om denna `char` har `Uppercase`-egenskapen.
    ///
    /// `Uppercase` beskrivs i kapitel 4 (Karaktärsegenskaper) i [Unicode Standard] och specificeras i [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // De olika kinesiska manus och skiljetecken har inte fall, och så:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Returnerar `true` om denna `char` har `White_Space`-egenskapen.
    ///
    /// `White_Space` specificeras i [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // ett icke-brytande utrymme
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Returnerar `true` om denna `char` uppfyller antingen [`is_alphabetic()`] eller [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Returnerar `true` om denna `char` har den allmänna kategorin för kontrollkoder.
    ///
    /// Kontrollkoder (kodpunkter med den allmänna kategorin `Cc`) beskrivs i kapitel 4 (Karaktärsegenskaper) på [Unicode Standard] och specificeras i [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// // U + 009C, STRINGTERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Returnerar `true` om denna `char` har `Grapheme_Extend`-egenskapen.
    ///
    /// `Grapheme_Extend` beskrivs i [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] och specificeras i [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Returnerar `true` om denna `char` har en av de allmänna kategorierna för siffror.
    ///
    /// De allmänna kategorierna för siffror (`Nd` för decimalsiffror, `Nl` för bokstavsliknande numeriska tecken och `No` för andra numeriska tecken) anges i [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Returnerar en iterator som ger gemenskapsmappningen av denna `char` som en eller flera
    /// `char`s.
    ///
    /// Om denna `char` inte har en gemenskapsmappning, ger iteratorn samma `char`.
    ///
    /// Om denna `char` har en en-till-en-gemenskapsmappning som ges av [Unicode Character Database][ucd] [`UnicodeData.txt`], ger iteratorn den `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Om denna `char` kräver särskilda överväganden (t.ex. flera "char"-er) ger iteratorn den "char" som ges av [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Denna operation utför en ovillkorlig kartläggning utan att skräddarsy.Det vill säga omvandlingen är oberoende av sammanhang och språk.
    ///
    /// I [Unicode Standard] diskuterar kapitel 4 (karaktärsegenskaper) fallkartläggning i allmänhet och kapitel 3 (Conformance) diskuterar standardalgoritmen för fallkonvertering.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Som en iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Använda `println!` direkt:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Båda motsvarar:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Använda `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Ibland är resultatet mer än en karaktär:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Tecken som inte har både stora och små bokstäver konverteras till sig själva.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Returnerar en iterator som ger den stora mappningen av denna `char` som en eller flera
    /// `char`s.
    ///
    /// Om denna `char` inte har en stor mappning ger iteratorn samma `char`.
    ///
    /// Om denna `char` har en en-till-en-mappning av versaler som ges av [Unicode Character Database][ucd] [`UnicodeData.txt`], ger iteratorn den `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Om denna `char` kräver särskilda överväganden (t.ex. flera "char"-er) ger iteratorn den "char" som ges av [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Denna operation utför en ovillkorlig kartläggning utan att skräddarsy.Det vill säga omvandlingen är oberoende av sammanhang och språk.
    ///
    /// I [Unicode Standard] diskuterar kapitel 4 (karaktärsegenskaper) fallkartläggning i allmänhet och kapitel 3 (Conformance) diskuterar standardalgoritmen för fallkonvertering.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Som en iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Använda `println!` direkt:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Båda motsvarar:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Använda `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Ibland är resultatet mer än en karaktär:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Tecken som inte har både stora och små bokstäver konverteras till sig själva.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Anmärkning om lokal
    ///
    /// På turkiska har motsvarigheten till 'i' på latin fem former istället för två:
    ///
    /// * 'Dotless': I/ı, ibland skriven ï
    /// * 'Dotted': I/i
    ///
    /// Observera att den små bokstaven 'i' är densamma som den latinska.Därför:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Värdet på `upper_i` här är beroende av språket i texten: om vi är i `en-US` borde det vara `"I"`, men om vi är i `tr_TR` borde det vara `"İ"`.
    /// `to_uppercase()` tar inte hänsyn till detta, och så:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// har flera språk.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Kontrollerar om värdet ligger inom ASCII-intervallet.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Gör en kopia av värdet i motsvarande versal för ASCII.
    ///
    /// ASCII-bokstäver 'a' till 'z' mappas till 'A' till 'Z', men icke-ASCII-bokstäver är oförändrade.
    ///
    /// Använd [`make_ascii_uppercase()`] för att versera värdet på plats.
    ///
    /// Använd [`to_uppercase()`] för att versera stora ASCII-tecken utöver icke-ASCII-tecken.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Gör en kopia av värdet i ASCII-gemener.
    ///
    /// ASCII-bokstäver 'A' till 'Z' mappas till 'a' till 'z', men icke-ASCII-bokstäver är oförändrade.
    ///
    /// Använd [`make_ascii_lowercase()`] för att sänka värdet på plats.
    ///
    /// Använd [`to_lowercase()`] om du vill ha små ASCII-tecken utöver icke-ASCII-tecken.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Kontrollerar att två värden är en ASCII-skiftlägeskänslig matchning.
    ///
    /// Motsvarar `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Konverterar den här typen till dess ASCII-versaler motsvarande på plats.
    ///
    /// ASCII-bokstäver 'a' till 'z' mappas till 'A' till 'Z', men icke-ASCII-bokstäver är oförändrade.
    ///
    /// Använd [`to_ascii_uppercase()`] för att returnera ett nytt uppskattat värde utan att ändra det befintliga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Konverterar den här typen till dess ASCII-gemener motsvarande på plats.
    ///
    /// ASCII-bokstäver 'A' till 'Z' mappas till 'a' till 'z', men icke-ASCII-bokstäver är oförändrade.
    ///
    /// Använd [`to_ascii_lowercase()`] för att returnera ett nytt lägre värde utan att ändra det befintliga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Kontrollerar om värdet är ett ASCII-alfabetiskt tecken:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', eller
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Kontrollerar om värdet är ett ASCII-versaltecken:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Kontrollerar om värdet är ett ASCII-gemener:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Kontrollerar om värdet är ett ASCII-alfanumeriskt tecken:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', eller
    /// - U + 0061 'a' ..=U + 007A 'z', eller
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Kontrollerar om värdet är en ASCII-decimal:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Kontrollerar om värdet är en ASCII-hexadecimal siffra:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', eller
    /// - U + 0041 'A' ..=U + 0046 'F', eller
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Kontrollerar om värdet är ett ASCII-skiljetecken:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, eller
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, eller
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, eller
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Kontrollerar om värdet är ett ASCII-grafiskt tecken:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Kontrollerar om värdet är ett ASCII-blankstegstecken:
    /// U + 0020 RYMD, U + 0009 HORISONTAL TAB, U + 000A LINJEMATNING, U + 000C FORMFODER, eller U + 000D RETURRETUR.
    ///
    /// Rust använder WhatWG Infra Standards [definition of ASCII whitespace][infra-aw].Det finns flera andra definitioner som används i stor utsträckning.
    /// [the POSIX locale][pct] inkluderar till exempel U + 000B VERTICAL TAB liksom alla ovanstående tecken, men-från samma specifikation-[standardregeln för "field splitting" i Bourne shell][bfs] beaktar *endast* SPACE, HORIZONTAL TAB och LINE FEED som blanksteg.
    ///
    ///
    /// Om du skriver ett program som bearbetar ett befintligt filformat, kontrollera vad formatets definition av blanksteg är innan du använder den här funktionen.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Kontrollerar om värdet är ett ASCII-kontrolltecken:
    /// U + 0000 NUL ..=U + 001F ENHETSSKILLARE, eller U + 007F RADERA.
    /// Observera att de flesta ASCII-blankstegstecken är kontrolltecken men SPACE inte.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Kodar ett råt u32-värde som UTF-8 i den tillhandahållna bytebufferten och returnerar sedan delskiktet av bufferten som innehåller det kodade tecknet.
///
///
/// Till skillnad från `char::encode_utf8` hanterar denna metod även kodpunkter i surrogatområdet.
/// (Att skapa en `char` i surrogatområdet är UB.) Resultatet är giltigt [generalized UTF-8] men inte giltigt UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics om bufferten inte är tillräckligt stor.
/// En buffert med längden fyra är tillräckligt stor för att koda alla `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Kodar ett råt u32-värde som UTF-16 i den medföljande `u16`-bufferten och returnerar sedan delens del av bufferten som innehåller det kodade tecknet.
///
///
/// Till skillnad från `char::encode_utf16` hanterar denna metod även kodpunkter i surrogatområdet.
/// (Att skapa en `char` i surrogatområdet är UB.)
///
/// # Panics
///
/// Panics om bufferten inte är tillräckligt stor.
/// En buffert med längd 2 är tillräckligt stor för att koda alla `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SÄKERHET: varje arm kontrollerar om det finns tillräckligt med bitar att skriva in
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP faller igenom
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Kompletterande flyg bryter in i surrogater.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}