#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Expanderar till antingen `$crate::panic::panic_2015` eller `$crate::panic::panic_2021` beroende på uppringarens utgåva.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Påstår att två uttryck är lika med varandra (med [`PartialEq`]).
///
/// På panic kommer detta makro att skriva ut uttrycksvärdena med deras felsökningsrepresentationer.
///
///
/// Liksom [`assert!`] har detta makro en andra form, där ett anpassat panic-meddelande kan tillhandahållas.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Återlåningen nedan är avsiktlig.
                    // Utan dem initialiseras stapelplatsen för lånet redan innan värdena jämförs, vilket leder till en märkbar avmattning.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Återlåningen nedan är avsiktlig.
                    // Utan dem initialiseras stapelplatsen för lånet redan innan värdena jämförs, vilket leder till en märkbar avmattning.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Påstår att två uttryck inte är lika med varandra (använder [`PartialEq`]).
///
/// På panic kommer detta makro att skriva ut uttrycksvärdena med deras felsökningsrepresentationer.
///
///
/// Liksom [`assert!`] har detta makro en andra form, där ett anpassat panic-meddelande kan tillhandahållas.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Återlåningen nedan är avsiktlig.
                    // Utan dem initialiseras stapelplatsen för lånet redan innan värdena jämförs, vilket leder till en märkbar avmattning.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Återlåningen nedan är avsiktlig.
                    // Utan dem initialiseras stapelplatsen för lånet redan innan värdena jämförs, vilket leder till en märkbar avmattning.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Påstår att ett booleskt uttryck är `true` vid körning.
///
/// Detta kommer att anropa [`panic!`]-makrot om det angivna uttrycket inte kan utvärderas till `true` vid körning.
///
/// Liksom [`assert!`] har detta makro också en andra version, där ett anpassat panic-meddelande kan tillhandahållas.
///
/// # Uses
///
/// Till skillnad från [`assert!`] är `debug_assert!`-uttalanden endast aktiverade i icke-optimerade byggnader som standard.
/// En optimerad version kör inte `debug_assert!`-satser såvida inte `-C debug-assertions` skickas till kompilatorn.
/// Detta gör `debug_assert!` användbart för kontroller som är för dyra för att vara närvarande i en release-version men som kan vara till hjälp under utvecklingen.
/// Resultatet av att expandera `debug_assert!` är alltid typkontrollerat.
///
/// Ett okontrollerat påstående gör det möjligt för ett program i inkonsekvent tillstånd att fortsätta, vilket kan få oväntade konsekvenser men inte inför osäkerhet så länge detta bara händer i säker kod.
///
/// Prestandakostnaden för påståenden är dock inte mätbar i allmänhet.
/// Ersättning av [`assert!`] med `debug_assert!` uppmuntras alltså endast efter noggrann profilering, och ännu viktigare, endast i säker kod!
///
/// # Examples
///
/// ```
/// // panic-meddelandet för dessa påståenden är det strängade värdet för det angivna uttrycket.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // en mycket enkel funktion
/// debug_assert!(some_expensive_computation());
///
/// // hävda med ett anpassat meddelande
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Påstår att två uttryck är lika med varandra.
///
/// På panic kommer detta makro att skriva ut uttrycksvärdena med deras felsökningsrepresentationer.
///
/// Till skillnad från [`assert_eq!`] är `debug_assert_eq!`-uttalanden endast aktiverade i icke-optimerade byggnader som standard.
/// En optimerad version kör inte `debug_assert_eq!`-satser såvida inte `-C debug-assertions` skickas till kompilatorn.
/// Detta gör `debug_assert_eq!` användbart för kontroller som är för dyra för att vara närvarande i en release-version men som kan vara till hjälp under utvecklingen.
///
/// Resultatet av att expandera `debug_assert_eq!` är alltid typkontrollerat.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Påstår att två uttryck inte är lika med varandra.
///
/// På panic kommer detta makro att skriva ut uttrycksvärdena med deras felsökningsrepresentationer.
///
/// Till skillnad från [`assert_ne!`] är `debug_assert_ne!`-uttalanden endast aktiverade i icke-optimerade byggnader som standard.
/// En optimerad version kör inte `debug_assert_ne!`-satser såvida inte `-C debug-assertions` skickas till kompilatorn.
/// Detta gör `debug_assert_ne!` användbart för kontroller som är för dyra för att vara närvarande i en release-version men kan vara till hjälp under utvecklingen.
///
/// Resultatet av att expandera `debug_assert_ne!` är alltid typkontrollerat.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Returnerar om det givna uttrycket matchar något av de givna mönstren.
///
/// Liksom i ett `match`-uttryck kan mönstret valfritt följas av `if` och ett skyddsuttryck som har tillgång till namn som är bundna av mönstret.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Packar upp ett resultat eller sprider dess fel.
///
/// `?`-operatören lades till för att ersätta `try!` och bör användas istället.
/// Dessutom är `try` ett reserverat ord i Rust 2018, så om du måste använda det måste du använda [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` matchar den angivna [`Result`].I fallet med `Ok`-varianten har uttrycket värdet på det inslagna värdet.
///
/// I fallet med `Err`-varianten hämtar det inre felet.`try!` utför sedan konvertering med `From`.
/// Detta ger automatisk konvertering mellan specialfel och mer generella.
/// Det resulterande felet returneras sedan omedelbart.
///
/// På grund av tidig retur kan `try!` endast användas i funktioner som returnerar [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Den föredragna metoden för att snabbt returnera fel
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Den tidigare metoden för att snabbt returnera fel
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Detta motsvarar:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Skriver formaterad data till en buffert.
///
/// Detta makro accepterar en 'writer', en formatsträng och en lista med argument.
/// Argument kommer att formateras enligt den angivna formatsträngen och resultatet skickas till författaren.
/// Författaren kan ha vilket värde som helst med en `write_fmt`-metod;i allmänhet kommer detta från en implementering av antingen [`fmt::Write`] eller [`io::Write`] trait.
/// Makrot returnerar vad som helst som `write_fmt`-metoden returnerar;vanligtvis en [`fmt::Result`] eller en [`io::Result`].
///
/// Se [`std::fmt`] för mer information om formatsträngens syntax.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// En modul kan importera både `std::fmt::Write` och `std::io::Write` och ringa `write!` på objekt som implementerar endera, eftersom objekt vanligtvis inte implementerar båda.
///
/// Modulen måste dock importera traits-kvalificerade så att deras namn inte strider mot:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // använder fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // använder io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Detta makro kan också användas i `no_std`-inställningar.
/// I en `no_std`-installation är du ansvarig för detaljerna om implementering av komponenterna.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Skriv formaterad data i en buffert med en ny rad bifogad.
///
/// På alla plattformar är den nya linjen enbart LINE FEED-karaktären (`\n`/`U+000A`) (inget ytterligare CARRIAGE RETURN (`\r`/`U+000D`).
///
/// Mer information finns i [`write!`].För information om formatsträngens syntax, se [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// En modul kan importera både `std::fmt::Write` och `std::io::Write` och ringa `write!` på objekt som implementerar endera, eftersom objekt vanligtvis inte implementerar båda.
/// Modulen måste dock importera traits-kvalificerade så att deras namn inte strider mot:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // använder fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // använder io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Indikerar oåtkomlig kod.
///
/// Det här är användbart när kompilatorn inte kan fastställa att någon kod inte kan nås.Till exempel:
///
/// * Matcha armarna med skyddsförhållandena.
/// * Slingor som dynamiskt avslutas.
/// * Iteratorer som dynamiskt avslutas.
///
/// Om bestämningen att koden inte kan nås visar sig vara felaktig avslutas programmet omedelbart med en [`panic!`].
///
/// Den osäkra motsvarigheten till detta makro är [`unreachable_unchecked`]-funktionen, vilket kommer att orsaka odefinierat beteende om koden nås.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Detta kommer alltid att [`panic!`].
///
/// # Examples
///
/// Matcharmar:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // kompilera fel om du kommenterar det
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // en av de fattigaste implementeringarna av x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Indikerar icke implementerad kod genom att panikera med ett meddelande om "not implemented".
///
/// Detta gör att din kod kan typkontrollera, vilket är användbart om du prototyper eller implementerar en trait som kräver flera metoder som du inte planerar att använda alla.
///
/// Skillnaden mellan `unimplemented!` och [`todo!`] är att medan `todo!` förmedlar en avsikt att implementera funktionaliteten senare och meddelandet är "not yet implemented", gör `unimplemented!` inga sådana påståenden.
/// Dess budskap är "not implemented".
/// Vissa IDE: er kommer också att markera 'todo!' S.
///
/// # Panics
///
/// Detta kommer alltid att [`panic!`] eftersom `unimplemented!` bara är en förkortning för `panic!` med ett fast, specifikt meddelande.
///
/// Liksom `panic!` har detta makro en andra form för att visa anpassade värden.
///
/// # Examples
///
/// Säg att vi har en trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Vi vill implementera `Foo` för 'MyStruct', men av någon anledning är det bara meningsfullt att implementera `bar()`-funktionen.
/// `baz()` och `qux()` måste fortfarande definieras i vår implementering av `Foo`, men vi kan använda `unimplemented!` i deras definitioner för att låta vår kod sammanställas.
///
/// Vi vill fortfarande att vårt program ska sluta köras om de icke implementerade metoderna uppnås.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Det är ingen mening att `baz` en `MyStruct`, så vi har ingen logik här alls.
/////
///         // Detta visar "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Vi har lite logik här, vi kan lägga till ett meddelande till unimplemented!för att visa vår utelämnande.
///         // Detta visar: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Indikerar oavslutad kod.
///
/// Detta kan vara användbart om du prototyper och bara vill ha din kodtypkontroll.
///
/// Skillnaden mellan [`unimplemented!`] och `todo!` är att medan `todo!` förmedlar en avsikt att implementera funktionaliteten senare och meddelandet är "not yet implemented", gör `unimplemented!` inga sådana påståenden.
/// Dess budskap är "not implemented".
/// Vissa IDE: er kommer också att markera 'todo!' S.
///
/// # Panics
///
/// Detta kommer alltid att [`panic!`].
///
/// # Examples
///
/// Här är ett exempel på någon pågående kod.Vi har en trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Vi vill implementera `Foo` på en av våra typer, men vi vill också arbeta med bara `bar()` först.För att vår kod ska kunna kompileras måste vi implementera `baz()` så att vi kan använda `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // genomförandet går här
///     }
///
///     fn baz(&self) {
///         // låt oss inte oroa oss för att implementera baz() för tillfället
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // vi använder inte ens baz(), så det är bra.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definitioner av inbyggda makron.
///
/// De flesta makroegenskaperna (stabilitet, synlighet etc.) är hämtade från källkoden här, med undantag av expansionsfunktioner som omvandlar makroingångar till utgångar, dessa funktioner tillhandahålls av kompilatorn.
///
///
pub(crate) mod builtin {

    /// Får sammanställning att misslyckas med det angivna felmeddelandet när det påträffas.
    ///
    /// Detta makro bör användas när en crate använder en villkorlig sammanställningsstrategi för att ge bättre felmeddelanden för felaktiga förhållanden.
    ///
    /// Det är kompileringsnivåformen för [`panic!`], men avger ett fel under *kompilering* snarare än vid *runtime*.
    ///
    /// # Examples
    ///
    /// Två sådana exempel är makron och `#[cfg]`-miljöer.
    ///
    /// Avsända bättre kompilatorfel om ett makro skickas ogiltiga värden.
    /// Utan den sista branch skulle kompilatorn fortfarande avge ett fel, men felmeddelandet nämner inte de två giltiga värdena.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Avsända kompileringsfel om en av ett antal funktioner inte är tillgänglig.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Konstruerar parametrar för andra strängformateringsmakron.
    ///
    /// Detta makro fungerar genom att ta en formateringssträng som innehåller `{}` för varje ytterligare argument som skickas.
    /// `format_args!` förbereder ytterligare parametrar för att säkerställa att utdata kan tolkas som en sträng och kanoniserar argumenten till en enda typ.
    /// Alla värden som implementerar [`Display`] trait kan skickas till `format_args!`, liksom alla [`Debug`]-implementeringar kan skickas till en `{:?}` i formateringssträngen.
    ///
    ///
    /// Detta makro ger ett värde av typen [`fmt::Arguments`].Detta värde kan skickas till makron i [`std::fmt`] för att utföra användbar omdirigering.
    /// Alla andra formateringsmakron ([`format!`], [`write!`], [`println!`], etc.) proxieras genom den här.
    /// `format_args!`, till skillnad från dess härledda makron undviker man högtilldelningar.
    ///
    /// Du kan använda [`fmt::Arguments`]-värdet som `format_args!` returnerar i `Debug`-och `Display`-sammanhang enligt nedan.
    /// Exemplet visar också att `Debug`-och `Display`-format till samma sak: den interpolerade formatsträngen i `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Mer information finns i dokumentationen i [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Samma som `format_args`, men lägger till en ny linje till slut.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Inspekterar en miljövariabel vid sammanställningstid.
    ///
    /// Detta makro utvidgas till värdet av den namngivna miljövariabeln vid sammanställningstid, vilket ger ett uttryck av typen `&'static str`.
    ///
    ///
    /// Om miljövariabeln inte är definierad kommer ett kompileringsfel att avges.
    /// Använd inte [`option_env!`]-makrot istället för att inte avge ett kompileringsfel.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Du kan anpassa felmeddelandet genom att skicka en sträng som den andra parametern:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Om miljövariabeln `documentation` inte är definierad får du följande fel:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inspekterar eventuellt en miljövariabel vid sammanställningstidpunkten.
    ///
    /// Om den namngivna miljövariabeln är närvarande vid kompileringstid kommer detta att expandera till ett uttryck av typen `Option<&'static str>` vars värde är `Some` av värdet för miljövariabeln.
    /// Om miljövariabeln inte finns kommer den att utvidgas till `None`.
    /// Se [`Option<T>`][Option] för mer information om den här typen.
    ///
    /// Ett kompileringsfel avges aldrig när du använder detta makro oavsett om miljövariabeln är närvarande eller inte.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Sammankopplar identifierare till en identifierare.
    ///
    /// Detta makro tar valfritt antal kommaseparerade identifierare och sammanfogar dem alla till en, vilket ger ett uttryck som är en ny identifierare.
    /// Observera att hygien gör det så att detta makro inte kan fånga lokala variabler.
    /// Som en allmän regel är makron endast tillåtna i artikel, uttalande eller uttrycksposition.
    /// Det betyder att även om du kan använda detta makro för att hänvisa till befintliga variabler, funktioner eller moduler etc kan du inte definiera ett nytt med det.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (new, fun, name) { }//kan inte användas på det här sättet!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Sammankopplar bokstäver till en statisk strängskiva.
    ///
    /// Detta makro tar valfritt antal kommaseparerade bokstäver, vilket ger ett uttryck av typen `&'static str` som representerar alla bokstäver som sammanfogas från vänster till höger.
    ///
    ///
    /// Heltals-och flytpunktsbokstavar strängas för att sammanfogas.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Expanderar till radnumret som det anropades på.
    ///
    /// Med [`column!`] och [`file!`] ger dessa makron felsökningsinformation för utvecklare om platsen i källan.
    ///
    /// Det utökade uttrycket har typ `u32` och är 1-baserat, så den första raden i varje fil utvärderas till 1, den andra till 2, etc.
    /// Detta överensstämmer med felmeddelanden från vanliga kompilatorer eller populära redaktörer.
    /// Den returnerade raden är *inte nödvändigtvis* linjen för `line!`-anropet i sig, utan snarare den första makroanropet som leder fram till anropet av `line!`-makrot.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Expanderar till kolumnnumret där den anropades.
    ///
    /// Med [`line!`] och [`file!`] ger dessa makron felsökningsinformation för utvecklare om platsen i källan.
    ///
    /// Det utökade uttrycket har typ `u32` och är 1-baserat, så den första kolumnen i varje rad utvärderas till 1, den andra till 2, etc.
    /// Detta överensstämmer med felmeddelanden från vanliga kompilatorer eller populära redaktörer.
    /// Den returnerade kolumnen är *inte nödvändigtvis* linjen i själva `column!`-anropet, utan snarare den första makroanropet som leder till anropet av `column!`-makrot.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Expanderar till filnamnet där den anropades.
    ///
    /// Med [`line!`] och [`column!`] ger dessa makron felsökningsinformation för utvecklare om platsen i källan.
    ///
    /// Det utökade uttrycket har typ `&'static str`, och den returnerade filen är inte anropet av själva `file!`-makrot, utan snarare den första makroanropet som leder fram till anropet av `file!`-makrot.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stärker dess argument.
    ///
    /// Detta makro ger ett uttryck av typen `&'static str` som är strängning av alla tokens som skickas till makrot.
    /// Inga begränsningar läggs på syntaxen för själva makroanropet.
    ///
    /// Observera att de utökade resultaten för ingången tokens kan förändras i future.Du bör vara försiktig om du litar på utdata.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Inkluderar en UTF-8-kodad fil som en sträng.
    ///
    /// Filen ligger relativt den aktuella filen (på samma sätt som hur moduler hittas).
    /// Den angivna vägen tolkas på ett plattformsspecifikt sätt vid sammanställningstid.
    /// Så till exempel skulle en anrop med en Windows-sökväg som innehåller bakåtstreck `\` inte kompileras korrekt på Unix.
    ///
    ///
    /// Detta makro ger ett uttryck av typen `&'static str` som är innehållet i filen.
    ///
    /// # Examples
    ///
    /// Antag att det finns två filer i samma katalog med följande innehåll:
    ///
    /// Fil 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fil 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Genom att kompilera 'main.rs' och köra den resulterande binära kommer "adiós" att skrivas ut.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inkluderar en fil som referens till en byte-array.
    ///
    /// Filen ligger relativt den aktuella filen (på samma sätt som hur moduler hittas).
    /// Den angivna vägen tolkas på ett plattformsspecifikt sätt vid sammanställningstid.
    /// Så till exempel skulle en anrop med en Windows-sökväg som innehåller bakåtstreck `\` inte kompileras korrekt på Unix.
    ///
    ///
    /// Detta makro ger ett uttryck av typen `&'static [u8; N]` som är innehållet i filen.
    ///
    /// # Examples
    ///
    /// Antag att det finns två filer i samma katalog med följande innehåll:
    ///
    /// Fil 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fil 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Genom att kompilera 'main.rs' och köra den resulterande binära kommer "adiós" att skrivas ut.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Expanderar till en sträng som representerar den aktuella modulvägen.
    ///
    /// Den aktuella modulsökvägen kan ses som en hierarki av moduler som leder tillbaka till crate root.
    /// Den första komponenten i den returnerade sökvägen är namnet på den crate som för närvarande kompileras.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Utvärderar booleska kombinationer av konfigurationsflaggor vid sammanställningstid.
    ///
    /// Förutom `#[cfg]`-attributet tillhandahålls detta makro för att möjliggöra boolesk uttrycksutvärdering av konfigurationsflaggor.
    /// Detta leder ofta till mindre duplicerad kod.
    ///
    /// Syntaxen som ges till detta makro är samma syntax som [`cfg`]-attributet.
    ///
    /// `cfg!`, till skillnad från `#[cfg]` tar inte bort någon kod och utvärderas bara till true eller false.
    /// Till exempel måste alla block i ett if/else-uttryck vara giltiga när `cfg!` används för tillståndet, oavsett vad `cfg!` utvärderar.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Tolkar en fil som ett uttryck eller ett objekt enligt sammanhanget.
    ///
    /// Filen ligger relativt den aktuella filen (på samma sätt som hur moduler hittas).Den angivna vägen tolkas på ett plattformsspecifikt sätt vid sammanställningstid.
    /// Så till exempel skulle en anrop med en Windows-sökväg som innehåller bakåtstreck `\` inte kompileras korrekt på Unix.
    ///
    /// Att använda detta makro är ofta en dålig idé, för om filen analyseras som ett uttryck kommer den att placeras i den omgivande koden ohygieniskt.
    /// Detta kan leda till att variabler eller funktioner skiljer sig från vad filen förväntade sig om det finns variabler eller funktioner som har samma namn i den aktuella filen.
    ///
    ///
    /// # Examples
    ///
    /// Antag att det finns två filer i samma katalog med följande innehåll:
    ///
    /// Fil 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Fil 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Genom att kompilera 'main.rs' och köra den resulterande binära kommer "🙈🙊🙉🙈🙊🙉" att skrivas ut.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Påstår att ett booleskt uttryck är `true` vid körning.
    ///
    /// Detta kommer att anropa [`panic!`]-makrot om det angivna uttrycket inte kan utvärderas till `true` vid körning.
    ///
    /// # Uses
    ///
    /// Påståenden kontrolleras alltid i både felsöknings-och release-versioner och kan inte inaktiveras.
    /// Se [`debug_assert!`] för påståenden som inte är aktiverade i versioner som standard.
    ///
    /// Osäker kod kan förlita sig på `assert!` för att genomdriva invarianter under körning som, om de bryts, kan leda till osäkerhet.
    ///
    /// Andra användningsfall av `assert!` inkluderar testning och tillämpning av körtidsinvarierare i säker kod (vars överträdelse inte kan leda till osäkerhet).
    ///
    ///
    /// # Anpassade meddelanden
    ///
    /// Detta makro har en andra form, där ett anpassat panic-meddelande kan tillhandahållas med eller utan argument för formatering.
    /// Se [`std::fmt`] för syntax för detta formulär.
    /// Uttryck som används som formatargument utvärderas endast om påståendet misslyckas.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // panic-meddelandet för dessa påståenden är det strängade värdet för det angivna uttrycket.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // en mycket enkel funktion
    ///
    /// assert!(some_computation());
    ///
    /// // hävda med ett anpassat meddelande
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Inbyggd montering.
    ///
    /// Läs [unstable book] för användning.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Inbyggd montering i LLVM-stil.
    ///
    /// Läs [unstable book] för användning.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Inbyggd montering på modulnivå.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Utskrifter skickade tokens till standardutmatningen.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Aktiverar eller inaktiverar spårningsfunktionalitet som används för felsökning av andra makron.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Attributmakro som används för att tillämpa härledningsmakron.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Attributmakro som tillämpas på en funktion för att göra det till ett enhetstest.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Attributmakro som tillämpas på en funktion för att göra det till ett riktmärketest.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// En implementeringsdetalj av `#[test]`-och `#[bench]`-makron.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Attributmakro tillämpas på en statisk för att registrera den som en global fördelare.
    ///
    /// Se även [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Behåller objektet som det används om den godkända sökvägen är tillgänglig och tar bort den annars.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Utökar alla `#[cfg]`-och `#[cfg_attr]`-attribut i kodfragmentet som den används på.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Instabil implementeringsdetalj för `rustc`-kompilatorn, använd inte.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Instabil implementeringsdetalj för `rustc`-kompilatorn, använd inte.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}