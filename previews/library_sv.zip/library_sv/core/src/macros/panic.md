Panics den aktuella tråden.

Detta gör att ett program kan avslutas omedelbart och ge feedback till den som ringer upp programmet.
`panic!` bör användas när ett program når ett oåtervinnbart tillstånd.

Detta makro är det perfekta sättet att hävda villkor i exempelkod och i tester.
`panic!` är nära knuten till `unwrap`-metoden i både [`Option`][ounwrap]-och [`Result`][runwrap]-enums.
Båda implementationerna anropar `panic!` när de är inställda på [`None`]-eller [`Err`]-varianter.

När du använder `panic!()` kan du ange en nyttolast för strängar som byggs med [`format!`]-syntaxen.
Den nyttolasten används när panic injiceras i den anropande Rust-tråden, vilket gör att tråden till panic helt.

Uppförandet av standard `std` hook, dvs.
koden som körs direkt efter att panic åberopats, är att skriva ut meddelandets nyttolast till `stderr` tillsammans med file/line/column-informationen för `panic!()`-samtalet.

Du kan åsidosätta panic hook med [`std::panic::set_hook()`].
Inuti hook kan en panic nås som en `&dyn Any + Send`, som innehåller antingen en `&str` eller `String` för vanliga `panic!()`-anrop.
Till panic med ett värde av en annan typ kan [`panic_any`] användas.

[`Result`] enum är ofta en bättre lösning för att återhämta sig från fel än att använda `panic!`-makrot.
Detta makro bör användas för att undvika att fortsätta använda felaktiga värden, till exempel från externa källor.
Detaljerad information om felhantering finns i [book].

Se även makrot [`compile_error!`] för att ta upp fel under kompileringen.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Aktuellt genomförande

Om huvudtråden panics kommer alla dina trådar att avslutas och programmet avslutas med koden `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





