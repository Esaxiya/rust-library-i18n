//! `Clone` trait för typer som inte kan "implicit kopieras".
//!
//! I Rust är några enkla typer "implicitly copyable" och när du tilldelar dem eller skickar dem som argument får mottagaren en kopia och lämnar originalvärdet på plats.
//! Dessa typer kräver inte allokering för att kopiera och har inte slutbehandlare (dvs. de innehåller inte ägda rutor eller implementerar [`Drop`]), så kompilatorn anser att de är billiga och säkra att kopiera.
//!
//! För andra typer måste kopior göras uttryckligen, enligt konvention som implementerar [`Clone`] trait och anropar [`clone`]-metoden.
//!
//! [`clone`]: Clone::clone
//!
//! Grundläggande användningsexempel:
//!
//! ```
//! let s = String::new(); // Strängtyp implementerar klon
//! let copy = s.clone(); // så att vi kan klona det
//! ```
//!
//! För att enkelt implementera Clone trait kan du också använda `#[derive(Clone)]`.Exempel:
//!
//! ```
//! #[derive(Clone)] // vi lägger till klonen trait till Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // och nu kan vi klona det!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// En vanlig trait för förmågan att uttryckligen duplicera ett objekt.
///
/// Skiljer sig från [`Copy`] genom att [`Copy`] är implicit och extremt billigt, medan `Clone` alltid är tydligt och kanske eller inte kan vara dyrt.
/// För att upprätthålla dessa egenskaper tillåter Rust dig inte att implementera [`Copy`] på nytt, men du kan återimplementera `Clone` och köra godtycklig kod.
///
/// Eftersom `Clone` är mer allmänt än [`Copy`] kan du automatiskt göra allt [`Copy`] också till `Clone`.
///
/// ## Derivable
///
/// Denna trait kan användas med `#[derive]` om alla fält är `Clone`.Den "härledda" implementeringen av [`Clone`] anropar [`clone`] på varje fält.
///
/// [`clone`]: Clone::clone
///
/// För en generisk struktur implementerar `#[derive]` `Clone` villkorligt genom att lägga till bunden `Clone` på generiska parametrar.
///
/// ```
/// // `derive` implementerar Clone for Reading<T>när T är klon.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Hur kan jag implementera `Clone`?
///
/// Typer som är [`Copy`] bör ha en trivial implementering av `Clone`.Mer formellt:
/// om `T: Copy`, `x: T` och `y: &T` är `let x = y.clone();` motsvarande `let x = *y;`.
/// Manuella implementeringar bör vara försiktiga för att upprätthålla denna invariant;osäker kod får dock inte lita på den för att säkerställa minnessäkerhet.
///
/// Ett exempel är en generisk struktur som innehåller en funktionspekare.I det här fallet kan inte implementeringen av `Clone` `härledas`, utan kan implementeras som:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Ytterligare implementatorer
///
/// Förutom [implementors listed below][impls] implementerar följande typer också `Clone`:
///
/// * Funktionsposttyper (dvs. de olika typerna som definierats för varje funktion)
/// * Funktionspekartyper (t.ex. `fn() -> i32`)
/// * Arraytyper, för alla storlekar, om artikeltypen också implementerar `Clone` (t.ex. `[i32; 123456]`)
/// * Tupeltyper, om varje komponent också implementerar `Clone` (t.ex. `()`, `(i32, bool)`)
/// * Stängningstyper, om de inte fångar något värde från miljön eller om alla sådana fångade värden implementerar `Clone` själva.
///   Observera att variabler som fångas av delad referens alltid implementerar `Clone` (även om referenten inte gör det), medan variabler som fångas av mutabel referens aldrig implementerar `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Returnerar en kopia av värdet.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str implementerar Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Utför kopieringstilldelning från `source`.
    ///
    /// `a.clone_from(&b)` motsvarar `a = b.clone()` i funktionalitet, men kan åsidosättas för att återanvända resurserna för `a` för att undvika onödiga tilldelningar.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Hämta makro som genererar en impl av trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): dessa strukturer används enbart av#[härleda] för att hävda att varje komponent av en typ implementerar klon eller kopia.
//
//
// Dessa strängar ska aldrig visas i användarkoden.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implementeringar av `Clone` för primitiva typer.
///
/// Implementeringar som inte kan beskrivas i Rust implementeras i `traits::SelectionContext::copy_clone_conditions()` i `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Delade referenser kan klonas, men muterbara referenser *kan inte*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Delade referenser kan klonas, men muterbara referenser *kan inte*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}