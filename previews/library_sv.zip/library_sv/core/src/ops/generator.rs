use crate::marker::Unpin;
use crate::pin::Pin;

/// Resultatet av en generatoråterupptagning.
///
/// Detta enum returneras från `Generator::resume`-metoden och indikerar möjliga returvärden för en generator.
/// För närvarande motsvarar detta antingen en upphängningspunkt (`Yielded`) eller en avslutningspunkt (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Generatorn avstängd med ett värde.
    ///
    /// Detta tillstånd indikerar att en generator har stängts av och motsvarar vanligtvis ett `yield`-uttalande.
    /// Värdet som tillhandahålls i denna variant motsvarar det uttryck som överförs till `yield` och tillåter generatorer att tillhandahålla ett värde varje gång de ger.
    ///
    ///
    Yielded(Y),

    /// Generatorn kompletterad med ett returvärde.
    ///
    /// Detta tillstånd indikerar att en generator har slutfört körningen med det angivna värdet.
    /// När en generator har returnerat `Complete` anses det vara ett programmeringsfel att ringa till `resume` igen.
    ///
    Complete(R),
}

/// trait implementerad av inbyggda generatortyper.
///
/// Generatorer, även kallade coroutines, är för närvarande en experimentell språkfunktion i Rust.
/// Tillagda i [RFC 2033]-generatorer är för närvarande avsedda att främst tillhandahålla ett byggsten för async/await-syntax men kommer sannolikt att sträcka sig till att också ge en ergonomisk definition för iteratorer och andra primitiva.
///
///
/// Syntaxen och semantiken för generatorer är instabil och kräver ytterligare RFC för stabilisering.Vid denna tidpunkt är dock syntaxen liknande:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Mer dokumentation om generatorer finns i den instabila boken.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Vilken typ av värde denna generator ger.
    ///
    /// Denna associerade typ motsvarar `yield`-uttrycket och de värden som får returneras varje gång en generator ger.
    ///
    /// Till exempel skulle en iterator-som-en-generator sannolikt ha denna typ som `T`, den typ som itereras över.
    ///
    type Yield;

    /// Den typ av värde som denna generator returnerar.
    ///
    /// Detta motsvarar typen som returneras från en generator antingen med ett `return`-uttalande eller implicit som det sista uttrycket för en generator bokstavligt.
    /// Till exempel skulle futures använda detta som `Result<T, E>` eftersom det representerar en färdig future.
    ///
    ///
    type Return;

    /// Återupptar körningen av denna generator.
    ///
    /// Den här funktionen återupptar körningen av generatorn eller startar körningen om den inte redan har gjort det.
    /// Detta samtal återgår till generatorns sista upphängningspunkt och återupptas från den senaste `yield`.
    /// Generatorn fortsätter att köra tills den antingen ger eller returnerar, vid vilken tidpunkt denna funktion kommer tillbaka.
    ///
    /// # Returvärde
    ///
    /// `GeneratorState`-enum som returneras från den här funktionen indikerar i vilket tillstånd generatorn befinner sig vid återkomst.
    /// Om `Yielded`-varianten returneras har generatorn nått en upphängningspunkt och ett värde har givits ut.
    /// Generatorer i detta tillstånd är tillgängliga för återupptagning vid ett senare tillfälle.
    ///
    /// Om `Complete` returneras är generatorn helt klar med det angivna värdet.Det är ogiltigt att generatorn återupptas igen.
    ///
    /// # Panics
    ///
    /// Denna funktion kan panic om den anropas efter att `Complete`-varianten har returnerats tidigare.
    /// Medan generatorbokstäver på språket garanteras att panic återupptas efter `Complete`, är det inte garanterat för alla implementeringar av `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}