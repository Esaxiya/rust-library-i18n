/// Används för oföränderliga derferensoperationer, som `*v`.
///
/// Förutom att användas för explicita dereferensoperationer med (unary) `*`-operatören i oföränderliga sammanhang, används `Deref` också implicit av kompilatorn under många omständigheter.
/// Denna mekanism kallas ['`Deref` coercion'][more].
/// I muterbara sammanhang används [`DerefMut`].
///
/// Genom att implementera `Deref` för smarta pekare blir det enkelt att komma åt data bakom dem, varför de implementerar `Deref`.
/// Å andra sidan utformades reglerna för `Deref` och [`DerefMut`] specifikt för att rymma smarta pekare.
/// På grund av detta bör **"Deref" endast implementeras för smarta pekare** för att undvika förvirring.
///
/// Av liknande skäl bör **denna trait aldrig misslyckas**.Fel under dereferenser kan vara extremt förvirrande när `Deref` åberopas implicit.
///
/// # Mer om `Deref` tvång
///
/// Om `T` implementerar `Deref<Target = U>` och `x` är ett värde av typen `T`:
///
/// * I oföränderliga sammanhang är `*x` (där `T` varken är en referens eller en rå pekare) ekvivalent med `* Deref::deref(&x)`.
/// * Värden av typen `&T` tvingas till värden av typen `&U`
/// * `T` implementerar implicit alla (immutable)-metoder av typen `U`.
///
/// För mer information, besök [the chapter in *The Rust Programming Language*][book] samt referensavsnitten om [the dereference operator][ref-deref-op], [method resolution] och [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// En struktur med ett enda fält som är tillgängligt genom att referera till strukturen.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Den resulterande typen efter dereferens.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Dereferenser värdet.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Används för muterbara operationer som hänvisar till, som i `*v = 1;`.
///
/// Förutom att den används för explicita derferensoperationer med (unary) `*`-operatören i muterbara sammanhang, används `DerefMut` också implicit av kompilatorn under många omständigheter.
/// Denna mekanism kallas ['`Deref` coercion'][more].
/// I oföränderliga sammanhang används [`Deref`].
///
/// Genom att implementera `DerefMut` för smarta pekare blir det enkelt att mutera data bakom dem, varför de implementerar `DerefMut`.
/// Å andra sidan utformades reglerna för [`Deref`] och `DerefMut` specifikt för att rymma smarta pekare.
/// På grund av detta bör **`DerefMut` endast implementeras för smarta pekare** för att undvika förvirring.
///
/// Av liknande skäl bör **denna trait aldrig misslyckas**.Fel under dereferenser kan vara extremt förvirrande när `DerefMut` åberopas implicit.
///
/// # Mer om `Deref` tvång
///
/// Om `T` implementerar `DerefMut<Target = U>` och `x` är ett värde av typen `T`:
///
/// * I förändrade sammanhang motsvarar `*x` (där `T` varken är en referens eller en rå pekare) motsvarande `* DerefMut::deref_mut(&mut x)`.
/// * Värden av typen `&mut T` tvingas till värden av typen `&mut U`
/// * `T` implementerar implicit alla (mutable)-metoder av typen `U`.
///
/// För mer information, besök [the chapter in *The Rust Programming Language*][book] samt referensavsnitten om [the dereference operator][ref-deref-op], [method resolution] och [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// En struktur med ett enda fält som kan modifieras genom att referera till strukturen.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Omvandlas omöjligt värdet.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Indikerar att en struct kan användas som metodmottagare utan `arbitrary_self_types`-funktionen.
///
/// Detta implementeras av stdlib-pekartyper som `Box<T>`, `Rc<T>`, `&T` och `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}