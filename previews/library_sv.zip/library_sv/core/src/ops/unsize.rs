use crate::marker::Unsize;

/// Trait som indikerar att det här är en pekare eller ett omslag för en där unsizing kan utföras på pointen.
///
/// Se [DST coercion RFC][dst-coerce] och [the nomicon entry on coercion][nomicon-coerce] för mer information.
///
/// För inbyggda pekartyper kommer pekare till `T` att tvingas till pekare till `U` om `T: Unsize<U>` genom att konvertera från en tunn pekare till en fettpekare.
///
/// För anpassade typer fungerar tvånget här genom att tvinga `Foo<T>` till `Foo<U>` förutsatt att det finns en impl. Av `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Ett sådant impl kan bara skrivas om `Foo<T>` bara har ett enda icke-fantomdatafält som involverar `T`.
/// Om fältet är `Bar<T>` måste en implementering av `CoerceUnsized<Bar<U>> for Bar<T>` finnas.
/// Tvingandet fungerar genom att tvinga `Bar<T>`-fältet till `Bar<U>` och fylla i resten av fälten från `Foo<T>` för att skapa en `Foo<U>`.
/// Detta kommer effektivt att borra ner till ett pekfält och tvinga det.
///
/// För smarta pekare implementerar du generellt `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, med en valfri `?Sized` bunden till själva `T`.
/// För omslagstyper som direkt bäddar in `T` som `Cell<T>` och `RefCell<T>` kan du direkt implementera `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Detta låter tvång av typer som `Cell<Box<T>>` fungera.
///
/// [`Unsize`][unsize] används för att markera typer som kan tvingas till sommartid om de ligger bakom pekare.Den implementeras automatiskt av kompilatorn.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * konst U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * konst U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *konst T->* konst U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Detta används för objektsäkerhet för att kontrollera att metodens mottagartyp kan skickas vidare.
///
/// Ett exempel på implementering av trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *konst T->* konst U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}