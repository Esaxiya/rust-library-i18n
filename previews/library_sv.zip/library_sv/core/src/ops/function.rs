/// Den version av samtalsoperatören som tar en oföränderlig mottagare.
///
/// Instanser av `Fn` kan anropas upprepade gånger utan att mutera tillstånd.
///
/// *Denna trait (`Fn`) ska inte förväxlas med [function pointers] (`fn`).*
///
/// `Fn` implementeras automatiskt av stängningar som endast tar oföränderliga referenser till fångade variabler eller inte fångar någonting alls, liksom (safe) [function pointers] (med vissa försiktighetsåtgärder, se deras dokumentation för mer information).
///
/// Dessutom, för alla typer av `F` som implementerar `Fn`, implementerar `&F` också `Fn`.
///
/// Eftersom både [`FnMut`] och [`FnOnce`] är superspår av `Fn`, kan alla instanser av `Fn` användas som en parameter där en [`FnMut`] eller [`FnOnce`] förväntas.
///
/// Använd `Fn` som en bunden när du vill acceptera en parameter av funktionsliknande typ och behöver ringa den upprepade gånger och utan att mutera tillstånd (t.ex. när du ringer till den samtidigt).
/// Om du inte behöver så strikta krav, använd [`FnMut`] eller [`FnOnce`] som gränser.
///
/// Se [chapter on closures in *The Rust Programming Language*][book] för mer information om detta ämne.
///
/// Observera också den speciella syntaxen för `Fn` traits (t.ex.
/// `Fn(usize, bool) -> använd storlek ').De som är intresserade av de tekniska detaljerna i detta kan hänvisa till [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Ringer en stängning
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Med hjälp av en `Fn`-parameter
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // så att regex kan lita på den `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Utför samtalsoperationen.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Den version av samtalsoperatören som tar en mutbar mottagare.
///
/// Instanser av `FnMut` kan anropas upprepade gånger och kan mutera tillståndet.
///
/// `FnMut` implementeras automatiskt av stängningar som tar muterbara referenser till fångade variabler, liksom alla typer som implementerar [`Fn`], t.ex. (safe) [function pointers] (eftersom `FnMut` är ett supertrait av [`Fn`]).
/// Dessutom, för alla typer av `F` som implementerar `FnMut`, implementerar `&mut F` också `FnMut`.
///
/// Eftersom [`FnOnce`] är en supertrait av `FnMut`, kan alla förekomster av `FnMut` användas där en [`FnOnce`] förväntas, och eftersom [`Fn`] är en underrubrik av `FnMut`, kan alla förekomster av [`Fn`] användas där `FnMut` förväntas.
///
/// Använd `FnMut` som en bunden när du vill acceptera en parameter av funktionsliknande typ och behöver ringa den upprepade gånger, samtidigt som den låter den mutera tillståndet.
/// Om du inte vill att parametern ska mutera tillstånd, använd [`Fn`] som en bunden;Om du inte behöver ringa upp det flera gånger, använd [`FnOnce`].
///
/// Se [chapter on closures in *The Rust Programming Language*][book] för mer information om detta ämne.
///
/// Observera också den speciella syntaxen för `Fn` traits (t.ex.
/// `Fn(usize, bool) -> använd storlek ').De som är intresserade av de tekniska detaljerna i detta kan hänvisa till [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Ringer till en föränderligt fångande stängning
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Med hjälp av en `FnMut`-parameter
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // så att regex kan lita på den `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Utför samtalsoperationen.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Versionen av samtalsoperatören som tar en motvärdemottagare.
///
/// Instanser av `FnOnce` kan anropas, men kanske inte kan anropas flera gånger.På grund av detta, om det enda som är känt om en typ är att den implementerar `FnOnce`, kan den bara anropas en gång.
///
/// `FnOnce` implementeras automatiskt av stängningar som kan konsumera fångade variabler, liksom alla typer som implementerar [`FnMut`], t.ex. (safe) [function pointers] (eftersom `FnOnce` är ett supertrait av [`FnMut`]).
///
///
/// Eftersom både [`Fn`] och [`FnMut`] är underdelar av `FnOnce` kan valfri förekomst av [`Fn`] eller [`FnMut`] användas där en `FnOnce` förväntas.
///
/// Använd `FnOnce` som en bunden när du vill acceptera en parameter av funktionsliknande typ och bara behöver ringa den en gång.
/// Om du behöver anropa parametern upprepade gånger, använd [`FnMut`] som en begränsning;Om du också behöver det för att inte mutera tillstånd, använd [`Fn`].
///
/// Se [chapter on closures in *The Rust Programming Language*][book] för mer information om detta ämne.
///
/// Observera också den speciella syntaxen för `Fn` traits (t.ex.
/// `Fn(usize, bool) -> använd storlek ').De som är intresserade av de tekniska detaljerna i detta kan hänvisa till [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Med hjälp av en `FnOnce`-parameter
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` förbrukar sina fångade variabler, så den kan inte köras mer än en gång.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Försök att åberopa `func()` igen kommer att orsaka ett `use of moved value`-fel för `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` kan inte längre åberopas vid denna tidpunkt
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // så att regex kan lita på den `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Den returnerade typen efter att samtalsoperatören används.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Utför samtalsoperationen.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}