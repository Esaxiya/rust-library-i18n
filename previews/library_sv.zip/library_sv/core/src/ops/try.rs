/// En trait för att anpassa beteendet hos `?`-operatören.
///
/// En typ som implementerar `Try` är en som har ett kanoniskt sätt att se den i termer av en success/failure-dikotomi.
/// Denna trait tillåter både extrahera dessa framgångs-eller misslyckande värden från en befintlig instans och skapa en ny instans från ett framgångs-eller misslyckandevärde.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Typen av detta värde när det betraktas som framgångsrikt.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Typen av detta värde när det betraktas som misslyckat.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Tillämpar "?"-operatören.En retur av `Ok(t)` innebär att körningen ska fortsätta normalt, och resultatet av `?` är värdet `t`.
    /// En retur av `Err(e)` betyder att körning ska branch till det innersta som omsluter `catch`, eller återvända från funktionen.
    ///
    /// Om ett `Err(e)`-resultat returneras kommer värdet `e` att vara "wrapped" i returtypen för det bifogade omfånget (som själv måste implementera `Try`).
    ///
    /// Specifikt returneras värdet `X::from_error(From::from(e))`, där `X` är returtypen för den inneslutande funktionen.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Slå in ett felvärde för att konstruera det sammansatta resultatet.
    /// Till exempel är `Result::Err(x)` och `Result::from_error(x)` ekvivalenta.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Slå in ett OK-värde för att konstruera det sammansatta resultatet.
    /// Till exempel är `Result::Ok(x)` och `Result::from_ok(x)` ekvivalenta.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}