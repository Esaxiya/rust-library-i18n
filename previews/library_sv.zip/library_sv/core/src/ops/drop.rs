/// Anpassad kod inom förstöraren.
///
/// När ett värde inte längre behövs kör Rust en "destructor" på det värdet.
/// Det vanligaste sättet att ett värde inte längre behövs är när det går utanför räckvidden.Destruktörer kan fortfarande köras under andra omständigheter, men vi kommer att fokusera på utrymme för exemplen här.
/// För att lära dig om några av de andra fallen, se [the reference] avsnitt om destruktörer.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Denna destruktör består av två komponenter:
/// - Ett samtal till `Drop::drop` för det värdet, om denna speciella `Drop` trait implementeras för sin typ.
/// - Den automatiskt genererade "drop glue" som rekursivt anropar destruktorerna för alla fält i detta värde.
///
/// Eftersom Rust automatiskt anropar destruktorerna för alla innehållna fält behöver du inte implementera `Drop` i de flesta fall.
/// Men det finns vissa fall där det är användbart, till exempel för typer som direkt hanterar en resurs.
/// Den resursen kan vara minne, det kan vara en filbeskrivare, det kan vara ett nätverksuttag.
/// När ett värde av den typen inte längre kommer att användas bör det "clean up" resursen genom att frigöra minnet eller stänga filen eller uttaget.
/// Detta är en destruktörs jobb och därför `Drop::drop` s jobb.
///
/// ## Examples
///
/// För att se förstörare i aktion, låt oss ta en titt på följande program:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust kommer först att ringa `Drop::drop` för `_x` och sedan för både `_x.one` och `_x.two`, vilket innebär att körning av detta kommer att skrivas ut
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Även om vi tar bort implementeringen av `Drop` för `HasTwoDrop` kallas fortfarande destruktörerna för dess fält.
/// Detta skulle resultera i
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Du kan inte ringa `Drop::drop` själv
///
/// Eftersom `Drop::drop` används för att städa upp ett värde kan det vara farligt att använda detta värde efter att metoden har anropats.
/// Eftersom `Drop::drop` inte tar äganderätten till dess ingång förhindrar Rust missbruk genom att inte tillåta dig att ringa `Drop::drop` direkt.
///
/// Med andra ord, om du försökte uttryckligen ringa `Drop::drop` i exemplet ovan, skulle du få ett kompilatorfel.
///
/// Om du uttryckligen vill ange förstöraren av ett värde kan [`mem::drop`] användas istället.
///
/// [`mem::drop`]: drop
///
/// ## Släpp order
///
/// Vilken av våra två `HasDrop` tappar dock först?För struts är det samma ordning som de deklareras: först `one`, sedan `two`.
/// Om du vill prova detta själv kan du ändra `HasDrop` ovan för att innehålla vissa data, som ett heltal, och sedan använda den i `println!` inuti `Drop`.
/// Detta beteende garanteras av språket.
///
/// Till skillnad från structs tappas lokala variabler i omvänd ordning:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Detta kommer att skrivas ut
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Se [the reference] för fullständiga regler.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` och `Drop` är exklusiva
///
/// Du kan inte implementera både [`Copy`] och `Drop` på samma typ.Typer som är `Copy` dupliceras implicit av kompilatorn, vilket gör det mycket svårt att förutsäga när och hur ofta förstörare kommer att köras.
///
/// Som sådan kan dessa typer inte ha destruktorer.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Utför förstöraren för den här typen.
    ///
    /// Denna metod kallas implicit när värdet går utanför räckvidden och kan inte anropas uttryckligen (detta är kompileringsfel [E0040]).
    /// Men [`mem::drop`]-funktionen i prelude kan användas för att anropa argumentets `Drop`-implementering.
    ///
    /// När den här metoden har anropats har `self` ännu inte delats ut.
    /// Det händer bara efter att metoden är över.
    /// Om detta inte var fallet skulle `self` vara en dinglande referens.
    ///
    /// # Panics
    ///
    /// Med tanke på att en [`panic!`] kommer att ringa `drop` när den avlindas kommer alla [`panic!`] i en `drop`-implementering sannolikt att avbrytas.
    ///
    /// Observera att även om detta panics anses värdet vara tappat;
    /// du får inte få `drop` att ringas upp igen.
    /// Detta hanteras normalt automatiskt av kompilatorn, men när du använder osäker kod kan det ibland inträffa oavsiktligt, särskilt när du använder [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}