use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// En minnesallokerare som kan registreras som standardbibliotekets standard genom `#[global_allocator]`-attributet.
///
/// Vissa av metoderna kräver att ett minnesblock *för närvarande tilldelas* via en allokerare.Detta innebär att:
///
/// * startadressen för det minnesblocket returnerades tidigare av ett tidigare samtal till en allokeringsmetod såsom `alloc` och
///
/// * minnesblocket har därefter inte omlokaliserats, där block omlokaliseras antingen genom att de skickas till en deallocation-metod såsom `dealloc` eller genom att skickas till en omallokeringsmetod som returnerar en icke-nollpekare.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait är en `unsafe` trait av flera anledningar och implementatorer måste se till att de följer dessa kontrakt:
///
/// * Det är odefinierat beteende om globala fördelare varva ner.Denna begränsning kan tas bort i future, men för närvarande kan en panic från någon av dessa funktioner leda till minnesosäkerhet.
///
/// * `Layout` frågor och beräkningar i allmänhet måste vara korrekta.Uppringare av denna trait får förlita sig på de kontrakt som definieras för varje metod, och genomförare måste se till att sådana kontrakt förblir sanna.
///
/// * Du kanske inte litar på att allokeringar faktiskt sker, även om det finns explicita högtilldelningar i källan.
/// Optimeraren kan upptäcka oanvända allokeringar som den antingen kan eliminera helt eller flytta till stacken och därmed aldrig åberopa fördelaren.
/// Optimeraren kan vidare anta att allokeringen är ofelbar, så kod som tidigare misslyckades på grund av allokeringsfel kan nu plötsligt fungera eftersom optimatorn arbetade kring behovet av en allokering.
/// Mer konkret är följande kodexempel osunt, oavsett om din anpassade fördelare tillåter att räkna hur många tilldelningar som har hänt.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Observera att de optimeringar som nämns ovan inte är den enda optimeringen som kan tillämpas.Du kan i allmänhet inte lita på att högtilldelningar sker om de kan tas bort utan att ändra programbeteende.
///   Oavsett om tilldelningar sker eller inte är inte en del av programmets beteende, även om det kan detekteras via en allokator som spårar tilldelningar genom att skriva ut eller på annat sätt har biverkningar.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Tilldela minne enligt beskrivningen av den givna `layout`.
    ///
    /// Returnerar en pekare till nyligen tilldelat minne eller null för att indikera allokeringsfel.
    ///
    /// # Safety
    ///
    /// Den här funktionen är osäker eftersom odefinierat beteende kan uppstå om den som ringer inte ser till att `layout` har en storlek som inte är noll.
    ///
    /// (Extrasubstrat kan ge mer specifika gränser för beteende, t.ex. garantera en vaktadress eller en nollpekare som svar på en begäran om tilldelning av nollstorlek.)
    ///
    /// Det tilldelade minnesblocket kan eller inte initialiseras.
    ///
    /// # Errors
    ///
    /// Att returnera en nollpekare indikerar att antingen minnet är uttömt eller att `layout` inte uppfyller denna allokerings storlek eller justeringsbegränsningar.
    ///
    /// Implementationer uppmuntras att återställa null vid minnesutmattning snarare än att avbryta, men detta är inte ett strikt krav.
    /// (Specifikt: det är *lagligt* att implementera denna trait ovanpå ett underliggande inbyggt tilldelningsbibliotek som avbryts vid minnesutmattning.)
    ///
    /// Kunder som vill avbryta beräkning som svar på ett allokeringsfel uppmanas att ringa [`handle_alloc_error`]-funktionen snarare än att direkt anropa `panic!` eller liknande.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Fördela minnesblocket vid den givna `ptr`-pekaren med den givna `layout`.
    ///
    /// # Safety
    ///
    /// Denna funktion är osäker eftersom odefinierat beteende kan uppstå om den som ringer inte säkerställer följande:
    ///
    ///
    /// * `ptr` måste beteckna ett minnesblock som för närvarande tilldelas via denna allokerare,
    ///
    /// * `layout` måste vara samma layout som användes för att allokera det minnesblocket.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Uppför sig som `alloc`, men ser också till att innehållet är noll innan det returneras.
    ///
    /// # Safety
    ///
    /// Den här funktionen är osäker av samma skäl som `alloc`.
    /// Emellertid garanteras det allokerade minnesblocket att initieras.
    ///
    /// # Errors
    ///
    /// Att returnera en nollpekare indikerar att antingen minnet är uttömt eller att `layout` inte uppfyller fördelarens storlek eller inriktningsbegränsningar, precis som i `alloc`.
    ///
    /// Kunder som vill avbryta beräkning som svar på ett allokeringsfel uppmanas att ringa [`handle_alloc_error`]-funktionen snarare än att direkt anropa `panic!` eller liknande.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SÄKERHET: Säkerhetsavtalet för `alloc` måste upprätthållas av den som ringer.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SÄKERHET: när tilldelningen lyckades, regionen från `ptr`
            // i storlek `size` är garanterat giltig för skrivningar.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Krymp eller växa ett minnesblock till den givna `new_size`.
    /// Blocket beskrivs av den givna `ptr`-pekaren och `layout`.
    ///
    /// Om detta returnerar en icke-nollpekare har äganderätten till det minnesblock som `ptr` refererar till överförts till denna allokerare.
    /// Minnet kan eller kanske inte har omlokaliserats och bör betraktas som oanvändbart (såvida det naturligtvis inte överfördes tillbaka till den som ringer igen via returvärdet för denna metod).
    /// Det nya minnesblocket tilldelas med `layout`, men med `size` uppdaterat till `new_size`.
    /// Den här nya layouten bör användas när du placerar det nya minnesblocket med `dealloc`.
    /// Området `0..min(layout.size(), new_size) `för det nya minnesblocket har garanterat samma värden som det ursprungliga blocket.
    ///
    /// Om den här metoden returnerar noll har äganderätten till minnesblocket inte överförts till denna fördelare och innehållet i minnesblocket är oförändrat.
    ///
    /// # Safety
    ///
    /// Denna funktion är osäker eftersom odefinierat beteende kan uppstå om den som ringer inte säkerställer följande:
    ///
    /// * `ptr` måste för närvarande tilldelas via denna fördelare,
    ///
    /// * `layout` måste vara samma layout som användes för att allokera det minnesblocket,
    ///
    /// * `new_size` måste vara större än noll.
    ///
    /// * `new_size`, när den avrundas till närmaste multipel av `layout.align()`, får den inte rinna över (dvs. det avrundade värdet måste vara mindre än `usize::MAX`).
    ///
    /// (Extrasubstrat kan ge mer specifika gränser för beteende, t.ex. garantera en vaktadress eller en nollpekare som svar på en begäran om tilldelning av nollstorlek.)
    ///
    /// # Errors
    ///
    /// Returnerar null om den nya layouten inte uppfyller begränsningarna för tilldelningens storlek och justering, eller om omfördelningen annars misslyckas.
    ///
    /// Implementationer uppmuntras att återställa noll på minnesutmattning snarare än att få panik eller avbryta, men detta är inte ett strikt krav.
    /// (Specifikt: det är *lagligt* att implementera denna trait ovanpå ett underliggande inbyggt tilldelningsbibliotek som avbryts vid minnesutmattning.)
    ///
    /// Kunder som vill avbryta beräkning som svar på ett omfördelningsfel uppmanas att ringa [`handle_alloc_error`]-funktionen snarare än att direkt anropa `panic!` eller liknande.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SÄKERHET: den som ringer måste se till att `new_size` inte flödar över.
        // `layout.align()` kommer från en `Layout` och är därmed garanterad giltig.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SÄKERHET: den som ringer måste se till att `new_layout` är större än noll.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SÄKERHET: det tidigare tilldelade blocket kan inte överlappa det nyligen tilldelade blocket.
            // Säkerhetsavtalet för `dealloc` måste upprätthållas av den som ringer.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}