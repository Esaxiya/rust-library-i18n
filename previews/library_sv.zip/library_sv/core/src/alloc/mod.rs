//! API för minnesallokering

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError`-felet indikerar ett allokeringsfel som kan bero på resursutmattning eller på något fel när de angivna inmatningsargumenten kombineras med den här allokeraren.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (vi behöver detta för nedströmsimplement av trait-fel)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// En implementering av `Allocator` kan allokera, växa, krympa och distribuera godtyckliga datablock som beskrivs via [`Layout`][].
///
/// `Allocator` är utformad för att implementeras på ZST, referenser eller smarta pekare eftersom det inte går att flytta en allokerare som `MyAlloc([u8; N])` utan att pekarna uppdateras till det tilldelade minnet.
///
/// Till skillnad från [`GlobalAlloc`][] är tilldelningar utan storlek i `Allocator` tillåtna.
/// Om en underliggande fördelare inte stöder detta (som jemalloc) eller returnerar en nollpekare (t.ex. `libc::malloc`), måste detta fångas av implementeringen.
///
/// ### För närvarande tilldelat minne
///
/// Vissa av metoderna kräver att ett minnesblock *för närvarande tilldelas* via en allokerare.Detta innebär att:
///
/// * startadressen för det minnesblocket returnerades tidigare av [`allocate`], [`grow`] eller [`shrink`], och
///
/// * minnesblocket har inte därefter omlokaliserats, där block antingen omlokaliseras direkt genom att de skickas till [`deallocate`] eller ändras genom att de skickas till [`grow`] eller [`shrink`] som returnerar `Ok`.
///
/// Om `grow` eller `shrink` har returnerat `Err` förblir den passerade pekaren giltig.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Minnesmontering
///
/// Några av metoderna kräver att en layout *passar* ett minnesblock.
/// Vad det betyder för en layout till "fit" betyder ett minnesblock (eller motsvarande för ett minnesblock till "fit" en layout) att följande villkor måste gälla:
///
/// * Blocket måste tilldelas med samma inriktning som [`layout.align()`], och
///
/// * Den medföljande [`layout.size()`] måste ligga inom intervallet `min ..= max`, där:
///   - `min` är storleken på den layout som senast användes för att allokera blocket, och
///   - `max` är den senaste faktiska storleken som returneras från [`allocate`], [`grow`] eller [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Minnesblock som returneras från en allokerare måste peka på giltigt minne och behålla sin giltighet tills förekomsten och alla dess kloner tappas,
///
/// * kloning eller flyttning av allokeringen får inte ogiltiga minnesblock som returneras från denna allokerare.En klonad fördelare måste bete sig som samma fördelare, och
///
/// * vilken pekare som helst till ett minnesblock som är [*currently allocated*] kan skickas till vilken som helst annan metod för allokeraren.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Försök att fördela ett minnesblock.
    ///
    /// Efter framgång returnerar en [`NonNull<[u8]>`][NonNull] som uppfyller `layout` storleks-och justeringsgarantier.
    ///
    /// Det returnerade blocket kan ha en större storlek än vad som anges av `layout.size()` och kanske eller kanske inte har initierat innehållet.
    ///
    /// # Errors
    ///
    /// Återgå till `Err` indikerar att antingen minnet är slut eller `layout` inte uppfyller fördelarens storlek eller inriktningsbegränsningar.
    ///
    /// Implementationer uppmuntras att returnera `Err` vid minnesutmattning snarare än att få panik eller avbryta, men detta är inte ett strikt krav.
    /// (Specifikt: det är *lagligt* att implementera denna trait ovanpå ett underliggande inbyggt tilldelningsbibliotek som avbryts vid minnesutmattning.)
    ///
    /// Kunder som vill avbryta beräkning som svar på ett allokeringsfel uppmanas att ringa [`handle_alloc_error`]-funktionen snarare än att direkt anropa `panic!` eller liknande.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Uppför sig som `allocate`, men ser också till att det returnerade minnet initialiseras noll.
    ///
    /// # Errors
    ///
    /// Återgå till `Err` indikerar att antingen minnet är slut eller `layout` inte uppfyller fördelarens storlek eller inriktningsbegränsningar.
    ///
    /// Implementationer uppmuntras att returnera `Err` vid minnesutmattning snarare än att få panik eller avbryta, men detta är inte ett strikt krav.
    /// (Specifikt: det är *lagligt* att implementera denna trait ovanpå ett underliggande inbyggt tilldelningsbibliotek som avbryts vid minnesutmattning.)
    ///
    /// Kunder som vill avbryta beräkning som svar på ett allokeringsfel uppmanas att ringa [`handle_alloc_error`]-funktionen snarare än att direkt anropa `panic!` eller liknande.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SÄKERHET: `alloc` returnerar ett giltigt minnesblock
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Omplacerar minnet som `ptr` refererar till.
    ///
    /// # Safety
    ///
    /// * `ptr` måste beteckna ett minnesblock [*currently allocated*] via denna allokerare, och
    /// * `layout` måste [*fit*] det minnesblocket.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Försök att förlänga minnesblocket.
    ///
    /// Returnerar en ny [`NonNull<[u8]>`][NonNull] som innehåller en pekare och den faktiska storleken på det tilldelade minnet.Pekaren är lämplig för lagring av data som beskrivs av `new_layout`.
    /// För att åstadkomma detta kan fördelaren förlänga den tilldelning som `ptr` refererar till för att passa den nya layouten.
    ///
    /// Om detta returnerar `Ok`, har äganderätten till det minnesblock som refereras av `ptr` överförts till denna allokerare.
    /// Minnet kanske eller inte har frigjorts och bör betraktas som oanvändbart om det inte överfördes tillbaka till den som ringer igen via returvärdet för denna metod.
    ///
    /// Om den här metoden returnerar `Err` har äganderätten till minnesblocket inte överförts till denna fördelare och innehållet i minnesblocket är oförändrat.
    ///
    /// # Safety
    ///
    /// * `ptr` måste beteckna ett minnesblock [*currently allocated*] via denna allokerare.
    /// * `old_layout` måste [*fit*] det minnesblocket (`new_layout`-argumentet behöver inte passa det.).
    /// * `new_layout.size()` måste vara större än eller lika med `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Returnerar `Err` om den nya layouten inte uppfyller fördelarens storlek och justeringsbegränsningar för allokeraren, eller om växande på annat sätt misslyckas.
    ///
    /// Implementationer uppmuntras att returnera `Err` vid minnesutmattning snarare än att få panik eller avbryta, men detta är inte ett strikt krav.
    /// (Specifikt: det är *lagligt* att implementera denna trait ovanpå ett underliggande inbyggt tilldelningsbibliotek som avbryts vid minnesutmattning.)
    ///
    /// Kunder som vill avbryta beräkning som svar på ett allokeringsfel uppmanas att ringa [`handle_alloc_error`]-funktionen snarare än att direkt anropa `panic!` eller liknande.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SÄKERHET: eftersom `new_layout.size()` måste vara större än eller lika med
        // `old_layout.size()`, både den gamla och den nya minnestilldelningen är giltig för läsningar och skrivningar för `old_layout.size()` byte.
        // Eftersom den gamla tilldelningen ännu inte var omplacerad kan den inte överlappa `new_ptr`.
        // Således är samtalet till `copy_nonoverlapping` säkert.
        // Säkerhetsavtalet för `dealloc` måste upprätthållas av den som ringer.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Uppför sig som `grow`, men ser också till att det nya innehållet sätts till noll innan det returneras.
    ///
    /// Minnesblocket innehåller följande innehåll efter ett lyckat samtal till
    /// `grow_zeroed`:
    ///   * Byte `0..old_layout.size()` bevaras från den ursprungliga tilldelningen.
    ///   * Bytes `old_layout.size()..old_size` kommer antingen att bevaras eller nollställas, beroende på allokeringsimplementeringen.
    ///   `old_size` avser storleken på minnesblocket före `grow_zeroed`-samtalet, som kan vara större än den storlek som ursprungligen begärdes när det tilldelades.
    ///   * Byte `old_size..new_size` nollställs.`new_size` avser storleken på minnesblocket som returneras av `grow_zeroed`-samtalet.
    ///
    /// # Safety
    ///
    /// * `ptr` måste beteckna ett minnesblock [*currently allocated*] via denna allokerare.
    /// * `old_layout` måste [*fit*] det minnesblocket (`new_layout`-argumentet behöver inte passa det.).
    /// * `new_layout.size()` måste vara större än eller lika med `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Returnerar `Err` om den nya layouten inte uppfyller fördelarens storlek och justeringsbegränsningar för allokeraren, eller om växande på annat sätt misslyckas.
    ///
    /// Implementationer uppmuntras att returnera `Err` vid minnesutmattning snarare än att få panik eller avbryta, men detta är inte ett strikt krav.
    /// (Specifikt: det är *lagligt* att implementera denna trait ovanpå ett underliggande inbyggt tilldelningsbibliotek som avbryts vid minnesutmattning.)
    ///
    /// Kunder som vill avbryta beräkning som svar på ett allokeringsfel uppmanas att ringa [`handle_alloc_error`]-funktionen snarare än att direkt anropa `panic!` eller liknande.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SÄKERHET: eftersom `new_layout.size()` måste vara större än eller lika med
        // `old_layout.size()`, både den gamla och den nya minnestilldelningen är giltig för läsningar och skrivningar för `old_layout.size()` byte.
        // Eftersom den gamla tilldelningen ännu inte var omplacerad kan den inte överlappa `new_ptr`.
        // Således är samtalet till `copy_nonoverlapping` säkert.
        // Säkerhetsavtalet för `dealloc` måste upprätthållas av den som ringer.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Försök att krympa minnesblocket.
    ///
    /// Returnerar en ny [`NonNull<[u8]>`][NonNull] som innehåller en pekare och den faktiska storleken på det tilldelade minnet.Pekaren är lämplig för lagring av data som beskrivs av `new_layout`.
    /// För att åstadkomma detta kan fördelaren krympa den tilldelning som `ptr` refererar till för att passa den nya layouten.
    ///
    /// Om detta returnerar `Ok`, har äganderätten till det minnesblock som refereras av `ptr` överförts till denna allokerare.
    /// Minnet kanske eller inte har frigjorts och bör betraktas som oanvändbart om det inte överfördes tillbaka till den som ringer igen via returvärdet för denna metod.
    ///
    /// Om den här metoden returnerar `Err` har äganderätten till minnesblocket inte överförts till denna fördelare och innehållet i minnesblocket är oförändrat.
    ///
    /// # Safety
    ///
    /// * `ptr` måste beteckna ett minnesblock [*currently allocated*] via denna allokerare.
    /// * `old_layout` måste [*fit*] det minnesblocket (`new_layout`-argumentet behöver inte passa det.).
    /// * `new_layout.size()` måste vara mindre än eller lika med `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Returnerar `Err` om den nya layouten inte uppfyller fördelarens storlek och justeringsbegränsningar för allokeraren, eller om krympning annars misslyckas.
    ///
    /// Implementationer uppmuntras att returnera `Err` vid minnesutmattning snarare än att få panik eller avbryta, men detta är inte ett strikt krav.
    /// (Specifikt: det är *lagligt* att implementera denna trait ovanpå ett underliggande inbyggt tilldelningsbibliotek som avbryts vid minnesutmattning.)
    ///
    /// Kunder som vill avbryta beräkning som svar på ett allokeringsfel uppmanas att ringa [`handle_alloc_error`]-funktionen snarare än att direkt anropa `panic!` eller liknande.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SÄKERHET: eftersom `new_layout.size()` måste vara lägre än eller lika med
        // `old_layout.size()`, både den gamla och den nya minnestilldelningen är giltig för läsningar och skrivningar för `new_layout.size()` byte.
        // Eftersom den gamla tilldelningen ännu inte var omplacerad kan den inte överlappa `new_ptr`.
        // Således är samtalet till `copy_nonoverlapping` säkert.
        // Säkerhetsavtalet för `dealloc` måste upprätthållas av den som ringer.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Skapar en "by reference"-adapter för denna förekomst av `Allocator`.
    ///
    /// Den returnerade adaptern implementerar också `Allocator` och lånar helt enkelt den här.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SÄKERHET: Säkerhetsavtalet måste upprätthållas av den som ringer
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SÄKERHET: Säkerhetsavtalet måste upprätthållas av den som ringer
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SÄKERHET: Säkerhetsavtalet måste upprätthållas av den som ringer
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SÄKERHET: Säkerhetsavtalet måste upprätthållas av den som ringer
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}