use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Medan den här funktionen används på ett ställe och dess implementering kan anges, gjorde tidigare försök att göra det rustc långsammare:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Layout av ett minnesblock.
///
/// En instans av `Layout` beskriver en viss minneslayout.
/// Du bygger en `Layout` upp som en ingång för att ge till en fördelare.
///
/// Alla layouter har en tillhörande storlek och en power-of-two-inriktning.
///
/// (Observera att layouter *inte* krävs för att ha en storlek som inte är noll, även om `GlobalAlloc` kräver att alla minnesförfrågningar inte är noll i storlek.
/// En uppringare måste antingen se till att villkor som detta är uppfyllda, använda specifika tilldelare med lösare krav eller använda det mildare `Allocator`-gränssnittet.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // storleken på det begärda minnesblocket, mätt i byte.
    size_: usize,

    // justering av det begärda minnesblocket, mätt i byte.
    // vi säkerställer att detta alltid är en power-of-two, eftersom API: er som `posix_memalign` kräver det och det är en rimlig begränsning att införa Layout-konstruktörer.
    //
    //
    // (Vi kräver emellertid inte analogt `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Konstruerar en `Layout` från en given `size` och `align` eller returnerar `LayoutError` om något av följande villkor inte uppfylls:
    ///
    /// * `align` får inte vara noll,
    ///
    /// * `align` måste vara en kraft av två,
    ///
    /// * `size`, när den avrundas till närmaste multipel av `align`, får den inte rinna över (dvs. det avrundade värdet måste vara mindre än eller lika med `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (power-of-two innebär align!=0.)

        // Avrundad storlek är:
        //   size_rounded_up=(size + align, 1)&! (align, 1);
        //
        // Vi vet uppifrån att justera!=0.
        // Om läggning (justering, 1) inte överflödar, kommer det att gå bra att avrunda uppåt.
        //
        // Omvänt kommer&-masking med! (Align, 1) att subtrahera endast bitar av låg ordning.
        // Således om överflöde inträffar med summan kan&-mask inte subtrahera tillräckligt för att ångra det överflödet.
        //
        //
        // Ovanstående innebär att det är nödvändigt och tillräckligt att kontrollera summeringsflöde.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SÄKERHET: villkoren för `from_size_align_unchecked` har varit
        // kontrolleras ovan.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Skapar en layout, förbi alla kontroller.
    ///
    /// # Safety
    ///
    /// Denna funktion är osäker eftersom den inte verifierar förutsättningarna från [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SÄKERHET: den som ringer måste se till att `align` är större än noll.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Minsta storlek i byte för ett minnesblock i denna layout.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Minsta bytejustering för ett minnesblock i denna layout.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Konstruerar en `Layout` som är lämplig för att hålla ett värde av typen `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SÄKERHET: inriktningen garanteras av Rust att vara en kraft av två och
        // kombinationen storlek + justering kommer garanterat att passa i vårt adressutrymme.
        // Som ett resultat använd den okontrollerade konstruktören här för att undvika att infoga kod som panics om den inte är optimerad tillräckligt.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Producerar layout som beskriver en post som kan användas för att allokera stödstruktur för `T` (som kan vara en trait eller annan osorterad typ som en skiva).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SÄKERHET: se motiv i `new` för varför detta använder den osäkra varianten
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Producerar layout som beskriver en post som kan användas för att allokera stödstruktur för `T` (som kan vara en trait eller annan osorterad typ som en skiva).
    ///
    /// # Safety
    ///
    /// Denna funktion är endast säker att ringa om följande villkor gäller:
    ///
    /// - Om `T` är `Sized` är den här funktionen alltid säker att ringa.
    /// - Om den osorterade svansen på `T` är:
    ///     - en [slice], så måste skivsvansens längd vara ett intialiserat heltal och storleken på *hela värdet*(dynamisk svanslängd + prefix för statisk storlek) måste passa in i `isize`.
    ///     - en [trait object] måste vtabeldelen av pekaren peka på en giltig vtabell för typen `T` som förvärvats av en osäker koersion och storleken på *hela värdet*(dynamisk svanslängd + prefix för statiskt storlek) måste passa in i `isize`.
    ///
    ///     - en (unstable) [extern type], då är den här funktionen alltid säker att ringa, men kan panic eller på annat sätt returnera fel värde, eftersom den externa typens layout inte är känd.
    ///     Detta är samma beteende som [`Layout::for_value`] på en referens till en extern svans.
    ///     - annars är det konservativt inte tillåtet att anropa denna funktion.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SÄKERHET: vi överför förutsättningarna för dessa funktioner till den som ringer
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SÄKERHET: se motiv i `new` för varför detta använder den osäkra varianten
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Skapar en `NonNull` som är dinglande men väl anpassad för denna layout.
    ///
    /// Observera att pekarens värde potentiellt kan representera en giltig pekare, vilket innebär att detta inte får användas som ett "not yet initialized"-sentinelvärde.
    /// Typer som lat tilldelas måste spåra initialisering på annat sätt.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SÄKERHET: inriktning garanteras vara noll
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Skapar en layout som beskriver posten som kan innehålla ett värde på samma layout som `self`, men som också är anpassad till `align` (uppmätt i byte).
    ///
    ///
    /// Om `self` redan uppfyller den föreskrivna inriktningen returnerar du `self`.
    ///
    /// Observera att den här metoden inte lägger till någon stoppning i den totala storleken, oavsett om den returnerade layouten har en annan inriktning.
    /// Med andra ord, om `K` har storlek 16, kommer `K.align_to(32)`*fortfarande* att ha storlek 16.
    ///
    /// Returnerar ett fel om kombinationen av `self.size()` och den angivna `align` bryter mot villkoren i [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Returnerar mängden stoppning som vi måste infoga efter `self` för att säkerställa att följande adress uppfyller `align` (uppmätt i byte).
    ///
    /// till exempel, om `self.size()` är 9, returnerar `self.padding_needed_for(4)` 3, eftersom det är det minsta antalet byte av vaddering som krävs för att få en 4-inriktad adress (förutsatt att motsvarande minnesblock börjar vid en 4-inriktad adress).
    ///
    ///
    /// Returvärdet för denna funktion har ingen betydelse om `align` inte är en power-of-two.
    ///
    /// Observera att nyttan av det returnerade värdet kräver att `align` är mindre än eller lika med inriktningen av startadressen för hela det tilldelade minnesblocket.Ett sätt att tillfredsställa denna begränsning är att säkerställa `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Avrundat värde är:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // och sedan returnerar vi vadderingsskillnaden: `len_rounded_up - len`.
        //
        // Vi använder modulär aritmetik hela tiden:
        //
        // 1. align är garanterat> 0, så align, 1 är alltid giltig.
        //
        // 2.
        // `len + align - 1` kan överflödas med högst `align - 1`, så&-mask med `!(align - 1)` säkerställer att `len_rounded_up` i sig själv är 0 vid överflöde.
        //
        //    Således ger den returnerade stoppningen, när den läggs till `len`, 0, vilket triviellt uppfyller inriktningen `align`.
        //
        // (Naturligtvis bör försök att allokera minnesblock vars storlek och stoppning överflödar på ovanstående sätt få allokeraren att ge ett fel ändå.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Skapar en layout genom att avrunda storleken på denna layout till en multipel av layoutens inriktning.
    ///
    ///
    /// Detta motsvarar att lägga till resultatet av `padding_needed_for` till layoutens nuvarande storlek.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Detta kan inte rinna över.Citat från invarianten i Layout:
        // > `size`, när den avrundas till närmaste multipel av `align`,
        // > får inte rinna över (dvs. det rundade värdet måste vara mindre än
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Skapar en layout som beskriver posten för `n`-instanser av `self`, med en lämplig mängd stoppning mellan varje för att säkerställa att varje instans får sin önskade storlek och justering.
    /// Efter framgång returneras `(k, offs)` där `k` är layouten för arrayen och `offs` är avståndet mellan början på varje element i arrayen.
    ///
    /// Vid aritmetisk överflöd, returnerar `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Detta kan inte rinna över.Citat från invarianten i Layout:
        // > `size`, när den avrundas till närmaste multipel av `align`,
        // > får inte rinna över (dvs. det rundade värdet måste vara mindre än
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SÄKERHET: self.align är redan känt för att vara giltigt och alloc_size har varit
        // vadderad redan.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Skapar en layout som beskriver posten för `self` följt av `next`, inklusive eventuell vaddering för att säkerställa att `next` kommer att justeras ordentligt, men *ingen efterföljande stoppning*.
    ///
    /// För att matcha C-representationslayout `repr(C)`, bör du ringa `pad_to_align` efter att du har utvidgat layouten med alla fält.
    /// (Det finns inget sätt att matcha standard Rust-representationslayouten `repr(Rust)`, as it is unspecified.)
    ///
    /// Observera att inriktningen för den resulterande layouten är maximal för `self` och `next`, för att säkerställa inriktning av båda delarna.
    ///
    /// Returnerar `Ok((k, offset))`, där `k` är layout för den sammanhängande posten och `offset` är den relativa platsen, i byte, för början på `next` inbäddad i den sammanhängande posten (förutsatt att själva posten börjar vid förskjutning 0).
    ///
    ///
    /// Vid aritmetisk överflöd, returnerar `LayoutError`.
    ///
    /// # Examples
    ///
    /// För att beräkna layouten för en `#[repr(C)]`-struktur och förskjutningarna av fälten från dess fälts layouter:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Kom ihåg att slutföra med `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // testa att det fungerar
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Skapar en layout som beskriver posten för `n`-instanser av `self`, utan vaddering mellan varje instans.
    ///
    /// Observera att `repeat_packed`, till skillnad från `repeat`, inte garanterar att de upprepade förekomsterna av `self` kommer att justeras ordentligt, även om en given instans av `self` är korrekt justerad.
    /// Med andra ord, om den layout som returneras av `repeat_packed` används för att allokera en matris, är det inte garanterat att alla element i matrisen kommer att justeras ordentligt.
    ///
    /// Vid aritmetisk överflöd, returnerar `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Skapar en layout som beskriver posten för `self` följt av `next` utan ytterligare stoppning mellan de två.
    /// Eftersom ingen stoppning är infogad är inriktningen av `next` irrelevant och ingår inte alls alls * i den resulterande layouten.
    ///
    ///
    /// Vid aritmetisk överflöd, returnerar `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Skapar en layout som beskriver posten för en `[T; n]`.
    ///
    /// Vid aritmetisk överflöd, returnerar `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Parametrarna som ges till `Layout::from_size_align` eller någon annan `Layout`-konstruktör uppfyller inte dess dokumenterade begränsningar.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (vi behöver detta för nedströmsimplement av trait-fel)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}