#![stable(feature = "core_hint", since = "1.27.0")]

//! Tips till kompilatorn som påverkar hur koden ska emitteras eller optimeras.
//! Tips kan vara kompileringstid eller körtid.

use crate::intrinsics;

/// Informerar kompilatorn att denna punkt i koden inte kan nås, vilket möjliggör ytterligare optimeringar.
///
/// # Safety
///
/// Att nå denna funktion är helt *odefinierat beteende*(UB).I synnerhet antar kompilatorn att all UB aldrig får ske, och därför kommer att eliminera alla grenar som når ett samtal till `unreachable_unchecked()`.
///
/// Liksom alla fall av UB, om detta antagande visar sig vara fel, dvs. att `unreachable_unchecked()`-samtalet faktiskt kan nås bland alla möjliga kontrollflöden, kommer kompilatorn att använda fel optimeringsstrategi och kan ibland till och med skada till synes orelaterad kod, vilket orsakar svår-att felsöka problem.
///
///
/// Använd endast den här funktionen när du kan bevisa att koden aldrig kommer att ringa den.
/// Annars kan du överväga att använda [`unreachable!`]-makrot, vilket inte tillåter optimeringar men panic när det körs.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` är alltid positivt (inte noll), därför kommer `checked_div` aldrig att returnera `None`.
/////
///     // Därför är det andra branch inte tillgängligt.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SÄKERHET: säkerhetskontraktet för `intrinsics::unreachable` måste
    // upprätthållas av den som ringer.
    unsafe { intrinsics::unreachable() }
}

/// Sänder ut en maskininstruktion för att signalera processorn att den körs i en upptagen-vänta snurrslinga ("snurrlås").
///
/// Vid mottagning av centrifugeringssignalen kan processorn optimera sitt beteende genom att t.ex. spara energi eller byta hyper-trådar.
///
/// Denna funktion skiljer sig från [`thread::yield_now`] som direkt ger systemets schemaläggare, medan `spin_loop` inte interagerar med operativsystemet.
///
/// Ett vanligt användningsfall för `spin_loop` är att implementera begränsad optimistisk snurrning i en CAS-slinga i synkroniseringsprimitiv.
/// För att undvika problem som prioritetsinversion rekommenderas det starkt att centrifugeringsslingan avslutas efter en begränsad mängd iterationer och en lämplig blockerande syscall görs.
///
///
/// **Obs**: På plattformar som inte stöder mottagning av spin-loop-tips gör den här funktionen ingenting alls.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Ett delat atomvärde som trådar kommer att använda för att samordna
/// let live = Arc::new(AtomicBool::new(false));
///
/// // I en bakgrundstråd sätter vi så småningom värdet
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Gör lite arbete och gör sedan värdet levande
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Tillbaka på vår nuvarande tråd väntar vi på att värdet ska ställas in
/// while !live.load(Ordering::Acquire) {
///     // Snurrslingan är en ledtråd till CPU: n att vi väntar, men förmodligen inte så länge
/////
///     hint::spin_loop();
/// }
///
/// // Värdet är nu inställt
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SÄKERHET: `cfg` attr säkerställer att vi bara utför detta på x86-mål.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SÄKERHET: `cfg` attr säkerställer att vi bara utför detta på x86_64-mål.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SÄKERHET: `cfg` attr säkerställer att vi bara utför detta på aarch64-mål.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SÄKERHET: `cfg` attr säkerställer att vi bara utför detta på armmål
            // med stöd för v6-funktionen.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// En identitetsfunktion som *__ antyder __* till kompilatorn för att vara maximalt pessimistisk om vad `black_box` kan göra.
///
/// Till skillnad från [`std::convert::identity`] uppmuntras en Rust-kompilator att anta att `black_box` kan använda `dummy` på något möjligt giltigt sätt som Rust-koden tillåts utan att införa odefinierat beteende i anropskoden.
///
/// Den här egenskapen gör `black_box` användbart för att skriva kod där vissa optimeringar inte önskas, till exempel riktmärken.
///
/// Observera dock att `black_box` endast tillhandahålls (och endast kan tillhandahållas) på "best-effort"-basis.I vilken utsträckning det kan blockera optimeringar kan variera beroende på vilken plattform och kodgen-backend som används.
/// Program kan inte förlita sig på `black_box` för *riktighet* på något sätt.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Vi måste "use" argumentera på något sätt LLVM kan inte introspektera, och på mål som stöder det kan vi vanligtvis utnyttja integrerad montering för att göra detta.
    // LLVMs tolkning av inbyggd montering är att det är, ja, en svart låda.
    // Detta är inte den största implementeringen eftersom det förmodligen deoptimerar mer än vi vill, men det är hittills tillräckligt bra.
    //
    //

    #[cfg(not(miri))] // Detta är bara en ledtråd, så det är bra att hoppa över i Miri.
    // SÄKERHET: den inbyggda enheten är en no-op.
    unsafe {
        // FIXME: Kan inte använda `asm!` eftersom den inte stöder MIPS och andra arkitekturer.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}