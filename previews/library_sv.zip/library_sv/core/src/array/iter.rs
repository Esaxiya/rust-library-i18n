//! Definierar `IntoIter`-ägd iterator för matriser.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// En [array] iterator av värde.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Det här är den grupp som vi itererar över.
    ///
    /// Element med index `i` där `alive.start <= i < alive.end` inte har givits ännu och är giltiga matrisposter.
    /// Element med index `i < alive.start` eller `i >= alive.end` har redan givits och får inte nås längre!Dessa döda element kan till och med vara i ett helt oinitialiserat tillstånd!
    ///
    ///
    /// Så invarianterna är:
    /// - `data[alive]` lever (dvs. innehåller giltiga element)
    /// - `data[..alive.start]` och `data[alive.end..]` är döda (dvs. elementen har redan lästs och får inte beröras längre!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Elementen i `data` som inte har givits ännu.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Skapar en ny iterator över den givna `array`.
    ///
    /// *Obs*: den här metoden kan avskaffas i future, efter [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Typ av `value` är en `i32` här istället för `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SÄKERHET: Omvandlingen här är faktiskt säker.Dokumenten för `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` garanteras ha samma storlek och inriktning
        // > som `T`.
        //
        // Dokumenten visar till och med en transmute från en array av `MaybeUninit<T>` till en array av `T`.
        //
        //
        // Med det uppfyller denna initialisering invarianterna.

        // FIXME(LukasKalbertodt): faktiskt använda `mem::transmute` här, när det fungerar med const generics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Fram till dess kan vi använda `mem::transmute_copy` för att skapa en bitvis kopia som en annan typ, sedan glömma `array` så att den inte tappas.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Returnerar en oföränderlig del av alla element som inte har givits ännu.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SÄKERHET: Vi vet att alla element inom `alive` har initialiserats ordentligt.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Returnerar en muterbar del av alla element som inte har givits ännu.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SÄKERHET: Vi vet att alla element inom `alive` har initialiserats ordentligt.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Få nästa index framifrån.
        //
        // Att öka `alive.start` med 1 bibehåller invarianten angående `alive`.
        // På grund av denna förändring är den levande zonen under en kort tid inte längre `data[alive]` utan `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Läs elementet från matrisen.
            // SÄKERHET: `idx` är ett index i den tidigare "alive"-regionen i
            // array.Att läsa detta element betyder att `data[idx]` betraktas som död nu (dvs rör inte).
            // Eftersom `idx` var början på den levande zonen är den levande zonen nu `data[alive]` igen och återställer alla invarianter.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Få nästa index bakifrån.
        //
        // Att minska `alive.end` med 1 bibehåller invarianten angående `alive`.
        // På grund av denna förändring är den levande zonen under en kort tid inte längre `data[alive]` utan `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Läs elementet från matrisen.
            // SÄKERHET: `idx` är ett index i den tidigare "alive"-regionen i
            // array.Att läsa detta element betyder att `data[idx]` betraktas som död nu (dvs rör inte).
            // Eftersom `idx` var slutet på den levande zonen, är den levande zonen nu `data[alive]` igen och återställer alla invarianter.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SÄKERHET: Detta är säkert: `as_mut_slice` returnerar exakt underskivan
        // av element som inte har flyttats ut ännu och som återstår att tappa.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Kommer aldrig att flöda på grund av invarianten `alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Iteratorn rapporterar verkligen rätt längd.
// Antalet "alive"-element (som fortfarande kommer att ges) är längden på intervallet `alive`.
// Detta intervall minskas i längd i antingen `next` eller `next_back`.
// Det minskas alltid med 1 i dessa metoder, men bara om `Some(_)` returneras.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Obs, vi behöver inte riktigt matcha exakt samma levande intervall, så vi kan bara klona till offset 0 oavsett var `self` är.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Klona alla levande element.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Skriv en klon i den nya matrisen och uppdatera sedan dess levande intervall.
            // Om vi klonar panics, släpper vi tidigare objekt korrekt.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Skriv bara ut de element som ännu inte givits: vi kan inte längre få åtkomst till de givna elementen.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}