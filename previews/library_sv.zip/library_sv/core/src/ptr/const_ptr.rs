use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Returnerar `true` om pekaren är noll.
    ///
    /// Observera att osorterade typer har många möjliga nollpekare, eftersom endast rådatapekaren beaktas, inte deras längd, vtabell etc.
    /// Därför kan två pekare som är noll fortfarande inte jämföra med varandra.
    ///
    /// ## Beteende under konst utvärdering
    ///
    /// När den här funktionen används under konst utvärdering kan den returnera `false` för pekare som visar sig vara noll vid körning.
    /// När en pekare till något minne förskjuts utanför dess gränser på ett sådant sätt att den resulterande pekaren är noll, kommer funktionen fortfarande att returnera `false`.
    ///
    /// Det finns inget sätt för CTFE att veta minnets absoluta position, så vi kan inte säga om pekaren är noll eller inte.
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Jämför via en gjutning till en tunn pekare, så feta pekare överväger bara sin "data"-del för nullitet.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Castar till en pekare av annan typ.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Sönderdela en (eventuellt bred) pekare till är adress-och metadatakomponenter.
    ///
    /// Pekaren kan senare rekonstrueras med [`from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Returnerar `None` om pekaren är noll eller annars returnerar en delad referens till värdet som slås in i `Some`.Om värdet kan vara oinitialiserat måste [`as_uninit_ref`] användas istället.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// När du anropar den här metoden måste du se till att *antingen* pekaren är NULL *eller* att allt detta är sant:
    ///
    /// * Pekaren måste vara rätt inriktad.
    ///
    /// * Det måste vara "dereferencable" i den mening som definieras i [the module documentation].
    ///
    /// * Pekaren måste peka på en initialiserad förekomst av `T`.
    ///
    /// * Du måste tillämpa Rust s aliasing-regler, eftersom den returnerade livstiden `'a` väljs godtyckligt och inte nödvändigtvis återspeglar den faktiska livslängden för data.
    ///   I synnerhet under den här livstiden får minnet som pekaren pekar på inte muteras (utom i `UnsafeCell`).
    ///
    /// Detta gäller även om resultatet av denna metod är oanvänd!
    /// (Delen om att initialiseras är ännu inte helt beslutad, men tills det är det enda säkra tillvägagångssättet är att se till att de verkligen initialiseras.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Null-okontrollerad version
    ///
    /// Om du är säker på att pekaren aldrig kan vara noll och letar efter någon form av `as_ref_unchecked` som returnerar `&T` istället för `Option<&T>`, vet du att du kan referera pekaren direkt.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SÄKERHET: den som ringer måste garantera att `self` är giltig
        // som referens om den inte är null.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Returnerar `None` om pekaren är noll eller annars returnerar en delad referens till värdet som slås in i `Some`.
    /// Till skillnad från [`as_ref`] kräver detta inte att värdet måste initialiseras.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// När du anropar den här metoden måste du se till att *antingen* pekaren är NULL *eller* att allt detta är sant:
    ///
    /// * Pekaren måste vara rätt inriktad.
    ///
    /// * Det måste vara "dereferencable" i den mening som definieras i [the module documentation].
    ///
    /// * Du måste tillämpa Rust s aliasing-regler, eftersom den returnerade livstiden `'a` väljs godtyckligt och inte nödvändigtvis återspeglar den faktiska livslängden för data.
    ///
    ///   I synnerhet under den här livstiden får minnet som pekaren pekar på inte muteras (utom i `UnsafeCell`).
    ///
    /// Detta gäller även om resultatet av denna metod är oanvänd!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SÄKERHET: den som ringer måste garantera att `self` uppfyller alla
        // krav på en referens.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Beräknar förskjutningen från en pekare.
    ///
    /// `count` är i enheter av T;t.ex. representerar en `count` av 3 en pekarkompensation av `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Om något av följande villkor bryts är resultatet odefinierat beteende:
    ///
    /// * Både start-och resulterande pekare måste vara antingen i gränser eller en byte efter slutet av samma tilldelade objekt.
    /// Observera att i Rust betraktas varje (stack-allocated)-variabel som ett separat tilldelat objekt.
    ///
    /// * Den beräknade förskjutningen,**i byte**, kan inte översvämma en `isize`.
    ///
    /// * Förskjutningen i gränser kan inte förlita sig på "wrapping around" adressutrymmet.Det vill säga den oändliga precisionssumman,**i byte**, måste passa in i en storlek.
    ///
    /// Kompilatorn och standardbiblioteket försöker generellt se till att allokeringar aldrig når en storlek där en förskjutning är ett problem.
    /// Till exempel säkerställer `Vec` och `Box` att de aldrig tilldelar mer än `isize::MAX` byte, så `vec.as_ptr().add(vec.len())` är alltid säker.
    ///
    /// De flesta plattformar kan i grunden inte ens konstruera en sådan fördelning.
    /// Till exempel kan ingen känd 64-bitarsplattform någonsin betjäna en begäran om 2 <sup>63</sup> byte på grund av sidtabellbegränsningar eller uppdelning av adressutrymmet.
    /// Vissa 32-bitars och 16-bitars plattformar kan dock framgångsrikt betjäna en begäran om mer än `isize::MAX` byte med saker som tillägg för fysisk adress.
    ///
    /// Som sådant kan minne som erhållits direkt från allokatorer eller minneskartade filer * vara för stort för att hantera den här funktionen.
    ///
    /// Överväg att använda [`wrapping_offset`] istället om dessa begränsningar är svåra att tillfredsställa.
    /// Den enda fördelen med denna metod är att den möjliggör mer aggressiva kompilatoroptimeringar.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `offset`.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Beräknar förskjutningen från en pekare med hjälp av inslagningsaritmetik.
    ///
    /// `count` är i enheter av T;t.ex. representerar en `count` av 3 en pekarkompensation av `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Den här åtgärden i sig är alltid säker, men det är inte att använda den resulterande pekaren.
    ///
    /// Den resulterande pekaren förblir ansluten till samma tilldelade objekt som `self` pekar på.
    /// Det kan *inte* användas för att komma åt ett annat tilldelat objekt.Observera att i Rust betraktas varje (stack-allocated)-variabel som ett separat tilldelat objekt.
    ///
    /// Med andra ord gör `let z = x.wrapping_offset((y as isize) - (x as isize))`*inte*`z` samma som `y` även om vi antar att `T` har storlek `1` och det inte finns något överflöde: `z` är fortfarande kopplat till objektet `x` är kopplat till, och därmed hänvisas det till odefinierat beteende såvida inte `x` och `y` pekar in i samma tilldelade objekt.
    ///
    /// Jämfört med [`offset`] fördröjer denna metod i princip kravet på att hålla sig inom samma tilldelade objekt: [`offset`] är omedelbart odefinierat beteende när objektgränserna passeras;`wrapping_offset` producerar en pekare men leder ändå till odefinierat beteende om en pekare härleds när den ligger utanför gränserna för objektet den är fäst vid.
    /// [`offset`] kan optimeras bättre och är därför att föredra i prestandakänslig kod.
    ///
    /// Den fördröjda kontrollen tar endast hänsyn till värdet på pekaren som hänfördes till, inte de mellanliggande värdena som användes under beräkningen av det slutliga resultatet.
    /// Till exempel är `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` alltid samma som `x`.Med andra ord är det tillåtet att lämna det tilldelade objektet och sedan mata in det senare.
    ///
    /// Om du behöver korsa objektgränser, kasta pekaren till ett heltal och gör aritmetiken där.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// // Iterera med en rå pekare i steg om två element
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Denna slinga skriver ut "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SÄKERHET: `arith_offset`-inneboende har inga förutsättningar att anropa.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Beräknar avståndet mellan två pekare.Det returnerade värdet är i enheter av T: avståndet i byte divideras med `mem::size_of::<T>()`.
    ///
    /// Denna funktion är den inversa av [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Om något av följande villkor bryts är resultatet odefinierat beteende:
    ///
    /// * Både start-och andra pekare måste vara antingen i gränser eller en byte efter slutet av samma tilldelade objekt.
    /// Observera att i Rust betraktas varje (stack-allocated)-variabel som ett separat tilldelat objekt.
    ///
    /// * Båda pekarna måste vara *härledda från* en pekare till samma objekt.
    ///   (Se nedan för ett exempel.)
    ///
    /// * Avståndet mellan pekarna i byte måste vara en exakt multipel av storleken på `T`.
    ///
    /// * Avståndet mellan pekarna,**i byte**, kan inte överskrida en `isize`.
    ///
    /// * Avståndet inom gränserna kan inte förlita sig på "wrapping around" adressutrymmet.
    ///
    /// Rust-typerna är aldrig större än `isize::MAX` och Rust-allokeringar lindas aldrig runt adressutrymmet, så två pekare inom något värde av Rust-typ `T` uppfyller alltid de två sista villkoren.
    ///
    /// Standardbiblioteket säkerställer också i allmänhet att tilldelningar aldrig når en storlek där en förskjutning är ett problem.
    /// Till exempel säkerställer `Vec` och `Box` att de aldrig tilldelar mer än `isize::MAX` byte, så `ptr_into_vec.offset_from(vec.as_ptr())` uppfyller alltid de två sista villkoren.
    ///
    /// De flesta plattformar kan i grunden inte ens konstruera en så stor fördelning.
    /// Till exempel kan ingen känd 64-bitarsplattform någonsin betjäna en begäran om 2 <sup>63</sup> byte på grund av sidtabellbegränsningar eller uppdelning av adressutrymmet.
    /// Vissa 32-bitars och 16-bitars plattformar kan dock framgångsrikt betjäna en begäran om mer än `isize::MAX` byte med saker som tillägg för fysisk adress.
    /// Som sådant kan minne som erhållits direkt från allokatorer eller minneskartade filer * vara för stort för att hantera den här funktionen.
    /// (Observera att [`offset`] och [`add`] också har en liknande begränsning och därför inte heller kan användas på så stora tilldelningar.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Denna funktion panics om `T` är en nollstorlek typ ("ZST").
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Felaktig* användning:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Gör ptr2_other till en "alias" av ptr2, men härledd från ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Eftersom ptr2_other och ptr2 härrör från pekare till olika objekt är beräkningen av deras förskjutning odefinierat beteende, även om de pekar på samma adress!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Odefinierat beteende
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `ptr_offset_from`.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Returnerar om två pekare garanteras vara lika.
    ///
    /// Vid körning fungerar den här funktionen som `self == other`.
    /// I vissa sammanhang (t.ex. kompileringstidutvärdering) är det dock inte alltid möjligt att bestämma likheten mellan två pekare, så denna funktion kan felaktigt returnera `false` för pekare som senare faktiskt visar sig vara lika.
    ///
    /// Men när den returnerar `true` är pekarna garanterade lika.
    ///
    /// Denna funktion är spegeln för [`guaranteed_ne`], men inte dess inversa.Det finns jämförelser för vilka båda funktionerna returnerar `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Returvärdet kan ändras beroende på kompilatorversionen och osäker kod beror kanske inte på resultatet av denna funktion för sundhet.
    /// Det rekommenderas att endast använda den här funktionen för prestandaoptimeringar där falska `false`-returvärden av denna funktion inte påverkar resultatet utan bara prestandan.
    /// Konsekvenserna av att använda denna metod för att få körtid och kompileringskod att fungera annorlunda har inte undersökts.
    /// Denna metod ska inte användas för att införa sådana skillnader, och den bör inte heller stabiliseras innan vi har en bättre förståelse för denna fråga.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Returnerar om två pekare garanteras vara ojämna.
    ///
    /// Vid körning fungerar den här funktionen som `self != other`.
    /// I vissa sammanhang (t.ex. kompileringstidutvärdering) är det dock inte alltid möjligt att bestämma ojämlikheten mellan två pekare, så denna funktion kan felaktigt returnera `false` för pekare som senare faktiskt visar sig vara ojämlika.
    ///
    /// Men när den returnerar `true` är pekarna garanterade att de är ojämna.
    ///
    /// Denna funktion är spegeln för [`guaranteed_eq`], men inte dess inversa.Det finns jämförelser för vilka båda funktionerna returnerar `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Returvärdet kan ändras beroende på kompilatorversionen och osäker kod beror kanske inte på resultatet av denna funktion för sundhet.
    /// Det rekommenderas att endast använda den här funktionen för prestandaoptimeringar där falska `false`-returvärden av denna funktion inte påverkar resultatet utan bara prestandan.
    /// Konsekvenserna av att använda denna metod för att få körtid och kompileringskod att fungera annorlunda har inte undersökts.
    /// Denna metod ska inte användas för att införa sådana skillnader, och den bör inte heller stabiliseras innan vi har en bättre förståelse för denna fråga.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Beräknar förskjutningen från en pekare (bekvämlighet för `.offset(count as isize)`).
    ///
    /// `count` är i enheter av T;t.ex. representerar en `count` av 3 en pekarkompensation av `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Om något av följande villkor bryts är resultatet odefinierat beteende:
    ///
    /// * Både start-och resulterande pekare måste vara antingen i gränser eller en byte efter slutet av samma tilldelade objekt.
    /// Observera att i Rust betraktas varje (stack-allocated)-variabel som ett separat tilldelat objekt.
    ///
    /// * Den beräknade förskjutningen,**i byte**, kan inte översvämma en `isize`.
    ///
    /// * Förskjutningen inom gränser kan inte förlita sig på "wrapping around" adressutrymmet.Det vill säga den oändliga precisionssummen måste passa i en `usize`.
    ///
    /// Kompilatorn och standardbiblioteket försöker generellt se till att allokeringar aldrig når en storlek där en förskjutning är ett problem.
    /// Till exempel säkerställer `Vec` och `Box` att de aldrig tilldelar mer än `isize::MAX` byte, så `vec.as_ptr().add(vec.len())` är alltid säker.
    ///
    /// De flesta plattformar kan i grunden inte ens konstruera en sådan fördelning.
    /// Till exempel kan ingen känd 64-bitarsplattform någonsin betjäna en begäran om 2 <sup>63</sup> byte på grund av sidtabellbegränsningar eller uppdelning av adressutrymmet.
    /// Vissa 32-bitars och 16-bitars plattformar kan dock framgångsrikt betjäna en begäran om mer än `isize::MAX` byte med saker som tillägg för fysisk adress.
    ///
    /// Som sådant kan minne som erhållits direkt från allokatorer eller minneskartade filer * vara för stort för att hantera den här funktionen.
    ///
    /// Överväg att använda [`wrapping_add`] istället om dessa begränsningar är svåra att tillfredsställa.
    /// Den enda fördelen med denna metod är att den möjliggör mer aggressiva kompilatoroptimeringar.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Beräknar offset från en pekare (bekvämlighet för `.offset ((räknas som isize).wrapping_neg())`).
    ///
    /// `count` är i enheter av T;t.ex. representerar en `count` av 3 en pekarkompensation av `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Om något av följande villkor bryts är resultatet odefinierat beteende:
    ///
    /// * Både start-och resulterande pekare måste vara antingen i gränser eller en byte efter slutet av samma tilldelade objekt.
    /// Observera att i Rust betraktas varje (stack-allocated)-variabel som ett separat tilldelat objekt.
    ///
    /// * Den beräknade förskjutningen får inte överstiga `isize::MAX`**byte**.
    ///
    /// * Förskjutningen i gränser kan inte förlita sig på "wrapping around" adressutrymmet.Det vill säga att den oändliga precisionssummen måste passa in i en storlek.
    ///
    /// Kompilatorn och standardbiblioteket försöker generellt se till att allokeringar aldrig når en storlek där en förskjutning är ett problem.
    /// Till exempel säkerställer `Vec` och `Box` att de aldrig tilldelar mer än `isize::MAX` byte, så `vec.as_ptr().add(vec.len()).sub(vec.len())` är alltid säker.
    ///
    /// De flesta plattformar kan i grunden inte ens konstruera en sådan fördelning.
    /// Till exempel kan ingen känd 64-bitarsplattform någonsin betjäna en begäran om 2 <sup>63</sup> byte på grund av sidtabellbegränsningar eller uppdelning av adressutrymmet.
    /// Vissa 32-bitars och 16-bitars plattformar kan dock framgångsrikt betjäna en begäran om mer än `isize::MAX` byte med saker som tillägg för fysisk adress.
    ///
    /// Som sådant kan minne som erhållits direkt från allokatorer eller minneskartade filer * vara för stort för att hantera den här funktionen.
    ///
    /// Överväg att använda [`wrapping_sub`] istället om dessa begränsningar är svåra att tillfredsställa.
    /// Den enda fördelen med denna metod är att den möjliggör mer aggressiva kompilatoroptimeringar.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Beräknar förskjutningen från en pekare med hjälp av inslagningsaritmetik.
    /// (bekvämlighet för `.wrapping_offset(count as isize)`)
    ///
    /// `count` är i enheter av T;t.ex. representerar en `count` av 3 en pekarkompensation av `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Den här åtgärden i sig är alltid säker, men det är inte att använda den resulterande pekaren.
    ///
    /// Den resulterande pekaren förblir ansluten till samma tilldelade objekt som `self` pekar på.
    /// Det kan *inte* användas för att komma åt ett annat tilldelat objekt.Observera att i Rust betraktas varje (stack-allocated)-variabel som ett separat tilldelat objekt.
    ///
    /// Med andra ord gör `let z = x.wrapping_add((y as usize) - (x as usize))`*inte*`z` samma som `y` även om vi antar att `T` har storlek `1` och det inte finns något överflöde: `z` är fortfarande kopplat till objektet `x` är kopplat till, och därmed hänvisas det till odefinierat beteende såvida inte `x` och `y` pekar in i samma tilldelade objekt.
    ///
    /// Jämfört med [`add`] fördröjer denna metod i princip kravet på att hålla sig inom samma tilldelade objekt: [`add`] är omedelbart odefinierat beteende när objektgränserna passeras;`wrapping_add` producerar en pekare men leder ändå till odefinierat beteende om en pekare härleds när den ligger utanför gränserna för objektet den är fäst vid.
    /// [`add`] kan optimeras bättre och är därför att föredra i prestandakänslig kod.
    ///
    /// Den fördröjda kontrollen tar endast hänsyn till värdet på pekaren som hänfördes till, inte de mellanliggande värdena som användes under beräkningen av det slutliga resultatet.
    /// Till exempel är `x.wrapping_add(o).wrapping_sub(o)` alltid samma som `x`.Med andra ord är det tillåtet att lämna det tilldelade objektet och sedan mata in det senare.
    ///
    /// Om du behöver korsa objektgränser, kasta pekaren till ett heltal och gör aritmetiken där.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// // Iterera med en rå pekare i steg om två element
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Denna slinga skriver ut "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Beräknar förskjutningen från en pekare med hjälp av inslagningsaritmetik.
    /// (bekvämlighet för `.wrapping_offset ((räknas som isize).wrapping_neg())`)
    ///
    /// `count` är i enheter av T;t.ex. representerar en `count` av 3 en pekarkompensation av `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Den här åtgärden i sig är alltid säker, men det är inte att använda den resulterande pekaren.
    ///
    /// Den resulterande pekaren förblir ansluten till samma tilldelade objekt som `self` pekar på.
    /// Det kan *inte* användas för att komma åt ett annat tilldelat objekt.Observera att i Rust betraktas varje (stack-allocated)-variabel som ett separat tilldelat objekt.
    ///
    /// Med andra ord gör `let z = x.wrapping_sub((x as usize) - (y as usize))`*inte*`z` samma som `y` även om vi antar att `T` har storlek `1` och det inte finns något överflöde: `z` är fortfarande kopplat till objektet `x` är kopplat till, och därmed hänvisas det till odefinierat beteende såvida inte `x` och `y` pekar in i samma tilldelade objekt.
    ///
    /// Jämfört med [`sub`] fördröjer denna metod i princip kravet på att hålla sig inom samma tilldelade objekt: [`sub`] är omedelbart odefinierat beteende när objektgränserna passeras;`wrapping_sub` producerar en pekare men leder ändå till odefinierat beteende om en pekare härleds när den ligger utanför gränserna för objektet den är fäst vid.
    /// [`sub`] kan optimeras bättre och är därför att föredra i prestandakänslig kod.
    ///
    /// Den fördröjda kontrollen tar endast hänsyn till värdet på pekaren som hänfördes till, inte de mellanliggande värdena som användes under beräkningen av det slutliga resultatet.
    /// Till exempel är `x.wrapping_add(o).wrapping_sub(o)` alltid samma som `x`.Med andra ord är det tillåtet att lämna det tilldelade objektet och sedan mata in det senare.
    ///
    /// Om du behöver korsa objektgränser, kasta pekaren till ett heltal och gör aritmetiken där.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// // Iterera med en rå pekare i steg om två element (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Denna slinga skriver ut "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Ställer in pekarens värde till `ptr`.
    ///
    /// Om `self` är en (fat)-pekare till en osorterad typ, kommer denna operation endast att påverka pekardelen, medan för (thin)-pekare till storlekstyper har detta samma effekt som en enkel tilldelning.
    ///
    /// Den resulterande pekaren kommer att ha härkomst av `val`, dvs för en fettpekare är denna operation semantiskt densamma som att skapa en ny fettpekare med datapekarens värde `val` men metadata för `self`.
    ///
    ///
    /// # Examples
    ///
    /// Denna funktion är främst användbar för att tillåta bytevis pekare-aritmetik på potentiellt feta pekare:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // kommer att skriva ut "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // SÄKERHET: I händelse av en tunn pekare är dessa operationer identiska
        // till ett enkelt uppdrag.
        // I fallet med en fettpekare, med den aktuella implementeringen av fettpekarlayouten, är det första fältet i en sådan pekare alltid datapekaren, som också tilldelas.
        //
        unsafe { *thin = val };
        self
    }

    /// Läser värdet från `self` utan att flytta det.
    /// Detta lämnar minnet i `self` oförändrat.
    ///
    /// Se [`ptr::read`] för säkerhetsproblem och exempel.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `read`.
        unsafe { read(self) }
    }

    /// Utför en flyktig avläsning av värdet från `self` utan att flytta det.Detta lämnar minnet i `self` oförändrat.
    ///
    /// Flyktiga operationer är avsedda att fungera på I/O-minne och garanteras att de inte elideras eller ordnas av kompilatorn över andra flyktiga operationer.
    ///
    ///
    /// Se [`ptr::read_volatile`] för säkerhetsproblem och exempel.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Läser värdet från `self` utan att flytta det.
    /// Detta lämnar minnet i `self` oförändrat.
    ///
    /// Till skillnad från `read` kan pekaren vara ojusterad.
    ///
    /// Se [`ptr::read_unaligned`] för säkerhetsproblem och exempel.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Kopierar `count * size_of<T>` byte från `self` till `dest`.
    /// Källan och destinationen kan överlappa varandra.
    ///
    /// NOTE: detta har *samma* argumentordning som [`ptr::copy`].
    ///
    /// Se [`ptr::copy`] för säkerhetsproblem och exempel.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Kopierar `count * size_of<T>` byte från `self` till `dest`.
    /// Källan och destinationen kanske *inte* överlappar varandra.
    ///
    /// NOTE: detta har *samma* argumentordning som [`ptr::copy_nonoverlapping`].
    ///
    /// Se [`ptr::copy_nonoverlapping`] för säkerhetsproblem och exempel.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Beräknar förskjutningen som måste appliceras på pekaren för att göra den anpassad till `align`.
    ///
    /// Om det inte är möjligt att justera pekaren returnerar implementeringen `usize::MAX`.
    /// Det är tillåtet för implementeringen att *alltid* returnera `usize::MAX`.
    /// Endast din algoritms prestanda kan bero på att få en användbar förskjutning här, inte dess korrekthet.
    ///
    /// Offset uttrycks i antal `T`-element och inte byte.Det returnerade värdet kan användas med `wrapping_add`-metoden.
    ///
    /// Det finns inga garantier för att kompensering av pekaren inte kommer att rinna över eller gå utöver allokeringen som pekaren pekar på.
    ///
    /// Det är upp till den som ringer att se till att den returnerade förskjutningen är korrekt i alla andra termer än justering.
    ///
    /// # Panics
    ///
    /// Funktionen panics om `align` inte är en power-of-two.
    ///
    /// # Examples
    ///
    /// Åtkomst till intilliggande `u8` som `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // medan pekaren kan justeras via `offset`, skulle den peka utanför allokeringen
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SÄKERHET: `align` har kontrollerats för att vara en effekt på 2 ovan
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Returnerar längden på en rå skiva.
    ///
    /// Det returnerade värdet är antalet **element**, inte antalet byte.
    ///
    /// Denna funktion är säker, även om den råa skivan inte kan kastas till en skivreferens eftersom pekaren är noll eller ojusterad.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SÄKERHET: detta är säkert eftersom `*const [T]` och `FatPtr<T>` har samma layout.
            // Endast `std` kan göra denna garanti.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Returnerar en rå pekare till skivans buffert.
    ///
    /// Detta motsvarar gjutning av `self` till `*const T`, men mer typsäkert.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Returnerar en rå pekare till ett element eller underdel utan att göra gränskontroll.
    ///
    /// Att kalla den här metoden med ett index utanför gränserna eller när `self` inte kan avläsas är *[odefinierat beteende]* även om den resulterande pekaren inte används.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SÄKERHET: den som ringer säkerställer att `self` kan avläsas och `index` inom gränserna.
        unsafe { index.get_unchecked(self) }
    }

    /// Returnerar `None` om pekaren är noll eller annars returnerar en delad del till värdet som slås in i `Some`.
    /// Till skillnad från [`as_ref`] kräver detta inte att värdet måste initialiseras.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// När du anropar den här metoden måste du se till att *antingen* pekaren är NULL *eller* att allt detta är sant:
    ///
    /// * Pekaren måste vara [valid] för läsning för `ptr.len() * mem::size_of::<T>()` många byte, och den måste vara korrekt inriktad.Detta innebär särskilt:
    ///
    ///     * Hela minnesområdet för denna skiva måste finnas i ett enda tilldelat objekt!
    ///       Skivor kan aldrig spänna över flera tilldelade objekt.
    ///
    ///     * Pekaren måste vara inriktad även för nollängdsskivor.
    ///     En anledning till detta är att optimeringar av enumlayout kan vara beroende av att referenser (inklusive skivor av vilken längd som helst) är inriktade och inte är null för att skilja dem från andra data.
    ///
    ///     Du kan få en pekare som kan användas som `data` för nollängdsskivor med [`NonNull::dangling()`].
    ///
    /// * Den totala storleken `ptr.len() * mem::size_of::<T>()` för skivan får inte vara större än `isize::MAX`.
    ///   Se säkerhetsdokumentationen för [`pointer::offset`].
    ///
    /// * Du måste tillämpa Rust s aliasing-regler, eftersom den returnerade livstiden `'a` väljs godtyckligt och inte nödvändigtvis återspeglar den faktiska livslängden för data.
    ///   I synnerhet under den här livstiden får minnet som pekaren pekar på inte muteras (utom i `UnsafeCell`).
    ///
    /// Detta gäller även om resultatet av denna metod är oanvänd!
    ///
    /// Se även [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Jämställdhet för pekare
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Jämförelse för pekare
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}