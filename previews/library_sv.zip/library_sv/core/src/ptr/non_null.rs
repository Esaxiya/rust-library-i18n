use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` men icke-noll och kovariant.
///
/// Detta är ofta rätt sak att använda när man bygger datastrukturer med råa pekare, men är i slutändan farligare att använda på grund av dess ytterligare egenskaper.Om du inte är säker på om du ska använda `NonNull<T>`, använd bara `*mut T`!
///
/// Till skillnad från `*mut T`, måste pekaren alltid vara icke-noll, även om pekaren aldrig refereras till.Detta för att enums kan använda detta förbjudna värde som en diskriminant-`Option<NonNull<T>>` har samma storlek som `* mut T`.
/// Men pekaren kan fortfarande dingla om den inte refereras till.
///
/// Till skillnad från `*mut T` valdes `NonNull<T>` att vara kovariant över `T`.Detta gör det möjligt att använda `NonNull<T>` när man bygger kovariantyper, men introducerar risken för osundhet om den används i en typ som inte borde vara kovariant.
/// (Det motsatta valet gjordes för `*mut T` trots att tekniskt sett kunde osundheten bara orsakas av att anropa osäkra funktioner.)
///
/// Kovarians är korrekt för de mest säkra abstraktionerna, till exempel `Box`, `Rc`, `Arc`, `Vec` och `LinkedList`.Detta är fallet eftersom de tillhandahåller ett offentligt API som följer de normala delade XOR-muterbara reglerna för Rust.
///
/// Om din typ inte säkert kan vara kovariant måste du se till att den innehåller ytterligare ett fält för att ge invarians.Ofta kommer detta fält att vara en [`PhantomData`]-typ som `PhantomData<Cell<T>>` eller `PhantomData<&'a mut T>`.
///
/// Observera att `NonNull<T>` har en `From`-instans för `&T`.Detta ändrar dock inte det faktum att mutering genom en (pekare härledd från en) delad referens är odefinierat beteende såvida inte mutationen sker i en [`UnsafeCell<T>`].Detsamma gäller för att skapa en muterbar referens från en delad referens.
///
/// När du använder den här `From`-instansen utan en `UnsafeCell<T>` är det ditt ansvar att se till att `as_mut` aldrig anropas och att `as_ptr` aldrig används för mutation.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` pekare är inte `Send` eftersom data som de hänvisar till kan vara alias.
// OBS! Detta impl är onödigt men borde ge bättre felmeddelanden.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` pekare är inte `Sync` eftersom data som de hänvisar till kan vara alias.
// OBS! Detta impl är onödigt men borde ge bättre felmeddelanden.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Skapar en ny `NonNull` som är dinglande men väl anpassad.
    ///
    /// Detta är användbart för att initialisera typer som lat tilldelas, som `Vec::new` gör.
    ///
    /// Observera att pekarens värde potentiellt kan representera en giltig pekare till en `T`, vilket innebär att detta inte får användas som ett "not yet initialized"-sentinelvärde.
    /// Typer som lat tilldelas måste spåra initialisering på annat sätt.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SÄKERHET: mem::align_of() returnerar en icke-nollanvändning som sedan kastas
        // till en * mut T.
        // Därför är `ptr` inte noll och villkoren för att ringa new_unchecked() respekteras.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Returnerar en delad referens till värdet.Till skillnad från [`as_ref`] kräver detta inte att värdet måste initialiseras.
    ///
    /// För den muterbara motsvarigheten, se [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// När du ringer till den här metoden måste du se till att allt följande är sant:
    ///
    /// * Pekaren måste vara rätt inriktad.
    ///
    /// * Det måste vara "dereferencable" i den mening som definieras i [the module documentation].
    ///
    /// * Du måste tillämpa Rust s aliasing-regler, eftersom den returnerade livstiden `'a` väljs godtyckligt och inte nödvändigtvis återspeglar den faktiska livslängden för data.
    ///
    ///   I synnerhet under den här livstiden får minnet som pekaren pekar på inte muteras (utom i `UnsafeCell`).
    ///
    /// Detta gäller även om resultatet av denna metod är oanvänd!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SÄKERHET: den som ringer måste garantera att `self` uppfyller alla
        // krav på en referens.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Returnerar en unik referens till värdet.Till skillnad från [`as_mut`] kräver detta inte att värdet måste initialiseras.
    ///
    /// För den delade motsvarigheten, se [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// När du ringer till den här metoden måste du se till att allt följande är sant:
    ///
    /// * Pekaren måste vara rätt inriktad.
    ///
    /// * Det måste vara "dereferencable" i den mening som definieras i [the module documentation].
    ///
    /// * Du måste tillämpa Rust s aliasing-regler, eftersom den returnerade livstiden `'a` väljs godtyckligt och inte nödvändigtvis återspeglar den faktiska livslängden för data.
    ///
    ///   I synnerhet under den här livstiden får minnet som pekaren pekar på inte komma åt (läsas eller skrivas) via någon annan pekare.
    ///
    /// Detta gäller även om resultatet av denna metod är oanvänd!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SÄKERHET: den som ringer måste garantera att `self` uppfyller alla
        // krav på en referens.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Skapar en ny `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` måste vara icke-noll.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SÄKERHET: den som ringer måste garantera att `ptr` inte är noll.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Skapar en ny `NonNull` om `ptr` inte är null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SÄKERHET: Pekaren är redan markerad och är inte noll
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Utför samma funktion som [`std::ptr::from_raw_parts`], förutom att en `NonNull`-pekare returneras, i motsats till en rå `*const`-pekare.
    ///
    ///
    /// Se dokumentationen för [`std::ptr::from_raw_parts`] för mer information.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SÄKERHET: Resultatet av `ptr::from::raw_parts_mut` är icke-null eftersom `data_address` är.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Sönderdela en (eventuellt bred) pekare till är adress-och metadatakomponenter.
    ///
    /// Pekaren kan senare rekonstrueras med [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Hämtar den underliggande `*mut`-pekaren.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Returnerar en delad referens till värdet.Om värdet kan inaktiveras måste [`as_uninit_ref`] användas istället.
    ///
    /// För den muterbara motsvarigheten, se [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// När du ringer till den här metoden måste du se till att allt följande är sant:
    ///
    /// * Pekaren måste vara rätt inriktad.
    ///
    /// * Det måste vara "dereferencable" i den mening som definieras i [the module documentation].
    ///
    /// * Pekaren måste peka på en initialiserad förekomst av `T`.
    ///
    /// * Du måste tillämpa Rust s aliasing-regler, eftersom den returnerade livstiden `'a` väljs godtyckligt och inte nödvändigtvis återspeglar den faktiska livslängden för data.
    ///
    ///   I synnerhet under den här livstiden får minnet som pekaren pekar på inte muteras (utom i `UnsafeCell`).
    ///
    /// Detta gäller även om resultatet av denna metod är oanvänd!
    /// (Delen om att initialiseras är ännu inte helt beslutad, men tills det är det enda säkra tillvägagångssättet är att se till att de verkligen initialiseras.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SÄKERHET: den som ringer måste garantera att `self` uppfyller alla
        // krav på en referens.
        unsafe { &*self.as_ptr() }
    }

    /// Returnerar en unik referens till värdet.Om värdet kan vara oinitialiserat måste [`as_uninit_mut`] användas istället.
    ///
    /// För den delade motsvarigheten, se [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// När du ringer till den här metoden måste du se till att allt följande är sant:
    ///
    /// * Pekaren måste vara rätt inriktad.
    ///
    /// * Det måste vara "dereferencable" i den mening som definieras i [the module documentation].
    ///
    /// * Pekaren måste peka på en initialiserad förekomst av `T`.
    ///
    /// * Du måste tillämpa Rust s aliasing-regler, eftersom den returnerade livstiden `'a` väljs godtyckligt och inte nödvändigtvis återspeglar den faktiska livslängden för data.
    ///
    ///   I synnerhet under den här livstiden får minnet som pekaren pekar på inte komma åt (läsas eller skrivas) via någon annan pekare.
    ///
    /// Detta gäller även om resultatet av denna metod är oanvänd!
    /// (Delen om att initialiseras är ännu inte helt beslutad, men tills det är det enda säkra tillvägagångssättet är att se till att de verkligen initialiseras.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SÄKERHET: den som ringer måste garantera att `self` uppfyller alla
        // krav på en förändrad referens.
        unsafe { &mut *self.as_ptr() }
    }

    /// Castar till en pekare av annan typ.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SÄKERHET: `self` är en `NonNull`-pekare som nödvändigtvis inte är null
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Skapar en rå skiva som inte är null från en tunn pekare och en längd.
    ///
    /// `len`-argumentet är antalet **element**, inte antalet byte.
    ///
    /// Den här funktionen är säker, men att inte referera till returvärdet är osäkert.
    /// Se dokumentationen för [`slice::from_raw_parts`] för säkerhetskrav för segment.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // skapa en skivpekare när du börjar med en pekare till det första elementet
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Observera att detta exempel på ett konstgjort sätt visar hur denna metod används, men `låt skiva= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SÄKERHET: `data` är en `NonNull`-pekare som nödvändigtvis inte är null
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Returnerar längden på en rå skiva som inte är null.
    ///
    /// Det returnerade värdet är antalet **element**, inte antalet byte.
    ///
    /// Den här funktionen är säker, även om råskivan som inte är null inte kan hänvisas till en skiva eftersom pekaren inte har en giltig adress.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Returnerar en icke-nollpekare till skivans buffert.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SÄKERHET: Vi vet att `self` inte är null.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Returnerar en rå pekare till skivans buffert.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Returnerar en delad referens till en bit möjligen oinitialiserade värden.Till skillnad från [`as_ref`] kräver detta inte att värdet måste initialiseras.
    ///
    /// För den muterbara motsvarigheten, se [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// När du ringer till den här metoden måste du se till att allt följande är sant:
    ///
    /// * Pekaren måste vara [valid] för läsning för `ptr.len() * mem::size_of::<T>()` många byte, och den måste vara korrekt inriktad.Detta innebär särskilt:
    ///
    ///     * Hela minnesområdet för denna skiva måste finnas i ett enda tilldelat objekt!
    ///       Skivor kan aldrig spänna över flera tilldelade objekt.
    ///
    ///     * Pekaren måste vara inriktad även för nollängdsskivor.
    ///     En anledning till detta är att optimeringar av enumlayout kan vara beroende av att referenser (inklusive skivor av vilken längd som helst) är inriktade och inte är null för att skilja dem från andra data.
    ///
    ///     Du kan få en pekare som kan användas som `data` för nollängdsskivor med [`NonNull::dangling()`].
    ///
    /// * Den totala storleken `ptr.len() * mem::size_of::<T>()` för skivan får inte vara större än `isize::MAX`.
    ///   Se säkerhetsdokumentationen för [`pointer::offset`].
    ///
    /// * Du måste tillämpa Rust s aliasing-regler, eftersom den returnerade livstiden `'a` väljs godtyckligt och inte nödvändigtvis återspeglar den faktiska livslängden för data.
    ///   I synnerhet under den här livstiden får minnet som pekaren pekar på inte muteras (utom i `UnsafeCell`).
    ///
    /// Detta gäller även om resultatet av denna metod är oanvänd!
    ///
    /// Se även [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Returnerar en unik referens till en bit möjligen oinitialiserade värden.Till skillnad från [`as_mut`] kräver detta inte att värdet måste initialiseras.
    ///
    /// För den delade motsvarigheten, se [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// När du ringer till den här metoden måste du se till att allt följande är sant:
    ///
    /// * Pekaren måste vara [valid] för att läsa och skriva för `ptr.len() * mem::size_of::<T>()` många byte, och den måste vara korrekt inriktad.Detta innebär särskilt:
    ///
    ///     * Hela minnesområdet för denna skiva måste finnas i ett enda tilldelat objekt!
    ///       Skivor kan aldrig spänna över flera tilldelade objekt.
    ///
    ///     * Pekaren måste vara inriktad även för nollängdsskivor.
    ///     En anledning till detta är att optimeringar av enumlayout kan vara beroende av att referenser (inklusive skivor av vilken längd som helst) är inriktade och inte är null för att skilja dem från andra data.
    ///
    ///     Du kan få en pekare som kan användas som `data` för nollängdsskivor med [`NonNull::dangling()`].
    ///
    /// * Den totala storleken `ptr.len() * mem::size_of::<T>()` för skivan får inte vara större än `isize::MAX`.
    ///   Se säkerhetsdokumentationen för [`pointer::offset`].
    ///
    /// * Du måste tillämpa Rust s aliasing-regler, eftersom den returnerade livstiden `'a` väljs godtyckligt och inte nödvändigtvis återspeglar den faktiska livslängden för data.
    ///   I synnerhet under den här livstiden får minnet som pekaren pekar på inte komma åt (läsas eller skrivas) via någon annan pekare.
    ///
    /// Detta gäller även om resultatet av denna metod är oanvänd!
    ///
    /// Se även [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Detta är säkert eftersom `memory` är giltigt för läser och skriver för `memory.len()` många byte.
    /// // Observera att det inte är tillåtet att ringa `memory.as_mut()` här eftersom innehållet kan vara oinitialiserat.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Returnerar en rå pekare till ett element eller underdel utan att göra gränskontroll.
    ///
    /// Att kalla den här metoden med ett index utanför gränserna eller när `self` inte kan avläsas är *[odefinierat beteende]* även om den resulterande pekaren inte används.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SÄKERHET: den som ringer säkerställer att `self` kan avläsas och `index` inom gränserna.
        // Som en konsekvens kan den resulterande pekaren inte vara NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SÄKERHET: En unik pekare kan inte vara noll, så villkoren för
        // new_unchecked() respekteras.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SÄKERHET: En förändrad referens kan inte vara noll.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SÄKERHET: En referens kan inte vara noll, så villkoren för
        // new_unchecked() respekteras.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}