use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Ett omslag runt en rå icke-null `*mut T` som indikerar att innehavaren av detta omslag äger referenten.
/// Användbar för att bygga abstraktioner som `Box<T>`, `Vec<T>`, `String` och `HashMap<K, V>`.
///
/// Till skillnad från `*mut T` beter `Unique<T>` sig "as if", det var en förekomst av `T`.
/// Den implementerar `Send`/`Sync` om `T` är `Send`/`Sync`.
/// Det innebär också den typ av starka aliasgarantier som en förekomst av `T` kan förvänta sig:
/// pekarens referens bör inte modifieras utan en unik sökväg till dess ägande Unique.
///
/// Om du är osäker på om det är korrekt att använda `Unique` för dina ändamål, överväg att använda `NonNull`, som har svagare semantik.
///
///
/// Till skillnad från `*mut T` måste pekaren alltid vara icke-noll, även om pekaren aldrig refereras till.
/// Detta för att enums kan använda detta förbjudna värde som en diskriminant-`Option<Unique<T>>` har samma storlek som `Unique<T>`.
/// Men pekaren kan fortfarande dingla om den inte refereras till.
///
/// Till skillnad från `*mut T` är `Unique<T>` kovariant över `T`.
/// Detta ska alltid vara korrekt för alla typer som upprätthåller Uniques aliasingskrav.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: denna markör har inga konsekvenser för varians, men är nödvändig
    // för dropck att förstå att vi logiskt äger en `T`.
    //
    // Mer information finns i:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` pekare är `Send` om `T` är `Send` eftersom informationen som de hänvisar till är inte utvärderad.
/// Observera att denna aliasingvariant inte styrs av typsystemet;abstraktionen med `Unique` måste genomdriva den.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` pekare är `Sync` om `T` är `Sync` eftersom informationen som de hänvisar till är ojämn.
/// Observera att denna aliasingvariant inte styrs av typsystemet;abstraktionen med `Unique` måste genomdriva den.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Skapar en ny `Unique` som är dinglande men väl anpassad.
    ///
    /// Detta är användbart för att initialisera typer som lat tilldelas, som `Vec::new` gör.
    ///
    /// Observera att pekarens värde potentiellt kan representera en giltig pekare till en `T`, vilket innebär att detta inte får användas som ett "not yet initialized"-sentinelvärde.
    /// Typer som lat tilldelas måste spåra initialisering på annat sätt.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SÄKERHET: mem::align_of() returnerar en giltig, icke-nollpekare.De
        // villkoren för att ringa new_unchecked() respekteras således.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Skapar en ny `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` måste vara icke-noll.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SÄKERHET: den som ringer måste garantera att `ptr` inte är noll.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Skapar en ny `Unique` om `ptr` inte är null.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SÄKERHET: Pekaren har redan kontrollerats och är inte noll.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Hämtar den underliggande `*mut`-pekaren.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Dereferenser innehållet.
    ///
    /// Den resulterande livstiden är bunden till sig själv så detta beter sig "as if" det var faktiskt en instans av T som får lånas.
    /// Om du behöver en längre (unbound)-livslängd, använd `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SÄKERHET: den som ringer måste garantera att `self` uppfyller alla
        // krav på en referens.
        unsafe { &*self.as_ptr() }
    }

    /// Du kan hänvisa innehållet till varandra.
    ///
    /// Den resulterande livstiden är bunden till sig själv så detta beter sig "as if" det var faktiskt en instans av T som får lånas.
    /// Om du behöver en längre (unbound)-livslängd, använd `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SÄKERHET: den som ringer måste garantera att `self` uppfyller alla
        // krav på en förändrad referens.
        unsafe { &mut *self.as_ptr() }
    }

    /// Castar till en pekare av annan typ.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SÄKERHET: Unique::new_unchecked() skapar ett nytt unikt och behov
        // den angivna pekaren inte är noll.
        // Eftersom vi passerar själv som en pekare kan det inte vara noll.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SÄKERHET: En förändrad referens kan inte vara noll
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}