//! Hantera minne manuellt genom råa pekare.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Många funktioner i den här modulen tar råa pekare som argument och läser från eller skriver till dem.För att detta ska vara säkert måste dessa pekare vara *giltiga*.
//! Huruvida en pekare är giltig beror på den funktion den används för (läs eller skriv), och omfattningen av minnet som nås (dvs. hur många byte som är read/written).
//! De flesta funktioner använder `*mut T` och `* const T` för att bara få åtkomst till ett enda värde, i vilket fall dokumentationen utelämnar storleken och antar implicit att den är `size_of::<T>()` byte.
//!
//! De exakta reglerna för giltighet är ännu inte fastställda.Garantierna som tillhandahålls vid denna tidpunkt är mycket minimala:
//!
//! * En [null]-pekare är *aldrig* giltig, inte ens för åtkomst till [size zero][zst].
//! * För att en pekare ska vara giltig är det nödvändigt, men inte alltid tillräckligt, att pekaren är *avlägsbar*: minnesområdet för den angivna storleken som börjar vid pekaren måste alla ligga inom gränserna för ett enda tilldelat objekt.
//!
//! Observera att i Rust betraktas varje (stack-allocated)-variabel som ett separat tilldelat objekt.
//! * Även för [size zero][zst]-operationer får pekaren inte peka på ett omplacerat minne, dvs. deallocation gör pekare ogiltiga även för nollstora operationer.
//! Att kasta valfritt heltal *bokstavligt* till en pekare är dock giltigt för åtkomst av nollstorlek, även om något minne råkar existera vid den adressen och omplaceras.
//! Detta motsvarar att skriva din egen fördelare: att tilldela objekt utan storlek är inte särskilt svårt.
//! Det kanoniska sättet att få en pekare som är giltig för åtkomst till nollstorlek är [`NonNull::dangling`].
//! * Alla åtkomster som utförs av funktioner i den här modulen är *icke-atomära* i den mening som [atomic operations] används för att synkronisera mellan trådar.
//! Det betyder att det är odefinierat beteende att utföra två samtidiga åtkomster till samma plats från olika trådar såvida inte båda åtkomstarna bara läses från minnet.
//! Observera att detta uttryckligen inkluderar [`read_volatile`] och [`write_volatile`]: Flyktiga åtkomster kan inte användas för synkronisering mellan trådar.
//! * Resultatet av att casta en referens till en pekare är giltig så länge det underliggande objektet är live och ingen referens (bara råa pekare) används för att komma åt samma minne.
//!
//! Dessa axiomer, tillsammans med noggrann användning av [`offset`] för pekare, är tillräckliga för att korrekt implementera många användbara saker i osäker kod.
//! Starkare garantier kommer att ges så småningom, eftersom [aliasing]-reglerna fastställs.
//! För mer information, se [book] samt avsnittet i referensen till [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Giltiga råpekare som definierats ovan är inte nödvändigtvis korrekt inriktade (där "proper"-inriktning definieras av pointe-typen, dvs. `*const T` måste vara inriktad mot `mem::align_of::<T>()`).
//! De flesta funktioner kräver dock att deras argument är korrekt anpassade och kommer att uttryckligen ange detta krav i sin dokumentation.
//! Anmärkningsvärda undantag från detta är [`read_unaligned`] och [`write_unaligned`].
//!
//! När en funktion kräver korrekt inriktning gör den det även om åtkomsten har storlek 0, dvs även om minnet faktiskt inte berörs.Överväg att använda [`NonNull::dangling`] i sådana fall.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Utför förstöraren (om någon) av det pekade värdet.
///
/// Detta motsvarar semantiskt att ringa [`ptr::read`] och kassera resultatet, men har följande fördelar:
///
/// * Det är *krävs* att använda `drop_in_place` för att släppa osorterade typer som trait-objekt, eftersom de inte kan läsas ut på stacken och tappas normalt.
///
/// * Det är vänligare för optimeraren att göra detta över [`ptr::read`] när man släpper manuellt tilldelat minne (t.ex. i implementeringarna av `Box`/`Rc`/`Vec`), eftersom kompilatorn inte behöver bevisa att det är bra att ta fram kopian.
///
///
/// * Den kan användas för att släppa [pinned]-data när `T` inte är `repr(packed)` (fästa data får inte flyttas innan de tappas).
///
/// Ojusterade värden kan inte släppas på plats, de måste kopieras till en justerad plats först med [`ptr::read_unaligned`].För packade struts görs detta drag automatiskt av kompilatorn.
/// Det betyder att fälten med packade strucker inte tappas på plats.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Beteende är odefinierat om något av följande villkor bryts:
///
/// * `to_drop` måste vara [valid] för både läsning och skrivning.
///
/// * `to_drop` måste vara ordentligt inriktade.
///
/// * Värdet `to_drop` pekar på måste vara giltigt för att släppa, vilket kan betyda att det måste upprätthålla ytterligare invarianter, detta är typberoende.
///
/// Dessutom, om `T` inte är [`Copy`], kan användning av det riktade värdet efter anrop till `drop_in_place` orsaka odefinierat beteende.Observera att `*to_drop = foo` räknas som en användning eftersom det gör att värdet tappas igen.
/// [`write()`] kan användas för att skriva över data utan att de tappas.
///
/// Observera att även om `T` har storlek `0`, måste pekaren vara icke-NULL och korrekt inriktad.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ta bort det sista objektet manuellt från en vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Få en rå pekare till det sista elementet i `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Förkorta `v` för att förhindra att det sista objektet tappas.
///     // Vi gör det först för att förhindra problem om `drop_in_place` under panics.
///     v.set_len(1);
///     // Utan ett samtal `drop_in_place` skulle det sista objektet aldrig tappas och minnet det hanterar skulle läcka ut.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Se till att det sista objektet tappades.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Observera att kompilatorn utför den här kopian automatiskt när du släpper packade delar, dvs. du behöver vanligtvis inte oroa dig för sådana problem om du inte ringer `drop_in_place` manuellt.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Koden här spelar ingen roll, den ersätts av kompilatorn med det riktiga dropplimet.
    //

    // SÄKERHET: se kommentar ovan
    unsafe { drop_in_place(to_drop) }
}

/// Skapar en null rå pekare.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Skapar en null-mutabel rå pekare.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Manuell implementering behövs för att undvika `T: Clone`-bunden.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Manuell implementering behövs för att undvika `T: Copy`-bunden.
impl<T> Copy for FatPtr<T> {}

/// Bildar en rå skiva från en pekare och en längd.
///
/// `len`-argumentet är antalet **element**, inte antalet byte.
///
/// Denna funktion är säker, men det är inte säkert att använda returvärdet.
/// Se dokumentationen för [`slice::from_raw_parts`] för säkerhetskrav för segment.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // skapa en skivpekare när du börjar med en pekare till det första elementet
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SÄKERHET: Åtkomst till värdet från `Repr`-facket är säkert eftersom * const [T]
        //
        // och FatPtr har samma minneslayouter.Endast std kan göra denna garanti.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Utför samma funktion som [`slice_from_raw_parts`], förutom att en rå muterbar skiva returneras, i motsats till en rå oföränderlig skiva.
///
///
/// Se dokumentationen för [`slice_from_raw_parts`] för mer information.
///
/// Denna funktion är säker, men det är inte säkert att använda returvärdet.
/// Se dokumentationen för [`slice::from_raw_parts_mut`] för säkerhetskrav för segment.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // tilldela ett värde i ett index i segmentet
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SÄKERHET: Åtkomst till värdet från `Repr`-facket är säkert eftersom * mut [T]
        // och FatPtr har samma minneslayouter
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Byt värdena på två ställbara platser av samma typ, utan att avinitialisera heller.
///
/// Men för följande två undantag motsvarar denna funktion semantiskt [`mem::swap`]:
///
///
/// * Det fungerar på råa pekare istället för referenser.
/// När referenser är tillgängliga bör [`mem::swap`] föredras.
///
/// * De två pekade värdena kan överlappa varandra.
/// Om värdena överlappar varandra används den överlappande minnesregionen från `x`.
/// Detta visas i det andra exemplet nedan.
///
/// # Safety
///
/// Beteende är odefinierat om något av följande villkor bryts:
///
/// * Både `x` och `y` måste vara [valid] för både läsning och skrivning.
///
/// * Både `x` och `y` måste vara korrekt inriktade.
///
/// Observera att även om `T` har storlek `0` måste pekarna vara icke-NULL och ordentligt inriktade.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Byta två icke-överlappande regioner:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // det här är `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // det här är `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Byta två överlappande regioner:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // det här är `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // det här är `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Indexen `1..3` i skivan överlappar mellan `x` och `y`.
///     // Rimliga resultat skulle vara för dem att vara `[2, 3]`, så att index `0..3` är `[1, 2, 3]` (matchande `y` före `swap`);eller för att de ska vara `[0, 1]` så att index `1..4` är `[0, 1, 2]` (matchande `x` före `swap`).
/////
///     // Denna implementering definieras för att göra det senare valet.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Ge oss lite reputrymme att arbeta med.
    // Vi behöver inte oroa oss för droppar: `MaybeUninit` gör ingenting när det tappas.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Utför bytet SÄKERHET: den som ringer måste garantera att `x` och `y` är giltiga för skrivning och korrekt inriktade.
    // `tmp` kan inte överlappa vare sig `x` eller `y` eftersom `tmp` bara tilldelades på stacken som ett separat tilldelat objekt.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` och `y` kan överlappa varandra
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Byt `count * size_of::<T>()` byte mellan de två minnesregionerna som börjar på `x` och `y`.
/// De två regionerna får *inte* överlappa varandra.
///
/// # Safety
///
/// Beteende är odefinierat om något av följande villkor bryts:
///
/// * Både `x` och `y` måste vara [valid] för både läsning och skrivning av `count *
///   storlek av: :<T>() `byte.
///
/// * Både `x` och `y` måste vara korrekt inriktade.
///
/// * Regionen minne som börjar vid `x` med storleken på `räknas *
///   storlek av: :<T>() `byte får *inte* överlappa minnesområdet som börjar vid `y` med samma storlek.
///
/// Observera att även om den effektivt kopierade storleken (`count * size_of: :<T>()`) är `0`, pekarna måste vara icke-NULL och korrekt inriktade.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SÄKERHET: den som ringer måste garantera att `x` och `y` är
    // giltig för skrivning och korrekt inriktad
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // För typer som är mindre än blockoptimeringen nedan, byt bara direkt för att undvika pessimisering av kodegen.
    //
    if mem::size_of::<T>() < 32 {
        // SÄKERHET: den som ringer måste garantera att `x` och `y` är giltiga
        // för skrivningar, korrekt inriktade och icke-överlappande.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Metoden här är att använda simd för att byta x&y effektivt.
    // Testning visar att byte av antingen 32 byte eller 64 byte åt gången är mest effektivt för Intel Haswell E-processorer.
    // LLVM kan bättre optimera om vi ger en struct en #[repr(simd)], även om vi inte använder den här strukturen direkt.
    //
    //
    // FIXME repr(simd) trasig på emscripten och redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Loop genom x&y, kopiera dem `Block` åt gången Optimizer ska rulla ut slingan helt för de flesta typer OBS
    // Vi kan inte använda en for loop eftersom `range` impl kallar `mem::swap` rekursivt
    //
    let mut i = 0;
    while i + block_size <= len {
        // Skapa lite oinitialiserat minne som skraputrymme. Genom att deklarera `t` här undviks att justera stacken när den här slingan inte används
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SÄKERHET: Som `i < len` och som den som ringer måste garantera att `x` och `y` är giltiga
        // för `len`-byte måste `x + i` och `y + i` vara giltiga adresser som uppfyller säkerhetskontraktet för `add`.
        //
        // Den som ringer måste också garantera att `x` och `y` är giltiga för skrivningar, korrekt inriktade och icke-överlappande, vilket uppfyller säkerhetskontraktet för `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Byt ett byteblock av x&y, använd t som en tillfällig buffert. Detta bör optimeras till effektiva SIMD-operationer där det finns
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Byt eventuella återstående byte
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SÄKERHET: se tidigare säkerhetskommentar.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Flyttar `src` in i den spetsiga `dst` och returnerar det tidigare `dst`-värdet.
///
/// Inget värde tappas.
///
/// Denna funktion är semantiskt likvärdig med [`mem::replace`] förutom att den fungerar på råa pekare istället för referenser.
/// När referenser är tillgängliga bör [`mem::replace`] föredras.
///
/// # Safety
///
/// Beteende är odefinierat om något av följande villkor bryts:
///
/// * `dst` måste vara [valid] för både läsning och skrivning.
///
/// * `dst` måste vara ordentligt inriktade.
///
/// * `dst` måste peka på ett korrekt initierat värde av typen `T`.
///
/// Observera att även om `T` har storlek `0`, måste pekaren vara icke-NULL och korrekt inriktad.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` skulle ha samma effekt utan att det krävs ett osäkert block.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SÄKERHET: den som ringer måste garantera att `dst` är giltig
    // cast till en muterbar referens (giltig för skrivning, justerad, initialiserad) och kan inte överlappa `src` eftersom `dst` måste peka på ett distinkt tilldelat objekt.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // kan inte överlappa varandra
    }
    src
}

/// Läser värdet från `src` utan att flytta det.Detta lämnar minnet i `src` oförändrat.
///
/// # Safety
///
/// Beteende är odefinierat om något av följande villkor bryts:
///
/// * `src` måste vara [valid] för läsning.
///
/// * `src` måste vara ordentligt inriktade.Använd [`read_unaligned`] om så inte är fallet.
///
/// * `src` måste peka på ett korrekt initierat värde av typen `T`.
///
/// Observera att även om `T` har storlek `0`, måste pekaren vara icke-NULL och korrekt inriktad.
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Manuellt implementera [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Skapa en bitvis kopia av värdet vid `a` i `tmp`.
///         let tmp = ptr::read(a);
///
///         // Avsluta vid denna punkt (antingen genom att uttryckligen återvända eller genom att anropa en funktion som panics) skulle orsaka att värdet i `tmp` tappas medan samma värde fortfarande refereras av `a`.
///         // Detta kan utlösa odefinierat beteende om `T` inte är `Copy`.
/////
/////
///
///         // Skapa en bitvis kopia av värdet vid `b` i `a`.
///         // Detta är säkert eftersom mutabla referenser inte kan alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Som ovan kan avsluta här utlösa odefinierat beteende eftersom samma värde refereras av `a` och `b`.
/////
///
///         // Flytta `tmp` till `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` har flyttats (`write` tar ägande av sitt andra argument), så inget tappas implicit här.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Ägarskap av det returnerade värdet
///
/// `read` skapar en bitvis kopia av `T`, oavsett om `T` är [`Copy`].
/// Om `T` inte är [`Copy`] kan användning av både det returnerade värdet och värdet vid `*src` bryta mot minnessäkerheten.
/// Observera att tilldelning till `*src` räknas som en användning eftersom det kommer att försöka släppa värdet vid `* src`.
///
/// [`write()`] kan användas för att skriva över data utan att de tappas.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` pekar nu på samma underliggande minne som `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Tilldelning till `s2` gör att dess ursprungliga värde tappas.
///     // Utöver denna punkt får `s` inte längre användas, eftersom det underliggande minnet har frigjorts.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Tilldelning till `s` skulle leda till att det gamla värdet tappades igen, vilket resulterade i odefinierat beteende.
/////
///     // s= String::from("bar");//FEL
///
///     // `ptr::write` kan användas för att skriva över ett värde utan att tappa det.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SÄKERHET: den som ringer måste garantera att `src` är giltigt för läsning.
    // `src` kan inte överlappa `tmp` eftersom `tmp` just tilldelades på stacken som ett separat tilldelat objekt.
    //
    //
    // Eftersom vi precis skrev ett giltigt värde i `tmp`, kommer det garanterat att initialiseras ordentligt.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Läser värdet från `src` utan att flytta det.Detta lämnar minnet i `src` oförändrat.
///
/// Till skillnad från [`read`] fungerar `read_unaligned` med oinriktade pekare.
///
/// # Safety
///
/// Beteende är odefinierat om något av följande villkor bryts:
///
/// * `src` måste vara [valid] för läsning.
///
/// * `src` måste peka på ett korrekt initierat värde av typen `T`.
///
/// Liksom [`read`] skapar `read_unaligned` en bitvis kopia av `T`, oavsett om `T` är [`Copy`].
/// Om `T` inte är [`Copy`] kan [violate memory safety][read-ownership] använda både det returnerade värdet och värdet vid `*src`.
///
/// Observera att även om `T` har storlek `0` måste pekaren vara icke-NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## På `packed`-strukturer
///
/// Det är för närvarande omöjligt att skapa råa pekare till ofördelade fält i en packad struktur.
///
/// Att försöka skapa en rå pekare till ett `unaligned`-strukturfält med ett uttryck som `&packed.unaligned as *const FieldType` skapar en mellanliggande icke-inriktad referens innan den konverteras till en råpekare.
///
/// Att denna referens är tillfällig och omedelbart gjuten är betydelsefull eftersom kompilatorn alltid förväntar sig att referenser ska vara korrekt anpassade.
/// Som ett resultat orsakar användning av `&packed.unaligned as *const FieldType` omedelbart* odefinierat beteende * i ditt program.
///
/// Ett exempel på vad man inte ska göra och hur detta relaterar till `read_unaligned` är:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Här försöker vi ta adressen till ett 32-bitars heltal som inte är justerat.
///     let unaligned =
///         // Här skapas en tillfällig icke-inriktad referens som resulterar i odefinierat beteende oavsett om referensen används eller inte.
/////
///         &packed.unaligned
///         // Casting till en rå pekare hjälper inte;misstaget har redan hänt.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Åtkomst till ofördelade fält direkt med t.ex. `packed.unaligned` är dock säkert.
///
///
///
///
///
///
// FIXME: Uppdatera dokument baserat på resultatet av RFC #2582 och vänner.
/// # Examples
///
/// Läs ett användningsvärde från en bytebuffert:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SÄKERHET: den som ringer måste garantera att `src` är giltigt för läsning.
    // `src` kan inte överlappa `tmp` eftersom `tmp` just tilldelades på stacken som ett separat tilldelat objekt.
    //
    //
    // Eftersom vi precis skrev ett giltigt värde i `tmp`, kommer det garanterat att initialiseras ordentligt.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Skrivar över en minnesplats med det angivna värdet utan att läsa eller släppa det gamla värdet.
///
/// `write` tappar inte innehållet i `dst`.
/// Detta är säkert, men det kan läcka allokeringar eller resurser, så försiktighet bör iakttas för att inte skriva över ett objekt som ska tappas.
///
///
/// Dessutom tappar den inte `src`.Semantiskt flyttas `src` till den plats som `dst` pekar på.
///
/// Detta är lämpligt för att initialisera oinitialiserat minne eller skriva över minne som tidigare har varit [`read`] från.
///
/// # Safety
///
/// Beteende är odefinierat om något av följande villkor bryts:
///
/// * `dst` måste vara [valid] för skrivningar.
///
/// * `dst` måste vara ordentligt inriktade.Använd [`write_unaligned`] om så inte är fallet.
///
/// Observera att även om `T` har storlek `0`, måste pekaren vara icke-NULL och korrekt inriktad.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Manuellt implementera [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Skapa en bitvis kopia av värdet vid `a` i `tmp`.
///         let tmp = ptr::read(a);
///
///         // Avsluta vid denna punkt (antingen genom att uttryckligen återvända eller genom att anropa en funktion som panics) skulle orsaka att värdet i `tmp` tappas medan samma värde fortfarande refereras av `a`.
///         // Detta kan utlösa odefinierat beteende om `T` inte är `Copy`.
/////
/////
///
///         // Skapa en bitvis kopia av värdet vid `b` i `a`.
///         // Detta är säkert eftersom mutabla referenser inte kan alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Som ovan kan avsluta här utlösa odefinierat beteende eftersom samma värde refereras av `a` och `b`.
/////
///
///         // Flytta `tmp` till `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` har flyttats (`write` tar ägande av sitt andra argument), så inget tappas implicit här.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Vi ringer direkt till inneboende för att undvika funktionssamtal i den genererade koden eftersom `intrinsics::copy_nonoverlapping` är en omslagsfunktion.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SÄKERHET: den som ringer måste garantera att `dst` är giltigt för skrivning.
    // `dst` kan inte överlappa `src` eftersom den som ringer har mutbar åtkomst till `dst` medan `src` ägs av denna funktion.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Skrivar över en minnesplats med det angivna värdet utan att läsa eller släppa det gamla värdet.
///
/// Till skillnad från [`write()`] kan pekaren vara ojusterad.
///
/// `write_unaligned` tappar inte innehållet i `dst`.Detta är säkert, men det kan läcka allokeringar eller resurser, så försiktighet bör iakttas för att inte skriva över ett objekt som ska tappas.
///
/// Dessutom tappar den inte `src`.Semantiskt flyttas `src` till den plats som `dst` pekar på.
///
/// Detta är lämpligt för att initiera oinitialiserat minne eller skriva över minne som tidigare har lästs med [`read_unaligned`].
///
/// # Safety
///
/// Beteende är odefinierat om något av följande villkor bryts:
///
/// * `dst` måste vara [valid] för skrivningar.
///
/// Observera att även om `T` har storlek `0` måste pekaren vara icke-NULL.
///
/// [valid]: self#safety
///
/// ## På `packed`-strukturer
///
/// Det är för närvarande omöjligt att skapa råa pekare till ofördelade fält i en packad struktur.
///
/// Att försöka skapa en rå pekare till ett `unaligned`-strukturfält med ett uttryck som `&packed.unaligned as *const FieldType` skapar en mellanliggande icke-inriktad referens innan den konverteras till en råpekare.
///
/// Att denna referens är tillfällig och omedelbart gjuten är betydelsefull eftersom kompilatorn alltid förväntar sig att referenser ska vara korrekt anpassade.
/// Som ett resultat orsakar användning av `&packed.unaligned as *const FieldType` omedelbart* odefinierat beteende * i ditt program.
///
/// Ett exempel på vad man inte ska göra och hur detta relaterar till `write_unaligned` är:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Här försöker vi ta adressen till ett 32-bitars heltal som inte är justerat.
///     let unaligned =
///         // Här skapas en tillfällig icke-inriktad referens som resulterar i odefinierat beteende oavsett om referensen används eller inte.
/////
///         &mut packed.unaligned
///         // Casting till en rå pekare hjälper inte;misstaget har redan hänt.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Åtkomst till ofördelade fält direkt med t.ex. `packed.unaligned` är dock säkert.
///
///
///
///
///
///
///
///
///
// FIXME: Uppdatera dokument baserat på resultatet av RFC #2582 och vänner.
/// # Examples
///
/// Skriv ett användningsvärde till en bytebuffert:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SÄKERHET: den som ringer måste garantera att `dst` är giltigt för skrivning.
    // `dst` kan inte överlappa `src` eftersom den som ringer har mutbar åtkomst till `dst` medan `src` ägs av denna funktion.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Vi ringer det inneboende direkt för att undvika funktionssamtal i den genererade koden.
        intrinsics::forget(src);
    }
}

/// Utför en flyktig avläsning av värdet från `src` utan att flytta det.Detta lämnar minnet i `src` oförändrat.
///
/// Flyktiga operationer är avsedda att fungera på I/O-minne och garanteras att de inte elideras eller ordnas av kompilatorn över andra flyktiga operationer.
///
/// # Notes
///
/// Rust har för närvarande inte en noggrant och formellt definierad minnesmodell, så den exakta semantiken för vad "volatile" betyder här kan ändras över tid.
/// Med detta sagt kommer semantiken nästan alltid att bli ganska lik [C11's definition of volatile][c11].
///
/// Kompilatorn bör inte ändra den relativa ordningen eller antalet flyktiga minnesoperationer.
/// Flyktiga minnesoperationer på nollstorlekstyper (t.ex. om en nollstorlekstyp skickas till `read_volatile`) är emellertid noops och kan ignoreras.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Beteende är odefinierat om något av följande villkor bryts:
///
/// * `src` måste vara [valid] för läsning.
///
/// * `src` måste vara ordentligt inriktade.
///
/// * `src` måste peka på ett korrekt initierat värde av typen `T`.
///
/// Liksom [`read`] skapar `read_volatile` en bitvis kopia av `T`, oavsett om `T` är [`Copy`].
/// Om `T` inte är [`Copy`] kan [violate memory safety][read-ownership] använda både det returnerade värdet och värdet vid `*src`.
/// Det är dock säkert felaktigt att lagra icke-['Copy']-typer i flyktigt minne.
///
/// Observera att även om `T` har storlek `0`, måste pekaren vara icke-NULL och korrekt inriktad.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Precis som i C, har huruvida en operation är flyktig ingen som helst betydelse för frågor som involverar samtidig åtkomst från flera trådar.Flyktiga åtkomster beter sig precis som icke-atomära åtkomster i det avseendet.
///
/// I synnerhet är ett lopp mellan en `read_volatile` och någon skrivoperation till samma plats odefinierat beteende.
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Inte panik för att hålla codegen påverkan mindre.
        abort();
    }
    // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Utför en flyktig skrivning av en minnesplats med det angivna värdet utan att läsa eller släppa det gamla värdet.
///
/// Flyktiga operationer är avsedda att fungera på I/O-minne och garanteras att de inte elideras eller ordnas av kompilatorn över andra flyktiga operationer.
///
/// `write_volatile` tappar inte innehållet i `dst`.Detta är säkert, men det kan läcka allokeringar eller resurser, så försiktighet bör iakttas för att inte skriva över ett objekt som ska tappas.
///
/// Dessutom tappar den inte `src`.Semantiskt flyttas `src` till den plats som `dst` pekar på.
///
/// # Notes
///
/// Rust har för närvarande inte en noggrant och formellt definierad minnesmodell, så den exakta semantiken för vad "volatile" betyder här kan ändras över tid.
/// Med detta sagt kommer semantiken nästan alltid att bli ganska lik [C11's definition of volatile][c11].
///
/// Kompilatorn bör inte ändra den relativa ordningen eller antalet flyktiga minnesoperationer.
/// Flyktiga minnesoperationer på nollstorlekstyper (t.ex. om en nollstorlekstyp skickas till `write_volatile`) är emellertid noops och kan ignoreras.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Beteende är odefinierat om något av följande villkor bryts:
///
/// * `dst` måste vara [valid] för skrivningar.
///
/// * `dst` måste vara ordentligt inriktade.
///
/// Observera att även om `T` har storlek `0`, måste pekaren vara icke-NULL och korrekt inriktad.
///
/// [valid]: self#safety
///
/// Precis som i C, har huruvida en operation är flyktig ingen som helst betydelse för frågor som involverar samtidig åtkomst från flera trådar.Flyktiga åtkomster beter sig precis som icke-atomära åtkomster i det avseendet.
///
/// I synnerhet är ett lopp mellan en `write_volatile` och andra operationer (läsning eller skrivning) på samma plats odefinierat beteende.
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Inte panik för att hålla codegen påverkan mindre.
        abort();
    }
    // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Rikta in pekaren `p`.
///
/// Beräkna förskjutning (i termer av element i `stride` steg) som måste tillämpas på pekaren `p` så att pekaren `p` skulle anpassas till `a`.
///
/// Note: Denna implementering har noggrant anpassats till inte panic.Det är UB för detta till panic.
/// Den enda verkliga förändringen som kan göras här är byte av `INV_TABLE_MOD_16` och tillhörande konstanter.
///
/// Om vi någonsin bestämmer oss för att göra det möjligt att ringa det inneboende med `a` som inte är en power-of-two, kommer det förmodligen att vara klokare att bara byta till en naiv implementering snarare än att försöka anpassa detta för att tillgodose den förändringen.
///
///
/// Eventuella frågor går till@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Direkt användning av dessa inneboende förbättrar kodegen betydligt på opt-level <=
    // 1, där metodversionerna av dessa operationer inte är inlinjerade.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Beräkna multiplikativ modulär invers av `x` modulo `m`.
    ///
    /// Denna implementering är skräddarsydd för `align_offset` och har följande förutsättningar:
    ///
    /// * `m` är en power-of-two;
    /// * `x < m`; (om `x ≥ m`, skicka in `x % m` istället)
    ///
    /// Implementering av denna funktion får inte panic.Någonsin.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Multiplikativ modulär inverterad tabell modulo 2⁴=16.
        ///
        /// Observera att denna tabell inte innehåller värden där invers inte finns (dvs. för `0⁻¹ mod 16`, `2⁻¹ mod 16`, etc.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo som `INV_TABLE_MOD_16` är avsedd för.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SÄKERHET: `m` krävs för att vara en power-of-two, därmed icke-noll.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Vi itererar "up" med följande formel:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // tills 2²ⁿ ≥ m.Då kan vi minska till önskad `m` genom att ta resultatet `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Observera att vi använder inslagningsoperationer här avsiktligt-originalformeln använder t.ex. subtraktion `mod n`.
                // Det är helt bra att göra dem `mod usize::MAX` istället, för vi tar ändå resultatet `mod n` i slutet.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SÄKERHET: `a` är en power-of-two, därför icke-noll.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` fall kan beräknas enklare genom `-p (mod a)`, men att göra det hämmar LLVM: s förmåga att välja instruktioner som `lea`.Istället beräknar vi
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // som distribuerar operationer runt den bärande, men pessimerar `and` tillräckligt för att LLVM ska kunna utnyttja de olika optimeringar den känner till.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Redan inriktad.Jippie!
        return 0;
    } else if stride == 0 {
        // Om pekaren inte är inriktad och elementet är nollstorlek, kommer ingen mängd element att justera pekaren någonsin.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SÄKERHET: a är power-of-two och därmed inte noll.steg==0 fall behandlas ovan.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SÄKERHET: gcdpow har en övre gräns som högst är antalet bitar i en storlek.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SÄKERHET: gcd är alltid större eller lika med 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Denna branch löser följande linjära kongruensekvation:
        //
        // ` p + so = 0 mod a `
        //
        // `p` här är pekarens värde, `s`, steg för `T`, `o` offset i `T`s, och `a`, den begärda justeringen.
        //
        // Med `g = gcd(a, s)` och ovanstående villkor som hävdar att `p` också är delbart med `g` kan vi beteckna `a' = a/g`, `s' = s/g`, `p' = p/g`, då blir detta ekvivalent med:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Den första termen är "the relative alignment of `p` to `a`" (dividerad med `g`), den andra termen är "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (återigen dividerad med `g`).
        //
        // Division med `g` är nödvändig för att göra det inversa välformat om `a` och `s` inte är samprimade.
        //
        // Dessutom är resultatet som produceras av denna lösning inte "minimal", så det är nödvändigt att ta resultatet `o mod lcm(s, a)`.Vi kan ersätta `lcm(s, a)` med bara en `a'`.
        //
        //
        //
        //
        //

        // SÄKERHET: `gcdpow` har en övre gräns som inte är större än antalet efterföljande 0-bitar i `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SÄKERHET: `a2` är icke-noll.Skiftning av `a` med `gcdpow` kan inte flytta ut någon av uppsättningsbitarna
        // i `a` (varav den har exakt en).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SÄKERHET: `gcdpow` har en övre gräns som inte är större än antalet efterföljande 0-bitar i `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SÄKERHET: `gcdpow` har en övre gräns som inte är större än antalet efterföljande 0-bitar
        // `a`.
        // Dessutom kan subtraktionen inte rinna över, eftersom `a2 = a >> gcdpow` alltid kommer att vara strikt större än `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SÄKERHET: `a2` är en power-of-two, som bevisats ovan.`s2` är strikt mindre än `a2`
        // eftersom `(s % a) >> gcdpow` är strikt mindre än `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Kan inte justeras alls.
    usize::MAX
}

/// Jämför råa pekare för jämlikhet.
///
/// Detta är detsamma som att använda `==`-operatören, men mindre generisk:
/// argumenten måste vara `*const T` råa pekare, inte något som implementerar `PartialEq`.
///
/// Detta kan användas för att jämföra `&T`-referenser (som tvingas implicit till `*const T`) med deras adress snarare än att jämföra de värden de pekar på (vilket är vad `PartialEq for &T`-implementeringen gör).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Skivor jämförs också efter längd (fettpekare):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits jämförs också genom deras implementering:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Pekare har lika adresser.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Objekt har lika adresser, men `Trait` har olika implementeringar.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Omvandla referensen till en `*const u8` jämförs med adress.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash en rå pekare.
///
/// Detta kan användas för att hash en `&T`-referens (som implicit tvingas till `*const T`) genom dess adress snarare än det värde den pekar på (vilket är vad `Hash for &T`-implementeringen gör).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls för funktionspekare
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Den mellanliggande gjutningen som storlek krävs för AVR
                // så att källfunktionspekarens adressutrymme bevaras i den slutliga funktionspekaren.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Den mellanliggande gjutningen som storlek krävs för AVR
                // så att källfunktionspekarens adressutrymme bevaras i den slutliga funktionspekaren.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Inga variadiska funktioner med 0 parametrar
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Skapa en `const` rå pekare till en plats utan att skapa en mellanreferens.
///
/// Att skapa en referens med `&`/`&mut` är endast tillåten om pekaren är korrekt inriktad och pekar på initialiserad data.
/// I fall där kraven inte uppfylls bör råa pekare användas istället.
/// `&expr as *const _` skapar dock en referens innan den kastas till en rå pekare, och den referensen är föremål för samma regler som alla andra referenser.
///
/// Detta makro kan skapa en rå pekare *utan* att först skapa en referens.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` skulle skapa en ojämn referens, och därmed vara odefinierad beteende!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Skapa en `mut` rå pekare till en plats utan att skapa en mellanreferens.
///
/// Att skapa en referens med `&`/`&mut` är endast tillåten om pekaren är korrekt inriktad och pekar på initialiserad data.
/// I fall där kraven inte uppfylls bör råa pekare användas istället.
/// `&mut expr as *mut _` skapar dock en referens innan den kastas till en rå pekare, och den referensen är föremål för samma regler som alla andra referenser.
///
/// Detta makro kan skapa en rå pekare *utan* att först skapa en referens.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` skulle skapa en ojämn referens, och därmed vara odefinierad beteende!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` tvingar kopiera fältet istället för att skapa en referens.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}