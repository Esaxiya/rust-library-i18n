#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Tillhandahåller pekarens metadatatyp för vilken typ som helst.
///
/// # Pekarens metadata
///
/// Rå pekartyper och referenstyper i Rust kan betraktas som gjorda av två delar:
/// en datapekare som innehåller värdets minnesadress och några metadata.
///
/// För statiska storlekar (som implementerar `Sized` traits) såväl som för `extern`-typer sägs pekare vara `tunna`: metadata är nollstorlek och dess typ är `()`.
///
///
/// Pekare till [dynamically-sized types][dst] sägs vara `breda` eller `feta`, de har metadata som inte är av storlek:
///
/// * För strukturer vars sista fält är en sommartid är metadata metadata för det sista fältet
/// * För `str`-typen är metadata längden i byte som `usize`
/// * För segmenttyper som `[T]` är metadata längden i artiklar som `usize`
/// * För trait-objekt som `dyn SomeTrait` är metadata [`DynMetadata<Self>`][DynMetadata] (t.ex. `DynMetadata<dyn SomeTrait>`)
///
/// I future kan Rust-språket få nya typer av typer som har olika pekmetadata.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Poängen med denna trait är dess `Metadata`-associerade typ, som är `()` eller `usize` eller `DynMetadata<_>` som beskrivs ovan.
/// Det implementeras automatiskt för alla typer.
/// Det kan antas implementeras i ett generiskt sammanhang, även utan motsvarande gräns.
///
/// # Usage
///
/// Rå pekare kan sönderdelas i dataadressen och metadatakomponenterna med deras [`to_raw_parts`]-metod.
///
/// Alternativt kan enbart metadata extraheras med [`metadata`]-funktionen.
/// En referens kan skickas till [`metadata`] och impliceras tvingas.
///
/// En (possibly-wide)-pekare kan sättas ihop från dess adress och metadata med [`from_raw_parts`] eller [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Typen för metadata i pekare och referenser till `Self`.
    #[lang = "metadata_type"]
    // NOTE: Håll trait bounds i `static_assert_expected_bounds_for_metadata`
    //
    // i `library/core/src/ptr/metadata.rs` synkroniserat med de här:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Pekare till typer som implementerar detta trait-alias är `tunna`.
///
/// Detta inkluderar statiskt-Storade typer och `extern`-typer.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: stabiliserar inte detta innan trait-alias är stabila på språket?
pub trait Thin = Pointee<Metadata = ()>;

/// Extrahera metadata-komponenten i en pekare.
///
/// Värden av typen `*mut T`, `&T` eller `&mut T` kan överföras direkt till denna funktion eftersom de implicit tvingas till `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SÄKERHET: Åtkomst till värdet från `PtrRepr`-kopplingen är säkert eftersom * konst T
    // och PtrComponents<T>har samma minneslayouter.
    // Endast std kan göra denna garanti.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Bildar en (possibly-wide) rå pekare från en dataadress och metadata.
///
/// Den här funktionen är säker men den returnerade pekaren är inte nödvändigtvis säker för avvikelse.
/// För skivor, se dokumentationen till [`slice::from_raw_parts`] för säkerhetskrav.
/// För trait-objekt måste metadata komma från en pekare till samma underliggande raderade typ.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SÄKERHET: Åtkomst till värdet från `PtrRepr`-kopplingen är säkert eftersom * konst T
    // och PtrComponents<T>har samma minneslayouter.
    // Endast std kan göra denna garanti.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Utför samma funktion som [`from_raw_parts`], förutom att en rå `*mut`-pekare returneras, i motsats till en rå `* const`-pekare.
///
///
/// Se dokumentationen för [`from_raw_parts`] för mer information.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SÄKERHET: Åtkomst till värdet från `PtrRepr`-kopplingen är säkert eftersom * konst T
    // och PtrComponents<T>har samma minneslayouter.
    // Endast std kan göra denna garanti.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Manuell implementering behövs för att undvika `T: Copy`-bunden.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Manuell implementering behövs för att undvika `T: Clone`-bunden.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Metadata för en `Dyn = dyn SomeTrait` trait-objekttyp.
///
/// Det är en pekare till en vtabell (virtuell samtalstabell) som representerar all nödvändig information för att manipulera den betongtyp som är lagrad i ett trait-objekt.
/// Vtabellen, särskilt den innehåller:
///
/// * typstorlek
/// * typjustering
/// * en pekare till typens `drop_in_place` impl (kan vara ett no-op för vanlig gammal data)
/// * pekare till alla metoder för typens implementering av trait
///
/// Observera att de tre första är speciella eftersom de är nödvändiga för att tilldela, släppa och fördela alla trait-objekt.
///
/// Det är möjligt att namnge denna struktur med en typparameter som inte är ett `dyn` trait-objekt (till exempel `DynMetadata<u64>`) men inte för att få ett meningsfullt värde för den strukturen.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Det vanliga prefixet för alla vtabeller.Det följs av funktionspekare för trait-metoder.
///
/// Privat implementeringsdetalj för `DynMetadata::size_of` etc.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Returnerar storleken på den typ som är associerad med denna vtabell.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Returnerar justeringen för den typ som är associerad med denna vtabell.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Returnerar storlek och justering tillsammans som en `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SÄKERHET: kompilatorn sände ut denna vtabell för en konkret Rust-typ som
        // är känt för att ha en giltig layout.Samma motiv som i `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Manuella impl. Behövs för att undvika `Dyn: $Trait`-gränser.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}