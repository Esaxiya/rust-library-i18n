#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Innehåller strukturdefinitioner för layouten för kompilerings inbyggda typer.
//!
//! De kan användas som mål för transmuterar i osäker kod för att manipulera de råa representationerna direkt.
//!
//!
//! Deras definition ska alltid matcha ABI definierad i `rustc_middle::ty::layout`.
//!

/// Representationen av ett trait-objekt som `&dyn SomeTrait`.
///
/// Denna struktur har samma layout som typer som `&dyn SomeTrait` och `Box<dyn AnotherTrait>`.
///
/// `TraitObject` garanteras att matcha layouter, men det är inte typen av trait-objekt (t.ex. att fälten inte är direkt tillgängliga på en `&dyn SomeTrait`) och inte heller styr den layouten (om du ändrar definitionen kommer inte `&dyn SomeTrait` att ändras).
///
/// Den är endast utformad för att användas av osäker kod som behöver manipulera detaljerna på låg nivå.
///
/// Det finns inget sätt att hänvisa till alla trait-objekt generiskt, så det enda sättet att skapa värden av denna typ är med funktioner som [`std::mem::transmute`][transmute].
/// På samma sätt är det enda sättet att skapa ett riktigt trait-objekt från ett `TraitObject`-värde med `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Syntetisering av ett trait-objekt med felaktiga typer-en där vtabellen inte motsvarar typen av det värde som datapekaren pekar på-leder sannolikt till odefinierat beteende.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // ett exempel trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // låt kompilatorn skapa ett trait-objekt
/// let object: &dyn Foo = &value;
///
/// // titta på den råa representationen
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // datapekaren är adressen till `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // konstruera ett nytt objekt, peka på en annan `i32`, var försiktig med att använda `i32` vtable från `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // det borde fungera precis som om vi hade konstruerat ett trait-objekt ur `other_value` direkt
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}