//! Den här modulen implementerar `Any` trait, vilket möjliggör dynamisk typning av vilken `'static`-typ som helst genom körtidsreflektion.
//!
//! `Any` i sig kan användas för att få en `TypeId` och har fler funktioner när den används som ett trait-objekt.
//! Som `&dyn Any` (ett lånat trait-objekt) har det metoderna `is` och `downcast_ref` för att testa om det inneslutna värdet är av en given typ och för att få en referens till det inre värdet som en typ.
//! Som `&mut dyn Any` finns det också `downcast_mut`-metoden för att få en förändrad referens till det inre värdet.
//! `Box<dyn Any>` lägger till `downcast`-metoden, som försöker konvertera till en `Box<T>`.
//! Se [`Box`]-dokumentationen för fullständiga detaljer.
//!
//! Observera att `&dyn Any` är begränsad till att testa om ett värde är av en specificerad betongtyp och kan inte användas för att testa om en typ implementerar en trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Smarta pekare och `dyn Any`
//!
//! En bit beteende att tänka på när du använder `Any` som ett trait-objekt, särskilt med typer som `Box<dyn Any>` eller `Arc<dyn Any>`, är att det bara att ringa `.type_id()` på värdet ger `TypeId` för *behållaren*, inte det underliggande trait-objektet.
//!
//! Detta kan undvikas genom att konvertera den smarta pekaren till en `&dyn Any` istället, som returnerar objektets `TypeId`.
//! Till exempel:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Det är mer troligt att du vill ha det här:
//! let actual_id = (&*boxed).type_id();
//! // ... än det här:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Tänk på en situation där vi vill logga ut ett värde som skickas till en funktion.
//! Vi vet vilket värde vi arbetar med implementerar Debug, men vi vet inte dess konkreta typ.Vi vill ge särskild behandling för vissa typer: i det här fallet skriva ut längden på strängvärden före deras värde.
//! Vi känner inte till den konkreta typen av vårt värde vid tidpunkten för kompilering, så vi måste använda reflektion i stället.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Loggerfunktion för alla typer som implementerar Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Försök att konvertera vårt värde till en `String`.
//!     // Om det lyckas, vill vi mata ut strängens längd och dess värde.
//!     // Om inte, är det en annan typ: skriv bara ut den smyckat.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Den här funktionen vill logga ut parametern innan den arbetar med den.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... göra något annat arbete
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Alla trait
///////////////////////////////////////////////////////////////////////////////

/// En trait för att efterlikna dynamisk typning.
///
/// De flesta typer implementerar `Any`.Men alla typer som innehåller en icke-"statisk" referens gör det inte.
/// Se [module-level documentation][mod] för mer information.
///
/// [mod]: crate::any
// Denna trait är inte osäker, även om vi förlitar oss på specifikationerna för den enda impl. `type_id`-funktionen i osäker kod (t.ex. `downcast`).Normalt skulle det vara ett problem, men eftersom den enda impl i `Any` är en filtimplementering kan ingen annan kod implementera `Any`.
//
// Vi skulle med rimlighet kunna göra denna trait osäker-det skulle inte orsaka brott, eftersom vi kontrollerar alla implementeringar-men vi väljer att inte göra det eftersom det inte är både nödvändigt och kan förvirra användarna om skillnaden mellan osäkra traits och osäkra metoder (dvs. `type_id` skulle fortfarande vara säkert att ringa, men vi skulle sannolikt vilja ange som sådana i dokumentationen).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Får `TypeId` av `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Förlängningsmetoder för alla trait-objekt.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Se till att resultatet av t.ex. anslutning av en tråd kan skrivas ut och därmed användas med `unwrap`.
// Kan så småningom inte längre behövas om leverans fungerar med uppkastning.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Returnerar `true` om rutan är densamma som `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Skaffa `TypeId` av den typ som denna funktion är instanserad med.
        let t = TypeId::of::<T>();

        // Få `TypeId` av typen i trait-objektet (`self`).
        let concrete = self.type_id();

        // Jämför båda `TypeId`s om jämställdhet.
        t == concrete
    }

    /// Returnerar viss referens till det inramade värdet om det är av typen `T`, eller `None` om det inte är det.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SÄKERHET: bara kontrollerat om vi pekar på rätt typ, och vi kan lita på
            // som kontrollerar för minnessäkerhet eftersom vi har implementerat Any för alla typer;inga andra impls kan existera eftersom de skulle strida mot vår impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Returnerar någon muterbar referens till det inramade värdet om det är av typen `T` eller `None` om det inte är det.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SÄKERHET: bara kontrollerat om vi pekar på rätt typ, och vi kan lita på
            // som kontrollerar för minnessäkerhet eftersom vi har implementerat Any för alla typer;inga andra impls kan existera eftersom de skulle strida mot vår impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Vidarebefordrar till metoden definierad på typen `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Vidarebefordrar till metoden definierad på typen `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Vidarebefordrar till metoden definierad på typen `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Vidarebefordrar till metoden definierad på typen `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Vidarebefordrar till metoden definierad på typen `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Vidarebefordrar till metoden definierad på typen `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID och dess metoder
///////////////////////////////////////////////////////////////////////////////

/// En `TypeId` representerar en globalt unik identifierare för en typ.
///
/// Varje `TypeId` är ett ogenomskinligt objekt som inte tillåter inspektion av vad som finns inuti men tillåter grundläggande operationer som kloning, jämförelse, utskrift och visning.
///
///
/// En `TypeId` är för närvarande endast tillgänglig för typer som tillskrivs `'static`, men denna begränsning kan tas bort i future.
///
/// Medan `TypeId` implementerar `Hash`, `PartialOrd` och `Ord` är det värt att notera att hash och beställning varierar mellan Rust-utgåvor.
/// Se upp för att lita på dem inuti din kod!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Returnerar `TypeId` av den typ som denna generiska funktion har initierats med.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Returnerar namnet på en typ som en strängskiva.
///
/// # Note
///
/// Detta är avsett för diagnostisk användning.
/// Det exakta innehållet och formatet för den returnerade strängen anges inte, förutom att det är en beskrivning av typen som är bäst.
/// Bland strängarna som `type_name::<Option<String>>()` kan returnera är till exempel `"Option<String>"` och `"std::option::Option<std::string::String>"`.
///
///
/// Den returnerade strängen får inte betraktas som en unik identifierare av en typ eftersom flera typer kan mappas till samma typnamn.
/// På samma sätt finns det ingen garanti för att alla delar av en typ kommer att visas i den returnerade strängen: till exempel är livstidsspecifikationer för närvarande inte inkluderade.
/// Dessutom kan utgången ändras mellan versionerna av kompilatorn.
///
/// Den nuvarande implementeringen använder samma infrastruktur som kompilerdiagnostik och debuginfo, men detta garanteras inte.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Returnerar namnet på typen av det pekade värdet som en strängskiva.
/// Detta är detsamma som `type_name::<T>()`, men kan användas där typen av variabel inte är lätt tillgänglig.
///
/// # Note
///
/// Detta är avsett för diagnostisk användning.Det exakta innehållet och formatet på strängen anges inte, förutom att det är en beskrivning av typen som är bäst.
/// `type_name_of_val::<Option<String>>(None)` kan till exempel returnera `"Option<String>"` eller `"std::option::Option<std::string::String>"`, men inte `"foobar"`.
///
/// Dessutom kan utgången ändras mellan versionerna av kompilatorn.
///
/// Denna funktion löser inte trait-objekt, vilket innebär att `type_name_of_val(&7u32 as &dyn Debug)` kan returnera `"dyn Debug"`, men inte `"u32"`.
///
/// Typnamnet bör inte betraktas som en unik typ av typ;
/// flera typer kan dela samma typnamn.
///
/// Den nuvarande implementeringen använder samma infrastruktur som kompilerdiagnostik och debuginfo, men detta garanteras inte.
///
/// # Examples
///
/// Skriver ut standard heltal och flottörtyper.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}