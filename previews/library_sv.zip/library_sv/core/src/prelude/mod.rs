//! Libcore prelude
//!
//! Den här modulen är avsedd för användare av libcore som inte länkar till libstd också.
//! Den här modulen importeras som standard när `#![no_std]` används på samma sätt som standardbibliotekets prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// 2015-versionen av kärnan prelude.
///
/// Se [module-level documentation](self) för mer information.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// 2018-versionen av kärnan prelude.
///
/// Se [module-level documentation](self) för mer information.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// 2021-versionen av kärnan prelude.
///
/// Se [module-level documentation](self) för mer information.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Lägg till fler saker.
}