//! Panic-stöd för libcore
//!
//! Kärnbiblioteket kan inte definiera panik, men det *förklarar* panik.
//! Detta innebär att funktionerna inuti libcore är tillåtna för panic, men för att vara användbara måste en uppströms crate definiera panik för att libcore ska kunna användas.
//! Det nuvarande gränssnittet för panik är:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Denna definition möjliggör panik med något allmänt meddelande, men det tillåter inte att misslyckas med ett `Box<Any>`-värde.
//! (`PanicInfo` innehåller bara en `&(dyn Any + Send)`, för vilken vi fyller i ett dummyvärde i `PanicInfo: : internal_constructor`.) Anledningen till detta är att libcore inte får tilldelas.
//!
//!
//! Den här modulen innehåller några andra panikfunktioner, men det här är bara nödvändiga langobjekt för kompilatorn.Alla panics kanaliseras genom denna funktion.
//! Den faktiska symbolen deklareras genom `#[panic_handler]`-attributet.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Den underliggande implementeringen av libcores `panic!`-makro när ingen formatering används.
#[cold]
// aldrig inline om inte panic_immediate_abort för att undvika uppblåst kod på samtalsplatserna så mycket som möjligt
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // behövs av codegen för panic vid överflöde och andra `Assert` MIR-terminatorer
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Använd Arguments::new_v1 istället för format_args! ("{}", Expr) för att eventuellt minska storleken.
    // Format_args!makro använder str's Display trait för att skriva expr, som kallar Formatter::pad, som måste rymma strängavkortning och stoppning (även om ingen används här).
    //
    // Användning av Arguments::new_v1 kan tillåta att kompilatorn utelämnar Formatter::pad från utdatabinären, vilket sparar upp till några kilobyte.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // behövs för konstbedömda panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // behövs av codegen för panic vid OOB array/slice-åtkomst
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Den underliggande implementeringen av libcores `panic!`-makro när formatering används.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // OBS Denna funktion passerar aldrig FFI-gränsen;Det är ett Rust-till-Rust-samtal som löses till `#[panic_handler]`-funktionen.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SÄKERHET: `panic_impl` definieras i säker Rust-kod och är därför säker att ringa.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Intern funktion för `assert_eq!`-och `assert_ne!`-makron
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}