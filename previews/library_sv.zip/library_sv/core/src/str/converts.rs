//! Sätt att skapa en `str` från bytesskiva.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Konverterar en bit byte till en strängskiva.
///
/// En strängskiva ([`&str`]) är gjord av byte ([`u8`]), och en bitskiva ([`&[u8]`][byteslice]) är gjord av byte, så den här funktionen omvandlas mellan de två.
/// Inte alla byte-skivor är giltiga strängskivor, dock: [`&str`] kräver att det är giltigt UTF-8.
/// `from_utf8()` kontrollerar att byte är giltiga UTF-8 och gör sedan konverteringen.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Om du är säker på att bytesskivan är giltig UTF-8 och du inte vill ådra dig giltighetskontrollens omkostnader, finns det en osäker version av den här funktionen, [`from_utf8_unchecked`], som har samma beteende men hoppar över kontrollen.
///
///
/// Om du behöver en `String` istället för en `&str`, överväg [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Eftersom du kan stack-allokera en `[u8; N]` och du kan ta en [`&[u8]`][byteslice] av den, är den här funktionen ett sätt att ha en stack-allokerad sträng.Det finns ett exempel på detta i avsnittet nedan.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Returnerar `Err` om segmentet inte är UTF-8 med en beskrivning av varför den angivna segmentet inte är UTF-8.
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// use std::str;
///
/// // några byte, i en vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Vi vet att dessa byte är giltiga, så använd bara `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Felaktiga byte:
///
/// ```
/// use std::str;
///
/// // några ogiltiga byte, i en vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Se dokumenten för [`Utf8Error`] för mer information om vilka typer av fel som kan returneras.
///
/// En "stack allocated string":
///
/// ```
/// use std::str;
///
/// // några byte i en stack-allokerad array
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Vi vet att dessa byte är giltiga, så använd bara `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SÄKERHET: Körde precis validering.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Konverterar en muterbar bitbit till en muterbar strängskiva.
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" som en muterbar vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Som vi vet är dessa byte giltiga kan vi använda `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Felaktiga byte:
///
/// ```
/// use std::str;
///
/// // Några ogiltiga byte i en muterbar vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Se dokumenten för [`Utf8Error`] för mer information om vilka typer av fel som kan returneras.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SÄKERHET: Körde precis validering.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Konverterar en bit byte till en strängskiva utan att kontrollera att strängen innehåller giltig UTF-8.
///
/// Se den säkra versionen, [`from_utf8`], för mer information.
///
/// # Safety
///
/// Denna funktion är osäker eftersom den inte kontrollerar att de byte som skickas till den är giltiga UTF-8.
/// Om denna begränsning bryts uppstår odefinierat beteende, eftersom resten av Rust antar att [`&str`] är giltiga UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// use std::str;
///
/// // några byte, i en vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SÄKERHET: den som ringer måste garantera att byten `v` är giltiga UTF-8.
    // Förlitar sig också på att `&str` och `&[u8]` har samma layout.
    unsafe { mem::transmute(v) }
}

/// Konverterar en bit bitar till en strängskiva utan att kontrollera att strängen innehåller giltig UTF-8;muterbar version.
///
///
/// Se den oföränderliga versionen, [`from_utf8_unchecked()`] för mer information.
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SÄKERHET: den som ringer måste garantera att byten `v`
    // är giltiga UTF-8, så cast till `*mut str` är säkert.
    // Dessutom är pekardereferensen säker eftersom den pekaren kommer från en referens som garanterat är giltig för skrivningar.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}