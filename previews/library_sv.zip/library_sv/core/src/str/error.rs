//! Definierar utf8-fel typ.

use crate::fmt;

/// Fel som kan uppstå när du försöker tolka en sekvens av [`u8`] som en sträng.
///
/// Som sådan använder `from_utf8`-familjen av funktioner och metoder för både [`String`] och [`&str`] s till exempel detta fel.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Den här filtypens metoder kan användas för att skapa funktioner som liknar `String::from_utf8_lossy` utan att allokera högminne:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Returnerar indexet i den angivna strängen till vilken giltig UTF-8 verifierades.
    ///
    /// Det är det maximala indexet så att `from_utf8(&input[..index])` skulle returnera `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// use std::str;
    ///
    /// // några ogiltiga byte, i en vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 returnerar en Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // den andra byten är ogiltig här
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Ger mer information om felet:
    ///
    /// * `None`: slutet på ingången nåddes oväntat.
    ///   `self.valid_up_to()` är 1 till 3 byte från slutet av ingången.
    ///   Om en byte-ström (t.ex. en fil eller ett nätverksuttag) avkodas stegvis kan detta vara en giltig `char` vars UTF-8-bytesekvens sträcker sig över flera bitar.
    ///
    ///
    /// * `Some(len)`: en oväntad byte påträffades.
    ///   Längden som tillhandahålls är den ogiltiga bytesekvensen som börjar vid indexet som ges av `valid_up_to()`.
    ///   Avkodning bör återupptas efter den sekvensen (efter att ha satt in en [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) vid avkodning med förlust.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Ett fel returneras när en `bool` med [`from_str`] analyseras misslyckas
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}