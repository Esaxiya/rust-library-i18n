//! Traits för omvandlingar mellan typer.
//!
//! traits i denna modul ger ett sätt att konvertera från en typ till en annan typ.
//! Varje trait har ett annat syfte:
//!
//! - Implementera [`AsRef`] trait för billiga referens-till-referens-konverteringar
//! - Implementera [`AsMut`] trait för billiga muterbara till muterbara omvandlingar
//! - Implementera [`From`] trait för att konsumera värde-till-värde-omvandlingar
//! - Implementera [`Into`] trait för att konsumera värde-till-värde-omvandlingar till typer utanför den nuvarande crate
//! - [`TryFrom`] och [`TryInto`] traits beter sig som [`From`] och [`Into`], men bör implementeras när konverteringen kan misslyckas.
//!
//! traits i denna modul används ofta som trait bounds för generiska funktioner så att argument av flera typer stöds.Se dokumentationen för varje trait för exempel.
//!
//! Som biblioteksförfattare bör du alltid föredra att implementera [`From<T>`][`From`] eller [`TryFrom<T>`][`TryFrom`] snarare än [`Into<U>`][`Into`] eller [`TryInto<U>`][`TryInto`], eftersom [`From`] och [`TryFrom`] ger större flexibilitet och erbjuder motsvarande [`Into`]-eller [`TryInto`]-implementeringar gratis tack vare en filtimplementering i standardbiblioteket.
//! När du riktar in dig mot en version före Rust 1.41 kan det vara nödvändigt att implementera [`Into`] eller [`TryInto`] direkt när du konverterar till en typ utanför den aktuella crate.
//!
//! # Generiska implementeringar
//!
//! - [`AsRef`] och [`AsMut`] autodereferens om den inre typen är en referens
//! - [`Från`]`<U>för T` innebär [`In till`]`</u><T><U>för U`</u>
//! - [`TryFrom`]`<U>för T` innebär [`TryInto`]`</u><T><U>för U`</u>
//! - [`From`] och [`Into`] är reflexiva, vilket innebär att alla typer kan `into` själva och `from` själva
//!
//! Se varje trait för användningsexempel.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Identitetsfunktionen.
///
/// Två saker är viktiga att notera om den här funktionen:
///
/// - Det motsvarar inte alltid en förslutning som `|x| x`, eftersom förslutningen kan tvinga `x` till en annan typ.
///
/// - Den flyttar ingången `x` som skickats till funktionen.
///
/// Även om det kan tyckas konstigt att ha en funktion som bara returnerar ingången, finns det några intressanta användningsområden.
///
///
/// # Examples
///
/// Använda `identity` för att göra ingenting i en sekvens av andra intressanta funktioner:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Låt oss låtsas att lägga till en är en intressant funktion.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Använda `identity` som ett "do nothing"-basfall i ett villkorligt:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Gör mer intressanta saker ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Använda `identity` för att behålla `Some`-varianterna av en iterator av `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Används för att göra en billig referens-till-referens-konvertering.
///
/// Denna trait liknar [`AsMut`] som används för att konvertera mellan muterbara referenser.
/// Om du behöver göra en kostsam konvertering är det bättre att implementera [`From`] med typ `&T` eller skriva en anpassad funktion.
///
/// `AsRef` har samma signatur som [`Borrow`], men [`Borrow`] skiljer sig åt i några få aspekter:
///
/// - Till skillnad från `AsRef` har [`Borrow`] en filt för alla `T` och kan användas för att acceptera antingen en referens eller ett värde.
/// - [`Borrow`] kräver också att [`Hash`], [`Eq`] och [`Ord`] för lånat värde motsvarar värdet på det ägda värdet.
/// Av den anledningen, om du bara vill låna ett enda fält i en struktur kan du implementera `AsRef`, men inte [`Borrow`].
///
/// **Note: Denna trait får inte misslyckas **.Om konverteringen kan misslyckas, använd en dedikerad metod som returnerar en [`Option<T>`] eller en [`Result<T, E>`].
///
/// # Generiska implementeringar
///
/// - `AsRef` autodereferenser om den inre typen är en referens eller en mutbar referens (t.ex.: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Genom att använda trait bounds kan vi acceptera argument av olika slag så länge de kan konverteras till den angivna typen `T`.
///
/// Till exempel: Genom att skapa en generisk funktion som tar en `AsRef<str>` uttrycker vi att vi vill acceptera alla referenser som kan konverteras till [`&str`] som ett argument.
/// Eftersom både [`String`] och [`&str`] implementerar `AsRef<str>` kan vi acceptera båda som inmatningsargument.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Utför omvandlingen.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Används för att göra en billig muterbar-till-muterbar referenskonvertering.
///
/// Denna trait liknar [`AsRef`] men används för att konvertera mellan muterbara referenser.
/// Om du behöver göra en kostsam konvertering är det bättre att implementera [`From`] med typ `&mut T` eller skriva en anpassad funktion.
///
/// **Note: Denna trait får inte misslyckas **.Om konverteringen kan misslyckas, använd en dedikerad metod som returnerar en [`Option<T>`] eller en [`Result<T, E>`].
///
/// # Generiska implementeringar
///
/// - `AsMut` auto-derferenser om den inre typen är en mutbar referens (t.ex.: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Genom att använda `AsMut` som trait bound för en generisk funktion kan vi acceptera alla muterbara referenser som kan konverteras till typ `&mut T`.
/// Eftersom [`Box<T>`] implementerar `AsMut<T>` kan vi skriva en funktion `add_one` som tar alla argument som kan konverteras till `&mut u64`.
/// Eftersom [`Box<T>`] implementerar `AsMut<T>` accepterar `add_one` även argument av typen `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Utför omvandlingen.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// En konvertering mellan värde och värde som förbrukar ingångsvärdet.Motsatsen till [`From`].
///
/// Man bör undvika att implementera [`Into`] och istället implementera [`From`].
/// Implementering av [`From`] ger automatiskt en implementering av [`Into`] tack vare filtimplementeringen i standardbiblioteket.
///
/// Föredrar att använda [`Into`] över [`From`] när du anger trait bounds på en generisk funktion för att säkerställa att typer som endast implementerar [`Into`] också kan användas.
///
/// **Note: Denna trait får inte misslyckas **.Om konverteringen kan misslyckas, använd [`TryInto`].
///
/// # Generiska implementeringar
///
/// - [`Från`]`<T>för U` innebär `Into<U> for T`
/// - [`Into`] är reflexiv, vilket innebär att `Into<T> for T` implementeras
///
/// # Implementering av [`Into`] för konverteringar till externa typer i gamla versioner av Rust
///
/// Före Rust 1.41, om destinationstypen inte var en del av den aktuella crate, kunde du inte implementera [`From`] direkt.
/// Ta till exempel den här koden:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Detta kommer inte att kompileras i äldre versioner av språket eftersom Rust s föräldralösa regler brukade vara lite strängare.
/// För att kringgå detta kan du implementera [`Into`] direkt:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Det är viktigt att förstå att [`Into`] inte ger en [`From`]-implementering (som [`From`] gör med [`Into`]).
/// Därför bör du alltid försöka implementera [`From`] och sedan falla tillbaka till [`Into`] om [`From`] inte kan implementeras.
///
/// # Examples
///
/// [`String`] implementerar [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// För att uttrycka att vi vill att en generisk funktion ska ta alla argument som kan konverteras till en specificerad typ `T`, kan vi använda en trait bound av [`Into`]`<T>".
///
/// Till exempel: Funktionen `is_hello` tar alla argument som kan omvandlas till en [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Utför omvandlingen.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Används för att göra värde-till-värde-omvandlingar medan du konsumerar ingångsvärdet.Det är det ömsesidiga med [`Into`].
///
/// Man bör alltid föredra att implementera `From` framför [`Into`] eftersom implementering av `From` automatiskt ger en implementering av [`Into`] tack vare filtimplementeringen i standardbiblioteket.
///
///
/// Implementera endast [`Into`] när du riktar in en version före Rust 1.41 och konverterar till en typ utanför den aktuella crate.
/// `From` kunde inte göra dessa typer av omvandlingar i tidigare versioner på grund av Rust s föräldralösa regler.
/// Se [`Into`] för mer information.
///
/// Föredrar att använda [`Into`] framför `From` när du anger trait bounds på en generisk funktion.
/// På detta sätt kan typer som direkt implementerar [`Into`] också användas som argument.
///
/// `From` är också mycket användbar vid felhantering.När du konstruerar en funktion som kan misslyckas har returtypen i allmänhet formen `Result<T, E>`.
/// `From` trait förenklar felhantering genom att tillåta en funktion att returnera en enda fel typ som inkapslar flera feltyper.Se "Examples"-avsnittet och [the book][book] för mer information.
///
/// **Note: Denna trait får inte misslyckas **.Om konverteringen kan misslyckas, använd [`TryFrom`].
///
/// # Generiska implementeringar
///
/// - `From<T> for U` antyder [`Into`]`<U>för T`</u>
/// - `From` är reflexiv, vilket innebär att `From<T> for T` implementeras
///
/// # Examples
///
/// [`String`] implementerar `From<&str>`:
///
/// En uttrycklig konvertering från en `&str` till en sträng görs enligt följande:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// När du utför felhantering är det ofta användbart att implementera `From` för din egen feltyp.
/// Genom att konvertera underliggande feltyper till vår egen anpassade feltyp som inkapslar den underliggande feltypen kan vi returnera en enda feltyp utan att förlora information om den underliggande orsaken.
/// '?'-operatören konverterar automatiskt den underliggande feltypen till vår anpassade feltyp genom att ringa till `Into<CliError>::into` som automatiskt tillhandahålls när `From` implementeras.
/// Kompilatorn kan sedan se vilken implementering av `Into` som ska användas.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Utför omvandlingen.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Ett försök till konvertering som förbrukar `self`, vilket kanske eller inte är dyrt.
///
/// Biblioteksförfattare bör vanligtvis inte direkt implementera denna trait, men föredrar att implementera [`TryFrom`] trait, som ger större flexibilitet och ger en motsvarande `TryInto`-implementering gratis, tack vare en filtimplementering i standardbiblioteket.
/// Mer information om detta finns i dokumentationen för [`Into`].
///
/// # Implementering av `TryInto`
///
/// Detta har samma begränsningar och resonemang som att implementera [`Into`], se där för detaljer.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Den typ som returneras i händelse av ett konverteringsfel.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Utför omvandlingen.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Enkla och säkra typkonverteringar som under vissa omständigheter kan misslyckas på ett kontrollerat sätt.Det är det ömsesidiga med [`TryInto`].
///
/// Detta är användbart när du gör en typkonvertering som trivialt kan lyckas men också kan behöva särskild hantering.
/// Det finns till exempel inget sätt att konvertera en [`i64`] till en [`i32`] med [`From`] trait, eftersom en [`i64`] kan innehålla ett värde som en [`i32`] inte kan representera och konverteringen skulle förlora data.
///
/// Detta kan hanteras genom att trunka [`i64`] till en [`i32`] (i huvudsak ge [`i64`]-värdet modulo [`i32::MAX`]) eller genom att helt enkelt returnera [`i32::MAX`], eller med någon annan metod.
/// [`From`] trait är avsedd för perfekta konverteringar, så `TryFrom` trait informerar programmeraren när en typkonvertering kan gå dåligt och låter dem bestämma hur de ska hantera den.
///
/// # Generiska implementeringar
///
/// - `TryFrom<T> for U` innebär [`TryInto`]`<U>för T`</u>
/// - [`try_from`] är reflexiv, vilket innebär att `TryFrom<T> for T` implementeras och inte kan misslyckas-den associerade `Error`-typen för att anropa `T::try_from()` på ett värde av typen `T` är [`Infallible`].
/// När [`!`]-typen är stabiliserad kommer [`Infallible`] och [`!`] att vara ekvivalenta.
///
/// `TryFrom<T>` kan implementeras enligt följande:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Som beskrivs implementerar [`i32`] `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Trunkerar `big_number` tyst, kräver detektering och hantering av trunkeringen efter det faktum.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Returnerar ett fel eftersom `big_number` är för stort för att passa i en `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Returnerar `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Den typ som returneras i händelse av ett konverteringsfel.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Utför omvandlingen.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// GENERISKA IMPLIKATIONER
////////////////////////////////////////////////////////////////////////////////

// Som hissar över&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Som hissar över &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): ersätt ovanstående impls för&/&mut med följande mer allmänna:
// // Som hissar över Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Storlek> AsRef <U>för D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut lyfter över &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): byt ut ovanstående impl för &mut med följande mer allmänna:
// // AsMut lyfter över DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Storlek> AsMut <U>för D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Från innebär in i
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Från (och därmed in i) är reflexiv
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Stabilitetsanmärkning:** Detta impl finns inte ännu, men vi är "reserving space" för att lägga till det i future.
/// Se [rust-lang/rust#64715][#64715] för mer information.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): gör en principfix istället.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom innebär TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Infallbara omvandlingar är semantiskt likvärdiga med felbara omvandlingar med obebodd fel.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// BETONA IMPL
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// NO-FEL FELTYP
////////////////////////////////////////////////////////////////////////////////

/// Feltypen för fel som aldrig kan hända.
///
/// Eftersom detta enum inte har någon variant kan ett värde av denna typ faktiskt aldrig existera.
/// Detta kan vara användbart för generiska API: er som använder [`Result`] och parametrerar feletypen för att indikera att resultatet alltid är [`Ok`].
///
/// Till exempel har [`TryFrom`] trait (konvertering som returnerar en [`Result`]) en filtimplementering för alla typer där en omvänd [`Into`]-implementering finns.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future-kompatibilitet
///
/// Detta enum har samma roll som [the `!`“never”type][never], vilket är instabilt i den här versionen av Rust.
/// När `!` är stabiliserat planerar vi att göra `Infallible` till ett typalias för det:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... och så småningom avskaffa `Infallible`.
///
/// Det finns dock ett fall där `!`-syntax kan användas innan `!` stabiliseras som en fullfjädrad typ: i positionen för en funktions returtyp.
/// Specifikt är det möjliga implementeringar för två olika funktionspekartyper:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Eftersom `Infallible` är enum är den här koden giltig.
/// Men när `Infallible` blir ett alias för never type, kommer de två `impl`erna att börja överlappa varför de inte tillåts av språkets trait-koherensregler.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}