//! Kompilatorens inneboende.
//!
//! Motsvarande definitioner finns i `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Motsvarande const-implementeringar finns i `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const inneboende
//!
//! Note: alla förändringar av konstensen hos inneboende ska diskuteras med språkgruppen.
//! Detta inkluderar förändringar i konstruktionens stabilitet.
//!
//! För att göra en inneboende användbar vid kompileringstid måste man kopiera implementeringen från <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> till `compiler/rustc_mir/src/interpret/intrinsics.rs` och lägga till en `#[rustc_const_unstable(feature = "foo", issue = "01234")]` till den inneboende.
//!
//!
//! Om en inneboende ska användas från en `const fn` med ett `rustc_const_stable`-attribut måste den inneboende attributet också vara `rustc_const_stable`.
//! En sådan ändring bör inte göras utan T-lang-samråd, eftersom den bakar en funktion till språket som inte kan replikeras i användarkod utan kompilatorstöd.
//!
//! # Volatiles
//!
//! Den flyktiga inneboendet tillhandahåller funktioner som är avsedda att fungera på I/O-minne, vilket garanterat inte kommer att omordnas av kompilatorn över andra flyktiga inneboende.Se LLVM-dokumentationen på [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Atomens inneboende ger vanliga atomoperationer på maskinord, med flera möjliga minnesordningar.De följer samma semantik som C++ 11.Se LLVM-dokumentationen på [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! En snabb uppdatering av minnesbeställning:
//!
//! * Förvärva, ett hinder för att förvärva ett lås.Efterföljande läsningar och skrivningar äger rum efter barriären.
//! * Släpp, ett hinder för att släppa ett lås.Föregående läsning och skrivning äger rum före barriären.
//! * Sekventiellt konsekventa, sekventiellt konsekventa operationer garanteras att ske i ordning.Detta är standardläget för att arbeta med atomtyper och motsvarar Java s `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Denna import används för att förenkla intra-doc-länkar
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SÄKERHET: se `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // OBS! Dessa inneboende tar råa pekare eftersom de muterar aliasminne, vilket inte är giltigt för varken `&` eller `&mut`.
    //

    /// Lagrar ett värde om det aktuella värdet är detsamma som `old`-värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `compare_exchange`-metoden genom att skicka [`Ordering::SeqCst`] som både `success`-och `failure`-parametrar.
    ///
    /// Till exempel, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrar ett värde om det aktuella värdet är detsamma som `old`-värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `compare_exchange`-metoden genom att skicka [`Ordering::Acquire`] som både `success`-och `failure`-parametrar.
    ///
    /// Till exempel, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrar ett värde om det aktuella värdet är detsamma som `old`-värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `compare_exchange`-metoden genom att passera [`Ordering::Release`] som `success` och [`Ordering::Relaxed`] som `failure`-parametrar.
    /// Till exempel, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrar ett värde om det aktuella värdet är detsamma som `old`-värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `compare_exchange`-metoden genom att passera [`Ordering::AcqRel`] som `success` och [`Ordering::Acquire`] som `failure`-parametrar.
    /// Till exempel, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrar ett värde om det aktuella värdet är detsamma som `old`-värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `compare_exchange`-metoden genom att skicka [`Ordering::Relaxed`] som både `success`-och `failure`-parametrar.
    ///
    /// Till exempel, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrar ett värde om det aktuella värdet är detsamma som `old`-värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `compare_exchange`-metoden genom att passera [`Ordering::SeqCst`] som `success` och [`Ordering::Relaxed`] som `failure`-parametrar.
    /// Till exempel, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrar ett värde om det aktuella värdet är detsamma som `old`-värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `compare_exchange`-metoden genom att passera [`Ordering::SeqCst`] som `success` och [`Ordering::Acquire`] som `failure`-parametrar.
    /// Till exempel, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrar ett värde om det aktuella värdet är detsamma som `old`-värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `compare_exchange`-metoden genom att passera [`Ordering::Acquire`] som `success` och [`Ordering::Relaxed`] som `failure`-parametrar.
    /// Till exempel, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrar ett värde om det aktuella värdet är detsamma som `old`-värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `compare_exchange`-metoden genom att passera [`Ordering::AcqRel`] som `success` och [`Ordering::Relaxed`] som `failure`-parametrar.
    /// Till exempel, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Lagrar ett värde om det aktuella värdet är detsamma som `old`-värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `compare_exchange_weak`-metoden genom att skicka [`Ordering::SeqCst`] som både `success`-och `failure`-parametrar.
    ///
    /// Till exempel, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrar ett värde om det aktuella värdet är detsamma som `old`-värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `compare_exchange_weak`-metoden genom att skicka [`Ordering::Acquire`] som både `success`-och `failure`-parametrar.
    ///
    /// Till exempel, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrar ett värde om det aktuella värdet är detsamma som `old`-värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `compare_exchange_weak`-metoden genom att passera [`Ordering::Release`] som `success` och [`Ordering::Relaxed`] som `failure`-parametrar.
    /// Till exempel, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrar ett värde om det aktuella värdet är detsamma som `old`-värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `compare_exchange_weak`-metoden genom att passera [`Ordering::AcqRel`] som `success` och [`Ordering::Acquire`] som `failure`-parametrar.
    /// Till exempel, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrar ett värde om det aktuella värdet är detsamma som `old`-värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `compare_exchange_weak`-metoden genom att skicka [`Ordering::Relaxed`] som både `success`-och `failure`-parametrar.
    ///
    /// Till exempel, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrar ett värde om det aktuella värdet är detsamma som `old`-värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `compare_exchange_weak`-metoden genom att passera [`Ordering::SeqCst`] som `success` och [`Ordering::Relaxed`] som `failure`-parametrar.
    /// Till exempel, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrar ett värde om det aktuella värdet är detsamma som `old`-värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `compare_exchange_weak`-metoden genom att passera [`Ordering::SeqCst`] som `success` och [`Ordering::Acquire`] som `failure`-parametrar.
    /// Till exempel, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrar ett värde om det aktuella värdet är detsamma som `old`-värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `compare_exchange_weak`-metoden genom att passera [`Ordering::Acquire`] som `success` och [`Ordering::Relaxed`] som `failure`-parametrar.
    /// Till exempel, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Lagrar ett värde om det aktuella värdet är detsamma som `old`-värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `compare_exchange_weak`-metoden genom att passera [`Ordering::AcqRel`] som `success` och [`Ordering::Relaxed`] som `failure`-parametrar.
    /// Till exempel, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Lägger till det aktuella värdet för pekaren.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `load`-metoden genom att passera [`Ordering::SeqCst`] som `order`.
    /// Till exempel, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Lägger till det aktuella värdet för pekaren.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `load`-metoden genom att passera [`Ordering::Acquire`] som `order`.
    /// Till exempel, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Lägger till det aktuella värdet för pekaren.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `load`-metoden genom att passera [`Ordering::Relaxed`] som `order`.
    /// Till exempel, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Lagrar värdet på den angivna minnesplatsen.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `store`-metoden genom att passera [`Ordering::SeqCst`] som `order`.
    /// Till exempel, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Lagrar värdet på den angivna minnesplatsen.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `store`-metoden genom att passera [`Ordering::Release`] som `order`.
    /// Till exempel, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Lagrar värdet på den angivna minnesplatsen.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `store`-metoden genom att passera [`Ordering::Relaxed`] som `order`.
    /// Till exempel, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Lagrar värdet på den angivna minnesplatsen och returnerar det gamla värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `swap`-metoden genom att passera [`Ordering::SeqCst`] som `order`.
    /// Till exempel, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lagrar värdet på den angivna minnesplatsen och returnerar det gamla värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `swap`-metoden genom att passera [`Ordering::Acquire`] som `order`.
    /// Till exempel, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lagrar värdet på den angivna minnesplatsen och returnerar det gamla värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `swap`-metoden genom att passera [`Ordering::Release`] som `order`.
    /// Till exempel, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lagrar värdet på den angivna minnesplatsen och returnerar det gamla värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `swap`-metoden genom att passera [`Ordering::AcqRel`] som `order`.
    /// Till exempel, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lagrar värdet på den angivna minnesplatsen och returnerar det gamla värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `swap`-metoden genom att passera [`Ordering::Relaxed`] som `order`.
    /// Till exempel, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Lägger till det aktuella värdet och returnerar det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_add`-metoden genom att passera [`Ordering::SeqCst`] som `order`.
    /// Till exempel, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lägger till det aktuella värdet och returnerar det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_add`-metoden genom att passera [`Ordering::Acquire`] som `order`.
    /// Till exempel, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lägger till det aktuella värdet och returnerar det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_add`-metoden genom att passera [`Ordering::Release`] som `order`.
    /// Till exempel, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lägger till det aktuella värdet och returnerar det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_add`-metoden genom att passera [`Ordering::AcqRel`] som `order`.
    /// Till exempel, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lägger till det aktuella värdet och returnerar det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_add`-metoden genom att passera [`Ordering::Relaxed`] som `order`.
    /// Till exempel, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Subtrahera från det aktuella värdet och returnera det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_sub`-metoden genom att passera [`Ordering::SeqCst`] som `order`.
    /// Till exempel, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Subtrahera från det aktuella värdet och returnera det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_sub`-metoden genom att passera [`Ordering::Acquire`] som `order`.
    /// Till exempel, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Subtrahera från det aktuella värdet och returnera det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_sub`-metoden genom att passera [`Ordering::Release`] som `order`.
    /// Till exempel, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Subtrahera från det aktuella värdet och returnera det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_sub`-metoden genom att passera [`Ordering::AcqRel`] som `order`.
    /// Till exempel, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Subtrahera från det aktuella värdet och returnera det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_sub`-metoden genom att passera [`Ordering::Relaxed`] som `order`.
    /// Till exempel, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitvis och med det aktuella värdet, returnerar det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_and`-metoden genom att passera [`Ordering::SeqCst`] som `order`.
    /// Till exempel, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis och med det aktuella värdet, returnerar det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_and`-metoden genom att passera [`Ordering::Acquire`] som `order`.
    /// Till exempel, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis och med det aktuella värdet, returnerar det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_and`-metoden genom att passera [`Ordering::Release`] som `order`.
    /// Till exempel, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis och med det aktuella värdet, returnerar det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_and`-metoden genom att passera [`Ordering::AcqRel`] som `order`.
    /// Till exempel, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis och med det aktuella värdet, returnerar det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_and`-metoden genom att passera [`Ordering::Relaxed`] som `order`.
    /// Till exempel, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitvis nand med det aktuella värdet och returnerar det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`AtomicBool`]-typen via `fetch_nand`-metoden genom att passera [`Ordering::SeqCst`] som `order`.
    /// Till exempel, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis nand med det aktuella värdet och returnerar det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`AtomicBool`]-typen via `fetch_nand`-metoden genom att passera [`Ordering::Acquire`] som `order`.
    /// Till exempel, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis nand med det aktuella värdet och returnerar det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`AtomicBool`]-typen via `fetch_nand`-metoden genom att passera [`Ordering::Release`] som `order`.
    /// Till exempel, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis nand med det aktuella värdet och returnerar det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`AtomicBool`]-typen via `fetch_nand`-metoden genom att passera [`Ordering::AcqRel`] som `order`.
    /// Till exempel, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis nand med det aktuella värdet och returnerar det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`AtomicBool`]-typen via `fetch_nand`-metoden genom att passera [`Ordering::Relaxed`] som `order`.
    /// Till exempel, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitvis eller med det aktuella värdet, returnerar det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_or`-metoden genom att passera [`Ordering::SeqCst`] som `order`.
    /// Till exempel, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis eller med det aktuella värdet, returnerar det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_or`-metoden genom att passera [`Ordering::Acquire`] som `order`.
    /// Till exempel, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis eller med det aktuella värdet, returnerar det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_or`-metoden genom att passera [`Ordering::Release`] som `order`.
    /// Till exempel, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis eller med det aktuella värdet, returnerar det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_or`-metoden genom att passera [`Ordering::AcqRel`] som `order`.
    /// Till exempel, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis eller med det aktuella värdet, returnerar det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_or`-metoden genom att passera [`Ordering::Relaxed`] som `order`.
    /// Till exempel, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitvis x eller med det aktuella värdet, och returnera det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_xor`-metoden genom att passera [`Ordering::SeqCst`] som `order`.
    /// Till exempel, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis x eller med det aktuella värdet, och returnera det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_xor`-metoden genom att passera [`Ordering::Acquire`] som `order`.
    /// Till exempel, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis x eller med det aktuella värdet, och returnera det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_xor`-metoden genom att passera [`Ordering::Release`] som `order`.
    /// Till exempel, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis x eller med det aktuella värdet, och returnera det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_xor`-metoden genom att passera [`Ordering::AcqRel`] som `order`.
    /// Till exempel, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis x eller med det aktuella värdet, och returnera det tidigare värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-typerna via `fetch_xor`-metoden genom att passera [`Ordering::Relaxed`] som `order`.
    /// Till exempel, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximalt med det aktuella värdet med en signerad jämförelse.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-signerade heltalstyper via `fetch_max`-metoden genom att skicka [`Ordering::SeqCst`] som `order`.
    /// Till exempel, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximalt med det aktuella värdet med en signerad jämförelse.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-signerade heltalstyper via `fetch_max`-metoden genom att skicka [`Ordering::Acquire`] som `order`.
    /// Till exempel, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximalt med det aktuella värdet med en signerad jämförelse.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-signerade heltalstyper via `fetch_max`-metoden genom att skicka [`Ordering::Release`] som `order`.
    /// Till exempel, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximalt med det aktuella värdet med en signerad jämförelse.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-signerade heltalstyper via `fetch_max`-metoden genom att skicka [`Ordering::AcqRel`] som `order`.
    /// Till exempel, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Max med det aktuella värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-signerade heltalstyper via `fetch_max`-metoden genom att skicka [`Ordering::Relaxed`] som `order`.
    /// Till exempel, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minst med det aktuella värdet med en signerad jämförelse.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-signerade heltalstyper via `fetch_min`-metoden genom att skicka [`Ordering::SeqCst`] som `order`.
    /// Till exempel, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minst med det aktuella värdet med en signerad jämförelse.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-signerade heltalstyper via `fetch_min`-metoden genom att skicka [`Ordering::Acquire`] som `order`.
    /// Till exempel, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minst med det aktuella värdet med en signerad jämförelse.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-signerade heltalstyper via `fetch_min`-metoden genom att skicka [`Ordering::Release`] som `order`.
    /// Till exempel, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minst med det aktuella värdet med en signerad jämförelse.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-signerade heltalstyper via `fetch_min`-metoden genom att skicka [`Ordering::AcqRel`] som `order`.
    /// Till exempel, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minst med det aktuella värdet med en signerad jämförelse.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`]-signerade heltalstyper via `fetch_min`-metoden genom att skicka [`Ordering::Relaxed`] som `order`.
    /// Till exempel, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minsta med det aktuella värdet med en osignerad jämförelse.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`] osignerade heltalstyper via `fetch_min`-metoden genom att passera [`Ordering::SeqCst`] som `order`.
    /// Till exempel, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minsta med det aktuella värdet med en osignerad jämförelse.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`] osignerade heltalstyper via `fetch_min`-metoden genom att passera [`Ordering::Acquire`] som `order`.
    /// Till exempel, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minsta med det aktuella värdet med en osignerad jämförelse.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`] osignerade heltalstyper via `fetch_min`-metoden genom att passera [`Ordering::Release`] som `order`.
    /// Till exempel, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minsta med det aktuella värdet med en osignerad jämförelse.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`] osignerade heltalstyper via `fetch_min`-metoden genom att passera [`Ordering::AcqRel`] som `order`.
    /// Till exempel, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minsta med det aktuella värdet med en osignerad jämförelse.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`] osignerade heltalstyper via `fetch_min`-metoden genom att passera [`Ordering::Relaxed`] som `order`.
    /// Till exempel, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Max med det aktuella värdet med en osignerad jämförelse.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`] osignerade heltalstyper via `fetch_max`-metoden genom att passera [`Ordering::SeqCst`] som `order`.
    /// Till exempel, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Max med det aktuella värdet med en osignerad jämförelse.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`] osignerade heltalstyper via `fetch_max`-metoden genom att passera [`Ordering::Acquire`] som `order`.
    /// Till exempel, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Max med det aktuella värdet med en osignerad jämförelse.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`] osignerade heltalstyper via `fetch_max`-metoden genom att passera [`Ordering::Release`] som `order`.
    /// Till exempel, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Max med det aktuella värdet med en osignerad jämförelse.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`] osignerade heltalstyper via `fetch_max`-metoden genom att passera [`Ordering::AcqRel`] som `order`.
    /// Till exempel, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Max med det aktuella värdet med en osignerad jämförelse.
    ///
    /// Den stabiliserade versionen av denna inneboende är tillgänglig på [`atomic`] osignerade heltalstyper via `fetch_max`-metoden genom att passera [`Ordering::Relaxed`] som `order`.
    /// Till exempel, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch`-inneboende är en ledtråd till kodgeneratorn för att infoga en prefetch-instruktion om den stöds;annars är det ett no-op.
    /// Förhämtningar har ingen inverkan på programmets beteende men kan ändra dess prestandaegenskaper.
    ///
    /// `locality`-argumentet måste vara ett konstant heltal och är en tidsmässig lokalitetsspecifikator som sträcker sig från (0), ingen lokalitet, till (3), extremt lokalt i cache.
    ///
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch`-inneboende är en ledtråd till kodgeneratorn för att infoga en prefetch-instruktion om den stöds;annars är det ett no-op.
    /// Förhämtningar har ingen inverkan på programmets beteende men kan ändra dess prestandaegenskaper.
    ///
    /// `locality`-argumentet måste vara ett konstant heltal och är en tidsmässig lokalitetsspecifikator som sträcker sig från (0), ingen lokalitet, till (3), extremt lokalt i cache.
    ///
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch`-inneboende är en ledtråd till kodgeneratorn för att infoga en prefetch-instruktion om den stöds;annars är det ett no-op.
    /// Förhämtningar har ingen inverkan på programmets beteende men kan ändra dess prestandaegenskaper.
    ///
    /// `locality`-argumentet måste vara ett konstant heltal och är en tidsmässig lokalitetsspecifikator som sträcker sig från (0), ingen lokalitet, till (3), extremt lokalt i cache.
    ///
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch`-inneboende är en ledtråd till kodgeneratorn för att infoga en prefetch-instruktion om den stöds;annars är det ett no-op.
    /// Förhämtningar har ingen inverkan på programmets beteende men kan ändra dess prestandaegenskaper.
    ///
    /// `locality`-argumentet måste vara ett konstant heltal och är en tidsmässig lokalitetsspecifikator som sträcker sig från (0), ingen lokalitet, till (3), extremt lokalt i cache.
    ///
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Ett atomstaket.
    ///
    /// Den stabiliserade versionen av denna inneboende finns i [`atomic::fence`] genom att passera [`Ordering::SeqCst`] som `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Ett atomstaket.
    ///
    /// Den stabiliserade versionen av denna inneboende finns i [`atomic::fence`] genom att passera [`Ordering::Acquire`] som `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Ett atomstaket.
    ///
    /// Den stabiliserade versionen av denna inneboende finns i [`atomic::fence`] genom att passera [`Ordering::Release`] som `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Ett atomstaket.
    ///
    /// Den stabiliserade versionen av denna inneboende finns i [`atomic::fence`] genom att passera [`Ordering::AcqRel`] som `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// En minnesbarriär endast för kompilatorn.
    ///
    /// Minnesåtkomst kommer aldrig att ordnas igenom denna barriär av kompilatorn, men inga instruktioner kommer att ges ut för den.
    /// Detta är lämpligt för operationer på samma tråd som kan förhindras, till exempel vid interaktion med signalhanterare.
    ///
    /// Den stabiliserade versionen av denna inneboende finns i [`atomic::compiler_fence`] genom att passera [`Ordering::SeqCst`] som `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// En minnesbarriär endast för kompilatorn.
    ///
    /// Minnesåtkomst kommer aldrig att ordnas igenom denna barriär av kompilatorn, men inga instruktioner kommer att ges ut för den.
    /// Detta är lämpligt för operationer på samma tråd som kan förhindras, till exempel vid interaktion med signalhanterare.
    ///
    /// Den stabiliserade versionen av denna inneboende finns i [`atomic::compiler_fence`] genom att passera [`Ordering::Acquire`] som `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// En minnesbarriär endast för kompilatorn.
    ///
    /// Minnesåtkomst kommer aldrig att ordnas igenom denna barriär av kompilatorn, men inga instruktioner kommer att ges ut för den.
    /// Detta är lämpligt för operationer på samma tråd som kan förhindras, till exempel vid interaktion med signalhanterare.
    ///
    /// Den stabiliserade versionen av denna inneboende finns i [`atomic::compiler_fence`] genom att passera [`Ordering::Release`] som `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// En minnesbarriär endast för kompilatorn.
    ///
    /// Minnesåtkomst kommer aldrig att ordnas igenom denna barriär av kompilatorn, men inga instruktioner kommer att ges ut för den.
    /// Detta är lämpligt för operationer på samma tråd som kan förhindras, till exempel vid interaktion med signalhanterare.
    ///
    /// Den stabiliserade versionen av denna inneboende finns i [`atomic::compiler_fence`] genom att passera [`Ordering::AcqRel`] som `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magisk inneboende som får sin mening från attribut som är kopplade till funktionen.
    ///
    /// Till exempel använder dataflödet detta för att injicera statiska påståenden så att `rustc_peek(potentially_uninitialized)` faktiskt skulle dubbelkontrollera att dataflödet verkligen beräknade att det inte har initierats vid den punkten i kontrollflödet.
    ///
    ///
    /// Denna inneboende bör inte användas utanför kompilatorn.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Avbryter genomförandet av processen.
    ///
    /// En mer användarvänlig och stabil version av denna operation är [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Informerar optimizer att denna punkt i koden inte kan nås, vilket möjliggör ytterligare optimeringar.
    ///
    /// OBS! Detta skiljer sig väldigt mycket från `unreachable!()`-makrot: Till skillnad från makrot, som panics när det körs, är det *odefinierat beteende* att nå kod markerad med denna funktion.
    ///
    ///
    /// Den stabiliserade versionen av denna inneboende är [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Informerar optimeraren om att ett villkor alltid är sant.
    /// Om villkoret är falskt är beteendet odefinierat.
    ///
    /// Ingen kod genereras för detta inneboende, men optimeraren försöker bevara den (och dess tillstånd) mellan passagerna, vilket kan störa optimeringen av omgivande kod och minska prestanda.
    /// Det ska inte användas om invarianten kan upptäckas av optimeraren ensam, eller om den inte möjliggör några betydande optimeringar.
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Tips till kompilatorn att branch villkor sannolikt är sant.
    /// Returnerar det värde som skickats till det.
    ///
    /// All annan användning än med `if`-uttalanden kommer troligen inte att ha någon effekt.
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Tips till kompilatorn att villkoret för branch sannolikt är falskt.
    /// Returnerar det värde som skickats till det.
    ///
    /// All annan användning än med `if`-uttalanden kommer troligen inte att ha någon effekt.
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Utför en brytpunktsfälla för inspektion av en felsökare.
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    pub fn breakpoint();

    /// Storleken på en typ i byte.
    ///
    /// Mer specifikt är detta förskjutningen i byte mellan på varandra följande föremål av samma typ, inklusive inriktningspolstring.
    ///
    ///
    /// Den stabiliserade versionen av denna inneboende är [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Minsta inriktning för en typ.
    ///
    /// Den stabiliserade versionen av denna inneboende är [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Den föredragna inriktningen av en typ.
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Storleken på det refererade värdet i byte.
    ///
    /// Den stabiliserade versionen av denna inneboende är [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Den erforderliga justeringen av det refererade värdet.
    ///
    /// Den stabiliserade versionen av denna inneboende är [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Hämtar en statisk strängskiva som innehåller namnet på en typ.
    ///
    /// Den stabiliserade versionen av denna inneboende är [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Hämtar en identifierare som är globalt unik för den angivna typen.
    /// Denna funktion returnerar samma värde för en typ oavsett vilken crate den anropas i.
    ///
    ///
    /// Den stabiliserade versionen av denna inneboende är [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// En vakt för osäkra funktioner som aldrig kan utföras om `T` är obebodd:
    /// Detta gör statiskt antingen panic, eller gör ingenting.
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Ett skydd för osäkra funktioner som aldrig kan köras om `T` inte tillåter nollinitiering: Detta kommer statiskt antingen panic eller göra ingenting.
    ///
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    pub fn assert_zero_valid<T>();

    /// Ett skydd för osäkra funktioner som aldrig kan köras om `T` har ogiltiga bitmönster: Detta kommer statiskt antingen att panic eller göra ingenting.
    ///
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    pub fn assert_uninit_valid<T>();

    /// Hänvisar till en statisk `Location` som anger var den anropades.
    ///
    /// Överväg att använda [`core::panic::Location::caller`](crate::panic::Location::caller) istället.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Flyttar ett värde utanför räckvidden utan att köra dropplim.
    ///
    /// Detta existerar enbart för [`mem::forget_unsized`];normal `forget` använder istället `ManuallyDrop`.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Omtolkar bitarna av ett värde av en typ som en annan typ.
    ///
    /// Båda typerna måste ha samma storlek.
    /// Varken originalet eller resultatet kan vara en [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` är semantiskt ekvivalent med en bitvis flyttning av en typ till en annan.Den kopierar bitarna från källvärdet till destinationsvärdet och glömmer sedan originalet.
    /// Det motsvarar C: s `memcpy` under huven, precis som `transmute_copy`.
    ///
    /// Eftersom `transmute` är en byvärdesoperation är det inte ett problem att justera de *transmuterade värdena*.
    /// Som med alla andra funktioner säkerställer kompilatorn att både `T` och `U` är korrekt inriktade.
    /// Men när du överför värden som *pekar någon annanstans*(som pekare, referenser, rutor ...), måste den som ringer se till att de riktade värdena justeras korrekt.
    ///
    /// `transmute` är **otroligt** osäker.Det finns ett stort antal sätt att orsaka [undefined behavior][ub] med denna funktion.`transmute` bör vara den absolut sista utväg.
    ///
    /// [nomicon](../../nomicon/transmutes.html) har ytterligare dokumentation.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Det finns några saker som `transmute` verkligen är användbart för.
    ///
    /// Omvandla en pekare till en funktionspekare.Detta är *inte* bärbart till maskiner där funktionspekare och datapekare har olika storlekar.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Förlänga en livstid eller förkorta en oförändrad livstid.Detta är avancerat, mycket osäkert Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Förtvivla inte: många användningar av `transmute` kan uppnås på andra sätt.
    /// Nedan följer vanliga applikationer av `transmute` som kan ersättas med säkrare konstruktioner.
    ///
    /// Omvandla rå bytes(`&[u8]`) till `u32`, `f64`, etc.:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // använd `u32::from_ne_bytes` istället
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // eller använd `u32::from_le_bytes` eller `u32::from_be_bytes` för att specificera ändligheten
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Omvandla en pekare till en `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Använd en `as`-gjutning istället
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Omvandla en `*mut T` till en `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Använd en reborrow istället
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Omvandla en `&mut T` till en `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Nu, sätt ihop `as` och återlåning, notera att kedjan av `as` `as` inte är övergående
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Omvandla en `&str` till en `&[u8]`:
    ///
    /// ```
    /// // detta är inte ett bra sätt att göra detta.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Du kan använda `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Eller använd bara en byte-sträng om du har kontroll över strängen bokstavligt
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Omvandla en `Vec<&T>` till en `Vec<Option<&T>>`.
    ///
    /// För att överföra den inre typen av innehållet i en container måste du se till att du inte bryter mot någon av behållarens invarianter.
    /// För `Vec` betyder det att både storlek *och justering* för de inre typerna måste matcha.
    /// Andra containrar kan förlita sig på storleken på typen, inriktningen eller till och med `TypeId`, i vilket fall transmutering inte alls skulle vara möjlig utan att bryta mot behållarens invarianter.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // klona vector eftersom vi kommer att återanvända dem senare
    /// let v_clone = v_orig.clone();
    ///
    /// // Använda transmute: detta förlitar sig på den ospecificerade datalayouten för `Vec`, vilket är en dålig idé och kan orsaka odefinierat beteende.
    /////
    /// // Det är dock ingen kopia.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Detta är det föreslagna, säkra sättet.
    /// // Det kopierar dock hela vector till en ny array.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Det här är det korrekta, osäkra sättet att kopiera "transmuting" till `Vec` utan att förlita sig på datalayouten.
    /// // Istället för att bokstavligen ringa `transmute` utför vi en pekare, men när det gäller att konvertera den ursprungliga inre typen (`&i32`) till den nya (`Option<&i32>`), har detta samma försiktighetsåtgärder.
    /////
    /// // Förutom informationen ovan, se även [`from_raw_parts`]-dokumentationen.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Uppdatera detta när vec_into_raw_parts är stabiliserat.
    ///     // Se till att originalet vector inte tappas.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Implementering av `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Det finns flera sätt att göra detta, och det finns flera problem med följande (transmute)-sätt.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // först: transmute är inte typsäkert;allt det kontrollerar är att T och
    ///         // Du har samma storlek.
    ///         // För det andra, här har du två muterbara referenser som pekar på samma minne.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Detta blir av med typsäkerhetsproblemen;`&mut *` ger* bara *dig en `&mut T` från en `&mut T` eller `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // dock har du fortfarande två muterbara referenser som pekar på samma minne.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Så här gör standardbiblioteket det.
    /// // Det här är den bästa metoden om du behöver göra något liknande
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Detta har nu tre muterbara referenser som pekar på samma minne.`slice`, rvalue ret.0 och rvalue ret.1.
    ///         // `slice` används aldrig efter `let ptr = ...`, och så kan man behandla det som "dead", och därför har du bara två riktiga mutabla skivor.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Även om detta gör den inneboende konst stabil, har vi lite anpassad kod i konst fn
    // kontroller som förhindrar dess användning inom `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Returnerar `true` om den faktiska typen som anges som `T` kräver dropplim;returnerar `false` om den faktiska typen som tillhandahålls för `T` implementerar `Copy`.
    ///
    ///
    /// Om den faktiska typen varken kräver dropplim eller implementerar `Copy`, är returvärdet för denna funktion ospecificerad.
    ///
    /// Den stabiliserade versionen av denna inneboende är [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Beräknar förskjutningen från en pekare.
    ///
    /// Detta implementeras som ett inneboende för att undvika att konvertera till och från ett heltal, eftersom konverteringen skulle kasta bort aliasinformation.
    ///
    /// # Safety
    ///
    /// Både startpekaren och den resulterande pekaren måste vara antingen i gränser eller en byte efter slutet av ett tilldelat objekt.
    /// Om endera pekaren är utanför gränserna eller aritmetisk överflöde inträffar kommer ytterligare användning av det returnerade värdet att leda till odefinierat beteende.
    ///
    ///
    /// Den stabiliserade versionen av denna inneboende är [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Beräknar förskjutningen från en pekare, eventuellt inslagning.
    ///
    /// Detta implementeras som ett inneboende för att undvika att konvertera till och från ett heltal, eftersom omvandlingen hämmar vissa optimeringar.
    ///
    /// # Safety
    ///
    /// Till skillnad från `offset`-inneboende, begränsar inte denna inneboende den resulterande pekaren att peka in i eller en byte förbi slutet av ett tilldelat objekt, och den sveper med tvås komplementaritmetik.
    /// Det resulterande värdet är inte nödvändigtvis giltigt för att användas för att få åtkomst till minne.
    ///
    /// Den stabiliserade versionen av denna inneboende är [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Motsvarar lämplig `llvm.memcpy.p0i8.0i8.*` inneboende, med en storlek på `count`*`size_of::<T>()` och en inriktning på
    ///
    /// `min_align_of::<T>()`
    ///
    /// Den flyktiga parametern är inställd på `true`, så den kommer inte att optimeras om inte storleken är lika med noll.
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Motsvarar lämplig `llvm.memmove.p0i8.0i8.*` inneboende, med en storlek på `count* size_of::<T>()` och en inriktning på
    ///
    /// `min_align_of::<T>()`
    ///
    /// Den flyktiga parametern är inställd på `true`, så den kommer inte att optimeras om inte storleken är lika med noll.
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Motsvarar lämplig `llvm.memset.p0i8.*` inneboende, med en storlek på `count* size_of::<T>()` och en inriktning på `min_align_of::<T>()`.
    ///
    ///
    /// Den flyktiga parametern är inställd på `true`, så den kommer inte att optimeras om inte storleken är lika med noll.
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Utför en flyktig belastning från `src`-pekaren.
    ///
    /// Den stabiliserade versionen av denna inneboende är [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Utför en flyktig butik till `dst`-pekaren.
    ///
    /// Den stabiliserade versionen av denna inneboende är [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Utför en flyktig belastning från `src`-pekaren. Pekaren behöver inte vara inriktad.
    ///
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Utför en flyktig butik till `dst`-pekaren.
    /// Pekaren behöver inte vara inriktad.
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Returnerar kvadratroten på en `f32`
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Returnerar kvadratroten på en `f64`
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Höjer en `f32` till ett heltal.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Höjer en `f64` till ett heltal.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Returnerar sinus på en `f32`.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Returnerar sinus på en `f64`.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Returnerar cosinus för en `f32`.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Returnerar cosinus för en `f64`.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Höjer en `f32` till en `f32`-effekt.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Höjer en `f64` till en `f64`-effekt.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Returnerar exponentialen för en `f32`.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Returnerar exponentialen för en `f64`.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Returnerar 2 höjda till kraften hos en `f32`.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Returnerar 2 höjda till kraften hos en `f64`.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Returnerar den naturliga logaritmen för en `f32`.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Returnerar den naturliga logaritmen för en `f64`.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Returnerar bas 10-logaritmen för en `f32`.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Returnerar bas 10-logaritmen för en `f64`.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Returnerar bas 2-logaritmen för en `f32`.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Returnerar bas 2-logaritmen för en `f64`.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Returnerar `a * b + c` för `f32`-värden.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Returnerar `a * b + c` för `f64`-värden.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Returnerar det absoluta värdet för en `f32`.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Returnerar det absoluta värdet för en `f64`.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Returnerar minst två `f32`-värden.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Returnerar minst två `f64`-värden.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Returnerar maximalt två `f32`-värden.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Returnerar maximalt två `f64`-värden.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Kopierar tecknet från `y` till `x` för `f32`-värden.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Kopierar tecknet från `y` till `x` för `f64`-värden.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Returnerar det största heltalet som är mindre än eller lika med en `f32`.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Returnerar det största heltalet som är mindre än eller lika med en `f64`.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Returnerar det minsta heltalet som är större än eller lika med en `f32`.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Returnerar det minsta heltalet som är större än eller lika med en `f64`.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Returnerar heltalet i en `f32`.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Returnerar heltalet i en `f64`.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Returnerar närmaste heltal till en `f32`.
    /// Kan höja ett felaktigt undantag från flytande punkter om argumentet inte är ett heltal.
    pub fn rintf32(x: f32) -> f32;
    /// Returnerar närmaste heltal till en `f64`.
    /// Kan höja ett felaktigt undantag från flytande punkter om argumentet inte är ett heltal.
    pub fn rintf64(x: f64) -> f64;

    /// Returnerar närmaste heltal till en `f32`.
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Returnerar närmaste heltal till en `f64`.
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Returnerar närmaste heltal till en `f32`.Avrundar halvvägsfall från noll.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Returnerar närmaste heltal till en `f64`.Avrundar halvvägsfall från noll.
    ///
    /// Den stabiliserade versionen av denna inneboende är
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Flyttillägg som möjliggör optimeringar baserat på algebraiska regler.
    /// Kan anta att insatserna är ändliga.
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Flyt subtraktion som möjliggör optimeringar baserat på algebraiska regler.
    /// Kan anta att insatserna är ändliga.
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Flytmultiplikation som möjliggör optimeringar baserat på algebraiska regler.
    /// Kan anta att insatserna är ändliga.
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Float division som möjliggör optimeringar baserat på algebraiska regler.
    /// Kan anta att insatserna är ändliga.
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Flytrest som tillåter optimeringar baserat på algebraiska regler.
    /// Kan anta att insatserna är ändliga.
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Konvertera med LLVMs fptoui/fptosi, som kan returnera undef för värden utanför intervallet
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabiliserad som [`f32::to_int_unchecked`] och [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Returnerar antalet bitar som ställts in i ett heltal `T`
    ///
    /// De stabiliserade versionerna av denna inneboende är tillgängliga på heltalets primitiva medel via `count_ones`-metoden.
    /// Till exempel,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Returnerar antalet ledande unset-bitar (zeroes) i ett heltal `T`.
    ///
    /// De stabiliserade versionerna av denna inneboende är tillgängliga på heltalets primitiva medel via `leading_zeros`-metoden.
    /// Till exempel,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// En `x` med värdet `0` returnerar bitbredden på `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Som `ctlz`, men extra osäker då den returnerar `undef` när den får en `x` med värdet `0`.
    ///
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Returnerar antalet efterföljande bitar (zeroes) i ett heltal `T`.
    ///
    /// De stabiliserade versionerna av denna inneboende är tillgängliga på heltalets primitiva medel via `trailing_zeros`-metoden.
    /// Till exempel,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// En `x` med värdet `0` returnerar bitbredden på `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Som `cttz`, men extra osäker då den returnerar `undef` när den får en `x` med värdet `0`.
    ///
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Omvandlar byten i ett heltal `T`.
    ///
    /// De stabiliserade versionerna av denna inneboende är tillgängliga på heltalets primitiva medel via `swap_bytes`-metoden.
    /// Till exempel,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Omvandlar bitarna i ett heltal `T`.
    ///
    /// De stabiliserade versionerna av denna inneboende är tillgängliga på heltalets primitiva medel via `reverse_bits`-metoden.
    /// Till exempel,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Utför markerat heltalstillägg.
    ///
    /// De stabiliserade versionerna av denna inneboende är tillgängliga på heltalets primitiva medel via `overflowing_add`-metoden.
    /// Till exempel,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Utför kontrollerad heltalssubtraktion
    ///
    /// De stabiliserade versionerna av denna inneboende är tillgängliga på heltalets primitiva medel via `overflowing_sub`-metoden.
    /// Till exempel,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Utför kontrollerad heltalsmultiplikation
    ///
    /// De stabiliserade versionerna av denna inneboende är tillgängliga på heltalets primitiva medel via `overflowing_mul`-metoden.
    /// Till exempel,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Utför en exakt uppdelning, vilket resulterar i odefinierat beteende där `x % y != 0` eller `y == 0` eller `x == T::MIN && y == -1`
    ///
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Utför en okontrollerad division, vilket resulterar i odefinierat beteende där `y == 0` eller `x == T::MIN && y == -1`
    ///
    ///
    /// Säkra omslag för detta inneboende finns tillgängliga på heltalets primitiva medel via `checked_div`-metoden.
    /// Till exempel,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Returnerar resten av en okontrollerad division, vilket resulterar i odefinierat beteende när `y == 0` eller `x == T::MIN && y == -1`
    ///
    ///
    /// Säkra omslag för detta inneboende finns tillgängliga på heltalets primitiva medel via `checked_rem`-metoden.
    /// Till exempel,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Utför en okontrollerad vänsterförskjutning, vilket resulterar i odefinierat beteende när `y < 0` eller `y >= N`, där N är bredden på T i bitar.
    ///
    ///
    /// Säkra omslag för detta inneboende finns tillgängliga på heltalets primitiva medel via `checked_shl`-metoden.
    /// Till exempel,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Utför en okontrollerad högerförskjutning, vilket resulterar i odefinierat beteende när `y < 0` eller `y >= N`, där N är bredden på T i bitar.
    ///
    ///
    /// Säkra omslag för detta inneboende finns tillgängliga på heltalets primitiva medel via `checked_shr`-metoden.
    /// Till exempel,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Returnerar resultatet av ett okontrollerat tillägg, vilket resulterar i odefinierat beteende när `x + y > T::MAX` eller `x + y < T::MIN`.
    ///
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Returnerar resultatet av en okontrollerad subtraktion, vilket resulterar i odefinierat beteende när `x - y > T::MAX` eller `x - y < T::MIN`.
    ///
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Returnerar resultatet av en okontrollerad multiplikation, vilket resulterar i odefinierat beteende när `x *y > T::MAX` eller `x* y < T::MIN`.
    ///
    ///
    /// Denna inneboende har inte en stabil motsvarighet.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Utför rotera åt vänster.
    ///
    /// De stabiliserade versionerna av denna inneboende är tillgängliga på heltalets primitiva medel via `rotate_left`-metoden.
    /// Till exempel,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Utför rotera åt höger.
    ///
    /// De stabiliserade versionerna av denna inneboende är tillgängliga på heltalets primitiva medel via `rotate_right`-metoden.
    /// Till exempel,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Returnerar (a + b) mod 2 <sup>N</sup>, där N är bredden på T i bitar.
    ///
    /// De stabiliserade versionerna av denna inneboende är tillgängliga på heltalets primitiva medel via `wrapping_add`-metoden.
    /// Till exempel,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Returnerar (a, b) mod 2 <sup>N</sup>, där N är bredden på T i bitar.
    ///
    /// De stabiliserade versionerna av denna inneboende är tillgängliga på heltalets primitiva medel via `wrapping_sub`-metoden.
    /// Till exempel,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Returnerar (a * b) mod 2 <sup>N</sup>, där N är bredden på T i bitar.
    ///
    /// De stabiliserade versionerna av denna inneboende är tillgängliga på heltalets primitiva medel via `wrapping_mul`-metoden.
    /// Till exempel,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Beräknar `a + b`, mättar vid numeriska gränser.
    ///
    /// De stabiliserade versionerna av denna inneboende är tillgängliga på heltalets primitiva medel via `saturating_add`-metoden.
    /// Till exempel,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Beräknar `a - b`, mättar vid numeriska gränser.
    ///
    /// De stabiliserade versionerna av denna inneboende är tillgängliga på heltalets primitiva medel via `saturating_sub`-metoden.
    /// Till exempel,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Returnerar värdet på diskriminanten för varianten i 'v';
    /// om `T` inte har någon diskriminant, returnerar `0`.
    ///
    /// Den stabiliserade versionen av denna inneboende är [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Returnerar antalet varianter av typen `T` gjutna till en `usize`;
    /// om `T` inte har några varianter, returneras `0`.Obebodda varianter kommer att räknas.
    ///
    /// Den att vara stabiliserade versionen av denna inneboende är [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust s "try catch"-konstruktion som åberopar funktionspekaren `try_fn` med datapekaren `data`.
    ///
    /// Det tredje argumentet är en funktion som kallas om en panic uppstår.
    /// Denna funktion tar datapekaren och en pekare till det målspecifika undantagsobjektet som fångades.
    ///
    /// För mer information se kompilatorns källa samt std s fångstimplementering.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Sänder ut en `!nontemporal`-butik enligt LLVM (se deras dokument).
    /// Kommer förmodligen aldrig att bli stabil.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Se dokumentation för `<*const T>::offset_from` för mer information.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Se dokumentation för `<*const T>::guaranteed_eq` för mer information.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Se dokumentation för `<*const T>::guaranteed_ne` för mer information.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Tilldela vid sammanställningstid.Bör inte anropas vid körning.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Vissa funktioner definieras här eftersom de av misstag blev tillgängliga i denna modul på stabilt.
// Se <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` faller också inom denna kategori, men det kan inte läggas in på grund av kontrollen att `T` och `U` har samma storlek.)
//

/// Kontrollerar om `ptr` är korrekt inriktad med avseende på `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kopierar `count *size_of::<T>()` byte från `src` till `dst`.Källan och destinationen måste* inte * överlappa varandra.
///
/// För minnesregioner som kan överlappa, använd [`copy`] istället.
///
/// `copy_nonoverlapping` är semantiskt ekvivalent med C: s [`memcpy`], men med argumentordningen bytt.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Beteende är odefinierat om något av följande villkor bryts:
///
/// * `src` måste vara [valid] för läsning av `count * size_of::<T>()` byte.
///
/// * `dst` måste vara [valid] för skrivning av `count * size_of::<T>()` byte.
///
/// * Både `src` och `dst` måste vara korrekt inriktade.
///
/// * Regionen minne som börjar vid `src` med storleken på `räknas *
///   storlek av: :<T>() `byte får *inte* överlappa minnesområdet som börjar vid `dst` med samma storlek.
///
/// Liksom [`read`] skapar `copy_nonoverlapping` en bitvis kopia av `T`, oavsett om `T` är [`Copy`].
/// Om `T` inte är [`Copy`], kan *både* värdena i regionen som börjar på `*src` och regionen som börjar vid `* dst` [violate memory safety][read-ownership].
///
///
/// Observera att även om den effektivt kopierade storleken (`count * size_of: :<T>()`) är `0`, pekarna måste vara icke-NULL och korrekt inriktade.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Manuellt implementera [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Flyttar alla element i `src` till `dst` och lämnar `src` tomt.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Se till att `dst` har tillräcklig kapacitet för att rymma hela `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Samtalet att kompensera är alltid säkert eftersom `Vec` aldrig tilldelar mer än `isize::MAX` byte.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Avkorta `src` utan att tappa innehållet.
///         // Vi gör detta först för att undvika problem om något längre ner i panics.
///         src.set_len(0);
///
///         // De två regionerna kan inte överlappa varandra eftersom föränderliga referenser inte alias, och två olika vektorer kan inte äga samma minne.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Meddela `dst` att det nu innehåller innehållet i `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Utför dessa kontroller endast vid körning
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Inte panik för att hålla codegen påverkan mindre.
        abort();
    }*/

    // SÄKERHET: säkerhetskontraktet för `copy_nonoverlapping` måste vara
    // upprätthålls av den som ringer.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Kopierar `count * size_of::<T>()` byte från `src` till `dst`.Källan och destinationen kan överlappa varandra.
///
/// Om källan och destinationen *aldrig* överlappar varandra kan [`copy_nonoverlapping`] användas istället.
///
/// `copy` är semantiskt ekvivalent med C: s [`memmove`], men med argumentordningen bytt.
/// Kopiering sker som om byte kopierades från `src` till en tillfällig matris och sedan kopierades från matrisen till `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Beteende är odefinierat om något av följande villkor bryts:
///
/// * `src` måste vara [valid] för läsning av `count * size_of::<T>()` byte.
///
/// * `dst` måste vara [valid] för skrivning av `count * size_of::<T>()` byte.
///
/// * Både `src` och `dst` måste vara korrekt inriktade.
///
/// Liksom [`read`] skapar `copy` en bitvis kopia av `T`, oavsett om `T` är [`Copy`].
/// Om `T` inte är [`Copy`] kan [violate memory safety][read-ownership] använda både värdena i regionen som börjar vid `*src` och regionen som börjar vid `* dst`.
///
///
/// Observera att även om den effektivt kopierade storleken (`count * size_of: :<T>()`) är `0`, pekarna måste vara icke-NULL och korrekt inriktade.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Skapa en Rust vector effektivt från en osäker buffert:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` måste vara rätt justerad för sin typ och inte noll.
/// /// * `ptr` måste vara giltigt för läsning av `elts` angränsande element av typen `T`.
/// /// * Dessa element får inte användas efter att ha anropat den här funktionen om inte `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SÄKERHET: Vår förutsättning säkerställer att källan är anpassad och giltig,
///     // och `Vec::with_capacity` säkerställer att vi har användbart utrymme för att skriva dem.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SÄKERHET: Vi skapade den med så mycket kapacitet tidigare,
///     // och den tidigare `copy` har initierat dessa element.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Utför dessa kontroller endast vid körning
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Inte panik för att hålla codegen påverkan mindre.
        abort();
    }*/

    // SÄKERHET: Säkerhetsavtalet för `copy` måste upprätthållas av den som ringer.
    unsafe { copy(src, dst, count) }
}

/// Ställer in `count * size_of::<T>()` byte minne som börjar på `dst` till `val`.
///
/// `write_bytes` liknar C: s [`memset`], men sätter `count * size_of::<T>()`-byte till `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Beteende är odefinierat om något av följande villkor bryts:
///
/// * `dst` måste vara [valid] för skrivning av `count * size_of::<T>()` byte.
///
/// * `dst` måste vara ordentligt inriktade.
///
/// Dessutom måste den som ringer se till att skriva `count * size_of::<T>()`-byte till den givna minnesregionen resulterar i ett giltigt värde på `T`.
/// Att använda en minnesregion skriven som en `T` som innehåller ett ogiltigt värde på `T` är odefinierat beteende.
///
/// Observera att även om den effektivt kopierade storleken (`count * size_of: :<T>()`) är `0`, pekaren måste vara icke-NULL och korrekt inriktad.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Skapa ett ogiltigt värde:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Läcker det tidigare hållna värdet genom att skriva över `Box<T>` med en nollpekare.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Vid denna tidpunkt använder eller släpper du `v` i odefinierat beteende.
/// // drop(v); // ERROR
///
/// // Även läcker `v` "uses" det, och därmed är odefinierat beteende.
/// // mem::forget(v); // ERROR
///
/// // I själva verket är `v` ogiltigt enligt grundläggande typlayoutvarianter, så *alla* operationer som rör den är odefinierat beteende.
/////
/// // låt v2 =v;//FEL
///
/// unsafe {
///     // Låt oss istället sätta in ett giltigt värde
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Nu är lådan bra
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SÄKERHET: Säkerhetsavtalet för `write_bytes` måste upprätthållas av den som ringer.
    unsafe { write_bytes(dst, val, count) }
}