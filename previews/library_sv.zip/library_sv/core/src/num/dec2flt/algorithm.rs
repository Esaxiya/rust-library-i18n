//! De olika algoritmerna från tidningen.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Antal signifikanta bitar i Fp
const P: u32 = 64;

// Vi lagrar helt enkelt den bästa approximationen för *alla* exponenter, så variabeln "h" och tillhörande förhållanden kan utelämnas.
// Detta byter prestanda för ett par kilobyte utrymme.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// I de flesta arkitekturer har flytpunktsoperationer en uttrycklig bitstorlek, därför beräknas beräkningens precision per operation.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// På x86 används x87 FPU för floatoperationer om SSE/SSE2-tillägg inte är tillgängliga.
// x87 FPU arbetar med 80 bitar precision som standard, vilket innebär att operationer kommer att runda till 80 bitar vilket gör att dubbel avrundning sker när värden så småningom representeras som
//
// 32/64 bitflottvärden.För att övervinna detta kan FPU-styrordet ställas in så att beräkningarna utförs med önskad precision.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// En struktur som används för att bevara FPU-styrordets ursprungliga värde så att det kan återställas när strukturen tappas.
    ///
    ///
    /// x87 FPU är ett 16-bitars register vars fält är följande:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Dokumentationen för alla fälten finns i IA-32 Architectures Software Developer's Manual (Volume 1).
    ///
    /// Det enda fältet som är relevant för följande kod är PC, Precision Control.
    /// Detta fält avgör precisionen för de operationer som utförs av FPU.
    /// Den kan ställas in på:
    ///  - 0b00, enstaka precision, dvs 32 bitar
    ///  - 0b10, dubbel precision dvs. 64-bitar
    ///  - 0b11, dubbel utökad precision dvs 80 bitar (standardläge) 0b01-värdet är reserverat och bör inte användas.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SÄKERHET: `fldcw`-instruktionen har granskats för att kunna fungera korrekt med
        // valfri `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Vi använder ATT-syntax för att stödja LLVM 8 och LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Ställer in FPU: s precisionsfält till `T` och returnerar en `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Beräkna värdet för Precision Control-fältet som är lämpligt för `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bitar
            8 => 0x0200, // 64 bitar
            _ => 0x0300, // standard, 80 bitar
        };

        // Få kontrollvärdets ursprungliga värde för att återställa det senare, när `FPUControlWord`-strukturen tappas SÄKERHET: `fnstcw`-instruktionen har granskats för att kunna fungera korrekt med alla `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Vi använder ATT-syntax för att stödja LLVM 8 och LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Ställ in kontrollordet på önskad precision.
        // Detta uppnås genom att maskera bort den gamla precisionen (bitar 8 och 9, 0x300) och ersätta den med den ovan angivna precisionsflaggan.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Den snabba vägen för Bellerophon med heltal och flottör i maskinstorlek.
///
/// Detta extraheras till en separat funktion så att det kan försökas innan en bignum konstrueras.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Vi jämför det exakta värdet med MAX_SIG nära slutet, detta är bara en snabb, billig avvisning (och frigör också resten av koden från att oroa sig för underflöde).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Den snabba vägen är avgörande för att aritmetiken avrundas till rätt antal bitar utan någon mellanliggande avrundning.
    // På x86 (utan SSE eller SSE2) kräver detta att x87 FPU-stacken ändras så att den direkt avrundas till 64/32-bit.
    // `set_precision`-funktionen tar hand om att ställa in precisionen på arkitekturer som kräver att den ställs in genom att ändra det globala tillståndet (som kontrollordet för x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Fallet e <0 kan inte vikas in i den andra branch.
    // Negativa krafter resulterar i en upprepande bråkdel i binär, som är rundade, vilket orsakar verkliga (och ibland ganska betydande!) Fel i slutresultatet.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algoritm Bellerophon är trivial kod motiverad av icke-trivial numerisk analys.
///
/// Den avrundar `` f '' till en flottör med 64 bitars signifikans och multiplicerar den med den bästa approximationen av `10^e` (i samma flytpunktsformat).Detta räcker ofta för att få rätt resultat.
/// Men när resultatet är nära halvvägs mellan två intilliggande (ordinary)-flottörer, betyder sammansatt avrundningsfel från att multiplicera två approximationer att resultatet kan vara av med några bitar.
/// När detta händer fixar iterativ algoritm R saker och ting.
///
/// Den handvågiga "close to halfway" görs exakt genom den numeriska analysen i papperet.
/// Med Clinger ord:
///
/// > Slop, uttryckt i enheter med minst signifikant bit, är en inkluderande gräns för felet
/// > ackumulerades under flytpunktberäkningen av approximationen till f * 10 ^ e.(Slop är
/// > inte en gräns för det sanna felet, men gränsar skillnaden mellan approximationen z och
/// > bästa möjliga uppskattning som använder p-bitar av betydelse.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Fall abs(e) <log5(2^N) finns i fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Är slopen tillräckligt stor för att göra skillnad när man avrundar till n bitar?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// En iterativ algoritm som förbättrar en flytande approximation av `f * 10^e`.
///
/// Varje iteration kommer en enhet på sista plats närmare, vilket naturligtvis tar väldigt lång tid att konvergera om `z0` till och med är lite avstängd.
/// Lyckligtvis, när den används som reserv för Bellerophon, är start approximationen avstängd av högst en ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Hitta positiva heltal `x`, `y` så att `x / y` är exakt `(f *10^e) / (m* 2^k)`.
        // Detta undviker inte bara att hantera tecknen på `e` och `k`, vi eliminerar också kraften hos två som är gemensamma för `10^e` och `2^k` för att göra siffrorna mindre.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Detta skrivs lite besvärligt eftersom våra bignum inte stöder negativa siffror, så vi använder det absoluta värdet + teckeninformation.
        // Multiplikationen med m_digits kan inte rinna över.
        // Om `x` eller `y` är tillräckligt stora för att vi behöver oroa oss för överflöde, är de också tillräckligt stora för att `make_ratio` har minskat fraktionen med en faktor 2 ^ 64 eller mer.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Behöver inte x längre, spara en clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Behöver fortfarande y, gör en kopia.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Med tanke på `x = f` och `y = m` där `f` representerar inmatade decimalsiffror som vanligt och `m` är betydelsen av en flytande approximation, gör förhållandet `x / y` lika med `(f *10^e) / (m* 2^k)`, eventuellt reducerat med en effekt på två som båda har gemensamt.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, förutom att vi minskar fraktionen med någon kraft på två.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Detta kan inte överflödas eftersom det kräver positivt `e` och negativt `k`, vilket bara kan hända för värden extremt nära 1, vilket innebär att `e` och `k` kommer att vara relativt små.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Det här kan inte heller rinna över, se ovan.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), reducerar igen med en gemensam effekt på två.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Konceptuellt är algoritm M det enklaste sättet att konvertera en decimal till en flottör.
///
/// Vi bildar ett förhållande som är lika med `f * 10^e` och slänger sedan in krafter på två tills det ger en giltig flottörbetydelse.
/// Den binära exponenten `k` är det antal gånger vi multiplicerade täljaren eller nämnaren med två, dvs `f *10^e` är alltid lika med `(u / v)* 2^k`.
/// När vi har fått reda på betydelse behöver vi bara runda genom att inspektera resten av uppdelningen, vilket görs i hjälpfunktioner längre ner.
///
///
/// Denna algoritm är super långsam, även med den optimering som beskrivs i `quick_start()`.
/// Det är dock det enklaste av algoritmerna att anpassa för resultat för överflöde, underflöde och subnormala.
/// Denna implementering tar över när Bellerophon och Algorithm R är överväldigade.
/// Det är enkelt att upptäcka underflöde och överflöd: förhållandet är fortfarande inte inom räckvidden, men minimum/maximum-exponenten har uppnåtts.
/// Vid överflöde returnerar vi helt enkelt oändligheten.
///
/// Att hantera underflöde och undernormaler är svårare.
/// Ett stort problem är att förhållandet, med minsta exponent, fortfarande kan vara för stort för en betydelse.
/// Se underflow() för mer information.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME möjlig optimering: generalisera big_to_fp så att vi kan göra motsvarande fp_to_float(big_to_fp(u)) här, bara utan den dubbla avrundningen.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Vi måste stanna vid minsta exponent, om vi väntar till `k < T::MIN_EXP_INT`, skulle vi ha en faktor två.
            // Tyvärr betyder det att vi måste specialfalla normala nummer med minsta exponent.
            // FIXME hittar en mer elegant formulering, men kör `tiny-pow10`-testet för att se till att det faktiskt är korrekt!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Hoppar över de flesta algoritm M-iterationer genom att kontrollera bitlängden.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Bitlängden är en uppskattning av bas två logaritmen och log(u / v) = log(u), log(v).
    // Uppskattningen är avstängd med högst 1, men alltid en underskattning, så felet på log(u) och log(v) är av samma tecken och avbryts (om båda är stora).
    // Därför är felet för log(u / v) högst ett också.
    // Målförhållandet är en där u/v ligger inom en betydelsefull betydelse.Således är vårt avslutningsvillkor log2(u / v) som är de betydande bitarna, plus/minus en.
    // FIXME Att titta på den andra biten kan förbättra uppskattningen och undvika några fler uppdelningar.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Underflöde eller subnormalt.Lämna det till huvudfunktionen.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Svämma över.Lämna det till huvudfunktionen.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Förhållandet är inte en betydelsefull betydelse med minsta exponent, så vi måste avrunda överflödiga bitar och justera exponenten därefter.
    // Det verkliga värdet ser nu ut så här:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(representerad av rem)
    //
    // Därför, när de avrundade bitarna är!= 0.5 ULP, bestämmer de avrundningen på egen hand.
    // När de är lika och resten är noll, måste värdet fortfarande avrundas uppåt.
    // Först när de avrundade bitarna är 1/2 och resten är noll, har vi en halv till jämn situation.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Vanlig rund-till-jämn, fördunkad genom att behöva runda baserat på resten av en uppdelning.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}