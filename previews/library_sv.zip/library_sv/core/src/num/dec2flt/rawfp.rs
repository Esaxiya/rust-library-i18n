//! Lite fiol på positiva IEEE 754-flottörer.Negativa siffror är inte och behöver inte hanteras.
//! Normala flytpunktsnummer har en kanonisk representation som (frac, exp) så att värdet är 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) där N är antalet bitar.
//!
//! Undernormaler är lite annorlunda och konstiga, men samma princip gäller.
//!
//! Här representerar vi emellertid dem som (sig, k) med f positivt, så att värdet är f *
//! 2 <sup>e</sup> .Förutom att "hidden bit" uttrycks, ändrar detta exponenten genom den så kallade mantissaskiftet.
//!
//! Sagt på ett annat sätt, normalt är floats skrivna som (1) men här skrivs de som (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Vi kallar (1) för **fraktionerad representation** och (2) för **integrerad representation**.
//!
//! Många funktioner i den här modulen hanterar bara normala nummer.Dec2flt-rutinerna tar konservativt den universellt korrekta långsamma vägen (algoritm M) för mycket små och mycket stora antal.
//! Den algoritmen behöver bara next_float() som hanterar undernormaler och nollor.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// En hjälpar trait för att undvika att duplicera i princip alla konverteringskoder för `f32` och `f64`.
///
/// Se föräldramodulens doc-kommentar för varför detta är nödvändigt.
///
/// Bör **aldrig** implementeras för andra typer eller användas utanför dec2flt-modulen.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Typ som används av `to_bits` och `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Utför en rå transmutation till ett heltal.
    fn to_bits(self) -> Self::Bits;

    /// Utför en rå transmutation från ett heltal.
    fn from_bits(v: Self::Bits) -> Self;

    /// Returnerar den kategori som detta nummer faller i.
    fn classify(self) -> FpCategory;

    /// Returnerar mantissan, exponenten och undertecknar som heltal.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Avkodar flottören.
    fn unpack(self) -> Unpacked;

    /// Gjuter från ett litet heltal som kan representeras exakt.
    /// Panic om heltalet inte kan representeras, ser den andra koden i den här modulen till att aldrig låta det hända.
    fn from_int(x: u64) -> Self;

    /// Hämtar värdet 10 <sup>e</sup> från en förberäknad tabell.
    /// Panics för `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Vad namnet säger.
    /// Det är lättare att hårdkoda än att jonglera med inneboende och hoppas att LLVM konstant viker det.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // En konservativ bunden till decimalsiffrorna för ingångar som inte kan producera överflöd eller noll eller
    /// undernormaler.Förmodligen decimaleksponenten för det maximala normalvärdet, därav namnet.
    const MAX_NORMAL_DIGITS: usize;

    /// När den mest signifikanta decimalsiffran har ett platsvärde som är större än detta avrundas numret verkligen till oändlighet.
    ///
    const INF_CUTOFF: i64;

    /// När den mest signifikanta decimalsiffran har ett platsvärde mindre än detta avrundas antalet säkert till noll.
    ///
    const ZERO_CUTOFF: i64;

    /// Antalet bitar i exponenten.
    const EXP_BITS: u8;

    /// Antalet bitar i signifikansen,*inklusive* den dolda biten.
    const SIG_BITS: u8;

    /// Antalet bitar i signifikansen,*exklusive* den dolda biten.
    const EXPLICIT_SIG_BITS: u8;

    /// Den maximala juridiska exponenten i fraktionerad representation.
    const MAX_EXP: i16;

    /// Den minsta juridiska exponenten i fraktionerad representation, exklusive undernormaler.
    const MIN_EXP: i16;

    /// `MAX_EXP` för integrerad representation, dvs med skiftet tillämpat.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` kodad (dvs. med förskjutning)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` för integrerad representation, dvs med skiftet tillämpat.
    const MIN_EXP_INT: i16;

    /// Den maximala normaliserade signifikansen i integrerad representation.
    const MAX_SIG: u64;

    /// Den minimala normaliserade signifikansen i integrerad representation.
    const MIN_SIG: u64;
}

// Mestadels en lösning för #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Returnerar mantissan, exponenten och undertecknar som heltal.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Exponent bias + mantissa shift
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe är osäker på om `as` rundas korrekt på alla plattformar.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Returnerar mantissan, exponenten och undertecknar som heltal.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Exponent bias + mantissa shift
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe är osäker på om `as` rundas korrekt på alla plattformar.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Konverterar en `Fp` till närmaste maskinflottyp.
/// Hanterar inte subnormala resultat.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f är 64 bitar, så xe har en mantissaskiftning på 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Runda 64-bitars signifikans till T::SIG_BITS-bitar med halv till jämn.
/// Hanterar inte exponentöverflöde.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Justera mantissaskiftet
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Omvänd av `RawFloat::unpack()` för normaliserade tal.
/// Panics om signifikans eller exponent inte är giltiga för normaliserade nummer.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Ta bort den dolda biten
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Justera exponenten för exponentbias och mantissaskift
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Lämna teckenbiten på 0 ("+"), våra siffror är alla positiva
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Konstruera ett subnormalt.En mantissa på 0 är tillåten och konstruerar noll.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Kodad exponent är 0, teckenbiten är 0, så vi måste bara tolka bitarna på nytt.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Ungefär en bignum med en Fp.Rundar inom 0.5 ULP med halv till jämn.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Vi klippte av alla bitar före index `start`, dvs. högerförskjuter vi effektivt med en mängd `start`, så detta är också exponenten vi behöver.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Rund (half-to-even) beroende på de trunkerade bitarna.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Hitta det största flytpunktnumret som är strikt mindre än argumentet.
/// Hanterar inte undernormaler, noll eller exponent underflöde.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Hitta det minsta antalet flytande punkter som är strikt större än argumentet.
// Denna operation är mättande, dvs next_float(inf) ==inf.
// Till skillnad från de flesta koder i den här modulen hanterar denna funktion noll, undernormaler och oändligheter.
// Men som alla andra koder här, hanterar den inte NaN och negativa siffror.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Det här verkar för bra för att vara sant, men det fungerar.
        // 0.0 kodas som ordet helt noll.Undernormaler är 0x000m ... m där m är mantissa.
        // I synnerhet är den minsta subnormala 0x0 ... 01 och den största är 0x000F ... F.
        // Det minsta normala antalet är 0x0010 ... 0, så det här hörnfodralet fungerar också.
        // Om inkrementet överflödar mantissan, ökar bärbiten exponenten som vi vill, och mantissbitarna blir noll.
        // På grund av den dolda bitkonventionen är detta också precis vad vi vill!
        // Slutligen f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}