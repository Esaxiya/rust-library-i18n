//! Verktygsfunktioner för bignum som inte är för vettiga att förvandlas till metoder.

// FIXME Den här modulens namn är lite olyckligt, eftersom andra moduler också importerar `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Testa om avkortning av alla bitar som är mindre signifikanta än `ones_place` introducerar ett relativt fel mindre, lika eller större än 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Om alla återstående bitar är noll är det= 0.5 ULP, annars> 0.5 Om det inte finns fler bitar (half_bit==0) returnerar nedan också korrekt lika.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Konverterar en ASCII-sträng som endast innehåller decimalsiffror till en `u64`.
///
/// Utför inte kontroller för överflöd eller ogiltiga tecken, så om den som ringer inte är försiktig är resultatet falskt och kan panic (även om det inte blir `unsafe`).
/// Dessutom behandlas tomma strängar som noll.
/// Denna funktion finns på grund av
///
/// 1. att använda `FromStr` på `&[u8]` kräver `from_utf8_unchecked`, vilket är dåligt, och
/// 2. att sammanföra resultaten av `integral.parse()` och `fractional.parse()` är mer komplicerat än hela denna funktion.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Konverterar en sträng av ASCII-siffror till en bignum.
///
/// Liksom `from_str_unchecked` förlitar sig denna funktion på att parsern rensar bort icke-siffror.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Packar upp ett bignum till ett 64-bitars heltal.Panics om antalet är för stort.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Extraherar ett antal bitar.

/// Index 0 är den minst signifikanta biten och intervallet är halvöppet som vanligt.
/// Panics om du ombeds extrahera fler bitar än att passa in i returtypen.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}