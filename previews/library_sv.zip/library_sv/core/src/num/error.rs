//! Feltyper för konvertering till integraltyper.

use crate::convert::Infallible;
use crate::fmt;

/// Feltypen returneras när en kontrollerad konvertering av integraltyp misslyckas.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Matcha snarare än att tvinga för att se till att kod som `From<Infallible> for TryFromIntError` ovan fortsätter att fungera när `Infallible` blir ett alias till `!`.
        //
        //
        match never {}
    }
}

/// Ett fel som kan returneras vid analysering av ett heltal.
///
/// Detta fel används som feletyp för `from_str_radix()`-funktionerna på de primitiva heltalstyperna, till exempel [`i8::from_str_radix`].
///
/// # Potentiella orsaker
///
/// Bland andra orsaker kan `ParseIntError` kastas på grund av ledande eller efterföljande utrymme i strängen, t.ex. när den erhålls från standardingången.
///
/// Användning av [`str::trim()`]-metoden säkerställer att inget utrymme finns kvar innan tolkning.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum för att lagra olika typer av fel som kan orsaka att en heltal misslyckas.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Värde som analyseras är tomt.
    ///
    /// Bland andra orsaker kommer denna variant att konstrueras när man analyserar en tom sträng.
    Empty,
    /// Innehåller en ogiltig siffra i sitt sammanhang.
    ///
    /// Bland andra orsaker kommer denna variant att konstrueras när man analyserar en sträng som innehåller en icke-ASCII-karaktär.
    ///
    /// Denna variant konstrueras också när en `+` eller `-` är felplacerad i en sträng antingen ensam eller mitt i ett nummer.
    ///
    ///
    InvalidDigit,
    /// Heltal är för stort för att lagras i måltalstyp.
    PosOverflow,
    /// Heltal är för litet för att lagras i måltalstyp.
    NegOverflow,
    /// Värde var noll
    ///
    /// Denna variant kommer att avges när tolkningssträngen har ett värde på noll, vilket skulle vara olagligt för icke-nolltyper.
    ///
    Zero,
}

impl ParseIntError {
    /// Matar ut den detaljerade orsaken till att ett heltal misslyckas.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}