//! Rust-anpassning av Grisu3-algoritmen som beskrivs i "Skriva ut flytpunktsnummer snabbt och exakt med heltal" [^ 1].
//! Den använder cirka 1 KB förberäknad tabell, och i sin tur är det väldigt snabbt för de flesta ingångar.
//!
//! [^1]: Florian Loitsch.2010. Utskrift av flytande nummer snabbt och
//!   exakt med heltal.SIGPLAN Inte.45, 6 (juni 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// se kommentarerna i `format_shortest_opt` för motiveringen.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Med tanke på `x > 0`, returnerar `(k, 10^k)` så att `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Det kortaste lägeimplementeringen för Grisu.
///
/// Den returnerar `None` när den annars skulle returnera en felaktig representation.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // vi behöver minst tre bitar med ytterligare precision

    // börja med de normaliserade värdena med den delade exponenten
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // hitta någon `cached = 10^minusk` så att `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // eftersom `plus` är normaliserat betyder detta `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // med tanke på våra val av `ALPHA` och `GAMMA`, sätter detta `plus * cached` i `[4, 2^32)`.
    //
    // det är uppenbarligen önskvärt att maximera `GAMMA - ALPHA`, så att vi inte behöver många cachade krafter på 10, men det finns några överväganden:
    //
    //
    // 1. vi vill hålla `floor(plus * cached)` inom `u32` eftersom det behöver en kostsam uppdelning.
    //    (detta är inte riktigt undvikbart, resten krävs för noggrannhetsuppskattning.)
    // 2.
    // resten av `floor(plus * cached)` multipliceras upprepade gånger med 10, och det ska inte rinna över.
    //
    // den första ger `64 + GAMMA <= 32`, medan den andra ger `10 * 2^-ALPHA <= 2^64`;
    // -60 och -32 är det maximala intervallet med denna begränsning, och V8 använder dem också.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // skala fps.detta ger det maximala felet på 1 ulp (bevisat från sats 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-faktiskt minusområde
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // över `minus`, `v` och `plus` är *kvantiserade* approximationer (fel <1 ulp).
    // eftersom vi inte vet är felet positivt eller negativt, vi använder två approximationer fördelade lika och har det maximala felet på 2 ulps.
    //
    // "unsafe region" är ett liberalt intervall som vi ursprungligen genererar.
    // "safe region" är ett konservativt intervall som vi bara accepterar.
    // vi börjar med rätt repr inom den osäkra regionen och försöker hitta den närmaste repr till `v` som också är inom den säkra regionen.
    // om vi inte kan, ger vi upp.
    //
    let plus1 = plus.f + 1;
    // låt plus0 = plus.f, 1;//endast för förklaring låt minus0 = minus.f + 1;//endast för förklaring
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // delad exponent

    // dela upp `plus1` i integrerade och bråkdelar.
    // integrerade delar passar garanterat i u32, eftersom cachad effekt garanterar `plus < 2^32` och normaliserad `plus.f` alltid är mindre än `2^64 - 2^4` på grund av precisionskravet.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // beräkna den största `10^max_kappa` inte mer än `plus1` (alltså `plus1 < 10^(max_kappa+1)`).
    // detta är en övre gräns för `kappa` nedan.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Sats 6.2: om `k` är det största heltalet
    // `0 <= y mod 10^k <= y - x`,              då är `V = floor(y / 10^k) * 10^k` i `[x, y]` och en av de kortaste representationerna (med det minsta antalet signifikanta siffror) i det intervallet.
    //
    //
    // hitta sifferlängden `kappa` mellan `(minus1, plus1)` enligt sats 6.2.
    // Sats 6.2 kan antas för att utesluta `x` genom att kräva `y mod 10^k < y - x` istället.
    // (t.ex. `x` =32000, `y` =32777; `kappa` =2 eftersom `y mod 10 ^ 3=777 <y, x=777 '.) algoritmen förlitar sig på den senare verifieringsfasen för att utesluta `y`.
    //
    let delta1 = plus1 - minus1;
    // låt delta1int=(delta1>> e) som storlek;//endast för förklaring
    let delta1frac = delta1 & ((1 << e) - 1);

    // återge integrerade delar, medan du kontrollerar noggrannheten i varje steg.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // siffror som ännu inte ska återges
    loop {
        // vi har alltid minst en siffra att återge, som `plus1 >= 10^kappa`-invarianter:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (det följer att `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // dela `remainder` med `10^kappa`.båda skalas av `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; vi har hittat rätt `kappa`.
            let ten_kappa = (ten_kappa as u64) << e; // skala 10 ^ kappa tillbaka till den delade exponenten
            return round_and_weed(
                // SÄKERHET: vi initialiserade minnet ovan.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // bryta slingan när vi har återgivit alla integrerade siffror.
        // det exakta antalet siffror är `max_kappa + 1` som `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // återställa invarianter
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // återge bråkdelar medan du kontrollerar noggrannheten i varje steg.
    // den här gången litar vi på upprepade multiplikationer, eftersom division kommer att förlora precisionen.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // nästa siffra borde vara viktig eftersom vi har testat det innan vi bryter ut invarianter, där `m = max_kappa + 1` (antal siffror i den integrerade delen):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // kommer inte att rinna över, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // dela `remainder` med `10^kappa`.
        // båda skalas av `2^e / 10^kappa`, så den senare är implicit här.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // implicit delare
            return round_and_weed(
                // SÄKERHET: vi initialiserade minnet ovan.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // återställa invarianter
        kappa -= 1;
        remainder = r;
    }

    // Vi har genererat alla signifikanta siffror på `plus1`, men är inte säkra på om det är det optimala.
    // till exempel, om `minus1` är 3.14153 ... och `plus1` är 3.14158 ... finns det 5 olika kortaste representationer från 3.14154 till 3.14158 men vi har bara den största.
    // vi måste successivt minska den sista siffran och kontrollera om detta är den optimala repr.
    // det finns högst nio kandidater (..1 till ..9), så det går ganska snabbt.("rounding"-fas)
    //
    // funktionen kontrollerar om denna "optimal" repr faktiskt ligger inom ulp-intervallen, och det är också möjligt att "second-to-optimal" repr faktiskt kan vara optimal på grund av avrundningsfelet.
    // i båda fallen returnerar detta `None`.
    // ("weeding"-fas)
    //
    // alla argument här skalas av det gemensamma (men implicita) värdet `k`, så att:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (och även `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (och även `threshold > plus1v` från tidigare invarianter)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // producera två approximationer till `v` (faktiskt `plus1 - v`) inom 1.5 ulps.
        // den resulterande representationen bör vara den närmaste representationen för båda.
        //
        // här används `plus1 - v` eftersom beräkningar görs med avseende på `plus1` för att undvika overflow/underflow (därav de till synes bytte namnen).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // minska den sista siffran och stanna vid den närmaste representationen till `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // vi arbetar med de ungefärliga siffrorna `w(n)`, som ursprungligen är lika med `plus1 - plus1 % 10^kappa`.efter att ha kört loopkroppen `n` gånger, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // vi ställer in `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (alltså `resten= plus1w(0)`) för att förenkla kontrollerna.
            // notera att `plus1w(n)` alltid ökar.
            //
            // vi har tre villkor att avsluta.någon av dem gör att slingan inte kan fortsätta, men vi har åtminstone en giltig representation som är känd för att vara närmast `v + 1 ulp` ändå.
            // vi kommer att beteckna dem som TC1 till TC3 för korthet.
            //
            // TC1: `w(n) <= v + 1 ulp`, dvs detta är den sista repr som kan vara den närmaste.
            // detta motsvarar `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // kombinerat med TC2 (som kontrollerar om `w(n+1)` is valid) förhindrar detta ett eventuellt överflöde vid beräkningen av `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, dvs nästa repr rundar definitivt inte till `v`.
            // detta motsvarar `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // vänster sida kan rinna över, men vi känner till `threshold > plus1v`, så om TC1 är falskt kan `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` och vi säkert kan testa om `threshold - plus1w(n) < 10^kappa` istället.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, dvs nästa repr är
            // inte närmare `v + 1 ulp` än den nuvarande repr.
            // givet `z(n) = plus1v_up - plus1w(n)` blir detta `abs(z(n)) <= abs(z(n+1))`.igen förutsatt att TC1 är falskt, har vi `z(n) > 0`.vi har två fall att överväga:
            //
            // - när `z(n+1) >= 0`: TC3 blir `z(n) <= z(n+1)`.
            // eftersom `plus1w(n)` ökar bör `z(n)` minska och detta är helt klart falskt.
            // - när `z(n+1) < 0`:
            //   - TC3a: förutsättningen är `plus1v_up < plus1w(n) + 10^kappa`.förutsatt att TC2 är falskt, `threshold >= plus1w(n) + 10^kappa` så att det inte kan rinna över.
            //   - TC3b: TC3 blir `z(n) <= -z(n+1)`, dvs `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   den negerade TC1 ger `plus1v_up > plus1w(n)`, så den kan inte rinna över eller underflöde i kombination med TC3a.
            //
            // följaktligen bör vi sluta när `TC1 || TC2 || (TC3a && TC3b)`.följande är lika med dess inversa, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // den kortaste repr kan inte sluta med `0`
                plus1w += ten_kappa;
            }
        }

        // kontrollera om den här representationen också är den närmaste representationen till `v - 1 ulp`.
        //
        // detta är helt enkelt samma som de avslutande villkoren för `v + 1 ulp`, med alla `plus1v_up` istället ersatta av `plus1v_down`.
        // analys av överflöd gäller också.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // nu har vi den närmaste representationen till `v` mellan `plus1` och `minus1`.
        // detta är dock för liberalt, så vi avvisar alla `w(n)` inte mellan `plus0` och `minus0`, dvs `plus1 - plus1w(n) <= minus0` eller `plus1 - plus1w(n) >= plus0`.
        // vi använder fakta som `threshold = plus1 - minus1` och `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Den kortaste implementeringen av läget för Grisu med Dragon fallback.
///
/// Detta bör användas i de flesta fall.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SÄKERHET: Lånekontrollern är inte tillräckligt smart för att vi ska kunna använda `buf`
    // i den andra branch, så vi tvättar livstiden här.
    // Men vi återanvänder bara `buf` om `format_shortest_opt` returnerade `None` så det är okej.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Den exakta och fasta implementeringen för Grisu.
///
/// Den returnerar `None` när den annars skulle returnera en felaktig representation.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // vi behöver minst tre bitar med ytterligare precision
    assert!(!buf.is_empty());

    // normalisera och skala `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // dela upp `v` i integrerade och bråkdelar.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // både gamla `v` och nya `v` (skalas av `10^-k`) har ett fel på <1 ulp (Theorem 5.1).
    // eftersom vi inte vet är felet positivt eller negativt, vi använder två approximationer fördelade lika och har det maximala felet på 2 ulps (samma till det kortaste fallet).
    //
    //
    // målet är att hitta exakt rundade siffror som är gemensamma för både `v - 1 ulp` och `v + 1 ulp`, så att vi är maximalt säkra.
    // om detta inte är möjligt vet vi inte vilken som är rätt utgång för `v`, så vi ger upp och faller tillbaka.
    //
    // `err` definieras som `1 ulp * 2^e` här (samma som ulp i `vfrac`), och vi skalar den när `v` blir skalad.
    //
    //
    //
    let mut err = 1;

    // beräkna den största `10^max_kappa` inte mer än `v` (alltså `v < 10^(max_kappa+1)`).
    // detta är en övre gräns för `kappa` nedan.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // om vi arbetar med den sista siffran begränsning, måste vi förkorta bufferten innan den faktiska rendering för att undvika dubbel avrundning.
    //
    // notera att vi måste förstora bufferten igen när avrundning sker!
    let len = if exp <= limit {
        // Oj, vi kan inte ens producera *en* siffra.
        // detta är möjligt när vi, säg, har något som 9.5 och det avrundas till 10.
        //
        // i princip kan vi omedelbart ringa `possibly_round` med en tom buffert, men skalning av `max_ten_kappa << e` med 10 kan resultera i överflöd.
        //
        // alltså är vi slarviga här och utvidgar felområdet med en faktor 10.
        // detta kommer att öka den falska negativa räntan, men bara mycket,*mycket* något;
        // det kan bara betyda märkbart när mantissan är större än 60 bitar.
        //
        // SÄKERHET: `len=0`, så skyldigheten att ha initierat minnet är trivial.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // återge integrerade delar.
    // felet är helt fraktionerat, så vi behöver inte kontrollera det i den här delen.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // siffror som ännu inte ska återges
    loop {
        // vi har alltid minst en siffra för att göra invarianter:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (det följer att `remainder = vint % 10^(kappa+1)`)
        //
        //

        // dela `remainder` med `10^kappa`.båda skalas av `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // är bufferten full?kör avrundningskortet med resten.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SÄKERHET: vi har initialiserat `len` många byte.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // bryta slingan när vi har återgivit alla integrerade siffror.
        // det exakta antalet siffror är `max_kappa + 1` som `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // återställa invarianter
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // återge bråkdelar.
    //
    // i princip kan vi fortsätta till den sista tillgängliga siffran och kontrollera riktigheten.
    // tyvärr arbetar vi med de ändliga storlekarna, så vi behöver något kriterium för att upptäcka överflödet.
    // V8 använder `remainder > err`, vilket blir falskt när de första `i` signifikanta siffrorna i `v - 1 ulp` och `v` skiljer sig åt.
    // detta avvisar dock för många annars giltiga inmatningar.
    //
    // eftersom den senare fasen har en korrekt överflödesdetektering använder vi istället strängare kriterium:
    // vi fortsätter tills `err` överstiger `10^kappa / 2`, så att intervallet mellan `v - 1 ulp` och `v + 1 ulp` definitivt innehåller två eller flera rundade representationer.
    //
    // detta är detsamma som de två första jämförelserna från `possibly_round`, som referens.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invarianter, där `m = max_kappa + 1` (antal siffror i den integrerade delen):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // kommer inte att rinna över, `2^e * 10 < 2^64`
        err *= 10; // kommer inte att rinna över, `err * 10 < 2^e * 5 < 2^64`

        // dela `remainder` med `10^kappa`.
        // båda skalas av `2^e / 10^kappa`, så den senare är implicit här.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // är bufferten full?kör avrundningskortet med resten.
        if i == len {
            // SÄKERHET: vi har initialiserat `len` många byte.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // återställa invarianter
        remainder = r;
    }

    // ytterligare beräkning är värdelös (`possibly_round` misslyckas definitivt), så vi ger upp.
    return None;

    // Vi har genererat alla begärda siffror på `v`, som också ska vara samma som motsvarande siffror på `v - 1 ulp`.
    // nu kontrollerar vi om det finns en unik representation som delas av både `v - 1 ulp` och `v + 1 ulp`;detta kan vara antingen samma för genererade siffror eller för den avrundade versionen av dessa siffror.
    //
    // om intervallet innehåller flera representationer av samma längd kan vi inte vara säkra och ska returnera `None` istället.
    //
    // alla argument här skalas av det gemensamma (men implicita) värdet `k`, så att:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // SÄKERHET: de första `len` bytes av `buf` måste initieras.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (som referens anger den streckade linjen det exakta värdet för möjliga representationer i ett givet antal siffror.)
        //
        //
        // fel är för stort för att det finns minst tre möjliga representationer mellan `v - 1 ulp` och `v + 1 ulp`.
        // vi kan inte avgöra vilken som är korrekt.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // i själva verket är 1/2 ulp tillräckligt för att införa två möjliga representationer.
        // (kom ihåg att vi behöver en unik representation för både `v - 1 ulp` och `v + 1 ulp '.) Detta kommer inte att rinna över, eftersom `ulp < ten_kappa` från första kontrollen.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // om `v + 1 ulp` är närmare den avrundade representationen (som redan finns i `buf`), kan vi säkert återvända.
        // notera att `v - 1 ulp`*kan* vara mindre än den nuvarande representationen, men som `1 ulp < 10^kappa / 2` är detta villkor tillräckligt:
        // avståndet mellan `v - 1 ulp` och den aktuella representationen får inte överstiga `10^kappa / 2`.
        //
        // villkoret är lika med `remainder + ulp < 10^kappa / 2`.
        // eftersom detta lätt kan överflöd, kontrollera först om `remainder < 10^kappa / 2`.
        // Vi har redan verifierat att `ulp < 10^kappa / 2`, så länge `10^kappa` inte överflödade trots allt, är den andra kontrollen bra.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SÄKERHET: vår uppringare initierade minnet.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------resten------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // å andra sidan, om `v - 1 ulp` är närmare den avrundade representationen, borde vi runda upp och återvända.
        // av samma anledning behöver vi inte kontrollera `v + 1 ulp`.
        //
        // villkoret är lika med `remainder - ulp >= 10^kappa / 2`.
        // igen kontrollerar vi först om `remainder > ulp` (notera att detta inte är `remainder >= ulp`, eftersom `10^kappa` aldrig är noll).
        //
        // Observera också att `remainder - ulp <= 10^kappa`, så den andra kontrollen överflödar inte.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // SÄKERHET: vår uppringare måste ha initierat minnet.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // lägg bara till en ytterligare siffra när vi har begärt fast precision.
                // Vi måste också kontrollera att om den ursprungliga bufferten var tom kan den extra siffran endast läggas till när `exp == limit` (fall edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // SÄKERHET: vi och vår uppringare initierade minnet.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // annars är vi dömda (dvs vissa värden mellan `v - 1 ulp` och `v + 1 ulp` avrundas ner och andra avrundas uppåt) och ger upp.
        //
        None
    }
}

/// Den exakta och fasta läget implementering för Grisu med Dragon fallback.
///
/// Detta bör användas i de flesta fall.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SÄKERHET: Lånekontrollern är inte tillräckligt smart för att vi ska kunna använda `buf`
    // i den andra branch, så vi tvättar livstiden här.
    // Men vi återanvänder bara `buf` om `format_exact_opt` returnerade `None` så det här är okej.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}