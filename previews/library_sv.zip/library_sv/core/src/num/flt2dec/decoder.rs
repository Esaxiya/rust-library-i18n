//! Avkodar ett flytpunktsvärde i enskilda delar och felområden.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Avkodat osignerat ändligt värde, så att:
///
/// - Det ursprungliga värdet är lika med `mant * 2^exp`.
///
/// - Alla nummer från `(mant - minus)*2^exp` till `(mant + plus)* 2^exp` kommer att avrundas till det ursprungliga värdet.
/// Området inkluderar endast när `inclusive` är `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Den skalade mantissen.
    pub mant: u64,
    /// Det lägre felintervallet.
    pub minus: u64,
    /// Det övre felområdet.
    pub plus: u64,
    /// Den delade exponenten i bas 2.
    pub exp: i16,
    /// Stämmer när felintervallet är inkluderande.
    ///
    /// I IEEE 754 är detta sant när den ursprungliga mantissen var jämn.
    pub inclusive: bool,
}

/// Avkodat osignerat värde.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Oändligheter, antingen positiva eller negativa.
    Infinite,
    /// Noll, antingen positiv eller negativ.
    Zero,
    /// Slutliga nummer med ytterligare avkodade fält.
    Finite(Decoded),
}

/// En flytpunktstyp som kan 'avkodas' d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Det minsta positiva normaliserade värdet.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Returnerar ett tecken (sant när det är negativt) och `FullDecoded`-värde från det givna flytpunkten.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // grannar: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode bevarar alltid exponenten, så mantissen skalas för subnormala.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // grannar: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // där maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // grannar: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}