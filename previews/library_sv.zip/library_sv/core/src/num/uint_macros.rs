macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Det minsta värdet som kan representeras av denna heltalstyp.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Det största värdet som kan representeras av denna heltalstyp.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Storleken på denna heltalstyp i bitar.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Konverterar en strängskiva i en given bas till ett heltal.
        ///
        /// Strängen förväntas vara ett valfritt `+`-tecken följt av siffror.
        ///
        /// Ledande och efterföljande blanksteg representerar ett fel.
        /// Siffror är en delmängd av dessa tecken, beroende på `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Denna funktion panics om `radix` inte ligger i intervallet 2 till 36.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Returnerar antalet av dem i den binära representationen av `self`.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Returnerar antalet nollor i den binära representationen av `self`.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Returnerar antalet ledande nollor i den binära representationen av `self`.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Returnerar antalet efterföljande nollor i den binära representationen av `self`.
        ///
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Returnerar antalet ledande i den binära representationen av `self`.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Returnerar antalet efterföljande i den binära representationen av `self`.
        ///
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Skiftar bitarna åt vänster med en angiven mängd, `n`, som sveper de trunkerade bitarna till slutet av det resulterande heltalet.
        ///
        ///
        /// Observera att detta inte är samma operation som `<<`-växlingsoperatören!
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Skiftar bitarna till höger med en angiven mängd, `n`, som sveper de trunkerade bitarna till början av det resulterande heltalet.
        ///
        ///
        /// Observera att detta inte är samma operation som `>>`-växlingsoperatören!
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Omvandlar heltalets byteordning.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// låt m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Omvandlar ordningen på bitar i heltalet.
        /// Den minst signifikanta biten blir den mest signifikanta biten, den andra minst signifikanta biten blir näst mest betydelsefulla biten, etc.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// låt m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Konverterar ett heltal från stor endian till målets slutlighet.
        ///
        /// På stora endian är detta ett no-op.
        /// På liten endian byts byten.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// om cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } annat {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Konverterar ett heltal från liten endian till målets slutlighet.
        ///
        /// På liten endian är detta ett no-op.
        /// På stora endian byts bytes.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// om cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } annat {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Konverterar `self` till stor endian från målets slutlighet.
        ///
        /// På stora endian är detta ett no-op.
        /// På liten endian byts byten.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// om cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } annat { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // eller inte vara?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Konverterar `self` till liten endian från målets slutlighet.
        ///
        /// På liten endian är detta ett no-op.
        /// På stora endian byts bytes.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// om cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } annat { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Kontrollerat heltalstillägg.
        /// Beräknar `self + rhs`, returnerar `None` om överflöde inträffade.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Okontrollerat heltalstillägg.Beräknar `self + rhs`, förutsatt att överflöde inte kan uppstå.
        /// Detta resulterar i odefinierat beteende när
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Kontrollerad heltalssubtraktion.
        /// Beräknar `self - rhs`, returnerar `None` om överflöde inträffade.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Okontrollerad heltalssubtraktion.Beräknar `self - rhs`, förutsatt att överflöde inte kan uppstå.
        /// Detta resulterar i odefinierat beteende när
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Kontrollerad heltalsmultiplikation.
        /// Beräknar `self * rhs`, returnerar `None` om överflöde inträffade.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Okontrollerad heltalsmultiplikation.Beräknar `self * rhs`, förutsatt att överflöde inte kan uppstå.
        /// Detta resulterar i odefinierat beteende när
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Kontrollerad heltalsdelning.
        /// Beräknar `self / rhs`, returnerar `None` om `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SÄKERHET: div med noll har markerats ovan och osignerade typer har inga andra
                // fellägen för uppdelning
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Kontrollerad euklidisk division.
        /// Beräknar `self.div_euclid(rhs)`, returnerar `None` om `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Kontrollerad återstod av heltal.
        /// Beräknar `self % rhs`, returnerar `None` om `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SÄKERHET: div med noll har markerats ovan och osignerade typer har inga andra
                // fellägen för uppdelning
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Kontrollerad euklidisk modulo.
        /// Beräknar `self.rem_euclid(rhs)`, returnerar `None` om `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Kontrollerad negation.Beräknar `-self`, returnerar `None` såvida inte `self==
        /// 0`.
        ///
        /// Observera att att negera alla positiva heltal kommer att rinna över.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kontrollerad skift åt vänster.
        /// Beräknar `self << rhs`, returnerar `None` om `rhs` är större än eller lika med antalet bitar i `self`.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kontrollerad skift till höger.
        /// Beräknar `self >> rhs`, returnerar `None` om `rhs` är större än eller lika med antalet bitar i `self`.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kontrollerad exponentiering.
        /// Beräknar `self.pow(exp)`, returnerar `None` om överflöde inträffade.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // eftersom exp!=0 måste slutligen exp vara 1.
            // Hantera den sista biten av exponenten separat, eftersom kvadrering av basen efteråt inte är nödvändig och kan orsaka onödigt överflöd.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Mättande heltalstillägg.
        /// Beräknar `self + rhs`, mättar vid de numeriska gränserna istället för att flyta över.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Mättande heltal subtrahering.
        /// Beräknar `self - rhs`, mättar vid de numeriska gränserna istället för att flyta över.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Mättande heltalsmultiplikation.
        /// Beräknar `self * rhs`, mättar vid de numeriska gränserna istället för att flyta över.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Mättande heltalsexponering.
        /// Beräknar `self.pow(exp)`, mättar vid de numeriska gränserna istället för att flyta över.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Wrapping (modular)-tillägg.
        /// Beräknar `self + rhs`, sveper runt vid typens gräns.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Förpackning (modular) subtraktion.
        /// Beräknar `self - rhs`, sveper runt vid typens gräns.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Inslagning av (modular)-multiplikation.
        /// Beräknar `self * rhs`, sveper runt vid typens gräns.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// Observera att detta exempel delas mellan heltalstyper.
        /// Vilket förklarar varför `u8` används här.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Inslagning (modular) division.Beräknar `self / rhs`.
        /// Inpackad delning på osignerade typer är bara normal uppdelning.
        /// Det finns inget sätt att inslagning någonsin kan hända.
        /// Denna funktion finns så att alla operationer redovisas i inslagningsoperationerna.
        ///
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Förpackning av den euklidiska divisionen.Beräknar `self.div_euclid(rhs)`.
        /// Inpackad delning på osignerade typer är bara normal uppdelning.
        /// Det finns inget sätt att inslagning någonsin kan hända.
        /// Denna funktion finns så att alla operationer redovisas i inslagningsoperationerna.
        /// Eftersom, för de positiva heltalen, alla vanliga definitioner av division är lika, är detta exakt lika med `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Packning (modular) resten.Beräknar `self % rhs`.
        /// Wrapped restberäkning på osignerade typer är bara den vanliga restberäkningen.
        ///
        /// Det finns inget sätt att inslagning någonsin kan hända.
        /// Denna funktion finns så att alla operationer redovisas i inslagningsoperationerna.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Inslagning av euklidisk modulo.Beräknar `self.rem_euclid(rhs)`.
        /// Wrapped modulo-beräkning på osignerade typer är bara den vanliga återstående beräkningen.
        /// Det finns inget sätt att inslagning någonsin kan hända.
        /// Denna funktion finns så att alla operationer redovisas i inslagningsoperationerna.
        /// Eftersom, för de positiva heltalen, alla vanliga definitioner av division är lika, är detta exakt lika med `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Inslagning av (modular)-negation.
        /// Beräknar `-self`, sveper runt vid typens gräns.
        ///
        /// Eftersom osignerade typer inte har negativa ekvivalenter kommer alla applikationer av denna funktion att slås in (förutom `-0`).
        /// För värden som är mindre än motsvarande signerade typs maximala är resultatet detsamma som att kasta motsvarande signerat värde.
        ///
        /// Eventuella större värden motsvarar `MAX + 1 - (val - MAX - 1)` där `MAX` är motsvarande signerad typs maximala.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// Observera att detta exempel delas mellan heltalstyper.
        /// Vilket förklarar varför `i8` används här.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-fri bitvis skift-vänster;
        /// ger `self << mask(rhs)`, där `mask` tar bort alla högordnade bitar av `rhs` som skulle få skiftet att överstiga typbredden.
        ///
        /// Observera att detta är *inte* detsamma som en rotera-vänster;RHS för en omslagsförskjutning till vänster är begränsad till typområdet, snarare än att bitarna som flyttats ut från LHS returneras till den andra änden.
        /// De primitiva heltalstyperna implementerar alla en [`rotate_left`](Self::rotate_left)-funktion, vilket kan vara vad du vill ha istället.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SÄKERHET: maskeringen av bitstorleken av typen ser till att vi inte växlar
            // utanför banan
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-fri bitvis skift-höger;
        /// ger `self >> mask(rhs)`, där `mask` tar bort alla högordnade bitar av `rhs` som skulle få skiftet att överstiga typbredden.
        ///
        /// Observera att detta är *inte* detsamma som en rotera-höger;RHS för en omslagsförskjutningshöger är begränsad till typområdet, snarare än att bitarna som flyttats ut från LHS returneras till den andra änden.
        /// De primitiva heltalstyperna implementerar alla en [`rotate_right`](Self::rotate_right)-funktion, vilket kan vara vad du vill ha istället.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SÄKERHET: maskeringen av bitstorleken av typen ser till att vi inte växlar
            // utanför banan
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Förpackning av (modular)-exponentiering.
        /// Beräknar `self.pow(exp)`, sveper runt vid typens gräns.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // eftersom exp!=0 måste slutligen exp vara 1.
            // Hantera den sista biten av exponenten separat, eftersom kvadrering av basen efteråt inte är nödvändig och kan orsaka onödigt överflöd.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Beräknar `self` + `rhs`
        ///
        /// Returnerar en tupel av tillägget tillsammans med en boolean som indikerar om ett aritmetiskt överflöde skulle inträffa.
        /// Om ett överflöde skulle ha inträffat returneras det inslagna värdet.
        ///
        /// # Examples
        ///
        /// Grundläggande användning
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Beräknar `self`, `rhs`
        ///
        /// Returnerar en tupel av subtraktionen tillsammans med en boolean som indikerar om ett aritmetiskt överflöde skulle inträffa.
        /// Om ett överflöde skulle ha inträffat returneras det inslagna värdet.
        ///
        /// # Examples
        ///
        /// Grundläggande användning
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Beräknar multiplikationen av `self` och `rhs`.
        ///
        /// Returnerar en tupel av multiplikationen tillsammans med en boolean som indikerar om ett aritmetiskt överflöde skulle inträffa.
        /// Om ett överflöde skulle ha inträffat returneras det inslagna värdet.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// Observera att detta exempel delas mellan heltalstyper.
        /// Vilket förklarar varför `u32` används här.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Beräknar delaren när `self` divideras med `rhs`.
        ///
        /// Returnerar en del av divisorn tillsammans med en boolean som indikerar om ett aritmetiskt överflöde skulle inträffa.
        /// Observera att för osignerade heltal inträffar aldrig överflöd, så det andra värdet är alltid `false`.
        ///
        /// # Panics
        ///
        /// Denna funktion kommer att panic om `rhs` är 0.
        ///
        /// # Examples
        ///
        /// Grundläggande användning
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Beräknar kvoten för den euklidiska divisionen `self.div_euclid(rhs)`.
        ///
        /// Returnerar en del av divisorn tillsammans med en boolean som indikerar om ett aritmetiskt överflöde skulle inträffa.
        /// Observera att för osignerade heltal inträffar aldrig överflöd, så det andra värdet är alltid `false`.
        /// Eftersom, för de positiva heltalen, alla vanliga definitioner av division är lika, är detta exakt lika med `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Denna funktion kommer att panic om `rhs` är 0.
        ///
        /// # Examples
        ///
        /// Grundläggande användning
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Beräknar resten när `self` divideras med `rhs`.
        ///
        /// Returnerar en tuppel av resten efter delning tillsammans med en boolean som indikerar om ett aritmetiskt överflöde skulle inträffa.
        /// Observera att för osignerade heltal inträffar aldrig överflöd, så det andra värdet är alltid `false`.
        ///
        /// # Panics
        ///
        /// Denna funktion kommer att panic om `rhs` är 0.
        ///
        /// # Examples
        ///
        /// Grundläggande användning
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Beräknar resten `self.rem_euclid(rhs)` som av euklidisk division.
        ///
        /// Returnerar en tuppel av modulo efter delning tillsammans med en boolean som indikerar om ett aritmetiskt överflöde skulle inträffa.
        /// Observera att för osignerade heltal inträffar aldrig överflöd, så det andra värdet är alltid `false`.
        /// Eftersom alla vanliga definitioner av delning är lika för positiva heltal är denna operation exakt lika med `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Denna funktion kommer att panic om `rhs` är 0.
        ///
        /// # Examples
        ///
        /// Grundläggande användning
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Negerar själv på ett överflödigt sätt.
        ///
        /// Returnerar `!self + 1` med hjälp av inslagningsoperationer för att returnera värdet som representerar negationen av detta osignerade värde.
        /// Observera att för positiva osignerade värden alltid överflöd förekommer, men att negera 0 inte överflödar.
        ///
        /// # Examples
        ///
        /// Grundläggande användning
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Skiftar själv med `rhs` bitar.
        ///
        /// Returnerar en tupel av den skiftade versionen av själv tillsammans med en boolean som indikerar om skiftvärdet var större än eller lika med antalet bitar.
        /// Om skiftvärdet är för stort maskeras värdet (N-1) där N är antalet bitar, och detta värde används sedan för att utföra skiftet.
        ///
        /// # Examples
        ///
        /// Grundläggande användning
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Skiftar självrätt med `rhs` bitar.
        ///
        /// Returnerar en tupel av den skiftade versionen av själv tillsammans med en boolean som indikerar om skiftvärdet var större än eller lika med antalet bitar.
        /// Om skiftvärdet är för stort maskeras värdet (N-1) där N är antalet bitar, och detta värde används sedan för att utföra skiftet.
        ///
        /// # Examples
        ///
        /// Grundläggande användning
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Ökar själv till kraften i `exp`, genom att använda exponentiering genom att kvadrera.
        ///
        /// Returnerar en tupel av exponentieringen tillsammans med en bool som indikerar om ett överflöde hände.
        ///
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, sant));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Skrapa utrymme för att lagra resultat av overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // eftersom exp!=0 måste slutligen exp vara 1.
            // Hantera den sista biten av exponenten separat, eftersom kvadrering av basen efteråt inte är nödvändig och kan orsaka onödigt överflöd.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Ökar själv till kraften i `exp`, genom att använda exponentiering genom att kvadrera.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // eftersom exp!=0 måste slutligen exp vara 1.
            // Hantera den sista biten av exponenten separat, eftersom kvadrering av basen efteråt inte är nödvändig och kan orsaka onödigt överflöd.
            //
            //
            acc * base
        }

        /// Utför euklidisk division.
        ///
        /// Eftersom, för de positiva heltalen, alla vanliga definitioner av division är lika, är detta exakt lika med `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Denna funktion kommer att panic om `rhs` är 0.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Beräknar den minsta återstoden av `self (mod rhs)`.
        ///
        /// Eftersom, för de positiva heltalen, alla vanliga definitioner av division är lika, är detta exakt lika med `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Denna funktion kommer att panic om `rhs` är 0.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Returnerar `true` om och endast om `self == 2^k` för vissa `k`.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Returnerar en mindre än nästa effekt på två.
        // (För 8u8 är nästa effekt på två 8u8 och för 6u8 är det 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Den här metoden kan inte överflödas, eftersom det i `next_power_of_two`-överflödesfallet istället hamnar tillbaka det maximala värdet för typen och kan returnera 0 för 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // SÄKERHET: Eftersom `p > 0` kan den inte bestå helt av ledande nollor.
            // Det betyder att skiftet alltid är inom gränserna, och vissa processorer (som intel pre-haswell) har effektivare ctlz-inneboende när argumentet inte är noll.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Returnerar den minsta effekten på två större än eller lika med `self`.
        ///
        /// När returvärdet överflödar (dvs. `self > (1 << (N-1))` för typ `uN`), panics i felsökningsläge och returvärdet lindas till 0 i frigöringsläge (den enda situationen där metoden kan returnera 0).
        ///
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Returnerar den minsta effekten på två större än eller lika med `n`.
        /// Om nästa effekt på två är större än typens maximala värde, returneras `None`, annars är effekten av två insvept i `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Returnerar den minsta effekten på två större än eller lika med `n`.
        /// Om nästa effekt på två är större än typens maximala värde, läggs returvärdet in till `0`.
        ///
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Returnera minnesrepresentationen för detta heltal som en byte-array i stor endian (network)-byteordning.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Returnera minnesrepresentationen för detta heltal som en byte-array i liten endian-byteordning.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Returnera minnesrepresentationen för detta heltal som en byte-array i native byte-ordning.
        ///
        /// Eftersom målplattformens ursprungliga slutanvändning används bör bärbar kod använda [`to_be_bytes`] eller [`to_le_bytes`], efter behov, istället.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     byte, om cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } annat {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SÄKERHET: const-ljud eftersom heltal är vanliga gamla datatyper så att vi alltid kan
        // överföra dem till bytesgrupper
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SÄKERHET: heltal är vanliga gamla datatyper så att vi alltid kan överföra dem till
            // matriser med byte
            unsafe { mem::transmute(self) }
        }

        /// Returnera minnesrepresentationen för detta heltal som en byte-array i native byte-ordning.
        ///
        ///
        /// [`to_ne_bytes`] bör föredras framför detta när det är möjligt.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// låt byte= num.as_ne_bytes();
        /// assert_eq!(
        ///     byte, om cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } annat {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SÄKERHET: heltal är vanliga gamla datatyper så att vi alltid kan överföra dem till
            // matriser med byte
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Skapa ett native endian-heltal från dess representation som en byte-array i big endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// använd std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ingång=vila;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Skapa ett ursprungligt endian-heltal från dess representation som en byte-array i liten endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// använd std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ingång=vila;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Skapa ett inbyggt endian-heltal från dess minnesrepresentation som en byte-array i native endianness.
        ///
        /// Eftersom målplattformens infödda användning används, vill den bärbara koden troligen använda [`from_be_bytes`] eller [`from_le_bytes`], i förekommande fall istället.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } annat {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// använd std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ingång=vila;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SÄKERHET: const-ljud eftersom heltal är vanliga gamla datatyper så att vi alltid kan
        // överför till dem
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SÄKERHET: heltal är vanliga gamla datatyper så att vi alltid kan överföra till dem
            unsafe { mem::transmute(bytes) }
        }

        /// Ny kod bör föredra att använda
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Returnerar det minsta värdet som kan representeras av denna heltalstyp.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Ny kod bör föredra att använda
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Returnerar det största värdet som kan representeras av denna heltalstyp.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}