macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Det minsta värdet som kan representeras av denna heltalstyp.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// Det största värdet som kan representeras av denna heltalstyp.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// Storleken på denna heltalstyp i bitar.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Konverterar en strängskiva i en given bas till ett heltal.
        ///
        /// Strängen förväntas vara ett valfritt `+`-eller `-`-tecken följt av siffror.
        /// Ledande och efterföljande blanksteg representerar ett fel.
        /// Siffror är en delmängd av dessa tecken, beroende på `radix`:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// Denna funktion panics om `radix` inte ligger i intervallet 2 till 36.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Returnerar antalet av dem i den binära representationen av `self`.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// Returnerar antalet nollor i den binära representationen av `self`.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Returnerar antalet ledande nollor i den binära representationen av `self`.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// Returnerar antalet efterföljande nollor i den binära representationen av `self`.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// Returnerar antalet ledande i den binära representationen av `self`.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// Returnerar antalet efterföljande i den binära representationen av `self`.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// Skiftar bitarna åt vänster med en angiven mängd, `n`, som sveper de trunkerade bitarna till slutet av det resulterande heltalet.
        ///
        ///
        /// Observera att detta inte är samma operation som `<<`-växlingsoperatören!
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// Skiftar bitarna till höger med en angiven mängd, `n`, som sveper de trunkerade bitarna till början av det resulterande heltalet.
        ///
        ///
        /// Observera att detta inte är samma operation som `>>`-växlingsoperatören!
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// Omvandlar heltalets byteordning.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// låt m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// Omvandlar ordningen på bitar i heltalet.
        /// Den minst signifikanta biten blir den mest signifikanta biten, den andra minst signifikanta biten blir näst mest betydelsefulla biten, etc.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// låt m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// Konverterar ett heltal från stor endian till målets slutlighet.
        ///
        /// På stora endian är detta ett no-op.På liten endian byts byten.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// om cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } annat {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Konverterar ett heltal från liten endian till målets slutlighet.
        ///
        /// På liten endian är detta ett no-op.På stora endian byts bytes.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// om cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } annat {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Konverterar `self` till stor endian från målets slutlighet.
        ///
        /// På stora endian är detta ett no-op.På liten endian byts byten.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// om cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } annat { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // eller inte vara?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Konverterar `self` till liten endian från målets slutlighet.
        ///
        /// På liten endian är detta ett no-op.På stora endian byts bytes.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// om cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } annat { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Kontrollerat heltalstillägg.
        /// Beräknar `self + rhs`, returnerar `None` om överflöde inträffade.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Okontrollerat heltalstillägg.Beräknar `self + rhs`, förutsatt att överflöde inte kan uppstå.
        /// Detta resulterar i odefinierat beteende när
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Kontrollerad heltalssubtraktion.
        /// Beräknar `self - rhs`, returnerar `None` om överflöde inträffade.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Okontrollerad heltalssubtraktion.Beräknar `self - rhs`, förutsatt att överflöde inte kan uppstå.
        /// Detta resulterar i odefinierat beteende när
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Kontrollerad heltalsmultiplikation.
        /// Beräknar `self * rhs`, returnerar `None` om överflöde inträffade.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Okontrollerad heltalsmultiplikation.Beräknar `self * rhs`, förutsatt att överflöde inte kan uppstå.
        /// Detta resulterar i odefinierat beteende när
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SÄKERHET: den som ringer måste upprätthålla säkerhetsavtalet för `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Kontrollerad heltalsdelning.
        /// Beräknar `self / rhs`, returnerar `None` om `rhs == 0` eller divisionen resulterar i överflöd.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // SÄKERHET: div med noll och med INT_MIN har kontrollerats ovan
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Kontrollerad euklidisk division.
        /// Beräknar `self.div_euclid(rhs)`, returnerar `None` om `rhs == 0` eller divisionen resulterar i överflöd.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// Kontrollerad återstod av heltal.
        /// Beräknar `self % rhs`, returnerar `None` om `rhs == 0` eller divisionen resulterar i överflöd.
        ///
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // SÄKERHET: div med noll och med INT_MIN har kontrollerats ovan
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Kontrollerad euklidisk återstod.
        /// Beräknar `self.rem_euclid(rhs)`, returnerar `None` om `rhs == 0` eller divisionen resulterar i överflöd.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Kontrollerad negation.
        /// Beräknar `-self`, returnerar `None` om `self == MIN`.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kontrollerad skift åt vänster.
        /// Beräknar `self << rhs`, returnerar `None` om `rhs` är större än eller lika med antalet bitar i `self`.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kontrollerad skift till höger.
        /// Beräknar `self >> rhs`, returnerar `None` om `rhs` är större än eller lika med antalet bitar i `self`.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kontrollerat absolut värde.
        /// Beräknar `self.abs()`, returnerar `None` om `self == MIN`.
        ///
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// Kontrollerad exponentiering.
        /// Beräknar `self.pow(exp)`, returnerar `None` om överflöde inträffade.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // eftersom exp!=0 måste slutligen exp vara 1.
            // Hantera den sista biten av exponenten separat, eftersom kvadrering av basen efteråt inte är nödvändig och kan orsaka onödigt överflöd.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Mättande heltalstillägg.
        /// Beräknar `self + rhs`, mättar vid de numeriska gränserna istället för att flyta över.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Mättande heltal subtrahering.
        /// Beräknar `self - rhs`, mättar vid de numeriska gränserna istället för att flyta över.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Mättande heltal negation.
        /// Beräknar `-self`, returnerar `MAX` om `self == MIN` istället för att överflödas.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// Mättande absolutvärde.
        /// Beräknar `self.abs()`, returnerar `MAX` om `self == MIN` istället för att överflödas.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// Mättande heltalsmultiplikation.
        /// Beräknar `self * rhs`, mättar vid de numeriska gränserna istället för att flyta över.
        ///
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// Mättande heltalsexponering.
        /// Beräknar `self.pow(exp)`, mättar vid de numeriska gränserna istället för att flyta över.
        ///
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// Wrapping (modular)-tillägg.
        /// Beräknar `self + rhs`, sveper runt vid typens gräns.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Förpackning (modular) subtraktion.
        /// Beräknar `self - rhs`, sveper runt vid typens gräns.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Inslagning av (modular)-multiplikation.
        /// Beräknar `self * rhs`, sveper runt vid typens gräns.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Inslagning (modular) division.Beräknar `self / rhs`, sveper runt vid typens gräns.
        ///
        /// Det enda fallet där sådan inslagning kan inträffa är när man delar `MIN / -1` på en signerad typ (där `MIN` är det negativa minimivärdet för typen);detta motsvarar `-MIN`, ett positivt värde som är för stort för att representera i typen.
        /// I ett sådant fall returnerar denna funktion `MIN` själv.
        ///
        /// # Panics
        ///
        /// Denna funktion kommer att panic om `rhs` är 0.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// Förpackning av den euklidiska divisionen.
        /// Beräknar `self.div_euclid(rhs)`, sveper runt vid typens gräns.
        ///
        /// Inslagning sker endast i `MIN / -1` på en signerad typ (där `MIN` är det negativa minimivärdet för typen).
        /// Detta motsvarar `-MIN`, ett positivt värde som är för stort för att representera i typen.
        /// I det här fallet returnerar den här metoden `MIN` själv.
        ///
        /// # Panics
        ///
        /// Denna funktion kommer att panic om `rhs` är 0.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// Packning (modular) resten.Beräknar `self % rhs`, sveper runt vid typens gräns.
        ///
        /// Sådan omslag sker faktiskt aldrig matematiskt;implementeringsartefakter gör `x % y` ogiltig för `MIN / -1` på en signerad typ (där `MIN` är det negativa minimivärdet).
        ///
        /// I ett sådant fall returnerar denna funktion `0`.
        ///
        /// # Panics
        ///
        /// Denna funktion kommer att panic om `rhs` är 0.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Inslagning av euklidisk återstod.Beräknar `self.rem_euclid(rhs)`, sveper runt vid typens gräns.
        ///
        /// Inslagning sker endast i `MIN % -1` på en signerad typ (där `MIN` är det negativa minimivärdet för typen).
        /// I det här fallet returnerar den här metoden 0.
        ///
        /// # Panics
        ///
        /// Denna funktion kommer att panic om `rhs` är 0.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// Inslagning av (modular)-negation.Beräknar `-self`, sveper runt vid typens gräns.
        ///
        /// Det enda fallet där sådan inslagning kan inträffa är när man negerar `MIN` på en signerad typ (där `MIN` är det negativa minimivärdet för typen);detta är ett positivt värde som är för stort för att representera i typen.
        /// I ett sådant fall returnerar denna funktion `MIN` själv.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-fri bitvis skift-vänster;ger `self << mask(rhs)`, där `mask` tar bort alla högordnade bitar av `rhs` som skulle få skiftet att överstiga typbredden.
        ///
        /// Observera att detta är *inte* detsamma som en rotera-vänster;RHS för en omslagsförskjutning till vänster är begränsad till typområdet, snarare än att bitarna som flyttats ut från LHS returneras till den andra änden.
        ///
        /// De primitiva heltalstyperna implementerar alla en [`rotate_left`](Self::rotate_left)-funktion, vilket kan vara vad du vill ha istället.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SÄKERHET: maskeringen av bitstorleken av typen ser till att vi inte växlar
            // utanför banan
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-fri bitvis skift-höger;ger `self >> mask(rhs)`, där `mask` tar bort alla högordnade bitar av `rhs` som skulle få skiftet att överstiga typbredden.
        ///
        /// Observera att detta är *inte* detsamma som en rotera-höger;RHS för en omslagsförskjutningshöger är begränsad till typområdet, snarare än att bitarna som flyttats ut från LHS returneras till den andra änden.
        ///
        /// De primitiva heltalstyperna implementerar alla en [`rotate_right`](Self::rotate_right)-funktion, vilket kan vara vad du vill ha istället.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SÄKERHET: maskeringen av bitstorleken av typen ser till att vi inte växlar
            // utanför banan
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Förpackning (modular) absolutvärde.Beräknar `self.abs()`, sveper runt vid typens gräns.
        ///
        /// Det enda fallet där sådan inslagning kan ske är när man tar det absoluta värdet av det negativa minimivärdet för typen;detta är ett positivt värde som är för stort för att representera i typen.
        /// I ett sådant fall returnerar denna funktion `MIN` själv.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// Beräknar det absoluta värdet på `self` utan inslagning eller panik.
        ///
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// Förpackning av (modular)-exponentiering.
        /// Beräknar `self.pow(exp)`, sveper runt vid typens gräns.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // eftersom exp!=0 måste slutligen exp vara 1.
            // Hantera den sista biten av exponenten separat, eftersom kvadrering av basen efteråt inte är nödvändig och kan orsaka onödigt överflöd.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Beräknar `self` + `rhs`
        ///
        /// Returnerar en tupel av tillägget tillsammans med en boolean som indikerar om ett aritmetiskt överflöde skulle inträffa.
        /// Om ett överflöde skulle ha inträffat returneras det inslagna värdet.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Beräknar `self`, `rhs`
        ///
        /// Returnerar en tupel av subtraktionen tillsammans med en boolean som indikerar om ett aritmetiskt överflöde skulle inträffa.
        /// Om ett överflöde skulle ha inträffat returneras det inslagna värdet.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Beräknar multiplikationen av `self` och `rhs`.
        ///
        /// Returnerar en tupel av multiplikationen tillsammans med en boolean som indikerar om ett aritmetiskt överflöde skulle inträffa.
        /// Om ett överflöde skulle ha inträffat returneras det inslagna värdet.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, sant));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Beräknar delaren när `self` divideras med `rhs`.
        ///
        /// Returnerar en del av divisorn tillsammans med en boolean som indikerar om ett aritmetiskt överflöde skulle inträffa.
        /// Om ett överflöde skulle inträffa returneras självet.
        ///
        /// # Panics
        ///
        /// Denna funktion kommer att panic om `rhs` är 0.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// Beräknar kvoten för den euklidiska divisionen `self.div_euclid(rhs)`.
        ///
        /// Returnerar en del av divisorn tillsammans med en boolean som indikerar om ett aritmetiskt överflöde skulle inträffa.
        /// Om ett överflöde skulle inträffa returneras `self`.
        ///
        /// # Panics
        ///
        /// Denna funktion kommer att panic om `rhs` är 0.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// Beräknar resten när `self` divideras med `rhs`.
        ///
        /// Returnerar en tuppel av resten efter delning tillsammans med en boolean som indikerar om ett aritmetiskt överflöde skulle inträffa.
        /// Om ett överflöde skulle inträffa returneras 0.
        ///
        /// # Panics
        ///
        /// Denna funktion kommer att panic om `rhs` är 0.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// Överflödande euklidisk återstod.Beräknar `self.rem_euclid(rhs)`.
        ///
        /// Returnerar en tuppel av resten efter delning tillsammans med en boolean som indikerar om ett aritmetiskt överflöde skulle inträffa.
        /// Om ett överflöde skulle inträffa returneras 0.
        ///
        /// # Panics
        ///
        /// Denna funktion kommer att panic om `rhs` är 0.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// Negerar själv, överflödigt om detta är lika med minimivärdet.
        ///
        /// Returnerar en tupel av den negerade versionen av jaget tillsammans med en boolean som indikerar om ett överflöde hände.
        /// Om `self` är minimivärdet (t.ex. `i32::MIN` för värden av typen `i32`) kommer minimivärdet att returneras igen och `true` kommer att returneras för ett överflöde.
        ///
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// Skiftar själv med `rhs` bitar.
        ///
        /// Returnerar en tupel av den skiftade versionen av själv tillsammans med en boolean som indikerar om skiftvärdet var större än eller lika med antalet bitar.
        /// Om skiftvärdet är för stort maskeras värdet (N-1) där N är antalet bitar, och detta värde används sedan för att utföra skiftet.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, sant));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Skiftar självrätt med `rhs` bitar.
        ///
        /// Returnerar en tupel av den skiftade versionen av själv tillsammans med en boolean som indikerar om skiftvärdet var större än eller lika med antalet bitar.
        /// Om skiftvärdet är för stort maskeras värdet (N-1) där N är antalet bitar, och detta värde används sedan för att utföra skiftet.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, sant));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Beräknar det absoluta värdet på `self`.
        ///
        /// Returnerar en tupel av den absoluta självversionen tillsammans med en boolean som indikerar om ett överflöde hände.
        /// Om själv är minimivärdet
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// då kommer minimivärdet att returneras igen och true kommer att returneras för ett överflöde.
        ///
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// Ökar själv till kraften i `exp`, genom att använda exponentiering genom att kvadrera.
        ///
        /// Returnerar en tupel av exponentieringen tillsammans med en bool som indikerar om ett överflöde hände.
        ///
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, sant));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Skrapa utrymme för att lagra resultat av overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // eftersom exp!=0 måste slutligen exp vara 1.
            // Hantera den sista biten av exponenten separat, eftersom kvadrering av basen efteråt inte är nödvändig och kan orsaka onödigt överflöd.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// Ökar själv till kraften i `exp`, genom att använda exponentiering genom att kvadrera.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // eftersom exp!=0 måste slutligen exp vara 1.
            // Hantera den sista biten av exponenten separat, eftersom kvadrering av basen efteråt inte är nödvändig och kan orsaka onödigt överflöd.
            //
            //
            acc * base
        }

        /// Beräknar kvoten för den euklidiska uppdelningen av `self` med `rhs`.
        ///
        /// Detta beräknar heltalet `n` så att `self = n * rhs + self.rem_euclid(rhs)`, med `0 <= self.rem_euclid(rhs) < rhs`.
        ///
        ///
        /// Med andra ord är resultatet `self / rhs` avrundat till heltalet `n` så att `self >= n * rhs`.
        /// Om `self > 0` är detta lika med runda mot noll (standard i Rust);
        /// om `self < 0` är detta lika med runda mot +/-oändlighet.
        ///
        /// # Panics
        ///
        /// Denna funktion kommer att panic om `rhs` är 0 eller uppdelningen resulterar i överflöd.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// låt b=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// Beräknar den minst icke-negativa återstoden av `self (mod rhs)`.
        ///
        /// Detta görs som av den euklidiska delningsalgoritmen-givet `r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r` och `0 <= r < abs(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Denna funktion kommer att panic om `rhs` är 0 eller uppdelningen resulterar i överflöd.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// låt b=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// Beräknar det absoluta värdet på `self`.
        ///
        /// # Överflödsbeteende
        ///
        /// Det absoluta värdet av
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// kan inte representeras som en
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// och att försöka beräkna det kommer att orsaka ett överflöd.
        /// Detta innebär att kod i felsökningsläge kommer att utlösa en panic i detta fall och optimerad kod kommer att återvända
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// utan panic.
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // Observera att#[inline] ovan betyder att överflödets semantik för subtraktionen beror på crate vi är inriktade på.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// Returnerar ett tal som representerar tecken på `self`.
        ///
        ///  - `0` om siffran är noll
        ///  - `1` om antalet är positivt
        ///  - `-1` om antalet är negativt
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// Returnerar `true` om `self` är positivt och `false` om talet är noll eller negativt.
        ///
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// Returnerar `true` om `self` är negativ och `false` om talet är noll eller positivt.
        ///
        ///
        /// # Examples
        ///
        /// Grundläggande användning:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// Returnera minnesrepresentationen för detta heltal som en byte-array i stor endian (network)-byteordning.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Returnera minnesrepresentationen för detta heltal som en byte-array i liten endian-byteordning.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Returnera minnesrepresentationen för detta heltal som en byte-array i native byte-ordning.
        ///
        /// Eftersom målplattformens ursprungliga slutanvändning används bör bärbar kod använda [`to_be_bytes`] eller [`to_le_bytes`], efter behov, istället.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     byte, om cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } annat {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SÄKERHET: const-ljud eftersom heltal är vanliga gamla datatyper så att vi alltid kan
        // överföra dem till bytesgrupper
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SÄKERHET: heltal är vanliga gamla datatyper så att vi alltid kan överföra dem till
            // matriser med byte
            unsafe { mem::transmute(self) }
        }

        /// Returnera minnesrepresentationen för detta heltal som en byte-array i native byte-ordning.
        ///
        ///
        /// [`to_ne_bytes`] bör föredras framför detta när det är möjligt.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// låt byte= num.as_ne_bytes();
        /// assert_eq!(
        ///     byte, om cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } annat {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SÄKERHET: heltal är vanliga gamla datatyper så att vi alltid kan överföra dem till
            // matriser med byte
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Skapa ett heltal från dess representation som en byte-array i stor endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// använd std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ingång=vila;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Skapa ett heltal från dess representation som en byte-array i liten endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// använd std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ingång=vila;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Skapa ett heltal från dess minnesrepresentation som en byte-array i native endianness.
        ///
        /// Eftersom målplattformens infödda användning används, vill den bärbara koden troligen använda [`from_be_bytes`] eller [`from_le_bytes`], i förekommande fall istället.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } annat {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// använd std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ingång=vila;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SÄKERHET: const-ljud eftersom heltal är vanliga gamla datatyper så att vi alltid kan
        // överför till dem
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SÄKERHET: heltal är vanliga gamla datatyper så att vi alltid kan överföra till dem
            unsafe { mem::transmute(bytes) }
        }

        /// Ny kod bör föredra att använda
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Returnerar det minsta värdet som kan representeras av denna heltalstyp.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// Ny kod bör föredra att använda
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Returnerar det största värdet som kan representeras av denna heltalstyp.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}