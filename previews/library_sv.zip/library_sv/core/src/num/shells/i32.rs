//! Konstanter för den 32-bitars signerade heltalstypen.
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! Ny kod bör använda tillhörande konstanter direkt på den primitiva typen.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }