use crate::fmt;

/// Skapar en ny iterator där varje iteration kallar den medföljande stängningen `F: FnMut() -> Option<T>`.
///
/// Detta gör det möjligt att skapa en anpassad iterator med något beteende utan att använda den mer detaljerade syntaxen för att skapa en dedikerad typ och implementera [`Iterator`] trait för den.
///
/// Observera att `FromFn`-iteratorn inte gör antaganden om stängningens beteende och därför inte implementerar [`FusedIterator`] konservativt eller åsidosätter [`Iterator::size_hint()`] från dess standard `(0, None)`.
///
///
/// Stängningen kan använda inspelningar och dess miljö för att spåra tillstånd över iterationer.Beroende på hur iteratorn används kan detta kräva att du anger [`move`]-nyckelordet på stängningen.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Låt oss implementera counter iterator från [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Öka vårt antal.Det är därför vi började på noll.
///     count += 1;
///
///     // Kontrollera om vi har räknat slut eller inte.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// En iterator där varje iteration kallar den medföljande stängningen `F: FnMut() -> Option<T>`.
///
/// Denna `struct` skapas av [`iter::from_fn()`]-funktionen.
/// Se dess dokumentation för mer information.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}