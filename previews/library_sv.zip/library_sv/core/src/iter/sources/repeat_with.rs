use crate::iter::{FusedIterator, TrustedLen};

/// Skapar en ny iterator som upprepar element av typen `A` oändligt genom att använda den medföljande förslutningen, repeatern, `F: FnMut() -> A`.
///
/// `repeat_with()`-funktionen anropar repeatern om och om igen.
///
/// Oändliga iteratorer som `repeat_with()` används ofta med adaptrar som [`Iterator::take()`] för att göra dem ändliga.
///
/// Om elementtypen för iteratorn du behöver implementerar [`Clone`], och det är OK att behålla källelementet i minnet, bör du istället använda [`repeat()`]-funktionen.
///
///
/// En iterator som produceras av `repeat_with()` är inte en [`DoubleEndedIterator`].
/// Om du behöver `repeat_with()` för att returnera en [`DoubleEndedIterator`], vänligen öppna ett GitHub-problem som förklarar ditt användningsfall.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// use std::iter;
///
/// // låt oss anta att vi har något värde av en typ som inte är `Clone` eller som inte vill ha i minnet ännu eftersom det är dyrt:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // ett visst värde för alltid:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Använda mutation och gå ändligt:
///
/// ```rust
/// use std::iter;
///
/// // Från noll till tredje kraft av två:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... och nu är vi klara
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// En iterator som upprepar element av typen `A` oändligt genom att använda den medföljande förslutningen `F: FnMut() -> A`.
///
///
/// Denna `struct` skapas av [`repeat_with()`]-funktionen.
/// Se dess dokumentation för mer information.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}