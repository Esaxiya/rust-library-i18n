use crate::iter::{FusedIterator, TrustedLen};

/// Skapar en iterator som lätt skapar ett värde exakt en gång genom att åberopa den medföljande stängningen.
///
/// Detta används vanligtvis för att anpassa en enskild värdegenerator till en [`chain()`] av andra typer av iteration.
/// Kanske har du en iterator som täcker nästan allt, men du behöver ett extra specialfall.
/// Kanske har du en funktion som fungerar på iteratorer, men du behöver bara bearbeta ett värde.
///
/// Till skillnad från [`once()`] genererar denna funktion latvärdet på begäran.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// use std::iter;
///
/// // en är det ensamaste numret
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // bara en, det är allt vi får
/// assert_eq!(None, one.next());
/// ```
///
/// Kedjning tillsammans med en annan iterator.
/// Låt oss säga att vi vill itera över varje fil i `.foo`-katalogen, men också en konfigurationsfil,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // vi måste konvertera från en iterator av DirEntry-s till en iterator av PathBufs, så vi använder karta
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // nu, vår iterator bara för vår konfigurationsfil
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // kedja de två iteratorerna ihop till en stor iterator
/// let files = dirs.chain(config);
///
/// // detta kommer att ge oss alla filer i .foo såväl som .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// En iterator som ger ett enda element av typen `A` genom att använda den medföljande förslutningen `F: FnOnce() -> A`.
///
///
/// Denna `struct` skapas av [`once_with()`]-funktionen.
/// Se dess dokumentation för mer information.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}