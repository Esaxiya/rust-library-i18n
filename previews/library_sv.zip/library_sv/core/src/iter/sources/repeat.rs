use crate::iter::{FusedIterator, TrustedLen};

/// Skapar en ny iterator som oändligt upprepar ett enda element.
///
/// `repeat()`-funktionen upprepar ett enda värde om och om igen.
///
/// Oändliga iteratorer som `repeat()` används ofta med adaptrar som [`Iterator::take()`] för att göra dem ändliga.
///
/// Om elementtypen för iteratorn du behöver inte implementerar `Clone`, eller om du inte vill behålla det upprepade elementet i minnet kan du istället använda [`repeat_with()`]-funktionen.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// use std::iter;
///
/// // nummer fyra 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // japp, fortfarande fyra
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Går ändligt med [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // det sista exemplet var för många fyra.Låt oss bara ha fyra fyror.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... och nu är vi klara
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// En iterator som upprepar ett element oändligt.
///
/// Denna `struct` skapas av [`repeat()`]-funktionen.Se dess dokumentation för mer information.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}