use crate::iter::{FusedIterator, TrustedLen};

/// Skapar en iterator som ger ett element exakt en gång.
///
/// Detta används vanligtvis för att anpassa ett enda värde till en [`chain()`] av andra typer av iteration.
/// Kanske har du en iterator som täcker nästan allt, men du behöver ett extra specialfall.
/// Kanske har du en funktion som fungerar på iteratorer, men du behöver bara bearbeta ett värde.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// use std::iter;
///
/// // en är det ensamaste numret
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // bara en, det är allt vi får
/// assert_eq!(None, one.next());
/// ```
///
/// Kedjning tillsammans med en annan iterator.
/// Låt oss säga att vi vill itera över varje fil i `.foo`-katalogen, men också en konfigurationsfil,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // vi måste konvertera från en iterator av DirEntry-s till en iterator av PathBufs, så vi använder karta
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // nu, vår iterator bara för vår konfigurationsfil
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // kedja de två iteratorerna ihop till en stor iterator
/// let files = dirs.chain(config);
///
/// // detta kommer att ge oss alla filer i .foo såväl som .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// En iterator som ger ett element exakt en gång.
///
/// Denna `struct` skapas av [`once()`]-funktionen.Se dess dokumentation för mer information.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}