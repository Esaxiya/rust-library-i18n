/// En iterator som vet sin exakta längd.
///
/// Många [`Iterator`] vet inte hur många gånger de kommer att itera, men vissa gör det.
/// Om en iterator vet hur många gånger den kan itera, kan det vara användbart att ge tillgång till den informationen.
/// Om du till exempel vill iterera bakåt är en bra start att veta var slutet är.
///
/// När du implementerar en `ExactSizeIterator` måste du också implementera [`Iterator`].
/// När du gör det måste implementeringen av [`Iterator::size_hint`] * returnera exakt storleken på iteratorn.
///
/// [`len`]-metoden har en standardimplementering, så du brukar inte implementera den.
/// Du kan dock kunna tillhandahålla en mer utförlig implementering än standard, så det är vettigt att åsidosätta det i det här fallet.
///
///
/// Observera att denna trait är en säker trait och som sådan inte *och* kan * inte garantera att den returnerade längden är korrekt.
/// Detta innebär att `unsafe`-koden **inte får** förlita sig på riktigheten hos [`Iterator::size_hint`].
/// Den instabila och osäkra [`TrustedLen`](super::marker::TrustedLen) trait ger denna extra garanti.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// // ett begränsat intervall vet exakt hur många gånger det kommer att upprepas
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// I [module-level docs] implementerade vi en [`Iterator`], `Counter`.
/// Låt oss implementera `ExactSizeIterator` för det också:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Vi kan enkelt beräkna det återstående antalet iterationer.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Och nu kan vi använda det!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Returnerar den exakta längden på iteratorn.
    ///
    /// Implementeringen säkerställer att iteratorn returnerar exakt `len()` fler gånger ett [`Some(T)`]-värde innan [`None`] returneras.
    ///
    /// Den här metoden har en standardimplementering, så du bör vanligtvis inte implementera den direkt.
    /// Men om du kan erbjuda en mer effektiv implementering kan du göra det.
    /// Se [trait-level]-dokumenten för ett exempel.
    ///
    /// Denna funktion har samma säkerhetsgarantier som [`Iterator::size_hint`]-funktionen.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// // ett begränsat intervall vet exakt hur många gånger det kommer att upprepas
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Detta påstående är alltför defensivt, men det kontrollerar invarianten
        // garanteras av trait.
        // Om denna trait var rust-intern skulle vi kunna använda debug_assert !;assert_eq!kommer också att kontrollera alla Rust-användarimplementeringar.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Returnerar `true` om iteratorn är tom.
    ///
    /// Den här metoden har en standardimplementering med [`ExactSizeIterator::len()`], så du behöver inte implementera den själv.
    ///
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}