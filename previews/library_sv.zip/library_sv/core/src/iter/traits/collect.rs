/// Konvertering från en [`Iterator`].
///
/// Genom att implementera `FromIterator` för en typ definierar du hur den ska skapas från en iterator.
/// Detta är vanligt för typer som beskriver en samling av något slag.
///
/// [`FromIterator::from_iter()`] kallas sällan uttryckligen och används istället genom [`Iterator::collect()`]-metoden.
///
/// Se [`Iterator::collect()`]'s-dokumentationen för fler exempel.
///
/// Se även: [`IntoIterator`].
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Använda [`Iterator::collect()`] för att implicit använda `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Implementera `FromIterator` för din typ:
///
/// ```
/// use std::iter::FromIterator;
///
/// // En provsamling, det är bara en omslag över Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Låt oss ge det några metoder så att vi kan skapa en och lägga till saker i den.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // och vi implementerar FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Nu kan vi skapa en ny iterator ...
/// let iter = (0..5).into_iter();
///
/// // ... och gör en MyCollection av den
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // samla verk också!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Skapar ett värde från en iterator.
    ///
    /// Se [module-level documentation] för mer information.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Omvandling till en [`Iterator`].
///
/// Genom att implementera `IntoIterator` för en typ definierar du hur den ska konverteras till en iterator.
/// Detta är vanligt för typer som beskriver en samling av något slag.
///
/// En fördel med att implementera `IntoIterator` är att din typ kommer att [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Se även: [`FromIterator`].
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Implementera `IntoIterator` för din typ:
///
/// ```
/// // En provsamling, det är bara en omslag över Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Låt oss ge det några metoder så att vi kan skapa en och lägga till saker i den.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // och vi implementerar IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Nu kan vi skapa en ny samling ...
/// let mut c = MyCollection::new();
///
/// // ... lägg till några saker till det ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... och gör det sedan till en Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Det är vanligt att använda `IntoIterator` som en trait bound.Detta gör att insamlingstypen kan ändras så länge den fortfarande är en iterator.
/// Ytterligare gränser kan anges genom att begränsa till
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Typen av element som itereras över.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Vilken typ av iterator gör vi detta till?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Skapar en iterator från ett värde.
    ///
    /// Se [module-level documentation] för mer information.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Utöka en samling med innehållet i en iterator.
///
/// Iteratorer producerar en serie värden, och samlingar kan också betraktas som en serie värden.
/// `Extend` trait överbryggar detta gap, så att du kan utöka en samling genom att inkludera innehållet i den iteratorn.
/// När en samling utökas med en redan befintlig nyckel uppdateras den posten eller, om det gäller samlingar som tillåter flera poster med lika nycklar, införs den posten.
///
///
/// # Examples
///
/// Grundläggande användning:
///
/// ```
/// // Du kan förlänga en sträng med några tecken:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Implementering av `Extend`:
///
/// ```
/// // En provsamling, det är bara en omslag över Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Låt oss ge det några metoder så att vi kan skapa en och lägga till saker i den.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // eftersom MyCollection har en lista över i32, implementerar vi Extend för i32
/// impl Extend<i32> for MyCollection {
///
///     // Detta är lite enklare med den konkreta typsignaturen: vi kan ringa förlängning på allt som kan förvandlas till en Iterator som ger oss i32.
///     // Eftersom vi behöver i32-filer för att sätta i MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Implementeringen är väldigt enkel: slinga igenom iteratorn och add() varje element för oss själva.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // låt oss utöka vår samling med ytterligare tre nummer
/// c.extend(vec![1, 2, 3]);
///
/// // vi har lagt till dessa element i slutet
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Utökar en samling med innehållet i en iterator.
    ///
    /// Eftersom detta är den enda metod som krävs för denna trait innehåller [trait-level]-dokumenten mer information.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Grundläggande användning:
    ///
    /// ```
    /// // Du kan förlänga en sträng med några tecken:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Utökar en samling med exakt ett element.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Reserverar kapacitet i en samling för det angivna antalet ytterligare element.
    ///
    /// Standardimplementeringen gör ingenting.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}